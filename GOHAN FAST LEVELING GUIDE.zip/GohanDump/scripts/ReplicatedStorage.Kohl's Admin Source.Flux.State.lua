-- Decompiled with Potassium's decompiler.

local RunService = game:GetService("RunService");
local script_Parent = script.Parent;
require(script_Parent.Type);
local DataType = require(script_Parent.DataType);
local u1 = {
    __mode = "k"
};
local u2 = {
    deferUpdates = true
};
u2.__index = u2;

function u2.isState(p3) -- Line: 14
    -- upvalues: u2 (copy)
    local v4;

    if type(p3) == "table" then
        v4 = getmetatable(p3) == u2;
    else
        v4 = false;
    end;

    return v4;
end;

local isState = u2.isState;

function u2.raw(p5) -- Line: 20
    -- upvalues: u2 (copy)
    if type(p5) == "table" and getmetatable(p5) == u2 then
        return p5._value;
    end;

    return p5;
end;

local raw = u2.raw;

function u2.rawVariadic(...) -- Line: 26
    -- upvalues: raw (copy)
    local v6 = {};

    for _, v in { ... } do
        table.insert(v6, raw(v));
    end;

    return unpack(v6);
end;

function u2.new(p7: any, p8: string?) -- Line: 54
    -- upvalues: isState (copy), u1 (copy), u2 (copy)
    if isState(p7) then
        return p7;
    end;

    local v9 = {
        _dependents = setmetatable({}, u1),
        _dependencies = {},
        _value = p7
    };
    local v10 = setmetatable(v9, u2);

    if p8 then
        if typeof(p7) ~= "Instance" then
            error((`Instance expected got {typeof(p7)}`));
        end;

        v10:_bindToProperty(p7, p8);
    end;

    return v10;
end;

local u11 = {};

function u2.compute(p12: function) -- Line: 78
    -- upvalues: u11 (copy), u2 (copy)
    local v13 = u11[p12];

    if v13 then
        return v13;
    end;

    local v14 = u2.new();
    v14._computation = p12;
    u11[p12] = v14;
    v14:_doComputation(true);

    return v14;
end;

local u15 = {};

function u2._updateDependence(p16) -- Line: 96
    -- upvalues: isState (copy), u15 (copy)
    local v17 = isState(p16) and u15[coroutine.running()];

    if v17 then
        p16._dependents[v17] = true;
        v17._dependencies[p16] = true;
    end;

    return p16;
end;

local _updateDependence = u2._updateDependence;

function u2._updateValue(p18: table, p19: any, p20: boolean?) -- Line: 110
    -- upvalues: raw (copy), DataType (copy)
    if not p20 then
        local v21 = raw(p18._tweenInfo);

        if v21 then
            p18._tweenInit = os.clock() + v21.DelayTime;
            p18._tweenGoal = p19;
            p18._tweenStart = p18._value;
            p18._tweenRepeat = v21.RepeatCount;

            return;
        end;

        if p18._springGoal then
            if p18._value ~= p19 then
                p18._activeStartP = DataType.unpack(p18._value, (typeof(p18._value)));
                p18._activeStartV = table.clone(p18._activeLatestV);
                p18._springGoal = p19;
                p18._springInit = os.clock();
            end;

            return;
        end;
    end;

    p18._value = p19;
end;

function u2.__call(p22, ...) -- Line: 132
    if select("#", ...) == 0 then
        p22:_updateDependence();

        return p22._value;
    end;

    local v23, v24, v25 = ...;
    local _value = p22._value;

    if v24 or (v23 ~= _value or type(_value) == "table") then
        p22:_updateValue(v23, v25);
        p22:_update(v24, v25, true);
    end;

    return p22;
end;

function u2.__concat(p26, p27) -- Line: 148
    -- upvalues: raw (copy), _updateDependence (copy)
    return raw(_updateDependence(p26)) .. raw(_updateDependence(p27));
end;

function u2.__unm(p28) -- Line: 151
    -- upvalues: _updateDependence (copy)
    return -_updateDependence(p28)._value;
end;

function u2.__add(p29, p30) -- Line: 154
    -- upvalues: raw (copy), _updateDependence (copy)
    return raw(_updateDependence(p29)) + raw(_updateDependence(p30));
end;

function u2.__sub(p31, p32) -- Line: 157
    -- upvalues: raw (copy), _updateDependence (copy)
    return raw(_updateDependence(p31)) - raw(_updateDependence(p32));
end;

function u2.__mul(p33, p34) -- Line: 160
    -- upvalues: raw (copy), _updateDependence (copy)
    return raw(_updateDependence(p33)) * raw(_updateDependence(p34));
end;

function u2.__div(p35, p36) -- Line: 163
    -- upvalues: raw (copy), _updateDependence (copy)
    return raw(_updateDependence(p35)) / raw(_updateDependence(p36));
end;

function u2.__idiv(p37, p38) -- Line: 166
    -- upvalues: raw (copy), _updateDependence (copy)
    return raw(_updateDependence(p37)) // raw(_updateDependence(p38));
end;

function u2.__mod(p39, p40) -- Line: 169
    -- upvalues: raw (copy), _updateDependence (copy)
    return raw(_updateDependence(p39)) % raw(_updateDependence(p40));
end;

function u2.__pow(p41, p42) -- Line: 172
    -- upvalues: raw (copy), _updateDependence (copy)
    return raw(_updateDependence(p41)) ^ raw(_updateDependence(p42));
end;

function u2.__tostring(p43) -- Line: 175
    -- upvalues: _updateDependence (copy)
    local _value = _updateDependence(p43)._value;

    return tostring(_value);
end;

function u2.__len(p44) -- Line: 178
    -- upvalues: _updateDependence (copy)
    return #_updateDependence(p44)._value;
end;

local u45 = {};
RunService.Heartbeat:Connect(function() -- Line: 184
    -- upvalues: u45 (copy)
    for i, v in u45 do
        if type(i._update) == "function" then
            task.spawn(i._update, i, nil, v % 2 == 1, v % 4 >= 2, true);
        end;
    end;
end);

function u2._dependencyUpdating(p46) -- Line: 193
    -- upvalues: u45 (copy)
    for i in p46._dependencies do
        if u45[i] or i._dependencyUpdating and i:_dependencyUpdating() then
            return true;
        end;
    end;

    return false;
end;

function u2._doComputation(p47: table, p48: boolean?) -- Line: 202
    -- upvalues: u15 (copy), raw (copy), _updateDependence (copy)
    if type(p47._computation) == "function" then
        local coroutine_running_ret = coroutine.running();
        local v49 = u15[coroutine_running_ret];
        u15[coroutine_running_ret] = p47;

        for i in p47._dependencies do
            i._dependents[p47] = nil;
            p47._dependencies[i] = nil;
        end;

        local success, result = pcall(p47._computation);

        if success then
            p47:_updateValue(raw(_updateDependence(result)), p48);
        else
            warn((`{result}\n{debug.traceback()}`));
        end;

        u15[coroutine_running_ret] = v49;
    end;
end;

function u2._update(p50: table, p51: boolean?, p52: boolean?, p53: boolean?, p54: boolean?) -- Line: 224
    -- upvalues: u2 (copy), u45 (copy)
    if u2.deferUpdates then
        if not p51 then
            if not p54 then
                u45[p50] = (p52 and 1 or 0) + (p53 and 2 or 0);

                return;
            end;

            if p50:_dependencyUpdating() then
                return;
            end;
        end;

        u45[p50] = nil;
    end;

    if not p53 then
        u2._doComputation(p50, p52);
    end;

    local _value = p50._value;

    if p50._binds then
        for i, v in p50._binds do
            local v55 = i;

            for i2, v2 in v do
                if type(i2) == "string" then
                    v55:SetAttribute(i2, _value);
                elseif type(v2) == "string" then
                    v55[v2] = _value;
                end;
            end;
        end;
    end;

    if p50._boundParent then
        p50:_updateBoundChildren();
    end;

    for i in p50._dependents do
        if type(i) == "table" and type(i._update) == "function" then
            task.spawn(i._update, i, p51, p52, nil, p54);
        end;
    end;

    if p50._connections then
        for i in p50._connections do
            if type(i) == "function" then
                task.spawn(i, _value);
            end;
        end;
    end;
end;

function u2._updateBoundChildren(p56) -- Line: 277
    local _boundParent = p56._boundParent;

    if typeof(_boundParent) == "Instance" then
        for _, v in p56._boundChildren do
            v.Parent = nil;
        end;

        table.clear(p56._boundChildren);
        local _boundChildrenLayoutOrder = p56._boundChildrenLayoutOrder;
        local _value = p56._value;

        if typeof(_value) == "Instance" then
            table.insert(p56._boundChildren, _value);

            if _value:IsA("GuiObject") and _value.LayoutOrder == 0 then
                _value.LayoutOrder = _boundChildrenLayoutOrder;
            end;

            _value.Parent = _boundParent;

            return;
        end;

        if type(_value) == "table" then
            for _, v in _value do
                if typeof(v) == "Instance" then
                    table.insert(p56._boundChildren, v);

                    if v:IsA("GuiObject") and v.LayoutOrder == 0 then
                        v.LayoutOrder = _boundChildrenLayoutOrder;
                        _boundChildrenLayoutOrder = _boundChildrenLayoutOrder + 1;
                    end;

                    v.Parent = _boundParent;
                end;
            end;
        end;
    end;
end;

local u57 = {};

function u2._bindProperty(p58: table, u59: userdata, p60: string) -- Line: 312
    -- upvalues: u57 (copy), isState (copy)
    local v61 = u57[u59];
    local v62;

    if v61 then
        v62 = v61[p60];
    else
        v62 = v61;
    end;

    if v62 then
        local v63 = v62._binds[u59];

        if string.find(p60, "Attribute.", 1, true) == 1 then
            v63[string.sub(p60, 11)] = nil;
        else
            local table_find_ret = table.find(v63, p60);

            if table_find_ret then
                table.remove(v63, table_find_ret);
            end;
        end;
    end;

    if not isState(p58) then
        return;
    end;

    if p58._binds then
        if not p58._binds[u59] then
            p58._binds[u59] = {};
        end;
    else
        p58._binds = {
            [u59] = {}
        };
    end;

    if string.find(p60, "Attribute.", 1, true) == 1 then
        p58._binds[u59][string.sub(p60, 11)] = true;
    else
        table.insert(p58._binds[u59], p60);
    end;

    if v61 then
        v61[p60] = p58;

        return;
    end;

    u57[u59] = {
        [p60] = p58
    };
    u59.Destroying:Once(function() -- Line: 347
        -- upvalues: u57 (ref), u59 (copy)
        for _, v in u57[u59] do
            if v._binds then
                v._binds[u59] = nil;
            end;
        end;

        table.clear(u57[u59]);
        u57[u59] = nil;
    end);
end;

function u2._bindToProperty(u64: table, u65: userdata, u66: string) -- Line: 362
    if u64._bindConnection then
        u64._bindConnection:Disconnect();
    end;

    if string.find(u66, "Attribute.", 1, true) ~= 1 then
        u64._value = u65[u66];
        u64._bindConnection = u65:GetPropertyChangedSignal(u66):Connect(function() -- Line: 376
            -- upvalues: u64 (copy), u65 (copy), u66 (copy)
            u64(u65[u66]);
        end);

        return;
    end;

    local string_sub_ret = string.sub(u66, 11);
    u64._value = u65:GetAttribute(string_sub_ret);
    u64._bindConnection = u65:GetAttributeChangedSignal(string_sub_ret):Connect(function() -- Line: 371
        -- upvalues: u64 (copy), u65 (copy), string_sub_ret (copy)
        u64(u65:GetAttribute(string_sub_ret));
    end);
end;

function u2.Connect(p67, u68) -- Line: 383
    if not p67._connections then
        p67._connections = {};
    end;

    local _connections = p67._connections;
    _connections[u68] = true;

    return function() -- Line: 391
        -- upvalues: _connections (copy), u68 (copy)
        _connections[u68] = nil;
    end;
end;

function u2.Destroy(p69) -- Line: 397
    -- upvalues: u45 (copy), u57 (copy)
    setmetatable(p69, nil);
    u45[p69] = nil;

    for i in p69._dependencies do
        p69._dependencies[i] = nil;
        i._dependents[p69] = nil;
    end;

    if p69._bindConnection then
        p69._bindConnection:Disconnect();
    end;

    if p69._binds then
        for i, v in p69._binds do
            local v70 = u57[i];

            for i2, v2 in v do
                if type(i2) == "string" then
                    v70[i2] = nil;
                elseif type(i2) == "number" then
                    v70[v2] = nil;
                end;
            end;
        end;

        table.clear(p69._binds);
    end;

    for i in p69._dependents do
        i:Destroy();
    end;

    table.clear(p69);
end;

return u2;