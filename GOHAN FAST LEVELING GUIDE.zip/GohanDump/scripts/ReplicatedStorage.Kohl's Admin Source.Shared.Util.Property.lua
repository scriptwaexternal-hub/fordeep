-- Decompiled with Potassium's decompiler.

local u1 = {};
local u2 = {};
u1.cache = u2;

function u1.override(u3: userdata, u4: string, p5: any) -- Line: 7
    -- upvalues: u2 (copy), u1 (copy)
    local u6 = u2[u3];

    if not u6 then
        u6 = {};
        u2[u3] = u6;
        u3.Destroying:Once(function() -- Line: 12
            -- upvalues: u6 (ref), u1 (ref), u3 (copy), u2 (ref)
            for i in u6 do
                u1.reset(u3, i);
            end;

            table.clear(u6);
            u2[u3] = nil;
        end);
    end;

    local u7 = u6[u4];

    if not u7 then
        u7 = { u3[u4] };
        u6[u4] = u7;
        u7[3] = u3:GetPropertyChangedSignal(u4):Connect(function() -- Line: 25
            -- upvalues: u7 (ref), u3 (copy), u4 (copy)
            if not u7 or u7[4] then
                return;
            end;

            u7[1] = u3[u4];
            u7[4] = true;
            u3[u4] = u7[2];
            u7[4] = false;
        end);
    end;

    u7[2] = p5;
    u7[4] = true;
    u3[u4] = p5;
    u7[4] = false;
end;

function u1.reset(p8: userdata, p9: string) -- Line: 47
    -- upvalues: u2 (copy)
    local v10 = u2[p8];
    local v11;

    if v10 then
        v11 = v10[p9];
    else
        v11 = nil;
    end;

    if v11 then
        if typeof(v11[3]) == "RBXScriptConnection" then
            v11[3]:Disconnect();
        end;

        p8[p9] = v11[1];
        v10[p9] = nil;
        table.clear(v11);
    end;
end;

return u1;