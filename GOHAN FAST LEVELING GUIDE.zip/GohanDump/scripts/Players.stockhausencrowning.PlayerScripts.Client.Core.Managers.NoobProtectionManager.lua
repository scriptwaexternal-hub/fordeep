-- Decompiled with Potassium's decompiler.

local ReplicatedStorage = game:GetService("ReplicatedStorage");
game:GetService("UserInputService");
local Players = game:GetService("Players");
game:GetService("Debris");
local Modules = ReplicatedStorage:WaitForChild("Modules");
local Remotes = ReplicatedStorage:WaitForChild("Remotes");
local _ = Modules.Metadata;
local _ = Modules.Shared;
local _ = Modules.Utility;
local _ = ReplicatedStorage.Assets;
local ServerRemote = Remotes.ServerRemote;
local LocalPlayer = Players.LocalPlayer;

local function GetTimeLeft(p1) -- Line: 31
    local v2 = p1 - tick();

    return v2 < 0 and 0 or v2;
end;

local function FormatTimeLeft(p3) -- Line: 44
    local math_floor_ret = math.floor(p3 / 3600);
    local math_floor_ret2 = math.floor(p3 % 3600 / 60);
    local math_floor_ret3 = math.floor(p3 % 60);

    return string.format("Time Left: %02d:%02d:%02d", math_floor_ret, math_floor_ret2, math_floor_ret3);
end;

local v4 = {};

local function getPanel() -- Line: 59
    -- upvalues: LocalPlayer (copy)
    local HUD = LocalPlayer:WaitForChild("PlayerGui"):WaitForChild("HUD", 5);

    if HUD then
        HUD = HUD:FindFirstChild("NoobProtection");
    end;

    return HUD;
end;

local u5 = 0;

function v4.Fire(p6) -- Line: 68
    -- upvalues: u5 (ref), LocalPlayer (copy), ServerRemote (copy)
    u5 = u5 + 1;
    local v7 = u5;
    local HUD = LocalPlayer:WaitForChild("PlayerGui"):WaitForChild("HUD", 5);

    if HUD then
        HUD = HUD:FindFirstChild("NoobProtection");
    end;

    if not HUD then
        return;
    end;

    local v8 = tonumber(p6.endTime) or 0;

    if v8 <= 0 then
        HUD.Visible = false;

        return;
    end;

    HUD.Visible = true;
    HUD.Exit.MouseButton1Up:Once(function() -- Line: 79
        -- upvalues: HUD (copy)
        HUD.Visible = false;
    end);
    HUD.Disable.MouseButton1Up:Once(function() -- Line: 84
        -- upvalues: HUD (copy), ServerRemote (ref)
        HUD.Visible = false;
        ServerRemote:FireServer(nil, {
            Module = "NoobProtectionHandler",
            Action = "Remove"
        });
    end);

    while u5 == v7 and (HUD.Parent and (HUD.Visible == true and v8 > 0)) do
        local TimeLabel = HUD:FindFirstChild("TimeLabel");

        if TimeLabel then
            local math_floor_ret = math.floor(v8 / 3600);
            local math_floor_ret2 = math.floor(v8 % 3600 / 60);
            local math_floor_ret3 = math.floor(v8 % 60);
            TimeLabel.Text = string.format("Time Left: %02d:%02d:%02d", math_floor_ret, math_floor_ret2, math_floor_ret3);
        end;

        v8 = v8 - 1;
        task.wait(1);
    end;

    if u5 == v7 and (HUD.Parent and v8 <= 0) then
        HUD.Visible = false;
    end;
end;

function v4.End(p9) -- Line: 106
    -- upvalues: u5 (ref), LocalPlayer (copy)
    u5 = u5 + 1;
    local HUD = LocalPlayer:WaitForChild("PlayerGui"):WaitForChild("HUD", 5);

    if HUD then
        HUD = HUD:FindFirstChild("NoobProtection");
    end;

    if HUD then
        HUD.Visible = false;
    end;
end;

return v4;