-- Decompiled with Potassium's decompiler.

local Parent = require(script.Parent.Parent);
local BaseClass = require(script.Parent:WaitForChild("BaseClass"));
require(script.Parent:WaitForChild("Menu"));
local u1 = {
    Adornee = false,
    RightAlign = false,
    Visible = false,
    Value = Color3.new(1, 0, 0)
};
local ColorSequence_new_ret = ColorSequence.new({
    ColorSequenceKeypoint.new(0, Color3.fromRGB(255, 0, 0)),
    ColorSequenceKeypoint.new(0.16666666666666666, Color3.fromRGB(255, 255, 0)),
    ColorSequenceKeypoint.new(0.3333333333333333, Color3.fromRGB(0, 255, 0)),
    ColorSequenceKeypoint.new(0.5, Color3.fromRGB(0, 255, 255)),
    ColorSequenceKeypoint.new(0.6666666666666666, Color3.fromRGB(0, 0, 255)),
    ColorSequenceKeypoint.new(0.8333333333333334, Color3.fromRGB(255, 0, 255)),
    ColorSequenceKeypoint.new(1, Color3.fromRGB(255, 0, 0))
});
local u3 = Parent.compute(function() -- Line: 26
    -- upvalues: Parent (copy)
    local v2 = Parent.Theme.FontSize();
    local Offset = Parent.Theme.Padding().Offset;

    return UDim2.fromOffset(math.max(80, 3.5 * v2 + Offset), v2 + Offset);
end);
local u5 = Parent.compute(function() -- Line: 32
    -- upvalues: Parent (copy), u3 (copy)
    local Offset = Parent.Theme.Padding().Offset;
    local v4 = Parent.Theme.FontSize() + Offset;

    return UDim2.new(0, v4, 0, Parent.Theme.FontSize() + u3().X.Offset + Offset * 2);
end);
local u6 = Parent.compute(function() -- Line: 38
    -- upvalues: u3 (copy)
    local Offset = u3().X.Offset;

    return UDim2.fromOffset(Offset, Offset);
end);
local u7 = Parent.compute(function() -- Line: 43
    -- upvalues: Parent (copy)
    if Parent.getLuminance(Parent.Theme.Primary()) > 0.5 then
        return Color3.new();
    end;

    return Color3.new(1, 1, 1);
end);
local u8 = {};
u8.__index = u8;
setmetatable(u8, BaseClass);

function u8.new(p9) -- Line: 51
    -- upvalues: u1 (copy), Parent (copy), u5 (copy), ColorSequence_new_ret (copy), u7 (copy), u3 (copy), u6 (copy), u8 (copy)
    local table_clone_ret = table.clone(u1);
    Parent.makeStatefulDefaults(table_clone_ret, p9);
    local v10 = {};
    local u11 = Parent.state(false);
    table.insert(v10, u11);
    local u12 = 0;
    local u20 = Parent.new("Slider")({
        Name = "HueSlider",
        Vertical = true,
        Size = u5,

        Value = function() -- Line: 65, Name: Value
            -- upvalues: table_clone_ret (copy), u12 (ref)
            local v13, v14, v15 = table_clone_ret.Value():ToHSV();
            local v16 = v13 == 1 and u12 == 0 and 0 or v13;

            if v14 <= 0 or v15 <= 0 then
                v16 = u12;
            end;

            u12 = v16;

            return u12;
        end,

        Parent.new("Frame")({
            Name = "Rainbow",
            BackgroundColor3 = Color3.new(1, 1, 1),
            AnchorPoint = Vector2.new(0.5, 0.5),
            Size = UDim2.new(1, 0, 1, 0),
            Position = UDim2.new(0.5, 0, 0.5, 0),
            Parent.new("UICorner")({
                CornerRadius = Parent.Theme.CornerPadded
            }),
            Parent.new("Stroke")({}),
            Parent.new("UIGradient")({
                Rotation = 90,
                Color = ColorSequence_new_ret
            })
        }),
        [Parent.Hook] = {
            Value = function(p17) -- Line: 92, Name: Value
                -- upvalues: u12 (ref), table_clone_ret (copy)
                if p17 == u12 then
                    return;
                end;

                local _, v18, v19 = table_clone_ret.Value._value:ToHSV();
                local Color3_fromHSV_ret = Color3.fromHSV(p17, v18, v19);
                u12 = p17;
                table_clone_ret.Value(Color3_fromHSV_ret, true);
            end
        }
    });
    table_clone_ret.hueSlider = u20;
    local v21 = Parent.compute(function() -- Line: 106
        -- upvalues: u20 (copy)
        return Color3.fromHSV(u20.Value(), 1, 1);
    end);
    Parent.edit(u20._slider, {
        BackgroundColor3 = v21,
        Parent.new("UIStroke")({
            Thickness = 1.5,
            ApplyStrokeMode = Enum.ApplyStrokeMode.Border,
            Color = Color3.new(1, 1, 1)
        })
    });
    u20._instance:FindFirstChild("Filled"):Destroy();
    local v24 = Parent.new("Input")({
        FontFace = Parent.Theme.FontMono,
        BackgroundColor3 = u7,
        TextColor3 = u7,
        Size = u3,
        Padding = UDim.new(0, 5),

        Validate = function(p22) -- Line: 125, Name: Validate
            return pcall(Color3.fromHex, p22);
        end,

        Value = function() -- Line: 128, Name: Value
            -- upvalues: table_clone_ret (copy)
            return `#{table_clone_ret.Value():ToHex()}`;
        end,

        [Parent.Hook] = {
            Value = function(p23) -- Line: 133, Name: Value
                -- upvalues: table_clone_ret (copy)
                if p23 == `#{table_clone_ret.Value():ToHex()}` then
                    return;
                end;

                table_clone_ret.Value(Color3.fromHex(p23), true);
            end
        }
    });
    table_clone_ret.hexInput = v24;
    local u25 = nil;
    local u26 = nil;
    local u27 = Parent.state(0);

    local function update(p28) -- Line: 145
        -- upvalues: u26 (ref), u25 (ref), u27 (copy), u12 (ref), table_clone_ret (copy)
        if not u26 then
            return;
        end;

        local math_clamp_ret = math.clamp((p28.Position.X - u25.AbsolutePosition.X - 8) / (u25.AbsoluteSize.X - 16), 0, 1);
        local v29 = 1 - math.clamp((p28.Position.Y - u25.AbsolutePosition.Y - 8) / (u25.AbsoluteSize.Y - 16), 0, 1);
        u27(math_clamp_ret, true);
        local Color3_fromHSV_ret = Color3.fromHSV(u12, math_clamp_ret, v29);
        table_clone_ret.Value(Color3_fromHSV_ret, true);
    end;

    local function inputBegan(u30) -- Line: 158
        -- upvalues: Parent (ref), u26 (ref), u11 (copy), update (copy)
        if u30.UserInputType == Enum.UserInputType.MouseButton1 or u30.UserInputType == Enum.UserInputType.Touch then
            Parent.Sound.Hover03:Play();
            u26 = u30;
            u11(true);
            local u31 = nil;
            u31 = u30:GetPropertyChangedSignal("UserInputState"):Connect(function() -- Line: 167
                -- upvalues: u30 (copy), u31 (ref), u26 (ref), Parent (ref), u11 (ref)
                if u30.UserInputState == Enum.UserInputState.End then
                    u31:Disconnect();

                    if u26 == u30 then
                        Parent.Sound.Hover01:Play();
                        u26 = nil;
                        u11(false);
                    end;
                end;
            end);
            update(u30);
        end;
    end;

    table.insert(v10, Parent.UserInputService.InputChanged:Connect(update));
    u25 = Parent.new("Frame")({
        Name = "SaturationValue",
        BackgroundColor3 = v21,
        Size = u6,
        SizeConstraint = Enum.SizeConstraint.RelativeYY,
        Parent.new("UICorner")({
            CornerRadius = Parent.Theme.CornerPadded
        }),
        Parent.new("Stroke")({}),
        Parent.new("Frame")({
            Name = "Saturation",
            BackgroundColor3 = Color3.new(1, 1, 1),
            Size = UDim2.new(1, 0, 1, 0),
            Parent.new("UICorner")({
                CornerRadius = Parent.Theme.CornerPadded2
            }),
            Parent.new("UIGradient")({
                Color = ColorSequence.new(Color3.new(1, 1, 1)),
                Transparency = NumberSequence.new(0, 1)
            })
        }),
        Parent.new("Frame")({
            Name = "Value",
            BackgroundColor3 = Color3.new(0, 0, 0),
            Size = UDim2.new(1, 0, 1, 0),
            ZIndex = 2,
            Parent.new("UICorner")({
                CornerRadius = Parent.Theme.CornerPadded2
            }),
            Parent.new("UIGradient")({
                Rotation = -90,
                Color = ColorSequence.new(Color3.new()),
                Transparency = NumberSequence.new(0, 1)
            })
        }),
        Parent.new("Frame")({
            Name = "PickerContainer",
            BackgroundTransparency = 1,
            Size = UDim2.new(1, 0, 1, 0),
            ZIndex = 3,
            Parent.new("UIPadding")({
                PaddingLeft = UDim.new(0, 8),
                PaddingRight = UDim.new(0, 8),
                PaddingTop = UDim.new(0, 8),
                PaddingBottom = UDim.new(0, 8)
            }),
            Parent.new("Frame")({
                Name = "Picker",
                AnchorPoint = Vector2.new(0.5, 0.5),
                BackgroundColor3 = table_clone_ret.Value,
                Size = Parent.tween(function() -- Line: 237
                    -- upvalues: u11 (copy)
                    if u11() then
                        return UDim2.new(0, 16, 0, 16);
                    end;

                    return UDim2.new(0, 8, 0, 8);
                end, Parent.Theme.TweenOut),

                Position = function() -- Line: 240, Name: Position
                    -- upvalues: table_clone_ret (copy), u27 (copy)
                    local _, v32, v33 = table_clone_ret.Value():ToHSV();
                    local v34 = u27();

                    if v33 ~= 0 then
                        v34 = v32;
                    end;

                    return UDim2.new(v34, 0, 1 - v33, 0);
                end,

                Parent.new("UICorner")({
                    CornerRadius = Parent.Theme.CornerDiameter
                }),
                Parent.new("UIStroke")({
                    Thickness = 1.5,
                    ApplyStrokeMode = Enum.ApplyStrokeMode.Border,
                    Color = Color3.new(1, 1, 1)
                }),
                InputBegan = inputBegan
            })
        }),
        InputBegan = inputBegan
    });
    table_clone_ret.sv = u25;
    table_clone_ret._menu = Parent.new("Menu")({
        Name = "ColorPicker",
        Adornee = table_clone_ret.Adornee,
        RightAlign = table_clone_ret.RightAlign,
        AutomaticSize = Enum.AutomaticSize.XY,
        Size = UDim2.new(),
        Visible = table_clone_ret.Visible,
        Parent.new("UIPadding")({
            PaddingLeft = Parent.Theme.Padding,
            PaddingRight = Parent.Theme.Padding,
            PaddingTop = Parent.Theme.Padding,
            PaddingBottom = Parent.Theme.Padding
        }),
        u20,
        Parent.new("Frame")({
            BackgroundTransparency = 1,
            AutomaticSize = Enum.AutomaticSize.XY,
            Parent.new("UIListLayout")({
                SortOrder = Enum.SortOrder.LayoutOrder,
                FillDirection = Enum.FillDirection.Vertical,
                Padding = Parent.Theme.Padding
            }),
            u25,
            v24
        }),
        [Parent.Clean] = v10
    });
    table_clone_ret._menu._list.FillDirection = Enum.FillDirection.Horizontal;
    table_clone_ret._menu._content.AutomaticSize = Enum.AutomaticSize.XY;
    Parent.edit(table_clone_ret._menu._list, {
        Padding = Parent.Theme.Padding
    });
    table_clone_ret._instance = table_clone_ret._menu._instance;

    return setmetatable(table_clone_ret, u8);
end;

return u8;