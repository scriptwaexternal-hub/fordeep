-- Decompiled with Potassium's decompiler.

local MarketplaceService = game:GetService("MarketplaceService");
local RunService = game:GetService("RunService");
local Util = require(script.Parent.Parent.Util);
local LocalPlayer = game.Players.LocalPlayer;

if RunService:IsServer() then
    return false;
end;

local Frame = Instance.new("Frame");
Frame.Name = "VIP";
Frame.AnchorPoint = Vector2.new(0.5, 0.5);
Frame.BackgroundTransparency = 1;
Frame.Position = UDim2.fromScale(0.5, 0.5);
Frame.Size = UDim2.fromOffset(420, 420);
Frame.Visible = false;
Frame.ZIndex = 900000000;
local ImageLabel = Instance.new("ImageLabel");
ImageLabel.Name = "ImageLabel";
ImageLabel.BackgroundColor3 = Color3.fromRGB(18, 18, 21);
ImageLabel.BackgroundTransparency = 0;
ImageLabel.Image = "rbxassetid://104331312960285";
ImageLabel.Size = UDim2.fromScale(1, 1);
local UICorner = Instance.new("UICorner");
UICorner.Name = "UICorner";
UICorner.CornerRadius = UDim.new(0, 12);
UICorner.Parent = ImageLabel;
ImageLabel.Parent = Frame;
local Frame2 = Instance.new("Frame");
Frame2.Name = "Frame";
Frame2.BackgroundTransparency = 1;
Frame2.Size = UDim2.fromScale(1, 1);
local UIListLayout = Instance.new("UIListLayout");
UIListLayout.Name = "UIListLayout";
UIListLayout.HorizontalAlignment = Enum.HorizontalAlignment.Center;
UIListLayout.Padding = UDim.new(0, 24);
UIListLayout.SortOrder = Enum.SortOrder.LayoutOrder;
UIListLayout.Parent = Frame2;
local Frame3 = Instance.new("Frame");
Frame3.Name = "Unlock";
Frame3.AutomaticSize = Enum.AutomaticSize.XY;
Frame3.BackgroundTransparency = 1;
Frame3.LayoutOrder = 1;
local TextLabel = Instance.new("TextLabel");
TextLabel.Name = "Label";
TextLabel.AnchorPoint = Vector2.new(0.5, 0);
TextLabel.AutomaticSize = Enum.AutomaticSize.XY;
TextLabel.BackgroundTransparency = 1;
TextLabel.FontFace = Font.new("rbxassetid://12187365364", Enum.FontWeight.SemiBold, Enum.FontStyle.Normal);
TextLabel.LayoutOrder = 1;
TextLabel.Position = UDim2.new(0.5, 8, 0, 64);
TextLabel.RichText = true;
TextLabel.Size = UDim2.new(0.5, 0, 0, 48);
TextLabel.Text = "Unlock exclusive commands <i>forever</i>";
TextLabel.TextColor3 = Color3.new(1, 1, 1);
TextLabel.TextSize = 24;
TextLabel.TextWrapped = true;
TextLabel.TextXAlignment = Enum.TextXAlignment.Left;
TextLabel.Parent = Frame3;
local TextLabel2 = Instance.new("TextLabel");
TextLabel2.Name = "Emoji";
TextLabel2.AnchorPoint = Vector2.new(1, 0);
TextLabel2.AutomaticSize = Enum.AutomaticSize.XY;
TextLabel2.BackgroundTransparency = 1;
TextLabel2.FontFace = Font.new("rbxassetid://12187365364", Enum.FontWeight.Bold, Enum.FontStyle.Normal);
TextLabel2.Position = UDim2.new(0.25, 0, 0, 64);
TextLabel2.Text = "✨";
TextLabel2.TextColor3 = Color3.new(1, 1, 1);
TextLabel2.TextSize = 48;
TextLabel2.TextWrapped = true;
TextLabel2.Parent = Frame3;
local UIListLayout2 = Instance.new("UIListLayout");
UIListLayout2.Name = "UIListLayout";
UIListLayout2.FillDirection = Enum.FillDirection.Horizontal;
UIListLayout2.Padding = UDim.new(0, 8);
UIListLayout2.SortOrder = Enum.SortOrder.LayoutOrder;
UIListLayout2.Parent = Frame3;
Frame3.Parent = Frame2;
local Frame4 = Instance.new("Frame");
Frame4.Name = "Games";
Frame4.AutomaticSize = Enum.AutomaticSize.XY;
Frame4.BackgroundTransparency = 1;
Frame4.LayoutOrder = 2;
local TextLabel3 = Instance.new("TextLabel");
TextLabel3.Name = "Label";
TextLabel3.AnchorPoint = Vector2.new(0.5, 0);
TextLabel3.AutomaticSize = Enum.AutomaticSize.XY;
TextLabel3.BackgroundTransparency = 1;
TextLabel3.FontFace = Font.new("rbxassetid://12187365364", Enum.FontWeight.SemiBold, Enum.FontStyle.Normal);
TextLabel3.LayoutOrder = 1;
TextLabel3.Position = UDim2.new(0.5, 8, 0, 64);
TextLabel3.RichText = true;
TextLabel3.Size = UDim2.new(0.5, 0, 0, 48);
TextLabel3.Text = "Use in over <b>10,000</b>\nRoblox experiences";
TextLabel3.TextColor3 = Color3.new(1, 1, 1);
TextLabel3.TextSize = 24;
TextLabel3.TextWrapped = true;
TextLabel3.TextXAlignment = Enum.TextXAlignment.Left;
TextLabel3.Parent = Frame4;
local UIListLayout3 = Instance.new("UIListLayout");
UIListLayout3.Name = "UIListLayout";
UIListLayout3.FillDirection = Enum.FillDirection.Horizontal;
UIListLayout3.Padding = UDim.new(0, 8);
UIListLayout3.SortOrder = Enum.SortOrder.LayoutOrder;
UIListLayout3.Parent = Frame4;
local ImageLabel2 = Instance.new("ImageLabel");
ImageLabel2.Name = "ImageLabel";
ImageLabel2.BackgroundTransparency = 1;
ImageLabel2.Image = "rbxasset://textures/loading/robloxTilt.png";
ImageLabel2.Size = UDim2.fromOffset(48, 48);
ImageLabel2.Parent = Frame4;
Frame4.Parent = Frame2;
local Frame5 = Instance.new("Frame");
Frame5.Name = "Panel";
Frame5.AutomaticSize = Enum.AutomaticSize.XY;
Frame5.BackgroundTransparency = 1;
Frame5.LayoutOrder = 5;
local TextLabel4 = Instance.new("TextLabel");
TextLabel4.Name = "Label";
TextLabel4.AnchorPoint = Vector2.new(0.5, 0);
TextLabel4.AutomaticSize = Enum.AutomaticSize.XY;
TextLabel4.BackgroundTransparency = 1;
TextLabel4.FontFace = Font.new("rbxassetid://12187365364", Enum.FontWeight.Bold, Enum.FontStyle.Normal);
TextLabel4.LayoutOrder = 1;
TextLabel4.Position = UDim2.new(0.5, 8, 0, 64);
TextLabel4.RichText = true;
TextLabel4.Size = UDim2.new(0.5, 0, 0, 32);
TextLabel4.Text = "30% goes to supporting free and open-source projects";
TextLabel4.TextColor3 = Color3.fromRGB(184, 184, 184);
TextLabel4.TextSize = 16;
TextLabel4.TextWrapped = true;
TextLabel4.TextXAlignment = Enum.TextXAlignment.Left;
TextLabel4.Parent = Frame5;
local TextLabel5 = Instance.new("TextLabel");
TextLabel5.Name = "Emoji";
TextLabel5.AnchorPoint = Vector2.new(1, 0);
TextLabel5.AutomaticSize = Enum.AutomaticSize.XY;
TextLabel5.BackgroundTransparency = 1;
TextLabel5.FontFace = Font.new("rbxassetid://12187365364", Enum.FontWeight.Bold, Enum.FontStyle.Normal);
TextLabel5.Position = UDim2.new(0.25, 0, 0, 64);
TextLabel5.Text = "🌎";
TextLabel5.TextColor3 = Color3.new(1, 1, 1);
TextLabel5.TextSize = 24;
TextLabel5.TextWrapped = true;
TextLabel5.Parent = Frame5;
local UIListLayout4 = Instance.new("UIListLayout");
UIListLayout4.Name = "UIListLayout";
UIListLayout4.FillDirection = Enum.FillDirection.Horizontal;
UIListLayout4.Padding = UDim.new(0, 8);
UIListLayout4.SortOrder = Enum.SortOrder.LayoutOrder;
UIListLayout4.VerticalAlignment = Enum.VerticalAlignment.Center;
UIListLayout4.Parent = Frame5;
Frame5.Parent = Frame2;
local Frame6 = Instance.new("Frame");
Frame6.Name = "Creator";
Frame6.AutomaticSize = Enum.AutomaticSize.XY;
Frame6.BackgroundTransparency = 1;
Frame6.LayoutOrder = 4;
local TextLabel6 = Instance.new("TextLabel");
TextLabel6.Name = "Label";
TextLabel6.AnchorPoint = Vector2.new(0.5, 0);
TextLabel6.AutomaticSize = Enum.AutomaticSize.XY;
TextLabel6.BackgroundTransparency = 1;
TextLabel6.FontFace = Font.new("rbxassetid://12187365364", Enum.FontWeight.Bold, Enum.FontStyle.Normal);
TextLabel6.LayoutOrder = 1;
TextLabel6.Position = UDim2.new(0.5, 8, 0, 64);
TextLabel6.RichText = true;
TextLabel6.Size = UDim2.new(0.5, 0, 0, 32);
TextLabel6.Text = "40% of your purchase goes to the creator of this experience";
TextLabel6.TextColor3 = Color3.fromRGB(184, 184, 184);
TextLabel6.TextSize = 16;
TextLabel6.TextWrapped = true;
TextLabel6.TextXAlignment = Enum.TextXAlignment.Left;
TextLabel6.Parent = Frame6;
local TextLabel7 = Instance.new("TextLabel");
TextLabel7.Name = "Emoji";
TextLabel7.AnchorPoint = Vector2.new(1, 0);
TextLabel7.AutomaticSize = Enum.AutomaticSize.XY;
TextLabel7.BackgroundTransparency = 1;
TextLabel7.FontFace = Font.new("rbxassetid://12187365364", Enum.FontWeight.Bold, Enum.FontStyle.Normal);
TextLabel7.Position = UDim2.new(0.25, 0, 0, 64);
TextLabel7.Text = "❤️";
TextLabel7.TextColor3 = Color3.new(1, 1, 1);
TextLabel7.TextSize = 24;
TextLabel7.TextWrapped = true;
TextLabel7.Parent = Frame6;
local UIListLayout5 = Instance.new("UIListLayout");
UIListLayout5.Name = "UIListLayout";
UIListLayout5.FillDirection = Enum.FillDirection.Horizontal;
UIListLayout5.Padding = UDim.new(0, 8);
UIListLayout5.SortOrder = Enum.SortOrder.LayoutOrder;
UIListLayout5.VerticalAlignment = Enum.VerticalAlignment.Center;
UIListLayout5.Parent = Frame6;
Frame6.Parent = Frame2;
local Frame7 = Instance.new("Frame");
Frame7.Name = "Title";
Frame7.BackgroundTransparency = 1;
Frame7.Size = UDim2.new(1, 0, 0, 40);
local TextLabel8 = Instance.new("TextLabel");
TextLabel8.Name = "Header";
TextLabel8.BackgroundTransparency = 1;
TextLabel8.FontFace = Font.new("rbxasset://fonts/families/RobotoMono.json", Enum.FontWeight.Bold, Enum.FontStyle.Normal);
TextLabel8.Size = UDim2.fromScale(1, 1);
TextLabel8.Text = "";
TextLabel8.TextColor3 = Color3.new(1, 1, 1);
TextLabel8.TextSize = 24;
TextLabel8.TextTransparency = 0.25;
TextLabel8.TextWrapped = true;
TextLabel8.RichText = true;
TextLabel8.Visible = true;
TextLabel8.Parent = Frame7;
local Frame8 = Instance.new("Frame");
Frame8.Name = "BG";
Frame8.BackgroundColor3 = Color3.fromRGB(255, 0, 0);
Frame8.BackgroundTransparency = 0.5;
Frame8.Size = UDim2.fromScale(1, 2);
Frame8.ZIndex = 0;
local UICorner2 = Instance.new("UICorner");
UICorner2.Name = "UICorner";
UICorner2.CornerRadius = UDim.new(0, 12);
UICorner2.Parent = Frame8;
local UIGradient = Instance.new("UIGradient");
UIGradient.Name = "UIGradient";
UIGradient.Rotation = 90;
UIGradient.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(1, 1) });
UIGradient.Parent = Frame8;
Frame8.Parent = Frame7;
Frame7.Parent = Frame2;
local Frame9 = Instance.new("Frame");
Frame9.Name = "BuyFrame";
Frame9.BackgroundTransparency = 1;
Frame9.LayoutOrder = 3;
Frame9.Size = UDim2.new(1, 0, 0, 64);
local TextButton = Instance.new("TextButton", Frame9);
TextButton.Name = "Favorite";
TextButton.BackgroundTransparency = 1;
TextButton.FontFace = Font.new("rbxasset://fonts/families/SourceSansPro.json");
TextButton.Size = UDim2.fromOffset(84, 48);
TextButton.Text = "⭐";
TextButton.TextColor3 = Color3.new();
TextButton.TextSize = 48;
TextButton.TextXAlignment = Enum.TextXAlignment.Right;
local TextButton2 = Instance.new("TextButton");
TextButton2.Name = "Buy";
TextButton2.BackgroundColor3 = Color3.fromRGB(51, 95, 255);
TextButton2.FontFace = Font.new("rbxasset://fonts/families/SourceSansPro.json");
TextButton2.LayoutOrder = 3;
TextButton2.Size = UDim2.fromOffset(114, 64);
TextButton2.Text = "399";
TextButton2.TextColor3 = Color3.new(1, 1, 1);
TextButton2.TextSize = 12;
TextButton2.TextTransparency = 1;
local UICorner3 = Instance.new("UICorner");
UICorner3.Name = "UICorner";
UICorner3.CornerRadius = UDim.new(0, 12);
UICorner3.Parent = TextButton2;
local ImageLabel3 = Instance.new("ImageLabel");
ImageLabel3.Name = "RobuxIcon";
ImageLabel3.BackgroundTransparency = 1;
ImageLabel3.Image = "rbxasset://textures/ui/common/robux@2x.png";
ImageLabel3.Size = UDim2.fromScale(1, 1);
ImageLabel3.SizeConstraint = Enum.SizeConstraint.RelativeYY;
ImageLabel3.ZIndex = 2;
ImageLabel3.Parent = TextButton2;
local UIPadding = Instance.new("UIPadding");
UIPadding.Name = "UIPadding";
UIPadding.PaddingBottom = UDim.new(0, 16);
UIPadding.PaddingLeft = UDim.new(0, 16);
UIPadding.PaddingRight = UDim.new(0, 16);
UIPadding.PaddingTop = UDim.new(0, 16);
UIPadding.Parent = TextButton2;
local TextLabel9 = Instance.new("TextLabel");
TextLabel9.Name = "Price";
TextLabel9.BackgroundTransparency = 1;
TextLabel9.FontFace = Font.new("rbxassetid://12187365364", Enum.FontWeight.Bold, Enum.FontStyle.Normal);
TextLabel9.Position = UDim2.fromOffset(40, 0);
TextLabel9.Size = UDim2.fromOffset(42, 32);
TextLabel9.Text = "399";
TextLabel9.TextColor3 = Color3.new(1, 1, 1);
TextLabel9.TextSize = 24;
TextLabel9.Parent = TextButton2;
TextButton2.Parent = Frame9;
local Frame10 = Instance.new("Frame");
Frame10.Name = "OriginalPrice";
Frame10.BackgroundTransparency = 1;
Frame10.Size = UDim2.fromOffset(84, 32);
Frame10.Visible = false;
local TextLabel10 = Instance.new("TextLabel");
TextLabel10.Name = "Label";
TextLabel10.BackgroundTransparency = 1;
TextLabel10.FontFace = Font.new("rbxassetid://12187365364", Enum.FontWeight.Medium, Enum.FontStyle.Normal);
TextLabel10.Position = UDim2.fromOffset(40, 0);
TextLabel10.Size = UDim2.fromOffset(42, 32);
TextLabel10.Text = "499";
TextLabel10.TextColor3 = Color3.fromRGB(184, 184, 184);
TextLabel10.TextSize = 24;
local Frame11 = Instance.new("Frame");
Frame11.Name = "Line";
Frame11.AnchorPoint = Vector2.new(0.5, 0.5);
Frame11.BackgroundColor3 = Color3.fromRGB(184, 184, 184);
Frame11.BorderColor3 = Color3.new();
Frame11.BorderSizePixel = 0;
Frame11.Position = UDim2.fromScale(0.5, 0.5);
Frame11.Size = UDim2.fromOffset(48, 2);
Frame11.ZIndex = 2;
Frame11.Parent = TextLabel10;
TextLabel10.Parent = Frame10;
local ImageLabel4 = Instance.new("ImageLabel");
ImageLabel4.Name = "RobuxIcon";
ImageLabel4.BackgroundTransparency = 1;
ImageLabel4.Image = "rbxasset://textures/ui/common/robux@2x.png";
ImageLabel4.ImageColor3 = Color3.fromRGB(184, 184, 184);
ImageLabel4.Size = UDim2.fromScale(1, 1);
ImageLabel4.SizeConstraint = Enum.SizeConstraint.RelativeYY;
ImageLabel4.ZIndex = 2;
ImageLabel4.Parent = Frame10;
Frame10.Parent = Frame9;
local UIListLayout6 = Instance.new("UIListLayout");
UIListLayout6.Name = "UIListLayout";
UIListLayout6.FillDirection = Enum.FillDirection.Horizontal;
UIListLayout6.HorizontalAlignment = Enum.HorizontalAlignment.Center;
UIListLayout6.Padding = UDim.new(0, 16);
UIListLayout6.SortOrder = Enum.SortOrder.LayoutOrder;
UIListLayout6.VerticalAlignment = Enum.VerticalAlignment.Center;
UIListLayout6.Parent = Frame9;
local TextButton3 = Instance.new("TextButton");
TextButton3.Name = "View";
TextButton3.AnchorPoint = Vector2.new(0, 0.5);
TextButton3.AutomaticSize = Enum.AutomaticSize.X;
TextButton3.BackgroundColor3 = Color3.fromRGB(64, 64, 64);
TextButton3.FontFace = Font.new("rbxassetid://12187365364", Enum.FontWeight.Bold, Enum.FontStyle.Normal);
TextButton3.LayoutOrder = 3;
TextButton3.Position = UDim2.new(1, 32, 0.5, 0);
TextButton3.Size = UDim2.fromOffset(0, 48);
TextButton3.Text = "View";
TextButton3.TextColor3 = Color3.new(1, 1, 1);
TextButton3.TextSize = 24;
local UICorner4 = Instance.new("UICorner");
UICorner4.Name = "UICorner";
UICorner4.CornerRadius = UDim.new(0, 12);
UICorner4.Parent = TextButton3;
local UIPadding2 = Instance.new("UIPadding");
UIPadding2.Name = "UIPadding";
UIPadding2.PaddingBottom = UDim.new(0, 16);
UIPadding2.PaddingLeft = UDim.new(0, 16);
UIPadding2.PaddingRight = UDim.new(0, 16);
UIPadding2.PaddingTop = UDim.new(0, 16);
UIPadding2.Parent = TextButton3;
TextButton3.Parent = Frame9;
Frame9.Parent = Frame2;
Frame2.Parent = Frame;
local ImageButton = Instance.new("ImageButton");
ImageButton.Name = "Close";
ImageButton.AnchorPoint = Vector2.new(1, 0);
ImageButton.BackgroundTransparency = 1;
ImageButton.Image = "rbxasset://textures/ui/ScreenshotHud/Close.png";
ImageButton.Position = UDim2.new(1, -4, 0, 4);
ImageButton.Size = UDim2.fromOffset(32, 32);
ImageButton.Parent = Frame;
local u1 = "110019084552349";

local function promptBulkPurchase(p2) -- Line: 425
    -- upvalues: Util (copy)
    Util.Remote.PromptBulkPurchase:Fire((tonumber(p2)));
end;

local function promptPurchaseVIP() -- Line: 429
    -- upvalues: u1 (ref), Util (copy)
    Util.Remote.PromptBulkPurchase:Fire((tonumber(u1)));
end;

task.spawn(function() -- Line: 433
    -- upvalues: promptBulkPurchase (copy), promptPurchaseVIP (copy), TextButton (copy)
    while not shared._K_INTERFACE do
        task.wait();
    end;

    shared._K_INTERFACE.PromptBulkPurchase = promptBulkPurchase;
    shared._K_INTERFACE.PromptPurchaseVIP = promptPurchaseVIP;
    shared._K_INTERFACE.UI.new("Tooltip")({
        Text = "Add to Favorites",
        Parent = TextButton
    });
end);

local function updateLabelPrice(p3: userdata, p4: number) -- Line: 446
    -- upvalues: MarketplaceService (copy)
    local success, result = pcall(MarketplaceService.GetProductInfoAsync, MarketplaceService, p4, Enum.InfoType.Asset);

    if success then
        p3.Text = result.PriceInRobux;
    end;
end;

local function setSalePrice(p5: boolean?) -- Line: 453
    -- upvalues: u1 (ref), TextButton (copy), Frame10 (copy), TextLabel8 (copy), TextButton2 (copy), updateLabelPrice (copy)
    u1 = p5 and "115444443724463" or "110019084552349";
    TextButton.Visible = not p5;
    Frame10.Visible = p5;
    TextLabel8.Visible = true;
    TextButton2.Price.Text = p5 and "479" or "799";
    task.spawn(updateLabelPrice, TextButton2.Price, u1);
end;

task.spawn(updateLabelPrice, TextLabel10, u1);
task.spawn(function() -- Line: 463
    -- upvalues: LocalPlayer (copy), u1 (ref), TextButton (copy), Frame10 (copy), TextLabel8 (copy), TextButton2 (copy), updateLabelPrice (copy)
    local Attribute = LocalPlayer:GetAttribute("_KInitialJoin");

    while not Attribute do
        task.wait();
        Attribute = LocalPlayer:GetAttribute("_KInitialJoin");
    end;

    local v6 = workspace:GetServerTimeNow() - Attribute;

    if v6 < 600 then
        u1 = "110019084552349";
        TextButton.Visible = true;
        Frame10.Visible = false;
        TextLabel8.Visible = true;
        TextButton2.Price.Text = "799";
        task.spawn(updateLabelPrice, TextButton2.Price, u1);

        while v6 < 600 do
            task.wait(0.5);
            v6 = workspace:GetServerTimeNow() - Attribute;
            local v7 = 600 - v6;
            TextLabel8.Text = `<font color="#0f0" transparency="0">40% OFF</font> in {string.format("%02d:%02d", v7 // 60, v7 % 60)}`;
        end;

        TextLabel8.Text = "<font color=\"#0f0\" transparency=\"0\">40% OFF</font>";
    end;

    u1 = "115444443724463";
    TextButton.Visible = false;
    Frame10.Visible = true;
    TextLabel8.Visible = true;
    TextButton2.Price.Text = "479";
    task.spawn(updateLabelPrice, TextButton2.Price, u1);
end);
TextButton2.Activated:Connect(promptPurchaseVIP);
TextButton.Activated:Connect(function() -- Line: 493
    -- upvalues: u1 (ref)
    pcall(function() -- Line: 494
        -- upvalues: u1 (ref)
        shared._K_INTERFACE.Service.AvatarEditor:PromptSetFavorite(u1, 1, true);
    end);
end);
TextButton3.Activated:Connect(function() -- Line: 498
    -- upvalues: Frame (copy)
    shared._K_INTERFACE.client.commandsWindowVisible(true);
    shared._K_INTERFACE.client.dashboard.Commands._input._input.Text = "role=vip";
    Frame.ZIndex = shared._K_INTERFACE.Registry.commands.cmds.env.window._instance.ZIndex - 1;
end);
ImageButton.Activated:Connect(function() -- Line: 504
    -- upvalues: Frame (copy)
    Frame.Visible = false;
end);
MarketplaceService.PromptBulkPurchaseFinished:Connect(function(p8, p9, p10) -- Line: 508
    -- upvalues: LocalPlayer (copy), u1 (ref), Frame (copy)
    if p8 ~= LocalPlayer or p10.Items[1].id ~= u1 and p10.Items[1].id ~= "115444443724463" then
        return;
    end;

    shared._K_INTERFACE.Remote.VIPCheck:Fire((tonumber(p10.Items[1].id)));

    if p9 == Enum.MarketplaceBulkPurchasePromptStatus.Completed then
        function shared._K_INTERFACE.client.VIPNotification() -- Line: 514
        end;

        Frame.Visible = false;
        task.wait(4);
        pcall(function() -- Line: 517
            game:GetService("AvatarEditorService"):PromptSetFavorite(17873329124, 1, true);
        end);
    end;
end);
local UIScale = Instance.new("UIScale", Frame);
Frame:GetPropertyChangedSignal("Parent"):Once(function() -- Line: 525
    -- upvalues: Frame (copy), UIScale (copy)
    local Parent = Frame.Parent;

    local function updateScale() -- Line: 527
        -- upvalues: UIScale (ref), Parent (copy)
        UIScale.Scale = math.min(1, Parent.AbsoluteSize.Y / 420);
    end;

    UIScale.Scale = math.min(1, Parent.AbsoluteSize.Y / 420);
    Parent:GetPropertyChangedSignal("AbsoluteSize"):Connect(updateScale);
end);

return Frame;