-- Decompiled with Potassium's decompiler.

local Debris = game:GetService("Debris");
local ReplicatedStorage = game:GetService("ReplicatedStorage");
local Modules = ReplicatedStorage:WaitForChild("Modules");
local SoundManager = require(Modules.Shared.SoundManager);
local GlobalFunctions = require(Modules.GlobalFunctions);
local Visuals = workspace.World.Visuals;
local Meshes = ReplicatedStorage.Assets.Effects.Meshes;
local Particles = ReplicatedStorage.Assets.Effects.Particles;
Color3.fromRGB(255, 255, 155);
local v1 = {};

local function clearStaged(p2) -- Line: 35
    -- upvalues: Visuals (copy)
    local v3 = "Kienzan:" .. p2.Name .. ":";

    for _, child in ipairs(Visuals:GetChildren()) do
        if child:GetAttribute("Staged") and child.Name:sub(1, #v3) == v3 then
            child:Destroy();
        end;
    end;
end;

function v1.Create(p4) -- Line: 44
    -- upvalues: Meshes (copy), clearStaged (copy), Visuals (copy), Debris (copy)
    local Character = p4.Character;

    if not Character then
        return;
    end;

    local v5 = Character:FindFirstChild("Right Arm") or Character:FindFirstChild("HumanoidRootPart");

    if not v5 then
        return;
    end;

    local v6 = Meshes.Skills.Blasts.Kienzan:FindFirstChild("Kienzan FX");

    if not v6 then
        return;
    end;

    clearStaged(Character);
    local u7 = v6:Clone();
    u7.Name = "Kienzan:" .. (p4.CastKey or Character.Name);
    u7:SetAttribute("Staged", true);
    local v8 = p4.Size and (p4.Size.X or 11.87) or 11.87;
    local v9 = v8 / 11.87;

    if math.abs(v9 - 1) > 0.05 then
        for _, descendant in ipairs(u7:GetDescendants()) do
            if descendant:IsA("ParticleEmitter") then
                local v10 = {};

                for _, v in ipairs(descendant.Size.Keypoints) do
                    table.insert(v10, NumberSequenceKeypoint.new(v.Time, v.Value * v9, v.Envelope * v9));
                end;

                descendant.Size = NumberSequence.new(v10);
            elseif descendant:IsA("Attachment") and (descendant.Name == "0" or descendant.Name == "1") then
                descendant.Position = descendant.Position * v9;
            end;
        end;

        u7.Size = Vector3.new(v8, v6.Size.Y, v8);
    end;

    u7.CFrame = CFrame.new((v5.CFrame * CFrame.new(0, -2, 0)).Position);
    u7.Parent = Visuals;
    Debris:AddItem(u7, (p4.Attack_Use_Time or 1) + 1.5);
    local v11 = p4.Attack_Use_Time or 1;
    local u12 = nil;
    u12 = Character.ChildAdded:Connect(function(p13) -- Line: 94
        -- upvalues: u12 (ref), u7 (copy)
        if p13.Name == "Stun" then
            u12:Disconnect();

            if u7.Parent then
                u7:Destroy();
            end;
        end;
    end);

    if not Character:FindFirstChild("Stun") then
        task.delay(v11, function() -- Line: 105
            -- upvalues: u12 (ref)
            if u12.Connected then
                u12:Disconnect();
            end;
        end);

        return;
    end;

    u12:Disconnect();
    u7:Destroy();
end;

function v1.Cancel(p14) -- Line: 110
    -- upvalues: Visuals (copy), clearStaged (copy)
    local Character = p14.Character;

    if not Character then
        return;
    end;

    if p14.CastKey then
        local v15 = Visuals:FindFirstChild("Kienzan:" .. p14.CastKey);

        if v15 and v15:GetAttribute("Staged") then
            v15:Destroy();
        end;
    else
        clearStaged(Character);
    end;
end;

function v1.Hit(p16) -- Line: 121
    -- upvalues: GlobalFunctions (copy), Particles (copy), Debris (copy), SoundManager (copy)
    local Victim = p16.Victim;

    if not Victim then
        return;
    end;

    local RootAndHumanoid = GlobalFunctions.GetRootAndHumanoid(Victim);

    if not RootAndHumanoid then
        return;
    end;

    local v17 = Particles.Sparks:Clone();
    v17.Parent = RootAndHumanoid;
    v17:Emit(50);
    Debris:AddItem(v17, 2);
    SoundManager.AddSound("Kienzan Hit", {
        Parent = RootAndHumanoid
    }, "Client");
end;

return v1;