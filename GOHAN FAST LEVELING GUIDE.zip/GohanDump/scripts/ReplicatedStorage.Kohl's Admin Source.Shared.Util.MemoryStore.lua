-- Decompiled with Potassium's decompiler.

return {
    getItemsFromHashMap = function(p1: userdata) -- Line: 3, Name: getItemsFromHashMap
        local v2 = p1:ListItemsAsync(200);
        local v3 = {};

        while true do
            for _, v in v2:GetCurrentPage() do
                v3[v.key] = v.value;
            end;

            if v2.IsFinished then
                return v3;
            end;

            v2:AdvanceToNextPageAsync();
        end;
    end
};