-- Decompiled with Potassium's decompiler.

return {
    debounce = function(u1: number, u2: function) -- Line: 3, Name: debounce
        local u3 = nil;

        return function(...) -- Line: 5
            -- upvalues: u3 (ref), u1 (copy), u2 (copy)
            if typeof(u3) == "thread" and coroutine.status(u3) == "suspended" then
                task.cancel(u3);
            end;

            u3 = task.delay(u1, u2, ...);
        end;
    end,

    throttle = function(u4: number, u5: function) -- Line: 13, Name: throttle
        local u6 = nil;
        local u7 = nil;

        local function trailing(...) -- Line: 15
            -- upvalues: u7 (ref), u4 (copy), u5 (copy)
            u7 = tick() + u4;
            u5(...);
        end;

        return function(...) -- Line: 20
            -- upvalues: u6 (ref), u7 (ref), trailing (copy), u4 (copy), u5 (copy)
            local v8 = tick();

            if typeof(u6) == "thread" and coroutine.status(u6) == "suspended" then
                task.cancel(u6);
                u6 = nil;
            end;

            if u7 and v8 < u7 then
                u6 = task.delay(u7 - v8, trailing, ...);

                return;
            end;

            u7 = v8 + u4;
            u5(...);
        end;
    end
};