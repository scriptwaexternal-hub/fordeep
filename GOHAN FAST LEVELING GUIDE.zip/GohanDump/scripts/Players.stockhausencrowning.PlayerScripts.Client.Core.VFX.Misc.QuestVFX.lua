-- Decompiled with Potassium's decompiler.

local Players = game:GetService("Players");
game:GetService("Debris");
local ReplicatedStorage = game:GetService("ReplicatedStorage");
local RunService = game:GetService("RunService");
game:GetService("CollectionService");
local Modules = ReplicatedStorage:WaitForChild("Modules");
ReplicatedStorage:WaitForChild("Remotes");
local _ = ReplicatedStorage.Assets;
local _ = Modules.Metadata;
local _ = Modules.Utility;
require(Modules.Shared.SoundManager);
require(Modules.GlobalFunctions);
local StoryGuideArrow = require(script.Parent:WaitForChild("StoryGuideArrow"));
local LocalPlayer = Players.LocalPlayer;
local workspace_World = workspace.World;
local _ = workspace_World.Visuals;
local NPC = workspace_World.NPC;
local UDim2_new_ret = UDim2.new(1, 40, 1, 40);

local function getIndicators() -- Line: 38
    -- upvalues: workspace_World (copy)
    local Map = workspace_World:FindFirstChild("Map");

    if Map then
        Map = Map:FindFirstChild("Indicators");
    end;

    return Map;
end;

local function forEachIndicator(p1, p2) -- Line: 62
    -- upvalues: workspace_World (copy)
    local Map = workspace_World:FindFirstChild("Map");

    if Map then
        Map = Map:FindFirstChild("Indicators");
    end;

    if not Map then
        return false;
    end;

    local v3 = false;

    for _, descendant in ipairs(Map:GetDescendants()) do
        if descendant.Name == p1 then
            local Marker = descendant:FindFirstChild("Marker");

            if Marker and Marker:IsA("BillboardGui") then
                p2(Marker);
                v3 = true;
            end;
        end;
    end;

    return v3;
end;

local Bangers = Enum.Font.Bangers;
local Color3_fromRGB_ret = Color3.fromRGB(255, 196, 68);
local Color3_fromRGB_ret2 = Color3.fromRGB(8, 7, 6);
local u4 = {};

local function ensureDistanceLabel(p5) -- Line: 93
    -- upvalues: Bangers (copy), Color3_fromRGB_ret (copy), Color3_fromRGB_ret2 (copy)
    local Dist = p5:FindFirstChild("Dist");

    if Dist then
        return Dist;
    end;

    local TextLabel = Instance.new("TextLabel");
    TextLabel.Name = "Dist";
    TextLabel.AnchorPoint = Vector2.new(0.5, 0);
    TextLabel.Position = UDim2.new(0.5, 0, 1, 2);
    TextLabel.Size = UDim2.new(3, 0, 0, 24);
    TextLabel.BackgroundTransparency = 1;
    TextLabel.Font = Bangers;
    TextLabel.TextSize = 20;
    TextLabel.TextColor3 = Color3_fromRGB_ret;
    TextLabel.TextStrokeColor3 = Color3_fromRGB_ret2;
    TextLabel.TextStrokeTransparency = 0;
    TextLabel.Text = "";
    TextLabel.ZIndex = 2;
    TextLabel.Parent = p5;

    return TextLabel;
end;

local function markerWorldPosition(p6) -- Line: 113
    local v7 = p6.Adornee or p6.Parent;

    if not v7 then
        return nil;
    end;

    if v7:IsA("BasePart") then
        return v7.Position;
    end;

    if not v7:IsA("Model") then
        return nil;
    end;

    local v8 = v7:FindFirstChild("HumanoidRootPart") or (v7.PrimaryPart or v7:FindFirstChildWhichIsA("BasePart"));

    if v8 then
        v8 = v8.Position;
    end;

    return v8;
end;

local u9 = 0;
RunService.RenderStepped:Connect(function(p10) -- Line: 126
    -- upvalues: u9 (ref), LocalPlayer (copy), u4 (copy), markerWorldPosition (copy)
    u9 = u9 + p10;

    if u9 < 0.2 then
        return;
    end;

    u9 = 0;
    local Character = LocalPlayer.Character;

    if Character then
        Character = Character:FindFirstChild("HumanoidRootPart");
    end;

    if not Character then
        return;
    end;

    for i in pairs(u4) do
        if i.Parent then
            if i.Enabled then
                local v11 = markerWorldPosition(i);
                local Dist = i:FindFirstChild("Dist");

                if v11 and Dist then
                    Dist.Text = ("%d m"):format((v11 - Character.Position).Magnitude);
                end;
            end;
        else
            u4[i] = nil;
        end;
    end;
end);

local function applyMarkerVisibility(p12) -- Line: 147
    -- upvalues: UDim2_new_ret (copy), ensureDistanceLabel (copy), u4 (copy)
    if not p12 then
        return;
    end;

    p12.Size = UDim2_new_ret;
    p12.MaxDistance = (1 / 0);
    p12.Enabled = true;
    ensureDistanceLabel(p12);
    u4[p12] = true;
end;

local Color3_fromRGB_ret3 = Color3.fromRGB(255, 45, 45);

local function storyIconsEnabled() -- Line: 167
    -- upvalues: LocalPlayer (copy)
    local Character = LocalPlayer.Character;

    return not Character or Character:GetAttribute("StoryIcons") ~= false;
end;

local function buildStoryMarker(p13) -- Line: 172
    -- upvalues: Bangers (copy), Color3_fromRGB_ret3 (copy), Color3_fromRGB_ret2 (copy), ensureDistanceLabel (copy), u4 (copy)
    local v14 = p13:FindFirstChild("Head") or (p13:FindFirstChild("HumanoidRootPart") or p13.PrimaryPart);

    if not v14 then
        return nil;
    end;

    local BillboardGui = Instance.new("BillboardGui");
    BillboardGui.Name = "StoryMarker";
    BillboardGui.Adornee = v14;
    BillboardGui.AlwaysOnTop = true;
    BillboardGui.MaxDistance = (1 / 0);
    BillboardGui.LightInfluence = 0;
    BillboardGui.Size = UDim2.fromOffset(60, 80);
    BillboardGui.StudsOffset = Vector3.new(0, 4.5, 0);
    local TextLabel = Instance.new("TextLabel");
    TextLabel.Name = "Mark";
    TextLabel.Size = UDim2.new(1, 0, 1, 0);
    TextLabel.BackgroundTransparency = 1;
    TextLabel.Font = Bangers;
    TextLabel.TextScaled = true;
    TextLabel.Text = "!";
    TextLabel.TextColor3 = Color3_fromRGB_ret3;
    TextLabel.TextStrokeColor3 = Color3_fromRGB_ret2;
    TextLabel.TextStrokeTransparency = 0;
    TextLabel.Parent = BillboardGui;
    task.spawn(function() -- Line: 195
        -- upvalues: BillboardGui (copy)
        local v15 = 0;

        while BillboardGui.Parent do
            v15 = v15 + task.wait();
            local v16 = math.sin(v15 * 3) * 0.25 + 4.5;
            BillboardGui.StudsOffset = Vector3.new(0, v16, 0);
        end;
    end);
    BillboardGui.Parent = p13;
    ensureDistanceLabel(BillboardGui);
    u4[BillboardGui] = true;

    return BillboardGui;
end;

local function applyStorySetting() -- Line: 209
    -- upvalues: u4 (copy)
    for i in pairs(u4) do
        if i.Name == "StoryMarker" and i.Parent then
            i.Enabled = false;
        end;
    end;
end;

local function watchStorySetting(p17) -- Line: 218
    -- upvalues: applyStorySetting (copy)
    if not p17 then
        return;
    end;

    p17:GetAttributeChangedSignal("StoryIcons"):Connect(applyStorySetting);
end;

local v18 = LocalPlayer.Character and LocalPlayer.Character;

if v18 then
    v18:GetAttributeChangedSignal("StoryIcons"):Connect(applyStorySetting);
end;

LocalPlayer.CharacterAdded:Connect(watchStorySetting);
local u19 = nil;

local function attachStoryMarker(p20) -- Line: 234
    -- upvalues: buildStoryMarker (copy)
    if not p20:IsA("Model") then
        return;
    end;

    local v21 = p20:FindFirstChild("StoryMarker") or buildStoryMarker(p20);

    if v21 then
        v21.Enabled = false;
    end;
end;

local function setStoryNpc(p22) -- Line: 243
    -- upvalues: u19 (ref), NPC (copy), buildStoryMarker (copy)
    u19 = p22;

    if not p22 then
        return;
    end;

    for _, descendant in ipairs(NPC:GetDescendants()) do
        if descendant:IsA("Model") and descendant.Name == p22 then
            if descendant:IsA("Model") then
                local v23 = descendant:FindFirstChild("StoryMarker") or buildStoryMarker(descendant);

                if v23 then
                    v23.Enabled = false;
                end;
            end;
        end;
    end;
end;

NPC.DescendantAdded:Connect(function(u24) -- Line: 251
    -- upvalues: u19 (ref), buildStoryMarker (copy)
    if u19 and (u24:IsA("Model") and u24.Name == u19) then
        task.defer(function() -- Line: 254
            -- upvalues: u24 (copy), u19 (ref), buildStoryMarker (ref)
            if u24.Parent and u24.Name == u19 then
                local v25 = u24;

                if not v25:IsA("Model") then
                    return;
                end;

                local v26 = v25:FindFirstChild("StoryMarker") or buildStoryMarker(v25);

                if v26 then
                    v26.Enabled = false;
                end;
            end;
        end);
    end;
end);

return {
    Indicator = function(p27) -- Line: 262
        -- upvalues: setStoryNpc (copy), StoryGuideArrow (copy), forEachIndicator (copy), applyMarkerVisibility (copy), NPC (copy), UDim2_new_ret (copy), ensureDistanceLabel (copy), u4 (copy)
        local IndicatorName = p27.IndicatorName;

        if p27.Story then
            setStoryNpc(IndicatorName);
            StoryGuideArrow.Set(IndicatorName, p27.Position);

            return;
        end;

        local v28 = forEachIndicator(IndicatorName, applyMarkerVisibility);

        if p27.StoryQuest and v28 then
            StoryGuideArrow.SetArea(IndicatorName);
        end;

        if v28 == false then
            for _, descendant in pairs(NPC:GetDescendants()) do
                if descendant:IsA("Model") and (descendant.Name == IndicatorName and not descendant:FindFirstChild("Marker")) then
                    local v29 = script.Marker:Clone();
                    v29.Parent = descendant;

                    if v29 then
                        v29.Size = UDim2_new_ret;
                        v29.MaxDistance = (1 / 0);
                        v29.Enabled = true;
                        ensureDistanceLabel(v29);
                        u4[v29] = true;
                    end;
                end;
            end;
        end;
    end,

    ["Remove Indicator"] = function(p30) -- Line: 297
        -- upvalues: u19 (ref), StoryGuideArrow (copy), forEachIndicator (copy), u4 (copy), NPC (copy)
        local IndicatorName = p30.IndicatorName;

        if u19 == IndicatorName then
            u19 = nil;
        end;

        StoryGuideArrow.Clear(IndicatorName);
        StoryGuideArrow.ClearArea(IndicatorName);
        forEachIndicator(IndicatorName, function(p31) -- Line: 310
            -- upvalues: u4 (ref)
            p31.Enabled = false;
            u4[p31] = nil;
        end);

        for _, descendant in pairs(NPC:GetDescendants()) do
            if descendant:IsA("Model") and descendant.Name == IndicatorName then
                local Marker = descendant:FindFirstChild("Marker");

                if Marker then
                    Marker:Destroy();
                end;

                local StoryMarker = descendant:FindFirstChild("StoryMarker");

                if StoryMarker then
                    u4[StoryMarker] = nil;
                    StoryMarker:Destroy();
                end;
            end;
        end;
    end
};