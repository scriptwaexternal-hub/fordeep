-- Decompiled with Potassium's decompiler.

local Parent = require(script.Parent.Parent);
local BaseClass = require(script.Parent:WaitForChild("BaseClass"));
local u1 = {};
u1.__index = u1;
setmetatable(u1, BaseClass);
local u2 = { { -1, 1, 0, 0, 48 }, { 1, 0, 0, 0, 48 }, { 0, 0, -1, 1, 0 }, { 0, 0, 1, 0, 0 }, { -1, 1, -1, 1, 72 }, { 1, 0, -1, 1, 24 }, { 1, 0, 1, 0, 72 }, { -1, 1, 1, 0, 24 } };

local function getResizeIndex(p3: any, p4: any, p5: any, p6: number) -- Line: 20
    -- upvalues: u2 (copy)
    local v7 = p5 + p4;

    if p3.X < p5.X - p6 or (p3.X > v7.X + p6 or (p3.Y < p5.Y - p6 or p3.Y > v7.Y + p6)) then
        return;
    end;

    local v8 = {
        math.abs(p3.X - p5.X),
        math.abs(p3.X - v7.X),
        math.abs(p3.Y - p5.Y),
        (math.abs(p3.Y - v7.Y))
    };

    if p6 < math.min(unpack(v8)) then
        return;
    end;

    for i, v in {
        p3 - p5,
        p3 - Vector2.new(v7.X, p5.Y),
        p3 - v7,
        p3 - Vector2.new(p5.X, v7.Y)
    } do
        if math.abs(v.X) <= p6 and math.abs(v.Y) <= p6 then
            return u2[i + 4];
        end;
    end;

    for i, v in v8 do
        if v <= p6 then
            return u2[i];
        end;
    end;
end;

local u9 = {};

local function sortZIndex(p10, p11) -- Line: 67
    return p10.ZIndex < p11.ZIndex;
end;

function u1.bringToFront(p12) -- Line: 71
    -- upvalues: u9 (copy), sortZIndex (copy)
    local v13 = {};

    for i in u9 do
        table.insert(v13, i._instance);
    end;

    table.sort(v13, sortZIndex);
    table.insert(v13, p12._instance);

    for i, v in v13 do
        v.ZIndex = i;
    end;
end;

function u1.nudge(p14) -- Line: 83
    -- upvalues: u9 (copy)
    local AbsolutePosition = p14._instance.AbsolutePosition;
    local AbsoluteSize = p14._instance.AbsoluteSize;
    local AbsoluteSize2 = p14._instance.Parent.AbsoluteSize;

    for i = 1, 16 do
        local _ = i;
        local v15 = nil;

        for i2 in u9 do
            if i2._instance.Visible and (i2 ~= p14 and (AbsolutePosition - i2._instance.AbsolutePosition).Magnitude < 16) then
                local v16 = AbsolutePosition.X + 32;
                local math_max_ret = math.max(0, AbsoluteSize2.X - AbsoluteSize.X);
                local math_clamp_ret = math.clamp(v16, 0, math_max_ret);
                local v17 = AbsolutePosition.Y + 32;
                local math_max_ret2 = math.max(0, AbsoluteSize2.Y - AbsoluteSize.Y);
                local math_clamp_ret2 = math.clamp(v17, 0, math_max_ret2);
                AbsolutePosition = AbsolutePosition + Vector2.new(32, 32);
                p14.Position(UDim2.fromOffset(math_clamp_ret, math_clamp_ret2));
                v15 = true;
                break;
            end;
        end;

        if not v15 then
            break;
        end;
    end;
end;

local u18 = {
    Exitable = true,
    Draggable = true,
    Resizable = true,
    RemoveOnClose = false,
    Icon = "",
    Title = "Window",
    Close = Parent.Function,
    IconProperties = {},
    AutomaticSize = Enum.AutomaticSize.None,
    Position = UDim2.new(0.5, -210, 0.5, -210),
    Size = UDim2.new(0, 420, 0, 420),
    SizeBounds = Rect.new(128, 128, 9000000000, 9000000000)
};

function u1.new(p19) -- Line: 129
    -- upvalues: u18 (copy), Parent (copy), u9 (copy), u1 (copy), getResizeIndex (copy)
    local table_clone_ret = table.clone(u18);
    table_clone_ret.IconProperties = {};
    Parent.makeStatefulDefaults(table_clone_ret, p19);
    u9[table_clone_ret] = true;
    local u20 = nil;
    local u21 = nil;
    local u22 = nil;
    local u23 = Parent.state(Vector2.new());
    local u24 = Parent.state(false);
    local u25 = Parent.state(false);
    local u26 = Parent.state(false);
    local u27 = Parent.state(Vector2.new());

    local function dragUpdate(p28) -- Line: 143
        -- upvalues: u20 (ref), u25 (copy), u21 (ref), table_clone_ret (copy), u22 (ref)
        if not u20 or u25._value then
            return;
        end;

        local v29 = p28.Position - u21;
        local v30 = table_clone_ret._instance.Parent.AbsoluteSize - table_clone_ret._instance.AbsoluteSize;
        local Position = table_clone_ret.Position;
        local UDim2_fromOffset = UDim2.fromOffset;
        local math_round_ret = math.round(u22.X + v29.X);
        local math_max_ret = math.max(0, v30.X);
        local math_clamp_ret = math.clamp(math_round_ret, 0, math_max_ret);
        local math_round_ret2 = math.round(u22.Y + v29.Y);
        local math_max_ret2 = math.max(0, v30.Y);
        Position(UDim2_fromOffset(math_clamp_ret, (math.clamp(math_round_ret2, 0, math_max_ret2))), true);
    end;

    local function dragInputBegan(u31, p32) -- Line: 160
        -- upvalues: table_clone_ret (copy), u25 (copy), u26 (copy), u1 (ref), u22 (ref), u20 (ref), u21 (ref), u24 (copy)
        if p32 or not table_clone_ret.Draggable._value then
            return;
        end;

        if not (u31.UserInputType ~= Enum.UserInputType.MouseButton1 and u31.UserInputType ~= Enum.UserInputType.Touch or (u25._value or u26._value)) then
            u1.bringToFront(table_clone_ret);
            u22 = table_clone_ret._instance.AbsolutePosition - table_clone_ret._instance.Parent.AbsolutePosition;
            u20 = u31;
            u21 = u31.Position;
            u24(true);
            local u33 = nil;
            u33 = u31:GetPropertyChangedSignal("UserInputState"):Connect(function() -- Line: 175
                -- upvalues: u31 (copy), u33 (ref), u20 (ref), u24 (ref)
                if u31.UserInputState == Enum.UserInputState.End then
                    u33:Disconnect();

                    if u20 == u31 then
                        u20 = nil;
                        u24(false);
                    end;
                end;
            end);
        end;
    end;

    local u34 = nil;
    local u35 = nil;
    local u36 = nil;
    local u37 = nil;
    local u38 = nil;

    local function resizeUpdate(p39) -- Line: 189
        -- upvalues: table_clone_ret (copy), u21 (ref), u34 (ref), u23 (copy), u35 (ref), u37 (ref), u22 (ref), u36 (ref), u38 (ref)
        local AbsoluteSize = table_clone_ret._instance.Parent.AbsoluteSize;
        local math_clamp_ret = math.clamp(p39.Position.X, 0, AbsoluteSize.X);
        local math_clamp_ret2 = math.clamp(p39.Position.Y, 0, AbsoluteSize.Y);
        local v40 = Vector3.new(math_clamp_ret, math_clamp_ret2, 0) - u21;
        local v41 = table_clone_ret.SizeBounds._value.Min - u34;
        local v42 = table_clone_ret.SizeBounds._value.Max - u34;
        u23(p39.Position);
        local Size = table_clone_ret.Size;
        local UDim2_fromOffset = UDim2.fromOffset;
        local X = u34.X;
        local v43 = u35 * v40.X;
        local X2 = v41.X;
        local math_max_ret = math.max(v41.X, v42.X);
        local v44 = X + math.clamp(v43, X2, math_max_ret);
        local math_round_ret = math.round(v44);
        local Y = u34.Y;
        local v45 = u37 * v40.Y;
        local Y2 = v41.Y;
        local math_max_ret2 = math.max(v41.Y, v42.Y);
        local v46 = Y + math.clamp(v45, Y2, math_max_ret2);
        Size(UDim2_fromOffset(math_round_ret, (math.round(v46))));
        local Position = table_clone_ret.Position;
        local UDim2_fromOffset2 = UDim2.fromOffset;
        local X3 = u22.X;
        local v47 = u36 * -v40.X;
        local X4 = v41.X;
        local math_max_ret3 = math.max(v41.X, v42.X);
        local v48 = X3 - math.clamp(v47, X4, math_max_ret3);
        local math_round_ret2 = math.round(v48);
        local Y3 = u22.Y;
        local v49 = u38 * -v40.Y;
        local Y4 = v41.Y;
        local math_max_ret4 = math.max(v41.Y, v42.Y);
        local v50 = Y3 - math.clamp(v49, Y4, math_max_ret4);
        Position(UDim2_fromOffset2(math_round_ret2, (math.round(v50))));
    end;

    local function resizeBegan(u51, p52) -- Line: 214
        -- upvalues: table_clone_ret (copy), getResizeIndex (ref), u35 (ref), u36 (ref), u37 (ref), u38 (ref), u20 (ref), u21 (ref), u22 (ref), u34 (ref), u25 (copy)
        if p52 or not table_clone_ret.Resizable._value then
            return;
        end;

        local v53 = (u51.UserInputType == Enum.UserInputType.MouseButton1 or u51.UserInputType == Enum.UserInputType.Touch) and (table_clone_ret._instance.Visible and getResizeIndex(Vector2.new(u51.Position.X, u51.Position.Y), table_clone_ret._instance.AbsoluteSize, table_clone_ret._instance.AbsolutePosition, 5));

        if v53 then
            local v54, v55, v56, v57 = unpack(v53, 1, 4);
            u35 = v54;
            u36 = v55;
            u37 = v56;
            u38 = v57;
            u20 = u51;
            u21 = u51.Position;
            u22 = table_clone_ret._instance.AbsolutePosition - table_clone_ret._instance.Parent.AbsolutePosition;
            u34 = table_clone_ret._instance.AbsoluteSize;
            u25(true);
            local u58 = nil;
            u58 = u51:GetPropertyChangedSignal("UserInputState"):Connect(function() -- Line: 235
                -- upvalues: u51 (copy), u58 (ref), u20 (ref), u25 (ref)
                if u51.UserInputState == Enum.UserInputState.End then
                    u58:Disconnect();

                    if u20 == u51 then
                        u20 = nil;
                        u25(false);
                    end;
                end;
            end);
        end;
    end;

    local u59 = Parent.compute(function() -- Line: 248
        -- upvalues: Parent (ref)
        return Parent.Theme.FontSize() + Parent.Theme.Padding().Offset * 2;
    end);

    local function v60() -- Line: 254
        -- upvalues: Parent (ref)
        return UDim2.fromOffset(Parent.Theme.FontSize(), Parent.Theme.FontSize());
    end;

    table_clone_ret._exitButton = Parent.new("Button")({
        LayoutOrder = 9,
        BackgroundTransparency = 1,
        HoverTransparency = 0,
        Text = "",
        BackgroundColor3 = Color3.fromRGB(200, 0, 0),

        Size = function() -- Line: 251
            -- upvalues: u59 (copy)
            return UDim2.fromOffset(u59(), u59());
        end,

        Icon = Parent.Theme.Image.Close,
        IconProperties = {
            ImageColor3 = Parent.Theme.PrimaryText,
            Size = UDim2.fromScale(0.5, 0.5)
        },

        Activated = function() -- Line: 270, Name: Activated
            -- upvalues: table_clone_ret (copy), Parent (ref)
            table_clone_ret._instance.Visible = false;
            Parent.clearActiveStates();

            if table_clone_ret.Close and type(table_clone_ret.Close._value) == "function" then
                table_clone_ret.Close._value(table_clone_ret);

                return;
            end;

            if table_clone_ret.RemoveOnClose._value then
                table_clone_ret:Destroy();
            end;
        end
    });
    table_clone_ret._exitButton._instance:FindFirstChildOfClass("UIStroke"):Destroy();
    Parent.edit(table_clone_ret._exitButton._instance.UICorner, {
        CornerRadius = Parent.Theme.CornerPadded
    });
    table_clone_ret._content = Parent.new("Frame")({
        Name = "UIContent",
        AutomaticSize = table_clone_ret.AutomaticSize,
        BackgroundTransparency = 1,
        Size = UDim2.new(1, 0, 1, 0),
        ClipsDescendants = true,
        Parent.new("UIFlexItem")({
            FlexMode = Enum.UIFlexMode.Fill
        }),
        Parent.new("UIPadding")({
            PaddingLeft = Parent.Theme.Padding,
            PaddingRight = Parent.Theme.Padding,
            PaddingBottom = Parent.Theme.Padding,
            PaddingTop = UDim.new(0, 1)
        })
    });
    table_clone_ret._instance = Parent.new("ImageLabel")({
        Name = "Window",
        AutomaticSize = table_clone_ret.AutomaticSize,

        BackgroundColor3 = function() -- Line: 305, Name: BackgroundColor3
            -- upvalues: Parent (ref)
            if Parent.Theme.BackgroundGradientEnabled() then
                return Color3.new(1, 1, 1);
            end;

            return Parent.Theme.Primary();
        end,

        BackgroundTransparency = Parent.Theme.Transparency,
        Image = Parent.Theme.BackgroundImage,
        ImageTransparency = Parent.Theme.BackgroundImageTransparency,
        ScaleType = Parent.Theme.BackgroundImageScaleType,
        Position = table_clone_ret.Position,
        Size = table_clone_ret.Size,
        Visible = false,
        Parent.new("UICorner")({
            CornerRadius = Parent.Theme.CornerRadius
        }),
        Parent.new("Gradient")({}),
        Parent.new("Stroke")({}),
        Parent.new("ImageLabel")({
            Name = "ResizeIcon",
            ZIndex = 1000,
            BackgroundTransparency = 1,
            Image = "rbxassetid://72264604015628",
            ImageRectSize = Vector2.new(24, 24),
            ImageRectOffset = u27,
            Size = UDim2.new(0, 24, 0, 24),
            Visible = u26,

            Position = function() -- Line: 331, Name: Position
                -- upvalues: u23 (copy), table_clone_ret (copy)
                local v61 = u23();

                return UDim2.fromOffset(v61.X - 12, v61.Y - 12) - table_clone_ret.Position();
            end,

            InputBegan = resizeBegan
        }),
        Parent.new("Frame")({
            AutomaticSize = table_clone_ret.AutomaticSize,
            BackgroundTransparency = 1,
            ClipsDescendants = true,
            Size = UDim2.fromScale(1, 1),
            Parent.new("UIListLayout")({
                SortOrder = Enum.SortOrder.LayoutOrder
            }),
            Parent.new("TextButton")({
                Name = "TitleBar",
                Active = true,
                Modal = true,
                LayoutOrder = -9000000000,
                BackgroundTransparency = 1,
                ClipsDescendants = true,
                AutomaticSize = Enum.AutomaticSize.Y,
                Size = UDim2.new(1, 0, 0, 0),
                TextTransparency = 1,
                Parent.new("UIListLayout")({
                    FillDirection = Enum.FillDirection.Horizontal,
                    SortOrder = Enum.SortOrder.LayoutOrder,
                    Padding = Parent.Theme.Padding,
                    VerticalAlignment = Enum.VerticalAlignment.Center
                }),
                Parent.new("UIPadding")({
                    PaddingLeft = function() -- Line: 367, Name: PaddingLeft
                        -- upvalues: Parent (ref)
                        return UDim.new(0, Parent.Theme.Padding().Offset + Parent.Theme.FontSize / 2);
                    end,

                    PaddingRight = Parent.Theme.Padding,
                    PaddingTop = Parent.Theme.Padding,
                    PaddingBottom = Parent.Theme.Padding
                }),
                Parent.new("Frame")({
                    Name = "Left",
                    AutomaticSize = Enum.AutomaticSize.XY,
                    BackgroundTransparency = 1,
                    Size = UDim2.new(),
                    Parent.edit(Parent.new("ImageLabel")({
                        BackgroundTransparency = 1,
                        AnchorPoint = Vector2.new(0, 0.5),
                        Image = table_clone_ret.Icon,
                        ImageColor3 = Parent.Theme.PrimaryText,
                        Position = UDim2.fromScale(0, 0.5),
                        Size = v60,

                        Visible = function() -- Line: 389, Name: Visible
                            -- upvalues: table_clone_ret (copy)
                            return table_clone_ret.Icon() ~= "";
                        end
                    }), table_clone_ret.IconProperties()),
                    Parent.new("TextLabel")({
                        AutoLocalize = false,
                        Name = "Title",
                        BackgroundTransparency = 1,
                        RichText = true,
                        AutomaticSize = Enum.AutomaticSize.XY,
                        Size = UDim2.new(0, 0, 0, 0),
                        FontFace = Parent.Theme.Font,

                        Position = function() -- Line: 403, Name: Position
                            -- upvalues: table_clone_ret (copy), Parent (ref)
                            local v62 = table_clone_ret.Icon() == "" and 0 or Parent.Theme.FontSize + Parent.Theme.Padding().Offset;

                            return UDim2.fromOffset(v62, 0);
                        end,

                        Text = function() -- Line: 408, Name: Text
                            -- upvalues: table_clone_ret (copy)
                            return `<b>{table_clone_ret.Title()}</b>`;
                        end,

                        TextColor3 = Parent.Theme.PrimaryText,
                        TextStrokeColor3 = Parent.Theme.Primary,
                        TextStrokeTransparency = Parent.Theme.TextStrokeTransparency,
                        TextSize = Parent.Theme.FontSizeLarger,
                        TextXAlignment = Enum.TextXAlignment.Left,
                        TextYAlignment = Enum.TextYAlignment.Center,
                        TextTruncate = Enum.TextTruncate.SplitWord
                    })
                }),
                Parent.new("Spacer")({}),
                table_clone_ret._exitButton,
                InputBegan = dragInputBegan
            }),
            table_clone_ret._content
        }),
        [Parent.Event] = {
            Visible = function() -- Line: 431, Name: Visible
                -- upvalues: table_clone_ret (copy), u1 (ref)
                if table_clone_ret._instance.Visible then
                    u1.bringToFront(table_clone_ret);
                    u1.nudge(table_clone_ret);
                end;
            end
        }
    });
    local MouseIconEnabled = Parent.UserInputService.MouseIconEnabled;
    local u63 = nil;
    Parent.UserInputService:GetPropertyChangedSignal("MouseIconEnabled"):Connect(function() -- Line: 441
        -- upvalues: u63 (ref), MouseIconEnabled (ref), Parent (ref)
        if u63 then
            return;
        end;

        MouseIconEnabled = Parent.UserInputService.MouseIconEnabled;
    end);
    Parent.UserInputService.InputBegan:Connect(resizeBegan);
    Parent.UserInputService.InputChanged:Connect(function(p64) -- Line: 449
        -- upvalues: table_clone_ret (copy), u25 (copy), resizeUpdate (copy), u24 (copy), dragUpdate (copy), getResizeIndex (ref), u23 (copy), u26 (copy), u27 (copy), Parent (ref), u63 (ref), MouseIconEnabled (ref)
        if not table_clone_ret._instance.Visible then
            return;
        end;

        if p64.UserInputType == Enum.UserInputType.MouseMovement or p64.UserInputType == Enum.UserInputType.Touch then
            if u25._value then
                resizeUpdate(p64);

                return;
            end;

            if u24._value then
                dragUpdate(p64);

                return;
            end;

            if table_clone_ret.Resizable._value then
                local v65 = getResizeIndex(Vector2.new(p64.Position.X, p64.Position.Y), table_clone_ret._instance.AbsoluteSize, table_clone_ret._instance.AbsolutePosition, 5);

                if v65 then
                    u23(p64.Position);
                    u26(true);
                    u27(Vector2.new(v65[5]));

                    if Parent.UserInputService.MouseIconEnabled then
                        u63 = true;
                        Parent.UserInputService.MouseIconEnabled = false;
                        u63 = false;
                    end;
                elseif u26._value then
                    u26(false);

                    if Parent.UserInputService.MouseIconEnabled ~= MouseIconEnabled then
                        u63 = true;
                        Parent.UserInputService.MouseIconEnabled = MouseIconEnabled;
                        u63 = false;
                    end;
                end;
            end;
        end;
    end);
    local u66 = nil;
    table_clone_ret._instance:GetPropertyChangedSignal("Parent"):Connect(function() -- Line: 492
        -- upvalues: u66 (ref), table_clone_ret (copy)
        if u66 then
            u66:Disconnect();
        end;

        local Parent2 = table_clone_ret._instance.Parent;

        if Parent2 and Parent2:IsA("GuiBase2d") then
            local function updateSize() -- Line: 498
                -- upvalues: table_clone_ret (ref)
                if not table_clone_ret._instance.Visible then
                    return;
                end;

                local AbsoluteSize = table_clone_ret._instance.Parent.AbsoluteSize;
                local AbsoluteSize2 = table_clone_ret._instance.AbsoluteSize;
                local v67 = AbsoluteSize - AbsoluteSize2;
                local v68 = table_clone_ret._instance.AbsolutePosition - table_clone_ret._instance.Parent.AbsolutePosition;
                local v69 = table_clone_ret._instance.Parent:FindFirstChildOfClass("UIPadding");
                local v70 = not v69 and 0 or v69.PaddingTop.Offset + AbsoluteSize.Y * v69.PaddingTop.Scale + v69.PaddingBottom.Offset + AbsoluteSize.Y * v69.PaddingBottom.Scale;
                local Size = table_clone_ret.Size;
                local UDim2_fromOffset = UDim2.fromOffset;
                local X = AbsoluteSize2.X;
                local math_max_ret = math.max(0, AbsoluteSize.X - (not v69 and 0 or v69.PaddingLeft.Offset + AbsoluteSize.X * v69.PaddingLeft.Scale + v69.PaddingRight.Offset + AbsoluteSize.X * v69.PaddingRight.Scale));
                local math_clamp_ret = math.clamp(X, 0, math_max_ret);
                local Y = AbsoluteSize2.Y;
                local math_max_ret2 = math.max(0, AbsoluteSize.Y - v70);
                Size(UDim2_fromOffset(math_clamp_ret, (math.clamp(Y, 0, math_max_ret2))));
                local Position = table_clone_ret.Position;
                local UDim2_fromOffset2 = UDim2.fromOffset;
                local X2 = v68.X;
                local math_max_ret3 = math.max(0, v67.X);
                local math_clamp_ret2 = math.clamp(X2, 0, math_max_ret3);
                local Y2 = v68.Y;
                local math_max_ret4 = math.max(0, v67.Y);
                Position(UDim2_fromOffset2(math_clamp_ret2, (math.clamp(Y2, 0, math_max_ret4))));
            end;

            u66 = Parent2:GetPropertyChangedSignal("AbsoluteSize"):Connect(updateSize);
            table_clone_ret._instance:GetPropertyChangedSignal("Visible"):Connect(updateSize);

            if table_clone_ret._instance.Visible then
                updateSize();
            end;
        end;
    end);

    return setmetatable(table_clone_ret, u1);
end;

return u1;