-- Decompiled with Potassium's decompiler.

local Players = game:GetService("Players");
local RunService = game:GetService("RunService");
local ReplicatedStorage = game:GetService("ReplicatedStorage");
local LocalPlayer = Players.LocalPlayer;
local ServerRemote = ReplicatedStorage:WaitForChild("Remotes"):WaitForChild("ServerRemote");
local Color3_fromRGB_ret = Color3.fromRGB(44, 44, 45);
local Color3_fromRGB_ret2 = Color3.fromRGB(28, 28, 30);
Color3.fromRGB(255, 255, 255);
local Color3_fromRGB_ret3 = Color3.fromRGB(0, 0, 0);
local Color3_fromRGB_ret4 = Color3.fromRGB(255, 152, 48);
Color3.fromRGB(140, 138, 132);
local Color3_fromRGB_ret5 = Color3.fromRGB(120, 235, 120);
local Arcade = Enum.Font.Arcade;
local Bangers = Enum.Font.Bangers;
local CFrame_new_ret = CFrame.new(0, 0, -7.5);
local u1 = nil;
local u2 = nil;
local u3 = nil;
local u4 = nil;
local u5 = 0;

local function stroke(p6, p7) -- Line: 44
    -- upvalues: Color3_fromRGB_ret3 (copy)
    local UIStroke = Instance.new("UIStroke");
    UIStroke.Color = Color3_fromRGB_ret3;
    UIStroke.Thickness = p7 or 2;
    UIStroke.ApplyStrokeMode = Enum.ApplyStrokeMode.Border;
    UIStroke.Parent = p6;

    return UIStroke;
end;

local function findDragonballs() -- Line: 136
    -- upvalues: LocalPlayer (copy), CFrame_new_ret (copy)
    local Character = LocalPlayer.Character;

    if not Character then
        return nil;
    end;

    local HumanoidRootPart = Character:FindFirstChild("HumanoidRootPart");

    if not HumanoidRootPart then
        return nil;
    end;

    local u8 = {};

    local function scanTools(p9) -- Line: 144
        -- upvalues: u8 (copy)
        if not p9 then
            return;
        end;

        for _, child in ipairs(p9:GetChildren()) do
            if child:IsA("Tool") and child.Name:match("^%d Star Dragonball$") then
                u8[child.Name] = true;
            end;
        end;
    end;

    scanTools(LocalPlayer:FindFirstChildOfClass("Backpack"));
    scanTools(Character);
    local World = workspace:FindFirstChild("World");

    if World then
        World = World:FindFirstChild("Live");
    end;

    local OverlapParams_new_ret = OverlapParams.new();

    if World then
        OverlapParams_new_ret.FilterDescendantsInstances = { World };
        OverlapParams_new_ret.FilterType = Enum.RaycastFilterType.Exclude;
    end;

    local PartBoundsInBox = workspace:GetPartBoundsInBox(HumanoidRootPart.CFrame * CFrame_new_ret, Vector3.new(25, 9, 25), OverlapParams_new_ret);

    for _, v in ipairs(PartBoundsInBox) do
        local Parent = v.Parent;

        if v.Name == "Handle" and (Parent and (Parent:IsA("Model") and (Parent.Name:match("^%d Star Dragonball$") and Parent:FindFirstChildWhichIsA("ProximityPrompt", true)))) then
            u8[Parent.Name] = true;
        end;
    end;

    return u8;
end;

local function canSummon() -- Line: 176
    -- upvalues: LocalPlayer (copy), findDragonballs (copy)
    if workspace:FindFirstChild("Shenron Summoned") or (workspace:FindFirstChild("Porunga Summoned") or workspace:FindFirstChild("Summon Cooldown")) then
        return false;
    end;

    local Character = LocalPlayer.Character;

    if not Character then
        return false;
    end;

    if Character:FindFirstChild("ForceField") then
        return false;
    end;

    local v10 = Character:FindFirstChildOfClass("Humanoid");

    if not v10 or v10.Health <= 0 then
        return false;
    end;

    local v11 = findDragonballs();

    if not v11 then
        return false;
    end;

    if not v11[3 .. " Star Dragonball"] then
        return false;
    end;

    if not v11[4 .. " Star Dragonball"] then
        return false;
    end;

    if not v11[5 .. " Star Dragonball"] then
        return false;
    end;

    if not v11[6 .. " Star Dragonball"] then
        return false;
    end;

    if v11[7 .. " Star Dragonball"] then
        return true, v11["1 Star Dragonball"] and v11["2 Star Dragonball"] and 1 or (v11["2 Star Dragonball"] and 2 or 3);
    end;

    return false;
end;

(function() -- Line: 53, Name: ensureGui
    -- upvalues: u1 (ref), LocalPlayer (copy), u2 (ref), Color3_fromRGB_ret (copy), Color3_fromRGB_ret3 (copy), Color3_fromRGB_ret2 (copy), Arcade (copy), Color3_fromRGB_ret4 (copy), Color3_fromRGB_ret5 (copy), u3 (ref), Bangers (copy), u4 (ref), u5 (ref), ServerRemote (copy)
    if u1 and u1.Parent then
        return;
    end;

    u1 = Instance.new("ScreenGui");
    u1.Name = "SummonButtonGui";
    u1.ResetOnSpawn = false;
    u1.DisplayOrder = 45;
    u1.Parent = LocalPlayer:WaitForChild("PlayerGui");
    u2 = Instance.new("Frame");
    u2.Name = "Card";
    u2.AnchorPoint = Vector2.new(0.5, 1);
    u2.Position = UDim2.new(0.5, 0, 1, -128);
    u2.Size = UDim2.fromOffset(190, 64);
    u2.BackgroundColor3 = Color3_fromRGB_ret;
    u2.BorderSizePixel = 0;
    u2.Visible = false;
    u2.Parent = u1;
    local UIStroke = Instance.new("UIStroke");
    UIStroke.Color = Color3_fromRGB_ret3;
    UIStroke.Thickness = 3;
    UIStroke.ApplyStrokeMode = Enum.ApplyStrokeMode.Border;
    UIStroke.Parent = u2;
    local TextLabel = Instance.new("TextLabel");
    TextLabel.Name = "Header";
    TextLabel.Size = UDim2.new(1, 0, 0, 18);
    TextLabel.BackgroundColor3 = Color3_fromRGB_ret2;
    TextLabel.BorderSizePixel = 0;
    TextLabel.Font = Arcade;
    TextLabel.TextSize = 11;
    TextLabel.TextColor3 = Color3_fromRGB_ret4;
    TextLabel.Text = "ETERNAL DRAGON";
    TextLabel.Parent = u2;
    local Frame = Instance.new("Frame");
    Frame.Name = "Accent";
    Frame.Position = UDim2.fromOffset(0, 18);
    Frame.Size = UDim2.new(1, 0, 0, 2);
    Frame.BackgroundColor3 = Color3_fromRGB_ret5;
    Frame.BorderSizePixel = 0;
    Frame.Parent = u2;
    u3 = Instance.new("TextButton");
    u3.Name = "Summon";
    u3.Position = UDim2.fromOffset(0, 20);
    u3.Size = UDim2.new(1, 0, 1, -34);
    u3.BackgroundColor3 = Color3_fromRGB_ret;
    u3.BorderSizePixel = 0;
    u3.AutoButtonColor = true;
    u3.Font = Bangers;
    u3.TextSize = 24;
    u3.TextColor3 = Color3_fromRGB_ret5;
    u3.TextStrokeColor3 = Color3_fromRGB_ret3;
    u3.TextStrokeTransparency = 0;
    u3.Text = "SUMMON SHENRON";
    u3.Parent = u2;
    u4 = Instance.new("TextLabel");
    u4.Name = "Tier";
    u4.AnchorPoint = Vector2.new(0, 1);
    u4.Position = UDim2.new(0, 0, 1, 0);
    u4.Size = UDim2.new(1, 0, 0, 14);
    u4.BackgroundTransparency = 1;
    u4.Font = Arcade;
    u4.TextSize = 10;
    u4.TextColor3 = Color3_fromRGB_ret4;
    u4.Text = "";
    u4.Parent = u2;
    u3.Activated:Connect(function() -- Line: 120
        -- upvalues: u5 (ref), u3 (ref), Color3_fromRGB_ret4 (ref), ServerRemote (ref), Color3_fromRGB_ret5 (ref)
        local os_clock_ret = os.clock();

        if os_clock_ret - u5 < 3 then
            return;
        end;

        u5 = os_clock_ret;
        u3.Text = "SUMMONING...";
        u3.TextColor3 = Color3_fromRGB_ret4;
        ServerRemote:FireServer("SummonRequest", {
            Module = "DragonballManager"
        });
        task.delay(3, function() -- Line: 127
            -- upvalues: u3 (ref), Color3_fromRGB_ret5 (ref)
            u3.Text = "SUMMON SHENRON";
            u3.TextColor3 = Color3_fromRGB_ret5;
        end);
    end);
end)();
local u12 = 0;
RunService.Heartbeat:Connect(function(p13) -- Line: 209
    -- upvalues: u12 (ref), canSummon (copy), u4 (ref), u2 (ref)
    u12 = u12 + p13;

    if u12 < 0.6 then
        return;
    end;

    u12 = 0;
    local v14, v15 = canSummon();

    if not v14 then
        u2.Visible = false;

        return;
    end;

    u4.Text = "TIER " .. v15 .. " WISH";
    u2.Visible = true;
end);