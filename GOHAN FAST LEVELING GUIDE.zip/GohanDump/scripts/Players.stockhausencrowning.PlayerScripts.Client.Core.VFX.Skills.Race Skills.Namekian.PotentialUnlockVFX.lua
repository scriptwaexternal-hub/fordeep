-- Decompiled with Potassium's decompiler.

local Debris = game:GetService("Debris");
local ReplicatedStorage = game:GetService("ReplicatedStorage");
local Modules = ReplicatedStorage:WaitForChild("Modules");
local GlobalFunctions = require(Modules.GlobalFunctions);
local Visuals = workspace.World.Visuals;
local Particles = ReplicatedStorage.Assets.Effects.Particles;

return {
    Start = function(p1) -- Line: 22
        -- upvalues: GlobalFunctions (copy), Particles (copy), Visuals (copy), Debris (copy)
        local Victim = p1.Victim;

        if not Victim then
            return;
        end;

        local RootAndHumanoid = GlobalFunctions.GetRootAndHumanoid(Victim);

        if not RootAndHumanoid then
            return;
        end;

        local v2 = p1.Duration or 4;
        local u3 = Particles["Small Ray"]:Clone();
        u3.CFrame = RootAndHumanoid.CFrame * CFrame.new(0, -2.5, 0);
        u3.Anchored = true;
        u3.CanCollide = false;
        u3.Rays.Enabled = true;
        u3.Rays.Rate = 0;
        u3.Parent = Visuals;
        GlobalFunctions.Tween({
            Duration = 4,
            Instance = u3.Rays
        }, {
            Rate = 100
        });
        task.delay(v2, function() -- Line: 39
            -- upvalues: u3 (copy), GlobalFunctions (ref), Debris (ref)
            if not u3.Parent then
                return;
            end;

            GlobalFunctions.Tween({
                Duration = 1,
                Instance = u3.Rays
            }, {
                Rate = 0
            });
            Debris:AddItem(u3, 2);
        end);
    end,

    Finish = function(p4) -- Line: 46
        -- upvalues: GlobalFunctions (copy), Particles (copy), Visuals (copy), Debris (copy)
        local Victim = p4.Victim;

        if not Victim then
            return;
        end;

        local RootAndHumanoid = GlobalFunctions.GetRootAndHumanoid(Victim);

        if not RootAndHumanoid then
            return;
        end;

        local u5 = Particles["Big Ray"]:Clone();
        u5.CFrame = RootAndHumanoid.CFrame * CFrame.new(0, -2.5, 0);
        u5.Anchored = true;
        u5.Rays.Enabled = true;
        u5.Parent = Visuals;
        task.delay(4, function() -- Line: 58
            -- upvalues: u5 (copy), GlobalFunctions (ref), Debris (ref)
            if not u5.Parent then
                return;
            end;

            GlobalFunctions.Tween({
                Duration = 1,
                Instance = u5.Rays
            }, {
                Rate = 0
            });
            Debris:AddItem(u5, 1);
        end);
    end
};