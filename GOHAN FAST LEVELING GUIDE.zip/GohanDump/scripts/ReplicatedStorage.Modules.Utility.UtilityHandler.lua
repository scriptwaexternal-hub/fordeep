-- Decompiled with Potassium's decompiler.

local u1 = {};

function Recursive_Search(p2, p3, p4)
    for i, v in pairs(p2) do
        if type(v) == "table" then
            if i == p3 and p4 then
                return v;
            end;

            local v5 = Recursive_Search(v, p3, p4);

            if v5 ~= nil then
                return v5;
            end;
        elseif tostring(i) == p3 then
            return v;
        end;
    end;

    return nil;
end;

function Recursive_Set(p6, p7, p8)
    for i, v in pairs(p6) do
        if type(v) == "table" then
            local v9 = Recursive_Set(v, p7, p8);

            if v9 ~= nil then
                return v9;
            end;
        elseif tostring(i) == p7 then
            return p8;
        end;
    end;

    return nil;
end;

local function DeepReconcile(p10, p11) -- Line: 50
    -- upvalues: DeepReconcile (copy)
    for i, v in pairs(p10) do
        if p11[i] == nil then
            if type(v) == "table" then
                p11[i] = DeepReconcile(v, {});
            else
                p11[i] = v;
            end;
        elseif type(v) == "table" and type(p11[i]) == "table" then
            DeepReconcile(v, p11[i]);
        end;
    end;

    return p11;
end;

local u12 = {
    Relations = true,
    Combat_Styles = true,
    Pity = true,
    ToolSlots = true,
    Quests = true,
    Emotes = true,
    TrainerSkills = true,
    Backpack = true
};

local function isEmptyTable(p13) -- Line: 124
    local v14;

    if type(p13) == "table" then
        v14 = next(p13) == nil;
    else
        v14 = false;
    end;

    return v14;
end;

local function DeepPrune(p15, p16, p17) -- Line: 128
    -- upvalues: u12 (copy), DeepPrune (copy)
    for i in pairs(p16) do
        local v18 = p17 and p17 .. "." .. tostring(i) or tostring(i);

        if not u12[v18] then
            local v19 = p15[i];
            local v20;

            if type(v19) == "table" then
                v20 = next(v19) == nil;
            else
                v20 = false;
            end;

            if not v20 then
                if p15[i] == nil then
                    p16[i] = nil;
                elseif type(p15[i]) == "table" and type(p16[i]) == "table" then
                    DeepPrune(p15[i], p16[i], v18);
                end;
            end;
        end;
    end;

    return p16;
end;

local function MigrateData(p21, p22) -- Line: 146
    -- upvalues: DeepReconcile (copy), DeepPrune (copy)
    DeepReconcile(p21, p22);
    DeepPrune(p21, p22);

    return p22;
end;

function u1.deepSearchFolder(p23, p24, p25, p26) -- Line: 152
    local Children = p24:GetChildren();
    local v27 = p25 or "Animation";
    local v28 = p26 or {};

    for _, v in ipairs(Children) do
        if v:IsA(v27) then
            v28[#v28 + 1] = v;
        elseif v:IsA("Folder") or v:IsA("ModuleScript") then
            p23:deepSearchFolder(v, v27, v28);
        end;
    end;

    return v28;
end;

function u1.DeepSearchTable(p29, p30, p31, p32) -- Line: 169
    return Recursive_Search(p30, p31, p32);
end;

function u1.SetValueTable(p33, p34, p35, p36) -- Line: 173
    return Recursive_Set(p34, p35, p36);
end;

function u1.DeepCopy(p37, p38) -- Line: 177
    -- upvalues: u1 (copy)
    local v39 = {};

    for i, v in pairs(p38) do
        local v40;

        if type(v) == "table" then
            v40 = u1:DeepCopy(v);
        else
            v40 = v;
        end;

        v39[i] = v40;
    end;

    return v39;
end;

function u1.Length(p41, p42) -- Line: 188
    local v43 = 0;

    for _, _ in pairs(p42) do
        v43 = v43 + 1;
    end;

    return v43;
end;

function u1.MigrateData(p44, p45, p46) -- Line: 196
    -- upvalues: DeepReconcile (copy), DeepPrune (copy)
    DeepReconcile(p45, p46);
    DeepPrune(p45, p46);
end;

return u1;