-- Decompiled with Potassium's decompiler.

local Players = game:GetService("Players");
local TweenService = game:GetService("TweenService");
local ReplicatedStorage = game:GetService("ReplicatedStorage");
local GlobalFunctions = require(ReplicatedStorage:WaitForChild("Modules"):WaitForChild("GlobalFunctions"));
local LocalPlayer = Players.LocalPlayer;
local Color3_fromRGB_ret = Color3.fromRGB(255, 255, 255);
local Color3_fromRGB_ret2 = Color3.fromRGB(216, 213, 205);
local Color3_fromRGB_ret3 = Color3.fromRGB(160, 158, 152);
local Color3_fromRGB_ret4 = Color3.fromRGB(226, 62, 48);
local Color3_fromRGB_ret5 = Color3.fromRGB(0, 0, 0);
local u1 = {};
local u2 = nil;
local u3 = nil;

local function label(p4, p5, p6, p7, p8) -- Line: 32
    -- upvalues: Color3_fromRGB_ret5 (copy)
    local TextLabel = Instance.new("TextLabel");
    TextLabel.BackgroundTransparency = 1;
    TextLabel.Size = UDim2.new(1, 0, 0, p6);
    TextLabel.LayoutOrder = p8;
    TextLabel.Font = Enum.Font.Bangers;
    TextLabel.TextSize = p6;
    TextLabel.TextColor3 = p7;
    TextLabel.TextStrokeColor3 = Color3_fromRGB_ret5;
    TextLabel.TextStrokeTransparency = 0.4;
    TextLabel.TextXAlignment = Enum.TextXAlignment.Center;
    TextLabel.TextTruncate = Enum.TextTruncate.AtEnd;
    TextLabel.Text = p5;
    TextLabel.ZIndex = 5;
    TextLabel.Parent = p4;

    return TextLabel;
end;

local function buildFace(p9, p10) -- Line: 51
    -- upvalues: GlobalFunctions (copy)
    if not (p10 and p10.Parent) then
        return false;
    end;

    if not (GlobalFunctions.FindFakeHead(p10) or p10:FindFirstChild("Head")) then
        return false;
    end;

    local Archivable = p10.Archivable;
    p10.Archivable = true;
    local success, result = pcall(p10.Clone, p10);
    p10.Archivable = Archivable;

    if not (success and result) then
        return false;
    end;

    for _, descendant in ipairs(result:GetDescendants()) do
        if descendant:IsA("BaseScript") or (descendant:IsA("Sound") or (descendant:IsA("ParticleEmitter") or (descendant:IsA("Trail") or descendant:IsA("Beam")))) then
            descendant:Destroy();
        elseif descendant:IsA("BasePart") then
            descendant.Anchored = true;
            descendant.CanCollide = false;
        end;
    end;

    local v11 = result:FindFirstChildOfClass("Humanoid");

    if v11 then
        v11.DisplayDistanceType = Enum.HumanoidDisplayDistanceType.None;
    end;

    local WorldModel = Instance.new("WorldModel");
    WorldModel.Parent = p9;
    result.Parent = WorldModel;
    local v12 = GlobalFunctions.FindFakeHead(result) or result:FindFirstChild("Head");

    if not v12 then
        return false;
    end;

    local Camera = Instance.new("Camera");
    Camera.FieldOfView = 40;
    Camera.Parent = p9;
    p9.CurrentCamera = Camera;
    local Position = v12.Position;
    Camera.CFrame = CFrame.lookAt(Position + v12.CFrame.LookVector * 2.6 + Vector3.new(0, 0.05, 0), Position);

    return true;
end;

function u1.Hide() -- Line: 89
    -- upvalues: u3 (ref), u2 (ref), TweenService (copy)
    if u3 then
        task.cancel(u3);
        u3 = nil;
    end;

    local u13 = u2;
    u2 = nil;

    if not u13 then
        return;
    end;

    local Holder = u13:FindFirstChild("Holder");

    if not Holder then
        u13:Destroy();

        return;
    end;

    local v14 = TweenService:Create(Holder, TweenInfo.new(0.35, Enum.EasingStyle.Quad, Enum.EasingDirection.In), {
        Position = UDim2.new(0.5, 0, 0.1, 0)
    });

    for _, descendant in ipairs(Holder:GetDescendants()) do
        if descendant:IsA("TextLabel") then
            TweenService:Create(descendant, TweenInfo.new(0.35), {
                TextTransparency = 1,
                TextStrokeTransparency = 1
            }):Play();
        end;

        if descendant:IsA("ViewportFrame") then
            TweenService:Create(descendant, TweenInfo.new(0.35), {
                ImageTransparency = 1
            }):Play();
        end;
    end;

    v14:Play();
    v14.Completed:Once(function() -- Line: 102
        -- upvalues: u13 (copy)
        u13:Destroy();
    end);
end;

function u1.Show(p15) -- Line: 108
    -- upvalues: u1 (copy), LocalPlayer (copy), u2 (ref), label (copy), Color3_fromRGB_ret4 (copy), Color3_fromRGB_ret (copy), buildFace (copy), Color3_fromRGB_ret2 (copy), Color3_fromRGB_ret3 (copy), TweenService (copy), u3 (ref)
    u1.Hide();
    local v16;

    if p15 then
        v16 = p15.Killer;
    else
        v16 = p15;
    end;

    if typeof(v16) ~= "Instance" or not v16:IsA("Player") then
        return;
    end;

    local v17 = tostring(p15.KillerName or v16.DisplayName);
    local ScreenGui = Instance.new("ScreenGui");
    ScreenGui.Name = "KilledByCard";
    ScreenGui.ResetOnSpawn = false;
    ScreenGui.IgnoreGuiInset = true;
    ScreenGui.DisplayOrder = 80;
    ScreenGui.Parent = LocalPlayer:WaitForChild("PlayerGui");
    u2 = ScreenGui;
    local Frame = Instance.new("Frame");
    Frame.Name = "Holder";
    Frame.BackgroundTransparency = 1;
    Frame.AnchorPoint = Vector2.new(0.5, 0);
    Frame.Position = UDim2.new(0.5, 0, 0.1, 0);
    Frame.Size = UDim2.new(0, 320, 0, 230);
    Frame.Parent = ScreenGui;
    local UIListLayout = Instance.new("UIListLayout");
    UIListLayout.FillDirection = Enum.FillDirection.Vertical;
    UIListLayout.HorizontalAlignment = Enum.HorizontalAlignment.Center;
    UIListLayout.SortOrder = Enum.SortOrder.LayoutOrder;
    UIListLayout.Padding = UDim.new(0, -2);
    UIListLayout.Parent = Frame;
    label(Frame, "KILLED BY", 16, Color3_fromRGB_ret4, 0);
    local ViewportFrame = Instance.new("ViewportFrame");
    ViewportFrame.Name = "Face";
    ViewportFrame.BackgroundTransparency = 1;
    ViewportFrame.BorderSizePixel = 0;
    ViewportFrame.Size = UDim2.new(0, 150, 0, 150);
    ViewportFrame.LayoutOrder = 1;
    ViewportFrame.Ambient = Color3.fromRGB(190, 190, 190);
    ViewportFrame.LightColor = Color3_fromRGB_ret;
    ViewportFrame.LightDirection = Vector3.new(-0.3, -1, -0.6);
    ViewportFrame.ZIndex = 5;
    ViewportFrame.Parent = Frame;
    pcall(buildFace, ViewportFrame, v16.Character);
    label(Frame, v17, 26, Color3_fromRGB_ret, 2);
    label(Frame, "(" .. v16.Name .. ")", 18, Color3_fromRGB_ret2, 3);
    label(Frame, tostring(v16.UserId), 14, Color3_fromRGB_ret3, 4);
    local Position = Frame.Position;
    Frame.Position = UDim2.new(0.5, 0, 0.04, 0);

    for _, descendant in ipairs(Frame:GetDescendants()) do
        if descendant:IsA("TextLabel") then
            descendant.TextTransparency = 1;
            descendant.TextStrokeTransparency = 1;
            TweenService:Create(descendant, TweenInfo.new(0.4), {
                TextTransparency = 0,
                TextStrokeTransparency = 0.4
            }):Play();
        end;
    end;

    ViewportFrame.ImageTransparency = 1;
    TweenService:Create(ViewportFrame, TweenInfo.new(0.4), {
        ImageTransparency = 0
    }):Play();
    TweenService:Create(Frame, TweenInfo.new(0.4, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
        Position = Position
    }):Play();
    u3 = task.delay(7, function() -- Line: 170
        -- upvalues: u3 (ref), u1 (ref)
        u3 = nil;
        u1.Hide();
    end);
end;

return u1;