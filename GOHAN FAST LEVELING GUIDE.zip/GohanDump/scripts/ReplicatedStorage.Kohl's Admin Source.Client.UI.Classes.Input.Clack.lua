-- Decompiled with Potassium's decompiler.

local ContentProvider = game:GetService("ContentProvider");
local TextChatService = game:GetService("TextChatService");
local UserInputService = game:GetService("UserInputService");
local SoundService = game:GetService("SoundService");
local u1 = TextChatService:FindFirstChildOfClass("ChatInputBarConfiguration");
local u2 = {
    enabled = true,
    everyTextBox = true
};
local Sound = Instance.new("Sound");
Sound.SoundId = "rbxassetid://136112106699293";
task.spawn(ContentProvider.PreloadAsync, ContentProvider, { Sound });
local u3 = nil;
local u4 = nil;
local Random_new_ret = Random.new();

function u2.sound(p5) -- Line: 22
    -- upvalues: Random_new_ret (copy), u3 (ref), u4 (ref), SoundService (copy)
    local v6 = p5.Value % 8;
    local Sound2 = Instance.new("Sound");
    Sound2.Volume = Random_new_ret:NextNumber(1.5, 2);

    if v6 == u3 and p5 ~= u4 then
        Sound2.PlaybackSpeed = Random_new_ret:NextNumber(0.9, 1.1);
    end;

    Sound2.SoundId = "rbxassetid://136112106699293";
    Sound2.PlaybackRegionsEnabled = true;
    Sound2.PlaybackRegion = NumberRange.new(v6 * 0.3, v6 * 0.3 + 0.15);
    Sound2.Parent = SoundService;
    Sound2:Play();
    task.delay(1, Sound2.Destroy, Sound2);
    u3 = v6;
    u4 = p5;
end;

function u2.registerAll() -- Line: 38
    -- upvalues: u2 (copy), UserInputService (copy), u1 (copy)
    u2.registerAll = nil;
    local u7 = {};
    local u8 = false;
    UserInputService.TextBoxFocused:Connect(function(p9) -- Line: 41
        -- upvalues: u7 (copy), u8 (ref)
        if not (p9 and p9.TextEditable) then
            return;
        end;

        u7[p9] = true;
        u8 = p9;
    end);
    UserInputService.TextBoxFocusReleased:Connect(function(p10) -- Line: 49
        -- upvalues: u7 (copy), u8 (ref)
        if not (p10 and p10.TextEditable) then
            return;
        end;

        u7[p10] = nil;

        if next(u7) then
            return;
        end;

        u8 = nil;
    end);
    UserInputService.InputBegan:Connect(function(p11, p12) -- Line: 60
        -- upvalues: u2 (ref), u8 (ref), u1 (ref)
        if not (u2.enabled and (u8 or u1.IsFocused)) or p11.KeyCode == Enum.KeyCode.Unknown then
            return;
        end;

        if u2.everyTextBox or u8 and u8:HasTag("KeyClackSound") then
            task.spawn(u2.sound, p11.KeyCode);
        end;
    end);

    return u2;
end;

return u2;