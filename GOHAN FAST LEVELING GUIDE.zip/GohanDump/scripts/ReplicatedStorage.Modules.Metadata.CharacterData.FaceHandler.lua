-- Decompiled with Potassium's decompiler.

local ReplicatedStorage = game:GetService("ReplicatedStorage");
game:GetService("ServerScriptService");
local Modules = ReplicatedStorage:WaitForChild("Modules");
local Metadata = Modules.Metadata;
local Assets = ReplicatedStorage.Assets;
local GlobalFunctions = require(Modules.GlobalFunctions);
local FaceData = require(Metadata.CharacterData.FaceData);
local TransformData = require(Metadata.MiscData.TransformData.TransformData);
local Faces = Assets.Faces;
local Noses = Assets.Noses;
local Mouths = Assets.Mouths;
local RaceMouths = Assets:FindFirstChild("RaceMouths");
local RaceNoses = Assets:FindFirstChild("RaceNoses");
local u5 = {
    MaxMouths = function(p1) -- Line: 26, Name: MaxMouths
        -- upvalues: FaceData (copy)
        return FaceData.Mouths + ((FaceData.RaceMouths or {})[p1] or 0);
    end,

    MinMouths = function(p2) -- Line: 29, Name: MinMouths
        -- upvalues: FaceData (copy)
        return (FaceData.RaceMouthsOnly or {})[p2] and FaceData.Mouths + 1 or 1;
    end,

    MinFace = function(p3) -- Line: 32, Name: MinFace
        -- upvalues: FaceData (copy)
        return (FaceData.FaceMin or {})[p3] or 1;
    end,

    MaxNoses = function(p4) -- Line: 35, Name: MaxNoses
        -- upvalues: FaceData (copy)
        return FaceData.Noses + ((FaceData.RaceNoses or {})[p4] or 0);
    end
};

local function pickDecal(p6, p7, p8, p9, p10) -- Line: 40
    local v11 = tonumber(p10) or 1;
    local v12 = p6:FindFirstChild(p9 .. v11);

    if not v12 and (p7 and p7:FindFirstChild(p8)) then
        v12 = p7[p8]:FindFirstChild(p9 .. v11);
    end;

    return (v12 or p6[p9 .. "1"]):Clone();
end;

function u5.Set(p13) -- Line: 49
    -- upvalues: u5 (copy), FaceData (copy)
    return math.random(u5.MinFace(p13), FaceData[p13]);
end;

function u5.Give(p14, p15) -- Line: 54
    -- upvalues: u5 (copy), GlobalFunctions (copy), Faces (copy), pickDecal (copy), Noses (copy), RaceNoses (copy), Mouths (copy), RaceMouths (copy)
    local Race = p14.CharacterData.Race.Race;
    local v16 = p14.CharacterData.Face or 1;
    local v17 = p14.CharacterData.HairColor or {
        Red = 0,
        Green = 0,
        Blue = 0
    };
    local v18 = p14.CharacterData.PupilColor or {
        Red = 0,
        Green = 0,
        Blue = 0
    };
    local v19 = p14.CharacterData.MouthType or 1;
    local v20 = p14.CharacterData.NoseType or 1;
    u5.RemoveFace(p15);
    local v21 = GlobalFunctions.FindFakeHead(p15);
    local v22 = (Faces[Race]:FindFirstChild(Race .. "Face" .. v16) or Faces[Race]:FindFirstChild(Race .. "Face" .. u5.MinFace(Race))):Clone();

    if v19 < u5.MinMouths(Race) then
        v19 = u5.MinMouths(Race);
    end;

    if v22:IsA("Decal") then
        v22.Parent = v21;

        return;
    end;

    if v22:IsA("Folder") then
        local v23 = pickDecal(Noses, RaceNoses, Race, "Nose", v20);
        local v24 = pickDecal(Mouths, RaceMouths, Race, "Mouth", v19);
        v23.Parent = v21;
        v24.Parent = v21;

        for _, child in pairs(v22:GetChildren()) do
            child.Parent = v21;

            if child.Name == "Eyebrow" then
                local v25 = {
                    Color3 = Color3.fromRGB(v17.Red, v17.Green, v17.Blue)
                };
                GlobalFunctions.Tween({
                    Duration = 0,
                    Instance = child
                }, v25);
            elseif child.Name == "Pupil" then
                local v26 = {
                    Color3 = Color3.fromRGB(v18.Red, v18.Green, v18.Blue)
                };
                GlobalFunctions.Tween({
                    Duration = 0,
                    Instance = child
                }, v26);
            end;
        end;
    end;
end;

function u5.GiveBioFace(p27, p28) -- Line: 115
    -- upvalues: u5 (copy), GlobalFunctions (copy), Faces (copy)
    local v29 = p27.Face or 1;
    local v30 = p27.HairColor or {
        Red = 0,
        Green = 0,
        Blue = 0
    };
    local v31 = p27.PupilColor or {
        Red = 0,
        Green = 0,
        Blue = 0
    };
    local _ = p27.MouthType or 1;
    local _ = p27.NoseType or 1;
    u5.RemoveFace(p28);
    local v32 = GlobalFunctions.FindFakeHead(p28);
    local v33 = Faces["Bio-Android"]["Bio-Android" .. "Face" .. v29]:Clone();

    if v33:IsA("Decal") then
        v33.Parent = v32;

        return;
    end;

    if v33:IsA("Folder") then
        for _, child in pairs(v33:GetChildren()) do
            child.Parent = v32;

            if child.Name == "Eyebrow" then
                local v34 = {
                    Color3 = Color3.fromRGB(v30.Red, v30.Green, v30.Blue)
                };
                GlobalFunctions.Tween({
                    Duration = 0,
                    Instance = child
                }, v34);
            elseif child.Name == "Pupil" then
                local v35 = {
                    Color3 = Color3.fromRGB(v31.Red, v31.Green, v31.Blue)
                };
                GlobalFunctions.Tween({
                    Duration = 0,
                    Instance = child
                }, v35);
            end;
        end;
    end;
end;

function u5.GiveSSJFace(p36, p37, p38) -- Line: 169
    -- upvalues: GlobalFunctions (copy), TransformData (copy)
    local _ = p36.CharacterData.Race.Race;
    local _ = p36.CharacterData.Race.SubType;
    local _ = p36.CharacterData.Face;
    local v39 = GlobalFunctions.FindFakeHead(p37);
    local v40, v41;

    if p38 == "LSSJ" then
        v40 = TransformData.Saiyan.LSSJCOLOR;
        v41 = Color3.fromRGB(255, 225, 0);
    elseif p38 == "Ikari" then
        v40 = Color3.fromRGB(0, 0, 0);
        v41 = Color3.fromRGB(255, 225, 0);
    elseif p38 == "SSJ4" then
        v40 = Color3.fromRGB(0, 0, 0);
        v41 = Color3.fromRGB(255, 225, 0);
    else
        v40 = TransformData.Saiyan.SSJCOLOR;
        v41 = Color3.fromRGB(0, 255, 255);
    end;

    for _, child in pairs(v39:GetChildren()) do
        if child:IsA("Decal") then
            if child.Name == "Eyebrow" then
                GlobalFunctions.Tween({
                    Duration = 1,
                    Instance = child
                }, {
                    Color3 = v40
                });
            elseif child.Name == "Pupil" then
                GlobalFunctions.Tween({
                    Duration = 1,
                    Instance = child
                }, {
                    Color3 = v41
                });
            end;
        end;
    end;
end;

function u5.TintEyebrows(p42, p43, p44) -- Line: 226
    -- upvalues: GlobalFunctions (copy)
    local v45 = GlobalFunctions.FindFakeHead(p42);

    if not v45 then
        return;
    end;

    for _, child in pairs(v45:GetChildren()) do
        if child:IsA("Decal") and child.Name == "Eyebrow" then
            GlobalFunctions.Tween({
                Instance = child,
                Duration = p44 or 1
            }, {
                Color3 = p43
            });
        end;
    end;
end;

function u5.RestoreEyebrows(p46, p47, p48) -- Line: 236
    -- upvalues: u5 (copy)
    local HairColor = p46.CharacterData.HairColor;
    u5.TintEyebrows(p47, Color3.fromRGB(HairColor.Red, HairColor.Green, HairColor.Blue), p48);
end;

function u5.RemoveSSJFace(p49, p50) -- Line: 241
    -- upvalues: GlobalFunctions (copy)
    local _ = p49.CharacterData.Race.Race;
    local PupilColor = p49.CharacterData.PupilColor;
    local HairColor = p49.CharacterData.HairColor;
    local v51 = GlobalFunctions.FindFakeHead(p50);

    for _, child in pairs(v51:GetChildren()) do
        if child:IsA("Decal") then
            if child.Name == "Eyebrow" then
                local v52 = {
                    Color3 = Color3.fromRGB(HairColor.Red, HairColor.Green, HairColor.Blue)
                };
                GlobalFunctions.Tween({
                    Duration = 1,
                    Instance = child
                }, v52);
            elseif child.Name == "Pupil" then
                local v53 = {
                    Color3 = Color3.fromRGB(PupilColor.Red, PupilColor.Green, PupilColor.Blue)
                };
                GlobalFunctions.Tween({
                    Duration = 1,
                    Instance = child
                }, v53);
            end;
        end;
    end;
end;

function u5.RemoveFace(p54) -- Line: 274
    -- upvalues: GlobalFunctions (copy)
    local v55 = GlobalFunctions.FindFakeHead(p54);

    for _, child in pairs(v55:GetChildren()) do
        if string.find(child.Name, "Face") then
            child:Destroy();
        elseif child.Name == "Pupil" or (child.Name == "Pupils" or (child.Name == "Eyebrow" or (child.Name == "Socket" or (child.Name == "Eyes" or (string.find(child.Name, "Mouth") or (string.find(child.Name, "Nose") or (child.Name == "Stripes" or child.Name == "Lines"))))))) then
            child:Destroy();
        end;
    end;
end;

return u5;