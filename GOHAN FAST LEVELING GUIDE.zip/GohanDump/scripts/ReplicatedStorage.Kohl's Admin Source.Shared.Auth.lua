-- Decompiled with Potassium's decompiler.

local Players = game:GetService("Players");
local script_Parent = script.Parent;
local Defaults = require(script_Parent.Data:WaitForChild("Defaults"));
local Hook = require(script_Parent:WaitForChild("Hook"));
local Registry = require(script_Parent:WaitForChild("Registry"));
local Util = require(script_Parent:WaitForChild("Util"));
local Remote = Util.Remote;
local u1 = {};

function u1.banHandler(p2) -- Line: 19
    -- upvalues: Defaults (copy), Util (copy), Players (copy), u1 (copy)
    local v3 = tostring(p2.UserId);
    local v4 = Defaults.bans[v3];

    if p2.UserId ~= Defaults.creatorId and (p2.UserId >= 1 and v4) then
        local v5 = not Util.RunContext.IsStudio and Players:GetBanHistoryAsync(p2.UserId);

        if v5 then
            local v6 = v5:GetCurrentPage()[1];

            if v6 and (not v6.Ban and (v4 and (v4[3] and v4[3] ~= 0))) then
                u1.unbanUsers({ p2.UserId });

                return;
            end;
        end;

        local _, v7, v8 = unpack(v4);
        local v9;

        if tonumber(v8) then
            if v8 > 0 then
                local v10 = v8 - os.time();

                if v10 <= 0 then
                    u1.unbanUsers({ p2.UserId });

                    return;
                end;

                v9 = "You are banned from this experience for " .. Util.Time.readable(v10) .. "!";
            else
                v9 = "You are permanently banned from this experience!";
            end;
        else
            v9 = "You are banned from this server!";
        end;

        if v7 then
            v9 = v9 .. "\n Reason: " .. v7;
        end;

        p2:Kick(v9);

        return true;
    end;
end;

local function saveBan(p11, p12, p13, p14, p15) -- Line: 62
    -- upvalues: Util (copy), Defaults (copy), Players (copy), u1 (copy), Remote (copy)
    local v16 = {
        Util.getUserInfo(p12).Username,
        p13,
        p14,
        p15
    };
    Defaults.bans[p11] = v16;

    if p14 then
        Defaults.Sync.bans[p11] = v16;
    end;

    for _, v in Players:GetPlayers() do
        if u1.hasCommand(v.UserId, "ban") then
            Remote.Ban:Fire(v, p11, v16);
        end;
    end;
end;

function u1.banUsers(p17: table, p18: string?, p19: number?, p20: number?, p21: boolean?) -- Line: 75
    -- upvalues: u1 (copy), Defaults (copy), saveBan (copy), Util (copy), Players (copy), Hook (copy)
    local v22 = p21 or (not p20 or u1.hasPermission(p20, "banasync"));
    local v23 = not v22 and 0 or p19;
    local v24;

    if v23 and v23 ~= 0 then
        v24 = v23 <= 0 and -1 or os.time() + v23;
    else
        v24 = nil;
    end;

    local v25 = {};

    for _, v in p17 do
        local v26 = tostring(v);

        if Defaults.bans[v26] and (Defaults.bans[v26][3] and Defaults.bans[v26][3] ~= 0) then
            Defaults.Sync.bans[v26] = Defaults.REMOVE;
            table.insert(v25, v);
        end;

        task.spawn(saveBan, v26, v, p18, v24, p20);
    end;

    if v22 and (v24 and not (Defaults.SEPARATE_DATASTORE or Util.RunContext.IsStudio)) then
        for i = 1, #p17, 50 do
            local table_move_ret = table.move(p17, i, math.min(#p17, i + 49), 1, {});
            local _ = i;
            local v27 = 0;

            while true do
                local success, result = pcall(Players.BanAsync, Players, {
                    ApplyToUniverse = true,
                    UserIds = table_move_ret,
                    PrivateReason = p18 or "No reason.",
                    DisplayReason = p18 or "No reason.",
                    Duration = v23
                });

                if success then
                    break;
                end;

                local string_match_ret = string.match(result, "\"code\": \"([^\"]+)\"");
                warn((`BanAsync failed: {string_match_ret or result}, trying again...`));
                v27 = v27 + 1;
                task.wait(2 ^ v27);
            end;
        end;
    elseif #v25 > 0 and not (Defaults.SEPARATE_DATASTORE or Util.RunContext.IsStudio) then
        for i = 1, #v25, 50 do
            local table_move_ret = table.move(v25, i, math.min(#v25, i + 49), 1, {});
            local _ = i;
            local v28 = 0;

            while true do
                local success, result = pcall(Players.UnbanAsync, Players, {
                    ApplyToUniverse = true,
                    UserIds = table_move_ret
                });

                if success then
                    break;
                end;

                local string_match_ret = string.match(result, "\"code\": \"([^\"]+)\"");
                warn((`UnbanAsync failed: {string_match_ret or result}, trying again...`));
                v28 = v28 + 1;
                task.wait(2 ^ v28);
            end;
        end;
    end;

    Hook.ban:Fire(p17, p18, v23, p20, p21);
end;

function u1.unbanUsers(p29: table, p30: number?, p31: boolean?) -- Line: 145
    -- upvalues: Defaults (copy), Players (copy), u1 (copy), Remote (copy), Util (copy), Hook (copy)
    local v32 = {};

    for _, v in p29 do
        local v33 = tostring(v);
        local v34 = tonumber(v);

        if p31 then
            local v35 = Defaults.bans[v33];

            if v35 and (v35[3] and v35[3] ~= 0) then
                table.insert(v32, v34);
            end;
        end;

        Defaults.bans[v33] = nil;
        Defaults.Sync.bans[v33] = Defaults.REMOVE;

        for _, v2 in Players:GetPlayers() do
            if u1.hasCommand(v2.UserId, "ban") then
                Remote.Ban:Fire(v2, v33);
            end;
        end;
    end;

    if p31 and (#v32 > 0 and not (Defaults.SEPARATE_DATASTORE or Util.RunContext.IsStudio)) then
        for i = 1, #v32, 50 do
            local table_move_ret = table.move(v32, i, math.min(#v32, i + 49), 1, {});
            local _ = i;
            local v36 = 0;

            while true do
                v36 = v36 + 1;
                local success, result = pcall(Players.UnbanAsync, Players, {
                    ApplyToUniverse = true,
                    UserIds = table_move_ret
                });

                if success then
                    break;
                end;

                local string_match_ret = string.match(result, "\"code\": \"([^\"]+)\"");
                warn((`UnbanAsync failed: {string_match_ret or result}, trying again...`));
                task.wait(2 ^ v36);
            end;
        end;
    end;

    Hook.unban:Fire(p29, p30, p31);
end;

local function saveMember(p37, p38) -- Line: 189
    -- upvalues: Defaults (copy), Util (copy)
    Defaults.Sync.members[p37] = { Util.getUserInfo(p38).Username, Defaults.members[p37].persist };
end;

function u1.networkMember(p39: number) -- Line: 193
    -- upvalues: Defaults (copy), Players (copy), Remote (copy)
    local v40 = tostring(p39);
    local v41 = Defaults.members[v40];

    for _, v in Players:GetPlayers() do
        if v:GetAttribute("_K_READY") then
            Remote.Member:Fire(v, v40, v41);
        end;
    end;
end;

local function updateMemberName(p42, p43) -- Line: 204
    -- upvalues: Util (copy), u1 (copy)
    p42.name = Util.getUserInfo(p43).Username;
    u1.networkMember(p43);
end;

function u1.roleIdSort(p44: string, p45: string) -- Line: 210
    -- upvalues: Defaults (copy)
    local v46 = Defaults.roles[p44];
    local v47 = Defaults.roles[p45];

    return (not v46 and 0 or v46._rank) > (not v47 and 0 or v47._rank);
end;

function u1.roleIdSortAscending(p48: string, p49: string) -- Line: 218
    -- upvalues: Defaults (copy)
    return Defaults.roles[p48]._rank < Defaults.roles[p49]._rank;
end;

function u1.userRoleAdd(p50: number, p51: string, p52: boolean?) -- Line: 223
    -- upvalues: Defaults (copy), updateMemberName (copy), u1 (copy), saveMember (copy), Hook (copy)
    if p51 == "everyone" then
        return false;
    end;

    local v53 = tostring(p50);
    local v54 = Defaults.members[v53];
    local v55 = false;

    if v54 then
        if not table.find(v54.roles, p51) then
            table.insert(v54.roles, p51);
            table.sort(v54.roles, u1.roleIdSort);
            v55 = true;
        end;

        if p52 and not table.find(v54.persist, p51) then
            table.insert(v54.persist, p51);
            table.sort(v54.persist, u1.roleIdSort);
            v55 = true;
        end;
    else
        v54 = {
            name = nil,
            roles = { p51 }
        };
        local v56 = {};
        local v57;

        if p52 then
            v57 = p51;
        else
            v57 = nil;
        end;

        v56[1] = v57;
        v54.persist = v56;
        Defaults.members[v53] = v54;
        task.spawn(updateMemberName, v54, p50);
        v55 = true;
    end;

    if v55 then
        if p52 then
            task.spawn(saveMember, v53, p50);
        end;

        Hook.roleAdded:Fire(p50, p51);

        if not v54.name then
            task.spawn(updateMemberName, v54, p50);

            return v55;
        end;

        u1.networkMember(p50);
    end;

    return v55;
end;

function u1.userRoleRemove(p58: number, p59: string) -- Line: 270
    -- upvalues: Defaults (copy), saveMember (copy), Hook (copy), u1 (copy)
    local v60 = tostring(p58);
    local v61 = Defaults.members[v60];
    local v62 = false;
    local v63 = false;

    if v61 then
        local table_find_ret = table.find(v61.roles, p59);

        if table_find_ret then
            table.remove(v61.roles, table_find_ret);
            v62 = true;
        end;

        local table_find_ret2 = table.find(v61.persist, p59);

        if table_find_ret2 then
            table.remove(v61.persist, table_find_ret2);
            v62 = true;
            v63 = true;
        end;
    end;

    if v62 then
        if #v61.roles == 0 then
            Defaults.members[v60] = nil;
        end;

        if v63 then
            if #v61.persist == 0 then
                Defaults.Sync.members[v60] = Defaults.REMOVE;
            else
                task.spawn(saveMember, v60, p58);
            end;
        end;

        Hook.roleRemoved:Fire(p58, p59);
        u1.networkMember(p58);
    end;

    return v62;
end;

local u64 = {};

function u1.userAsyncRoles(u65: number, p66: boolean?) -- Line: 309
    -- upvalues: u64 (copy), Defaults (copy), Util (copy), u1 (copy), Players (copy)
    local v67 = u64[u65];

    if v67 and not p66 then
        return;
    end;

    u64[u65] = true;

    if next(Defaults.async.group) then
        local v68, v69 = Util.Retry(function() -- Line: 317
            -- upvalues: Util (ref), u65 (copy)
            return Util.Service.Group:GetGroupsAsync(u65);
        end);

        if v68 then
            for _, v in v69 do
                local v70 = Defaults.async.group[v.Id];

                if v70 then
                    local v71 = v;

                    for _, v2 in v70 do
                        if v71.Rank == v2.rank or not v2.exactRank and v71.Rank >= v2.rank then
                            for _, v3 in v2.roles do
                                u1.userRoleAdd(u65, v3);
                            end;
                        end;
                    end;
                end;
            end;
        else
            warn(v69);
        end;
    end;

    if v67 then
        return;
    end;

    for i, v in Defaults.async.gamepass do
        local v72, v73 = Util.Retry(function() -- Line: 343
            -- upvalues: Util (ref), u65 (copy), i (copy)
            return Util.Service.Marketplace:UserOwnsGamePassAsync(u65, i);
        end);

        if v72 and v73 then
            for _, v2 in v do
                u1.userRoleAdd(u65, v2);
            end;
        elseif not v72 then
            warn(v73);
        end;
    end;

    local PlayerByUserId = Players:GetPlayerByUserId(u65);

    if not PlayerByUserId then
        return;
    end;

    for i, v in Defaults.async.asset do
        local v74, v75 = Util.Retry(function() -- Line: 361
            -- upvalues: Util (ref), PlayerByUserId (copy), i (copy)
            return Util.Service.Marketplace:PlayerOwnsAssetAsync(PlayerByUserId, i);
        end);

        if v74 and v75 then
            for _, v2 in v do
                u1.userRoleAdd(u65, v2);
            end;
        elseif not v74 then
            warn(v75);
        end;
    end;

    for i, v in Defaults.async.subscription do
        local v76, v77 = Util.Retry(function() -- Line: 374
            -- upvalues: Util (ref), PlayerByUserId (copy), i (copy)
            return Util.Service.Marketplace:GetUserSubscriptionStatusAsync(PlayerByUserId, i);
        end);

        if v76 and v77.IsSubscribed then
            for _, v2 in v do
                u1.userRoleAdd(u65, v2);
            end;
        elseif not v76 then
            warn(v77);
        end;
    end;
end;

function u1.roleCanUseArgument(p78: string, p79: any) -- Line: 390
    -- upvalues: Defaults (copy)
    local v80 = Defaults.roles[p78];

    if not v80 then
        warn((`undefined role "{p78}"`));

        return false;
    end;

    if v80.permissions.admin then
        return true;
    end;

    if p79.permissions then
        for i, v in p79.permissions do
            if v80.permissions[i] ~= v then
                return false;
            end;
        end;
    end;

    return true;
end;

function u1.roleCanUseCommand(p81: string, p82: any) -- Line: 413
    -- upvalues: Defaults (copy), Registry (copy)
    local v83 = Defaults.roles[p81];

    if not v83 then
        warn((`undefined role "{p81}"`));

        return false;
    end;

    local v84;

    if type(p82) == "string" then
        v84 = Registry.commands[string.lower(p82)];
    else
        v84 = p82;
    end;

    if type(v84) ~= "table" then
        warn(`Invalid command type for {tostring(p82)}: Expected table or string got {typeof(v84)}`, 2);

        return false;
    end;

    if v83.permissions and v83.permissions.admin then
        return true;
    end;

    if v83.commands then
        local v85 = v83.commands[v84.name];

        if v85 ~= nil then
            return v85;
        end;

        if v84.aliases then
            for _, v in v84.aliases do
                local v86 = v83.commands[v];

                if v86 ~= nil then
                    return v86;
                end;
            end;
        end;
    end;

    if v84.permissions then
        for i, v in v84.permissions do
            if v83.permissions[i] ~= v then
                return false;
            end;
        end;
    end;

    return v84 and (v83.groups and (v84.group and table.find(v83.groups, string.lower(v84.group)))) and true or false;
end;

function u1.hasArgument(p87: number, p88: any) -- Line: 464
    -- upvalues: Defaults (copy), u1 (copy)
    if p87 == Defaults.creatorId or u1.roleCanUseArgument("everyone", p88) then
        return true;
    end;

    local v89 = Defaults.members[tostring(p87)];

    if v89 then
        for _, v in v89.roles do
            if u1.roleCanUseArgument(v, p88) then
                return true;
            end;
        end;
    end;

    if Defaults.settings.freeAdmin then
        for _, v in Defaults.settings.freeAdmin do
            if u1.roleCanUseArgument(v, p88) then
                return true;
            end;
        end;
    end;

    return false;
end;

function u1.hasCommand(p90: number, p91: any) -- Line: 487
    -- upvalues: Defaults (copy), u1 (copy)
    if p90 == Defaults.creatorId then
        return (1 / 0);
    end;

    local v92 = Defaults.members[tostring(p90)];

    if v92 then
        for _, v in v92.roles do
            if u1.roleCanUseCommand(v, p91) then
                return Defaults.roles[v]._rank;
            end;
        end;
    end;

    if Defaults.settings.freeAdmin then
        for _, v in Defaults.settings.freeAdmin do
            if u1.roleCanUseCommand(v, p91) then
                return Defaults.roles[v]._rank;
            end;
        end;
    end;

    return u1.roleCanUseCommand("everyone", p91) and 0 or false;
end;

function u1.hasPermission(p93: number, p94: string) -- Line: 513
    -- upvalues: Defaults (copy)
    if p93 == Defaults.creatorId or (Defaults.roles.everyone.permissions.admin or Defaults.roles.everyone.permissions[p94]) then
        return true;
    end;

    local v95 = Defaults.members[tostring(p93)];

    if v95 then
        for _, v in v95.roles do
            local v96 = Defaults.roles[v];

            if v96 and (v96.permissions.admin or v96.permissions[p94]) then
                return true;
            end;
        end;
    end;

    if Defaults.settings.freeAdmin then
        for _, v in Defaults.settings.freeAdmin do
            local v97 = Defaults.roles[v];

            if v97 and (v97.permissions.admin or v97.permissions[p94]) then
                return true;
            end;
        end;
    end;

    return false;
end;

function u1.getRank(p98: number) -- Line: 542
    -- upvalues: Defaults (copy)
    if p98 == Defaults.creatorId then
        return (1 / 0), Defaults.roles.creator;
    end;

    local v99 = Defaults.members[tostring(p98)];
    local v100 = 0;
    local everyone = Defaults.roles.everyone;

    if v99 then
        for _, v in v99.roles do
            local v101 = Defaults.roles[v];

            if v101 and v100 < v101._rank then
                v100 = v101._rank;
                everyone = v101;
            end;
        end;
    end;

    if Defaults.settings.freeAdmin then
        for _, v in Defaults.settings.freeAdmin do
            local v102 = Defaults.roles[v];

            if v102 and v100 < v102._rank then
                v100 = v102._rank;
                everyone = v102;
            end;
        end;
    end;

    return v100, everyone;
end;

function u1.getRoleFromRank(p103: number) -- Line: 569
    -- upvalues: Defaults (copy)
    local creator = Defaults.roles.creator;

    for _, v in Defaults.roles do
        if v._rank == p103 then
            return v;
        end;

        if p103 <= v._rank and (not creator or v._rank < creator._rank) then
            creator = v;
        end;
    end;

    return creator;
end;

function u1.targetUserArgument(p104: any, p105: number, p106: any) -- Line: 583
    -- upvalues: Defaults (copy), u1 (copy), Players (copy)
    local from = p104.command.from;
    local limits = p104.command.fromRole.limits;
    local targetLimits = p104._K.Data.targetLimits;
    targetLimits[from] = targetLimits[from] or 0;

    if limits and targetLimits[from] > (limits.targets or (1 / 0)) then
        return nil, `Can only target {limits.targets} user{limits.targets == 1 and "" or "s"}`;
    end;

    targetLimits[from] = targetLimits[from] + 1;

    if p105 == from then
        if p104.definition.ignoreSelf then
            return nil, "Can\'t target yourself";
        end;

        return p106;
    end;

    if from == Defaults.creatorId or u1.hasPermission(from, "admin") then
        return p106;
    end;

    if u1.hasPermission(from, "targetOthers") ~= true then
        return nil, "Can only target yourself";
    end;

    if not (p104.definition.lowerRank and (not p104.definition.shouldRequest or p104._K.Data.settings.commandRequests == false)) then
        return p106;
    end;

    local PlayerByUserId = Players:GetPlayerByUserId(p105);

    if PlayerByUserId and PlayerByUserId:GetAttribute("_KRolesLoaded") ~= true then
        return nil, "Can\'t target loading user";
    end;

    local Rank = u1.getRank(p105);
    local v107;

    if p104.command.rank == 0 then
        v107 = p104.command.fromRank;
    else
        v107 = p104.command.rank;
    end;

    if Rank < v107 then
        return p106;
    end;

    return nil, "Can only target lower ranks";
end;

function u1.hasRestrictedRole(p108: number) -- Line: 622
    -- upvalues: Defaults (copy)
    local v109 = Defaults.members[tostring(p108)];

    if v109 and v109.roles then
        for _, v in v109.roles do
            local v110 = Defaults.roles[v];

            if v110 and (v ~= "vip" or not Defaults.settings.vip) and not (type(v110.assets) == "table" and next(v110.assets) or (type(v110.gamepasses) == "table" and next(v110.gamepasses) or type(v110.subscriptions) == "table" and next(v110.subscriptions))) then
                local v111 = v;
                local v112 = nil;

                for _, v2 in Defaults.settings.freeAdmin do
                    if v111 == v2 then
                        v112 = true;
                        break;
                    end;
                end;

                if not v112 then
                    return true;
                end;
            end;
        end;
    end;

    return false;
end;

return u1;