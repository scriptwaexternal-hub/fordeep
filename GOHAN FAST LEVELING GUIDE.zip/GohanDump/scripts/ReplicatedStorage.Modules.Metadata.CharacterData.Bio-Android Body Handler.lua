-- Decompiled with Potassium's decompiler.

game:GetService("Players");
local ReplicatedStorage = game:GetService("ReplicatedStorage");
game:GetService("ServerScriptService");
local Debris = game:GetService("Debris");
game:GetService("Chat");
local Modules = ReplicatedStorage:WaitForChild("Modules");
local Metadata = Modules.Metadata;
local _ = Modules.Shared;
local _ = Modules.Utility;
ReplicatedStorage:WaitForChild("Remotes");
local u1 = ReplicatedStorage.Assets.RaceParts["Bio-Android"];
local GlobalFunctions = require(Modules.GlobalFunctions);
local FaceHandler = require(Metadata.CharacterData.FaceHandler);
local u2 = {};

function Retrieve_Model(p3)
    -- upvalues: u1 (copy)
    for _, descendant in pairs(u1:GetDescendants()) do
        if descendant:IsA("Model") and descendant.Name == p3 then
            return descendant:Clone();
        end;
    end;
end;

function u2.GiveBody(p4: userdata, p5: any, p6: any) -- Line: 41
    -- upvalues: GlobalFunctions (copy), FaceHandler (copy)
    local v7 = p6 and (p6.Form or "Imperfect Form") or "Imperfect Form";
    local SkinColor = p5.CharacterData.SkinColor;
    local SecondarySkinColor = p5.CharacterData.SecondarySkinColor;
    local v8 = p6 and p6.FormTime or 0.5;
    local _ = p5 and (p5.Accessories and p5.Accessories.Arm);

    if p5 and p5.CharacterData then
        local _ = p5.CharacterData.Height;
    end;

    local v9 = Retrieve_Model(v7);

    if not v9 then
        warn("No Model Found For CELL", p4.Name);

        return;
    end;

    v9:ScaleTo(p4:GetScale() + 0.05);

    for _, descendant in pairs(v9:GetDescendants()) do
        if descendant.Name == "Colorable" and (descendant:IsA("Part") or descendant:IsA("MeshPart")) then
            descendant.Color = Color3.fromRGB(SkinColor.Red, SkinColor.Green, SkinColor.Blue);
            local SurfaceAppearance = descendant:FindFirstChild("SurfaceAppearance");

            if SurfaceAppearance then
                SurfaceAppearance.Color = Color3.fromRGB(SkinColor.Red, SkinColor.Green, SkinColor.Blue);
            end;
        elseif descendant.Name == "Second Color" and (descendant:IsA("Part") or descendant:IsA("MeshPart")) then
            descendant.Color = Color3.fromRGB(SecondarySkinColor.Red, SecondarySkinColor.Green, SecondarySkinColor.Blue);
            local SurfaceAppearance = descendant:FindFirstChild("SurfaceAppearance");

            if SurfaceAppearance then
                SurfaceAppearance.Color = descendant.Color;
            end;
        end;
    end;

    for _, child in pairs(v9:GetChildren()) do
        local v10 = p4:FindFirstChild(child.Name);

        if not (v10 and (v10.Transparency == 1 and v10.Name == "Left Arm")) then
            for _, child2 in pairs(child:GetChildren()) do
                local Attachment = child2:FindFirstChild("Attachment");

                if v10 and Attachment then
                    local Size = child2.Size;
                    child2.Size = Vector3.new(0, 0, 0);
                    local v11 = child2:Clone();
                    v11.Name = "Bio-Armor";
                    require(game:GetService("ReplicatedStorage").Modules.Metadata.CharacterData.ClothesHandler).AttachCosmetic(p4, v11);
                    local Weld = Instance.new("Weld");
                    Weld.Parent = v11;
                    Weld.Part0 = v11;
                    Weld.Part1 = v10;
                    Weld.C0 = Attachment.CFrame;
                    GlobalFunctions.Tween({
                        Instance = v11,
                        Duration = v8
                    }, {
                        Size = Size
                    });
                end;
            end;
        end;
    end;

    FaceHandler.GiveBioFace({
        Face = v7 == "Imperfect Form" and 1 or (v7 == "Semi Perfect Form" and 2 or (v7 == "Perfect Form" and 3 or false)),
        MouthType = p5.CharacterData.MouthType,
        NoseType = p5.CharacterData.NoseType
    }, p4);
end;

function u2.RemoveBody(p12) -- Line: 140
    -- upvalues: GlobalFunctions (copy), Debris (copy)
    for _, descendant in pairs(p12:GetDescendants()) do
        if descendant.Name == "Bio-Armor" then
            GlobalFunctions.Tween({
                Duration = 2,
                Instance = descendant
            }, {
                Size = Vector3.new(0, 0, 0)
            });
            Debris:AddItem(descendant, 1);
        end;
    end;
end;

function u2.Transform(p13, p14, p15) -- Line: 157
    -- upvalues: GlobalFunctions (copy), u2 (copy)
    GlobalFunctions.Highlight(p13, {
        Duration = p15.Duration or 3
    });
    u2.RemoveBody(p13);
    u2.GiveBody(p13, p14, p15);
end;

return u2;