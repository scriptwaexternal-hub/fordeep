-- Decompiled with Potassium's decompiler.

local Players = game:GetService("Players");
local ReplicatedStorage = game:GetService("ReplicatedStorage");
local Remotes = ReplicatedStorage:WaitForChild("Remotes");
local u1 = ReplicatedStorage.Assets.Gui.Skills.RaceSkills.Demon["Majin Mark"];
local MajinInviteRemote = Remotes.MajinInviteRemote;
local LocalPlayer = Players.LocalPlayer;
local u2 = { "K.O", "Enrage", "Drain", "Punish", "Heal", "Summon", "Release" };

local function getPopupGui() -- Line: 40
    -- upvalues: LocalPlayer (copy)
    return LocalPlayer.PlayerGui:FindFirstChild("PopupGui") or LocalPlayer.PlayerGui:WaitForChild("PopupGui", 5);
end;

function MajinInviteRemote.OnClientInvoke(p3) -- Line: 111
    -- upvalues: LocalPlayer (copy), u1 (copy)
    local Inviter = p3.Inviter;
    local v4 = LocalPlayer.PlayerGui:FindFirstChild("PopupGui") or LocalPlayer.PlayerGui:WaitForChild("PopupGui", 5);

    if not v4 then
        return false;
    end;

    local v5 = u1.TextPrompt:Clone();
    v5.Parent = v4;
    v5.TimeLabel.Text = 15;
    v5.Text = "Accept <font color=\'rgb(255, 55, 52)\'>" .. tostring(Inviter) .. "</font> as your Master?";
    local u6 = nil;
    local v7 = v5.No.MouseButton1Up:Connect(function() -- Line: 122
        -- upvalues: u6 (ref)
        u6 = false;
    end);
    local v8 = v5.Yes.MouseButton1Up:Connect(function() -- Line: 123
        -- upvalues: u6 (ref)
        u6 = true;
    end);
    local v9 = 0;

    while u6 == nil and v9 < 15 do
        task.wait(1);
        v9 = v9 + 1;
        v5.TimeLabel.Text = 15 - v9;
    end;

    v7:Disconnect();
    v8:Disconnect();
    v5:Destroy();

    return u6 == true;
end;

return {
    ["Majin Mark"] = function(p10) -- Line: 47
        -- upvalues: LocalPlayer (copy), u1 (copy), Players (copy), u2 (copy), MajinInviteRemote (copy)
        local VictimList = p10.VictimList;

        if not VictimList then
            return;
        end;

        local v11 = LocalPlayer.PlayerGui:FindFirstChild("PopupGui") or LocalPlayer.PlayerGui:WaitForChild("PopupGui", 5);

        if not v11 then
            return;
        end;

        local u12 = u1.MainMarkControlFrame:Clone();
        u12.Parent = v11;
        local MarkControlList = u12.MarkControlList;
        u12.Exit.MouseButton1Up:Once(function() -- Line: 57
            -- upvalues: u12 (copy)
            u12:Destroy();
        end);
        local v13 = {};

        for _, v in ipairs(Players:GetPlayers()) do
            v13[v.UserId] = true;
        end;

        for _, v in pairs(VictimList) do
            if v13[v.ID] then
                local u14 = u1.MarkPlayerFrame:Clone();
                u14.Parent = MarkControlList;
                u14.PlayerName.Text = v.VictimName;
                local v15 = u14["Button Holder"];
                local u16 = v;

                for _, v2 in ipairs(u2) do
                    local u17 = u1.MarkButtonTemplate:Clone();
                    u17.Parent = v15;
                    u17.Text = v2;

                    if v2 == "Release" then
                        u17.BackgroundColor3 = Color3.fromRGB(255, 155, 155);
                    end;

                    local u18 = false;
                    u17.MouseButton1Up:Connect(function() -- Line: 83
                        -- upvalues: u18 (ref), u17 (copy), MajinInviteRemote (ref), v2 (copy), u16 (copy), u14 (copy)
                        if u18 then
                            return;
                        end;

                        u18 = true;
                        u17.CDFrame.Visible = true;
                        MajinInviteRemote:InvokeServer({
                            Ability = v2,
                            VictimID = u16.ID
                        });

                        if v2 == "Release" then
                            u14:Destroy();

                            return;
                        end;

                        task.delay(5, function() -- Line: 98
                            -- upvalues: u18 (ref), u17 (ref)
                            u18 = false;

                            if u17.Parent then
                                u17.CDFrame.Visible = false;
                            end;
                        end);
                    end);
                end;
            end;
        end;
    end
};