-- Decompiled with Potassium's decompiler.

local Debris = game:GetService("Debris");
local ReplicatedStorage = game:GetService("ReplicatedStorage");
local Modules = ReplicatedStorage:WaitForChild("Modules");
local GlobalFunctions = require(Modules.GlobalFunctions);
local SoundManager = require(Modules.Shared.SoundManager);
local Particles = ReplicatedStorage.Assets.Effects.Particles;

return {
    Fire = function(p1) -- Line: 21
        -- upvalues: GlobalFunctions (copy), Particles (copy), Debris (copy), SoundManager (copy)
        local Victim = p1.Victim;

        if not Victim then
            return;
        end;

        local RootAndHumanoid = GlobalFunctions.GetRootAndHumanoid(Victim);

        if not RootAndHumanoid then
            return;
        end;

        local v2 = Particles["Heal Effect"].HealEffect:Clone();
        v2.Parent = RootAndHumanoid;
        Debris:AddItem(v2, 2);
        SoundManager.AddSound("Namekian Heal", {
            Parent = RootAndHumanoid
        }, "Client");

        for _, child in ipairs(v2:GetChildren()) do
            if child:IsA("ParticleEmitter") then
                child:Emit(1);
            end;
        end;

        for _, child in ipairs(Victim:GetChildren()) do
            if child:IsA("Part") then
                local v3 = Particles["Heal Aura"].Aura:Clone();
                v3.Parent = child;
                v3:Emit(10);
                Debris:AddItem(v3, 2);
            end;
        end;
    end
};