-- Decompiled with Potassium's decompiler.

local Parent = require(script.Parent.Parent);
local UI = require(script.Parent:WaitForChild("UI"));

return function(u1: number?, p2: string?, p3: string?, p4: boolean?) -- Line: 4
    -- upvalues: UI (copy), Parent (copy)
    local v5 = u1 == "_K";
    local u6;

    if type(u1) == "string" then
        if p2 ~= nil or u1 == "_K" then
            u1 = p2;
        end;

        u6 = nil;
    else
        u6 = u1;
        u1 = p2;
    end;

    local v7 = u1 or "";
    local v8, v9;

    if u6 then
        v7 = "Loading...";
        v8 = "Unknown";
        v9 = "?";
    else
        v8 = nil;
        v9 = nil;
    end;

    local v10;

    if p3 or (v5 or tonumber(u6)) then
        if u6 then
            v10 = UI.new("ImageLabel")({
                Name = "Icon",
                BackgroundTransparency = UI.Theme.TransparencyHeavy,
                BackgroundColor3 = UI.Theme.PrimaryText,

                Size = function() -- Line: 35, Name: Size
                    -- upvalues: UI (ref)
                    return UDim2.fromOffset(UI.Theme.FontSizeDouble(), UI.Theme.FontSizeDouble());
                end,

                Image = p3 or (not u6 and "rbxassetid://10650688076" or `rbxthumb://type=AvatarHeadShot&id={u6}&w=48&h=48`),
                UI.new("UICorner")({
                    CornerRadius = UI.Theme.CornerPadded
                }),
                UI.new("Stroke")({})
            });
        else
            v10 = UI.new("Frame")({
                BackgroundTransparency = 1,

                Size = function() -- Line: 50, Name: Size
                    -- upvalues: UI (ref)
                    return UDim2.fromOffset(UI.Theme.FontSizeLarger(), UI.Theme.FontSizeLarger());
                end,

                UI.new("ImageLabel")({
                    Name = "Icon",
                    BackgroundTransparency = 1,
                    Image = "rbxassetid://71961243872230",
                    AnchorPoint = Vector2.new(0.5, 0.5),
                    Position = UDim2.fromScale(0.5, 0.5),

                    Size = function() -- Line: 58, Name: Size
                        -- upvalues: UI (ref)
                        return UDim2.fromOffset(UI.Theme.FontSize(), UI.Theme.FontSize());
                    end
                })
            });
        end;
    else
        v10 = nil;
    end;

    local TextLabel = UI.new("TextLabel");
    local v11 = {
        AutoLocalize = false,
        Name = "From",
        BackgroundTransparency = 1,
        TextXAlignment = "Left",
        RichText = true,
        TextColor3 = UI.Theme.PrimaryText,
        TextStrokeColor3 = UI.Theme.Primary,
        TextStrokeTransparency = UI.Theme.TextStrokeTransparency,
        Text = v7
    };
    local v12;

    if u6 then
        v12 = UI.Theme.FontSizeLarge;
    else
        v12 = UI.Theme.FontSizeLarger;
    end;

    v11.TextSize = v12;
    v11.FontFace = UI.Theme.FontHeavy;
    v11.AutomaticSize = Enum.AutomaticSize.XY;
    local u13 = TextLabel(v11);
    local u14 = UI.new("TextLabel")({
        AutoLocalize = false,
        Name = "FromBottom",
        BackgroundTransparency = 1,
        TextXAlignment = "Left",
        RichText = true,
        TextColor3 = UI.Theme.PrimaryText,
        TextStrokeColor3 = UI.Theme.Primary,
        TextStrokeTransparency = UI.Theme.TextStrokeTransparency,
        Text = `<font transparency="0.5"><b>@{v8}</b></font>`,
        TextSize = UI.Theme.FontSizeSmall,
        FontFace = UI.Theme.Font,
        AutomaticSize = Enum.AutomaticSize.XY,

        Position = function() -- Line: 96, Name: Position
            -- upvalues: UI (ref)
            return UDim2.fromOffset(0, UI.Theme.FontSizeLarge());
        end
    });
    local u15 = UI.state(u13, "AbsoluteSize");
    local u16;

    if (p4 == nil and true or p4) and v9 then
        local TextLabel2 = UI.new("TextLabel");
        local v17 = {
            AutoLocalize = false,
            Name = "Badge",
            BackgroundColor3 = Color3.fromHex("#fff")
        };
        local v18;

        if UI.getLuminance(Color3.fromHex("#fff")) > 0.5 then
            v18 = Color3.new();
        else
            v18 = Color3.new(1, 1, 1);
        end;

        v17.TextColor3 = v18;
        v17.Text = `<b>{string.upper(v9)}</b>`;

        function v17.TextSize() -- Line: 110
            -- upvalues: UI (ref)
            return UI.Theme.FontSizeLarge() - 8;
        end;

        v17.TextXAlignment = "Left";
        v17.FontFace = UI.Theme.FontMono;
        v17.RichText = true;
        v17.AutomaticSize = Enum.AutomaticSize.X;

        function v17.Size() -- Line: 118
            -- upvalues: UI (ref)
            return UDim2.fromOffset(0, UI.Theme.FontSizeLarge());
        end;

        function v17.Position() -- Line: 121
            -- upvalues: u15 (copy)
            return UDim2.fromOffset(u15().X + 4, 0);
        end;

        v17[1], v17[2] = UI.new("UICorner")({
    CornerRadius = UI.Theme.CornerPadded
}), UI.new("UIPadding")({
    PaddingLeft = UDim.new(0, 4),
    PaddingRight = UDim.new(0, 4),
    PaddingTop = UDim.new(0, 4),
    PaddingBottom = UDim.new(0, 4)
});
        u16 = TextLabel2(v17);
    else
        u16 = nil;
    end;

    task.spawn(function() -- Line: 137
        -- upvalues: u6 (ref), u16 (copy), Parent (ref), UI (ref), u13 (copy), u14 (copy), u1 (ref)
        if not u6 then
            return;
        end;

        if u16 then
            local _, v19 = Parent.Auth.getRank(u6);
            u16.BackgroundColor3 = Color3.fromHex(v19.color);
            u16.Text = `<b>{string.upper(not v19 and "Unknown" or v19.name)}</b>`;
            local v20;

            if UI.getLuminance(Color3.fromHex(v19.color or Color3.new(1, 1, 1))) > 0.5 then
                v20 = Color3.new();
            else
                v20 = Color3.new(1, 1, 1);
            end;

            u16.TextColor3 = v20;
        end;

        local UserInfo = Parent.Util.getUserInfo(u6);
        local v21 = `<b>{u1 or UserInfo.DisplayName}</b>`;
        local v22 = `<font transparency="0.5"><b>@{UserInfo.Username}</b></font>`;
        u13.Text = v21;
        u14.Text = v22;
    end);
    local Frame = UI.new("Frame");
    local v23 = {
        Name = "Header",
        Size = UDim2.new(),
        AutomaticSize = Enum.AutomaticSize.XY,
        BackgroundTransparency = 1
    };
    local Frame2 = UI.new("Frame");
    local v24 = {
        Name = "From",
        AutomaticSize = Enum.AutomaticSize.XY,
        BackgroundTransparency = 1,
        ClipsDescendants = true,

        Position = function() -- Line: 170, Name: Position
            -- upvalues: UI (ref)
            return UDim2.fromOffset(UI.Theme.FontSizeDouble() + 4, 0);
        end
    };
    local v25 = UI.new("UIFlexItem")({
        FlexMode = Enum.UIFlexMode.Shrink
    });
    local v26 = UI.new("UIPadding")({
        PaddingLeft = UI.Theme.PaddingStroke,
        PaddingRight = UI.Theme.PaddingStroke,
        PaddingTop = UI.Theme.PaddingStroke,
        PaddingBottom = UI.Theme.PaddingStroke
    });

    if not v8 then
        u14 = nil;
    end;

    if not v9 then
        u16 = nil;
    end;

    v24[1], v24[2], v24[3], v24[4], v24[5] = v25, v26, u13, u14, u16;
    v23[1], v23[2] = v10, Frame2(v24);

    return Frame(v23);
end;