-- Decompiled with Potassium's decompiler.

local ReplicatedStorage = game:GetService("ReplicatedStorage");
local Modules = ReplicatedStorage:WaitForChild("Modules");
local Remotes = ReplicatedStorage:WaitForChild("Remotes");
require(Modules.Metadata.MiscData.TechData.TechData);
local ServerRemote = Remotes.ServerRemote;
local script_Parent = script.Parent;
local u1 = true;
script_Parent.Activated:Connect(function() -- Line: 24
    -- upvalues: u1 (ref), ServerRemote (copy), script_Parent (copy)
    if u1 == false then
        return;
    end;

    u1 = false;
    ServerRemote:FireServer(nil, {
        Module = "TechManager",
        Action = "Needle",
        ActionType = "On",
        Tool = script_Parent
    });
    task.delay(1, function() -- Line: 35
        -- upvalues: u1 (ref)
        u1 = true;
    end);
end);