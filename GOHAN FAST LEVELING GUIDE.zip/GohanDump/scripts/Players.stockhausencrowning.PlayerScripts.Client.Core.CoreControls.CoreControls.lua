-- Decompiled with Potassium's decompiler.

local ReplicatedStorage = game:GetService("ReplicatedStorage");
game:GetService("UserInputService");
game:GetService("Debris");
local Players = game:GetService("Players");
local Modules = ReplicatedStorage:WaitForChild("Modules");
local Remotes = ReplicatedStorage:WaitForChild("Remotes");
local Metadata = Modules.Metadata;
local Shared = Modules.Shared;
local Utility = Modules.Utility;
local Gui = ReplicatedStorage.Assets.Gui;
local LocalPlayer = Players.LocalPlayer;
local ControlData = require(Metadata.ControlData.ControlData);
local EmoteData = require(Metadata.EmoteData.EmoteData);
local GlobalFunctions = require(Modules.GlobalFunctions);
local AnimationManager = require(Shared.AnimationManager);
local GameMessage = require(Utility.GameMessage);
local CinemaManager = require(Shared.CinemaManager);
local ClimbHandler = require(LocalPlayer:FindFirstChild("ClimbHandler", true));
local StateManager = require(ReplicatedStorage.Modules.Metadata.ControlData.StateManager);
require(ReplicatedStorage.Modules.Metadata.MiscData.LocationRules);
local ServerRemote = ReplicatedStorage.Remotes.ServerRemote;
local StatRetrieveRemote = ReplicatedStorage.Remotes.StatRetrieveRemote;
local EmoteRemote = Remotes.EmoteRemote;
local World = workspace:WaitForChild("World");
local Mouse = LocalPlayer:GetMouse();
local FlightControls = ControlData.Controls.FlightControls;
local ClimbControls = ControlData.Controls.ClimbControls;
local CoreControls = ControlData.Controls.CoreControls;
local u1 = false;
local u2 = 0;

local function getCurrentPlanet() -- Line: 66
    -- upvalues: World (copy)
    return World.Map.CurrentPlanet.Planet.Value;
end;

return {
    Meditate = function(p3, p4) -- Line: 76
        -- upvalues: LocalPlayer (copy), StateManager (copy), ServerRemote (copy), CoreControls (copy)
        local v5 = LocalPlayer.Character or LocalPlayer.CharacterAdded:Wait();

        if StateManager.IsInState(v5, "Meditating") then
            ServerRemote:FireServer(nil, {
                Module = "CoreControlHandler",
                Action = p3
            });

            return;
        end;

        if not CoreControls.MeditateEnabled then
            return;
        end;

        if StateManager.IsInState(v5, "Sleeping") or StateManager.IsInState(v5, "Flying") then
            return;
        end;

        if v5:GetAttribute("InUI") then
            return;
        end;

        ServerRemote:FireServer(nil, {
            Module = "CoreControlHandler",
            Action = p3
        });
        CoreControls.MeditateEnabled = false;
        task.delay(CoreControls.MeditateCD, function() -- Line: 96
            -- upvalues: CoreControls (ref)
            CoreControls.MeditateEnabled = true;
        end);
    end,

    Sleep = function(p6, p7) -- Line: 101
        -- upvalues: LocalPlayer (copy), CoreControls (copy), StateManager (copy), ServerRemote (copy)
        local v8 = LocalPlayer.Character or LocalPlayer.CharacterAdded:Wait();

        if not CoreControls.SleepEnabled then
            return;
        end;

        if StateManager.IsInState(v8, "Meditating") or StateManager.IsInState(v8, "Flying") then
            return;
        end;

        ServerRemote:FireServer(nil, {
            Module = "CoreControlHandler",
            Action = p6
        });
        CoreControls.SleepEnabled = false;
        task.delay(CoreControls.MeditateCD, function() -- Line: 110
            -- upvalues: CoreControls (ref)
            CoreControls.SleepEnabled = true;
        end);
    end,

    ["Flight/Climb"] = function(p9, p10) -- Line: 119
        -- upvalues: LocalPlayer (copy), GlobalFunctions (copy), StatRetrieveRemote (copy), StateManager (copy), FlightControls (copy), ServerRemote (copy), ClimbControls (copy), ClimbHandler (copy), u2 (ref), GameMessage (copy)
        local u11 = LocalPlayer.Character or LocalPlayer.CharacterAdded:Wait();
        local RootAndHumanoid = GlobalFunctions.GetRootAndHumanoid(u11);
        local u12 = StatRetrieveRemote:InvokeServer("KiUnlocked");
        local v13 = StatRetrieveRemote:InvokeServer("Ki Fly", "Skill Stat");
        local v14;

        if type(v13) == "table" then
            v14 = v13.Unlocked or false;
        else
            v14 = false;
        end;

        if StateManager.IsInState(u11, "Sleeping") or StateManager.IsInState(u11, "Meditating") then
            return;
        end;

        local function tryFly() -- Line: 132
            -- upvalues: u12 (copy), FlightControls (ref), StateManager (ref), u11 (copy), ServerRemote (ref), RootAndHumanoid (copy)
            if not u12 then
                return;
            end;

            if FlightControls.FlightEnabled == false then
                FlightControls.FlightEnabled = true;
                task.wait(FlightControls.Flight_Tap_Time);
                FlightControls.FlightEnabled = false;

                return;
            end;

            if StateManager.IsInState(u11, "Flying") then
                return;
            end;

            if StateManager.IsInState(u11, "InCombat") then
                return;
            end;

            if u11:GetAttribute("WMATRestricted") == true then
                return;
            end;

            if u11:GetAttribute("RivalMatch") then
                return;
            end;

            if StateManager.IsInState(u11, "GreatApe") or StateManager.IsInState(u11, "BerserkApe") then
                return;
            end;

            if not StateManager.CanPerformAction(u11, "Fly") then
                return;
            end;

            ServerRemote:FireServer("Run", {
                Action = "Terminate"
            });
            ServerRemote:FireServer("Flight", {
                Action = "Execute"
            });
            local FlyAttachment = RootAndHumanoid:FindFirstChild("FlyAttachment");

            if FlyAttachment then
                FlyAttachment:Destroy();
            end;

            local Attachment = Instance.new("Attachment");
            Attachment.Name = "FlyAttachment";
            Attachment.Parent = RootAndHumanoid;
            local LinearVelocity = Instance.new("LinearVelocity");
            LinearVelocity.Name = "FlyVelocity";
            LinearVelocity.Attachment0 = Attachment;
            LinearVelocity.MaxForce = math.max(RootAndHumanoid.AssemblyMass, 1) * 12000;
            local AssemblyLinearVelocity = RootAndHumanoid.AssemblyLinearVelocity;
            LinearVelocity.VectorVelocity = Vector3.new(AssemblyLinearVelocity.X, 0, AssemblyLinearVelocity.Z);
            LinearVelocity.Parent = Attachment;
            task.delay(0.25, function() -- Line: 200
                -- upvalues: LinearVelocity (copy), AssemblyLinearVelocity (copy)
                if LinearVelocity.Parent and LinearVelocity.VectorVelocity == Vector3.new(AssemblyLinearVelocity.X, 0, AssemblyLinearVelocity.Z) then
                    LinearVelocity.VectorVelocity = Vector3.new(0, 0, 0);
                end;
            end);
            task.delay(0.75, function() -- Line: 213
                -- upvalues: Attachment (copy), StateManager (ref), u11 (ref)
                if Attachment.Parent and not StateManager.IsInState(u11, "Flying") then
                    Attachment:Destroy();
                end;
            end);
        end;

        local function tryClimb() -- Line: 220
            -- upvalues: ClimbControls (ref), StateManager (ref), u11 (copy), ClimbHandler (ref)
            if ClimbControls.Climb_Enabled ~= false then
                if StateManager.IsInState(u11, "Climbing") then
                    return;
                end;

                ClimbHandler.Execute({
                    Character = u11
                });

                return;
            end;

            ClimbControls.Climb_Enabled = true;
            task.wait(ClimbControls.Climb_Tap_Time);
            ClimbControls.Climb_Enabled = false;
        end;

        if u12 and v14 and not (StateManager.IsInState(u11, "InCombat") or StateManager.IsInState(u11, "Climbing")) then
            tryFly();

            return;
        end;

        if not (u12 and v14 or (StateManager.IsInState(u11, "InCombat") or (StateManager.IsInState(u11, "Climbing") or os.clock() - u2 <= 6))) then
            u2 = os.clock();

            if u12 then
                GameMessage.SendMessage(LocalPlayer, "You haven\'t learned Ki Flight yet.");
            else
                GameMessage.SendMessage(LocalPlayer, "You must unlock your Ki before you can fly.");
            end;
        end;

        tryClimb();
    end,

    Dive = {
        Execute = function(p15, p16) -- Line: 289
            -- upvalues: LocalPlayer (copy), StateManager (copy), ServerRemote (copy)
            local Character = LocalPlayer.Character;

            if not Character then
                return;
            end;

            if not StateManager.IsInState(Character, "Swimming") then
                return;
            end;

            ServerRemote:FireServer("Dive", {
                Module = "SwimHandler",
                Action = "Execute"
            });
        end,

        Terminate = function(p17, p18) -- Line: 296
            -- upvalues: LocalPlayer (copy), ServerRemote (copy)
            if not LocalPlayer.Character then
                return;
            end;

            ServerRemote:FireServer("Dive", {
                Module = "SwimHandler",
                Action = "Terminate"
            });
        end
    },

    ["Tail Tuck"] = function(p19, p20) -- Line: 307
        -- upvalues: LocalPlayer (copy), ServerRemote (copy)
        if not LocalPlayer.Character then
            return;
        end;

        ServerRemote:FireServer("Tuck", {
            Module = "TailHandler"
        });
    end,

    ["Cinematic Mode"] = function(p21, p22) -- Line: 312
        -- upvalues: CoreControls (copy), CinemaManager (copy), LocalPlayer (copy)
        if not CoreControls.CinemaModeEnabled then
            return;
        end;

        CoreControls.CinemaModeEnabled = false;

        if CoreControls.CinemaOn then
            CoreControls.CinemaOn = false;
            CinemaManager.FadeOut(LocalPlayer);
        else
            CoreControls.CinemaOn = true;
            CinemaManager.FadeIn(LocalPlayer, nil, {
                Strict = true
            });
        end;

        task.delay(CoreControls.CinemaCD, function() -- Line: 326
            -- upvalues: CoreControls (ref)
            CoreControls.CinemaModeEnabled = true;
        end);
    end,

    Emotes = function(p23, p24) -- Line: 331
        -- upvalues: LocalPlayer (copy), GlobalFunctions (copy), u1 (ref), StatRetrieveRemote (copy), Gui (copy), EmoteRemote (copy), AnimationManager (copy), EmoteData (copy), Mouse (copy), StateManager (copy)
        local u25 = LocalPlayer.Character or LocalPlayer.CharacterAdded:Wait();
        local _, _ = GlobalFunctions.GetRootAndHumanoid(u25);

        if not u1 and u25:GetAttribute("InUI") then
            return;
        end;

        local PopupGui = LocalPlayer.PlayerGui.PopupGui;
        local u26 = nil;

        local function activateEmoteWheel() -- Line: 346
            -- upvalues: u25 (copy), StatRetrieveRemote (ref), Gui (ref), PopupGui (copy), EmoteRemote (ref), AnimationManager (ref), GlobalFunctions (ref), u26 (ref), u1 (ref), EmoteData (ref), Mouse (ref), StateManager (ref)
            u25:SetAttribute("InUI", true);

            local function createEmoteWheel() -- Line: 349
                -- upvalues: StatRetrieveRemote (ref), Gui (ref), PopupGui (ref), EmoteRemote (ref), AnimationManager (ref), GlobalFunctions (ref), u26 (ref), u1 (ref), EmoteData (ref), u25 (ref), Mouse (ref), StateManager (ref)
                local u27 = StatRetrieveRemote:InvokeServer("Emotes", "TableStat");
                local Emoticons = u27.Emoticons;
                local u28 = Gui.Emotes.EmoteWheel:Clone();
                u28.Parent = PopupGui;
                local EmoteList = u28.EmoteList;
                local SetFrame = u28.SetFrame;
                local u29 = "";

                for _, v in pairs(Emoticons) do
                    local v30 = Gui.Emotes.EmoteTemplate:Clone();
                    v30.Parent = EmoteList;
                    v30.Name = v;
                    v30.Text = v;
                    v30.MouseButton1Up:Connect(function() -- Line: 368
                        -- upvalues: u29 (ref), v (copy), SetFrame (copy)
                        u29 = v;
                        SetFrame.Visible = true;
                    end);
                end;

                for _, child in pairs(SetFrame:GetChildren()) do
                    if child:IsA("TextButton") then
                        child.MouseButton1Up:Connect(function() -- Line: 378
                            -- upvalues: SetFrame (copy), EmoteRemote (ref), child (copy), u29 (ref), u28 (copy), AnimationManager (ref)
                            SetFrame.Visible = false;
                            EmoteRemote:FireServer({
                                SlotToSet = child.Name,
                                EmoteName = u29
                            });

                            for _, child2 in pairs(u28:GetChildren()) do
                                if child2:IsA("ImageButton") and child2.Name == child.Name then
                                    local EmoteRig = child2.VFrame.WorldModel:FindFirstChild("EmoteRig");

                                    if EmoteRig then
                                        local v31 = EmoteRig:FindFirstChildOfClass("Humanoid");

                                        if v31 then
                                            v31 = v31:FindFirstChildOfClass("Animator");
                                        end;

                                        if v31 then
                                            for _, v in ipairs(v31:GetPlayingAnimationTracks()) do
                                                v:Stop();
                                            end;
                                        end;

                                        AnimationManager.PlayAnimation(EmoteRig, u29, {
                                            Looped = true
                                        });

                                        return;
                                    end;

                                    break;
                                end;
                            end;
                        end);
                    end;
                end;

                for _, child in pairs(u28:GetChildren()) do
                    if child:IsA("ImageButton") then
                        local VFrame = child.VFrame;
                        local WorldModel = Instance.new("WorldModel");
                        WorldModel.Parent = VFrame;
                        local Camera = Instance.new("Camera");
                        Camera.Parent = VFrame;
                        VFrame.CurrentCamera = Camera;
                        local v32 = Gui.Emotes.EmoteRig:Clone();
                        v32.Parent = WorldModel;
                        local RootAndHumanoid = GlobalFunctions.GetRootAndHumanoid(v32);
                        Camera.CFrame = CFrame.lookAt(RootAndHumanoid.CFrame.Position + Vector3.new(0, 0, 7), RootAndHumanoid.Position);
                        local u33 = u27[child.Name] == "" and "Hover" or (u27[child.Name] or "Hover");
                        AnimationManager.PlayAnimation(v32, u33, {
                            Looped = true
                        });
                        child.MouseButton1Up:Connect(function() -- Line: 434
                            -- upvalues: u26 (ref), u1 (ref), u27 (ref), StatRetrieveRemote (ref), u33 (ref), child (copy), EmoteData (ref), AnimationManager (ref), u25 (ref), Mouse (ref), StateManager (ref)
                            u26();
                            u1 = false;
                            u27 = StatRetrieveRemote:InvokeServer("Emotes", "TableStat");
                            u33 = u27[child.Name] ~= "" and u27[child.Name] or "Hover";
                            local v34 = EmoteData.IsWalkable(u33);
                            local v35 = AnimationManager.PlayAnimation(u25, u33);
                            local u36 = true;
                            Mouse.Button1Up:Once(function() -- Line: 455
                                -- upvalues: u36 (ref)
                                u36 = false;
                            end);
                            v35.Ended:Once(function() -- Line: 459
                                -- upvalues: u36 (ref)
                                u36 = false;
                            end);

                            while u36 and not StateManager.IsInState(u25, "Stunned") do
                                if not v34 then
                                    StateManager.SetState(u25, "Emoting");
                                end;

                                task.wait();
                            end;

                            StateManager.ClearState(u25, "Emoting");
                            AnimationManager.StopAnimation(u25, u33);
                        end);
                    end;
                end;
            end;

            local EmoteWheel = PopupGui:FindFirstChild("EmoteWheel");

            if EmoteWheel then
                EmoteWheel.Visible = true;

                return;
            end;

            createEmoteWheel();
        end;

        u26 = function() -- Line: 489, Name: removeEmoteWheel
            -- upvalues: u25 (copy), PopupGui (copy)
            u25:SetAttribute("InUI", nil);
            local EmoteWheel = PopupGui:FindFirstChild("EmoteWheel");

            if EmoteWheel then
                EmoteWheel.Visible = false;
            end;
        end;

        if u1 then
            u26();
        else
            u25:SetAttribute("InUI", true);

            local function v47() -- Line: 349
                -- upvalues: StatRetrieveRemote (ref), Gui (ref), PopupGui (copy), EmoteRemote (ref), AnimationManager (ref), GlobalFunctions (ref), u26 (ref), u1 (ref), EmoteData (ref), u25 (copy), Mouse (ref), StateManager (ref)
                local u37 = StatRetrieveRemote:InvokeServer("Emotes", "TableStat");
                local Emoticons = u37.Emoticons;
                local u38 = Gui.Emotes.EmoteWheel:Clone();
                u38.Parent = PopupGui;
                local EmoteList = u38.EmoteList;
                local SetFrame = u38.SetFrame;
                local u39 = "";

                for _, v in pairs(Emoticons) do
                    local v40 = Gui.Emotes.EmoteTemplate:Clone();
                    v40.Parent = EmoteList;
                    v40.Name = v;
                    v40.Text = v;
                    v40.MouseButton1Up:Connect(function() -- Line: 368
                        -- upvalues: u39 (ref), v (copy), SetFrame (copy)
                        u39 = v;
                        SetFrame.Visible = true;
                    end);
                end;

                for _, child in pairs(SetFrame:GetChildren()) do
                    if child:IsA("TextButton") then
                        child.MouseButton1Up:Connect(function() -- Line: 378
                            -- upvalues: SetFrame (copy), EmoteRemote (ref), child (copy), u39 (ref), u38 (copy), AnimationManager (ref)
                            SetFrame.Visible = false;
                            EmoteRemote:FireServer({
                                SlotToSet = child.Name,
                                EmoteName = u39
                            });

                            for _, child2 in pairs(u38:GetChildren()) do
                                if child2:IsA("ImageButton") and child2.Name == child.Name then
                                    local EmoteRig = child2.VFrame.WorldModel:FindFirstChild("EmoteRig");

                                    if EmoteRig then
                                        local v41 = EmoteRig:FindFirstChildOfClass("Humanoid");

                                        if v41 then
                                            v41 = v41:FindFirstChildOfClass("Animator");
                                        end;

                                        if v41 then
                                            for _, v in ipairs(v41:GetPlayingAnimationTracks()) do
                                                v:Stop();
                                            end;
                                        end;

                                        AnimationManager.PlayAnimation(EmoteRig, u39, {
                                            Looped = true
                                        });

                                        return;
                                    end;

                                    break;
                                end;
                            end;
                        end);
                    end;
                end;

                for _, child in pairs(u38:GetChildren()) do
                    if child:IsA("ImageButton") then
                        local VFrame = child.VFrame;
                        local WorldModel = Instance.new("WorldModel");
                        WorldModel.Parent = VFrame;
                        local Camera = Instance.new("Camera");
                        Camera.Parent = VFrame;
                        VFrame.CurrentCamera = Camera;
                        local v42 = Gui.Emotes.EmoteRig:Clone();
                        v42.Parent = WorldModel;
                        local RootAndHumanoid = GlobalFunctions.GetRootAndHumanoid(v42);
                        Camera.CFrame = CFrame.lookAt(RootAndHumanoid.CFrame.Position + Vector3.new(0, 0, 7), RootAndHumanoid.Position);
                        local u43 = u37[child.Name] == "" and "Hover" or (u37[child.Name] or "Hover");
                        AnimationManager.PlayAnimation(v42, u43, {
                            Looped = true
                        });
                        child.MouseButton1Up:Connect(function() -- Line: 434
                            -- upvalues: u26 (ref), u1 (ref), u37 (ref), StatRetrieveRemote (ref), u43 (ref), child (copy), EmoteData (ref), AnimationManager (ref), u25 (ref), Mouse (ref), StateManager (ref)
                            u26();
                            u1 = false;
                            u37 = StatRetrieveRemote:InvokeServer("Emotes", "TableStat");
                            u43 = u37[child.Name] ~= "" and u37[child.Name] or "Hover";
                            local v44 = EmoteData.IsWalkable(u43);
                            local v45 = AnimationManager.PlayAnimation(u25, u43);
                            local u46 = true;
                            Mouse.Button1Up:Once(function() -- Line: 455
                                -- upvalues: u46 (ref)
                                u46 = false;
                            end);
                            v45.Ended:Once(function() -- Line: 459
                                -- upvalues: u46 (ref)
                                u46 = false;
                            end);

                            while u46 and not StateManager.IsInState(u25, "Stunned") do
                                if not v44 then
                                    StateManager.SetState(u25, "Emoting");
                                end;

                                task.wait();
                            end;

                            StateManager.ClearState(u25, "Emoting");
                            AnimationManager.StopAnimation(u25, u43);
                        end);
                    end;
                end;
            end;

            local EmoteWheel = PopupGui:FindFirstChild("EmoteWheel");

            if EmoteWheel then
                EmoteWheel.Visible = true;
            else
                v47();
            end;
        end;

        u1 = not u1;
    end
};