-- Decompiled with Potassium's decompiler.

local Parent = require(script.Parent.Parent);
local BaseClass = require(script.Parent:WaitForChild("BaseClass"));
local TweenService = game:GetService("TweenService");
local u1 = {
    Icon = "",
    IconRightAlign = false,
    Label = "",
    ActiveSound = true,
    HoverTransparency = 0.75,
    TextScaled = false,
    IconProperties = {},
    LabelProperties = {},
    AutomaticSize = Enum.AutomaticSize.None,
    BackgroundColor3 = Parent.Theme.Secondary,
    BackgroundTransparency = Parent.Theme.TransparencyHeavy,
    FontFace = Parent.Theme.Font,
    TextSize = Parent.Theme.FontSize,
    TextXAlignment = Enum.TextXAlignment.Center,
    TextYAlignment = Enum.TextYAlignment.Center,
    Padding = Parent.Theme.Padding
};
local u2 = {};
u2.__index = u2;
setmetatable(u2, BaseClass);

function u2.new(p3) -- Line: 32
    -- upvalues: u1 (copy), Parent (copy), TweenService (copy), u2 (copy)
    local table_clone_ret = table.clone(u1);
    table_clone_ret.IconProperties = {};
    table_clone_ret.LabelProperties = {};
    Parent.makeStatefulDefaults(table_clone_ret, p3);
    local u4 = Parent.state(false);
    table_clone_ret._hovering = u4;
    local v8 = Parent.compute(function() -- Line: 40
        -- upvalues: table_clone_ret (copy)
        local v5 = table_clone_ret.AutomaticSize();
        local v6 = 1;
        local v7 = 1;

        if v5 == Enum.AutomaticSize.XY then
            v6 = 0;
            v7 = 0;
        elseif v5 == Enum.AutomaticSize.X then
            v6 = 0;
        elseif v5 == Enum.AutomaticSize.Y then
            v7 = 0;
        end;

        return UDim2.fromScale(v6, v7);
    end);
    table_clone_ret._content = Parent.new("Frame")({
        Name = "UIContent",
        AutomaticSize = table_clone_ret.AutomaticSize,
        BackgroundTransparency = 1,
        Size = v8,
        Parent.new("UIListLayout")({
            FillDirection = Enum.FillDirection.Horizontal,
            SortOrder = Enum.SortOrder.LayoutOrder,
            VerticalAlignment = Enum.VerticalAlignment.Center
        }),
        Parent.edit(Parent.new("TextLabel")({
            Name = "Label",
            LayoutOrder = 2,
            AutomaticSize = table_clone_ret.AutomaticSize,
            AutoLocalize = false,
            BackgroundTransparency = 1,
            Size = v8,
            FontFace = table_clone_ret.FontFace,
            RichText = true,

            Text = function() -- Line: 74, Name: Text
                -- upvalues: table_clone_ret (copy)
                return tostring(table_clone_ret.Label);
            end,

            TextSize = table_clone_ret.TextSize,
            TextScaled = table_clone_ret.TextScaled,
            TextColor3 = Parent.Theme.PrimaryText,
            TextStrokeColor3 = Parent.Theme.Primary,
            TextStrokeTransparency = Parent.Theme.TextStrokeTransparency,
            TextTruncate = Enum.TextTruncate.SplitWord,
            TextXAlignment = table_clone_ret.TextXAlignment,
            TextYAlignment = table_clone_ret.TextYAlignment,

            Visible = function() -- Line: 85, Name: Visible
                -- upvalues: table_clone_ret (copy)
                return table_clone_ret.Label() ~= "";
            end,

            Parent.new("UIFlexItem")({
                FlexMode = Enum.UIFlexMode.Fill
            }),
            Parent.new("UIPadding")({
                PaddingLeft = table_clone_ret.Padding,
                PaddingRight = table_clone_ret.Padding
            })
        }), table_clone_ret.LabelProperties._value),
        Parent.new("Frame")({
            Name = "IconFrame",

            LayoutOrder = function() -- Line: 102, Name: LayoutOrder
                -- upvalues: table_clone_ret (copy)
                return table_clone_ret.IconRightAlign() and 9 or -9;
            end,

            BackgroundTransparency = 1,
            Size = UDim2.new(1, 0, 1, 0),
            SizeConstraint = Enum.SizeConstraint.RelativeYY,

            Visible = function() -- Line: 108, Name: Visible
                -- upvalues: table_clone_ret (copy)
                return table_clone_ret.Icon() ~= "";
            end,

            Parent.edit(Parent.new("ImageLabel")({
                Name = "Icon",
                BackgroundTransparency = 1,
                AnchorPoint = Vector2.new(0.5, 0.5),
                Position = UDim2.new(0.5, 0, 0.5, 0),
                Size = UDim2.new(1, 0, 1, 0),
                Image = table_clone_ret.Icon,
                ScaleType = Enum.ScaleType.Fit
            }), table_clone_ret.IconProperties._value)
        })
    });
    local u9 = Parent.new("Frame")({
        Name = "Ripple",
        Active = false,
        AnchorPoint = Vector2.new(0.5, 0),
        BackgroundTransparency = 1,
        BackgroundColor3 = Parent.Theme.Secondary,
        Parent.new("UICorner")({
            CornerRadius = Parent.Theme.CornerPadded
        })
    });
    table_clone_ret._instance = Parent.new("TextButton")({
        AutomaticSize = table_clone_ret.AutomaticSize,
        AutoLocalize = false,
        Name = "Button",
        Active = true,
        AutoButtonColor = false,
        BackgroundColor3 = table_clone_ret.BackgroundColor3,

        BackgroundTransparency = function() -- Line: 150, Name: BackgroundTransparency
            -- upvalues: u4 (copy), table_clone_ret (copy)
            if u4() then
                return table_clone_ret.HoverTransparency();
            end;

            return table_clone_ret.BackgroundTransparency();
        end,

        ClipsDescendants = true,
        Text = "",
        TextTransparency = 1,

        Size = function() -- Line: 156, Name: Size
            -- upvalues: table_clone_ret (copy), Parent (ref)
            local v10 = table_clone_ret.AutomaticSize();

            return UDim2.new((v10 == Enum.AutomaticSize.X or v10 == Enum.AutomaticSize.XY) and 0 or 1, 0, 0, Parent.Theme.FontSize + Parent.Theme.Padding().Offset * 2);
        end,

        Parent.new("UICorner")({
            CornerRadius = Parent.Theme.CornerPadded
        }),
        Parent.new("Stroke")({}),
        table_clone_ret._content,
        u9,

        Activated = function() -- Line: 170, Name: Activated
            -- upvalues: table_clone_ret (copy), Parent (ref)
            if table_clone_ret.ActiveSound._value then
                Parent.Sound.Hover01:Play();
            end;
        end,

        InputBegan = function(p11, p12) -- Line: 175, Name: InputBegan
            -- upvalues: u9 (copy), table_clone_ret (copy), TweenService (ref), Parent (ref)
            if p12 or p11.UserInputType ~= Enum.UserInputType.MouseButton1 and p11.UserInputType ~= Enum.UserInputType.Touch then
                return;
            end;

            local X = p11.Position.X;
            u9.Size = UDim2.new(0, 0, 1, 0);
            u9.Position = UDim2.new(0, X - table_clone_ret._instance.AbsolutePosition.x, 0, 0);
            TweenService:Create(u9, Parent.Theme.TweenOut._value, {
                BackgroundTransparency = 0.9,
                Size = UDim2.new(1, 0, 1, 0),
                Position = UDim2.new(0.5, 0, 0, 0)
            }):Play();
        end,

        InputChanged = function(p13, p14) -- Line: 194, Name: InputChanged
            -- upvalues: Parent (ref), table_clone_ret (copy), u4 (copy)
            if p14 then
                return;
            end;

            if p13.UserInputType == Enum.UserInputType.MouseMovement or p13.UserInputType == Enum.UserInputType.Touch then
                if Parent.sinkInput(p13.Position.X, p13.Position.Y, table_clone_ret._instance) then
                    Parent.deactivateState(u4, "hover");

                    return;
                end;

                Parent.activateState(u4, "hover");
            end;
        end,

        InputEnded = function(p15) -- Line: 209, Name: InputEnded
            -- upvalues: Parent (ref), u4 (copy), TweenService (ref), u9 (copy)
            local v16 = p15.UserInputType == Enum.UserInputType.MouseMovement and true or p15.UserInputType == Enum.UserInputType.Touch;

            if v16 then
                Parent.deactivateState(u4, "hover");
            end;

            if v16 or p15.UserInputType == Enum.UserInputType.MouseButton1 then
                TweenService:Create(u9, Parent.Theme.TweenOut._value, {
                    BackgroundTransparency = 1
                }):Play();
            end;
        end
    });

    return setmetatable(table_clone_ret, u2);
end;

return u2;