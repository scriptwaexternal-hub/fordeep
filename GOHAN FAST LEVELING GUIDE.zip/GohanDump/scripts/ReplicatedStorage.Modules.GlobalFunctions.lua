-- Decompiled with Potassium's decompiler.

local Players = game:GetService("Players");
local TweenService = game:GetService("TweenService");
local ReplicatedStorage = game:GetService("ReplicatedStorage");
local Debris = game:GetService("Debris");
local CollectionService = game:GetService("CollectionService");
local Modules = ReplicatedStorage:WaitForChild("Modules");
local Metadata = Modules.Metadata;
local _ = Modules.Shared;
local Utility = Modules.Utility;
local SkillData = require(Metadata.SkillData.SkillData);
local ReplicationModule = require(Utility.ReplicationModule);
local RankData = require(Metadata.CharacterData.RankData);
local Create = require(Utility.Create);
local GetMouse = ReplicatedStorage.Remotes.GetMouse;
local workspace_World = workspace.World;
local Visuals = workspace_World.Visuals;
local Live = workspace_World.Live;
local u1 = nil;
local u2 = nil;

local function getSpeedManager() -- Line: 45
    -- upvalues: u1 (ref)
    if not u1 then
        local Server = game:GetService("ServerScriptService"):WaitForChild("Server");
        u1 = require(Server.Managers.SpeedManager);
    end;

    return u1;
end;

local function getStateManager() -- Line: 54
    -- upvalues: u2 (ref)
    if not u2 then
        local Server = game:GetService("ServerScriptService"):WaitForChild("Server");
        u2 = require(Server.Managers.ServerStateManager);
    end;

    return u2;
end;

local u8 = {
    GetRootAndHumanoid = function(p3) -- Line: 69, Name: GetRootAndHumanoid
        if p3 then
            return p3:FindFirstChild("HumanoidRootPart"), p3:FindFirstChild("Humanoid");
        end;
    end,

    FindFakeHead = function(p4) -- Line: 75, Name: FindFakeHead
        return p4:FindFirstChild("FakeHead", true);
    end,

    FindCharacter = function(p5: string) -- Line: 79, Name: FindCharacter
        -- upvalues: Live (copy)
        for _, descendant in pairs(Live:GetDescendants()) do
            if descendant:IsA("Model") and (descendant:FindFirstChild("Humanoid") and descendant.Name == p5) then
                return descendant;
            end;
        end;

        return nil;
    end,

    FindCharacterDisabler = function(p6) -- Line: 94, Name: FindCharacterDisabler
        -- upvalues: u2 (ref)
        warn("FindCharacterDisabler is deprecated — use ServerStateManager.IsInCategory(character, \'disabled\')");

        if not p6 then
            return false, nil;
        end;

        if not u2 then
            local Server = game:GetService("ServerScriptService"):WaitForChild("Server");
            u2 = require(Server.Managers.ServerStateManager);
        end;

        local v7 = u2;

        if v7.IsInCategory(p6, "disabled") then
            return true, v7.GetState(p6);
        end;

        return false, nil;
    end
};

function u8.CheckDistance(p9, p10, p11) -- Line: 109
    -- upvalues: u8 (copy)
    local RootAndHumanoid = u8.GetRootAndHumanoid(p9);
    local RootAndHumanoid2 = u8.GetRootAndHumanoid(p10);

    if RootAndHumanoid and RootAndHumanoid2 then
        return (RootAndHumanoid.Position - RootAndHumanoid2.Position).Magnitude <= p11;
    end;

    return false;
end;

function u8.CheckDistanceFlat(p12, p13, p14) -- Line: 133
    -- upvalues: u8 (copy)
    local RootAndHumanoid = u8.GetRootAndHumanoid(p12);
    local RootAndHumanoid2 = u8.GetRootAndHumanoid(p13);

    if not (RootAndHumanoid and RootAndHumanoid2) then
        return false;
    end;

    local v15 = RootAndHumanoid2.Position - RootAndHumanoid.Position;

    return Vector3.new(v15.X, 0, v15.Z).Magnitude <= p14;
end;

function u8.GetAngle(p16, p17) -- Line: 141
    -- upvalues: u8 (copy)
    local RootAndHumanoid = u8.GetRootAndHumanoid(p16);
    local RootAndHumanoid2 = u8.GetRootAndHumanoid(p17);

    if not (RootAndHumanoid and RootAndHumanoid2) then
        return false;
    end;

    local v18 = RootAndHumanoid2.Position - p16.Head.Position;
    local LookVector = RootAndHumanoid.CFrame.LookVector;
    local v19 = v18:Dot(LookVector) / (v18.Magnitude * LookVector.Magnitude);
    local math_acos_ret = math.acos(v19);

    return math.deg(math_acos_ret) <= 35;
end;

function u8.GetClosestCharacterInFront(p20, p21) -- Line: 155
    -- upvalues: Live (copy)
    local v22 = p21 or 0;
    local HumanoidRootPart = p20:FindFirstChild("HumanoidRootPart");

    if not HumanoidRootPart then
        return nil;
    end;

    local Position = HumanoidRootPart.Position;
    local LookVector = HumanoidRootPart.CFrame.LookVector;
    local v23 = (1 / 0);
    local v24 = nil;

    for _, descendant in ipairs(Live:GetDescendants()) do
        if descendant ~= p20 and (descendant:IsA("Model") and descendant:FindFirstChildOfClass("Humanoid")) then
            local HumanoidRootPart2 = descendant:FindFirstChild("HumanoidRootPart");
            local v25 = descendant:FindFirstChildOfClass("Humanoid");

            if HumanoidRootPart2 and (v25 and v25.Health > 0) then
                local v26 = HumanoidRootPart2.Position - Position;

                if v22 <= LookVector:Dot(v26.Unit) then
                    local Magnitude = v26.Magnitude;

                    if Magnitude < v23 then
                        v24 = descendant;
                        v23 = Magnitude;
                    end;
                end;
            end;
        end;
    end;

    return v24;
end;

local function isLiveCharacter(p27) -- Line: 215
    if not p27:IsA("Model") then
        return false;
    end;

    if not p27:FindFirstChild("Humanoid") then
        return false;
    end;

    if p27:FindFirstChild("No Body") then
        return false;
    end;

    return p27:FindFirstChild("HumanoidRootPart") and true or false;
end;

local function lockedTarget(p28, p29, p30) -- Line: 233
    -- upvalues: u8 (copy)
    local LockTarget = p28:FindFirstChild("LockTarget");

    if LockTarget then
        LockTarget = LockTarget.Value;
    end;

    if not LockTarget or LockTarget == p28 then
        return nil;
    end;

    if LockTarget.Parent then
        local v31;

        if LockTarget:IsA("Model") and (LockTarget:FindFirstChild("Humanoid") and not LockTarget:FindFirstChild("No Body")) then
            v31 = LockTarget:FindFirstChild("HumanoidRootPart") and true or false;
        else
            v31 = false;
        end;

        if v31 then
            if LockTarget:FindFirstChild("Humanoid").Health <= 0 then
                return nil;
            end;

            local HumanoidRootPart = p28:FindFirstChild("HumanoidRootPart");
            local HumanoidRootPart2 = LockTarget:FindFirstChild("HumanoidRootPart");

            if not (HumanoidRootPart and HumanoidRootPart2) then
                return nil;
            end;

            if p29 and p29 < (HumanoidRootPart.Position - HumanoidRootPart2.Position).Magnitude then
                return nil;
            end;

            if p30 and not u8.GetAngle(p28, LockTarget) then
                return nil;
            end;

            return LockTarget;
        end;
    end;

    return nil;
end;

local function isDamageable(p32) -- Line: 260
    if not p32:IsA("Model") then
        return false;
    end;

    if p32:FindFirstChild("Humanoid") then
        return p32:FindFirstChild("HumanoidRootPart") and true or false;
    end;

    return false;
end;

function u8.GetNearPlayers(p33, p34) -- Line: 267
    -- upvalues: Players (copy)
    local HumanoidRootPart = p33:FindFirstChild("HumanoidRootPart");

    if not HumanoidRootPart then
        return {};
    end;

    local v35 = {};

    for _, v in ipairs(Players:GetPlayers()) do
        local Character = v.Character;
        local v36;

        if Character then
            v36 = Character:FindFirstChild("HumanoidRootPart");
        else
            v36 = Character;
        end;

        if Character and (v36 and (Character ~= p33 and (HumanoidRootPart.Position - v36.Position).Magnitude <= p34)) then
            v35[#v35 + 1] = v;
        end;
    end;

    return v35;
end;

function u8.GetNearCharacter(p37, p38) -- Line: 285
    -- upvalues: lockedTarget (copy), Live (copy)
    local HumanoidRootPart = p37:FindFirstChild("HumanoidRootPart");

    if not HumanoidRootPart then
        return nil;
    end;

    local v39 = lockedTarget(p37, p38);

    if v39 then
        return v39;
    end;

    local v40 = (1 / 0);
    local v41 = nil;

    for _, descendant in ipairs(Live:GetDescendants()) do
        local v42;

        if descendant:IsA("Model") and (descendant:FindFirstChild("Humanoid") and not descendant:FindFirstChild("No Body")) then
            v42 = descendant:FindFirstChild("HumanoidRootPart") and true or false;
        else
            v42 = false;
        end;

        if v42 and descendant ~= p37 then
            local HumanoidRootPart2 = descendant:FindFirstChild("HumanoidRootPart");

            if HumanoidRootPart2 then
                local Magnitude = (HumanoidRootPart.Position - HumanoidRootPart2.Position).Magnitude;

                if Magnitude <= p38 and Magnitude < v40 then
                    v41 = descendant;
                    v40 = Magnitude;
                end;
            end;
        end;
    end;

    return v41;
end;

function u8.GetNearCharacters(p43, p44) -- Line: 306
    -- upvalues: Live (copy)
    local HumanoidRootPart = p43:FindFirstChild("HumanoidRootPart");

    if not HumanoidRootPart then
        return {};
    end;

    local v45 = {};

    for _, descendant in ipairs(Live:GetDescendants()) do
        local v46;

        if descendant:IsA("Model") and (descendant:FindFirstChild("Humanoid") and not descendant:FindFirstChild("No Body")) then
            v46 = descendant:FindFirstChild("HumanoidRootPart") and true or false;
        else
            v46 = false;
        end;

        if v46 and descendant ~= p43 then
            local HumanoidRootPart2 = descendant:FindFirstChild("HumanoidRootPart");

            if HumanoidRootPart2 and (HumanoidRootPart.Position - HumanoidRootPart2.Position).Magnitude <= p44 then
                v45[#v45 + 1] = descendant;
            end;
        end;
    end;

    return v45;
end;

function u8.GetNearCharacterInAngle(p47, p48, p49) -- Line: 321
    -- upvalues: lockedTarget (copy), Live (copy), u8 (copy)
    local HumanoidRootPart = p47:FindFirstChild("HumanoidRootPart");

    if not HumanoidRootPart then
        return nil;
    end;

    local v50 = lockedTarget(p47, p48, true);

    if v50 then
        return v50;
    end;

    local v51 = (1 / 0);
    local v52 = nil;

    for _, descendant in ipairs(Live:GetDescendants()) do
        local v53;

        if descendant:IsA("Model") and (descendant:FindFirstChild("Humanoid") and not descendant:FindFirstChild("No Body")) then
            v53 = descendant:FindFirstChild("HumanoidRootPart") and true or false;
        else
            v53 = false;
        end;

        if v53 and descendant ~= p47 then
            local HumanoidRootPart2 = descendant:FindFirstChild("HumanoidRootPart");

            if HumanoidRootPart2 then
                local Magnitude = (HumanoidRootPart.Position - HumanoidRootPart2.Position).Magnitude;

                if Magnitude <= p48 and (u8.GetAngle(p47, descendant) and Magnitude < v51) then
                    v52 = descendant;
                    v51 = Magnitude;
                end;
            end;
        end;
    end;

    return v52;
end;

function u8.GetNearCharactersWithIgnoreTag(p54, p55, p56, p57) -- Line: 353
    -- upvalues: Live (copy), CollectionService (copy)
    local HumanoidRootPart = p54:FindFirstChild("HumanoidRootPart");

    if not HumanoidRootPart then
        return {};
    end;

    local v58 = {};

    for _, descendant in ipairs(Live:GetDescendants()) do
        local v59;

        if descendant:IsA("Model") and (descendant:FindFirstChild("Humanoid") and not descendant:FindFirstChild("No Body")) then
            v59 = descendant:FindFirstChild("HumanoidRootPart") and true or false;
        else
            v59 = false;
        end;

        if v59 and (descendant ~= p54 and not (CollectionService:HasTag(descendant, p56) or p57 and p57[descendant])) then
            local HumanoidRootPart2 = descendant:FindFirstChild("HumanoidRootPart");

            if HumanoidRootPart2 then
                local Magnitude = (HumanoidRootPart.Position - HumanoidRootPart2.Position).Magnitude;

                if Magnitude <= p55 then
                    v58[#v58 + 1] = {
                        Character = descendant,
                        Distance = Magnitude
                    };
                end;
            end;
        end;
    end;

    return v58;
end;

function u8.GetNearCharacterWithIgnoreTag(p60, p61, p62, p63) -- Line: 371
    -- upvalues: Live (copy), CollectionService (copy)
    local HumanoidRootPart = p60:FindFirstChild("HumanoidRootPart");

    if not HumanoidRootPart then
        return nil;
    end;

    local v64 = (1 / 0);
    local v65 = nil;

    for _, descendant in ipairs(Live:GetDescendants()) do
        local v66;

        if descendant:IsA("Model") and (descendant:FindFirstChild("Humanoid") and not descendant:FindFirstChild("No Body")) then
            v66 = descendant:FindFirstChild("HumanoidRootPart") and true or false;
        else
            v66 = false;
        end;

        if v66 and (descendant ~= p60 and not (CollectionService:HasTag(descendant, p62) or p63[descendant])) then
            local HumanoidRootPart2 = descendant:FindFirstChild("HumanoidRootPart");

            if HumanoidRootPart2 then
                local Magnitude = (HumanoidRootPart.Position - HumanoidRootPart2.Position).Magnitude;

                if Magnitude <= p61 and Magnitude < v64 then
                    v65 = descendant;
                    v64 = Magnitude;
                end;
            end;
        end;
    end;

    return v65;
end;

function u8.GetCharactersNearPoint(p67, p68, p69, p70) -- Line: 392
    -- upvalues: isDamageable (copy), isLiveCharacter (copy), Live (copy)
    local v71 = p70 and isDamageable or isLiveCharacter;
    local v72 = {};

    for _, descendant in ipairs(Live:GetDescendants()) do
        if v71(descendant) and descendant ~= p67 then
            local HumanoidRootPart = descendant:FindFirstChild("HumanoidRootPart");

            if HumanoidRootPart and (p68 - HumanoidRootPart.Position).Magnitude <= p69 then
                v72[#v72 + 1] = descendant;
            end;
        end;
    end;

    return v72;
end;

function u8.GetAllCharactersNearPoint(p73, p74, p75) -- Line: 405
    -- upvalues: isDamageable (copy), isLiveCharacter (copy), Live (copy)
    local v76 = p75 and isDamageable or isLiveCharacter;
    local v77 = {};

    for _, descendant in ipairs(Live:GetDescendants()) do
        if v76(descendant) then
            local HumanoidRootPart = descendant:FindFirstChild("HumanoidRootPart");

            if HumanoidRootPart and (p73 - HumanoidRootPart.Position).Magnitude <= p74 then
                v77[#v77 + 1] = descendant;
            end;
        end;
    end;

    return v77;
end;

function u8.CastRay(p78, p79, p80, p81) -- Line: 425
    -- upvalues: Visuals (copy), Live (copy)
    local RaycastParams_new_ret = RaycastParams.new();
    RaycastParams_new_ret.FilterType = Enum.RaycastFilterType.Exclude;
    RaycastParams_new_ret.FilterDescendantsInstances = p80 or { Visuals, Live };

    if p81 then
        RaycastParams_new_ret.RespectCanCollide = true;
    end;

    return workspace:Raycast(p78, p79, RaycastParams_new_ret);
end;

function u8.BeamWait(p82) -- Line: 447
    -- upvalues: u2 (ref)
    if not u2 then
        local Server = game:GetService("ServerScriptService"):WaitForChild("Server");
        u2 = require(Server.Managers.ServerStateManager);
    end;

    while u2.IsInState(p82, "ChargingBeam") do
        task.wait();
    end;
end;

function u8.CheckForStun(u83) -- Line: 465
    -- upvalues: u2 (ref)
    if not u2 then
        local Server = game:GetService("ServerScriptService"):WaitForChild("Server");
        u2 = require(Server.Managers.ServerStateManager);
    end;

    local u84 = u2;

    local function isCharging() -- Line: 481
        -- upvalues: u84 (copy), u83 (copy)
        return u84.IsInState(u83, "ChargingBeam") or u84.IsInState(u83, "UsedSkill") or (u83:FindFirstChild("Charging Beam") ~= nil and true or u83:FindFirstChild("UsedSkill") ~= nil);
    end;

    local function isStunned() -- Line: 468
        -- upvalues: u84 (copy), u83 (copy)
        return u84.IsInState(u83, "Stunned") or u84.IsInState(u83, "Knocked") or (u84.IsInState(u83, "KO") or u84.IsInState(u83, "Dead")) or (u84.IsInState(u83, "GettingGripped") or u84.IsInState(u83, "GettingCarried") or u83:FindFirstChild("Stun") ~= nil);
    end;

    while not isStunned() and (u84.IsInState(u83, "ChargingBeam") or (u84.IsInState(u83, "UsedSkill") or (u83:FindFirstChild("Charging Beam") ~= nil or u83:FindFirstChild("UsedSkill") ~= nil))) do
        task.wait();
    end;
end;

function u8.SetSpeedAndJump(p85) -- Line: 502
    -- upvalues: u1 (ref)
    if not u1 then
        local Server = game:GetService("ServerScriptService"):WaitForChild("Server");
        u1 = require(Server.Managers.SpeedManager);
    end;

    u1.Apply(p85);
end;

function u8.FreezeCharacter(p86) -- Line: 510
    -- upvalues: u2 (ref), u1 (ref), u8 (copy)
    if not u2 then
        local Server = game:GetService("ServerScriptService"):WaitForChild("Server");
        u2 = require(Server.Managers.ServerStateManager);
    end;

    if not u1 then
        local Server = game:GetService("ServerScriptService"):WaitForChild("Server");
        u1 = require(Server.Managers.SpeedManager);
    end;

    u2.SetState(p86, "Stuck");
    u1.Lock(p86);
    local _, v87 = u8.GetRootAndHumanoid(p86);

    if v87 then
        v87.AutoRotate = false;
    end;
end;

function u8.UnFreezeCharacter(p88) -- Line: 527
    -- upvalues: u2 (ref), u1 (ref), u8 (copy)
    if not u2 then
        local Server = game:GetService("ServerScriptService"):WaitForChild("Server");
        u2 = require(Server.Managers.ServerStateManager);
    end;

    if not u1 then
        local Server = game:GetService("ServerScriptService"):WaitForChild("Server");
        u1 = require(Server.Managers.SpeedManager);
    end;

    u2.ClearState(p88, "Stuck");
    u1.Apply(p88);
    local _, v89 = u8.GetRootAndHumanoid(p88);

    if v89 then
        v89.AutoRotate = true;
    end;
end;

function u8.AnchorCharacter(p90) -- Line: 543
    for _, child in pairs(p90:GetChildren()) do
        if child:IsA("BasePart") then
            child.Anchored = true;
        end;
    end;
end;

function u8.StopCharacters(p91, p92) -- Line: 555
    -- upvalues: u1 (ref), u8 (copy)
    if not u1 then
        local Server = game:GetService("ServerScriptService"):WaitForChild("Server");
        u1 = require(Server.Managers.SpeedManager);
    end;

    local u93 = u1;

    for _, v in pairs(p91) do
        local _, u94 = u8.GetRootAndHumanoid(v);

        if u94 then
            u93.Lock(v);
            u94.AutoRotate = false;
            task.delay(p92, function() -- Line: 562
                -- upvalues: u93 (copy), v (copy), u94 (copy)
                u93.Apply(v);
                u94.AutoRotate = true;
            end);
        end;
    end;
end;

function u8.Aim_Assist(p95, p96, p97, p98) -- Line: 574
    -- upvalues: Players (copy), SkillData (copy), ReplicationModule (copy)
    local PlayerFromCharacter = Players:GetPlayerFromCharacter(p95);
    local Any = SkillData.GetAny(p96, p97, p98);

    if Any and (Any.AimAssist and PlayerFromCharacter) then
        ReplicationModule.FireOneClient(PlayerFromCharacter, "ClientRemote", {
            Module = "AimAssist",
            Function = "Execution",
            Character = p95
        });
    end;
end;

function u8.SkillWait(p99, p100, p101, p102) -- Line: 592
    -- upvalues: u2 (ref), Create (copy), u8 (copy)
    if not u2 then
        local Server = game:GetService("ServerScriptService"):WaitForChild("Server");
        u2 = require(Server.Managers.ServerStateManager);
    end;

    local v103 = u2;
    local v104 = Create.new(p99, "UsingSkill", p100);
    local v105 = tick();
    local v106;

    if p101 == nil then
        u8.FreezeCharacter(p99);
        v106 = false;
    else
        v106 = false;
    end;

    while tick() - v105 < p100 * 1.3 do
        task.wait();

        if v103.IsInState(p99, "Stunned") then
            v106 = true;
            break;
        end;

        if p102 and p102() then
            break;
        end;
    end;

    v104:Destroy();
    u8.UnFreezeCharacter(p99);

    return v106;
end;

function u8.Count(p107) -- Line: 620
    local v108 = 0;

    for _ in pairs(p107) do
        v108 = v108 + 1;
    end;

    return v108;
end;

function u8.DictionaryCount(p109) -- Line: 630
    local v110 = 0;

    for _ in pairs(p109) do
        v110 = v110 + 1;
    end;

    return v110;
end;

function u8.Shuffle(p111) -- Line: 636
    local table_clone_ret = table.clone(p111);
    local v112 = {};

    while #table_clone_ret > 0 do
        local math_random_ret = math.random(#table_clone_ret);
        v112[#v112 + 1] = table_clone_ret[math_random_ret];
        table.remove(table_clone_ret, math_random_ret);
    end;

    return v112;
end;

function u8.RemoveValue(p113, p114) -- Line: 647
    for _, child in pairs(p113:GetChildren()) do
        if child.Name == p114 then
            child:Destroy();
        end;
    end;
end;

function u8.GetMouse(p115) -- Line: 659
    -- upvalues: Players (copy), GetMouse (copy)
    local PlayerFromCharacter = Players:GetPlayerFromCharacter(p115);

    if PlayerFromCharacter then
        return GetMouse:InvokeClient(PlayerFromCharacter);
    end;

    return nil;
end;

function u8.LevelScale(p116) -- Line: 696
    local v117 = tonumber(p116) or 1;
    local v118 = -(math.clamp(v117, 1, 100) - 1) / 45;

    return ((1 - math.exp(v118)) * 14.057629778551952 + 1) * 0.5;
end;

function u8.LegacyLevelScale(p119) -- Line: 705
    local v120 = tonumber(p119) or 1;
    local v121 = -(math.max(v120, 1) - 1) / 6;

    return ((1 - math.exp(v121)) * 3.1 + 1) * 0.3;
end;

local u122 = {
    F = 1,
    E = 8,
    D = 18,
    C = 28,
    B = 38,
    A = 50,
    S = 58,
    SS = 65
};

function u8.RankToLevel(p123) -- Line: 712
    -- upvalues: u122 (copy)
    return u122[tostring(p123)] or 50;
end;

function u8.HealScale(p124) -- Line: 719
    -- upvalues: Players (copy), u8 (copy)
    if not p124 then
        return 1;
    end;

    local PlayerFromCharacter = Players:GetPlayerFromCharacter(p124);
    local v125 = PlayerFromCharacter and PlayerFromCharacter:FindFirstChild("PlayerStats") or p124:FindFirstChild("PlayerStats");
    local v126;

    if v125 then
        v126 = v125:FindFirstChild("Level", true);
    else
        v126 = v125;
    end;

    if v126 and (type(v126.Value) == "number" and v126.Value > 0) then
        return u8.LevelScale(v126.Value);
    end;

    local Attribute = p124:GetAttribute("NpcLevel");

    if Attribute then
        return u8.LevelScale(Attribute);
    end;

    if v125 then
        v125 = v125:FindFirstChild("Rank", true);
    end;

    if v125 then
        v125 = v125.Value;
    end;

    return u8.LevelScale(u8.RankToLevel(v125));
end;

function u8.getRankValue(p127) -- Line: 733
    -- upvalues: RankData (copy)
    local v128 = RankData[p127];

    if type(v128) == "table" and v128.Value then
        return v128.Value;
    end;

    warn("No rank value for:", p127);

    return 0;
end;

function u8.ComputeMaxHealth(p129, p130) -- Line: 762
    -- upvalues: u8 (copy)
    local RankValue = u8.getRankValue(p129.CharacterData.Rank);
    local v131 = 0;
    local v132 = p129.StatData and p129.StatData.CoreStats;

    if v132 and v132.Durability then
        v131 = (v132.Durability.BaseDurability or 0) + (v132.Durability.EnhancedDurability or 0);
    end;

    if p130 then
        local DurabilityBoost = p130:FindFirstChild("DurabilityBoost", true);

        if DurabilityBoost and type(DurabilityBoost.Value) == "number" then
            v131 = v131 + math.max(DurabilityBoost.Value, 0);
        end;
    end;

    return (v131 * 6 + 465 + 30 * RankValue) * u8.LevelScale(p129.StatData and (p129.StatData.GameLevel and p129.StatData.GameLevel.Level) or 1);
end;

function u8.GetFormDuration(p133, p134, p135) -- Line: 793
    local v136 = p133.BaseTime * (1 + p135 * p133.MasteryScaling);

    if (p135 or 0) >= 100 and p133.MasteredTimeBonus then
        v136 = v136 * p133.MasteredTimeBonus;
    end;

    return v136;
end;

function u8.ResetBoosters(p137) -- Line: 805
    -- upvalues: u1 (ref)
    local v138 = p137.Character or p137.CharacterAdded:Wait();
    local PlayerStats = p137:FindFirstChild("PlayerStats");

    if not PlayerStats then
        return;
    end;

    local CriticalHitChance = PlayerStats:FindFirstChild("CriticalHitChance", true);

    if CriticalHitChance then
        CriticalHitChance.Value = 3;
    end;

    local Boosters = PlayerStats:FindFirstChild("Boosters", true);

    if Boosters then
        for _, child in pairs(Boosters:GetChildren()) do
            child.Value = 0;
        end;
    end;

    local TempStats = PlayerStats:FindFirstChild("TempStats", true);

    if TempStats then
        for _, child in pairs(TempStats:GetChildren()) do
            child.Value = 0;
        end;
    end;

    if not u1 then
        local Server = game:GetService("ServerScriptService"):WaitForChild("Server");
        u1 = require(Server.Managers.SpeedManager);
    end;

    u1.Apply(v138);
end;

function u8.ResetMultipliers(p139) -- Line: 831
    -- upvalues: u1 (ref)
    local PlayerStats = p139:FindFirstChild("PlayerStats");

    if not PlayerStats then
        return;
    end;

    for i, v in pairs({
        DefenseMultiplier = 1,
        StrengthMultiplier = 1,
        SpeedMultiplier = 1,
        KiDmgMultiplier = 1,
        ExpGain = 1,
        StrengthExpGain = 1,
        AgilityExpGain = 1,
        MotivationGain = 1,
        CooldownFactor = 1,
        RegenMultiplier = 1,
        SprintMultiplier = 1,
        AttackSpeedMultiplier = 1
    }) do
        local v140 = PlayerStats:FindFirstChild(i, true);

        if v140 then
            v140.Value = v;
        end;
    end;

    local Character = p139.Character;

    if Character then
        if not u1 then
            local Server = game:GetService("ServerScriptService"):WaitForChild("Server");
            u1 = require(Server.Managers.SpeedManager);
        end;

        u1.Apply(Character);
    end;
end;

function u8.ResetFormData(p141) -- Line: 868
    local PlayerStats = p141:FindFirstChild("PlayerStats");

    if not PlayerStats then
        return;
    end;

    local Form = PlayerStats:FindFirstChild("Form", true);
    local SubForm = PlayerStats:FindFirstChild("SubForm", true);
    local Transformation = PlayerStats:FindFirstChild("Transformation", true);
    local Evolution = PlayerStats:FindFirstChild("Evolution", true);

    if Form then
        Form.Value = "None";
    end;

    if SubForm then
        SubForm.Value = "None";
    end;

    if Transformation then
        Transformation.Value = "Ki Burst";
    end;

    if Evolution then
        Evolution.Value = "None";
    end;
end;

function u8.Tween(p142, p143) -- Line: 892
    -- upvalues: TweenService (copy)
    local TweenInfo_new_ret = TweenInfo.new(p142.Duration or 1, p142.EasingStyle or Enum.EasingStyle.Linear, p142.EasingDirection or Enum.EasingDirection.Out, 0, p142.Reverse or false, 0);
    local v144 = TweenService:Create(p142.Instance, TweenInfo_new_ret, p143);
    v144:Play();

    return v144;
end;

function u8.TransparencyTween(p145) -- Line: 907
    -- upvalues: TweenService (copy)
    local v146 = TweenService:Create(p145.Instance, TweenInfo.new(p145.Duration or 1), {
        Transparency = 1
    });
    v146:Play();

    return v146;
end;

function u8.Highlight(p147, p148) -- Line: 917
    -- upvalues: u8 (copy)
    local u149 = p148.HighlightTime or 0.1;
    local v150 = p148.Duration or 2;
    local v151 = p148.OutlineColor or Color3.fromRGB(255, 255, 255);
    local v152 = p148.FillColor or Color3.fromRGB(255, 255, 255);
    local Highlight = Instance.new("Highlight");
    Highlight.Parent = p147;
    Highlight.OutlineColor = v151;
    Highlight.FillColor = v152;
    Highlight.OutlineTransparency = 0;
    Highlight.FillTransparency = 0;
    u8.Tween({
        Duration = u149,
        Instance = Highlight
    }, {
        FillTransparency = 0,
        OutlineTransparency = 0
    });
    task.delay(v150, function() -- Line: 935
        -- upvalues: u8 (ref), u149 (copy), Highlight (copy)
        u8.Tween({
            Duration = u149,
            Instance = Highlight
        }, {
            FillTransparency = 1,
            OutlineTransparency = 1
        }).Completed:Once(function() -- Line: 940
            -- upvalues: Highlight (ref)
            Highlight:Destroy();
        end);
    end);
end;

function u8.UndodgeableHighlight(p153) -- Line: 946
    -- upvalues: u8 (copy)
    u8.Highlight(p153, {
        HighlightTime = 0.25,
        Duration = 0.25,
        OutlineColor = Color3.fromRGB(255, 100, 100),
        FillColor = Color3.fromRGB(255, 100, 100)
    });
end;

function u8.Visualize_HitBox(p154, p155) -- Line: 955
    -- upvalues: Visuals (copy), u8 (copy), Debris (copy)
    local Part = Instance.new("Part");
    Part.Parent = Visuals;
    Part.CFrame = p154;
    Part.Size = p155;
    Part.Anchored = true;
    Part.CanCollide = false;
    Part.Color = Color3.fromRGB(255, 0, 0);
    Part.Material = Enum.Material.ForceField;
    task.delay(1, function() -- Line: 965
        -- upvalues: u8 (ref), Part (copy), Debris (ref)
        u8.TransparencyTween({
            Duration = 1,
            Instance = Part
        });
        Debris:AddItem(Part, 1);
    end);

    return Part;
end;

function u8.Weightless(p156, p157, p158, p159) -- Line: 976
    for _, descendant in pairs(p156:GetDescendants()) do
        if descendant:IsA("BasePart") then
            if p157 == true then
                if p158 then
                    descendant.Massless = true;
                elseif not descendant.Massless then
                    descendant.Massless = true;
                    task.delay(p159, function() -- Line: 985
                        -- upvalues: descendant (copy)
                        descendant.Massless = false;
                    end);
                end;
            elseif descendant.Parent.Name ~= "Clothing" and descendant.Name ~= "Clothing" then
                descendant.Massless = false;
            end;
        end;
    end;
end;

function u8.FindDestructables(p160) -- Line: 998
    -- upvalues: CollectionService (copy)
    local v161 = {};

    for _, v in pairs(p160) do
        if CollectionService:HasTag(v, "Destructable") then
            v161[#v161 + 1] = v;
        end;
    end;

    return v161;
end;

function u8.FormAuraEnabled(p162) -- Line: 1010
    return not p162 or p162:GetAttribute("FormAura") ~= false;
end;

return u8;