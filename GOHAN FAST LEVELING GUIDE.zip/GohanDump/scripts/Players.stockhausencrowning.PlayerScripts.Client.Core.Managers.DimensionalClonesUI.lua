-- Decompiled with Potassium's decompiler.

local ReplicatedStorage = game:GetService("ReplicatedStorage");
local GuiService = game:GetService("GuiService");
local UserInputService = game:GetService("UserInputService");
local Players = game:GetService("Players");
local Modules = ReplicatedStorage:WaitForChild("Modules");
local KamiCard = require(Modules.Shared.KamiCard);
local SkillRemote = ReplicatedStorage:WaitForChild("Remotes"):WaitForChild("SkillRemote");
local Color3_fromRGB_ret = Color3.fromRGB(28, 28, 30);
local Color3_fromRGB_ret2 = Color3.fromRGB(255, 255, 255);
local Color3_fromRGB_ret3 = Color3.fromRGB(216, 213, 205);
local Color3_fromRGB_ret4 = Color3.fromRGB(88, 214, 106);
local Color3_fromRGB_ret5 = Color3.fromRGB(72, 160, 255);
local Color3_fromRGB_ret6 = Color3.fromRGB(226, 62, 48);
local Color3_fromRGB_ret7 = Color3.fromRGB(0, 0, 0);
local Color3_fromRGB_ret8 = Color3.fromRGB(120, 124, 132);
local u1 = nil;
local u2 = nil;
local u3 = {};
local u4 = nil;
local u5 = nil;
local u6 = {};

local function send(u7, u8) -- Line: 35
    -- upvalues: SkillRemote (copy)
    task.spawn(function() -- Line: 36
        -- upvalues: SkillRemote (ref), u7 (copy), u8 (copy)
        pcall(SkillRemote.InvokeServer, SkillRemote, {
            Action = "CloneCommand",
            Command = u7,
            Index = u8
        });
    end);
end;

local function makeButton(p9, p10, p11, p12, p13) -- Line: 41
    -- upvalues: Color3_fromRGB_ret (copy), Color3_fromRGB_ret2 (copy), Color3_fromRGB_ret7 (copy)
    local TextButton = Instance.new("TextButton");
    TextButton.Name = p10;
    TextButton.LayoutOrder = p12;
    TextButton.Size = UDim2.new(0, 0, 0, 34);
    TextButton.AutomaticSize = Enum.AutomaticSize.X;
    TextButton.BackgroundColor3 = Color3_fromRGB_ret;
    TextButton.BorderSizePixel = 0;
    TextButton.AutoButtonColor = true;
    TextButton.Selectable = true;
    TextButton.Font = Enum.Font.Arcade;
    TextButton.TextSize = 15;
    TextButton.TextColor3 = p11 or Color3_fromRGB_ret2;
    TextButton.Text = p10;
    TextButton.TextStrokeColor3 = Color3_fromRGB_ret7;
    TextButton.TextStrokeTransparency = 0.5;
    TextButton.ZIndex = 5;
    local UIPadding = Instance.new("UIPadding");
    UIPadding.PaddingLeft = UDim.new(0, 12);
    UIPadding.PaddingRight = UDim.new(0, 12);
    UIPadding.Parent = TextButton;
    local UIStroke = Instance.new("UIStroke");
    UIStroke.Color = Color3_fromRGB_ret7;
    UIStroke.Thickness = 1.5;
    UIStroke.Parent = TextButton;
    TextButton.MouseButton1Click:Connect(p13);
    TextButton.Parent = p9;

    return TextButton;
end;

function u6.Hide() -- Line: 68
    -- upvalues: u2 (ref), u4 (ref), u5 (ref), u3 (ref), u1 (ref), GuiService (copy)
    if u2 then
        task.cancel(u2);
        u2 = nil;
    end;

    if u4 then
        task.cancel(u4);
        u4 = nil;
    end;

    if u5 then
        u5:Disconnect();
        u5 = nil;
    end;

    u3 = {};

    if u1 then
        local v14 = u1;
        u1 = nil;

        if GuiService.SelectedObject and GuiService.SelectedObject:IsDescendantOf(v14.Card) then
            GuiService.SelectedObject = nil;
        end;

        v14:Dismiss();
    end;
end;

function u6.Show(p15) -- Line: 83
    -- upvalues: u6 (copy), u1 (ref), KamiCard (copy), makeButton (copy), Color3_fromRGB_ret3 (copy), SkillRemote (copy), Color3_fromRGB_ret4 (copy), u3 (ref), Color3_fromRGB_ret5 (copy), Color3_fromRGB_ret6 (copy), Color3_fromRGB_ret8 (copy), u4 (ref), Players (copy), u5 (ref), UserInputService (copy), GuiService (copy), u2 (ref)
    u6.Hide();
    local v16;

    if p15 then
        v16 = p15.Count;
    else
        v16 = p15;
    end;

    local v17 = tonumber(v16) or 2;
    local math_clamp_ret = math.clamp(v17, 1, 4);

    if p15 then
        p15 = p15.Life;
    end;

    local v18 = tonumber(p15) or 30;
    u1 = KamiCard.new({
        Name = "DimensionalClonesCard",
        Width = 460,
        Height = 104,
        DisplayOrder = 70,
        Portrait = false
    });
    u1:Render({
        Speaker = "",
        Title = "DIMENSIONAL CLONES",
        Objective = "",
        Detail = "",
        Counter = "",
        Button = false,
        Keys = {}
    });
    u1.Title.Size = UDim2.new(1, -36, 0, 28);
    local Frame = Instance.new("Frame");
    Frame.Name = "Commands";
    Frame.BackgroundTransparency = 1;
    Frame.Position = UDim2.new(0, 18, 0, 46);
    Frame.Size = UDim2.new(1, -36, 0, 34);
    Frame.ZIndex = 5;
    local UIListLayout = Instance.new("UIListLayout");
    UIListLayout.FillDirection = Enum.FillDirection.Horizontal;
    UIListLayout.SortOrder = Enum.SortOrder.LayoutOrder;
    UIListLayout.Padding = UDim.new(0, 8);
    UIListLayout.VerticalAlignment = Enum.VerticalAlignment.Center;
    UIListLayout.Parent = Frame;
    Frame.Parent = u1.Card;
    local v21 = makeButton(Frame, "STOP", Color3_fromRGB_ret3, 1, function() -- Line: 106
        -- upvalues: SkillRemote (ref)
        local u19 = "stop";
        local u20 = nil;
        task.spawn(function() -- Line: 36
            -- upvalues: SkillRemote (ref), u19 (copy), u20 (copy)
            pcall(SkillRemote.InvokeServer, SkillRemote, {
                Action = "CloneCommand",
                Command = u19,
                Index = u20
            });
        end);
    end);
    makeButton(Frame, "ATTACK", Color3_fromRGB_ret4, 2, function() -- Line: 107
        -- upvalues: SkillRemote (ref)
        local u22 = "attack";
        local u23 = nil;
        task.spawn(function() -- Line: 36
            -- upvalues: SkillRemote (ref), u22 (copy), u23 (copy)
            pcall(SkillRemote.InvokeServer, SkillRemote, {
                Action = "CloneCommand",
                Command = u22,
                Index = u23
            });
        end);
    end);
    u3 = {};

    for i = 1, math_clamp_ret do
        local v26 = makeButton(Frame, "SWITCH " .. i, Color3_fromRGB_ret5, i + 2, function() -- Line: 110
            -- upvalues: i (copy), SkillRemote (ref)
            local u24 = i;
            local u25 = "switch";
            task.spawn(function() -- Line: 36
                -- upvalues: SkillRemote (ref), u25 (copy), u24 (copy)
                pcall(SkillRemote.InvokeServer, SkillRemote, {
                    Action = "CloneCommand",
                    Command = u25,
                    Index = u24
                });
            end);
        end);
        u3[#u3 + 1] = {
            button = v26,
            index = i
        };
        local _ = i;
    end;

    makeButton(Frame, "DISMISS", Color3_fromRGB_ret6, 10, function() -- Line: 113
        -- upvalues: SkillRemote (ref)
        local u27 = "die";
        local u28 = nil;
        task.spawn(function() -- Line: 36
            -- upvalues: SkillRemote (ref), u27 (copy), u28 (copy)
            pcall(SkillRemote.InvokeServer, SkillRemote, {
                Action = "CloneCommand",
                Command = u27,
                Index = u28
            });
        end);
    end);

    local function setSwitchReady(p29, p30) -- Line: 117
        -- upvalues: u3 (ref), Color3_fromRGB_ret5 (ref), Color3_fromRGB_ret8 (ref)
        for _, v in ipairs(u3) do
            local button = v.button;

            if button.Parent then
                button.TextColor3 = p29 and Color3_fromRGB_ret5 or Color3_fromRGB_ret8;
                button.AutoButtonColor = p29;
                button.Text = p29 and "SWITCH " .. v.index or ("SWITCH %d (%.1f)"):format(v.index, p30);
            end;
        end;
    end;

    local function watchCooldown() -- Line: 126
        -- upvalues: u4 (ref), Players (ref), setSwitchReady (copy), u1 (ref)
        if u4 then
            task.cancel(u4);
            u4 = nil;
        end;

        local Character = Players.LocalPlayer.Character;

        if Character then
            Character = tonumber(Character:GetAttribute("CloneSwitchReadyAt"));
        end;

        if Character and Character > workspace:GetServerTimeNow() then
            u4 = task.spawn(function() -- Line: 131
                -- upvalues: u1 (ref), Character (copy), setSwitchReady (ref), u4 (ref)
                while u1 do
                    local v31 = Character - workspace:GetServerTimeNow();

                    if v31 <= 0 then
                        break;
                    end;

                    setSwitchReady(false, v31);
                    task.wait(0.1);
                end;

                u4 = nil;
                setSwitchReady(true);
            end);

            return;
        end;

        setSwitchReady(true);
    end;

    local Character = Players.LocalPlayer.Character;

    if Character then
        u5 = Character:GetAttributeChangedSignal("CloneSwitchReadyAt"):Connect(watchCooldown);
        watchCooldown();
    end;

    u1:SlideIn();

    if UserInputService.GamepadEnabled and (UserInputService:GetLastInputType() ~= Enum.UserInputType.Keyboard and UserInputService:GetLastInputType() ~= Enum.UserInputType.MouseMovement) then
        GuiService.SelectedObject = v21;
    end;

    u2 = task.delay(v18 + 1, function() -- Line: 155
        -- upvalues: u2 (ref), u6 (ref)
        u2 = nil;
        u6.Hide();
    end);
end;

return u6;