-- Decompiled with Potassium's decompiler.

local u1 = require("./String");
local u2 = require("./Table");
local u28 = {
    getNames = function(p3) -- Line: 9, Name: getNames
        local v4 = {};
        local v5 = {};

        for i, v in p3 do
            local v6 = v.Name or (v.name or tostring(v));

            if not v4[v6] then
                v4[v6] = true;
                v5[i] = v6;
            end;
        end;

        return v5, p3;
    end,

    query = function(p7: string, p8: table, p9: table?) -- Line: 23, Name: query
        -- upvalues: u1 (copy), u2 (copy)
        local string_lower_ret = string.lower(p7);
        local v10 = {};
        local v11 = {};
        local v12 = {};
        local v13 = {};

        for i, v in p8 do
            local v14, v15, v16;

            if type(v) == "table" then
                v14, v15, v16 = unpack(v);
            else
                v14 = v;
                v16 = nil;
                v15 = nil;
            end;

            local v17 = type(v14) ~= "table" and { v14 } or v14;

            if p9 then
                v16 = p9[v16] or p9[i] or (p9[v] or v16);
            end;

            local v18 = false;

            for _, v2 in v17 do
                if string.lower(v2) == string_lower_ret then
                    table.insert(v12, 1, { v2, v15, v16 or v2 });
                    v18 = true;
                    break;
                end;
            end;

            if not v18 then
                local v19 = 0;
                local v20 = nil;
                local v21 = nil;

                for _, v2 in v17 do
                    local string_find_ret, v22 = string.find(string.lower(v2), string_lower_ret, 1, true);

                    if string_find_ret then
                        if string_find_ret == 1 and v19 < v22 then
                            v21 = v2;
                            v19 = v22;
                        elseif v19 == 0 and not v20 then
                            v20 = v2;
                        end;
                    end;
                end;

                local v23 = v21 or v20;

                if v23 then
                    local v24;

                    if v21 then
                        v24 = v10;
                    else
                        v24 = v13;
                    end;

                    table.insert(v24, { v23, v15, v16 or v23 });
                    v18 = true;
                end;
            end;

            if not v18 then
                for _, v2 in v17 do
                    table.insert(v11, { v2, v15, v16 or v2 });
                end;
            end;
        end;

        if #v11 > 0 then
            local v25 = (1 / 0);
            local v26 = nil;

            for _, v in v11 do
                local v27 = u1.levenshteinDistance(string.lower(v[1]), string_lower_ret);

                if v27 < v25 then
                    v26 = v;
                    v25 = v27;
                end;
            end;

            if v26 then
                table.insert(v13, v26);
            end;
        end;

        if #v10 > 0 then
            u2.mergeList(v12, v10);
        end;

        if #v13 > 0 then
            u2.mergeList(v12, v13);
        end;

        return v12;
    end
};

function u28.new(p29) -- Line: 94
    -- upvalues: u28 (copy)
    local v30 = nil;
    local v31 = {};
    local v32 = typeof(p29);

    if v32 == "Enum" then
        p29 = p29:GetEnumItems();
        v32 = typeof(p29);
    end;

    if v32 == "Instance" then
        local Names, v33 = u28.getNames(p29:GetChildren());

        return Names, v33;
    end;

    if v32 ~= "table" then
        error((`only accepts a table, Enum, or Instance, got: {v32}`));

        return v30, v31;
    end;

    local v34 = p29[1] or next(p29);
    local v35 = typeof(v34);

    if v35 == "Instance" or (v35 == "EnumItem" or v35 == "table" and (v34 and (type(v34.Name) == "string" or type(v34.name) == "string"))) then
        local Names, v36 = u28.getNames(p29);

        return Names, v36;
    end;

    if v35 == "string" then
        return p29, v31;
    end;

    if v34 == nil then
        return {}, v31;
    end;

    error((`only accepts tables of instances or strings, got: {v35}`));

    return v30, v31;
end;

return u28;