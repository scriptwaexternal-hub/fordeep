-- Decompiled with Potassium's decompiler.

local Parent = require(script.Parent.Parent);
local BaseClass = require(script.Parent:WaitForChild("BaseClass"));
local u1 = {
    Collapsible = false,
    Collapsed = false,
    Label = "",
    Padding = Parent.Theme.Padding
};
local u2 = {};
u2.__index = u2;
setmetatable(u2, BaseClass);

function u2.new(p3) -- Line: 17
    -- upvalues: u1 (copy), Parent (copy), u2 (copy)
    local table_clone_ret = table.clone(u1);
    Parent.makeStatefulDefaults(table_clone_ret, p3);
    local v4 = {};
    local v5 = Parent.new("UIListLayout")({
        SortOrder = Enum.SortOrder.LayoutOrder,
        Padding = table_clone_ret.Padding,
        HorizontalAlignment = Enum.HorizontalAlignment.Left,
        VerticalAlignment = Enum.VerticalAlignment.Top
    });
    local u6 = Parent.state(v5, "AbsoluteContentSize");
    table.insert(v4, u6);
    local v7 = Parent.tween(function() -- Line: 33
        -- upvalues: table_clone_ret (copy)
        return table_clone_ret.Collapsed() and 0.5 or 0;
    end, Parent.Theme.TweenOut);
    table.insert(v4, v7);
    table_clone_ret._instance = Parent.new("Frame")({
        Name = "List",
        BackgroundColor3 = Parent.Theme.Secondary,
        BackgroundTransparency = Parent.Theme.TransparencyMax,
        ClipsDescendants = true,
        Size = Parent.tween(function() -- Line: 43
            -- upvalues: Parent (ref), table_clone_ret (copy), u6 (copy)
            local v8 = Parent.Theme.FontSize();
            local Offset = Parent.Theme.Padding().Offset;
            local v9;

            if table_clone_ret.Collapsed() then
                v9 = v8 + Offset * 4;
            else
                local Y = u6().Y;
                local v10;

                if table_clone_ret.Label() == "" then
                    v10 = Offset * 2;
                else
                    v10 = v8 + Offset * 6;
                end;

                v9 = Y + v10;
            end;

            return UDim2.new(1, 0, 0, v9);
        end, Parent.Theme.TweenOut),
        Parent.new("UICorner")({
            CornerRadius = Parent.Theme.CornerPadded
        }),
        Parent.new("Stroke")({
            Transparency = Parent.Theme.TransparencyBalanced
        }),
        Parent.new("TextButton")({
            AutoLocalize = false,
            Name = "Header",
            Active = true,
            AutomaticSize = Enum.AutomaticSize.Y,
            BackgroundTransparency = 1,
            TextTransparency = 1,
            Text = "",
            Size = UDim2.new(1, 0, 0, 0),

            Visible = function() -- Line: 65, Name: Visible
                -- upvalues: table_clone_ret (copy)
                return table_clone_ret.Collapsible() or table_clone_ret.Label() ~= "";
            end,

            Parent.new("UIPadding")({
                PaddingLeft = table_clone_ret.Padding,
                PaddingRight = table_clone_ret.Padding,
                PaddingTop = table_clone_ret.Padding,
                PaddingBottom = table_clone_ret.Padding
            }),
            Parent.new("ImageLabel")({
                Name = "Arrow",
                BackgroundTransparency = 1,
                AnchorPoint = Vector2.new(0, 0.5),
                Position = UDim2.new(0, 0, 0.5, 0),
                Size = UDim2.new(0.75, 0, 0.75, 0),
                Image = Parent.Theme.Image.Down,
                ImageColor3 = Parent.Theme.PrimaryText,
                ImageTransparency = v7,
                Visible = table_clone_ret.Collapsible,
                Rotation = Parent.tween(function() -- Line: 86
                    -- upvalues: table_clone_ret (copy)
                    return table_clone_ret.Collapsed() and -90 or 0;
                end, Parent.Theme.TweenOut),
                Parent.new("UIAspectRatioConstraint")({})
            }),
            Parent.new("TextLabel")({
                AutoLocalize = false,
                Name = "Label",
                BackgroundTransparency = 1,
                TextXAlignment = "Left",
                AutomaticSize = Enum.AutomaticSize.Y,

                Position = function() -- Line: 98, Name: Position
                    -- upvalues: table_clone_ret (copy), Parent (ref)
                    local UDim2_new = UDim2.new;
                    local v11;

                    if table_clone_ret.Collapsible() then
                        v11 = Parent.Theme.FontSize();
                    else
                        v11 = Parent.Theme.Padding();
                    end;

                    return UDim2_new(0, v11, 0, 0);
                end,

                Size = function() -- Line: 101, Name: Size
                    -- upvalues: Parent (ref)
                    return UDim2.new(1, -Parent.Theme.FontSize(), 0, 0);
                end,

                FontFace = Parent.Theme.FontBold,

                Text = function() -- Line: 105, Name: Text
                    -- upvalues: table_clone_ret (copy)
                    return string.upper((table_clone_ret.Label()));
                end,

                TextSize = Parent.Theme.FontSize,
                TextColor3 = Parent.Theme.PrimaryText,
                TextStrokeColor3 = Parent.Theme.Primary,
                TextStrokeTransparency = Parent.Theme.TextStrokeTransparency,
                TextTransparency = v7,
                TextTruncate = Enum.TextTruncate.SplitWord
            }),

            Activated = function() -- Line: 117, Name: Activated
                -- upvalues: table_clone_ret (copy), Parent (ref)
                if table_clone_ret.Collapsible._value then
                    table_clone_ret.Collapsed(not table_clone_ret.Collapsed._value);

                    if table_clone_ret.Collapsed._value then
                        Parent.Sound.Hover01:Play();

                        return;
                    end;

                    Parent.Sound.Hover03:Play();
                end;
            end
        }),
        [Parent.Clean] = v4
    });
    table_clone_ret._content = Parent.new("Frame")({
        Name = "UIContent",
        Parent = table_clone_ret._instance,
        BackgroundTransparency = 1,

        Position = function() -- Line: 135, Name: Position
            -- upvalues: table_clone_ret (copy), Parent (ref)
            local Offset = table_clone_ret.Padding().Offset;
            local UDim2_new = UDim2.new;

            if table_clone_ret.Label() ~= "" then
                Offset = Parent.Theme.FontSize + Offset * 2;
            end;

            return UDim2_new(0, 0, 0, Offset);
        end,

        Size = Parent.tween(function() -- Line: 139
            -- upvalues: table_clone_ret (copy), Parent (ref)
            local v12 = table_clone_ret.Collapsed();

            return UDim2.new(1, 0, v12 and 0 or 1, v12 and 0 or -Parent.Theme.FontSize + table_clone_ret.Padding().Offset * 2);
        end, Parent.Theme.TweenOut),
        ClipsDescendants = true,
        v5,
        Parent.new("UIPadding")({
            PaddingLeft = table_clone_ret.Padding,
            PaddingRight = table_clone_ret.Padding,
            PaddingTop = UDim.new(0, 1),
            PaddingBottom = UDim.new(0, 1)
        })
    });

    return setmetatable(table_clone_ret, u2);
end;

return u2;