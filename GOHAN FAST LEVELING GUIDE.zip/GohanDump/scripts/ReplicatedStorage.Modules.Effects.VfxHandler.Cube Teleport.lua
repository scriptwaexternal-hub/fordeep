-- Decompiled with Potassium's decompiler.

game:GetService("Players");
local Debris = game:GetService("Debris");
game:GetService("Chat");
local ReplicatedStorage = game:GetService("ReplicatedStorage");
game:GetService("ServerStorage");
game:GetService("ServerScriptService");
game:GetService("RunService");
local TweenService = game:GetService("TweenService");
local v1 = {};
local Modules = ReplicatedStorage:WaitForChild("Modules");
ReplicatedStorage:WaitForChild("Remotes");
local _ = Modules.Metadata;
local _ = Modules.Shared;
local Create = require(Modules.Utility.Create);
local GlobalFunctions = require(Modules.GlobalFunctions);
local Invisibility = require(script.Parent.Invisibility);

function v1.TeleportWithCubify(p2, u3, p4, p5, p6, p7) -- Line: 32
    -- upvalues: Create (copy), GlobalFunctions (copy), Invisibility (copy), TweenService (copy)
    local u8 = p5 or 0.5;
    local v9 = p6 or 0.01;
    local u10 = p7 or 0.3;
    local HumanoidRootPart = p2:FindFirstChild("HumanoidRootPart");

    if not HumanoidRootPart then
        warn("Character has no HumanoidRootPart");

        return;
    end;

    local v11 = (p4 or 0.5) * (HumanoidRootPart.Size.Magnitude / (Vector3.new(2, 2, 1)).Magnitude);
    local v12 = u8 + v9 * 10;
    HumanoidRootPart.Anchored = true;
    Create.new(p2, "Stuck", v12);
    Create.new(p2, "IFrame", v12);
    p2.Archivable = true;
    local u13 = p2:Clone();
    u13.Parent = workspace;
    local HumanoidRootPart2 = u13:FindFirstChild("HumanoidRootPart");
    HumanoidRootPart2.Anchored = true;
    HumanoidRootPart2.CFrame = HumanoidRootPart.CFrame;
    u13.Parent = nil;

    for _, descendant in ipairs(u13:GetDescendants()) do
        if descendant:IsA("BasePart") then
            descendant.Anchored = true;
            descendant.CanCollide = false;
        end;
    end;

    local function cubifyPart(p14, p15, p16) -- Line: 78
        -- upvalues: GlobalFunctions (ref)
        local Size = p14.Size;
        local CFrame2 = p14.CFrame;
        local math_floor_ret = math.floor(Size.X / p16);
        local math_clamp_ret = math.clamp(math_floor_ret, 1, 10);
        local math_floor_ret2 = math.floor(Size.Y / p16);
        local math_clamp_ret2 = math.clamp(math_floor_ret2, 1, 10);
        local math_floor_ret3 = math.floor(Size.Z / p16);
        local math_clamp_ret3 = math.clamp(math_floor_ret3, 1, 10);
        local v17 = {};

        for i = 0, math_clamp_ret2 - 1 do
            local v18 = i;

            for i2 = 0, math_clamp_ret - 1 do
                local v19 = i2;

                for i3 = 0, math_clamp_ret3 - 1 do
                    local Part = Instance.new("Part");
                    Part.Size = Vector3.new(Size.X / math_clamp_ret, Size.Y / math_clamp_ret2, Size.Z / math_clamp_ret3);
                    Part.Anchored = true;
                    Part.CanCollide = false;
                    Part.Material = p14.Material;
                    Part.Color = p14.Color;
                    Part.CFrame = CFrame2 * CFrame.new((v19 - math_clamp_ret / 2 + 0.5) * Part.Size.X, (v18 - math_clamp_ret2 / 2 + 0.5) * Part.Size.Y, (i3 - math_clamp_ret3 / 2 + 0.5) * Part.Size.Z);
                    Part.Parent = workspace;
                    Part.Transparency = 1;
                    GlobalFunctions.Tween({
                        Duration = 0.25,
                        Instance = Part
                    }, {
                        Transparency = 0
                    });
                    local v20 = p15:ToObjectSpace(Part.CFrame);
                    table.insert(v17, {
                        part = Part,
                        offset = v20,
                        height = v20.Y
                    });
                    local _ = i3;
                end;
            end;
        end;

        return v17;
    end;

    local u21 = {};

    for _, descendant in ipairs(u13:GetDescendants()) do
        if descendant:IsA("Part") and descendant ~= u13:FindFirstChild("HumanoidRootPart") then
            local v22 = cubifyPart(descendant, u13.HumanoidRootPart.CFrame, v11);

            for _, v in ipairs(v22) do
                table.insert(u21, v);
            end;
        end;
    end;

    table.sort(u21, function(p23, p24) -- Line: 135
        return p23.height > p24.height;
    end);
    local math_max_ret = math.max(1, #u21);
    local v25 = u8 + v9 * math_max_ret;
    Invisibility.Invis(p2, v25 + 0.25, 0.25);
    p2:SetAttribute("BoundsGraceUntil", os.clock() + v25 + 0.25 + 2);
    task.wait(0.25);
    GlobalFunctions.Tween({
        Duration = v25,
        Instance = HumanoidRootPart
    }, {
        CFrame = u3
    });

    for i, v in ipairs(u21) do
        task.delay(i / math_max_ret * v9 * math_max_ret, function() -- Line: 158
            -- upvalues: v (copy), u3 (copy), TweenService (ref), u8 (ref)
            local part = v.part;
            local v26 = u3 * CFrame.new(v.offset.Position);
            TweenService:Create(part, TweenInfo.new(u8, Enum.EasingStyle.Linear), {
                CFrame = v26
            }):Play();
        end);
    end;

    task.delay(u8 + v9 * math_max_ret, function() -- Line: 170
        -- upvalues: HumanoidRootPart (copy), u21 (copy), TweenService (ref), u10 (ref)
        HumanoidRootPart.Anchored = false;

        for _, v in ipairs(u21) do
            local part = v.part;
            local v27 = TweenService:Create(part, TweenInfo.new(u10, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
                Size = Vector3.new(0, 0, 0),
                Transparency = 1
            });
            v27:Play();
            v27.Completed:Connect(function() -- Line: 180
                -- upvalues: part (copy)
                part:Destroy();
            end);
        end;
    end);
    task.delay(u8 + v9 * math_max_ret + u10, function() -- Line: 187
        -- upvalues: u13 (copy)
        u13:Destroy();
    end);
end;

function v1.Burst(p28, p29, p30) -- Line: 214
    -- upvalues: TweenService (copy), Debris (copy)
    local v31 = p30 or {};
    local v32 = v31.Reform or false;
    local v33 = v31.Duration or 0.25;
    local v34 = v31.Spread or 6;
    local v35;

    if p28 then
        v35 = p28:FindFirstChild("HumanoidRootPart");
    else
        v35 = p28;
    end;

    if not v35 then
        return;
    end;

    local v36 = p29 or v35.CFrame;
    local v37 = (v31.CubeSize or 0.5) * (v35.Size.Magnitude / (Vector3.new(2, 2, 1)).Magnitude);
    p28.Archivable = true;
    local v38 = p28:Clone();
    local HumanoidRootPart = v38:FindFirstChild("HumanoidRootPart");

    if not HumanoidRootPart then
        v38:Destroy();

        return;
    end;

    HumanoidRootPart.CFrame = v36;
    local v39 = {};

    for _, descendant in ipairs(v38:GetDescendants()) do
        if descendant:IsA("BasePart") and (descendant ~= HumanoidRootPart and descendant.Transparency < 1) then
            local Size = descendant.Size;
            local math_floor_ret = math.floor(Size.X / v37);
            local math_clamp_ret = math.clamp(math_floor_ret, 1, 6);
            local math_floor_ret2 = math.floor(Size.Y / v37);
            local math_clamp_ret2 = math.clamp(math_floor_ret2, 1, 6);
            local math_floor_ret3 = math.floor(Size.Z / v37);
            local math_clamp_ret3 = math.clamp(math_floor_ret3, 1, 6);
            local v40 = descendant;

            for i = 0, math_clamp_ret - 1 do
                local v41 = i;

                for i2 = 0, math_clamp_ret2 - 1 do
                    local v42 = i2;

                    for i3 = 0, math_clamp_ret3 - 1 do
                        local Part = Instance.new("Part");
                        Part.Size = Vector3.new(Size.X / math_clamp_ret, Size.Y / math_clamp_ret2, Size.Z / math_clamp_ret3);
                        Part.Anchored = true;
                        Part.CanCollide = false;
                        Part.CanQuery = false;
                        Part.CanTouch = false;
                        Part.Material = v40.Material;
                        Part.Color = v40.Color;
                        local v43 = v40.CFrame * CFrame.new((v41 - math_clamp_ret / 2 + 0.5) * Part.Size.X, (v42 - math_clamp_ret2 / 2 + 0.5) * Part.Size.Y, (i3 - math_clamp_ret3 / 2 + 0.5) * Part.Size.Z);
                        local v44 = v43 * CFrame.new(math.random(-v34, v34), math.random(-v34, v34), math.random(-v34, v34));
                        Part.CFrame = v32 and v44 and v44 or v43;
                        Part.Transparency = v32 and 1 or 0;
                        Part.Parent = workspace;
                        table.insert(v39, {
                            part = Part,
                            settled = v43,
                            scattered = v44
                        });
                        local _ = i3;
                    end;
                end;
            end;
        end;
    end;

    v38:Destroy();
    local TweenInfo_new_ret = TweenInfo.new(v33, Enum.EasingStyle.Quad, v32 and Enum.EasingDirection.Out or Enum.EasingDirection.In);

    for _, v in ipairs(v39) do
        TweenService:Create(v.part, TweenInfo_new_ret, {
            CFrame = v32 and v.settled or v.scattered,
            Transparency = v32 and 0 or 1
        }):Play();
        Debris:AddItem(v.part, v33 + 0.1);
    end;
end;

return v1;