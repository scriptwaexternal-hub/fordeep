-- Decompiled with Potassium's decompiler.

game:GetService("Players");
local Metadata = game:GetService("ReplicatedStorage"):WaitForChild("Modules").Metadata;
local SkillData = require(Metadata.SkillData.SkillData);
local u1 = {};
local u2 = {};

local function runCooldownOnFrame(u3, u4) -- Line: 43
    -- upvalues: u1 (copy)
    local CD_Frame = u3:FindFirstChild("CD_Frame");

    if not CD_Frame then
        return;
    end;

    local u5 = u3:FindFirstChild("TimeLeft") or CD_Frame:FindFirstChild("TimeLeft");
    local u6 = (u1[u3] or 0) + 1;
    u1[u3] = u6;
    CD_Frame.Size = UDim2.new(1, 0, 1, 0);
    CD_Frame.Visible = true;

    if u5 then
        u5.Visible = true;
        u5.Text = string.format("%.1f", u4);
    end;

    task.spawn(function() -- Line: 61
        -- upvalues: u4 (copy), u1 (ref), u3 (copy), u6 (copy), u5 (copy), CD_Frame (copy)
        local v7 = os.clock() + u4;

        while os.clock() < v7 do
            if u1[u3] ~= u6 then
                return;
            end;

            if not u3.Parent then
                return;
            end;

            if u5 then
                local string_format = string.format;
                local v8 = v7 - os.clock();
                u5.Text = string_format("%.1f", (math.max(v8, 0)));
            end;

            task.wait(0.1);
        end;

        if u1[u3] ~= u6 then
            return;
        end;

        CD_Frame.Visible = false;

        if u5 then
            u5.Visible = false;
            u5.Text = "";
        end;
    end);
end;

function u2.Start(p9, p10, p11) -- Line: 85
    -- upvalues: runCooldownOnFrame (copy)
    if not (p10 and (p10 ~= "" and (p11 and p11 > 0))) then
        return;
    end;

    local PlayerGui = p9:FindFirstChild("PlayerGui");

    if PlayerGui then
        PlayerGui = PlayerGui:FindFirstChild("HUD");
    end;

    if PlayerGui then
        PlayerGui = PlayerGui:FindFirstChild("Inventory");
    end;

    if PlayerGui then
        PlayerGui = PlayerGui:FindFirstChild("RegSlots");
    end;

    if not PlayerGui then
        return;
    end;

    for _, child in ipairs(PlayerGui:GetChildren()) do
        if child:IsA("Frame") then
            local ItemFrame = child:FindFirstChild("ItemFrame");

            if ItemFrame then
                local ItemName = ItemFrame:FindFirstChild("ItemName");

                if ItemName and ItemName.Text == p10 then
                    runCooldownOnFrame(ItemFrame, p11);
                end;
            end;
        end;
    end;
end;

function u2.Fire(p12, p13, p14, p15) -- Line: 111
    -- upvalues: SkillData (copy), u2 (copy)
    local Any = SkillData.GetAny(p13, p14, p15);

    if Any then
        Any = Any.Cooldown;
    end;

    if not Any then
        return;
    end;

    local PlayerStats = p12:FindFirstChild("PlayerStats");

    if PlayerStats then
        PlayerStats = PlayerStats:FindFirstChild("CooldownFactor", true);
    end;

    if PlayerStats then
        Any = Any * PlayerStats.Value;
    end;

    local Character = p12.Character;
    local v16 = Character and (Character:GetAttribute("CD_" .. tostring(p14):gsub("%W", "")) or 1) or 1;
    u2.Start(p12, p14, Any * v16);
end;

return u2;