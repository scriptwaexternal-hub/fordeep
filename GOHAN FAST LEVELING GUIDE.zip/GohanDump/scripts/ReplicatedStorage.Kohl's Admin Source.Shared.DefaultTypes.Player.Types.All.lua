-- Decompiled with Potassium's decompiler.

local Players = game:GetService("Players");
local generateValidate = require(script.Parent.Parent:WaitForChild("generateValidate"));

local function allParse(p1, p2) -- Line: 5
    -- upvalues: Players (copy)
    local v3 = {};
    local v4 = {};

    for _, v in Players:GetPlayers() do
        local v5, v6 = p2._K.Auth.targetUserArgument(p2, v.UserId, v);

        if v5 then
            table.insert(v3, v5);
        elseif not table.find(v4, v6) then
            table.insert(v4, v6);
        end;
    end;

    if #v3 > 0 then
        return v3;
    end;

    return nil, #v4 > 0 and table.concat(v4, "\n") or "No targetable player found";
end;

local u9 = {
    listable = true,
    transform = string.lower,
    validate = generateValidate(allParse),

    suggestions = function(p7, p8) -- Line: 29, Name: suggestions
        return { { { "*", "all" }, "*  [all] (Everyone)" } };
    end,

    parse = allParse
};

return function(p10) -- Line: 35
    -- upvalues: u9 (copy)
    p10.Registry.registerType("allPlayers", u9);
end;