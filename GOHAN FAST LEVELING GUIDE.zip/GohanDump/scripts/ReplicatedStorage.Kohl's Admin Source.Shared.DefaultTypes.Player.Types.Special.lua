-- Decompiled with Potassium's decompiler.

local Players = game:GetService("Players");
local generateValidate = require(script.Parent.Parent:WaitForChild("generateValidate"));

return function(u1) -- Line: 5
    -- upvalues: Players (copy), generateValidate (copy)
    local u28 = {
        all = function(p2, p3) -- Line: 7, Name: all
            return true;
        end,

        others = function(p4, p5) -- Line: 10, Name: others
            return p4 ~= p5, "Can\'t target yourself";
        end,

        admins = function(p6) -- Line: 13, Name: admins
            -- upvalues: u1 (copy)
            return u1.Data.members[tostring(p6.UserId)];
        end,

        nonadmins = function(p7) -- Line: 16, Name: nonadmins
            -- upvalues: u1 (copy)
            return not u1.Data.members[tostring(p7.UserId)];
        end,

        friends = function(p8, p9) -- Line: 19, Name: friends
            local v10;

            if p8 == p9 then
                v10 = false;
            else
                v10 = p8:IsFriendsWith(p9);
            end;

            return v10;
        end,

        close = function(p11, p12) -- Line: 22, Name: close
            if p11.Character and p12.Character then
                return p11:DistanceFromCharacter(p12.Character.PrimaryPart.Position) <= 100;
            end;

            return false;
        end,

        far = function(p13, p14) -- Line: 27, Name: far
            if p13.Character and p14.Character then
                return p13:DistanceFromCharacter(p14.Character.PrimaryPart.Position) > 100;
            end;

            return false;
        end,

        distance = function(p15: userdata, p16: userdata, p17: string) -- Line: 32, Name: distance
            if p15.Character and p16.Character then
                local string_match_ret, v18 = string.match(p17, "([><])(%d+)$");
                local v19 = tonumber(v18);

                if not v19 then
                    return false, "Invalid distance radius: " .. p17;
                end;

                local Pivot = p16.Character:GetPivot();

                if not Pivot then
                    return false, "Cannot calculate distance, you need a character";
                end;

                if string_match_ret == ">" then
                    return v19 < p15:DistanceFromCharacter(Pivot.Position);
                end;

                if string_match_ret == "<" then
                    return p15:DistanceFromCharacter(Pivot.Position) <= v19;
                end;
            end;

            return false;
        end,

        group = function(p20: userdata, p21: any, p22: string) -- Line: 51, Name: group
            local string_match_ret, v23, v24, v25 = string.match(p22, "=(%d+)([>=<])(=?)(%d*)$");
            local v26 = tonumber(string_match_ret);
            local v27 = tonumber(v25);

            if not v26 then
                return false, "Invalid group: " .. p22;
            end;

            if not p20:IsInGroupAsync(v26) then
                return false;
            end;

            if not v27 then
                return true;
            end;

            local RankInGroupAsync = p20:GetRankInGroupAsync(v26);

            if not RankInGroupAsync then
                return false;
            end;

            if v23 == ">" then
                if v24 then
                    return v27 <= RankInGroupAsync;
                end;

                return v27 < RankInGroupAsync;
            end;

            if v23 ~= "<" then
                return RankInGroupAsync == v27;
            end;

            if v24 then
                return RankInGroupAsync <= v27;
            end;

            return RankInGroupAsync < v27;
        end
    };
    local u29 = {};

    for i, _ in u28 do
        if i == "distance" then
            table.insert(u29, "$distance<200");
        elseif i == "group" then
            local v30 = `${i}={u1.groupId or 3403354}<=255`;
            table.insert(u29, v30);
        else
            table.insert(u29, "$" .. i);
        end;
    end;

    table.sort(u29);

    local function specialParse(p31, p32) -- Line: 89
        -- upvalues: u28 (copy), Players (ref)
        for i, v in u28 do
            local v33, v34, v35, v36, v37, v38, v39, v40;

            if i == "distance" or i == "group" then
                if string.find(p31, i, 1, true) == 1 then
                    v33 = v;
                    v34 = {};
                    v35 = {};

                    for i2, v2 in Players:GetPlayers() do
                        v36, v37, v38 = pcall(v33, v2, p32.command.fromPlayer, p31);

                        if v36 and v37 then
                            v39, v40 = p32._K.Auth.targetUserArgument(p32, v2.UserId, v2);

                            if v39 then
                                table.insert(v34, v39);
                            elseif not table.find(v35, v40) then
                                table.insert(v35, v40);
                            end;
                        elseif not table.find(v35, v38) then
                            table.insert(v35, v38);
                        end;
                    end;

                    if #v34 <= 0 then
                        v34 = false;
                    end;

                    return v34, #v35 > 0 and table.concat(v35, "\n") or "No targetable player found";
                end;
            elseif string.find(i, p31, 1, true) == 1 then
                v33 = v;
                v34 = {};
                v35 = {};

                for i2, v2 in Players:GetPlayers() do
                    v36, v37, v38 = pcall(v33, v2, p32.command.fromPlayer, p31);

                    if v36 and v37 then
                        v39, v40 = p32._K.Auth.targetUserArgument(p32, v2.UserId, v2);

                        if v39 then
                            table.insert(v34, v39);
                        elseif not table.find(v35, v40) then
                            table.insert(v35, v40);
                        end;
                    elseif not table.find(v35, v38) then
                        table.insert(v35, v38);
                    end;
                end;

                if #v34 <= 0 then
                    v34 = false;
                end;

                return v34, #v35 > 0 and table.concat(v35, "\n") or "No targetable player found";
            end;
        end;

        return false, "Invalid match";
    end;

    local v43 = {
        listable = true,
        transform = string.lower,
        validate = generateValidate(specialParse),
        parse = specialParse,

        suggestions = function(p41, p42) -- Line: 130, Name: suggestions
            -- upvalues: u29 (copy)
            return u29;
        end
    };
    u1.Registry.registerType("specialPlayers", v43);
end;