-- Decompiled with Potassium's decompiler.

local Debris = game:GetService("Debris");
local ReplicatedStorage = game:GetService("ReplicatedStorage");
local Modules = ReplicatedStorage:WaitForChild("Modules");
local SoundManager = require(Modules.Shared.SoundManager);
local GlobalFunctions = require(Modules.GlobalFunctions);
local VfxHandler = require(Modules.Effects.VfxHandler);
local Visuals = workspace.World.Visuals;
local Meshes = ReplicatedStorage.Assets.Effects.Meshes;

return {
    Start = function(p1) -- Line: 33
        -- upvalues: Meshes (copy), Visuals (copy), SoundManager (copy), GlobalFunctions (copy), Debris (copy)
        local Character = p1.Character;

        if not Character then
            return;
        end;

        local v2 = Character:FindFirstChild("Left Arm") or Character:FindFirstChild("HumanoidRootPart");

        if not v2 then
            return;
        end;

        local u3 = Meshes.Skills.Beam_Start:Clone();
        u3.Name = "Big_Bang" .. Character.Name;
        u3.CFrame = v2.CFrame * CFrame.new(0, -2, -0.2);
        u3.Anchored = false;
        u3.Parent = Visuals;
        local WeldConstraint = Instance.new("WeldConstraint");
        WeldConstraint.Part0 = u3;
        WeldConstraint.Part1 = v2;
        WeldConstraint.Parent = u3;
        SoundManager.AddSound("Beam Charge", {
            Parent = u3
        }, "Client");
        GlobalFunctions.Tween({
            Instance = u3
        }, {
            Size = Vector3.new(1, 1, 1) * (p1.Start_Size or 2)
        });
        task.spawn(function() -- Line: 58
            -- upvalues: u3 (copy), Meshes (ref), Visuals (ref), Debris (ref), GlobalFunctions (ref)
            while u3.Parent ~= nil do
                local v4 = Meshes.Skills.Blasts["Big Bang Attack"].Black_Orb:Clone();
                v4.CFrame = u3.CFrame;
                v4.Anchored = true;
                v4.Parent = Visuals;
                Debris:AddItem(v4, 2);
                GlobalFunctions.Tween({
                    Duration = 2,
                    Instance = v4
                }, {
                    Size = Vector3.new(10, 10, 10),
                    Transparency = 1
                });
                task.wait(1);
            end;
        end);
        task.spawn(function() -- Line: 73
            -- upvalues: Character (copy), u3 (copy), WeldConstraint (copy)
            while Character:FindFirstChild("Charging Beam") do
                if Character:FindFirstChild("Stun") then
                    u3:Destroy();

                    return;
                end;

                task.wait();
            end;

            WeldConstraint:Destroy();
            u3.Anchored = true;
        end);
    end,

    Execute = function(p5) -- Line: 87
        -- upvalues: Meshes (copy), Visuals (copy), Debris (copy), GlobalFunctions (copy), SoundManager (copy), VfxHandler (copy)
        local Location = p5.Location;

        if not Location then
            return;
        end;

        local Instance2 = p5.Instance;
        local v6 = p5.Size or 40;
        local u7 = Meshes.Skills.Explosion:Clone();
        u7.CFrame = Location;
        u7.Size = Vector3.new(0, 0, 0);
        u7.Parent = Visuals;
        Debris:AddItem(u7, 2.5);
        local v8 = Meshes["Blast Effect"].BlastEffect:Clone();
        v8.Parent = u7;
        v8.PFX:Emit(10);
        GlobalFunctions.Tween({
            Duration = 1.5,
            Instance = u7,
            EasingStyle = Enum.EasingStyle.Exponential
        }, {
            Size = Vector3.new(1, 1, 1) * v6
        }).Completed:Once(function() -- Line: 107
            -- upvalues: GlobalFunctions (ref), u7 (copy)
            GlobalFunctions.TransparencyTween({
                Instance = u7
            });
        end);
        SoundManager.AddSound("Explosion 1", {
            Parent = u7
        }, "Client");

        if Instance2 then
            VfxHandler.BlockDebris.Execute({
                Location = Location,
                Material = Instance2.Material,
                Color = Instance2.Color,
                Transparency = Instance2.Transparency
            });
        end;
    end
};