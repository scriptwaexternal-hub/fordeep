-- Decompiled with Potassium's decompiler.

local TweenService = game:GetService("TweenService");
local Clipping = script:FindFirstAncestor("HUD").MainFrame.HUDisplay.HUDMAIN.EvadeMeter:WaitForChild("Clipping");
local Fill = Clipping:WaitForChild("Fill");
local NumberValue = Instance.new("NumberValue");
NumberValue.Value = 1;
local ImageColor3 = Fill.ImageColor3;
local Color3_new_ret = Color3.new(ImageColor3.R * 0.55, ImageColor3.G * 0.55, ImageColor3.B * 0.55);

local function applyFill(p1) -- Line: 32
    -- upvalues: Clipping (copy), Fill (copy)
    local math_clamp_ret = math.clamp(p1, 0, 1);

    if math_clamp_ret <= 0.001 then
        Clipping.Size = UDim2.new(1, 0, 0, 0);

        return;
    end;

    Clipping.Size = UDim2.new(1, 0, math_clamp_ret, 0);
    Fill.Size = UDim2.new(1, 0, 1 / math_clamp_ret, 0);
end;

NumberValue.Changed:Connect(applyFill);
applyFill(NumberValue.Value);

return {
    Update = function(p2) -- Line: 51, Name: Update
        -- upvalues: TweenService (copy), NumberValue (copy), Fill (copy), ImageColor3 (copy), Color3_new_ret (copy)
        local math_clamp_ret = math.clamp(p2 / 4, 0, 1);
        TweenService:Create(NumberValue, TweenInfo.new(0.2, Enum.EasingStyle.Sine, Enum.EasingDirection.Out), {
            Value = math_clamp_ret
        }):Play();
        TweenService:Create(Fill, TweenInfo.new(0.2, Enum.EasingStyle.Sine, Enum.EasingDirection.Out), {
            ImageColor3 = p2 >= 0.999999 and ImageColor3 or Color3_new_ret
        }):Play();
    end
};