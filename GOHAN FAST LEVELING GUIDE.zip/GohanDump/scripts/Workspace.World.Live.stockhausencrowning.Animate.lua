-- Decompiled with Potassium's decompiler.

local script_Parent = script.Parent;
local Torso = script_Parent:WaitForChild("Torso");
local u1 = Torso:WaitForChild("Right Shoulder");
local u2 = Torso:WaitForChild("Left Shoulder");
local u3 = Torso:WaitForChild("Right Hip");
local u4 = Torso:WaitForChild("Left Hip");
Torso:WaitForChild("Neck");
local Humanoid = script_Parent:WaitForChild("Humanoid");
local u5 = {};
local u6 = {
    idle = { {
            id = "http://www.roblox.com/asset/?id=18321727828",
            weight = 9
        }, {
            id = "http://www.roblox.com/asset/?id=7997058135",
            weight = 1
        } },
    walk = { {
            id = "http://www.roblox.com/asset/?id=9399717472",
            weight = 10
        } },
    run = { {
            id = "run.xml",
            weight = 10
        } },
    jump = { {
            id = "http://www.roblox.com/asset/?id=87514293098090",
            weight = 10
        } },
    fall = { {
            id = "http://www.roblox.com/asset/?id=9295465422",
            weight = 10
        } },
    climb = { {
            id = "http://www.roblox.com/asset/?id=180436334",
            weight = 10
        } },
    sit = { {
            id = "http://www.roblox.com/asset/?id=178130996",
            weight = 10
        } },
    toolnone = { {
            id = "http://www.roblox.com/asset/?id=182393478",
            weight = 10
        } },
    toolslash = { {
            id = "http://www.roblox.com/asset/?id=129967390",
            weight = 10
        } },
    toollunge = { {
            id = "http://www.roblox.com/asset/?id=129967478",
            weight = 10
        } },
    wave = { {
            id = "http://www.roblox.com/asset/?id=128777973",
            weight = 10
        } },
    point = { {
            id = "http://www.roblox.com/asset/?id=128853357",
            weight = 10
        } },
    dance1 = { {
            id = "http://www.roblox.com/asset/?id=182435998",
            weight = 10
        }, {
            id = "http://www.roblox.com/asset/?id=182491037",
            weight = 10
        }, {
            id = "http://www.roblox.com/asset/?id=182491065",
            weight = 10
        } },
    dance2 = { {
            id = "http://www.roblox.com/asset/?id=182436842",
            weight = 10
        }, {
            id = "http://www.roblox.com/asset/?id=182491248",
            weight = 10
        }, {
            id = "http://www.roblox.com/asset/?id=182491277",
            weight = 10
        } },
    dance3 = { {
            id = "http://www.roblox.com/asset/?id=182436935",
            weight = 10
        }, {
            id = "http://www.roblox.com/asset/?id=182491368",
            weight = 10
        }, {
            id = "http://www.roblox.com/asset/?id=182491423",
            weight = 10
        } },
    laugh = { {
            id = "http://www.roblox.com/asset/?id=129423131",
            weight = 10
        } },
    cheer = { {
            id = "http://www.roblox.com/asset/?id=129423030",
            weight = 10
        } }
};

function configureAnimationSet(u7, u8)
    -- upvalues: u5 (copy)
    if u5[u7] ~= nil then
        for _, v in pairs(u5[u7].connections) do
            v:disconnect();
        end;
    end;

    u5[u7] = {};
    u5[u7].count = 0;
    u5[u7].totalWeight = 0;
    u5[u7].connections = {};
    local v9 = script:FindFirstChild(u7);

    if v9 ~= nil then
        table.insert(u5[u7].connections, v9.ChildAdded:connect(function(p10) -- Line: 98
            -- upvalues: u7 (copy), u8 (copy)
            configureAnimationSet(u7, u8);
        end));
        table.insert(u5[u7].connections, v9.ChildRemoved:connect(function(p11) -- Line: 99
            -- upvalues: u7 (copy), u8 (copy)
            configureAnimationSet(u7, u8);
        end));
        local v12 = 1;

        for _, child in pairs(v9:GetChildren()) do
            if child:IsA("Animation") then
                table.insert(u5[u7].connections, child.Changed:connect(function(p13) -- Line: 103
                    -- upvalues: u7 (copy), u8 (copy)
                    configureAnimationSet(u7, u8);
                end));
                u5[u7][v12] = {};
                u5[u7][v12].anim = child;
                local Weight = child:FindFirstChild("Weight");

                if Weight == nil then
                    u5[u7][v12].weight = 1;
                else
                    u5[u7][v12].weight = Weight.Value;
                end;

                u5[u7].count = u5[u7].count + 1;
                u5[u7].totalWeight = u5[u7].totalWeight + u5[u7][v12].weight;
                v12 = v12 + 1;
            end;
        end;
    end;

    if u5[u7].count <= 0 then
        for i, v in pairs(u8) do
            u5[u7][i] = {};
            u5[u7][i].anim = Instance.new("Animation");
            u5[u7][i].anim.Name = u7;
            u5[u7][i].anim.AnimationId = v.id;
            u5[u7][i].weight = v.weight;
            u5[u7].count = u5[u7].count + 1;
            u5[u7].totalWeight = u5[u7].totalWeight + v.weight;
        end;
    end;
end;

function scriptChildModified(p14)
    -- upvalues: u6 (copy)
    local v15 = u6[p14.Name];

    if v15 ~= nil then
        configureAnimationSet(p14.Name, v15);
    end;
end;

script.ChildAdded:connect(scriptChildModified);
script.ChildRemoved:connect(scriptChildModified);
local u16 = { "dance1", "dance2", "dance3" };
local u17 = "Standing";
local u18 = nil;
local u19 = nil;
local u20 = nil;
local u21 = "";
local u22 = {
    wave = false,
    point = false,
    dance1 = true,
    dance2 = true,
    dance3 = true,
    laugh = false,
    cheer = false
};
local u23 = 1;

for i, v in pairs(u6) do
    configureAnimationSet(i, v);
end;

local u24 = "None";
local u25 = 0;
local u26 = 0;

function stopAllAnimations()
    -- upvalues: u21 (ref), u22 (copy), u18 (ref), u19 (ref), u20 (ref)
    local v27 = u21;
    local v28 = u22[v27] ~= nil and u22[v27] == false and "idle" or v27;
    u21 = "";
    u18 = nil;

    if u19 ~= nil then
        u19:disconnect();
    end;

    if u20 ~= nil then
        u20:Stop();
        u20:Destroy();
        u20 = nil;
    end;

    return v28;
end;

function setAnimationSpeed(p29)
    -- upvalues: u23 (ref), u20 (ref)
    if p29 ~= u23 then
        u23 = p29;
        u20:AdjustSpeed(u23);
    end;
end;

function keyFrameReachedFunc(p30)
    -- upvalues: u21 (ref), u22 (copy), u23 (ref), Humanoid (copy)
    if p30 == "End" then
        local v31 = u21;
        playAnimation(u22[v31] ~= nil and u22[v31] == false and "idle" or v31, 0, Humanoid);
        setAnimationSpeed(u23);
    end;
end;

function playAnimation(p32, p33, p34)
    -- upvalues: u5 (copy), u18 (ref), u20 (ref), u23 (ref), u21 (ref), u19 (ref)
    local math_random_ret = math.random(1, u5[p32].totalWeight);
    local v35 = 1;

    while u5[p32][v35].weight < math_random_ret do
        math_random_ret = math_random_ret - u5[p32][v35].weight;
        v35 = v35 + 1;
    end;

    local anim = u5[p32][v35].anim;

    if anim ~= u18 then
        if u20 ~= nil then
            u20:Stop(p33);
            u20:Destroy();
        end;

        u23 = 1;
        u20 = p34:LoadAnimation(anim);

        if p32 == "jump" then
            u20.Priority = Enum.AnimationPriority.Action;
        else
            u20.Priority = Enum.AnimationPriority.Core;
        end;

        u20:Play(p33);
        u21 = p32;
        u18 = anim;

        if u19 ~= nil then
            u19:disconnect();
        end;

        u19 = u20.KeyframeReached:connect(keyFrameReachedFunc);
    end;
end;

local u36 = "";
local u37 = nil;
local u38 = nil;
local u39 = nil;

function toolKeyFrameReachedFunc(p40)
    -- upvalues: u36 (ref), Humanoid (copy)
    if p40 == "End" then
        playToolAnimation(u36, 0, Humanoid);
    end;
end;

function playToolAnimation(p41, p42, p43, p44)
    -- upvalues: u5 (copy), u38 (ref), u37 (ref), u36 (ref), u39 (ref)
    local math_random_ret = math.random(1, u5[p41].totalWeight);
    local v45 = 1;

    while u5[p41][v45].weight < math_random_ret do
        math_random_ret = math_random_ret - u5[p41][v45].weight;
        v45 = v45 + 1;
    end;

    local anim = u5[p41][v45].anim;

    if u38 ~= anim then
        if u37 ~= nil then
            u37:Stop();
            u37:Destroy();
            p42 = 0;
        end;

        u37 = p43:LoadAnimation(anim);

        if p44 then
            u37.Priority = p44;
        end;

        u37:Play(p42);
        u36 = p41;
        u38 = anim;
        u39 = u37.KeyframeReached:connect(toolKeyFrameReachedFunc);
    end;
end;

function stopToolAnimations()
    -- upvalues: u36 (ref), u39 (ref), u38 (ref), u37 (ref)
    local v46 = u36;

    if u39 ~= nil then
        u39:disconnect();
    end;

    u36 = "";
    u38 = nil;

    if u37 ~= nil then
        u37:Stop();
        u37:Destroy();
        u37 = nil;
    end;

    return v46;
end;

function onRunning(p47)
    -- upvalues: Humanoid (copy), u18 (ref), u17 (ref), u22 (copy), u21 (ref)
    if p47 <= 0.01 then
        if u22[u21] == nil then
            playAnimation("idle", 0.1, Humanoid);
            u17 = "Standing";
        end;

        return;
    end;

    playAnimation("walk", 0.1, Humanoid);

    if u18 and u18.AnimationId == "http://www.roblox.com/asset/?id=180426354" then
        setAnimationSpeed(p47 / 14.5);
    end;

    u17 = "Running";
end;

function onDied()
    -- upvalues: u17 (ref)
    u17 = "Dead";
end;

function onJumping()
    -- upvalues: Humanoid (copy), u26 (ref), u17 (ref)
    playAnimation("jump", 0.1, Humanoid);
    u26 = 0.3;
    u17 = "Jumping";
end;

function onClimbing(p48)
    -- upvalues: Humanoid (copy), u17 (ref)
    playAnimation("climb", 0.1, Humanoid);
    setAnimationSpeed(p48 / 12);
    u17 = "Climbing";
end;

function onGettingUp()
    -- upvalues: u17 (ref)
    u17 = "GettingUp";
end;

function onFreeFall()
    -- upvalues: u26 (ref), Humanoid (copy), u17 (ref)
    if u26 <= 0 then
        playAnimation("fall", 0.3, Humanoid);
    end;

    u17 = "FreeFall";
end;

function onFallingDown()
    -- upvalues: u17 (ref)
    u17 = "FallingDown";
end;

function onSeated()
    -- upvalues: u17 (ref)
    u17 = "Seated";
end;

function onPlatformStanding()
    -- upvalues: u17 (ref)
    u17 = "PlatformStanding";
end;

function onSwimming(p49)
    -- upvalues: u17 (ref)
    if p49 > 0 then
        u17 = "Running";

        return;
    end;

    u17 = "Standing";
end;

function getTool()
    -- upvalues: script_Parent (copy)
    for _, child in ipairs(script_Parent:GetChildren()) do
        if child.className == "Tool" then
            return child;
        end;
    end;

    return nil;
end;

function getToolAnim(p50)
    for _, child in ipairs(p50:GetChildren()) do
        if child.Name == "toolanim" and child.className == "StringValue" then
            return child;
        end;
    end;

    return nil;
end;

function animateTool()
    -- upvalues: u24 (ref), Humanoid (copy)
    if u24 == "None" then
        playToolAnimation("toolnone", 0.1, Humanoid, Enum.AnimationPriority.Idle);

        return;
    end;

    if u24 == "Slash" then
        playToolAnimation("toolslash", 0, Humanoid, Enum.AnimationPriority.Action);

        return;
    end;

    if u24 ~= "Lunge" then
        return;
    end;

    playToolAnimation("toollunge", 0, Humanoid, Enum.AnimationPriority.Action);
end;

function moveSit()
    -- upvalues: u1 (copy), u2 (copy), u3 (copy), u4 (copy)
    u1.MaxVelocity = 0.15;
    u2.MaxVelocity = 0.15;
    u1:SetDesiredAngle(1.57);
    u2:SetDesiredAngle(-1.57);
    u3:SetDesiredAngle(1.57);
    u4:SetDesiredAngle(-1.57);
end;

local u51 = 0;

function move(p52)
    -- upvalues: u51 (ref), u26 (ref), u17 (ref), Humanoid (copy), u1 (copy), u2 (copy), u3 (copy), u4 (copy), u24 (ref), u25 (ref), u38 (ref)
    local v53 = 1;
    local v54 = 1;
    local v55 = p52 - u51;
    u51 = p52;
    local v56 = false;

    if u26 > 0 then
        u26 = u26 - v55;
    end;

    if u17 == "FreeFall" and u26 <= 0 then
        playAnimation("fall", 0.3, Humanoid);
    else
        if u17 == "Seated" then
            playAnimation("sit", 0.5, Humanoid);

            return;
        end;

        if u17 == "Running" then
            playAnimation("walk", 0.1, Humanoid);
        elseif u17 == "Dead" or (u17 == "GettingUp" or (u17 == "FallingDown" or (u17 == "Seated" or u17 == "PlatformStanding"))) then
            stopAllAnimations();
            v56 = true;
            v54 = 1;
            v53 = 0.1;
        end;
    end;

    if v56 then
        local v57 = v53 * math.sin(p52 * v54);
        u1:SetDesiredAngle(v57 + 0);
        u2:SetDesiredAngle(v57 - 0);
        u3:SetDesiredAngle(-v57);
        u4:SetDesiredAngle(-v57);
    end;

    local v58 = getTool();

    if v58 and v58:FindFirstChild("Handle") then
        local v59 = getToolAnim(v58);

        if v59 then
            u24 = v59.Value;
            v59.Parent = nil;
            u25 = p52 + 0.3;
        end;

        if u25 < p52 then
            u25 = 0;
            u24 = "None";
        end;

        animateTool();

        return;
    end;

    stopToolAnimations();
    u24 = "None";
    u38 = nil;
    u25 = 0;
end;

Humanoid.Died:connect(onDied);
Humanoid.Running:connect(onRunning);
Humanoid.Jumping:connect(onJumping);
Humanoid.Climbing:connect(onClimbing);
Humanoid.GettingUp:connect(onGettingUp);
Humanoid.FreeFalling:connect(onFreeFall);
Humanoid.FallingDown:connect(onFallingDown);
Humanoid.Seated:connect(onSeated);
Humanoid.PlatformStanding:connect(onPlatformStanding);
Humanoid.Swimming:connect(onSwimming);
game:GetService("Players").LocalPlayer.Chatted:connect(function(p60) -- Line: 515
    -- upvalues: u16 (copy), u17 (ref), u22 (copy), Humanoid (copy)
    local v61 = "";

    if p60 == "/e dance" then
        v61 = u16[math.random(1, #u16)];
    elseif string.sub(p60, 1, 3) == "/e " then
        v61 = string.sub(p60, 4);
    elseif string.sub(p60, 1, 7) == "/emote " then
        v61 = string.sub(p60, 8);
    end;

    if u17 == "Standing" and u22[v61] ~= nil then
        playAnimation(v61, 0.1, Humanoid);
    end;
end);
playAnimation("idle", 0.1, Humanoid);
u17 = "Standing";

while script_Parent.Parent ~= nil do
    local _, v62 = wait(0.1);
    move(v62);
end;