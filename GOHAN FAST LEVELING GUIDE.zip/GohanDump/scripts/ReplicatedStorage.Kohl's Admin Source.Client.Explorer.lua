-- Decompiled with Potassium's decompiler.

local Parent = require(script.Parent.Parent);
local UI = require(script.Parent:WaitForChild("UI"));
local ExplorerOrder = require(script:WaitForChild("ExplorerOrder"));
local ContentProvider = game:GetService("ContentProvider");
local ReflectionService = game:GetService("ReflectionService");
local u1 = {
    Active = false,
    StartPos = Vector3.new(0, 0, 0),
    Ghost = nil,
    TargetNode = nil
};
local u2 = {};
local u3 = {};
local u4 = setmetatable({
    [game] = {
        AncestorExpanded = true,
        Expanded = true,
        Instance = game
    }
}, {
    __mode = "k"
});
local u5 = nil;
local u6 = nil;

local function isService(p7: userdata) -- Line: 22
    -- upvalues: ReflectionService (copy)
    local Class = ReflectionService:GetClass(p7.ClassName);

    return Class and Class.Permits and Class.Permits.GetService;
end;

local function setAncestorExpanded(p8, p9) -- Line: 27
    -- upvalues: u4 (copy), setAncestorExpanded (copy)
    if not p8.Expanded then
        p9 = false;
    end;

    for _, child in p8.Instance:GetChildren() do
        local v10 = u4[child];

        if v10 then
            v10.AncestorExpanded = p9;
            setAncestorExpanded(v10, p9);
        end;
    end;
end;

local function getFallbackIcon(p11: userdata) -- Line: 38
    -- upvalues: ReflectionService (copy)
    local Class = ReflectionService:GetClass(p11.ClassName);

    return `rbxasset://studio_svg_textures/Shared/{Class and Class.Permits and Class.Permits.GetService and "InsertableObjects/Dark/Standard/Service" or "Placeholder/Dark/Standard/Placeholder"}.png`;
end;

local u12 = {};

local function getClassIcon(p13: userdata) -- Line: 47
    -- upvalues: u12 (copy), ReflectionService (copy)
    local v14 = u12[p13.ClassName];

    if v14 == nil then
        return `rbxasset://studio_svg_textures/Shared/InsertableObjects/Dark/Standard/{p13.ClassName}.png`;
    end;

    if not v14 then
        local Class = ReflectionService:GetClass(p13.ClassName);
        v14 = `rbxasset://studio_svg_textures/Shared/{Class and Class.Permits and Class.Permits.GetService and "InsertableObjects/Dark/Standard/Service" or "Placeholder/Dark/Standard/Placeholder"}.png`;
    end;

    return v14;
end;

local function setClassIcon(u15: any, u16: userdata) -- Line: 56
    -- upvalues: u12 (copy), ReflectionService (copy), ContentProvider (copy)
    local v17 = u12[u16.ClassName];

    if v17 ~= nil then
        local ImageLabel = u15._instance.IconFrame.ImageLabel;

        if not v17 then
            local Class = ReflectionService:GetClass(u16.ClassName);
            v17 = `rbxasset://studio_svg_textures/Shared/{Class and Class.Permits and Class.Permits.GetService and "InsertableObjects/Dark/Standard/Service" or "Placeholder/Dark/Standard/Placeholder"}.png`;
        end;

        ImageLabel.Image = v17;

        return;
    end;

    u15._instance.IconFrame.ImageLabel.Image = "rbxasset://studio_svg_textures/Shared/Placeholder/Dark/Standard/Placeholder.png";
    local v18 = `rbxasset://studio_svg_textures/Shared/InsertableObjects/Dark/Standard/{u16.ClassName}.png`;
    local Decal = Instance.new("Decal");
    Decal.Texture = v18;
    task.spawn(ContentProvider.PreloadAsync, ContentProvider, { Decal }, function(p19: string, p20: any) -- Line: 74
        -- upvalues: u12 (ref), u16 (copy), u15 (copy), ReflectionService (ref)
        if p20 == Enum.AssetFetchStatus.Success then
            u12[u16.ClassName] = p19;

            if u15.node.Instance == u16 then
                u15._instance.IconFrame.ImageLabel.Image = p19;
            end;
        elseif p20 == Enum.AssetFetchStatus.Failure or p20 == Enum.AssetFetchStatus.TimedOut then
            u12[u16.ClassName] = false;

            if u15.node.Instance == u16 then
                local ImageLabel = u15._instance.IconFrame.ImageLabel;
                local Class = ReflectionService:GetClass(u16.ClassName);
                ImageLabel.Image = `rbxasset://studio_svg_textures/Shared/{Class and Class.Permits and Class.Permits.GetService and "InsertableObjects/Dark/Standard/Service" or "Placeholder/Dark/Standard/Placeholder"}.png`;
            end;
        end;
    end);
end;

local function sortChildren(p21, p22) -- Line: 90
    -- upvalues: ExplorerOrder (copy)
    local v23 = ExplorerOrder[p21.ClassName];
    local v24 = ExplorerOrder[p22.ClassName];

    if v23 and (v24 and v23 ~= v24) then
        return v23 < v24;
    end;

    if p21.ClassName == p22.ClassName then
        return p21.Name < p22.Name;
    end;

    return p21.ClassName < p22.ClassName;
end;

local function sortNodes(p25: userdata, p26: userdata) -- Line: 102
    -- upvalues: u4 (copy)
    local v27 = u4[p25];
    local v28 = u4[p26];

    if v27 and v28 then
        return v27.Index < v28.Index;
    end;

    return false;
end;

local function traverse(p29: userdata, p30: number, p31: boolean?) -- Line: 110
    -- upvalues: u4 (copy), sortChildren (copy), traverse (copy)
    local v32 = u4[p29];

    if not (v32 and (v32.AncestorExpanded or p31)) then
        return p30;
    end;

    v32.Index = p30;
    local Children = p29:GetChildren();
    table.sort(Children, sortChildren);

    for _, v in Children do
        p30 = traverse(v, p30 + 1, p31);
    end;

    return p30;
end;

local function instanceRemoving(p33: userdata) -- Line: 128
    -- upvalues: u4 (copy), u6 (ref), u5 (ref)
    local v34 = p33.Parent and u4[p33.Parent];

    if v34 and v34.Expanded then
        u6(u5);
    end;
end;

local function check(p35: userdata) -- Line: 135
    return p35.AncestryChanged;
end;

local function isAncestorExpanded(p36: userdata) -- Line: 139
    -- upvalues: u4 (copy)
    if p36 == game then
        return true;
    end;

    local Parent2 = p36.Parent;

    while Parent2 do
        if Parent2 == game then
            return true;
        end;

        local v37 = u4[Parent2];

        if v37 and not v37.Expanded then
            return false;
        end;

        Parent2 = Parent2.Parent;
    end;

    return false;
end;

local function removeNode(p38) -- Line: 159
    -- upvalues: u4 (copy), Parent (copy)
    local v39 = u4[p38];

    if v39 then
        if Parent and (Parent.Flux and Parent.Flux.cleanup) then
            Parent.Flux.cleanup(v39);
        end;

        u4[p38] = nil;
    end;

    for _, descendant in p38:GetDescendants() do
        local v40 = u4[descendant];

        if v40 then
            if Parent and (Parent.Flux and Parent.Flux.cleanup) then
                Parent.Flux.cleanup(v40);
            end;

            u4[descendant] = nil;
        end;
    end;
end;

local function instanceAdded(u41: userdata, p42: userdata?) -- Line: 179
    -- upvalues: check (copy), u4 (copy), removeNode (copy), isAncestorExpanded (copy), u6 (ref), u5 (ref), instanceAdded (copy)
    if not pcall(check, u41) then
        return;
    end;

    local v43 = p42 or u41.Parent;

    if not v43 then
        if u4[u41] then
            removeNode(u41);

            if isAncestorExpanded(u41) then
                u6(u5);
            end;
        end;

        return;
    end;

    local v44 = v43;
    local v45 = { u41 };

    while v43 do
        table.insert(v45, v43);
        v43 = v43.Parent;
    end;

    for i = #v45 - 1, 1, -1 do
        local v46 = v45[i];
        local v47 = u4[v46];

        if not v47 then
            v47 = {
                Expanded = false,
                Selected = false,
                Index = 0,
                AncestorExpanded = isAncestorExpanded(v46),
                Instance = v46
            };
            u4[v46] = v47;
        end;

        v47.Depth = #v45 - i - 1;
        local _ = i;
    end;

    local v48 = u4[u41];

    if v48 then
        v48.AncestorExpanded = isAncestorExpanded(u41);

        if not v48.Connection then
            v48.Connection = true;
            u41.AncestryChanged:Connect(instanceAdded);
            u41.Destroying:Connect(function() -- Line: 228
                -- upvalues: u41 (copy), u4 (ref), u6 (ref), u5 (ref), removeNode (ref)
                local v49 = u41.Parent and u4[u41.Parent];

                if v49 and v49.Expanded then
                    u6(u5);
                end;

                removeNode(u41);
            end);
        end;
    end;

    local v50 = u4[v44];

    if v50 and v50.Expanded then
        u6(u5);
    end;
end;

local function parentInstanceUnsafe(p51: userdata, p52: userdata?) -- Line: 244
    p51.Parent = p52;
end;

local function cloneInstanceUnsafe(p53: any, p54: userdata?) -- Line: 248
    local v55 = p53:Clone();
    v55.Parent = p54;

    return v55;
end;

local function COPY() -- Line: 255
    -- upvalues: u2 (copy), u3 (copy), cloneInstanceUnsafe (copy)
    table.clear(u2);

    for _, v in u3 do
        if pcall(cloneInstanceUnsafe, v.Instance) then
            table.insert(u2, v.Instance);
        end;
    end;
end;

local function DELETE() -- Line: 264
    -- upvalues: u3 (copy), Parent (copy)
    local table_create_ret = table.create(#u3);

    for _, v in u3 do
        table.insert(table_create_ret, v.Instance);
    end;

    Parent.Remote.Explorer:Fire("DELETE", table_create_ret);

    for _, v in u3 do
        if not v.Instance:IsA("Player") then
            pcall(game.Destroy, v.Instance);
        end;
    end;

    table.clear(u3);
end;

local function PASTE() -- Line: 280
    -- upvalues: u3 (copy), Parent (copy), u2 (copy), setAncestorExpanded (copy), u6 (ref), u5 (ref)
    local v56 = u3[1];
    Parent.Remote.Explorer:Fire("PASTE", u2, v56.Instance);

    if not v56.Expanded then
        v56.Expanded = true;
        setAncestorExpanded(v56, true);
    end;

    u6(u5);
end;

local u57 = UI.compute(function() -- Line: 292
    -- upvalues: UI (copy)
    return UI.Theme.FontSize() + UI.Theme.Padding().Offset * 2;
end);

local function u58() -- Line: 296
    -- upvalues: u57 (copy)
    return UDim2.fromOffset(u57(), u57());
end;

local function Initialize() -- Line: 300
    -- upvalues: UI (copy), u58 (copy), DELETE (copy), COPY (copy), PASTE (copy), u1 (copy), u3 (copy), u12 (copy), ReflectionService (copy), parentInstanceUnsafe (copy), setAncestorExpanded (copy), u6 (ref), u5 (ref), Parent (copy), u2 (copy), u4 (copy), setClassIcon (copy), ExplorerOrder (copy), traverse (copy), sortNodes (copy), instanceAdded (copy), instanceRemoving (copy)
    local u59 = UI.new("Window")({
        Parent = UI.LayerTopInset,
        Icon = "rbxassetid://71961243872230",
        Name = "Explorer",
        Title = "Explorer",
        UI.new("UIListLayout")({
            Padding = UI.Theme.Padding
        })
    });
    local TitleBar = u59._instance.Frame.TitleBar;
    local v60 = UI.new("Button")({
        LayoutOrder = 4,
        Parent = TitleBar,
        Icon = UI.Theme.Image.Delete,
        IconProperties = {
            ImageColor3 = UI.Theme.PrimaryText,
            Size = UDim2.fromScale(0.625, 0.625)
        },
        Size = u58,
        Activated = DELETE
    });
    UI.new("Tooltip")({
        Text = "Delete",
        Parent = v60,
        Hovering = v60._hovering
    });
    local v61 = UI.new("Button")({
        LayoutOrder = 6,
        Parent = TitleBar,
        Icon = UI.Theme.Image.Copy,
        IconProperties = {
            ImageColor3 = UI.Theme.PrimaryText,
            Size = UDim2.fromScale(0.625, 0.625)
        },
        Size = u58,
        Activated = COPY
    });
    UI.new("Tooltip")({
        Text = "Copy",
        Parent = v61,
        Hovering = v61._hovering
    });
    local v62 = UI.new("Button")({
        LayoutOrder = 7,
        Parent = TitleBar,
        Icon = UI.Theme.Image.Paste,
        IconProperties = {
            ImageColor3 = UI.Theme.PrimaryText,
            Size = UDim2.fromScale(0.625, 0.625)
        },
        Size = u58,
        Activated = PASTE
    });
    UI.new("Tooltip")({
        Text = "Paste",
        Parent = v62,
        Hovering = v62._hovering
    });
    local UDim2_new_ret = UDim2.new(1, 0, 0, 20);

    local function createGhost() -- Line: 358
        -- upvalues: u1 (ref), UI (ref), u3 (ref), u12 (ref), ReflectionService (ref)
        if u1.Ghost then
            u1.Ghost:Destroy();
        end;

        local v63 = UI.new("Frame")({
            Parent = UI.LayerTop,
            BackgroundTransparency = 1,
            Active = false,
            AutomaticSize = Enum.AutomaticSize.XY,
            Size = UDim2.new(),
            UI.new("UIListLayout")({
                SortOrder = Enum.SortOrder.LayoutOrder
            })
        });

        for i, v in u3 do
            if v.Depth > 0 then
                local Frame = UI.new("Frame");
                local v64 = {
                    LayoutOrder = i,
                    Parent = v63,
                    AutomaticSize = Enum.AutomaticSize.X,
                    BackgroundTransparency = 1,
                    Size = UDim2.new(0, 0, 0, 20)
                };
                local v65 = UI.new("UIListLayout")({
                    FillDirection = Enum.FillDirection.Horizontal,
                    SortOrder = Enum.SortOrder.LayoutOrder,
                    VerticalAlignment = Enum.VerticalAlignment.Center
                });
                local Frame2 = UI.new("Frame");
                local v66 = {
                    Name = "IconFrame",
                    BackgroundTransparency = 1,
                    Size = UDim2.fromOffset(20, 20)
                };
                local ImageLabel = UI.new("ImageLabel");
                local v67 = {
                    BackgroundTransparency = 1,
                    ImageTransparency = 0.25,
                    AnchorPoint = Vector2.new(0, 0.5),
                    Position = UDim2.fromScale(0, 0.5),
                    Size = UDim2.fromOffset(16, 16)
                };
                local Instance2 = v.Instance;
                local v68 = u12[Instance2.ClassName];

                if v68 == nil then
                    v68 = `rbxasset://studio_svg_textures/Shared/InsertableObjects/Dark/Standard/{Instance2.ClassName}.png`;
                elseif not v68 then
                    local Class = ReflectionService:GetClass(Instance2.ClassName);
                    v68 = `rbxasset://studio_svg_textures/Shared/{Class and Class.Permits and Class.Permits.GetService and "InsertableObjects/Dark/Standard/Service" or "Placeholder/Dark/Standard/Placeholder"}.png`;
                end;

                v67.Image = v68;
                v66[1] = ImageLabel(v67);
                v64[1], v64[2], v64[3] = v65, Frame2(v66), UI.new("TextLabel")({
    BackgroundTransparency = 1,
    TextSize = 16,
    TextTransparency = 0.25,
    AutomaticSize = Enum.AutomaticSize.X,
    Font = Enum.Font.SourceSans,
    Text = v.Instance.Name,
    TextColor3 = UI.Theme.PrimaryText,
    TextStrokeColor3 = UI.Theme.Primary,
    TextStrokeTransparency = UI.Theme.TextStrokeTransparency,
    TextTruncate = Enum.TextTruncate.SplitWord,
    Size = UDim2.new(0, 0, 1, 0),
    TextXAlignment = Enum.TextXAlignment.Left
});
                Frame(v64);
            end;
        end;

        u1.Ghost = v63;
    end;

    local function updateGhost(p69: vector) -- Line: 426
        -- upvalues: u1 (ref), UI (ref)
        if u1.Ghost then
            u1.Ghost.Position = UDim2.fromOffset(p69.X + 6, p69.Y - 10 + UI.TopbarInset._value.Height);
        end;
    end;

    local function executeReparent() -- Line: 432
        -- upvalues: u1 (ref), u3 (ref), ReflectionService (ref), parentInstanceUnsafe (ref), setAncestorExpanded (ref), u6 (ref), u5 (ref)
        if not (u1.TargetNode and u1.TargetNode.Instance) then
            return;
        end;

        local Instance2 = u1.TargetNode.Instance;
        local v70 = false;

        for _, v in u3 do
            local Instance3 = v.Instance;

            if Instance3 ~= Instance2 then
                local Class = ReflectionService:GetClass(Instance3.ClassName);

                if not (Class and Class.Permits and Class.Permits.GetService or (Instance2:IsDescendantOf(Instance3) or Instance3.Parent == Instance2)) then
                    pcall(parentInstanceUnsafe, Instance3, Instance2);
                    v70 = true;
                end;
            end;
        end;

        if v70 and u1.TargetNode then
            u1.TargetNode.Expanded = true;
            setAncestorExpanded(u1.TargetNode, u1.TargetNode.Expanded);
            u6(u5);
        end;
    end;

    UI.UserInputService.InputChanged:Connect(function(p71, p72) -- Line: 455
        -- upvalues: u1 (ref), UI (ref)
        if p71.UserInputType == Enum.UserInputType.MouseMovement and u1.Active then
            local Position = p71.Position;

            if u1.Ghost then
                u1.Ghost.Position = UDim2.fromOffset(Position.X + 6, Position.Y - 10 + UI.TopbarInset._value.Height);
            end;
        end;
    end);
    UI.UserInputService.InputEnded:Connect(function(p73) -- Line: 463
        -- upvalues: u1 (ref), executeReparent (copy)
        if p73.UserInputType == Enum.UserInputType.MouseButton1 and u1.Active then
            executeReparent();
            u1.Active = false;
            u1.TargetNode = nil;

            if u1.Ghost then
                u1.Ghost:Destroy();
                u1.Ghost = nil;
            end;
        end;
    end);
    UI.UserInputService.InputBegan:Connect(function(p74: userdata) -- Line: 477
        -- upvalues: UI (ref), COPY (ref), u3 (ref), Parent (ref), u2 (ref), setAncestorExpanded (ref), u6 (ref), u5 (ref), DELETE (ref)
        if p74.UserInputType == Enum.UserInputType.Keyboard then
            local v75 = UI.UserInputService:IsKeyDown(Enum.KeyCode.LeftControl);

            if p74.KeyCode == Enum.KeyCode.C and v75 then
                COPY();

                return;
            end;

            if p74.KeyCode == Enum.KeyCode.V and v75 then
                local v76 = u3[1];
                Parent.Remote.Explorer:Fire("PASTE", u2, v76.Instance);

                if not v76.Expanded then
                    v76.Expanded = true;
                    setAncestorExpanded(v76, true);
                end;

                u6(u5);

                return;
            end;

            if p74.KeyCode == Enum.KeyCode.Delete then
                DELETE();
            end;
        end;
    end);
    u5 = UI.new("ScrollerFast")({
        DictList = true,
        Enabled = true,
        FilterInput = true,
        Visible = true,
        Parent = u59,
        List = u4,
        ItemSize = UDim2_new_ret,

        CreateItem = function(p77) -- Line: 498, Name: CreateItem
            -- upvalues: UI (ref), u59 (copy), UDim2_new_ret (copy), setAncestorExpanded (ref), u5 (ref), u3 (ref), u1 (ref), createGhost (copy)
            local u78 = {};
            local u79 = 0;
            u78._instance = UI.new("TextButton")({
                Parent = u59._content,
                AutoButtonColor = false,
                BackgroundColor3 = UI.Theme.Secondary,
                BackgroundTransparency = 1,
                BorderSizePixel = 0,
                TextTransparency = 1,
                Size = UDim2_new_ret,
                UI.new("UIPadding")({}),
                UI.new("UIListLayout")({
                    FillDirection = Enum.FillDirection.Horizontal,
                    SortOrder = Enum.SortOrder.LayoutOrder,
                    VerticalAlignment = Enum.VerticalAlignment.Center
                }),
                UI.new("TextButton")({
                    Name = "Expand",
                    BackgroundTransparency = 1,
                    TextTransparency = 1,
                    Size = UDim2.fromOffset(20, 20),
                    UI.new("ImageLabel")({
                        BackgroundTransparency = 1,
                        Rotation = -90,
                        AnchorPoint = Vector2.new(0.5, 0.5),
                        Position = UDim2.fromScale(0.5, 0.5),
                        Size = UDim2.fromOffset(8, 8),
                        Image = UI.Theme.Image.Down
                    }),

                    Activated = function() -- Line: 533, Name: Activated
                        -- upvalues: u78 (copy), setAncestorExpanded (ref), u5 (ref)
                        if u78._instance.Expand.ImageLabel.Visible then
                            u78.node.Expanded = not u78.node.Expanded;
                            setAncestorExpanded(u78.node, u78.node.Expanded);
                            u5:refreshList();
                        end;
                    end
                }),
                UI.new("Frame")({
                    Name = "IconFrame",
                    BackgroundTransparency = 1,
                    Size = UDim2.fromOffset(20, 20),
                    UI.new("ImageLabel")({
                        BackgroundTransparency = 1,
                        AnchorPoint = Vector2.new(0, 0.5),
                        Position = UDim2.fromScale(0, 0.5),
                        Size = UDim2.fromOffset(16, 16),
                        Image = UI.Theme.Image.Add
                    })
                }),
                UI.new("TextLabel")({
                    BackgroundTransparency = 1,
                    TextSize = 16,
                    Font = Enum.Font.SourceSans,
                    TextColor3 = UI.Theme.PrimaryText,
                    TextStrokeColor3 = UI.Theme.Primary,
                    TextStrokeTransparency = UI.Theme.TextStrokeTransparency,
                    TextTruncate = Enum.TextTruncate.SplitWord,
                    Size = UDim2.new(1, -40, 1, 0),
                    TextXAlignment = Enum.TextXAlignment.Left
                }),

                Activated = function() -- Line: 570, Name: Activated
                    -- upvalues: u78 (copy), u79 (ref), setAncestorExpanded (ref), u5 (ref), UI (ref), u3 (ref)
                    if u78._instance.Expand.ImageLabel.Visible then
                        local v80 = u79;
                        u79 = os.clock();

                        if u79 - v80 < 0.3 then
                            u78.node.Expanded = not u78.node.Expanded;
                            setAncestorExpanded(u78.node, u78.node.Expanded);
                            u5:refreshList();

                            return;
                        end;
                    end;

                    if UI.UserInputService:IsKeyDown(Enum.KeyCode.LeftControl) or UI.UserInputService:IsKeyDown(Enum.KeyCode.LeftShift) then
                        u78.node.Selected = not u78.node.Selected;

                        if u78.node.Selected then
                            table.insert(u3, u78.node);
                            u78._instance.BackgroundTransparency = 0.75;

                            return;
                        end;

                        local table_find_ret = table.find(u3, u78.node);

                        if table_find_ret then
                            table.remove(u3, table_find_ret);
                            u78._instance.BackgroundTransparency = 0.9;
                        end;
                    else
                        for _, v in u5._lineItemCache do
                            v._instance.BackgroundTransparency = 1;
                        end;

                        for _, v in u5._lineItemFree do
                            v._instance.BackgroundTransparency = 1;
                        end;

                        for _, v in u3 do
                            v.Selected = false;
                        end;

                        table.clear(u3);
                        u78.node.Selected = true;
                        table.insert(u3, u78.node);
                        u78._instance.BackgroundTransparency = 0.75;
                    end;
                end,

                TouchLongPress = function(p81, p82) -- Line: 615, Name: TouchLongPress
                    -- upvalues: u1 (ref)
                    u1.StartPos = p81.Position;
                end,

                InputBegan = function(p83, p84) -- Line: 619, Name: InputBegan
                    -- upvalues: u1 (ref)
                    if p83.UserInputType == Enum.UserInputType.MouseButton1 then
                        u1.StartPos = p83.Position;
                    end;
                end,

                InputChanged = function(p85, p86) -- Line: 625, Name: InputChanged
                    -- upvalues: u1 (ref), UI (ref), u78 (copy), u3 (ref), u5 (ref), createGhost (ref)
                    if p85.UserInputType == Enum.UserInputType.MouseMovement and (not u1.Active and (UI.UserInputService:IsMouseButtonPressed(Enum.UserInputType.MouseButton1) and (u78.node and (u78.node.Depth > 0 and (p85.Position - u1.StartPos).Magnitude > 5)))) then
                        u1.Active = true;

                        if u78.node and not u78.node.Selected then
                            for _, v in u3 do
                                v.Selected = false;
                            end;

                            table.clear(u3);
                            u78.node.Selected = true;
                            table.insert(u3, u78.node);
                            u5:refreshList();
                        end;

                        createGhost();
                        local Position = p85.Position;

                        if u1.Ghost then
                            u1.Ghost.Position = UDim2.fromOffset(Position.X + 6, Position.Y - 10 + UI.TopbarInset._value.Height);
                        end;
                    end;
                end
            });
            u78.hovering = UI.newSinkHoverState(u78._instance);
            UI.edit(u78._instance, {
                BackgroundTransparency = UI.compute(function() -- Line: 657
                    -- upvalues: u78 (copy), u1 (ref)
                    local v87 = u78.hovering();

                    if v87 and u1.Active then
                        u1.TargetNode = u78.node;
                    end;

                    return u78.node and u78.node.Selected and 0.75 or (v87 and 0.875 or 1);
                end)
            });

            return u78;
        end,

        RenderItem = function(p88, p89, p90) -- Line: 671, Name: RenderItem
            -- upvalues: u4 (ref), setClassIcon (ref)
            local v91 = u4[p90];

            if v91 then
                p89.node = v91;
                p89._instance.TextLabel.Text = p90.Name;
                p89._instance.BackgroundTransparency = v91.Selected and 0.75 or 1;
                setClassIcon(p89, p90);
                p89._instance.Expand.ImageLabel.Visible = #p90:GetChildren() > 0;
                p89._instance.Expand.ImageLabel.Rotation = v91.Expanded and 0 or -90;
                p89._instance.UIPadding.PaddingLeft = UDim.new(0, v91.Depth * 10);
            end;
        end
    });
    UI.new("Tooltip")({
        Text = "Search uses game:QueryDescendants()",
        Parent = u5._input._instance.ImageLabel
    });
    u6 = Parent.Util.Function.throttle(1, u5.updateList);
    u5:filter(function(p92, p93) -- Line: 693
        -- upvalues: u5 (ref), ExplorerOrder (ref), u4 (ref), ReflectionService (ref), traverse (ref), sortNodes (ref)
        local v94 = {};
        local Text = u5._input._input.Text;
        p92._filter = Text;
        local string_find_ret = string.find(p92._filter, "^%s*$");

        if string_find_ret then
            for _, v in p93 do
                if ExplorerOrder[v.ClassName] then
                    local v95 = u4[v];

                    if v95 and (v95.AncestorExpanded and v95.Depth) then
                        table.insert(v94, v);
                    end;
                end;
            end;
        else
            local v96;

            if string.find(Text, "^%w$") and not ReflectionService:GetClass(Text) then
                v96 = "#" .. Text;
            else
                v96 = Text;
            end;

            local v97 = {};
            local v98 = 0;
            local success, result = pcall(game.QueryDescendants, game, v96);
            local v99 = not success and {} or result;

            if #v99 > 0 then
                for _, v in v99 do
                    if ExplorerOrder[v.ClassName] then
                        local v100 = u4[v];

                        if v100 and v100.Depth then
                            v98 = v98 + 1;
                            v97[v] = true;
                            local Parent2 = v.Parent;

                            while Parent2 and (Parent2 ~= game and not v97[Parent2]) do
                                v97[Parent2] = true;
                                Parent2 = Parent2.Parent;
                            end;
                        end;
                    end;
                end;
            else
                local string_lower_ret = string.lower(Text);

                for _, v in p93 do
                    if ExplorerOrder[v.ClassName] then
                        local v101 = u4[v];

                        if v101 and (v101.Depth and string.find(string.lower(v.Name), string_lower_ret, 1, true)) then
                            v98 = v98 + 1;
                            v97[v] = true;
                            local Parent2 = v.Parent;

                            while Parent2 and (Parent2 ~= game and not v97[Parent2]) do
                                v97[Parent2] = true;
                                Parent2 = Parent2.Parent;
                            end;
                        end;
                    end;
                end;
            end;

            if v98 > 32 then
                v94 = table.create(v98);
            end;

            for i in v97 do
                table.insert(v94, i);
            end;
        end;

        traverse(game, 0, not string_find_ret);
        table.sort(v94, sortNodes);

        return v94;
    end);
    UI.edit(u59, {
        Visible = true
    });
    game.DescendantAdded:Connect(instanceAdded);
    game.DescendantRemoving:Connect(instanceRemoving);

    for _, descendant in game:GetDescendants() do
        task.spawn(instanceAdded, descendant);
    end;

    return u59;
end;

local u102 = false;

return {
    Show = function() -- Line: 786, Name: Show
        -- upvalues: u102 (ref), Initialize (copy), UI (copy)
        if u102 then
            UI.edit(u102, {
                Visible = true
            });

            return;
        end;

        u102 = Initialize();
    end
};