-- Decompiled with Potassium's decompiler.

game:GetService("Players");
local ReplicatedStorage = game:GetService("ReplicatedStorage");
local Modules = ReplicatedStorage:WaitForChild("Modules");
ReplicatedStorage:WaitForChild("Remotes");
local _ = Modules.Metadata;
local _ = Modules.Shared;
local _ = Modules.Utility;
local GlobalFunctions = require(Modules.GlobalFunctions);

return {
    Set = function(p1, p2) -- Line: 20, Name: Set
        local SubType = p2.CharacterData.Race.SubType;
        local v3 = {
            Red = math.random(1, 255),
            Green = math.random(1, 255),
            Blue = math.random(1, 255)
        };

        return p1 == "Saiyan" and SubType ~= "Half Saiyan" and {
            Red = 0,
            Green = 0,
            Blue = 0
        } or (p1 == "Angel" and {
            Red = 255,
            Green = 255,
            Blue = 255
        } or v3);
    end,

    Give = function(p4, p5) -- Line: 39, Name: Give
        -- upvalues: GlobalFunctions (copy)
        local _ = p4.CharacterData.Race.Race;
        local PupilColor = p4.CharacterData.PupilColor;
        local HairColor = p4.CharacterData.HairColor;
        local v6 = GlobalFunctions.FindFakeHead(p5);

        for _, child in pairs(v6:GetChildren()) do
            if child:IsA("Decal") then
                if child.Name == "Eyebrows" then
                    local v7 = {
                        Color3 = Color3.fromRGB(HairColor.Red, HairColor.Green, HairColor.Blue)
                    };
                    GlobalFunctions.Tween({
                        Duration = 1,
                        Instance = child
                    }, v7);
                elseif child.Name == "Pupils" then
                    local v8 = {
                        Color3 = Color3.fromRGB(PupilColor.Red, PupilColor.Green, PupilColor.Blue)
                    };
                    GlobalFunctions.Tween({
                        Duration = 1,
                        Instance = child
                    }, v8);
                end;
            end;
        end;
    end
};