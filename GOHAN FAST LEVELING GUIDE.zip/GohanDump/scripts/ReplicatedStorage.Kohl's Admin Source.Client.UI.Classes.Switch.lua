-- Decompiled with Potassium's decompiler.

local Parent = require(script.Parent.Parent);
local BaseClass = require(script.Parent:WaitForChild("BaseClass"));
local u1 = {
    Value = false
};
local u2 = Parent.compute(function() -- Line: 10
    -- upvalues: Parent (copy)
    return Parent.Theme.FontSize() + Parent.Theme.Padding().Offset;
end);
local u3 = {};
u3.__index = u3;
setmetatable(u3, BaseClass);

function u3.new(p4) -- Line: 18
    -- upvalues: u1 (copy), Parent (copy), u2 (copy), u3 (copy)
    local table_clone_ret = table.clone(u1);
    Parent.makeStatefulDefaults(table_clone_ret, p4);
    local v5 = {};
    local v6 = Parent.tween(function() -- Line: 24
        -- upvalues: table_clone_ret (copy), Parent (ref)
        return table_clone_ret.Value() and 0 or Parent.Theme.TransparencyHeavy();
    end, Parent.Theme.TweenOut);
    table.insert(v5, v6);
    local v7 = Parent.tween(function() -- Line: 29
        -- upvalues: table_clone_ret (copy), Parent (ref)
        return table_clone_ret.Value() and 0 or Parent.Theme.TransparencyClamped();
    end, Parent.Theme.TweenOut);
    table.insert(v5, v7);
    table_clone_ret._instance = Parent.new("TextButton")({
        AutoLocalize = false,
        Name = "Switch",
        Active = true,
        AutoButtonColor = false,
        AnchorPoint = Vector2.new(1, 0),
        BackgroundColor3 = Parent.Theme.Secondary,
        BackgroundTransparency = v6,
        Position = UDim2.new(1, 0, 0, 0),
        Text = "",
        TextTransparency = 1,

        Size = function() -- Line: 45, Name: Size
            -- upvalues: u2 (ref)
            local v8 = u2();

            return UDim2.new(0, v8 * 2, 0, v8);
        end,

        Parent.new("UICorner")({
            CornerRadius = Parent.Theme.CornerPadded
        }),
        Parent.new("Stroke")({}),
        Parent.new("Frame")({
            Name = "Circle",
            BackgroundColor3 = Parent.Theme.SecondaryText,
            BackgroundTransparency = v7,
            Size = UDim2.new(1, -2, 1, -2),
            SizeConstraint = Enum.SizeConstraint.RelativeYY,
            Position = Parent.tween(function() -- Line: 61
                -- upvalues: table_clone_ret (copy), u2 (ref)
                return UDim2.new(0, not table_clone_ret.Value() and 1 or u2() + 1, 0, 1);
            end, Parent.Theme.TweenOut),
            Parent.new("UICorner")({
                CornerRadius = Parent.Theme.CornerPadded
            })
        }),

        Activated = function() -- Line: 70, Name: Activated
            -- upvalues: Parent (ref), table_clone_ret (copy)
            local v9 = not Parent.raw(table_clone_ret.Value);
            table_clone_ret.Value(v9);

            if v9 then
                Parent.Sound.Hover03:Play();

                return;
            end;

            Parent.Sound.Hover01:Play();
        end,

        [Parent.Clean] = v5
    });

    return setmetatable(table_clone_ret, u3);
end;

return u3;