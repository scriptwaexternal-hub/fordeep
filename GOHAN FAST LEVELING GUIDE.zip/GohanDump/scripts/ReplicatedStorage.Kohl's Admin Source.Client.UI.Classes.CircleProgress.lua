-- Decompiled with Potassium's decompiler.

local Parent = require(script.Parent.Parent);
local BaseClass = require(script.Parent:WaitForChild("BaseClass"));
local u1 = {
    Alpha = 0,
    Image = Parent.Theme.Image.Circle
};
local NumberSequence_new_ret = NumberSequence.new({
    NumberSequenceKeypoint.new(0, 0),
    NumberSequenceKeypoint.new(0.5, 0),
    NumberSequenceKeypoint.new(0.5, 1),
    NumberSequenceKeypoint.new(1, 1)
});
local u2 = {};
u2.__index = u2;
setmetatable(u2, BaseClass);

function u2.new(p3) -- Line: 22
    -- upvalues: u1 (copy), Parent (copy), NumberSequence_new_ret (copy), u2 (copy)
    local table_clone_ret = table.clone(u1);
    Parent.makeStatefulDefaults(table_clone_ret, p3);
    table_clone_ret._instance = Parent.new("Frame")({
        Name = "CircleProgress",
        AnchorPoint = Vector2.new(0, 0),
        BackgroundTransparency = 1,
        Size = UDim2.fromOffset(64, 64),
        Parent.new("Frame")({
            Name = "Left",
            BackgroundTransparency = 1,
            ClipsDescendants = true,
            Size = UDim2.fromScale(0.5, 1),

            Visible = function() -- Line: 37, Name: Visible
                -- upvalues: table_clone_ret (copy)
                return table_clone_ret.Alpha() > 0.5;
            end,

            Parent.new("ImageLabel")({
                BackgroundTransparency = 1,
                ImageColor3 = Parent.Theme.Secondary,
                Image = table_clone_ret.Image,
                Size = UDim2.fromScale(2, 1),
                Parent.new("UIGradient")({
                    Transparency = NumberSequence_new_ret,

                    Rotation = function() -- Line: 49, Name: Rotation
                        -- upvalues: table_clone_ret (copy)
                        local v4 = table_clone_ret.Alpha() * 360 - 360;

                        return math.clamp(v4, -180, 0);
                    end
                })
            })
        }),
        Parent.new("Frame")({
            Name = "Right",
            BackgroundTransparency = 1,
            ClipsDescendants = true,
            Position = UDim2.fromScale(0.5, 0),
            Size = UDim2.fromScale(0.5, 1),

            Visible = function() -- Line: 62, Name: Visible
                -- upvalues: table_clone_ret (copy)
                return table_clone_ret.Alpha() > 0;
            end,

            Parent.new("ImageLabel")({
                BackgroundTransparency = 1,
                ImageColor3 = Parent.Theme.Secondary,
                Image = table_clone_ret.Image,
                Position = UDim2.fromScale(-1, 0),
                Size = UDim2.fromScale(2, 1),
                Parent.new("UIGradient")({
                    Transparency = NumberSequence_new_ret,

                    Rotation = function() -- Line: 75, Name: Rotation
                        -- upvalues: table_clone_ret (copy)
                        local v5 = table_clone_ret.Alpha() * 360;

                        return math.clamp(v5, 0, 180);
                    end
                })
            })
        })
    });

    return setmetatable(table_clone_ret, u2);
end;

return u2;