-- Decompiled with Potassium's decompiler.

local Players = game:GetService("Players");
local Debris = game:GetService("Debris");
local ReplicatedStorage = game:GetService("ReplicatedStorage");
game:GetService("RunService");
game:GetService("UserInputService");
local Assets = ReplicatedStorage.Assets;
local Modules = ReplicatedStorage:WaitForChild("Modules");
ReplicatedStorage:WaitForChild("Remotes");
local _ = Modules.Metadata;
local Utility = Modules.Utility;
local _ = Assets.Gui;
local SoundManager = require(Modules.Shared.SoundManager);
local GlobalFunctions = require(Modules.GlobalFunctions);
local PassiveHud = require(Utility.PassiveHud);
local _ = workspace.World.Visuals;
local _ = Players.LocalPlayer;
local _ = Assets.Sounds;
local Particles = Assets.Effects.Particles;
local _ = Assets.Gui.Passive;

return {
    Zenkai = function(p1) -- Line: 39
        -- upvalues: GlobalFunctions (copy), Particles (copy), SoundManager (copy), Debris (copy)
        local Character = p1.Character;
        local RootAndHumanoid = GlobalFunctions.GetRootAndHumanoid(Character);
        local ZenkaiPFX = Particles.ZenkaiPFX;
        SoundManager.AddSound("Zenkai", {
            Parent = RootAndHumanoid
        }, "Client");
        local Highlight = Instance.new("Highlight");
        Highlight.Parent = Character;
        Highlight.FillColor = Color3.fromRGB(155, 255, 155);
        Highlight.FillTransparency = 0;
        Highlight.OutlineTransparency = 1;
        Debris:AddItem(Highlight, 2);

        for _, child in pairs(Character:GetChildren()) do
            if child:IsA("Part") or child:IsA("MeshPart") then
                local v2 = child;

                for _, child2 in pairs(ZenkaiPFX:GetChildren()) do
                    local v3 = child2:Clone();
                    v3.Parent = v2;
                    v3:Emit(10);
                    Debris:AddItem(v3, 5);
                end;
            end;
        end;

        GlobalFunctions.Tween({
            Instance = Highlight
        }, {
            FillTransparency = 1
        });
    end,

    AddPassiveGui = function(p4) -- Line: 80
        -- upvalues: PassiveHud (copy)
        PassiveHud.Add(p4.PassiveName, p4.Category, p4.PassiveDesc);
    end,

    RemovePassiveGui = function(p5) -- Line: 89
        -- upvalues: PassiveHud (copy)
        PassiveHud.Remove(p5.PassiveName);
    end,

    AddBuffGui = function(p6) -- Line: 93
        -- upvalues: PassiveHud (copy)
        PassiveHud.AddBuff(p6.BuffName, p6.BuffDesc, p6.Duration);
    end,

    RemoveBuffGui = function(p7) -- Line: 96
        -- upvalues: PassiveHud (copy)
        PassiveHud.RemoveBuff(p7.BuffName);
    end
};