-- Decompiled with Potassium's decompiler.

local Players = game:GetService("Players");
local Debris = game:GetService("Debris");
local ReplicatedStorage = game:GetService("ReplicatedStorage");
game:GetService("RunService");
game:GetService("CollectionService");
local Modules = ReplicatedStorage:WaitForChild("Modules");
ReplicatedStorage:WaitForChild("Remotes");
local Assets = ReplicatedStorage.Assets;
local _ = Modules.Metadata;
local Shared = Modules.Shared;
local _ = Modules.Utility;
require(Shared.SoundManager);
local GlobalFunctions = require(Modules.GlobalFunctions);
require(Shared.SoundManager);
local _ = workspace.World.Visuals;
local _ = Players.LocalPlayer;
local _ = Assets.Sounds;
local Particles = Assets.Effects.Particles;

return {
    Fire = function(p1) -- Line: 36
        -- upvalues: GlobalFunctions (copy), Particles (copy)
        local Character = p1.Character;
        local CurrentRate = p1.CurrentRate;
        local _, v2 = GlobalFunctions.GetRootAndHumanoid(Character);

        if not Character:FindFirstChild("Kaioken Aura") then
            local v3 = Particles["New Kaioken Aura"];

            for _, child in pairs(Character:GetChildren()) do
                if v2:GetLimb(child) ~= Enum.Limb.Unknown then
                    local v4 = child;

                    for _, child2 in pairs(v3:GetChildren()) do
                        if child2:IsA("ParticleEmitter") then
                            local v5 = child2:Clone();
                            v5.Parent = v4;
                            v5.Rate = CurrentRate;
                            v5.Name = "Kaioken Aura";
                        end;
                    end;
                end;
            end;
        end;

        for _, descendant in pairs(Character:GetDescendants()) do
            if descendant.Name == "Kaioken Aura" then
                descendant.Enabled = true;
                descendant.Rate = CurrentRate;
            end;
        end;
    end,

    Disable = function(p6) -- Line: 72
        -- upvalues: Debris (copy)
        for _, descendant in pairs(p6.Character:GetDescendants()) do
            if descendant.Name == "Kaioken Aura" then
                descendant.Enabled = false;
                Debris:AddItem(descendant, 2);
            end;
        end;
    end
};