-- Decompiled with Potassium's decompiler.

local Modules = game:GetService("ReplicatedStorage"):WaitForChild("Modules");
local GlobalFunctions = require(Modules.GlobalFunctions);
local v1 = {};
local u4 = {
    linear = function(p2) -- Line: 26, Name: linear
        return p2;
    end,

    smooth = function(p3) -- Line: 28, Name: smooth
        return p3 * p3 * (3 - 2 * p3);
    end
};

local function easeOf(p5) -- Line: 31
    -- upvalues: u4 (copy)
    return u4[p5] or u4.linear;
end;

local function interpolate(p6, p7, p8, p9, p10, p11) -- Line: 37
    -- upvalues: u4 (copy)
    local v12 = u4[p10] or u4.linear;
    local os_clock_ret = os.clock();

    while p6.Parent do
        local v13 = (os.clock() - os_clock_ret) / p9;
        local math_min_ret = math.min(v13, 1);
        local v14 = p7 + (p8 - p7) * v12(math_min_ret);
        p6:ScaleTo(v14);

        if p11 then
            p11(math_min_ret, v14);
        end;

        if math_min_ret >= 1 then
            break;
        end;

        task.wait();
    end;
end;

local function stepLoop(p15, p16, p17, p18, p19) -- Line: 51
    local math_abs_ret = math.abs(p18 or 0);

    if math_abs_ret == 0 then
        return;
    end;

    if p17 < p16 then
        math_abs_ret = -math_abs_ret;
    end;

    for i = p16, p17, math_abs_ret do
        if not p15.Parent then
            return;
        end;

        p15:ScaleTo(i);

        if p19 then
            p19(i);
        end;

        task.wait();
        local _ = i;
    end;
end;

function v1.Scale(p20) -- Line: 63
    -- upvalues: interpolate (copy), stepLoop (copy)
    local ModelToScale = p20.ModelToScale;

    if not ModelToScale then
        return;
    end;

    local MaxScale = p20.MaxScale;
    local v21 = p20.MinScale or 0.1;
    local Duration = p20.Duration;

    if Duration and Duration > 0 then
        interpolate(ModelToScale, v21, MaxScale, Duration, p20.Easing);
    else
        stepLoop(ModelToScale, v21, MaxScale, p20.Speed);
    end;

    if ModelToScale.Parent then
        ModelToScale:ScaleTo(MaxScale);
    end;
end;

function v1.ScaleDown(p22) -- Line: 82
    -- upvalues: interpolate (copy), stepLoop (copy)
    local ModelToScale = p22.ModelToScale;

    if not (ModelToScale and ModelToScale.Parent) then
        return;
    end;

    local MaxScale = p22.MaxScale;
    local v23 = p22.MinScale or ModelToScale:GetScale();
    local Duration = p22.Duration;

    if Duration and Duration > 0 then
        interpolate(ModelToScale, v23, MaxScale, Duration, p22.Easing);
    else
        stepLoop(ModelToScale, v23, MaxScale, p22.Speed);
    end;

    if ModelToScale.Parent then
        ModelToScale:ScaleTo(MaxScale);
    end;
end;

function v1.ScaleCharacter(u24) -- Line: 105
    -- upvalues: GlobalFunctions (copy), interpolate (copy), stepLoop (copy)
    local Character = u24.Character;

    if not Character then
        return;
    end;

    local MaxScale = u24.MaxScale;
    local Speed = u24.Speed;
    local Duration = u24.Duration;
    local RootAndHumanoid = GlobalFunctions.GetRootAndHumanoid(Character);

    if not RootAndHumanoid then
        return;
    end;

    local u25 = u24.TotalLift or (Speed and Speed > 0 and ((MaxScale - 1) / Speed * 0.1 or 0) or 0);
    RootAndHumanoid.Anchored = true;
    local success = pcall(function() -- Line: 125
        -- upvalues: Duration (copy), interpolate (ref), Character (copy), MaxScale (copy), u24 (copy), RootAndHumanoid (copy), u25 (copy), stepLoop (ref), Speed (copy)
        if not Duration or Duration <= 0 then
            stepLoop(Character, 1, MaxScale, Speed, function() -- Line: 135
                -- upvalues: RootAndHumanoid (ref)
                if RootAndHumanoid.Parent then
                    local v26 = RootAndHumanoid;
                    v26.CFrame = v26.CFrame * CFrame.new(0, 0.1, 0);
                end;
            end);

            return;
        end;

        local u27 = 0;
        interpolate(Character, 1, MaxScale, Duration, u24.Easing, function(p28) -- Line: 128
            -- upvalues: RootAndHumanoid (ref), u25 (ref), u27 (ref)
            if not RootAndHumanoid.Parent then
                return;
            end;

            local v29 = u25 * p28;
            local v30 = RootAndHumanoid;
            v30.CFrame = v30.CFrame * CFrame.new(0, v29 - u27, 0);
            u27 = v29;
        end);
    end);

    if Character.Parent then
        Character:ScaleTo(MaxScale);
    end;

    if RootAndHumanoid.Parent then
        RootAndHumanoid.Anchored = false;
    end;

    if not success then
        warn("ScaleModel.ScaleCharacter: rise failed");
    end;
end;

return v1;