-- Decompiled with Potassium's decompiler.

local ReplicatedStorage = game:GetService("ReplicatedStorage");
game:GetService("UserInputService");
game:GetService("Players");
local Modules = ReplicatedStorage:WaitForChild("Modules");
ReplicatedStorage:WaitForChild("Remotes");
local _ = Modules.Metadata;
local Shared = Modules.Shared;
local _ = Modules.Utility;
local Assets = ReplicatedStorage.Assets;
local GlobalFunctions = require(Modules.GlobalFunctions);
local SoundManager = require(Shared.SoundManager);
local u1 = {};
local u2 = 0;

function Remove_UI(p3: userdata)
    -- upvalues: GlobalFunctions (copy)
    if p3:GetAttribute("Fading") then
        return;
    end;

    p3:SetAttribute("Fading", true);
    local Parent = p3.Parent;
    GlobalFunctions.Tween({
        Duration = 0.35,
        Instance = p3,
        EasingStyle = Enum.EasingStyle.Quad,
        EasingDirection = Enum.EasingDirection.In
    }, {
        BackgroundTransparency = 1,
        Position = UDim2.new(1.25, 0, 1, 0)
    });

    for _, child in pairs(p3:GetChildren()) do
        if child:IsA("TextLabel") then
            GlobalFunctions.Tween({
                Duration = 0.35,
                Instance = child
            }, {
                TextTransparency = 1,
                TextStrokeTransparency = 1
            });
        elseif child:IsA("ImageLabel") then
            GlobalFunctions.Tween({
                Duration = 0.35,
                Instance = child
            }, {
                ImageTransparency = 1,
                BackgroundTransparency = 1
            });
        elseif child:IsA("ViewportFrame") then
            GlobalFunctions.Tween({
                Duration = 0.35,
                Instance = child
            }, {
                ImageTransparency = 1,
                BackgroundTransparency = 1
            });
        end;
    end;

    task.delay(0.39999999999999997, function() -- Line: 53
        -- upvalues: Parent (copy)
        if Parent and Parent.Parent then
            Parent:Destroy();
        end;
    end);
end;

local u16 = {
    SendMessage = function(p4, p5, p6, p7, p8) -- Line: 59, Name: SendMessage
        -- upvalues: u1 (copy), u2 (ref), Assets (copy), GlobalFunctions (copy), SoundManager (copy)
        if not p4 then
            return;
        end;

        if not u1[p4] then
            u1[p4] = {};
        end;

        local PopupGui = p4.PlayerGui:FindFirstChild("PopupGui");

        if not PopupGui then
            return;
        end;

        local v9 = p4.Character or p4.CharacterAdded:Wait();
        local Frame = Instance.new("Frame");
        Frame.Name = "MessageSlot";
        Frame.BackgroundTransparency = 1;
        Frame.Size = UDim2.new(1, 0, 0.3, 0);
        Frame.ClipsDescendants = false;
        u2 = u2 + 1;
        Frame.LayoutOrder = u2;
        local u10 = Assets.Gui.GameMessage.GameTextMessage:Clone();
        local Desc = u10.Desc;
        Desc.Text = "[" .. p5 .. "]";
        Desc.TextColor3 = p7 or Color3.fromRGB(255, 255, 255);
        local v11 = p8 and p8.SenderName and u10:FindFirstChild("NameLabel");

        if v11 then
            v11.Text = p8.SenderName;
        end;

        if p8 and (p8.SenderCharacter and p8.SenderCharacter.Parent) then
            local ImageLabel = u10:FindFirstChild("ImageLabel");

            if ImageLabel then
                local ViewportFrame = Instance.new("ViewportFrame");
                ViewportFrame.Name = "SenderPortrait";
                ViewportFrame.Size = ImageLabel.Size;
                ViewportFrame.Position = ImageLabel.Position;
                ViewportFrame.AnchorPoint = ImageLabel.AnchorPoint;
                ViewportFrame.BackgroundTransparency = 1;
                ViewportFrame.Ambient = Color3.fromRGB(150, 150, 150);
                ViewportFrame.LightColor = Color3.fromRGB(255, 255, 255);
                ViewportFrame.LightDirection = Vector3.new(-0.4, -1, -0.6);
                local v12 = ImageLabel:FindFirstChildOfClass("UIAspectRatioConstraint");

                if v12 then
                    v12:Clone().Parent = ViewportFrame;
                end;

                ViewportFrame.Parent = u10;
                ImageLabel:Destroy();
                local SenderCharacter = p8.SenderCharacter;
                SenderCharacter.Archivable = true;
                local v13 = SenderCharacter:Clone();

                if v13 then
                    for _, descendant in ipairs(v13:GetDescendants()) do
                        if descendant:IsA("BaseScript") or descendant:IsA("ModuleScript") then
                            descendant:Destroy();
                        end;
                    end;

                    v13.Parent = ViewportFrame;
                    local Head = v13:FindFirstChild("Head");
                    local HumanoidRootPart = v13:FindFirstChild("HumanoidRootPart");

                    if Head and HumanoidRootPart then
                        local Camera = Instance.new("Camera");
                        Camera.Parent = ViewportFrame;
                        ViewportFrame.CurrentCamera = Camera;
                        Camera.FieldOfView = 45;
                        Camera.CFrame = CFrame.lookAt((HumanoidRootPart.CFrame * CFrame.new(0.2, 0.8, -3.6)).Position, Head.Position);
                    end;
                end;
            end;
        end;

        u10.AnchorPoint = Vector2.new(0, 1);
        u10.Size = UDim2.new(1, 0, 0.7, 0);
        u10.Position = UDim2.new(1.25, 0, 1, 0);
        u10:SetAttribute("Fading", false);
        u10.Parent = Frame;
        Frame.Parent = PopupGui.MessageFrame;
        GlobalFunctions.Tween({
            Duration = 0.35,
            Instance = u10,
            EasingStyle = Enum.EasingStyle.Quint,
            EasingDirection = Enum.EasingDirection.Out
        }, {
            Position = UDim2.new(0, 0, 1, 0)
        });
        local v14 = u1[p4];

        for i = #v14, 1, -1 do
            local v15;

            if v14[i].Parent then
                v15 = i;
            else
                table.remove(v14, i);
                v15 = i;
            end;
        end;

        table.insert(v14, u10);

        if #v14 > 3 then
            local table_remove_ret = table.remove(v14, 1);
            Remove_UI(table_remove_ret);
        end;

        SoundManager.AddSound("Game Notification", {
            Parent = v9:FindFirstChild("Root")
        }, "Client");
        task.delay(p6 or 2, function() -- Line: 176
            -- upvalues: u10 (copy)
            Remove_UI(u10);
        end);
    end
};

function u16.SendPrompt(p17, p18) -- Line: 181
    -- upvalues: SoundManager (copy), Assets (copy), u16 (copy)
    local v19 = p17.Character or p17.CharacterAdded:Wait();

    if not p17.PlayerGui.PopupGui:FindFirstChild("TextPrompt") then
        SoundManager.AddSound("Game Notification", {
            Parent = v19:FindFirstChild("Root")
        }, "Client");
        local v20 = Assets.Gui.GameMessage.TextPrompt:Clone();
        v20.Parent = p17.PlayerGui.PopupGui;
        v20.Text = p18;
        local No = v20.No;
        local u21 = "Nil";
        v20.Yes.MouseButton1Up:Connect(function() -- Line: 198
            -- upvalues: u21 (ref)
            u21 = true;
        end);
        No.MouseButton1Up:Connect(function() -- Line: 202
            -- upvalues: u21 (ref)
            u21 = false;
        end);

        while u21 == "Nil" do
            task.wait();
        end;

        game.Debris:AddItem(v20, 0.1);

        return u21;
    end;

    u16.SendMessage(p17, "Another prompt is already active!");
end;

function u16.NotifyMove(p22, p23) -- Line: 217
    -- upvalues: Assets (copy)
    local MainFrame = p22.PlayerGui.PopupGui.MainFrame;
    local v24 = Assets.Gui.GameMessage.MoveLabel:Clone();
    v24.Parent = MainFrame;
    v24.Text = p23;
    game.Debris:AddItem(v24, 2.5);
end;

return u16;