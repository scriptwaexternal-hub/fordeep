-- Decompiled with Potassium's decompiler.

local u1 = nil;
local u9 = {
    filterLog = true,

    transform = function(p2) -- Line: 5, Name: transform
        return p2 == "" and 0 or tonumber(p2);
    end,

    validate = function(p3) -- Line: 8, Name: validate
        local v4;

        if p3 == nil then
            v4 = false;
        else
            v4 = p3 == math.floor(p3);
        end;

        return v4, "Only whole numbers are valid";
    end,

    parse = function(p5, p6) -- Line: 11, Name: parse
        -- upvalues: u1 (ref)
        local Texture = u1.Util.getTexture(p5, u1.IsClient);

        if Texture then
            return Texture;
        end;

        if p6.definition.optional and p6.rawArg == "" then
            return "";
        end;

        if u1.IsClient then
            return "rbxasset://textures/ui/GuiImagePlaceholder.png";
        end;

        return nil, "Failed to load image";
    end,

    suggestions = function(p7) -- Line: 24, Name: suggestions
        local v8 = {};

        if not tonumber(p7) then
            p7 = nil;
        end;

        v8[1] = p7;

        return v8;
    end
};

return function(p10) -- Line: 29
    -- upvalues: u1 (ref), u9 (copy)
    u1 = p10;
    u1.Registry.registerType("image", u9);
    u1.Registry.registerType("images", {
        listable = true
    }, u9);
end;