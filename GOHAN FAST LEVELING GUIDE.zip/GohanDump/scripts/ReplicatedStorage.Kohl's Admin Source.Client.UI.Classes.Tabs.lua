-- Decompiled with Potassium's decompiler.

local Parent = require(script.Parent.Parent);
local BaseClass = require(script.Parent:WaitForChild("BaseClass"));
local u1 = {
    CurrentPage = false,
    Vertical = false,
    Tabs = {}
};
local u2 = {};
u2.__index = u2;
setmetatable(u2, BaseClass);

function u2.new(p3) -- Line: 16
    -- upvalues: u1 (copy), Parent (copy), u2 (copy)
    local table_clone_ret = table.clone(u1);
    Parent.makeStatefulDefaults(table_clone_ret, p3);
    local v4 = {};
    local v5 = table_clone_ret.CurrentPage();

    if type(v5) == "table" and v5._instance then
        table_clone_ret.CurrentPage(v5._instance);
    end;

    local u6 = Parent.state(0);
    local u7 = nil;
    table.insert(v4, u6);
    local u8 = Parent.new("UIListLayout")({
        FillDirection = function() -- Line: 33, Name: FillDirection
            -- upvalues: table_clone_ret (copy)
            if table_clone_ret.Vertical() then
                return Enum.FillDirection.Vertical;
            end;

            return Enum.FillDirection.Horizontal;
        end,

        HorizontalFlex = function() -- Line: 36, Name: HorizontalFlex
            -- upvalues: table_clone_ret (copy)
            if table_clone_ret.Vertical() then
                return Enum.UIFlexAlignment.Fill;
            end;

            return Enum.UIFlexAlignment.None;
        end,

        SortOrder = Enum.SortOrder.LayoutOrder,
        Padding = Parent.Theme.Padding
    });
    local u9 = nil;
    u9 = Parent.new("ScrollingFrame")({
        Name = "Tabs",
        Active = false,
        AutomaticCanvasSize = Enum.AutomaticSize.XY,

        AutomaticSize = function() -- Line: 48, Name: AutomaticSize
            -- upvalues: table_clone_ret (copy)
            if table_clone_ret.Vertical() then
                return Enum.AutomaticSize.X;
            end;

            return Enum.AutomaticSize.Y;
        end,

        BackgroundTransparency = 1,
        ClipsDescendants = false,
        CanvasPosition = Parent.tween(function() -- Line: 53
            -- upvalues: table_clone_ret (copy), u6 (copy)
            if table_clone_ret.Vertical() then
                return Vector2.new(0, u6());
            end;

            return Vector2.new(u6(), 0);
        end, Parent.Theme.TweenOut),
        CanvasSize = UDim2.new(),
        Size = UDim2.new(1, 0, 1, 0),
        ScrollBarThickness = 0,

        MouseWheelForward = function() -- Line: 60, Name: MouseWheelForward
            -- upvalues: table_clone_ret (copy), u7 (ref), u9 (ref), u6 (copy)
            if table_clone_ret.Vertical() then
                u7 = nil;

                return;
            end;

            local X = table_clone_ret._instance.AbsolutePosition.X;
            local v10 = (1 / 0);
            local v11 = nil;

            for _, child in u9:GetChildren() do
                if child:IsA("GuiObject") then
                    local X2 = child.AbsolutePosition.X;

                    if X2 < X - 2 and X - X2 < v10 then
                        v10 = math.floor(X - X2);
                        v11 = child;
                    end;
                end;
            end;

            if v10 == (1 / 0) then
                return;
            end;

            u7 = v11;
            u6((math.max(0, v11.AbsolutePosition.X - (u9.AbsolutePosition.X - u9.CanvasPosition.X))));
        end,

        MouseWheelBackward = function() -- Line: 82, Name: MouseWheelBackward
            -- upvalues: table_clone_ret (copy), u7 (ref), u9 (ref), u8 (copy), u6 (copy)
            if table_clone_ret.Vertical() then
                u7 = nil;

                return;
            end;

            local v12 = table_clone_ret._instance.AbsolutePosition.X + (not u7 and 0 or u7.AbsoluteSize.X);
            local v13 = (1 / 0);
            local v14 = nil;

            for _, child in u9:GetChildren() do
                if child:IsA("GuiObject") then
                    local X = child.AbsolutePosition.X;

                    if v12 + 2 < X and X - v12 < v13 then
                        v13 = math.floor(X - v12);
                        v14 = child;
                    end;
                end;
            end;

            if v13 == (1 / 0) then
                return;
            end;

            if u8.AbsoluteContentSize.X - u9.AbsoluteSize.X > 0 then
                u7 = v14;
            end;

            u6(v14.AbsolutePosition.X - (u9.AbsolutePosition.X - u9.CanvasPosition.X));
        end,

        [Parent.Event] = {
            CanvasPosition = function() -- Line: 111, Name: CanvasPosition
                -- upvalues: u9 (ref), table_clone_ret (copy)
                if u9.CanvasPosition.Y == 1 and not table_clone_ret.Vertical() then
                    u9.CanvasPosition = Vector2.new(u9.CanvasPosition.X, 0);
                end;
            end
        },
        u8
    });
    local PropertyChangedSignal = u9:GetPropertyChangedSignal("AbsoluteSize");
    table.insert(v4, PropertyChangedSignal:Connect(function() -- Line: 123
        -- upvalues: table_clone_ret (copy), u6 (copy), u8 (copy), u9 (ref)
        if table_clone_ret.Vertical() then
            u6(math.clamp(u6._value, 0, u8.AbsoluteContentSize.Y + u9.AbsoluteSize.Y), false, true);

            return;
        end;

        u6(math.clamp(u6._value, 0, u8.AbsoluteContentSize.X + u9.AbsoluteSize.X), false, true);
    end));
    local u15 = {};
    local u16 = {};
    local u17 = Parent.new("UIPageLayout")({
        Animated = false,
        ScrollWheelInputEnabled = false,
        SortOrder = Enum.SortOrder.LayoutOrder,
        Padding = Parent.Theme.PaddingWithStroke
    });
    table_clone_ret._pages = u17;
    table_clone_ret._pageCache = u15;
    table_clone_ret._containerCache = u16;
    table.insert(v4, u17.PageEnter:Connect(function(p18) -- Line: 155
        -- upvalues: u15 (copy), table_clone_ret (copy)
        local v19 = u15[p18];

        if not v19 then
            return;
        end;

        table_clone_ret.CurrentPage(v19);
        v19.Visible = true;
        v19.Parent = p18;
    end));
    table.insert(v4, u17.PageLeave:Connect(function(u20) -- Line: 168
        -- upvalues: u15 (copy), u17 (copy)
        local u21 = u15[u20];

        if not u21 then
            return;
        end;

        task.defer(function() -- Line: 173
            -- upvalues: u17 (ref), u20 (copy), u21 (copy)
            if u17.CurrentPage ~= u20 then
                u21.Parent = nil;
                u21.Visible = false;
            end;
        end);
    end));
    local v22 = Parent.compute(function() -- Line: 182
        -- upvalues: table_clone_ret (copy), Parent (ref)
        if table_clone_ret.Vertical() then
            return Parent.Theme.Padding();
        end;

        return UDim.new(0, 1);
    end);
    table.insert(v4, v22);
    table_clone_ret._instance = Parent.new("Frame")({
        Name = "TabController",
        BackgroundTransparency = 1,
        Size = UDim2.new(1, 0, 1, 0),
        Parent.new("UIListLayout")({
            FillDirection = function() -- Line: 193, Name: FillDirection
                -- upvalues: table_clone_ret (copy)
                if table_clone_ret.Vertical() then
                    return Enum.FillDirection.Horizontal;
                end;

                return Enum.FillDirection.Vertical;
            end,

            SortOrder = Enum.SortOrder.LayoutOrder
        }),
        Parent.new("Frame")({
            Name = "Bar",
            BackgroundTransparency = 1,
            ClipsDescendants = true,

            AutomaticSize = function() -- Line: 203, Name: AutomaticSize
                -- upvalues: table_clone_ret (copy)
                if table_clone_ret.Vertical() then
                    return Enum.AutomaticSize.X;
                end;

                return Enum.AutomaticSize.Y;
            end,

            Size = function() -- Line: 206, Name: Size
                -- upvalues: table_clone_ret (copy)
                if table_clone_ret.Vertical() then
                    return UDim2.new(0, 0, 1, 0);
                end;

                return UDim2.new(1, 0, 0, 0);
            end,

            u9,
            Parent.new("UIPadding")({
                PaddingTop = v22,
                PaddingBottom = v22,
                PaddingLeft = Parent.Theme.Padding,
                PaddingRight = Parent.Theme.Padding
            })
        }),
        [Parent.Clean] = v4
    });
    local v23 = Parent.compute(function() -- Line: 222
        -- upvalues: table_clone_ret (copy), Parent (ref)
        if table_clone_ret.Vertical() then
            return Parent.Theme.PaddingStroke;
        end;

        return Parent.Theme.PaddingWithStroke;
    end);
    table.insert(v4, v23);
    local v24 = Parent.new("Frame")({
        Name = "PagesFrame",
        AnchorPoint = Vector2.new(0, 1),
        BackgroundTransparency = 1,
        Size = UDim2.new(1, 0, 1, 0),
        Position = UDim2.new(0, 0, 1, 0),
        Parent.new("UIPadding")({
            PaddingTop = Parent.Theme.PaddingStroke,
            PaddingBottom = Parent.Theme.PaddingStroke,
            PaddingLeft = v23,
            PaddingRight = v23
        }),
        u17
    });
    table_clone_ret._content = Parent.new("Frame")({
        LayoutOrder = 3,
        Name = "UIContent",
        Parent = table_clone_ret._instance,
        AnchorPoint = Vector2.new(0, 1),
        BackgroundTransparency = 1,
        Size = UDim2.new(1, 0, 1, 0),
        Position = UDim2.new(0, 0, 1, 0),
        ClipsDescendants = true,
        Parent.new("UIFlexItem")({
            FlexMode = Enum.UIFlexMode.Fill
        }),
        v24,

        ChildAdded = function(u25) -- Line: 259, Name: ChildAdded
            -- upvalues: u16 (copy), table_clone_ret (copy)
            local u26 = u16[u25];

            if u26 then
                task.defer(function() -- Line: 262
                    -- upvalues: u25 (copy), table_clone_ret (ref), u26 (copy)
                    local v27;

                    if table_clone_ret.CurrentPage() == u26 then
                        v27 = u26;
                    else
                        v27 = nil;
                    end;

                    u25.Parent = v27;
                end);
            end;
        end
    });

    for i, v in Parent.raw(table_clone_ret.Tabs) do
        local u28, v29 = unpack(v);

        if type(u28) == "table" then
            u28 = u28._instance;
        end;

        if u16[u28] then
            return;
        end;

        local u30 = Parent.new("Frame")({
            BackgroundTransparency = 1,
            Parent = v24,
            Name = u28.Name,
            LayoutOrder = i,
            Size = UDim2.fromScale(1, 1)
        });
        u15[u30] = u28;
        u16[u28] = u30;

        if table_clone_ret.CurrentPage() == u28 then
            u28.Parent = u30;
            u17:JumpTo(u30);
        end;

        local u31 = Parent.state(u28, "Name");
        local u32 = nil;
        u32 = Parent.new("Button")({
            Parent = u9,
            LayoutOrder = i,
            Name = u31,
            Icon = v29,
            IconProperties = {
                Size = function() -- Line: 302, Name: Size
                    -- upvalues: Parent (ref)
                    local v33 = Parent.Theme.FontSize + Parent.Theme.PaddingHalf().Offset;

                    return UDim2.fromOffset(v33, v33);
                end
            },

            Size = function() -- Line: 307, Name: Size
                -- upvalues: Parent (ref), u31 (copy)
                local Offset = Parent.Theme.Padding().Offset;
                local GetTextBoundsParams = Instance.new("GetTextBoundsParams");
                GetTextBoundsParams.Text = u31();
                GetTextBoundsParams.Font = Parent.Theme.FontBold();
                GetTextBoundsParams.Size = Parent.Theme.FontSize();
                local v34 = Parent.retryGetTextBoundsAsync(GetTextBoundsParams).X + Offset * 2;

                return UDim2.new(0, math.ceil(v34), 0, Parent.Theme.FontSize + Offset * 2);
            end,

            Label = function() -- Line: 316, Name: Label
                -- upvalues: u31 (copy)
                return `<b>{u31()}</b>`;
            end,

            TextXAlignment = Enum.TextXAlignment.Left,

            Activated = function() -- Line: 321, Name: Activated
                -- upvalues: Parent (ref), u17 (copy), u30 (copy), table_clone_ret (copy), u9 (ref), u32 (ref), u8 (copy), u6 (copy)
                Parent.clearActiveStates();
                u17:JumpTo(u30);
                local v35 = table_clone_ret.Vertical() and "Y" or "X";
                local v36 = u9.Parent.AbsolutePosition[v35];
                local v37 = v36 + u9.Parent.AbsoluteSize[v35];
                local v38 = u32._instance.AbsolutePosition[v35];
                local v39 = v38 + u32._instance.AbsoluteSize[v35] + u8.Padding.Offset;

                if u8.AbsoluteContentSize[v35] >= u9.AbsoluteSize[v35] and v37 < v39 + 32 then
                    u6((math.min(u8.AbsoluteContentSize[v35] - u9.AbsoluteSize[v35], u6 + (32 + (v39 - v37)))));

                    return;
                end;

                if v38 - 32 < v36 then
                    u6((math.max(0, u6 - (v36 - v38 + 32 + u8.Padding.Offset))));
                end;
            end
        });
        table.insert(v4, u32);
        Parent.edit(u32._content.Label, {
            TextTransparency = Parent.tween(function() -- Line: 346
                -- upvalues: table_clone_ret (copy), u28 (ref), u32 (ref)
                return table_clone_ret.CurrentPage() == u28 and 0 or (u32._hovering() and 0.125 or 0.5);
            end, Parent.Theme.TweenOut)
        });
        Parent.edit(u32._content.Label.UIPadding, {
            PaddingLeft = Parent.Theme.Padding
        });
        Parent.edit(u32._instance.UIStroke, {
            Transparency = Parent.tween(function() -- Line: 356
                -- upvalues: table_clone_ret (copy), u28 (ref), Parent (ref), u32 (ref)
                if table_clone_ret.CurrentPage() == u28 then
                    return Parent.Theme.TransparencyLight;
                end;

                return not u32._hovering() and 1 or Parent.Theme.TransparencyBalanced;
            end, Parent.Theme.TweenOut)
        });
        Parent.edit(u32._instance, {
            BackgroundTransparency = Parent.tween(function() -- Line: 365
                -- upvalues: table_clone_ret (copy), u28 (ref), Parent (ref), u32 (ref)
                if table_clone_ret.CurrentPage() == u28 then
                    return Parent.Theme.TransparencyHeavy;
                end;

                return not u32._hovering() and 1 or Parent.Theme.TransparencyMax;
            end, Parent.Theme.TweenOut)
        });

        local function hideButton() -- Line: 373
            -- upvalues: u28 (ref), u30 (copy), u32 (ref)
            local v40;

            if u28.Parent == u30 or u28.Parent == nil then
                v40 = u28:GetAttribute("Enabled") ~= false;
            else
                v40 = false;
            end;

            u32._instance.Visible = v40;
            u30.Visible = v40;
        end;

        local PropertyChangedSignal2 = u28:GetPropertyChangedSignal("Parent");
        table.insert(v4, PropertyChangedSignal2:Connect(hideButton));
        local AttributeChangedSignal = u28:GetAttributeChangedSignal("Enabled");
        table.insert(v4, AttributeChangedSignal:Connect(hideButton));
        local v41;

        if u28.Parent == u30 or u28.Parent == nil then
            v41 = u28:GetAttribute("Enabled") ~= false;
        else
            v41 = false;
        end;

        u32._instance.Visible = v41;
        u30.Visible = v41;
    end;

    return setmetatable(table_clone_ret, u2);
end;

return u2;