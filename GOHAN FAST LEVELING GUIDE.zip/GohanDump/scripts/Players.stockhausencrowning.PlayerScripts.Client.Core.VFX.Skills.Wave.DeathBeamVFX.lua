-- Decompiled with Potassium's decompiler.

local Debris = game:GetService("Debris");
local ReplicatedStorage = game:GetService("ReplicatedStorage");
local Modules = ReplicatedStorage:WaitForChild("Modules");
local GlobalFunctions = require(Modules.GlobalFunctions);
local WaveVFX = require(script.Parent.WaveVFX);
local Visuals = workspace.World.Visuals;
local Effects = ReplicatedStorage.Assets.Effects;
local Color3_fromRGB_ret = Color3.fromRGB(255, 0, 0);

return {
    Fire = function(p1) -- Line: 28
        -- upvalues: GlobalFunctions (copy), Color3_fromRGB_ret (copy), Effects (copy), Visuals (copy), Debris (copy), WaveVFX (copy)
        local Character = p1.Character;

        if not Character then
            return;
        end;

        local RootAndHumanoid = GlobalFunctions.GetRootAndHumanoid(Character);

        if not RootAndHumanoid then
            return;
        end;

        local u2 = Character:FindFirstChild("Left Arm") or RootAndHumanoid;
        local u3 = p1.StartSize or 0;
        local u4 = p1.Color or Color3_fromRGB_ret;
        task.spawn(function() -- Line: 38, Name: ringsEffect
            -- upvalues: u2 (copy), u3 (copy), Effects (ref), u4 (copy), Visuals (ref), Debris (ref), GlobalFunctions (ref)
            local CFrame2 = u2.CFrame;
            local v5 = 5;
            local v6 = 5.1;

            for i = 1, 2 do
                local u7 = Effects.Meshes.Ring:Clone();
                u7.CFrame = CFrame2 * CFrame.new(0, -2, 0);
                u7.Size = Vector3.new(1, 0.05, 1) * (1.1 + u3);
                u7.Color = u4;
                u7.Parent = Visuals;
                Debris:AddItem(u7, 5);
                GlobalFunctions.Tween({
                    Duration = 3.5,
                    Instance = u7,
                    EasingStyle = Enum.EasingStyle.Exponential
                }, {
                    Size = Vector3.new(1, 0.05, 1) * (v6 + u3),
                    CFrame = u7.CFrame * CFrame.new(0, v5, 0)
                });
                task.delay(0.5, function() -- Line: 62
                    -- upvalues: u7 (copy), GlobalFunctions (ref)
                    if not u7.Parent then
                        return;
                    end;

                    GlobalFunctions.Tween({
                        Duration = 0.6,
                        Instance = u7,
                        EasingStyle = Enum.EasingStyle.Exponential
                    }, {
                        Transparency = 1
                    });
                end);
                v6 = v6 / 2;
                v5 = v5 / 2;
                task.wait(0.2);
                local _ = i;
            end;
        end);
        WaveVFX.Fire(p1);
    end
};