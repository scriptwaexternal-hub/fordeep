-- Decompiled with Potassium's decompiler.

local u1 = {
    ["0,0,0"] = Color3.new(0, 0, 0),
    ["255,255,255"] = Color3.new(1, 1, 1),
    ["#000"] = Color3.new(0, 0, 0),
    ["#fff"] = Color3.new(1, 1, 1),
    red = Color3.new(1, 0, 0),
    orange = Color3.new(1, 0.5, 0),
    yellow = Color3.new(1, 1, 0),
    yellowgreen = Color3.new(0.5, 1, 0),
    green = Color3.new(0, 1, 0),
    aqua = Color3.new(0, 1, 1),
    cyan = Color3.new(0, 1, 1),
    blue = Color3.new(0, 0, 1),
    purple = Color3.new(0.5, 0, 1),
    violet = Color3.new(0.5, 0, 1),
    pink = Color3.new(1, 0, 1),
    magenta = Color3.new(1, 0, 0.5),
    white = Color3.new(1, 1, 1),
    black = Color3.new(0, 0, 0),
    grey = Color3.new(0.5, 0.5, 0.5),
    gray = Color3.new(0.5, 0.5, 0.5)
};
local Number = BrickColor.new(-1).Number;
local u2 = nil;

for i = 1, 1032 do
    local BrickColor_new_ret = BrickColor.new(i);
    local v3;

    if i == Number or BrickColor_new_ret.Number ~= Number then
        local string_lower_ret = string.lower(BrickColor_new_ret.Name);

        if u1[string_lower_ret] then
            v3 = i;
        else
            u1[tostring(i)] = BrickColor_new_ret.Color;
            u1[string_lower_ret] = BrickColor_new_ret.Color;
            v3 = i;
        end;
    else
        v3 = i;
    end;
end;

local u4 = {};

for i in u1 do
    table.insert(u4, i);
end;

table.sort(u4);
u1.random = Color3.new(math.random(), math.random(), math.random());
table.insert(u4, 1, "random");
local u19 = {
    transform = function(p5: string) -- Line: 52, Name: transform
        -- upvalues: u2 (ref), u1 (copy)
        if p5 == "" then
            return "";
        end;

        local v6 = u2.Util.String.trim(string.lower(p5));

        if u1[v6] then
            if v6 == "random" then
                return Color3.new(math.random(), math.random(), math.random());
            end;

            return u1[v6];
        end;

        if string.find(v6, "^#") then
            if #v6 > 7 or string.find(v6, "[^#a-f%d]") then
                return nil;
            end;

            if #v6 < 4 then
                v6 = v6 .. string.rep("f", 4 - #v6);
            elseif #v6 > 4 then
                v6 = v6 .. string.rep("f", 7 - #v6);
            end;

            return Color3.fromHex(v6);
        end;

        local string_match_ret, v7, v8 = string.match(v6, "^(%d+),?(%d*),?(%d*)$");

        if string_match_ret then
            local v9 = true;

            for _, v in { string_match_ret, v7, v8 } do
                local v10 = tonumber(v);

                if v10 and (#v > 3 or (v10 < 0 or v10 > 255)) then
                    v9 = false;
                    break;
                end;
            end;

            if v9 then
                return Color3.fromRGB(string_match_ret or 255, v7 or 255, v8 or 255);
            end;
        end;

        for i, v in u1 do
            if string.find(i, v6, 1, true) == 1 then
                return v;
            end;
        end;

        return nil, "Invalid Color";
    end,

    validate = function(p11) -- Line: 97, Name: validate
        if typeof(p11) == "Color3" then
            return true;
        end;

        return false, "Invalid Color3";
    end,

    parse = function(p12) -- Line: 104, Name: parse
        return p12;
    end,

    suggestions = function(p13: string) -- Line: 108, Name: suggestions
        -- upvalues: u4 (copy), u1 (copy)
        local table_clone_ret = table.clone(u4);

        if string.find(p13, "^#") then
            if #p13 < 4 then
                local v14 = p13 .. string.rep("f", 4 - #p13);
                table.insert(table_clone_ret, v14);
            end;

            if #p13 < 7 then
                local v15 = p13 .. string.rep("f", 7 - #p13);
                table.insert(table_clone_ret, v15);
            end;
        elseif p13 ~= "" then
            if string.find("random", string.lower(p13), 1, true) == 1 then
                u1.random = Color3.new(math.random(), math.random(), math.random());
            end;

            local string_match_ret, v16, v17 = string.match(p13, "^(%d+),?(%d*),?(%d*)$");
            local v18 = `{string_match_ret or 255},{v16 or 255},{v17 or 255}`;
            table.insert(table_clone_ret, v18);
        end;

        return table_clone_ret, u1;
    end
};

return function(p20) -- Line: 130
    -- upvalues: u2 (ref), u19 (copy)
    u2 = p20;
    u2.Registry.registerType("color", u19);
end;