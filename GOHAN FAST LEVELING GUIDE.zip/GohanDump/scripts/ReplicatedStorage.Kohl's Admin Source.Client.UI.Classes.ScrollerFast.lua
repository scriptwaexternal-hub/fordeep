-- Decompiled with Potassium's decompiler.

local RunService = game:GetService("RunService");
local BaseClass = require(script.Parent:WaitForChild("BaseClass"));
local Parent = require(script.Parent.Parent);
local u1 = {};
local u2 = 0;

function u1.reset(p3: number?) -- Line: 10
    -- upvalues: u2 (ref)
    if u2 <= os.clock() then
        u2 = os.clock() + 0.004166666666666667;
    end;
end;

function u1.wait(p4: number?) -- Line: 17
    -- upvalues: u2 (ref), u1 (copy)
    if u2 <= os.clock() then
        task.wait();
        u1.reset(p4);
    end;
end;

local u5 = {};
u5.__index = u5;
setmetatable(u5, BaseClass);

local function defaultFilter(p6, p7) -- Line: 30
    -- upvalues: u5 (copy)
    local string_lower_ret = string.lower(p6._input._input.Text);
    p6._filter = string_lower_ret;

    if string.find(string_lower_ret, "^%s*$") then
        return p7;
    end;

    local v8 = {};

    for _, v in p7 do
        local string_find_ret, v9 = string.find(string.lower(v), string_lower_ret, 1, true);

        if string_find_ret then
            local string_format = string.format;
            local v10 = u5.escapeRichText((string.sub(v, 1, string_find_ret - 1)));
            local v11 = u5.escapeRichText((string.sub(v, string_find_ret, v9)));
            local escapeRichText = u5.escapeRichText;
            local string_sub_ret = string.sub(v, v9 + 1);
            table.insert(v8, string_format("<font transparency=\"0.5\">%s</font><b>%s</b><font transparency=\"0.5\">%s</font>", v10, v11, escapeRichText(string_sub_ret)));
        end;
    end;

    return v8;
end;

function u5.escapeRichText(p12: string) -- Line: 54
    local string_gsub_ret = string.gsub(p12, "&", "&amp;");
    local string_gsub_ret2 = string.gsub(string_gsub_ret, "<", "&lt;");
    local string_gsub_ret3 = string.gsub(string_gsub_ret2, ">", "&gt;");
    local string_gsub_ret4 = string.gsub(string_gsub_ret3, "\"", "&quot;");

    return string.gsub(string_gsub_ret4, "\'", "&apos;");
end;

local u13 = {};
local u14 = {};
local u15 = {};
local u16 = {};
RunService.Heartbeat:connect(function() -- Line: 68
    -- upvalues: u13 (ref), u14 (ref), u15 (ref), u16 (ref)
    local os_clock_ret = os.clock();
    local v17 = u13;
    u13 = {};

    for i in v17 do
        if i._instance.Visible and os.clock() - os_clock_ret <= 0.011111111111111112 then
            i:cloneRaw();
            i:refreshList();
        else
            i:updateList();
        end;
    end;

    if os.clock() - os_clock_ret > 0.011111111111111112 then
        return;
    end;

    local v18 = u14;
    u14 = {};

    for i in v18 do
        if i._instance.Visible and os.clock() - os_clock_ret <= 0.011111111111111112 then
            local v19;

            if i.DictList._value then
                local v20 = i._sortedList == i.List._value and {} or (i._sortedList or {});
                table.clear(v20);
                v19 = i;
                local v21 = 1;

                for i2 in i.List._value do
                    v20[v21] = i2;
                    v21 = v21 + 1;
                end;

                v19._sortedList = v20;
            elseif i._sortFunction then
                i._sortedList = table.clone(i.List._value);
                v19 = i;
            else
                i._sortedList = i.List._value;
                v19 = i;
            end;

            if v19._sortFunction then
                table.sort(v19._sortedList, v19._sortFunction);
            end;
        else
            i:cloneRaw();
        end;
    end;

    if os.clock() - os_clock_ret > 0.011111111111111112 then
        return;
    end;

    local v22 = u15;
    u15 = {};

    for i in v22 do
        if i._instance.Visible and os.clock() - os_clock_ret <= 0.011111111111111112 then
            local v23;

            if i._filterFunction then
                v23 = i._filterFunction(i, i._sortedList);
            else
                v23 = i._sortedList;
            end;

            i._filteredList = v23;

            if not i.DictList._value then
                local Offset = i.ItemSize._value.Y.Offset;

                if i._lastValue and Offset < i._scroller.CanvasPosition.Y then
                    local v24 = #i._filteredList - i._lastLength;

                    if v24 == 0 then
                        v24 = (table.find(i._filteredList, i._lastValue) or 1) - 1;
                    end;

                    local _scroller = i._scroller;
                    _scroller.CanvasPosition = _scroller.CanvasPosition + Vector2.new(0, v24 * Offset);
                end;

                i._lastLength = #i._filteredList;
                i._lastValue = i._filteredList[1];
            end;

            i:render(true);
        else
            i:refreshList();
        end;
    end;

    if os.clock() - os_clock_ret > 0.011111111111111112 then
        return;
    end;

    local v25 = u16;
    u16 = {};

    for i in v25 do
        if i._instance.Visible and os.clock() - os_clock_ret <= 0.011111111111111112 then
            i:forceRender();
        else
            i:render();
        end;
    end;
end);

function u5.forceRender(p26) -- Line: 160
    -- upvalues: Parent (copy)
    if not (p26.Enabled._value and (p26._instance.Visible and p26._filteredList)) then
        return;
    end;

    local v27 = #p26._filteredList;
    local Offset = p26.ItemSize._value.Y.Offset;
    local math_floor_ret = math.floor(p26._scroller.CanvasPosition.Y / Offset);
    local v28 = math.max(0, math_floor_ret) + 1;
    local v29 = v28 + math.ceil(p26._scroller.AbsoluteWindowSize.Y / Offset);
    local math_min_ret = math.min(v29, v27);
    local UIPadding = p26._scroller:FindFirstChild("UIPadding");
    p26._scroller.CanvasSize = UDim2.new(0, 0, 0, v27 * Offset + (not UIPadding and 0 or UIPadding.PaddingTop.Offset + UIPadding.PaddingBottom.Offset));
    local v30 = {};

    for i = math.max(1, v28 - 4), math.min(v27, math_min_ret + 4) do
        local v31;

        if p26.ReverseOrder._value then
            v31 = p26._filteredList[v27 - i + 1];
        else
            v31 = p26._filteredList[i];
        end;

        local v32 = p26._lineItemCache[v31];

        if not v32 then
            v32 = table.remove(p26._lineItemFree);

            if not v32 then
                if p26.CreateItem then
                    v32 = p26.CreateItem._value(p26, v31);
                else
                    v32 = Parent.new("TextLabel")({
                        AutoLocalize = false,
                        BackgroundTransparency = 1,
                        RichText = true,
                        Size = p26.ItemSize,
                        FontFace = Parent.Theme.FontMono,
                        TextSize = Parent.Theme.FontSize,
                        TextColor3 = Parent.Theme.PrimaryText,
                        TextStrokeColor3 = Parent.Theme.Primary,
                        TextStrokeTransparency = Parent.Theme.TextStrokeTransparency,
                        TextTruncate = Enum.TextTruncate.SplitWord,
                        TextXAlignment = Enum.TextXAlignment.Left
                    });
                end;
            end;

            p26._lineItemCache[v31] = v32;

            if p26.RenderItem then
                p26.RenderItem._value(p26, v32, v31);
            else
                v32.Text = v31;
            end;

            local v33;

            if type(v32) == "table" then
                v33 = v32._instance;
            else
                v33 = v32;
            end;

            v33.Position = UDim2.new(0, 0, 0, (i - 1) * Offset);
            v33.Parent = p26._scroller;
        end;

        v30[v31] = v32;
        local _ = i;
    end;

    p26:freeCache(v30);
end;

function u5.freeCache(p34: table, p35: table?) -- Line: 213
    for i, v in p34._lineItemCache do
        if not (p35 and p35[i]) then
            p34._lineItemCache[i] = nil;
            table.insert(p34._lineItemFree, v);
            local v36;

            if type(v) == "table" then
                v36 = v._instance;
            else
                v36 = v;
            end;

            v36.Parent = nil;
        end;
    end;
end;

function u5.updateList(p37) -- Line: 226
    -- upvalues: u13 (ref)
    u13[p37] = true;
end;

function u5.cloneRaw(p38) -- Line: 230
    -- upvalues: u14 (ref)
    u14[p38] = true;
end;

function u5.refreshList(p39) -- Line: 234
    -- upvalues: u15 (ref)
    u15[p39] = true;
end;

function u5.render(p40: table, p41: boolean?) -- Line: 238
    -- upvalues: u16 (ref)
    if p41 then
        p40:freeCache();
    end;

    u16[p40] = true;
end;

function u5.filter(p42: table, p43: function) -- Line: 245
    p42._filterFunction = p43;
    p42.Enabled(true);
    p42:refreshList();
end;

function u5.sort(p44: table, p45: function) -- Line: 251
    p44._sortFunction = p45;

    if p44._instance.Visible then
        if p45 then
            if p44._sortedList then
                table.sort(p44._sortedList, p45);
            end;
        else
            p44:cloneRaw();
        end;

        p44:refreshList();
    end;
end;

local u46 = {
    Enabled = true,
    DictList = false,
    FilterInput = false,
    FilterInputDebounce = 0,
    ReverseOrder = false,
    Visible = true,

    ItemSize = function() -- Line: 267, Name: ItemSize
        -- upvalues: Parent (copy)
        return UDim2.new(1, 0, 0, Parent.Theme.FontSize() + Parent.Theme.PaddingDouble().Offset);
    end,

    List = {},
    CreateItem = Parent.Function,
    RenderItem = Parent.Function
};

function u5.new(p47) -- Line: 282
    -- upvalues: u46 (copy), Parent (copy), u5 (copy), defaultFilter (copy)
    local table_clone_ret = table.clone(u46);
    Parent.makeStatefulDefaults(table_clone_ret, p47);
    table_clone_ret._lineItemCache = {};
    table_clone_ret._lineItemFree = {};
    table_clone_ret._lastSizeY = 0;
    table_clone_ret._lastScrollY = 0;

    local function render() -- Line: 291
        -- upvalues: Parent (ref), table_clone_ret (ref)
        Parent.clearState("hover");
        local Y = table_clone_ret._scroller.AbsoluteWindowSize.Y;
        local Y2 = table_clone_ret._scroller.CanvasPosition.Y;

        if Y ~= table_clone_ret._lastSizeY or Y2 ~= table_clone_ret._lastScrollY then
            if Y <= math.abs(Y2 - table_clone_ret._lastScrollY) then
                table_clone_ret:forceRender();
            else
                table_clone_ret:render();
            end;

            table_clone_ret._lastSizeY = Y;
            table_clone_ret._lastScrollY = Y2;
        end;
    end;

    table_clone_ret._scroller = Parent.new("ScrollingFrame")({
        Name = "ScrollerFast",
        BorderSizePixel = 0,
        BackgroundTransparency = 1,
        Position = UDim2.new(0, 0, 0, 0),
        Size = UDim2.new(1, 0, 1, 0),
        ScrollBarThickness = 8,
        ScrollBarImageColor3 = Parent.Theme.Secondary,
        ScrollBarImageTransparency = Parent.Theme.TransparencyClamped,
        TopImage = Parent.Theme.ScrollTopImage,
        MidImage = Parent.Theme.ScrollMidImage,
        BottomImage = Parent.Theme.ScrollBottomImage,
        VerticalScrollBarInset = Enum.ScrollBarInset.ScrollBar,
        Parent.new("UIFlexItem")({
            FlexMode = Enum.UIFlexMode.Fill
        }),
        [Parent.Event] = {
            AbsoluteWindowSize = render,
            CanvasPosition = render
        }
    });
    local u48 = Parent.new("UIPadding")({
        Parent = table_clone_ret._scroller,
        PaddingBottom = Parent.Theme.PaddingWithStroke,
        PaddingTop = Parent.Theme.PaddingWithStroke,
        PaddingLeft = Parent.Theme.PaddingStroke,
        PaddingRight = Parent.Theme.PaddingWithStroke
    });

    local function updatePadding() -- Line: 339
        -- upvalues: Parent (ref), u48 (copy), table_clone_ret (ref)
        local edit = Parent.edit;
        local v49 = {};
        local v50;

        if table_clone_ret._scroller.AbsoluteCanvasSize.Y > table_clone_ret._scroller.AbsoluteWindowSize.Y then
            v50 = Parent.Theme.PaddingWithStroke;
        else
            v50 = UDim.new();
        end;

        v49.PaddingRight = v50;
        edit(u48, v49);
    end;

    updatePadding();
    local v51 = { table_clone_ret._scroller:GetPropertyChangedSignal("AbsoluteWindowSize"):Connect(updatePadding), table_clone_ret._scroller:GetPropertyChangedSignal("AbsoluteCanvasSize"):Connect(updatePadding) };
    table_clone_ret._instance = Parent.new("Frame")({
        Name = "ScrollerFast",
        BackgroundTransparency = 1,
        Size = UDim2.new(1, 0, 1, 0),
        Visible = table_clone_ret.Visible,
        Parent.new("UIListLayout")({
            SortOrder = Enum.SortOrder.LayoutOrder,
            Padding = Parent.Theme.Padding
        }),
        table_clone_ret._scroller,
        [Parent.Clean] = v51,
        [Parent.Event] = {
            Parent = render
        }
    });
    table_clone_ret = setmetatable(table_clone_ret, u5);
    table.insert(v51, table_clone_ret.List:Connect(function() -- Line: 372
        -- upvalues: table_clone_ret (ref)
        table_clone_ret:updateList();
    end));
    table_clone_ret:updateList();

    local function refresh() -- Line: 378
        -- upvalues: table_clone_ret (ref)
        table_clone_ret:refreshList();
    end;

    table.insert(v51, Parent.Theme.FontSize:Connect(refresh));
    table.insert(v51, Parent.Theme.Padding:Connect(refresh));

    if table_clone_ret.FilterInput._value then
        local u52 = false;

        local function debounce() -- Line: 386
            -- upvalues: u52 (ref), table_clone_ret (ref)
            if typeof(u52) == "thread" and coroutine.status(u52) == "suspended" then
                task.cancel(u52);
            end;

            u52 = task.delay(table_clone_ret.FilterInputDebounce._value, table_clone_ret.refreshList, table_clone_ret);
        end;

        table_clone_ret._input = Parent.new("Input")({
            LayoutOrder = -1,
            ClearTextButton = true,
            Fill = true,
            Placeholder = "Search",
            Parent = table_clone_ret._instance,
            Icon = Parent.Theme.Image.Search,
            IconProperties = {
                ImageColor3 = Parent.Theme.PrimaryText,
                Size = UDim2.fromOffset(18, 18)
            }
        });
        local PropertyChangedSignal = table_clone_ret._input._input:GetPropertyChangedSignal("Text");
        table.insert(v51, PropertyChangedSignal:Connect(debounce));
        table_clone_ret:filter(defaultFilter);
    end;

    return setmetatable(table_clone_ret, u5);
end;

return u5;