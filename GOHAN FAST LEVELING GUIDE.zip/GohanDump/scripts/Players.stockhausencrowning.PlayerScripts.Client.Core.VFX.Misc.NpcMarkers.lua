-- Decompiled with Potassium's decompiler.

local Players = game:GetService("Players");
local RunService = game:GetService("RunService");
local ReplicatedStorage = game:GetService("ReplicatedStorage");
local NpcMarkerData = require(ReplicatedStorage.Modules.Metadata.NPCData.NpcMarkerData);
local Remotes = ReplicatedStorage:WaitForChild("Remotes");
local LocalPlayer = Players.LocalPlayer;
local Bangers = Enum.Font.Bangers;
local Color3_fromRGB_ret = Color3.fromRGB(196, 156, 74);
local Color3_fromRGB_ret2 = Color3.fromRGB(255, 253, 247);
local Color3_fromRGB_ret3 = Color3.fromRGB(255, 196, 68);
local Color3_fromRGB_ret4 = Color3.fromRGB(122, 220, 122);
local Color3_fromRGB_ret5 = Color3.fromRGB(8, 7, 6);
local u1 = {};
local u2 = {};
local u3 = nil;
local u4 = nil;
local u5 = nil;
local u6 = 0;

local function resolveTag(p7, p8) -- Line: 71
    -- upvalues: NpcMarkerData (copy)
    if NpcMarkerData.Hidden[p7.Name] then
        return false;
    end;

    local Parent = p7.Parent;
    local v9 = {};

    while Parent and Parent ~= p8 do
        table.insert(v9, 1, Parent.Name);
        Parent = Parent.Parent;
    end;

    if #v9 == 0 then
        return nil;
    end;

    local v10 = v9[1];

    if NpcMarkerData.HiddenGroups[v10] then
        return false;
    end;

    local v11 = NpcMarkerData.TagOverrides[p7.Name];

    if v11 then
        return v11;
    end;

    for i = #v9, 2, -1 do
        local v12 = NpcMarkerData.SubFolderTags[v9[i]];

        if v12 then
            return v12;
        end;

        local _ = i;
    end;

    return NpcMarkerData.GroupTags[v10];
end;

local function makeLabel(p13, p14, p15, p16, p17, p18, p19) -- Line: 99
    -- upvalues: Bangers (copy), Color3_fromRGB_ret5 (copy)
    local TextLabel = Instance.new("TextLabel");
    TextLabel.BackgroundTransparency = 1;
    TextLabel.Size = UDim2.new(1, 0, 0, p16);
    TextLabel.Position = UDim2.new(0, 0, 0, p15);
    TextLabel.Font = Bangers;
    TextLabel.Text = p14;
    TextLabel.TextSize = p17;
    TextLabel.TextColor3 = p18;
    TextLabel.Parent = p13;
    local UIStroke = Instance.new("UIStroke");
    UIStroke.Color = Color3_fromRGB_ret5;
    UIStroke.Thickness = p19;
    UIStroke.Parent = TextLabel;

    return TextLabel;
end;

local function resolveAnchor(p20) -- Line: 126
    local Head = p20:FindFirstChild("Head");

    if Head and Head:IsA("BasePart") then
        return Head;
    end;

    local v21 = Head and Head:IsA("Model") and (Head.PrimaryPart or Head:FindFirstChildWhichIsA("BasePart", true));

    if v21 then
        return v21;
    end;

    local HumanoidRootPart = p20:FindFirstChild("HumanoidRootPart");

    if HumanoidRootPart and HumanoidRootPart:IsA("BasePart") then
        return HumanoidRootPart;
    end;

    if p20.PrimaryPart then
        return p20.PrimaryPart;
    end;

    return p20:FindFirstChildWhichIsA("BasePart", true);
end;

local function anchorOffset(u22, p23) -- Line: 150
    local v25, v26, v27 = pcall(function() -- Line: 151
        -- upvalues: u22 (copy)
        local BoundingBox, v24 = u22:GetBoundingBox();

        return BoundingBox, v24;
    end);

    if not (v25 and (v26 and v27)) then
        return 5;
    end;

    local v28 = v26.Position.Y + v27.Y / 2 - p23.Position.Y + 3;

    return (v28 ~= v28 or (v28 < 0.5 or v28 > 60)) and 5 or v28;
end;

local function formatClock(p29) -- Line: 163
    local math_floor_ret = math.floor(p29);
    local math_max_ret = math.max(0, math_floor_ret);

    if math_max_ret >= 3600 then
        return string.format("%d:%02d:%02d", math.floor(math_max_ret / 3600), math.floor(math_max_ret / 60) % 60, math_max_ret % 60);
    end;

    return string.format("%d:%02d", math.floor(math_max_ret / 60), math_max_ret % 60);
end;

local function buildMarker(p30, p31, p32, p33) -- Line: 172
    -- upvalues: resolveAnchor (copy), anchorOffset (copy), LocalPlayer (copy), makeLabel (copy), Color3_fromRGB_ret3 (copy), Color3_fromRGB_ret (copy), Color3_fromRGB_ret2 (copy)
    local v34 = resolveAnchor(p30);

    if not v34 then
        return nil;
    end;

    local BillboardGui = Instance.new("BillboardGui");
    BillboardGui.Name = "NpcMarker";
    BillboardGui.Adornee = v34;
    BillboardGui.AlwaysOnTop = true;
    BillboardGui.LightInfluence = 0;
    BillboardGui.MaxDistance = 70;
    BillboardGui.Size = UDim2.fromOffset(170, (p31 and 70 or 56) + (p33 and 16 or 0));
    local v35 = anchorOffset(p30, v34);
    BillboardGui.StudsOffsetWorldSpace = Vector3.new(0, v35, 0);
    BillboardGui.Parent = LocalPlayer:FindFirstChildOfClass("PlayerGui");
    local v36 = {};
    local v37 = 0;
    local v38;

    if p33 then
        v38 = makeLabel(BillboardGui, "", v37, 15, 15, Color3_fromRGB_ret3, 2);
        v36[#v36 + 1] = v38;
        v37 = v37 + 16;
    else
        v38 = nil;
    end;

    if p31 then
        v36[#v36 + 1] = makeLabel(BillboardGui, "[" .. p31 .. "]", v37, 14, 14, Color3_fromRGB_ret, 2);
        v37 = v37 + 14;
    end;

    v36[#v36 + 1] = makeLabel(BillboardGui, string.upper(p30.Name), v37, 24, 24, Color3_fromRGB_ret2, 2.5);
    local v39 = v37 + 23;

    if p32 then
        v36[#v36 + 1] = makeLabel(BillboardGui, p32, v39, 16, 16, Color3_fromRGB_ret3, 2);
        v39 = v39 + 17;
    end;

    v36[#v36 + 1] = makeLabel(BillboardGui, "▼", v39, 15, 14, Color3_fromRGB_ret3, 2);

    return BillboardGui, v36, v34, v38;
end;

function u1.Clear() -- Line: 221
    -- upvalues: u6 (ref), u3 (ref), u2 (copy)
    u6 = u6 + 1;

    if u3 then
        u3:Disconnect();
        u3 = nil;
    end;

    for _, v in pairs(u2) do
        if v.gui then
            v.gui:Destroy();
        end;
    end;

    table.clear(u2);
end;

local function addFor(p40, p41) -- Line: 230
    -- upvalues: u2 (copy), resolveTag (copy), NpcMarkerData (copy), buildMarker (copy), anchorOffset (copy)
    if u2[p40] then
        return;
    end;

    if not p40:FindFirstChildOfClass("Humanoid") then
        return;
    end;

    local v42 = resolveTag(p40, p41);

    if v42 == false then
        return;
    end;

    local v43;

    if NpcMarkerData.Dailies then
        v43 = NpcMarkerData.Dailies[p40.Name] or nil;
    else
        v43 = nil;
    end;

    local v44, v45, v46, v47 = buildMarker(p40, v42, NpcMarkerData.Roles[p40.Name], v43);

    if not v44 then
        return;
    end;

    u2[p40] = {
        readyAt = nil,
        gui = v44,
        labels = v45,
        anchor = v46,
        baseY = anchorOffset(p40, v46),
        phase = #u2 % 8 * 0.6,
        daily = v43,
        dailyLabel = v47
    };
end;

local function scan(p48) -- Line: 257
    -- upvalues: addFor (copy), u2 (copy)
    for _, descendant in ipairs(p48:GetDescendants()) do
        if descendant:IsA("Model") then
            addFor(descendant, p48);
        end;
    end;

    for i, v in pairs(u2) do
        if not i.Parent then
            if v.gui then
                v.gui:Destroy();
            end;

            u2[i] = nil;
        end;
    end;
end;

function u1.Start(p49) -- Line: 275
    -- upvalues: u1 (copy), u6 (ref), scan (copy), u5 (ref), u2 (copy), Remotes (copy), formatClock (copy), Color3_fromRGB_ret3 (copy), Color3_fromRGB_ret4 (copy), u4 (ref), u3 (ref), RunService (copy)
    u1.Clear();
    local u50 = u6;
    local World = workspace:FindFirstChild("World");

    if World then
        World = World:FindFirstChild("NPC");
    end;

    if not World then
        return;
    end;

    scan(World);
    u5 = task.spawn(function() -- Line: 293
        -- upvalues: u6 (ref), u50 (copy), u2 (ref), Remotes (ref), formatClock (ref), Color3_fromRGB_ret3 (ref), Color3_fromRGB_ret4 (ref)
        local v51 = 0;

        while u6 == u50 do
            if v51 % 30 == 0 then
                local v52 = {};
                local v53 = false;

                for _, v in pairs(u2) do
                    local daily = v.daily;

                    if daily then
                        if daily.HTC then
                            v53 = true;
                        elseif daily.Daily then
                            v52[daily.Daily] = true;
                        end;
                    end;
                end;

                local v54 = nil;

                if v53 then
                    local success, result = pcall(function() -- Line: 310
                        -- upvalues: Remotes (ref)
                        local StatRetrieveRemote = Remotes:FindFirstChild("StatRetrieveRemote");

                        if StatRetrieveRemote then
                            StatRetrieveRemote = StatRetrieveRemote:InvokeServer("HTC", "TableStat");
                        end;

                        return StatRetrieveRemote;
                    end);

                    if success and type(result) == "table" then
                        local v55 = tonumber(result.lastClaimed) or 0;
                        local v56 = tonumber(result.timeStarted) or 0;
                        local os_time_ret = os.time();
                        v54 = (v55 == 0 or os_time_ret - v56 < 900) and 0 or v55 + 86400;
                    end;
                end;

                local v57 = {};

                for i in pairs(v52) do
                    local success, result = pcall(function() -- Line: 331
                        -- upvalues: Remotes (ref), i (copy)
                        local DailyRemote = Remotes:FindFirstChild("DailyRemote");

                        if DailyRemote then
                            DailyRemote = DailyRemote:InvokeServer({
                                Action = "CheckTimeLeft",
                                DailyName = i
                            });
                        end;

                        return DailyRemote;
                    end);

                    if success and type(result) == "number" then
                        v57[i] = os.time() + math.max(0, result);
                    end;
                end;

                if u6 ~= u50 then
                    return;
                end;

                for _, v in pairs(u2) do
                    local daily = v.daily;

                    if daily then
                        if daily.HTC then
                            v.readyAt = v54 or v.readyAt;
                        elseif daily.Daily then
                            v.readyAt = v57[daily.Daily] or v.readyAt;
                        end;
                    end;
                end;
            end;

            local os_time_ret = os.time();

            for _, v in pairs(u2) do
                local dailyLabel = v.dailyLabel;

                if dailyLabel and (dailyLabel.Parent and v.readyAt) then
                    local v58 = v.readyAt - os_time_ret;

                    if v58 > 0 then
                        dailyLabel.Text = v.daily.Label .. " " .. formatClock(v58);
                        dailyLabel.TextColor3 = Color3_fromRGB_ret3;
                    else
                        dailyLabel.Text = v.daily.Label .. " READY";
                        dailyLabel.TextColor3 = Color3_fromRGB_ret4;
                    end;
                end;
            end;

            v51 = v51 + 1;
            task.wait(1);
        end;
    end);
    u4 = task.spawn(function() -- Line: 376
        -- upvalues: u6 (ref), u50 (copy), World (copy), scan (ref)
        while u6 == u50 do
            task.wait(2);

            if u6 ~= u50 then
                return;
            end;

            if World.Parent then
                scan(World);
            end;
        end;
    end);
    u3 = RunService.Heartbeat:Connect(function() -- Line: 387
        -- upvalues: u2 (ref)
        local workspace_CurrentCamera = workspace.CurrentCamera;

        if not workspace_CurrentCamera then
            return;
        end;

        local Position = workspace_CurrentCamera.CFrame.Position;
        local os_clock_ret = os.clock();

        for _, v in pairs(u2) do
            local gui = v.gui;
            local anchor = v.anchor;

            if gui and (gui.Parent and (anchor and anchor.Parent)) then
                local v59 = v.baseY + math.sin((os_clock_ret + v.phase) * 3.141592653589793) * 0.22;
                gui.StudsOffsetWorldSpace = Vector3.new(0, v59, 0);
                local Magnitude = (anchor.Position - Position).Magnitude;
                local v60 = Magnitude <= 55 and 0 or math.clamp((Magnitude - 55) / 15, 0, 1);

                for _, v2 in ipairs(v.labels) do
                    v2.TextTransparency = v60;
                    local v61 = v2:FindFirstChildOfClass("UIStroke");

                    if v61 then
                        v61.Transparency = v60;
                    end;
                end;
            end;
        end;
    end);
end;

return u1;