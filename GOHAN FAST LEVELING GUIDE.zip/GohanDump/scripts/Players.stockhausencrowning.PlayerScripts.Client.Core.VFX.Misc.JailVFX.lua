-- Decompiled with Potassium's decompiler.

local Players = game:GetService("Players");
local Debris = game:GetService("Debris");
local ReplicatedStorage = game:GetService("ReplicatedStorage");
game:GetService("RunService");
game:GetService("CollectionService");
local Modules = ReplicatedStorage:WaitForChild("Modules");
ReplicatedStorage:WaitForChild("Remotes");
local Assets = ReplicatedStorage.Assets;
local _ = Modules.Metadata;
local Shared = Modules.Shared;
local _ = Modules.Utility;
require(Shared.SoundManager);
require(Modules.GlobalFunctions);
require(Shared.CinemaManager);
local Visuals = workspace.World.Visuals;
local _ = Players.LocalPlayer;
local _ = Assets.Sounds;
local Effects = Assets.Effects;
local _ = Effects.Particles;

return {
    ["Jail Transport"] = function(p1) -- Line: 34
        -- upvalues: Effects (copy), Visuals (copy), Debris (copy)
        local _ = p1.Character;
        local _ = p1.Victim;
        local Location = p1.Location;
        local v2 = Effects.Beams.JailBeam:Clone();
        v2.Parent = Visuals;
        v2.CFrame = Location;

        for _, descendant in pairs(v2:GetDescendants()) do
            if descendant:IsA("ParticleEmitter") then
                local u3 = descendant.Rate + 15;
                descendant.Rate = 0;
                task.delay(3, function() -- Line: 52
                    -- upvalues: descendant (copy), u3 (copy)
                    descendant.Rate = u3;
                    task.wait(3);
                    descendant.Enabled = false;
                end);
            elseif descendant:IsA("Beam") then
                task.spawn(function() -- Line: 60
                    -- upvalues: descendant (copy)
                    for i = 1, 50 do
                        local v4 = 1 - i / 100;
                        descendant.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, v4), NumberSequenceKeypoint.new(0.5, v4), NumberSequenceKeypoint.new(1, v4) });
                        task.wait();
                        local _ = i;
                    end;
                end);
                task.delay(6, function() -- Line: 72
                    -- upvalues: descendant (copy)
                    for i = 1, 50 do
                        local v5 = i / 100 + 0.5;
                        descendant.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, v5), NumberSequenceKeypoint.new(0.5, v5), NumberSequenceKeypoint.new(1, v5) });
                        task.wait();
                        local _ = i;
                    end;
                end);
            end;
        end;

        Debris:AddItem(v2, 10);
    end
};