-- Decompiled with Potassium's decompiler.

local Debris = game:GetService("Debris");
local ReplicatedStorage = game:GetService("ReplicatedStorage");
local Modules = ReplicatedStorage:WaitForChild("Modules");
local SoundManager = require(Modules.Shared.SoundManager);
local GlobalFunctions = require(Modules.GlobalFunctions);
local BeamRigVFX = require(script.Parent.BeamRigVFX);
local Visuals = workspace.World.Visuals;
local Effects = ReplicatedStorage.Assets.Effects;
local Wave = Effects.Skills.Wave;

local function multNumberSequence(p1, p2) -- Line: 39
    local v3 = {};

    for i = 1, #p1.Keypoints do
        local v4 = p1.Keypoints[i];
        table.insert(v3, NumberSequenceKeypoint.new(v4.Time, v4.Value * p2));
        local _ = i;
    end;

    return NumberSequence.new(v3);
end;

return {
    Start = function(p5) -- Line: 50
        -- upvalues: GlobalFunctions (copy), Wave (copy), Visuals (copy), SoundManager (copy), Debris (copy)
        local Character = p5.Character;

        if not Character then
            return;
        end;

        local RootAndHumanoid = GlobalFunctions.GetRootAndHumanoid(Character);

        if not RootAndHumanoid then
            return;
        end;

        local v6 = Character:FindFirstChild("Left Arm") or RootAndHumanoid;
        local u7 = p5.TweenTime or 1;
        local math_min_ret = math.min(p5.StartSize or 1, 200);
        local v8 = p5.Color or Color3.fromRGB(255, 0, 0);
        local v9 = p5.StartLocation or v6.CFrame * CFrame.new(0, -2, 0);
        local v10 = p5.WeldLocation or v6;
        local v11 = p5.WeldInformation or CFrame.new(0, -2, 0);
        local v12 = p5.StartSoundName or "Beam Charge";
        local v13 = p5.SpecialEffect or false;
        local Rig = p5.Rig;
        local v14 = Rig and Wave:FindFirstChild(Rig .. " Start") or Wave["Wave Start"];

        if not (Rig and Wave:FindFirstChild(Rig .. " End")) then
            local _ = Wave["Wave End"];
        end;

        local u15 = v14:Clone();
        local u16 = u15["Inner Wave Point"];
        u15.CFrame = v9;
        u15.Name = "Beam" .. Character.Name;
        u15.Color = v8;
        u15.Size = Vector3.new(0, 0, 0);
        u15.Anchored = false;
        u15.Transparency = 1;
        u16.Size = Vector3.new(0, 0, 0);
        u16.Transparency = 1;
        u15.Parent = Visuals;

        for _, child in ipairs(u15.Main1:GetChildren()) do
            child.Enabled = true;

            if child.Name == "Circle0" then
                child.Rate = 250;
            else
                child.Color = ColorSequence.new({ ColorSequenceKeypoint.new(0, v8), ColorSequenceKeypoint.new(1, v8) });
            end;
        end;

        local Weld = Instance.new("Weld");
        Weld.Part0 = v10;
        Weld.Part1 = u15;
        Weld.C0 = v11;
        Weld.Parent = u15;
        SoundManager.AddSound(v12, {
            Parent = u15
        }, "Client");
        GlobalFunctions.Tween({
            Instance = u15,
            Duration = u7
        }, {
            Size = Vector3.new(1, 1, 1) * math_min_ret
        });
        GlobalFunctions.Tween({
            Instance = u16,
            Duration = u7
        }, {
            Size = Vector3.new(1, 1, 1) * (math_min_ret * 0.9)
        });

        if v13 then
            for _, child in ipairs(u16.SpecialEffect:GetChildren()) do
                child.Enabled = true;
                child.Color = ColorSequence.new({ ColorSequenceKeypoint.new(0, v8), ColorSequenceKeypoint.new(1, v8) });
            end;
        end;

        task.spawn(function() -- Line: 130
            -- upvalues: Character (copy), u15 (copy), u7 (copy), GlobalFunctions (ref), u16 (copy), Debris (ref)
            local function stillCharging() -- Line: 131
                -- upvalues: Character (ref)
                return Character:GetAttribute("State_ChargingBeam") ~= nil and true or Character:FindFirstChild("Charging Beam") ~= nil;
            end;

            local function interrupted() -- Line: 135
                -- upvalues: Character (ref)
                return (Character:GetAttribute("State_Stunned") ~= nil or (Character:GetAttribute("State_Knocked") ~= nil or (Character:GetAttribute("State_KO") ~= nil or Character:GetAttribute("State_Dead") ~= nil))) and true or Character:FindFirstChild("Stun") ~= nil;
            end;

            while (Character:GetAttribute("State_ChargingBeam") ~= nil and true or Character:FindFirstChild("Charging Beam") ~= nil) and (not interrupted() and u15.Parent) do
                task.wait();
            end;

            for _, descendant in ipairs(u15:GetDescendants()) do
                if descendant:IsA("ParticleEmitter") then
                    descendant.Enabled = false;
                end;
            end;

            local math_min_ret2 = math.min(u7, 0.4);
            local v17 = {
                Size = Vector3.new(0, 0, 0)
            };
            GlobalFunctions.Tween({
                Instance = u15,
                Duration = math_min_ret2
            }, v17);
            GlobalFunctions.Tween({
                Instance = u16,
                Duration = math_min_ret2
            }, v17);
            Debris:AddItem(u15, math_min_ret2 + 0.1);
        end);
    end,

    Fire = function(p18) -- Line: 161
        -- upvalues: Wave (copy), BeamRigVFX (copy), GlobalFunctions (copy), multNumberSequence (copy), Visuals (copy), SoundManager (copy), Debris (copy), Effects (copy)
        local v19 = p18.Rig and Wave:FindFirstChild(p18.Rig .. " Rig") or Wave:FindFirstChild("Beam Rig");

        if v19 and v19:IsA("Model") then
            return BeamRigVFX.Fire(p18);
        end;

        local Character = p18.Character;

        if not Character then
            return;
        end;

        local RootAndHumanoid = GlobalFunctions.GetRootAndHumanoid(Character);

        if not RootAndHumanoid then
            return;
        end;

        local v20 = Character:FindFirstChild("Left Arm") or RootAndHumanoid;
        local v21 = p18.StartSize or 5;
        local u22 = p18.EndSize or (p18.StartSize or 5);
        local u23 = p18.Length or 10;
        local v24 = p18.Speed or 5;
        local v25 = p18.Duration or 4;
        local u26 = p18.CloseDuration or 0.5;
        local u27 = p18.Color or Color3.fromRGB(255, 0, 0);
        local v28 = p18.SecondaryColor or Color3.fromRGB(255, 255, 255);
        local v29 = p18.StartLocation or v20.CFrame * CFrame.new(0, -2, 0);
        local v30 = p18.StartSoundName or "Death Beam";
        local v31 = p18.MousePosition or false;
        local v32 = p18.Rings or false;
        local u33 = p18.RingDelay or 0;
        local u34 = p18.RingColor or Color3.fromRGB(255, 255, 255);
        local u35 = p18.RingAmt or 25;
        local u36 = p18.ForceColor == true;
        local u37 = v24 + v25;

        local function fixParticles(p38, p39) -- Line: 205
            -- upvalues: u36 (copy), u27 (copy), multNumberSequence (ref)
            p38.Enabled = true;

            if p38:GetAttribute("KeepColor") and not u36 then
                return;
            end;

            if p38.Name == "Circle0" then
                p38.Rate = 150;
            else
                p38.Color = ColorSequence.new({ ColorSequenceKeypoint.new(0, u27), ColorSequenceKeypoint.new(1, u27) });
                p38.Rate = p38.Rate * 1.5;
            end;

            p38.Size = multNumberSequence(p38.Size, p39 / 3);
        end;

        local Rig = p18.Rig;
        local v40 = Rig and Wave:FindFirstChild(Rig .. " Start") or Wave["Wave Start"];
        local v41 = Rig and Wave:FindFirstChild(Rig .. " End") or Wave["Wave End"];
        local u42 = v40:Clone();
        local u43 = u42["Inner Wave Point"];
        u42.CFrame = v29;
        u42.Name = "STARTBeam" .. Character.Name;
        u42.Color = u27;
        u42.Size = Vector3.new(1, 1, 1) * v21;
        u42.Transparency = 1;
        u43.Size = Vector3.new(1, 1, 1) * (v21 * 0.85);
        u43.Color = v28;
        u43.Transparency = 1;
        u42.Parent = Visuals;
        local u44 = v41:Clone();
        local u45 = u44["Inner Wave Point"];
        u44.CFrame = v29;
        u44.Name = "ENDBeam" .. Character.Name;
        u44.Color = u27;
        u44.Size = Vector3.new(1, 1, 1) * u22;
        u44.Transparency = 1;
        u45.Size = Vector3.new(1, 1, 1) * (u22 * 0.85);
        u45.Color = v28;
        u45.Transparency = 1;
        u44.Parent = Visuals;

        for _, child in ipairs(u42.Main1:GetChildren()) do
            fixParticles(child, v21);
        end;

        for _, child in ipairs(u44.BeamEnd:GetChildren()) do
            if child:IsA("ParticleEmitter") then
                fixParticles(child, u22);
            end;
        end;

        SoundManager.AddSound(v30, {
            Parent = u42
        }, "Client", {
            Duration = 2
        });
        local v46 = v31 or (p18.DefaultEndLocation or (u42.CFrame * CFrame.new(0, 0, -u23)).Position);
        u44.CFrame = CFrame.lookAt(u44.Position, v46);
        local v47 = u22 * 0.85;

        for _, child in ipairs(u42.BeamStart:GetChildren()) do
            if child:IsA("Attachment") then
                local v48 = u44.BeamEnd:FindFirstChild(child.Name) or u44.BeamEnd;

                for _, child2 in ipairs(child:GetChildren()) do
                    if child2:IsA("Beam") then
                        child2.Attachment1 = v48;
                        child2.Width0 = v47;
                        child2.Width1 = v47 / 2;
                        child2.Enabled = true;
                    end;
                end;
            elseif child:IsA("Beam") then
                child.Attachment1 = u44.BeamEnd;
                child.Width0 = child.Width0 * v21 / 3;
                child.Width1 = child.Width1 * u22 / 3;

                if u36 or child.Name ~= "Beam2" and not child:GetAttribute("KeepColor") then
                    child.Color = ColorSequence.new({ ColorSequenceKeypoint.new(0, u27), ColorSequenceKeypoint.new(1, u27) });
                end;

                child.Enabled = true;
            end;
        end;

        GlobalFunctions.Tween({
            Instance = u44,
            Duration = v24
        }, {
            CFrame = u44.CFrame * CFrame.new(0, 0, -u23)
        });
        local u49 = false;
        task.delay(u37, function() -- Line: 311, Name: closeBeam
            -- upvalues: u49 (ref), u42 (copy), u44 (copy), GlobalFunctions (ref), u26 (copy), u43 (copy), u45 (copy), Debris (ref)
            if u49 then
                return;
            end;

            u49 = true;

            for _, v in ipairs({ u42, u44 }) do
                for _, descendant in ipairs(v:GetDescendants()) do
                    if descendant:IsA("Beam") then
                        GlobalFunctions.Tween({
                            Instance = descendant,
                            Duration = u26
                        }, {
                            Width0 = 0,
                            Width1 = 0
                        });
                    elseif descendant:IsA("ParticleEmitter") then
                        descendant.Enabled = false;
                    end;
                end;
            end;

            local v50 = {
                Size = Vector3.new(0, 0, 0)
            };
            local v51 = GlobalFunctions.Tween({
                Instance = u42,
                Duration = u26
            }, v50);
            GlobalFunctions.Tween({
                Instance = u44,
                Duration = u26
            }, v50);
            GlobalFunctions.Tween({
                Instance = u43,
                Duration = u26
            }, v50);
            GlobalFunctions.Tween({
                Instance = u45,
                Duration = u26
            }, v50);
            task.delay(u26, function() -- Line: 335
                -- upvalues: u42 (ref), u44 (ref)
                for _, v in ipairs({ u42, u44 }) do
                    if v.Parent then
                        for _, descendant in ipairs(v:GetDescendants()) do
                            if descendant:IsA("Beam") then
                                descendant.Enabled = false;
                            end;
                        end;
                    end;
                end;
            end);
            v51.Completed:Once(function() -- Line: 344
                -- upvalues: Debris (ref), u42 (ref), u44 (ref)
                Debris:AddItem(u42, 0.1);
                Debris:AddItem(u44, 0.1);
            end);
        end);

        if not v32 then
            return;
        end;

        local function spawnRing(p52) -- Line: 354
            -- upvalues: Effects (ref), u44 (copy), u22 (copy), u34 (copy), Visuals (ref), Debris (ref), GlobalFunctions (ref), u37 (copy)
            local u53 = Effects.Meshes.Ring:Clone();
            u53.CFrame = u44.CFrame * CFrame.Angles(1.5707963267948966, 0, 0);
            u53.Position = p52;
            u53.Size = Vector3.new(1, 0.05, 1) * (1.1 + u22);
            u53.Color = u34;
            u53.Parent = Visuals;
            Debris:AddItem(u53, 5);
            GlobalFunctions.Tween({
                Duration = 3.5,
                Instance = u53,
                EasingStyle = Enum.EasingStyle.Exponential
            }, {
                Size = Vector3.new(1, 0.05, 1) * (1.1 + u22)
            });
            task.delay(u37, function() -- Line: 367
                -- upvalues: u53 (copy), GlobalFunctions (ref)
                if not u53.Parent then
                    return;
                end;

                GlobalFunctions.Tween({
                    Duration = 0.6,
                    Instance = u53,
                    EasingStyle = Enum.EasingStyle.Exponential
                }, {
                    Transparency = 1
                });
            end);
        end;

        task.spawn(function() -- Line: 375
            -- upvalues: u42 (copy), u44 (copy), u23 (copy), u35 (copy), u49 (ref), spawnRing (copy), u33 (copy)
            local Position = u42.Position;
            local v54 = u44.CFrame * CFrame.new(0, 0, -u23).Position - Position;

            if v54.Magnitude < 0.01 then
                return;
            end;

            for i = 0, u35 do
                if u49 then
                    break;
                end;

                spawnRing(Position + v54.Unit * i * v54.Magnitude / u35);
                task.wait(u33);
                local _ = i;
            end;
        end);
    end
};