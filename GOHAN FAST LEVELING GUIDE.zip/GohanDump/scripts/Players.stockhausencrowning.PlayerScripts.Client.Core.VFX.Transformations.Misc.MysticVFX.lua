-- Decompiled with Potassium's decompiler.

local Players = game:GetService("Players");
local Debris = game:GetService("Debris");
local ReplicatedStorage = game:GetService("ReplicatedStorage");
game:GetService("RunService");
game:GetService("CollectionService");
local Modules = ReplicatedStorage:WaitForChild("Modules");
ReplicatedStorage:WaitForChild("Remotes");
local Assets = ReplicatedStorage.Assets;
local _ = Modules.Metadata;
local Shared = Modules.Shared;
local _ = Modules.Utility;
require(Shared.SoundManager);
require(Modules.GlobalFunctions);
require(Shared.SoundManager);
local _ = workspace.World.Visuals;
local _ = Players.LocalPlayer;
local _ = Assets.Sounds;
local Particles = Assets.Effects.Particles;

return {
    Fire = function(p1) -- Line: 44
        -- upvalues: Particles (copy)
        local Character = p1.Character;
        local MysticAura = Particles:FindFirstChild("MysticAura");

        if not MysticAura then
            return;
        end;

        local function tag(p2) -- Line: 49
            p2:SetAttribute("MysticFX", true);

            return p2;
        end;

        for _, v in ipairs({ "Head", "Left Arm", "Right Arm", "Left Leg", "Right Leg" }) do
            local v3 = Character:FindFirstChild(v);

            if v3 then
                for _, child in ipairs(MysticAura.Limb:GetChildren()) do
                    local v4 = child:Clone();
                    v4:SetAttribute("MysticFX", true);
                    v4.Parent = v3;
                end;
            end;
        end;

        local Torso = Character:FindFirstChild("Torso");

        if Torso then
            local v5 = MysticAura.MysticAuraSheet:Clone();
            v5:SetAttribute("MysticFX", true);
            v5.Parent = Torso;
        end;

        local HumanoidRootPart = Character:FindFirstChild("HumanoidRootPart");

        if HumanoidRootPart then
            local v6 = MysticAura.MysticGround:Clone();
            v6:SetAttribute("MysticFX", true);
            v6.Parent = HumanoidRootPart;
        end;
    end,

    Disable = function(p7) -- Line: 79
        -- upvalues: Debris (copy)
        for _, descendant in ipairs(p7.Character:GetDescendants()) do
            if descendant:GetAttribute("MysticFX") then
                local v8;

                if descendant:IsA("ParticleEmitter") then
                    descendant.Enabled = false;
                    v8 = descendant;
                elseif descendant:IsA("Attachment") then
                    v8 = descendant;

                    for _, child in ipairs(descendant:GetChildren()) do
                        if child:IsA("ParticleEmitter") then
                            child.Enabled = false;
                        end;

                        if child:IsA("PointLight") then
                            child.Enabled = false;
                        end;
                    end;
                else
                    v8 = descendant;
                end;

                Debris:AddItem(v8, 2);
            end;
        end;
    end
};