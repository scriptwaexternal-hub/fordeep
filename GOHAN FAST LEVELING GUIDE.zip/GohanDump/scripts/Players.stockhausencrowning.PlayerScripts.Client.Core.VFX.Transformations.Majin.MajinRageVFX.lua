-- Decompiled with Potassium's decompiler.

local Players = game:GetService("Players");
local Debris = game:GetService("Debris");
local ReplicatedStorage = game:GetService("ReplicatedStorage");
game:GetService("RunService");
game:GetService("CollectionService");
local Modules = ReplicatedStorage:WaitForChild("Modules");
ReplicatedStorage:WaitForChild("Remotes");
local Assets = ReplicatedStorage.Assets;
local _ = Modules.Metadata;
local Shared = Modules.Shared;
local _ = Modules.Utility;
require(Shared.SoundManager);
local GlobalFunctions = require(Modules.GlobalFunctions);
require(Shared.SoundManager);
local _ = workspace.World.Visuals;
local _ = Players.LocalPlayer;
local _ = Assets.Sounds;
local Particles = Assets.Effects.Particles;

return {
    Fire = function(p1) -- Line: 36
        -- upvalues: GlobalFunctions (copy), Particles (copy)
        local Character = p1.Character;
        local _ = p1.CurrentRate;
        GlobalFunctions.GetRootAndHumanoid(Character);

        for _, child in pairs(Character:GetChildren()) do
            if child:IsA("Part") or child:IsA("MeshPart") then
                local v2 = Particles["Majin Glow"]:Clone();
                v2.Parent = child;
                v2.Enabled = true;
            end;
        end;
    end,

    Disable = function(p3) -- Line: 54
        -- upvalues: Debris (copy)
        for _, descendant in pairs(p3.Character:GetDescendants()) do
            if descendant.Name == "Majin Glow" then
                descendant.Enabled = false;
                Debris:AddItem(descendant, 5);
            end;
        end;
    end
};