-- Decompiled with Potassium's decompiler.

local u1 = nil;
local u2 = {};
u2.__index = u2;

function u2.new(p3, p4, p5, p6, p7) -- Line: 8
    -- upvalues: u2 (copy)
    local string_match_ret, v8, v9 = string.match(p3, "(%d%d%d%d)%-(%d%d)%-(%d%d)");
    local string_match_ret2, v10, v11 = string.match(p4, "(%d%d%d%d)%-(%d%d)%-(%d%d)");
    local v12;

    if string_match_ret then
        if v8 then
            v12 = v9;
        else
            v12 = v8;
        end;
    else
        v12 = string_match_ret;
    end;

    assert(v12, "Invalid start date format, use YYYY-MM-DD");
    local v13;

    if string_match_ret2 then
        if v10 then
            v13 = v11;
        else
            v13 = v10;
        end;
    else
        v13 = string_match_ret2;
    end;

    assert(v13, "Invalid finish date format, use YYYY-MM-DD");
    local os_time_ret = os.time({
        year = string_match_ret,
        month = v8,
        day = v9
    });
    local os_time_ret2 = os.time({
        year = string_match_ret2,
        month = v10,
        day = v11
    });
    assert(os_time_ret < os_time_ret2, "finish date must be greater than start date");

    return setmetatable({
        key = p5,
        seed = p6 or 0,
        curve = p7 or 1,
        start = os_time_ret,
        duration = os_time_ret2 - os_time_ret
    }, u2);
end;

function u2.test(p14, p15) -- Line: 28
    -- upvalues: u1 (ref)
    if u1 and u1[p14.key] ~= nil then
        return u1[p14.key];
    end;

    local v16 = (os.time() - p14.start) / p14.duration;
    local math_max_ret = math.max(1, v16);
    local math_clamp_ret = math.clamp(0, 1, math_max_ret);

    return Random.new(p15 + p14.seed):NextNumber() <= math_clamp_ret ^ p14.curve;
end;

function u2.setFFlagDictionary(p17, p18) -- Line: 36
    -- upvalues: u1 (ref)
    u1 = p18;
end;

return u2;