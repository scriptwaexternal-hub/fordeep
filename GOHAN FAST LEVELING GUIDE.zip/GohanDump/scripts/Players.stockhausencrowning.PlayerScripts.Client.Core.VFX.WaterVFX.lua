-- Decompiled with Potassium's decompiler.

local ReplicatedStorage = game:GetService("ReplicatedStorage");
local Debris = game:GetService("Debris");
local Assets = ReplicatedStorage:WaitForChild("Assets");
local Visuals = workspace:WaitForChild("World"):WaitForChild("Visuals");
local u1 = {};
local DownslamVFX = Assets.Effects.Particles:FindFirstChild("DownslamVFX");

if DownslamVFX then
    for _, descendant in ipairs(DownslamVFX:GetDescendants()) do
        if descendant:IsA("ParticleEmitter") and (descendant.Name == "Water Splash 8" or descendant.Name == "Water34") then
            table.insert(u1, descendant);
        end;
    end;
end;

local u2 = {
    ["Water Splash 8"] = 22,
    Water34 = 14
};
local ColorSequence_new_ret = ColorSequence.new({ ColorSequenceKeypoint.new(0, Color3.fromRGB(205, 235, 250)), ColorSequenceKeypoint.new(0.4, Color3.fromRGB(140, 195, 235)), ColorSequenceKeypoint.new(1, Color3.fromRGB(85, 145, 205)) });

return {
    Splash = function(p3) -- Line: 59, Name: Splash
        -- upvalues: u1 (copy), Visuals (copy), ColorSequence_new_ret (copy), u2 (copy), Debris (copy)
        local Position = p3.Position;

        if typeof(Position) ~= "Vector3" then
            return;
        end;

        if #u1 == 0 then
            return;
        end;

        local Part = Instance.new("Part");
        Part.Name = "WaterSplashFX";
        Part.Size = Vector3.new(1, 1, 1);
        Part.CFrame = CFrame.new(Position);
        Part.Anchored = true;
        Part.CanCollide = false;
        Part.CanQuery = false;
        Part.CanTouch = false;
        Part.Transparency = 1;
        Part.Parent = Visuals;
        local Attachment = Instance.new("Attachment");
        Attachment.Parent = Part;

        for _, v in ipairs(u1) do
            local v4 = v:Clone();
            v4.Enabled = false;
            v4.Color = ColorSequence_new_ret;
            v4.Parent = Attachment;
            v4:Emit(u2[v4.Name] or 15);
        end;

        Debris:AddItem(Part, 3);
    end
};