-- Decompiled with Potassium's decompiler.

local Parent = require(script.Parent.Parent);
local BaseClass = require(script.Parent:WaitForChild("BaseClass"));
local u1 = {};
local u2 = {};
u2.__index = u2;
setmetatable(u2, BaseClass);

function u2.new(p3) -- Line: 12
    -- upvalues: u1 (copy), Parent (copy), u2 (copy)
    local table_clone_ret = table.clone(u1);
    Parent.makeStatefulDefaults(table_clone_ret, p3);
    table_clone_ret._instance = Parent.new("Frame")({
        Name = "Spacer",
        BackgroundTransparency = 1,
        Parent.new("UIFlexItem")({
            FlexMode = Enum.UIFlexMode.Fill
        })
    });

    return setmetatable(table_clone_ret, u2);
end;

return u2;