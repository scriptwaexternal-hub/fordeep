-- Decompiled with Potassium's decompiler.

local ReplicatedStorage = game:GetService("ReplicatedStorage");
local UserInputService = game:GetService("UserInputService");
local Players = game:GetService("Players");
local Modules = ReplicatedStorage:WaitForChild("Modules");
local Remotes = ReplicatedStorage:WaitForChild("Remotes");
local Shared = Modules.Shared;
local ControlData = require(Modules.Metadata.ControlData.ControlData);
local AnimationManager = require(Shared.AnimationManager);
local u1 = require(Shared.Mouse).new();
local Platform = require(Shared.Platform);
local StateManager = require(ReplicatedStorage.Modules.Metadata.ControlData.StateManager);
local ClientRemote = ReplicatedStorage.Remotes.ClientRemote;
local GetMouse = ReplicatedStorage.Remotes.GetMouse;
local AnimationRemote = Remotes.AnimationRemote;
local StatRetrieveRemote = ReplicatedStorage.Remotes.StatRetrieveRemote;
local LocalPlayer = Players.LocalPlayer;
local workspace_Camera = workspace.Camera;
local workspace_World = workspace.World;
local Visuals = workspace_World.Visuals;
local Live = workspace_World.Live;
local FormStates = ControlData.FormStates;
local RaycastParams_new_ret = RaycastParams.new();
RaycastParams_new_ret.FilterType = Enum.RaycastFilterType.Exclude;
RaycastParams_new_ret.FilterDescendantsInstances = { Visuals, Live };
RaycastParams_new_ret.RespectCanCollide = true;
u1.TargetBlackList = { workspace_World.Visuals, workspace_World:FindFirstChild("Zones", true) };

function u1.IgnoreCheck(p2, p3) -- Line: 91
    if p3 then
        return not p3:IsDescendantOf(game.Workspace) and true or (p3:IsA("BasePart") and p3.Transparency >= 0.95 and true or false);
    end;

    return false;
end;

local u4 = {};

local function getActiveFormModule(p5) -- Line: 67
    -- upvalues: FormStates (copy), StateManager (copy)
    for i, v in pairs(FormStates) do
        if StateManager.IsInState(p5, i) then
            return v;
        end;
    end;

    return nil;
end;

for _, descendant in ipairs(script:GetDescendants()) do
    if descendant:IsA("ModuleScript") then
        u4[descendant.Name] = require(descendant);
    end;
end;

local u24 = {
    Play = function(p6, p7, p8) -- Line: 117
        -- upvalues: AnimationManager (copy)
        AnimationManager.PlayAnimation(p6, p7, p8);
    end,

    Stop = function(p9, p10, p11) -- Line: 120
        -- upvalues: AnimationManager (copy)
        AnimationManager.StopAnimation(p9, p10, p11);
    end,

    Adjust = function(p12, p13, p14) -- Line: 123
        -- upvalues: AnimationManager (copy)
        AnimationManager.AdjustAnimationSpeed(p12, p13, p14 and p14.AdjustSpeed or 1);
    end,

    StopAll = function(p15, p16, p17) -- Line: 130
        -- upvalues: AnimationManager (copy)
        AnimationManager.StopAllAnimations(p15);
    end,

    Reload = function(u18, u19, u20) -- Line: 135
        -- upvalues: AnimationManager (copy)
        if u19 == "Saiyan Tail Wag" or u19 == "Arcosian Tail Wag" then
            task.spawn(function() -- Line: 159
                -- upvalues: u18 (copy), AnimationManager (ref), u19 (copy), u20 (copy)
                local v21 = u18 and u18:FindFirstChild("Torso");

                if not v21 then
                    return;
                end;

                if not v21:FindFirstChild("Tail") then
                    v21:WaitForChild("Tail", 10);
                end;

                if not (u18.Parent and v21:FindFirstChild("Tail")) then
                    return;
                end;

                AnimationManager.ReloadAnimation(u18, u19, u20);
            end);

            return;
        end;

        AnimationManager.ReloadAnimation(u18, u19, u20);
    end,

    LoadAnimations = function(p22, p23) -- Line: 172
        -- upvalues: AnimationManager (copy)
        AnimationManager.LoadAnimations(p22, p23);
    end
};
local u25 = {
    Tail = true,
    Cellgame = true
};

local function tailWagName(p26) -- Line: 194
    if p26.Name == "Cellgame" then
        return "Bio Tail Wag";
    end;

    local Part1 = p26.Part1;

    return Part1 and Part1.Name == "MonkeyTail" and "Saiyan Tail Wag" or "Arcosian Tail Wag";
end;

LocalPlayer.CharacterAdded:Connect(function(u27) -- Line: 201, Name: hookTailKeeper
    -- upvalues: u25 (copy), AnimationManager (copy)
    task.spawn(function() -- Line: 202
        -- upvalues: u27 (copy), u25 (ref), AnimationManager (ref)
        local Torso = u27:WaitForChild("Torso", 10);

        if not Torso then
            return;
        end;

        Torso.ChildAdded:Connect(function(p28) -- Line: 205
            -- upvalues: u25 (ref), u27 (ref), AnimationManager (ref)
            if p28:IsA("Motor6D") and u25[p28.Name] then
                task.wait(0.2);

                if p28.Parent and u27.Parent then
                    local v29;

                    if p28.Name == "Cellgame" then
                        v29 = "Bio Tail Wag";
                    else
                        local Part1 = p28.Part1;
                        v29 = Part1 and Part1.Name == "MonkeyTail" and "Saiyan Tail Wag" or "Arcosian Tail Wag";
                    end;

                    AnimationManager.ReloadAnimation(u27, v29, {
                        Looped = true
                    });
                end;
            end;
        end);
    end);
end);

if LocalPlayer.Character then
    local Character = LocalPlayer.Character;
    task.spawn(function() -- Line: 202
        -- upvalues: Character (copy), u25 (copy), AnimationManager (copy)
        local Torso = Character:WaitForChild("Torso", 10);

        if not Torso then
            return;
        end;

        Torso.ChildAdded:Connect(function(p30) -- Line: 205
            -- upvalues: u25 (ref), Character (ref), AnimationManager (ref)
            if p30:IsA("Motor6D") and u25[p30.Name] then
                task.wait(0.2);

                if p30.Parent and Character.Parent then
                    local v31;

                    if p30.Name == "Cellgame" then
                        v31 = "Bio Tail Wag";
                    else
                        local Part1 = p30.Part1;
                        v31 = Part1 and Part1.Name == "MonkeyTail" and "Saiyan Tail Wag" or "Arcosian Tail Wag";
                    end;

                    AnimationManager.ReloadAnimation(Character, v31, {
                        Looped = true
                    });
                end;
            end;
        end);
    end);
end;

task.spawn(function() -- Line: 219
    -- upvalues: LocalPlayer (copy), u25 (copy), AnimationManager (copy)
    while true do
        task.wait(4);
        local Character = LocalPlayer.Character;
        local v32;

        if Character then
            v32 = Character:FindFirstChild("Torso");
        else
            v32 = Character;
        end;

        if v32 then
            for i in pairs(u25) do
                local v33 = v32:FindFirstChild(i);

                if v33 and (v33:IsA("Motor6D") and v33.Part1) then
                    local v34;

                    if v33.Name == "Cellgame" then
                        v34 = "Bio Tail Wag";
                    else
                        local Part1 = v33.Part1;
                        v34 = Part1 and Part1.Name == "MonkeyTail" and "Saiyan Tail Wag" or "Arcosian Tail Wag";
                    end;

                    AnimationManager.PlayAnimation(Character, v34, {
                        Looped = true,
                        SkipIfPlaying = true
                    });
                end;
            end;
        end;
    end;
end);
local u35 = {
    Block = true,
    Light = true
};
local u36 = {};
local u37 = {
    ButtonX = Enum.KeyCode.ButtonX,
    ButtonY = Enum.KeyCode.ButtonY,
    ButtonA = Enum.KeyCode.ButtonA,
    ButtonB = Enum.KeyCode.ButtonB,
    ButtonL1 = Enum.KeyCode.ButtonL1,
    ButtonR1 = Enum.KeyCode.ButtonR1,
    ButtonL2 = Enum.KeyCode.ButtonL2,
    ButtonR2 = Enum.KeyCode.ButtonR2,
    ButtonL3 = Enum.KeyCode.ButtonL3,
    ButtonR3 = Enum.KeyCode.ButtonR3,
    ButtonStart = Enum.KeyCode.ButtonStart,
    ButtonSelect = Enum.KeyCode.ButtonSelect,
    DPadUp = Enum.KeyCode.DPadUp,
    DPadDown = Enum.KeyCode.DPadDown,
    DPadLeft = Enum.KeyCode.DPadLeft,
    DPadRight = Enum.KeyCode.DPadRight,
    Thumbstick1 = Enum.KeyCode.Thumbstick1,
    Thumbstick2 = Enum.KeyCode.Thumbstick2
};
local u38 = {
    Charge = "DeCharge"
};

local function doubleTapTarget(p39) -- Line: 308
    -- upvalues: u38 (copy), ControlData (copy)
    for i, v in pairs(u38) do
        local v40 = ControlData.Controls.Combat[i];

        if type(v40) == "table" and v40[2] == p39 then
            local v41 = ControlData.Controls.Combat[v];

            return type(v41) == "table" and v41[1] or nil;
        end;
    end;

    return nil;
end;

local u42 = {};
LocalPlayer.CharacterRemoving:Connect(function(p43) -- Line: 322
    -- upvalues: StateManager (copy), AnimationManager (copy)
    StateManager.CleanupCharacter(p43);
    AnimationManager.CleanupCharacter(p43);
end);

local function getKeyEvaluation(p44) -- Line: 331
    -- upvalues: Platform (copy)
    if p44.UserInputType == Enum.UserInputType.Keyboard then
        return p44.KeyCode.Name;
    end;

    if p44.UserInputType == Enum.UserInputType.MouseButton1 then
        return "MouseButton1";
    end;

    if p44.UserInputType == Enum.UserInputType.MouseButton2 then
        return "MouseButton2";
    end;

    if Platform.IsGamepadInput(p44.UserInputType) then
        return p44.KeyCode.Name;
    end;

    return p44.UserInputType.Name;
end;

local function findActionForKey(p45, p46) -- Line: 348
    for i, v in pairs(p46) do
        if typeof(v) == "table" then
            local v47 = i;

            for _, v2 in ipairs(v) do
                if v2 == p45 then
                    return v47;
                end;
            end;
        elseif v == p45 then
            return i;
        end;
    end;

    return nil;
end;

local function isKeyHeld(p48) -- Line: 368
    -- upvalues: UserInputService (copy), u37 (copy), Platform (copy)
    if p48 == "MouseButton1" then
        return UserInputService:IsMouseButtonPressed(Enum.UserInputType.MouseButton1);
    end;

    if p48 == "MouseButton2" then
        return UserInputService:IsMouseButtonPressed(Enum.UserInputType.MouseButton2);
    end;

    local v49 = u37[p48];

    if v49 then
        return Platform.IsButtonDown(v49);
    end;

    local v50 = Enum.KeyCode[p48];
    local v51;

    if v50 == nil then
        v51 = false;
    else
        v51 = UserInputService:IsKeyDown(v50);
    end;

    return v51;
end;

local function isActionPressed(p52) -- Line: 382
    -- upvalues: isKeyHeld (copy)
    for _, v in ipairs(p52) do
        if isKeyHeld(v) then
            return true;
        end;
    end;

    return false;
end;

local function resolveRoute(p53, p54) -- Line: 404
    -- upvalues: getActiveFormModule (copy), findActionForKey (copy), ControlData (copy), StateManager (copy), ReplicatedStorage (copy)
    local v55 = getActiveFormModule(p53);
    local v56 = findActionForKey(p54, ControlData.Controls.Combat);
    local v57 = findActionForKey(p54, ControlData.Controls.CoreControls);
    local v58 = v55 and ControlData.Controls[v55] and findActionForKey(p54, ControlData.Controls[v55]);
    local v59 = StateManager.IsInState(p53, "Flying");
    local v60 = {
        ["Ki Sense"] = true
    };
    local v61;

    if v59 then
        v61 = not v60[v56];
    else
        v61 = v59;
    end;

    if v59 and (not v58 and table.find(ControlData.Controls.Flight.Move, p54)) then
        return p54, "FlyHandler", "Move", v56;
    end;

    if v59 and not (v58 or p54 ~= "ButtonL2" and p54 ~= "ButtonL3") then
        ReplicatedStorage.Remotes.TouchActionRemote:Fire("CoreControls", "Fast Fly", p54);

        return nil;
    end;

    local v62 = v58 or (v57 or v56);

    if v62 then
        return v62, v58 and v55 and v55 or (v61 and "FlyHandler" or (v57 and "CoreControls" or (v56 and "Core Combat" or v62))), v58 or (v61 and "Move" or (v57 or (v56 or v62))), v62;
    end;

    return nil;
end;

local function handleAction(p63, p64, p65, p66, p67) -- Line: 497
    -- upvalues: u35 (copy), getActiveFormModule (copy), ControlData (copy), isKeyHeld (copy), u36 (copy), StateManager (copy)
    if not p67 then
        return;
    end;

    if u35[p64] then
        local v68 = getActiveFormModule(p63);
        local v69 = v68 and ControlData.Controls[v68] and ControlData.Controls[v68][p64] or ControlData.Controls.Combat[p64];

        if not v69 then
            return;
        end;

        while true do
            local v70 = false;

            for _, v in ipairs(v69) do
                if isKeyHeld(v) then
                    v70 = true;
                    break;
                end;
            end;

            if not (v70 or u36[p64]) then
                break;
            end;

            if StateManager.CanPerformAction(p63, p64) then
                if p64 == "Block" then
                    if p63:FindFirstChildOfClass("Tool") then
                        break;
                    end;

                    if typeof(p67) == "table" then
                        p67.Execute(p65, p66);
                    else
                        p67(p65, p66);
                    end;

                    task.wait();
                else
                    local Block = ControlData.Controls.Combat.Block;

                    if Block then
                        local v71 = false;

                        for _, v in ipairs(Block) do
                            if isKeyHeld(v) then
                                v71 = true;
                                break;
                            end;
                        end;

                        if v71 then
                            task.wait();
                        else
                            if p63:FindFirstChildOfClass("Tool") then
                                break;
                            end;

                            if typeof(p67) == "table" then
                                p67.Execute(p65, p66);
                            else
                                p67(p65, p66);
                            end;

                            task.wait();
                        end;
                    else
                        if p63:FindFirstChildOfClass("Tool") then
                            break;
                        end;

                        if typeof(p67) == "table" then
                            p67.Execute(p65, p66);
                        else
                            p67(p65, p66);
                        end;

                        task.wait();
                    end;
                end;
            else
                task.wait();
            end;
        end;
    else
        if typeof(p67) == "table" then
            p67.Execute(p65, p66);

            return;
        end;

        p67(p65, p66);
    end;
end;

local function beginInput(p72) -- Line: 560
    -- upvalues: LocalPlayer (copy), doubleTapTarget (copy), u42 (copy), resolveRoute (copy), StateManager (copy), u4 (copy), handleAction (copy)
    local v73 = LocalPlayer.Character or LocalPlayer.CharacterAdded:Wait();
    local Humanoid = v73:FindFirstChild("Humanoid");

    if Humanoid and Humanoid.Health <= 0 then
        return;
    end;

    local v74 = doubleTapTarget(p72);

    if v74 then
        local os_clock_ret = os.clock();

        if os_clock_ret - (u42[p72] or 0) <= 0.3 then
            u42[p72] = 0;
        else
            u42[p72] = os_clock_ret;
            v74 = p72;
        end;
    else
        v74 = p72;
    end;

    local v75, v76, v77, v78 = resolveRoute(v73, v74);

    if not v75 then
        return;
    end;

    if not StateManager.CanPerformAction(v73, v75) and v75 ~= "Block" then
        return;
    end;

    handleAction(v73, v78, v75, v74, u4[v76] and u4[v76][v77] or nil);
end;

local function endInput(u79) -- Line: 603
    -- upvalues: LocalPlayer (copy), resolveRoute (copy), u4 (copy)
    local u80, u81, u82 = resolveRoute(LocalPlayer.Character or LocalPlayer.CharacterAdded:Wait(), u79);

    if not u80 then
        return;
    end;

    pcall(function() -- Line: 611
        -- upvalues: u4 (ref), u81 (copy), u82 (copy), u80 (copy), u79 (copy)
        local v83 = u4[u81] and u4[u81][u82];

        if typeof(v83) == "table" and v83.Terminate then
            v83.Terminate(u80, u79);
        end;
    end);
end;

Remotes:WaitForChild("TouchActionRemote").Event:Connect(function(p84, p85, p86, p87) -- Line: 644
    -- upvalues: u36 (copy), endInput (copy), beginInput (copy)
    if p84 ~= "SynthKey" then
        return;
    end;

    if type(p86) ~= "string" or p86 == "" then
        return;
    end;

    if p87 == "End" then
        u36[p85] = nil;
        endInput(p86);

        return;
    end;

    u36[p85] = true;
    beginInput(p86);
end);
local workspace_CurrentCamera = workspace.CurrentCamera;

local function metrics() -- Line: 704
    -- upvalues: workspace_CurrentCamera (copy)
    local v88 = workspace_CurrentCamera and workspace_CurrentCamera.ViewportSize or Vector2.new(800, 480);
    local v89 = math.min(v88.X, v88.Y) * 0.105;
    local math_floor_ret = math.floor(v89);
    local math_clamp_ret = math.clamp(math_floor_ret, 44, 62);
    local math_floor_ret2 = math.floor(math_clamp_ret * 0.18);

    return math_clamp_ret, math_clamp_ret + math.clamp(math_floor_ret2, 6, 14), v88;
end;

local v90 = workspace_CurrentCamera and workspace_CurrentCamera.ViewportSize or Vector2.new(800, 480);
local v91 = math.min(v90.X, v90.Y) * 0.105;
local math_floor_ret = math.floor(v91);
local math_clamp_ret = math.clamp(math_floor_ret, 44, 62);
local math_floor_ret2 = math.floor(math_clamp_ret * 0.18);
local u92 = math_clamp_ret;
local u93 = math_clamp_ret + math.clamp(math_floor_ret2, 6, 14);
local GuiService = game:GetService("GuiService");

local function jumpButtonTop() -- Line: 746
    -- upvalues: LocalPlayer (copy), workspace_CurrentCamera (copy)
    local v94 = LocalPlayer:FindFirstChild("PlayerGui") and LocalPlayer.PlayerGui:FindFirstChild("TouchGui");

    if v94 then
        v94 = v94:FindFirstChild("TouchControlFrame");
    end;

    if v94 then
        v94 = v94:FindFirstChild("JumpButton");
    end;

    if not (v94 and (v94.Visible and v94.AbsoluteSize.Y > 0)) then
        return nil;
    end;

    local v95 = workspace_CurrentCamera and workspace_CurrentCamera.ViewportSize;

    if v95 then
        return v95.Y - v94.AbsolutePosition.Y;
    end;

    return nil;
end;

local function computeMargins() -- Line: 758
    -- upvalues: GuiService (copy), jumpButtonTop (copy)
    local v96 = GuiService:GetGuiInset().Y + 74;
    local v97 = jumpButtonTop();

    return v96, (v97 and math.max(150, v97 + 12) or 150) + 26;
end;

local u98 = 0;

local function fitCluster(p99, p100, p101, u102, u103, u104) -- Line: 795
    -- upvalues: u98 (ref), jumpButtonTop (copy)
    local function topRowY(p105, p106, p107) -- Line: 796
        -- upvalues: u103 (copy), u102 (copy)
        return u103 - (p107 + p105 + (u102 - 1) * p106);
    end;

    local function clearY(p108) -- Line: 800
        -- upvalues: u104 (copy)
        return u104 + p108 + 8;
    end;

    u98 = 0;

    if u103 - (p101 + p99 + (u102 - 1) * p100) < u104 + p99 + 8 then
        p101 = math.max(p101 - 26, 0);
    end;

    local v109 = jumpButtonTop();

    while u103 - (p101 + p99 + (u102 - 1) * p100) < u104 + p99 + 8 and (v109 and v109 + 12 or 90) < p101 do
        p101 = p101 - 4;
    end;

    while u103 - (p101 + p99 + (u102 - 1) * p100) < u104 + p99 + 8 and p99 > 44 do
        p99 = math.max(p99 - 2, 44);
        local math_floor_ret3 = math.floor(p99 * 0.18);
        p100 = p99 + math.clamp(math_floor_ret3, 6, 14);
    end;

    if u103 - (p101 + p99 + (u102 - 1) * p100) < u104 + p99 + 8 then
        u98 = 6;
    end;

    return p99, p100, math.max(p101, 0);
end;

local v110 = GuiService:GetGuiInset().Y + 74;
local v111 = jumpButtonTop();
local v112 = v111 and math.max(150, v111 + 12) or 150;
local u113 = v110;
local u114 = v112 + 26;
local SettingsRemote = Remotes:WaitForChild("SettingsRemote");
local u115 = {};

local function layoutKey(p116, p117) -- Line: 863
    return p116 .. "/" .. p117;
end;

local u118 = nil;

local function safeRect(p119) -- Line: 882
    -- upvalues: u118 (ref)
    local AbsolutePosition = p119.AbsolutePosition;
    local AbsoluteSize = p119.AbsoluteSize;
    local Vector2_zero = Vector2.zero;

    if u118 and u118.Parent then
        local AbsolutePosition2 = u118.AbsolutePosition;
        local AbsoluteSize2 = u118.AbsoluteSize;

        if AbsoluteSize2.X > 0 and AbsoluteSize2.Y > 0 then
            Vector2_zero = Vector2.new(math.max(0, AbsolutePosition2.X - AbsolutePosition.X), (math.max(0, AbsolutePosition2.Y - AbsolutePosition.Y)));
            AbsoluteSize = Vector2.new(math.min(AbsoluteSize.X, AbsolutePosition2.X - AbsolutePosition.X + AbsoluteSize2.X), (math.min(AbsoluteSize.Y, AbsolutePosition2.Y - AbsolutePosition.Y + AbsoluteSize2.Y)));
        end;
    end;

    return Vector2_zero, AbsoluteSize;
end;

local function clampCentre(p120, p121, p122) -- Line: 896
    -- upvalues: safeRect (copy), u92 (ref)
    local v123, v124 = safeRect(p120);
    local v125 = u92 / 2 + 4;
    local v126 = v123.X + v125;
    local math_max_ret = math.max(v123.X + v125, v124.X - v125);
    local math_clamp_ret2 = math.clamp(p121, v126, math_max_ret);
    local v127 = v123.Y + v125;
    local math_max_ret2 = math.max(v123.Y + v125, v124.Y - v125);

    return math_clamp_ret2, math.clamp(p122, v127, math_max_ret2);
end;

local function shortSide(p128) -- Line: 903
    local math_min_ret = math.min(p128.X, p128.Y);

    return math.max(math_min_ret, 1);
end;

local function toEntry(p129, p130, p131) -- Line: 908
    local math_min_ret = math.min(p129.X, p129.Y);
    local math_max_ret = math.max(math_min_ret, 1);
    local v132 = p129.X / 2 < p130 and 1 or 0;
    local v133 = p129.Y / 2 < p131 and 1 or 0;
    local v134 = {
        AX = v132,
        AY = v133
    };

    if v132 == 1 then
        p130 = p129.X - p130 or p130;
    end;

    v134.DX = p130 / math_max_ret;

    if v133 == 1 then
        p131 = p129.Y - p131 or p131;
    end;

    v134.DY = p131 / math_max_ret;

    return v134;
end;

local function fromEntry(p135, p136) -- Line: 920
    if type(p136) ~= "table" then
        return nil;
    end;

    local math_min_ret = math.min(p135.X, p135.Y);
    local math_max_ret = math.max(math_min_ret, 1);
    local v137 = tonumber(p136.AX);
    local v138 = tonumber(p136.AY);
    local v139 = tonumber(p136.DX);
    local v140 = tonumber(p136.DY);

    if v137 and (v138 and (v139 and v140)) then
        return v137 == 1 and p135.X - v139 * math_max_ret or v139 * math_max_ret, v138 == 1 and p135.Y - v140 * math_max_ret or v140 * math_max_ret;
    end;

    local v141 = tonumber(p136.X);
    local v142 = tonumber(p136.Y);

    if v141 and v142 then
        return v141 * p135.X, v142 * p135.Y;
    end;

    return nil;
end;

local function customPos(p143, p144) -- Line: 934
    -- upvalues: fromEntry (copy), u115 (copy), clampCentre (copy)
    local AbsoluteSize = p143.AbsoluteSize;

    if AbsoluteSize.X < 1 or AbsoluteSize.Y < 1 then
        return nil;
    end;

    local v145, v146 = fromEntry(AbsoluteSize, u115[p143.Name .. "/" .. p144]);

    if v145 then
        return UDim2.fromOffset(clampCentre(p143, v145, v146));
    end;

    return nil;
end;

local function sendEntry(p147, p148, p149) -- Line: 942
    -- upvalues: SettingsRemote (copy)
    SettingsRemote:FireServer({
        Action = "MobileLayout",
        Page = p147,
        ButtonAction = p148,
        AX = p149.AX,
        AY = p149.AY,
        DX = p149.DX,
        DY = p149.DY
    });
end;

local u150 = {};

local function saveButtonPos(p151, p152, p153, p154) -- Line: 952
    -- upvalues: toEntry (copy), u115 (copy), u150 (copy), SettingsRemote (copy)
    local v155 = p151.Name .. "/" .. p152;
    local v156 = toEntry(p151.AbsoluteSize, p153, p154);
    u115[v155] = v156;
    u150[v155] = true;
    SettingsRemote:FireServer({
        Action = "MobileLayout",
        Page = p151.Name,
        ButtonAction = p152,
        AX = v156.AX,
        AY = v156.AY,
        DX = v156.DX,
        DY = v156.DY
    });
end;

local function applyFit() -- Line: 960
    -- upvalues: workspace_CurrentCamera (copy), u92 (ref), u93 (ref), u114 (ref), fitCluster (copy), u113 (ref)
    local v157 = workspace_CurrentCamera and workspace_CurrentCamera.ViewportSize or Vector2.new(800, 480);
    local v158 = math.min(v157.X, v157.Y) * 0.105;
    local math_floor_ret3 = math.floor(v158);
    local math_clamp_ret2 = math.clamp(math_floor_ret3, 44, 62);
    local math_floor_ret4 = math.floor(math_clamp_ret2 * 0.18);
    local _ = math_clamp_ret2 + math.clamp(math_floor_ret4, 6, 14);
    local v159, v160, v161 = fitCluster(u92, u93, u114, 4, v157 and v157.Y or 480, u113);
    u92 = v159;
    u93 = v160;
    u114 = v161;
end;

local v162 = workspace_CurrentCamera and workspace_CurrentCamera.ViewportSize or Vector2.new(800, 480);
local v163 = math.min(v162.X, v162.Y) * 0.105;
local math_floor_ret3 = math.floor(v163);
local math_clamp_ret2 = math.clamp(math_floor_ret3, 44, 62);
local math_floor_ret4 = math.floor(math_clamp_ret2 * 0.18);
local _ = math_clamp_ret2 + math.clamp(math_floor_ret4, 6, 14);
local v164, v165, v166 = fitCluster(u92, u93, u114, 4, v162 and v162.Y or 480, u113);
u92 = v164;
u93 = v165;
u114 = v166;

local function slotPos(p167) -- Line: 970
    -- upvalues: u92 (ref), u93 (ref), u114 (ref)
    local v168 = p167 - 1;
    local math_floor_ret5 = math.floor(v168 / 4);

    return UDim2.new(1, -(14 + u92 + v168 % 4 * u93), 1, -(u114 + u92 + math_floor_ret5 * u93));
end;

local function topSlotPos(p169) -- Line: 982
    -- upvalues: u98 (ref), u92 (ref), u93 (ref), u113 (ref)
    return UDim2.new(1, -(14 + u92 + (p169 - 1 + u98) * u93), 0, u113);
end;

local function gridCentre(p170, p171) -- Line: 995
    -- upvalues: u92 (ref), u93 (ref), u114 (ref)
    return UDim2.new(1, -(14 + u92 + p170 * u93) + u92 / 2, 1, -(u114 + u92 + p171 * u93) + u92 / 2);
end;

local function slotCentre(p172, p173) -- Line: 1001
    -- upvalues: u98 (ref), u92 (ref), u93 (ref), u113 (ref), u114 (ref)
    local v174 = p173 and UDim2.new(1, -(14 + u92 + (p172 - 1 + u98) * u93), 0, u113);

    if not v174 then
        local v175 = p172 - 1;
        local math_floor_ret5 = math.floor(v175 / 4);
        v174 = UDim2.new(1, -(14 + u92 + v175 % 4 * u93), 1, -(u114 + u92 + math_floor_ret5 * u93));
    end;

    return UDim2.new(v174.X.Scale, v174.X.Offset + u92 / 2, v174.Y.Scale, v174.Y.Offset + u92 / 2);
end;

local TouchActionRemote = Remotes:WaitForChild("TouchActionRemote");
local u176 = {
    UI = true,
    Menu_UI = true
};

local function isBridged(p177) -- Line: 1032
    -- upvalues: u176 (copy)
    return p177.bridge == true and true or u176[p177.group] == true;
end;

local Color3_fromRGB_ret = Color3.fromRGB(12, 11, 10);
local Color3_fromRGB_ret2 = Color3.fromRGB(255, 196, 68);
local u178 = { {
        action = "Light",
        group = "Combat",
        label = "M1",
        slot = 1
    }, {
        action = "Heavy",
        group = "Combat",
        label = "M2",
        slot = 2
    }, {
        action = "Follow Up",
        group = "Combat",
        label = "Z",
        slot = 3
    }, {
        action = "Block",
        group = "Combat",
        label = "BLK",
        slot = 4
    }, {
        action = "Evade",
        group = "Combat",
        label = "EVD",
        slot = 5
    }, {
        action = "Dash",
        group = "Combat",
        label = "DASH",
        slot = 6
    }, {
        action = "Ki Blast",
        group = "Combat",
        label = "KI",
        slot = 7
    }, {
        action = "Charge",
        group = "Combat",
        label = "CHG",
        slot = 8
    }, {
        action = "Lock On",
        group = "CoreControls",
        label = "TRGT",
        slot = 9,
        bridge = true
    }, {
        action = "Flight/Climb",
        group = "CoreControls",
        label = "FLY",
        slot = 10
    }, {
        action = "Run",
        group = "Combat",
        label = "RUN",
        slot = 11,
        toggle = true
    }, {
        action = "Dive",
        group = "CoreControls",
        label = "DWN",
        slot = 12
    } };
local u179 = {
    {
        action = "Transform",
        group = "Combat",
        label = "FORM",
        slot = 1
    },
    {
        action = "DeTransform",
        group = "Combat",
        label = "REVT",
        slot = 2
    },
    {
        action = "DeCharge",
        group = "Combat",
        label = "DCHG",
        slot = 3
    },
    {
        action = "Grip",
        group = "Combat",
        label = "GRIP",
        slot = 4
    },
    {
        action = "Carry",
        group = "Combat",
        label = "CARY",
        slot = 5
    },
    {
        action = "Loot",
        group = "Combat",
        label = "ROB",
        slot = 6
    },
    {
        action = "Ki Sense",
        group = "Combat",
        label = "SENS",
        slot = 7
    },
    {
        action = "Fast Fly",
        group = "CoreControls",
        label = "FAST",
        slot = 8,
        bridge = true
    },
    {
        action = "Meditate",
        group = "CoreControls",
        label = "MED",
        slot = 9
    },
    {
        action = "Skill Tree",
        group = "UI",
        label = "SKLS",
        slot = 10
    },
    {
        action = "Transformations",
        group = "UI",
        label = "FRMS",
        slot = 11
    },
    {
        action = "Emotes",
        group = "CoreControls",
        label = "EMOT",
        slot = 12
    },
    {
        action = "Cinematic Mode",
        group = "CoreControls",
        label = "CINE",
        slot = 13
    },
    {
        action = "Zone Map",
        group = "Overlay",
        label = "ZONE",
        slot = 14,
        bridge = true,
        holdBridge = true
    },
    {
        action = "Shift Lock",
        group = "CoreControls",
        label = "LOCK",
        slot = 15,
        bridge = true
    }
};
local u180 = { {
        action = "Menu",
        group = "Menu_UI",
        label = "MENU",
        slot = 1
    }, {
        action = "Inventory",
        group = "CoreControls",
        label = "BAG",
        slot = 2,
        bridge = true
    } };

local function primaryKey(p181, p182) -- Line: 1128
    -- upvalues: ControlData (copy)
    local v183 = ControlData.Controls and ControlData.Controls[p181];

    if v183 then
        v183 = v183[p182];
    end;

    if typeof(v183) == "table" then
        return v183[1];
    end;

    return v183;
end;

local u184 = {};

local function pressEntry(p185, p186) -- Line: 1137
    -- upvalues: u176 (copy), TouchActionRemote (copy), u184 (copy), LocalPlayer (copy), StateManager (copy), u36 (copy), endInput (copy), beginInput (copy)
    if p185.bridge == true and true or u176[p185.group] == true then
        TouchActionRemote:Fire(p185.group, p185.action, p186);

        return;
    end;

    if not p185.toggle then
        u36[p185.action] = true;
        beginInput(p186);

        if p185.doubleTap then
            beginInput(p186);
        end;

        return;
    end;

    local v187 = u184[p185.action];

    if p185.action == "Run" then
        local Character = LocalPlayer.Character;

        if Character == nil then
            v187 = false;
        else
            v187 = StateManager.IsInState(Character, "Running");
        end;
    end;

    if v187 then
        u184[p185.action] = nil;
        u36[p185.action] = nil;
        endInput(p186);

        return;
    end;

    u184[p185.action] = true;
    u36[p185.action] = true;
    beginInput(p186);
    beginInput(p186);
end;

local function releaseEntry(p188, p189) -- Line: 1176
    -- upvalues: u176 (copy), TouchActionRemote (copy), u36 (copy), endInput (copy)
    if p188.bridge == true and true or u176[p188.group] == true then
        if p188.holdBridge then
            TouchActionRemote:Fire(p188.group, p188.action, p189, "End");
        end;

        return;
    end;

    if p188.toggle then
        return;
    end;

    if not u36[p188.action] then
        return;
    end;

    u36[p188.action] = nil;
    endInput(p189);
end;

local u190 = false;
local u191 = {};
local u192 = {};

local function setEditMode(p193) -- Line: 1197
    -- upvalues: u190 (ref), u191 (copy)
    u190 = p193 and true or false;

    for _, v in ipairs(u191) do
        local success, result = pcall(v, u190);

        if not success then
            warn("[MobileControls] edit-mode watcher failed: " .. tostring(result));
        end;
    end;
end;

local function buildButton(u194, u195, p196) -- Line: 1205
    -- upvalues: ControlData (copy), u176 (copy), u92 (ref), customPos (copy), u93 (ref), u114 (ref), u98 (ref), u113 (ref), Color3_fromRGB_ret (copy), Color3_fromRGB_ret2 (copy), LocalPlayer (copy), u190 (ref), pressEntry (copy), u184 (copy), TouchActionRemote (copy), u36 (copy), endInput (copy), clampCentre (copy), u192 (copy), UserInputService (copy), safeRect (copy), toEntry (copy), u115 (copy), u150 (copy), SettingsRemote (copy), u191 (copy)
    local action = u195.action;
    local u197 = ControlData.Controls and ControlData.Controls[u195.group];

    if u197 then
        u197 = u197[action];
    end;

    if typeof(u197) == "table" then
        u197 = u197[1];
    end;

    if not (u197 or (u195.bridge == true or u176[u195.group] == true)) then
        warn(("[MobileControls] no ControlData key for %s.%s -- button skipped"):format(u195.group, u195.action));

        return nil;
    end;

    local _ = u194.Name;
    local TextButton = Instance.new("TextButton");
    TextButton.Name = u195.action;
    TextButton.Size = UDim2.fromOffset(u92, u92);
    TextButton.AnchorPoint = Vector2.new(0.5, 0.5);
    local v198 = customPos(u194, u195.action) or u195.col and UDim2.new(1, -(14 + u92 + u195.col * u93) + u92 / 2, 1, -(u114 + u92 + (u195.row or 0) * u93) + u92 / 2);

    if not v198 then
        local slot = u195.slot;
        local v199 = p196 and UDim2.new(1, -(14 + u92 + (slot - 1 + u98) * u93), 0, u113);

        if not v199 then
            local v200 = slot - 1;
            local math_floor_ret5 = math.floor(v200 / 4);
            v199 = UDim2.new(1, -(14 + u92 + v200 % 4 * u93), 1, -(u114 + u92 + math_floor_ret5 * u93));
        end;

        v198 = UDim2.new(v199.X.Scale, v199.X.Offset + u92 / 2, v199.Y.Scale, v199.Y.Offset + u92 / 2);
    end;

    TextButton.Position = v198;
    TextButton.BackgroundColor3 = Color3_fromRGB_ret;
    TextButton.BackgroundTransparency = 0.2;
    TextButton.BorderSizePixel = 0;
    TextButton.Text = u195.label;
    TextButton.TextColor3 = Color3_fromRGB_ret2;
    TextButton.Font = Enum.Font.GothamBold;
    local math_floor_ret5 = math.floor(u92 * 0.24);
    TextButton.TextSize = math.clamp(math_floor_ret5, 10, 15);
    TextButton.AutoButtonColor = true;
    TextButton.Parent = u194;
    local UICorner = Instance.new("UICorner");
    UICorner.CornerRadius = UDim.new(0, 8);
    UICorner.Parent = TextButton;
    local UIStroke = Instance.new("UIStroke");
    UIStroke.Color = Color3_fromRGB_ret2;
    UIStroke.Thickness = 1;
    UIStroke.Transparency = 0.45;
    UIStroke.Parent = TextButton;

    if u195.action == "Lock On" then
        task.spawn(function() -- Line: 1250
            -- upvalues: LocalPlayer (ref), u190 (ref), TextButton (copy), Color3_fromRGB_ret2 (ref), Color3_fromRGB_ret (ref)
            local LockOnTarget = LocalPlayer:WaitForChild("LockOnTarget", 30);

            if not LockOnTarget then
                return;
            end;

            LockOnTarget.Changed:Connect(function() -- Line: 1253, Name: paint
                -- upvalues: u190 (ref), LockOnTarget (copy), TextButton (ref), Color3_fromRGB_ret2 (ref), Color3_fromRGB_ret (ref)
                if u190 then
                    return;
                end;

                local v201 = LockOnTarget.Value ~= nil;
                TextButton.BackgroundColor3 = v201 and Color3_fromRGB_ret2 or Color3_fromRGB_ret;
                TextButton.TextColor3 = v201 and Color3_fromRGB_ret or Color3_fromRGB_ret2;
            end);

            if u190 then
                return;
            end;

            local v202 = LockOnTarget.Value ~= nil;
            TextButton.BackgroundColor3 = v202 and Color3_fromRGB_ret2 or Color3_fromRGB_ret;
            TextButton.TextColor3 = v202 and Color3_fromRGB_ret or Color3_fromRGB_ret2;
        end);
    end;

    TextButton.MouseButton1Down:Connect(function() -- Line: 1264
        -- upvalues: u190 (ref), pressEntry (ref), u195 (copy), ControlData (ref), u197 (copy), u184 (ref), TextButton (copy), Color3_fromRGB_ret2 (ref), Color3_fromRGB_ret (ref)
        if u190 then
            return;
        end;

        local action2 = u195.action;
        local v203 = ControlData.Controls and ControlData.Controls[u195.group];

        if v203 then
            v203 = v203[action2];
        end;

        if typeof(v203) == "table" then
            v203 = v203[1];
        end;

        pressEntry(u195, v203 or u197);

        if u195.toggle then
            local v204 = u184[u195.action] == true;
            TextButton.BackgroundColor3 = v204 and Color3_fromRGB_ret2 or Color3_fromRGB_ret;
            TextButton.TextColor3 = v204 and Color3_fromRGB_ret or Color3_fromRGB_ret2;
        end;
    end);
    TextButton.MouseButton1Up:Connect(function() -- Line: 1278
        -- upvalues: u190 (ref), u195 (copy), ControlData (ref), u197 (copy), u176 (ref), TouchActionRemote (ref), u36 (ref), endInput (ref)
        if u190 then
            return;
        end;

        local v205 = u195;
        local action2 = u195.action;
        local v206 = ControlData.Controls and ControlData.Controls[u195.group];

        if v206 then
            v206 = v206[action2];
        end;

        if typeof(v206) == "table" then
            v206 = v206[1];
        end;

        local v207 = v206 or u197;

        if v205.bridge == true and true or u176[v205.group] == true then
            if v205.holdBridge then
                TouchActionRemote:Fire(v205.group, v205.action, v207, "End");
            end;
        else
            if v205.toggle then
                return;
            end;

            if not u36[v205.action] then
                return;
            end;

            u36[v205.action] = nil;
            endInput(v207);
        end;
    end);
    TextButton.MouseLeave:Connect(function() -- Line: 1284
        -- upvalues: u190 (ref), u195 (copy), ControlData (ref), u197 (copy), u176 (ref), TouchActionRemote (ref), u36 (ref), endInput (ref)
        if u190 then
            return;
        end;

        local v208 = u195;
        local action2 = u195.action;
        local v209 = ControlData.Controls and ControlData.Controls[u195.group];

        if v209 then
            v209 = v209[action2];
        end;

        if typeof(v209) == "table" then
            v209 = v209[1];
        end;

        local v210 = v209 or u197;

        if v208.bridge == true and true or u176[v208.group] == true then
            if v208.holdBridge then
                TouchActionRemote:Fire(v208.group, v208.action, v210, "End");
            end;
        else
            if v208.toggle then
                return;
            end;

            if not u36[v208.action] then
                return;
            end;

            u36[v208.action] = nil;
            endInput(v210);
        end;
    end);
    local u211 = nil;
    local u212 = nil;
    local u213 = nil;
    local u214 = nil;
    local u215 = nil;

    local function localCentre(p216) -- Line: 1302
        -- upvalues: u194 (copy), clampCentre (ref)
        local AbsolutePosition = u194.AbsolutePosition;

        return clampCentre(u194, p216.X - AbsolutePosition.X, p216.Y - AbsolutePosition.Y);
    end;

    local function stopDrag() -- Line: 1307
        -- upvalues: u214 (ref), u215 (ref), u211 (ref), u212 (ref), u213 (ref)
        if u214 then
            u214:Disconnect();
            u214 = nil;
        end;

        if u215 then
            u215:Disconnect();
            u215 = nil;
        end;

        u211 = nil;
        u212 = nil;
        u213 = nil;
    end;

    table.insert(u192, function() -- Line: 1315
        -- upvalues: u211 (ref), u214 (ref), u215 (ref), u212 (ref), u213 (ref)
        if u211 then
            if u214 then
                u214:Disconnect();
                u214 = nil;
            end;

            if u215 then
                u215:Disconnect();
                u215 = nil;
            end;

            u211 = nil;
            u212 = nil;
            u213 = nil;
        end;
    end);
    TextButton.InputBegan:Connect(function(p217) -- Line: 1319
        -- upvalues: u190 (ref), u211 (ref), u212 (ref), u213 (ref), TextButton (copy), u214 (ref), UserInputService (ref), localCentre (copy), u215 (ref), u194 (copy), u195 (copy), safeRect (ref), u92 (ref), toEntry (ref), u115 (ref), u150 (ref), SettingsRemote (ref)
        if not u190 then
            return;
        end;

        if p217.UserInputType ~= Enum.UserInputType.Touch and p217.UserInputType ~= Enum.UserInputType.MouseButton1 then
            return;
        end;

        if u211 then
            return;
        end;

        u211 = p217;
        u212 = p217.Position;
        u213 = TextButton.AbsolutePosition + TextButton.AbsoluteSize / 2;
        u214 = UserInputService.InputChanged:Connect(function(p218) -- Line: 1330
            -- upvalues: u211 (ref), u212 (ref), u213 (ref), TextButton (ref), localCentre (ref)
            local v219;

            if u211.UserInputType == Enum.UserInputType.MouseButton1 then
                v219 = p218.UserInputType == Enum.UserInputType.MouseMovement;
            else
                v219 = false;
            end;

            if not (p218 == u211 or v219) then
                return;
            end;

            local v220 = p218.Position - u212;
            local v221 = u213 + Vector2.new(v220.X, v220.Y);
            TextButton.Position = UDim2.fromOffset(localCentre(v221));
        end);
        u215 = UserInputService.InputEnded:Connect(function(p222) -- Line: 1343
            -- upvalues: u211 (ref), u194 (ref), u195 (ref), TextButton (ref), safeRect (ref), u92 (ref), toEntry (ref), u115 (ref), u150 (ref), SettingsRemote (ref), u214 (ref), u215 (ref), u212 (ref), u213 (ref)
            if p222 ~= u211 then
                return;
            end;

            local v223 = u194;
            local action2 = u195.action;
            local v224 = TextButton.AbsolutePosition + TextButton.AbsoluteSize / 2;
            local AbsolutePosition = u194.AbsolutePosition;
            local v225 = v224.X - AbsolutePosition.X;
            local v226 = v224.Y - AbsolutePosition.Y;
            local v227, v228 = safeRect(u194);
            local v229 = u92 / 2 + 4;
            local v230 = v227.X + v229;
            local math_max_ret = math.max(v227.X + v229, v228.X - v229);
            local math_clamp_ret3 = math.clamp(v225, v230, math_max_ret);
            local v231 = v227.Y + v229;
            local math_max_ret2 = math.max(v227.Y + v229, v228.Y - v229);
            local math_clamp_ret4 = math.clamp(v226, v231, math_max_ret2);
            local v232 = v223.Name .. "/" .. action2;
            local v233 = toEntry(v223.AbsoluteSize, math_clamp_ret3, math_clamp_ret4);
            u115[v232] = v233;
            u150[v232] = true;
            SettingsRemote:FireServer({
                Action = "MobileLayout",
                Page = v223.Name,
                ButtonAction = action2,
                AX = v233.AX,
                AY = v233.AY,
                DX = v233.DX,
                DY = v233.DY
            });

            if u214 then
                u214:Disconnect();
                u214 = nil;
            end;

            if u215 then
                u215:Disconnect();
                u215 = nil;
            end;

            u211 = nil;
            u212 = nil;
            u213 = nil;
        end);
    end);
    table.insert(u191, function(p234) -- Line: 1353
        -- upvalues: TextButton (copy), UIStroke (copy), Color3_fromRGB_ret2 (ref)
        if not TextButton.Parent then
            return;
        end;

        UIStroke.Color = p234 and Color3.fromRGB(120, 220, 255) or Color3_fromRGB_ret2;
        UIStroke.Transparency = p234 and 0 or 0.45;
    end);

    return TextButton;
end;

if Platform.IsTouch() then
    local u235 = nil;
    local u236 = false;
    local u237 = false;
    task.spawn(function() -- Line: 1373
        -- upvalues: StatRetrieveRemote (copy), u150 (copy), u115 (copy), u236 (ref), u235 (ref)
        local success, result = pcall(function() -- Line: 1374
            -- upvalues: StatRetrieveRemote (ref)
            return StatRetrieveRemote:InvokeServer("MobileLayout", "TableStat");
        end);

        if success and type(result) == "table" then
            for i, v in pairs(result) do
                if type(i) == "string" and (type(v) == "table" and not u150[i]) then
                    u115[i] = {
                        AX = tonumber(v.AX),
                        AY = tonumber(v.AY),
                        DX = tonumber(v.DX),
                        DY = tonumber(v.DY),
                        X = tonumber(v.X),
                        Y = tonumber(v.Y)
                    };
                end;
            end;
        end;

        u236 = true;

        if u235 then
            u235();
        end;
    end);
    local ScreenGui = Instance.new("ScreenGui");
    ScreenGui.Name = "MobileControls";
    ScreenGui.ResetOnSpawn = false;
    ScreenGui.IgnoreGuiInset = true;
    ScreenGui.DisplayOrder = 20;
    ScreenGui.Parent = LocalPlayer:WaitForChild("PlayerGui");
    local ScreenGui2 = Instance.new("ScreenGui");
    ScreenGui2.Name = "MobileSafeArea";
    ScreenGui2.ResetOnSpawn = false;
    ScreenGui2.IgnoreGuiInset = true;
    ScreenGui2.ScreenInsets = Enum.ScreenInsets.DeviceSafeInsets;
    ScreenGui2.Parent = LocalPlayer.PlayerGui;
    u118 = Instance.new("Frame");
    u118.Size = UDim2.fromScale(1, 1);
    u118.BackgroundTransparency = 1;
    u118.Active = false;
    u118.Parent = ScreenGui2;
    local u238 = 0;
    TouchActionRemote.Event:Connect(function(p239, p240, p241) -- Line: 1425
        -- upvalues: u238 (ref), ScreenGui (copy)
        if p239 ~= "TouchPad" or p240 ~= "EventFocus" then
            return;
        end;

        u238 = math.max(0, u238 + (p241 == true and 1 or -1));
        ScreenGui.Enabled = u238 == 0;
    end);
    local Frame = Instance.new("Frame");
    Frame.Name = "Main";
    Frame.Size = UDim2.fromScale(1, 1);
    Frame.BackgroundTransparency = 1;
    Frame.Parent = ScreenGui;
    local Frame2 = Instance.new("Frame");
    Frame2.Name = "More";
    Frame2.Size = UDim2.fromScale(1, 1);
    Frame2.BackgroundTransparency = 1;
    Frame2.Visible = false;
    Frame2.Parent = ScreenGui;

    for _, v in ipairs(u178) do
        buildButton(Frame, v);
    end;

    for _, v in ipairs(u179) do
        buildButton(Frame2, v);
    end;

    local ScreenGui3 = Instance.new("ScreenGui");
    ScreenGui3.Name = "TouchCrosshair";
    ScreenGui3.ResetOnSpawn = false;
    ScreenGui3.IgnoreGuiInset = true;
    ScreenGui3.DisplayOrder = 15;
    ScreenGui3.Enabled = LocalPlayer:GetAttribute("ShiftlockEnabled") == true;
    LocalPlayer:GetAttributeChangedSignal("ShiftlockEnabled"):Connect(function() -- Line: 1462
        -- upvalues: ScreenGui3 (copy), LocalPlayer (copy)
        ScreenGui3.Enabled = LocalPlayer:GetAttribute("ShiftlockEnabled") == true;
    end);
    ScreenGui3.Parent = LocalPlayer:WaitForChild("PlayerGui");
    local Frame3 = Instance.new("Frame");
    Frame3.Name = "Ring";
    Frame3.AnchorPoint = Vector2.new(0.5, 0.5);
    Frame3.Position = UDim2.fromScale(0.5, 0.5);
    Frame3.Size = UDim2.fromOffset(14, 14);
    Frame3.BackgroundTransparency = 1;
    Frame3.Parent = ScreenGui3;
    local UICorner = Instance.new("UICorner");
    UICorner.CornerRadius = UDim.new(1, 0);
    UICorner.Parent = Frame3;
    local UIStroke = Instance.new("UIStroke");
    UIStroke.Color = Color3_fromRGB_ret2;
    UIStroke.Thickness = 1.5;
    UIStroke.Transparency = 0.25;
    UIStroke.Parent = Frame3;
    local Frame4 = Instance.new("Frame");
    Frame4.Name = "Dot";
    Frame4.AnchorPoint = Vector2.new(0.5, 0.5);
    Frame4.Position = UDim2.fromScale(0.5, 0.5);
    Frame4.Size = UDim2.fromOffset(3, 3);
    Frame4.BackgroundColor3 = Color3_fromRGB_ret2;
    Frame4.BackgroundTransparency = 0.1;
    Frame4.BorderSizePixel = 0;
    Frame4.Parent = ScreenGui3;
    local UICorner2 = Instance.new("UICorner");
    UICorner2.CornerRadius = UDim.new(1, 0);
    UICorner2.Parent = Frame4;
    local Frame5 = Instance.new("Frame");
    Frame5.Name = "Menus";
    Frame5.Size = UDim2.fromScale(1, 1);
    Frame5.BackgroundTransparency = 1;
    Frame5.Parent = ScreenGui;

    for _, v in ipairs(u180) do
        buildButton(Frame5, v, true);
    end;

    local TextButton = Instance.new("TextButton");
    TextButton.Name = "MobileMore";
    TextButton.Size = UDim2.fromOffset(u92, u92);
    TextButton.Position = UDim2.new(1, -(14 + u92 + 4 * u93), 1, -(u114 + u92));
    TextButton.BackgroundColor3 = Color3_fromRGB_ret2;
    TextButton.BorderSizePixel = 0;
    TextButton.Text = "MORE";
    TextButton.TextColor3 = Color3_fromRGB_ret;
    TextButton.Font = Enum.Font.GothamBold;
    local math_floor_ret5 = math.floor(u92 * 0.24);
    TextButton.TextSize = math.clamp(math_floor_ret5, 10, 15);
    TextButton.Parent = ScreenGui;
    local UICorner3 = Instance.new("UICorner");
    UICorner3.CornerRadius = UDim.new(0, 8);
    UICorner3.Parent = TextButton;
    TextButton.MouseButton1Click:Connect(function() -- Line: 1515
        -- upvalues: Frame2 (copy), Frame (copy), TextButton (copy)
        local v242 = not Frame2.Visible;
        Frame2.Visible = v242;
        Frame.Visible = not v242;
        TextButton.Text = v242 and "BACK" or "MORE";
    end);
    local TextButton2 = Instance.new("TextButton");
    TextButton2.Name = "MobileEdit";
    TextButton2.Size = UDim2.fromOffset(u92, (math.floor(u92 * 0.6)));
    TextButton2.AnchorPoint = Vector2.new(0.5, 0.5);
    TextButton2.BackgroundColor3 = Color3_fromRGB_ret;
    TextButton2.BackgroundTransparency = 0.2;
    TextButton2.BorderSizePixel = 0;
    TextButton2.Text = "EDIT";
    TextButton2.TextColor3 = Color3_fromRGB_ret2;
    TextButton2.Font = Enum.Font.GothamBold;
    local math_floor_ret6 = math.floor(u92 * 0.2);
    TextButton2.TextSize = math.clamp(math_floor_ret6, 9, 13);
    TextButton2.Parent = ScreenGui;
    local UICorner4 = Instance.new("UICorner");
    UICorner4.CornerRadius = UDim.new(0, 6);
    UICorner4.Parent = TextButton2;
    local UIStroke2 = Instance.new("UIStroke");
    UIStroke2.Color = Color3_fromRGB_ret2;
    UIStroke2.Thickness = 1;
    UIStroke2.Transparency = 0.45;
    UIStroke2.Parent = TextButton2;
    local u243 = TextButton2:Clone();
    u243.Name = "MobileReset";
    u243.Text = "RESET";
    u243.Visible = false;
    u243.Parent = ScreenGui;

    local function positionEditButtons() -- Line: 1554
        -- upvalues: u92 (ref), u93 (ref), workspace_CurrentCamera (copy), u114 (ref), TextButton2 (copy), u243 (copy)
        local v244 = 1 - (14 + u92 + 4 * u93 + u92 / 2) / math.max(workspace_CurrentCamera and workspace_CurrentCamera.ViewportSize.X or 800, 1);
        local v245 = 1 - (u114 + u92 + math.floor(u92 * 0.6)) / math.max(workspace_CurrentCamera and workspace_CurrentCamera.ViewportSize.Y or 480, 1);
        TextButton2.Position = UDim2.fromScale(v244, v245);
        u243.Position = UDim2.fromScale(v244, v245 - u92 * 0.7 / math.max(workspace_CurrentCamera and workspace_CurrentCamera.ViewportSize.Y or 480, 1));
    end;

    positionEditButtons();
    TextButton2.MouseButton1Click:Connect(function() -- Line: 1565
        -- upvalues: setEditMode (copy), u190 (ref), TextButton2 (copy), Color3_fromRGB_ret2 (copy), Color3_fromRGB_ret (copy), u243 (copy), Frame2 (copy), Frame (copy), TextButton (copy)
        setEditMode(not u190);
        TextButton2.Text = u190 and "DONE" or "EDIT";
        TextButton2.BackgroundColor3 = u190 and Color3_fromRGB_ret2 or Color3_fromRGB_ret;
        TextButton2.TextColor3 = u190 and Color3_fromRGB_ret or Color3_fromRGB_ret2;
        u243.Visible = u190;

        if u190 then
            Frame2.Visible = true;
            Frame.Visible = true;

            return;
        end;

        Frame2.Visible = TextButton.Text == "BACK";
        Frame.Visible = not Frame2.Visible;
    end);
    u243.MouseButton1Click:Connect(function() -- Line: 1582
        -- upvalues: u115 (copy), SettingsRemote (copy), u235 (ref)
        table.clear(u115);
        SettingsRemote:FireServer({
            Action = "ResetMobileLayout"
        });

        if u235 then
            u235();
        end;
    end);
    LocalPlayer.CharacterRemoving:Connect(function() -- Line: 1588
        -- upvalues: u36 (copy), u184 (copy)
        table.clear(u36);
        table.clear(u184);
    end);

    local function safeDefault(p246, p247) -- Line: 1595
        -- upvalues: safeRect (copy), u92 (ref)
        local AbsoluteSize = p246.AbsoluteSize;

        if AbsoluteSize.X < 1 or AbsoluteSize.Y < 1 then
            return p247;
        end;

        local v248 = p247.X.Scale * AbsoluteSize.X + p247.X.Offset;
        local v249 = p247.Y.Scale * AbsoluteSize.Y + p247.Y.Offset;
        local v250, v251 = safeRect(p246);
        local v252 = u92 / 2 + 4;
        local v253 = v250.X + v252;
        local math_max_ret = math.max(v250.X + v252, v251.X - v252);
        local math_clamp_ret3 = math.clamp(v248, v253, math_max_ret);
        local v254 = v250.Y + v252;
        local math_max_ret2 = math.max(v250.Y + v252, v251.Y - v252);
        local math_clamp_ret4 = math.clamp(v249, v254, math_max_ret2);

        if math.abs(math_clamp_ret3 - v248) < 0.5 and math.abs(math_clamp_ret4 - v249) < 0.5 then
            return p247;
        end;

        return UDim2.fromOffset(math_clamp_ret3, math_clamp_ret4);
    end;

    local u255 = nil;

    u235 = function() -- Line: 1606, Name: relayout
        -- upvalues: Frame (copy), u255 (ref), u192 (copy), u236 (ref), u237 (ref), u115 (copy), toEntry (copy), SettingsRemote (copy), u92 (ref), u93 (ref), workspace_CurrentCamera (copy), u113 (ref), u114 (ref), GuiService (copy), jumpButtonTop (copy), fitCluster (copy), u178 (copy), Frame2 (copy), u179 (copy), Frame5 (copy), u180 (copy), customPos (copy), safeDefault (copy), u98 (ref), TextButton (copy), TextButton2 (copy), u243 (copy), positionEditButtons (copy)
        local AbsoluteSize = Frame.AbsoluteSize;

        if u255 and AbsoluteSize ~= u255 then
            for _, v in ipairs(u192) do
                pcall(v);
            end;
        end;

        u255 = AbsoluteSize;

        if u236 and (not u237 and AbsoluteSize.X > 0) then
            u237 = true;

            for i, v in pairs(u115) do
                if v.AX == nil and (tonumber(v.X) and tonumber(v.Y)) then
                    local v256, v257 = i:match("^([^/]+)/(.+)$");

                    if v256 and v257 then
                        local v258 = toEntry(AbsoluteSize, v.X * AbsoluteSize.X, v.Y * AbsoluteSize.Y);
                        u115[i] = v258;
                        SettingsRemote:FireServer({
                            Action = "MobileLayout",
                            Page = v256,
                            ButtonAction = v257,
                            AX = v258.AX,
                            AY = v258.AY,
                            DX = v258.DX,
                            DY = v258.DY
                        });
                    end;
                end;
            end;
        end;

        local v259 = workspace_CurrentCamera and workspace_CurrentCamera.ViewportSize or Vector2.new(800, 480);
        local v260 = math.min(v259.X, v259.Y) * 0.105;
        local math_floor_ret7 = math.floor(v260);
        local math_clamp_ret3 = math.clamp(math_floor_ret7, 44, 62);
        local math_floor_ret8 = math.floor(math_clamp_ret3 * 0.18);
        local v261 = math_clamp_ret3 + math.clamp(math_floor_ret8, 6, 14);
        u92 = math_clamp_ret3;
        u93 = v261;
        local v262 = GuiService:GetGuiInset().Y + 74;
        local v263 = jumpButtonTop();
        local v264 = (v263 and math.max(150, v263 + 12) or 150) + 26;
        u113 = v262;
        u114 = v264;
        local v265 = workspace_CurrentCamera and workspace_CurrentCamera.ViewportSize or Vector2.new(800, 480);
        local v266 = math.min(v265.X, v265.Y) * 0.105;
        local math_floor_ret9 = math.floor(v266);
        local math_clamp_ret4 = math.clamp(math_floor_ret9, 44, 62);
        local math_floor_ret10 = math.floor(math_clamp_ret4 * 0.18);
        local _ = math_clamp_ret4 + math.clamp(math_floor_ret10, 6, 14);
        local v267, v268, v269 = fitCluster(u92, u93, u114, 4, v265 and v265.Y or 480, u113);
        u92 = v267;
        u93 = v268;
        u114 = v269;
        local UDim2_fromOffset_ret = UDim2.fromOffset(u92, u92);
        local math_floor_ret11 = math.floor(u92 * 0.24);
        local math_clamp_ret5 = math.clamp(math_floor_ret11, 10, 15);

        for _, v in ipairs({
            { Frame, u178, false },
            { Frame2, u179, false },
            { Frame5, u180, true }
        }) do
            local v270 = v;

            for _, v2 in ipairs(v[2]) do
                local v271 = v270[1]:FindFirstChild(v2.action);

                if v271 then
                    v271.Size = UDim2_fromOffset_ret;
                    v271.TextSize = math_clamp_ret5;
                    local v272 = customPos(v270[1], v2.action);

                    if not v272 then
                        local v273 = v270[1];
                        local v274 = v2.col and UDim2.new(1, -(14 + u92 + v2.col * u93) + u92 / 2, 1, -(u114 + u92 + (v2.row or 0) * u93) + u92 / 2);

                        if not v274 then
                            local slot = v2.slot;
                            local v275 = v270[3] and UDim2.new(1, -(14 + u92 + (slot - 1 + u98) * u93), 0, u113);

                            if not v275 then
                                local v276 = slot - 1;
                                local math_floor_ret12 = math.floor(v276 / 4);
                                v275 = UDim2.new(1, -(14 + u92 + v276 % 4 * u93), 1, -(u114 + u92 + math_floor_ret12 * u93));
                            end;

                            v274 = UDim2.new(v275.X.Scale, v275.X.Offset + u92 / 2, v275.Y.Scale, v275.Y.Offset + u92 / 2);
                        end;

                        v272 = safeDefault(v273, v274);
                    end;

                    v271.Position = v272;
                end;
            end;
        end;

        TextButton.Size = UDim2_fromOffset_ret;
        TextButton.TextSize = math_clamp_ret5;
        TextButton.Position = UDim2.new(1, -(14 + u92 + 4 * u93), 1, -(u114 + u92));
        TextButton2.Size = UDim2.fromOffset(u92, (math.floor(u92 * 0.6)));
        u243.Size = TextButton2.Size;
        positionEditButtons();
    end;

    workspace_CurrentCamera:GetPropertyChangedSignal("ViewportSize"):Connect(function() -- Line: 1662
        -- upvalues: u235 (ref)
        task.defer(u235);
    end);
    Frame:GetPropertyChangedSignal("AbsoluteSize"):Connect(function() -- Line: 1663
        -- upvalues: u235 (ref)
        task.defer(u235);
    end);
    task.defer(u235);
    task.spawn(function() -- Line: 1674
        -- upvalues: GuiService (copy), jumpButtonTop (copy), u114 (ref), u235 (ref)
        for i = 1, 10 do
            task.wait(0.5);
            local _ = GuiService:GetGuiInset().Y + 74;
            local v277 = jumpButtonTop();
            local v278;

            if (v277 and math.max(150, v277 + 12) or 150) + 26 == u114 then
                v278 = i;
            else
                u235();
                v278 = i;
            end;
        end;
    end);
    LocalPlayer.CharacterAdded:Connect(function() -- Line: 1681
        -- upvalues: u235 (ref)
        task.wait(1);
        u235();
    end);
end;

local PadLayer = ControlData.PadLayer;
local Modifier = PadLayer.Modifier;
local HoldTime = PadLayer.HoldTime;
local u279 = {
    [Modifier] = true
};
local Bank = PadLayer.Bank;
local Hold = PadLayer.Hold;
local u280 = {};
local u281 = {};
local u282 = {
    ButtonX = {
        slot = "1"
    },
    ButtonY = {
        slot = "2"
    },
    ButtonB = {
        slot = "3"
    },
    ButtonR2 = {
        slot = "4"
    },
    DPadRight = {
        cycle = "Hotbar Next"
    }
};
local u283 = nil;
local u284 = nil;
local u285 = nil;
local u286 = false;

local function pressBank(p287) -- Line: 1741
    -- upvalues: u176 (copy), TouchActionRemote (copy), ControlData (copy), beginInput (copy), endInput (copy)
    if p287.bridge ~= true and u176[p287.group] ~= true then
        local action = p287.action;
        local v288 = ControlData.Controls and ControlData.Controls[p287.group];

        if v288 then
            v288 = v288[action];
        end;

        if typeof(v288) == "table" then
            v288 = v288[1];
        end;

        if not v288 then
            warn(("[GamepadBank] no ControlData key for %s.%s"):format(p287.group, p287.action));

            return;
        end;

        beginInput(v288);
        task.defer(endInput, v288);

        return;
    end;

    local group = p287.group;
    local action = p287.action;
    local action2 = p287.action;
    local v289 = ControlData.Controls and ControlData.Controls[p287.group];

    if v289 then
        v289 = v289[action2];
    end;

    if typeof(v289) == "table" then
        v289 = v289[1];
    end;

    TouchActionRemote:Fire(group, action, v289);
end;

u4.GamepadBank = {
    Key = Modifier,
    Keys = u279,
    Map = Bank,
    Hold = Hold,

    IsHeld = function() -- Line: 1758, Name: IsHeld
        -- upvalues: u284 (ref)
        return u284 ~= nil;
    end
};
local GamepadGlyphs = require(Shared.GamepadGlyphs);
local u290 = { "ButtonL1", "DPadRight", "ButtonY", "ButtonX", "ButtonB", "ButtonA", "ButtonR1", "DPadUp", "DPadLeft", "ButtonL2", "ButtonR2" };
local u291 = {
    ["Hotbar Prev"] = "Hotbar -",
    ["Hotbar Next"] = "Hotbar +",
    Transformations = "Forms",
    ["Cinematic Mode"] = "Cinematic"
};
local Color3_fromRGB_ret3 = Color3.fromRGB(235, 228, 215);
local u292 = nil;

local function buildPrompt() -- Line: 1781
    -- upvalues: Color3_fromRGB_ret (copy), GamepadGlyphs (copy), Color3_fromRGB_ret2 (copy), Color3_fromRGB_ret3 (copy), Modifier (copy), u290 (copy), Bank (copy), u291 (copy), LocalPlayer (copy)
    local ScreenGui = Instance.new("ScreenGui");
    ScreenGui.Name = "PadLayerPrompt";
    ScreenGui.ResetOnSpawn = false;
    ScreenGui.IgnoreGuiInset = true;
    ScreenGui.DisplayOrder = 45;
    ScreenGui.Enabled = false;
    local Frame = Instance.new("Frame");
    Frame.AnchorPoint = Vector2.new(0.5, 1);
    Frame.Position = UDim2.new(0.5, 0, 1, -140);
    Frame.AutomaticSize = Enum.AutomaticSize.XY;
    Frame.Size = UDim2.new(0, 0, 0, 0);
    Frame.BackgroundColor3 = Color3_fromRGB_ret;
    Frame.BackgroundTransparency = 0.15;
    Frame.BorderSizePixel = 0;
    Frame.Parent = ScreenGui;
    Instance.new("UICorner", Frame).CornerRadius = UDim.new(0, 6);
    local UIPadding = Instance.new("UIPadding");
    UIPadding.PaddingLeft = UDim.new(0, 12);
    UIPadding.PaddingRight = UDim.new(0, 12);
    UIPadding.PaddingTop = UDim.new(0, 6);
    UIPadding.PaddingBottom = UDim.new(0, 6);
    UIPadding.Parent = Frame;
    local UIListLayout = Instance.new("UIListLayout");
    UIListLayout.FillDirection = Enum.FillDirection.Horizontal;
    UIListLayout.VerticalAlignment = Enum.VerticalAlignment.Center;
    UIListLayout.SortOrder = Enum.SortOrder.LayoutOrder;
    UIListLayout.Padding = UDim.new(0, 14);
    UIListLayout.Parent = Frame;

    local function chip(p293, p294, p295, p296) -- Line: 1810
        -- upvalues: Frame (copy), GamepadGlyphs (ref), Color3_fromRGB_ret2 (ref), Color3_fromRGB_ret (ref), Color3_fromRGB_ret3 (ref)
        local Frame2 = Instance.new("Frame");
        Frame2.LayoutOrder = p293;
        Frame2.BackgroundTransparency = 1;
        Frame2.AutomaticSize = Enum.AutomaticSize.X;
        Frame2.Size = UDim2.new(0, 0, 0, 26);
        Frame2.Parent = Frame;
        local UIListLayout2 = Instance.new("UIListLayout");
        UIListLayout2.FillDirection = Enum.FillDirection.Horizontal;
        UIListLayout2.VerticalAlignment = Enum.VerticalAlignment.Center;
        UIListLayout2.SortOrder = Enum.SortOrder.LayoutOrder;
        UIListLayout2.Padding = UDim.new(0, 5);
        UIListLayout2.Parent = Frame2;
        local v297 = GamepadGlyphs.Image(p294);

        if v297 then
            local ImageLabel = Instance.new("ImageLabel");
            ImageLabel.LayoutOrder = 1;
            ImageLabel.BackgroundTransparency = 1;
            ImageLabel.Size = UDim2.new(0, 26, 0, 26);
            ImageLabel.Image = v297;
            ImageLabel.Parent = Frame2;
        else
            local TextLabel = Instance.new("TextLabel");
            TextLabel.LayoutOrder = 1;
            TextLabel.AutomaticSize = Enum.AutomaticSize.X;
            TextLabel.Size = UDim2.new(0, 0, 0, 22);
            TextLabel.BackgroundColor3 = Color3_fromRGB_ret2;
            TextLabel.BorderSizePixel = 0;
            TextLabel.Font = Enum.Font.GothamBold;
            TextLabel.TextSize = 12;
            TextLabel.TextColor3 = Color3_fromRGB_ret;
            TextLabel.Text = " " .. GamepadGlyphs.Short(p294) .. " ";
            TextLabel.Parent = Frame2;
            Instance.new("UICorner", TextLabel).CornerRadius = UDim.new(0, 4);
        end;

        local TextLabel = Instance.new("TextLabel");
        TextLabel.LayoutOrder = 2;
        TextLabel.AutomaticSize = Enum.AutomaticSize.X;
        TextLabel.Size = UDim2.new(0, 0, 0, 22);
        TextLabel.BackgroundTransparency = 1;
        TextLabel.Font = p296 and Enum.Font.GothamBold or Enum.Font.GothamMedium;
        TextLabel.TextSize = 13;
        TextLabel.TextColor3 = p296 and Color3_fromRGB_ret2 or Color3_fromRGB_ret3;
        TextLabel.Text = p295;
        TextLabel.Parent = Frame2;
    end;

    chip(0, Modifier, "+", true);

    for i, v in ipairs(u290) do
        local v298 = Bank[v];

        if v298 then
            chip(i, v, u291[v298.action] or v298.action);
        end;
    end;

    ScreenGui.Parent = LocalPlayer:WaitForChild("PlayerGui");

    return ScreenGui;
end;

local function setPrompt(p299) -- Line: 1867
    -- upvalues: u292 (ref), buildPrompt (copy)
    if p299 and not u292 then
        u292 = buildPrompt();
    end;

    if u292 then
        u292.Enabled = p299;
    end;
end;

local function padModifierTap(p300) -- Line: 1879
    -- upvalues: LocalPlayer (copy), StateManager (copy), beginInput (copy), endInput (copy)
    local Character = LocalPlayer.Character;

    if not Character then
        return;
    end;

    if StateManager.IsInState(Character, "Flying") then
        beginInput(p300);

        return;
    end;

    if StateManager.IsInState(Character, "Running") then
        endInput(p300);

        return;
    end;

    beginInput(p300);
    beginInput(p300);
end;

UserInputService.InputBegan:Connect(function(p301, p302) -- Line: 1899
    -- upvalues: Platform (copy), getKeyEvaluation (copy), u279 (copy), u284 (ref), u285 (ref), u286 (ref), HoldTime (copy), u292 (ref), buildPrompt (copy), u283 (ref), u282 (copy), TouchActionRemote (copy), Bank (copy), pressBank (copy), Hold (copy), u280 (copy), u281 (copy), ControlData (copy), beginInput (copy)
    if Platform.InputBlocked(p301, p302) then
        return;
    end;

    local u303 = getKeyEvaluation(p301);

    if u279[u303] and not u284 then
        local os_clock_ret = os.clock();
        u284 = os_clock_ret;
        u285 = u303;
        u286 = false;
        task.delay(HoldTime, function() -- Line: 1910
            -- upvalues: u284 (ref), os_clock_ret (copy), u292 (ref), buildPrompt (ref)
            if u284 == os_clock_ret then
                if not u292 then
                    u292 = buildPrompt();
                end;

                if u292 then
                    u292.Enabled = true;
                end;
            end;
        end);

        return;
    end;

    if u303 == "ButtonL1" then
        u283 = os.clock();
    else
        local v304 = u283 and u282[u303];

        if v304 then
            if v304.slot then
                TouchActionRemote:Fire("CoreControls", "Hotbar Slot", v304.slot);

                return;
            end;

            TouchActionRemote:Fire("CoreControls", v304.cycle, u303);

            return;
        end;
    end;

    local v305 = u284 and Bank[u303];

    if v305 then
        u286 = true;
        pressBank(v305);

        return;
    end;

    local u306 = Hold[u303];

    if u306 then
        local os_clock_ret = os.clock();
        u280[u303] = os_clock_ret;
        u281[u303] = nil;
        task.delay(0.25, function() -- Line: 1949
            -- upvalues: u280 (ref), u303 (copy), os_clock_ret (copy), u306 (copy), ControlData (ref), u281 (ref), beginInput (ref)
            if u280[u303] ~= os_clock_ret then
                return;
            end;

            local v307 = u306;
            local v308 = ControlData.Controls and ControlData.Controls.Combat;

            if v308 then
                v308 = v308[v307];
            end;

            if typeof(v308) == "table" then
                v308 = v308[1];
            end;

            if not v308 then
                return;
            end;

            u281[u303] = v308;
            beginInput(v308);
        end);
    end;

    beginInput(u303);
end);
UserInputService.InputEnded:Connect(function(p309, p310) -- Line: 1961
    -- upvalues: getKeyEvaluation (copy), u283 (ref), Platform (copy), u285 (ref), u284 (ref), u286 (ref), u292 (ref), Hold (copy), u280 (copy), u281 (copy), endInput (copy), HoldTime (copy), padModifierTap (copy)
    local v311 = getKeyEvaluation(p309);

    if v311 == "ButtonL1" then
        u283 = nil;
    end;

    if Platform.InputBlocked(p309, p310) then
        if v311 == u285 then
            u284 = nil;
            u285 = nil;
            u286 = false;

            if u292 then
                u292.Enabled = false;
            end;
        end;

        if Hold[v311] then
            u280[v311] = nil;
            local v312 = u281[v311];
            u281[v311] = nil;

            if v312 then
                endInput(v312);
            end;
        end;

        return;
    end;

    if v311 ~= u285 then
        if Hold[v311] then
            u280[v311] = nil;
            local v313 = u281[v311];
            u281[v311] = nil;

            if v313 then
                endInput(v313);
            end;
        end;

        endInput(v311);

        return;
    end;

    local v314 = u284 and os.clock() - u284 or (1 / 0);
    u284 = nil;
    u285 = nil;

    if u292 then
        u292.Enabled = false;
    end;

    if not u286 and v314 < HoldTime then
        padModifierTap(v311);
    end;

    u286 = false;
end);
task.spawn(function() -- Line: 2024
    local PlayerGui = game:GetService("Players").LocalPlayer:WaitForChild("PlayerGui");

    if PlayerGui:FindFirstChild("BossBarGui") then
        return;
    end;

    local BossBarGui = game:GetService("ReplicatedStorage"):WaitForChild("Assets"):WaitForChild("Gui"):WaitForChild("BossBarGui", 20);

    if BossBarGui and not PlayerGui:FindFirstChild("BossBarGui") then
        BossBarGui:Clone().Parent = PlayerGui;
    end;
end);
AnimationRemote.OnClientEvent:Connect(function(p315, p316, p317, p318) -- Line: 2034
    -- upvalues: u24 (copy)
    if p316 == "LoadAnimations" then
        u24[p316](p315, p317);

        return;
    end;

    u24[p316](p318, p315, p317);
end);
ClientRemote.OnClientEvent:Connect(function(p319) -- Line: 2042
    -- upvalues: u4 (copy)
    if not p319.Module then
        return;
    end;

    u4[p319.Module][p319.Function](p319);
end);

local function getMouseWorldPosition() -- Line: 2049
    -- upvalues: workspace_Camera (copy), u1 (copy), LocalPlayer (copy), Visuals (copy), workspace_World (copy), RaycastParams_new_ret (copy)
    local Position = workspace_Camera.CFrame.Position;
    local v320 = u1.Hit and u1.Hit.Position;

    if not v320 then
        return Position;
    end;

    local function findLivingCharacter(p321) -- Line: 2061
        -- upvalues: LocalPlayer (ref)
        while p321 and p321 ~= workspace do
            local v322 = p321:IsA("Model") and p321:FindFirstChildOfClass("Humanoid");

            if v322 then
                if v322.Health > 0 and p321 ~= LocalPlayer.Character then
                    return p321;
                end;

                return nil;
            end;

            p321 = p321.Parent;
        end;

        return nil;
    end;

    local Target = u1.Target;

    if Target and findLivingCharacter(Target) then
        return v320;
    end;

    local RaycastParams_new_ret2 = RaycastParams.new();
    RaycastParams_new_ret2.FilterType = Enum.RaycastFilterType.Exclude;
    RaycastParams_new_ret2.FilterDescendantsInstances = { Visuals, LocalPlayer.Character, workspace_World:FindFirstChild("Zones", true) };
    local v323 = workspace:Raycast(Position, (v320 - Position).Unit * 10000, RaycastParams_new_ret2);

    if v323 and findLivingCharacter(v323.Instance) then
        return v323.Position;
    end;

    local v324 = workspace:Raycast(Position, (v320 - Position).Unit * 10000, RaycastParams_new_ret);

    if v324 then
        v320 = v324.Position or v320;
    end;

    return v320;
end;

function GetMouse.OnClientInvoke() -- Line: 2112
    -- upvalues: u1 (copy), workspace_World (copy), LocalPlayer (copy), workspace_Camera (copy), getMouseWorldPosition (copy)
    u1.TargetBlackList = { workspace_World.Visuals, LocalPlayer.Character, workspace_World:FindFirstChild("Zones", true) };
    local LockOnTarget = LocalPlayer:FindFirstChild("LockOnTarget");

    if LockOnTarget then
        LockOnTarget = LockOnTarget.Value;
    end;

    local v325 = LockOnTarget and LockOnTarget.Parent and LockOnTarget:FindFirstChild("HumanoidRootPart");

    if LockOnTarget then
        LockOnTarget = LockOnTarget:FindFirstChildOfClass("Humanoid");
    end;

    if not (v325 and (LockOnTarget and LockOnTarget.Health > 0)) then
        return {
            Hit = u1.Hit,
            Position = getMouseWorldPosition(),
            Target = u1.Target
        };
    end;

    local v326 = v325.Position + Vector3.new(0, 1, 0);

    return {
        Hit = CFrame.lookAt(v326, v326 + (v326 - workspace_Camera.CFrame.Position).Unit),
        Position = v326,
        Target = v325
    };
end;