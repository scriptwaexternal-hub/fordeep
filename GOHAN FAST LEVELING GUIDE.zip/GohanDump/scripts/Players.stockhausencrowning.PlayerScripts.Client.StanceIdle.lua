-- Decompiled with Potassium's decompiler.

local Players = game:GetService("Players");
local ReplicatedStorage = game:GetService("ReplicatedStorage");
local UserInputService = game:GetService("UserInputService");
local RunService = game:GetService("RunService");
local Modules = ReplicatedStorage:WaitForChild("Modules");
local Stances = ReplicatedStorage:WaitForChild("Assets"):WaitForChild("Animations"):WaitForChild("Stances");
local StateManager = require(Modules.Metadata.ControlData.StateManager);
local SoundManager = require(Modules.Shared.SoundManager);
local StatChangeRemote = ReplicatedStorage.Remotes.StatChangeRemote;
local u1 = {
    Default = true,
    Brawler = true,
    Crane = true,
    Turtle = true
};
local LocalPlayer = Players.LocalPlayer;
local u2 = ReplicatedStorage.Remotes.StatRetrieveRemote:InvokeServer("CombatType") or "Default";
local os_clock_ret = os.clock();
local u3 = nil;
local u4 = nil;
local u5 = false;
local u6 = 0;
StatChangeRemote.OnClientEvent:Connect(function(p7, p8) -- Line: 41
    -- upvalues: u2 (ref)
    if p7 == "Combat Style" and (p8 and p8.NewStyle) then
        u2 = p8.NewStyle;
    end;
end);

local function styleName() -- Line: 47
    -- upvalues: u1 (copy), u2 (ref)
    return u1[u2] and u2 or "Default";
end;

local function stopStance() -- Line: 51
    -- upvalues: u5 (ref), u6 (ref), u3 (ref), u4 (ref)
    if not u5 then
        return;
    end;

    u5 = false;
    u6 = u6 + 1;

    if u3 then
        u3:Stop(0.25);
        u3:Destroy();
        u3 = nil;
    end;

    if u4 then
        u4:Stop(0.25);
        u4:Destroy();
        u4 = nil;
    end;
end;

local function markActive() -- Line: 59
    -- upvalues: os_clock_ret (ref), u5 (ref), u6 (ref), u3 (ref), u4 (ref)
    os_clock_ret = os.clock();

    if not u5 then
        return;
    end;

    u5 = false;
    u6 = u6 + 1;

    if u3 then
        u3:Stop(0.25);
        u3:Destroy();
        u3 = nil;
    end;

    if u4 then
        u4:Stop(0.25);
        u4:Destroy();
        u4 = nil;
    end;
end;

local function canIdle(p9, p10) -- Line: 64
    -- upvalues: StateManager (copy)
    if p10.Health <= 0 then
        return false;
    end;

    if p10.MoveDirection.Magnitude > 0 then
        return false;
    end;

    if p10.FloorMaterial == Enum.Material.Air then
        return false;
    end;

    if p10.Sit or p10.PlatformStand then
        return false;
    end;

    return StateManager.GetState(p9) == "Idle";
end;

local function startStance(u11, p12) -- Line: 73
    -- upvalues: u1 (copy), u2 (ref), Stances (copy), u5 (ref), u6 (ref), u3 (ref), SoundManager (copy), u4 (ref)
    local u13 = p12:FindFirstChildOfClass("Animator");

    if not u13 then
        return;
    end;

    local v14 = u1[u2] and u2 or "Default";
    local v15 = Stances:FindFirstChild(v14 .. " Stance Entry");
    local u16 = Stances:FindFirstChild(v14 .. " Stance Idle");

    if not (v15 and u16) then
        return;
    end;

    u5 = true;
    u6 = u6 + 1;
    local u17 = u6;
    u3 = u13:LoadAnimation(v15);
    u3.Priority = Enum.AnimationPriority.Action;
    u3.Looped = false;
    u3:GetMarkerReachedSignal("Hand"):Connect(function() -- Line: 89
        -- upvalues: u6 (ref), u17 (copy), u11 (copy), SoundManager (ref)
        if u6 ~= u17 then
            return;
        end;

        local HumanoidRootPart = u11:FindFirstChild("HumanoidRootPart");

        if HumanoidRootPart then
            SoundManager.AddSound("Hand Sound", {
                Parent = HumanoidRootPart
            }, "Client");
        end;
    end);
    u3.Stopped:Once(function() -- Line: 95
        -- upvalues: u6 (ref), u17 (copy), u5 (ref), u4 (ref), u13 (copy), u16 (copy)
        if u6 ~= u17 or not u5 then
            return;
        end;

        u4 = u13:LoadAnimation(u16);
        u4.Priority = Enum.AnimationPriority.Action;
        u4.Looped = true;
        u4:Play(0.25);
    end);
    u3:Play(0.25);
end;

UserInputService.InputBegan:Connect(function(p18, p19) -- Line: 107
    -- upvalues: os_clock_ret (ref), u5 (ref), u6 (ref), u3 (ref), u4 (ref)
    if p19 then
        return;
    end;

    os_clock_ret = os.clock();

    if not u5 then
        return;
    end;

    u5 = false;
    u6 = u6 + 1;

    if u3 then
        u3:Stop(0.25);
        u3:Destroy();
        u3 = nil;
    end;

    if u4 then
        u4:Stop(0.25);
        u4:Destroy();
        u4 = nil;
    end;
end);

local function bindCharacter(u20) -- Line: 113
    -- upvalues: os_clock_ret (ref), u5 (ref), u6 (ref), u3 (ref), u4 (ref), RunService (copy), StateManager (copy), startStance (copy)
    local Humanoid = u20:WaitForChild("Humanoid");
    os_clock_ret = os.clock();

    if u5 then
        u5 = false;
        u6 = u6 + 1;

        if u3 then
            u3:Stop(0.25);
            u3:Destroy();
            u3 = nil;
        end;

        if u4 then
            u4:Stop(0.25);
            u4:Destroy();
            u4 = nil;
        end;
    end;

    local u21 = nil;
    u21 = RunService.Heartbeat:Connect(function() -- Line: 118
        -- upvalues: u20 (copy), Humanoid (copy), u5 (ref), u6 (ref), u3 (ref), u4 (ref), u21 (ref), StateManager (ref), os_clock_ret (ref), startStance (ref)
        if u20.Parent == nil or Humanoid.Health <= 0 then
            if u5 then
                u5 = false;
                u6 = u6 + 1;

                if u3 then
                    u3:Stop(0.25);
                    u3:Destroy();
                    u3 = nil;
                end;

                if u4 then
                    u4:Stop(0.25);
                    u4:Destroy();
                    u4 = nil;
                end;
            end;

            u21:Disconnect();

            return;
        end;

        local v22 = u20;
        local v23 = Humanoid;
        local v24;

        if v23.Health <= 0 or (v23.MoveDirection.Magnitude > 0 or (v23.FloorMaterial == Enum.Material.Air or (v23.Sit or v23.PlatformStand))) then
            v24 = false;
        else
            v24 = StateManager.GetState(v22) == "Idle";
        end;

        if v24 then
            if not u5 and os.clock() - os_clock_ret >= 15 then
                startStance(u20, Humanoid);
            end;

            return;
        end;

        os_clock_ret = os.clock();

        if not u5 then
            return;
        end;

        u5 = false;
        u6 = u6 + 1;

        if u3 then
            u3:Stop(0.25);
            u3:Destroy();
            u3 = nil;
        end;

        if u4 then
            u4:Stop(0.25);
            u4:Destroy();
            u4 = nil;
        end;
    end);
end;

if LocalPlayer.Character then
    local Character = LocalPlayer.Character;
    local Humanoid = Character:WaitForChild("Humanoid");
    os_clock_ret = os.clock();

    if u5 then
        u5 = false;
        u6 = u6 + 1;

        if u3 then
            u3:Stop(0.25);
            u3:Destroy();
            u3 = nil;
        end;

        if u4 then
            u4:Stop(0.25);
            u4:Destroy();
            u4 = nil;
        end;
    end;

    local u25 = nil;
    u25 = RunService.Heartbeat:Connect(function() -- Line: 118
        -- upvalues: Character (copy), Humanoid (copy), u5 (ref), u6 (ref), u3 (ref), u4 (ref), u25 (ref), StateManager (copy), os_clock_ret (ref), startStance (copy)
        if Character.Parent == nil or Humanoid.Health <= 0 then
            if u5 then
                u5 = false;
                u6 = u6 + 1;

                if u3 then
                    u3:Stop(0.25);
                    u3:Destroy();
                    u3 = nil;
                end;

                if u4 then
                    u4:Stop(0.25);
                    u4:Destroy();
                    u4 = nil;
                end;
            end;

            u25:Disconnect();

            return;
        end;

        local v26 = Character;
        local v27 = Humanoid;
        local v28;

        if v27.Health <= 0 or (v27.MoveDirection.Magnitude > 0 or (v27.FloorMaterial == Enum.Material.Air or (v27.Sit or v27.PlatformStand))) then
            v28 = false;
        else
            v28 = StateManager.GetState(v26) == "Idle";
        end;

        if v28 then
            if not u5 and os.clock() - os_clock_ret >= 15 then
                startStance(Character, Humanoid);
            end;

            return;
        end;

        os_clock_ret = os.clock();

        if not u5 then
            return;
        end;

        u5 = false;
        u6 = u6 + 1;

        if u3 then
            u3:Stop(0.25);
            u3:Destroy();
            u3 = nil;
        end;

        if u4 then
            u4:Stop(0.25);
            u4:Destroy();
            u4 = nil;
        end;
    end);
end;

LocalPlayer.CharacterAdded:Connect(bindCharacter);