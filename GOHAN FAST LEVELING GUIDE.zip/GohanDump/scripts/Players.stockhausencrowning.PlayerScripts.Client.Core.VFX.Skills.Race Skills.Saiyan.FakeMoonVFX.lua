-- Decompiled with Potassium's decompiler.

local Debris = game:GetService("Debris");
local ReplicatedStorage = game:GetService("ReplicatedStorage");
local RunService = game:GetService("RunService");
local Modules = ReplicatedStorage:WaitForChild("Modules");
local GlobalFunctions = require(Modules.GlobalFunctions);
local AnimationManager = require(Modules.Shared.AnimationManager);
local Bezier = require(Modules.Shared.Bezier);
local Visuals = workspace.World.Visuals;

return {
    Fire = function(p1) -- Line: 25
        -- upvalues: GlobalFunctions (copy), AnimationManager (copy), Visuals (copy), Debris (copy), Bezier (copy), RunService (copy)
        local Character = p1.Character;

        if not Character then
            return;
        end;

        local RootAndHumanoid = GlobalFunctions.GetRootAndHumanoid(Character);

        if not RootAndHumanoid then
            return;
        end;

        local u2 = p1.Duration or 10;
        local u3 = Character:FindFirstChild("Right Arm") or RootAndHumanoid;
        local u4 = Character:FindFirstChild("Head") or RootAndHumanoid;
        local u5 = AnimationManager.PlayAnimation(Character, "Fake Moon");
        local Part = Instance.new("Part");
        local Weld = Instance.new("Weld");

        local function generate() -- Line: 40
            -- upvalues: Part (copy), Visuals (ref), Debris (ref), u2 (copy), Weld (copy), u3 (copy), GlobalFunctions (ref)
            Part.Material = Enum.Material.Neon;
            Part.Size = Vector3.new(0, 0, 0);
            Part.CanCollide = false;
            Part.Shape = Enum.PartType.Ball;
            Part.Parent = Visuals;
            Debris:AddItem(Part, u2);
            Weld.Part0 = Part;
            Weld.Part1 = u3;
            Weld.C0 = CFrame.new(0, 2, 0);
            Weld.Parent = Part;
            GlobalFunctions.Tween({
                Duration = 0.5,
                Instance = Part
            }, {
                Size = Vector3.new(2, 2, 2)
            });
            task.delay(u2 - 1, function() -- Line: 55
                -- upvalues: Part (ref), GlobalFunctions (ref)
                if not Part.Parent then
                    return;
                end;

                GlobalFunctions.Tween({
                    Duration = 1,
                    Instance = Part
                }, {
                    Size = Vector3.new(0, 0, 0)
                });
            end);
        end;

        local function throw() -- Line: 61
            -- upvalues: Weld (copy), Part (copy), u4 (copy), Bezier (ref), RunService (ref), GlobalFunctions (ref)
            Weld:Destroy();
            Part.Anchored = true;
            local Position = Part.CFrame.Position;
            local v6 = Part.CFrame * CFrame.new(math.random(-40, 40), math.random(20, 40), math.random(-70, -20)).Position;
            local v7 = u4.CFrame * CFrame.new(0, 50, 0).Position;
            local v8 = Bezier.new(Bezier.quadBezier, 10, Position, v6, v7);

            for i = 0, 1, 0.02 do
                if not Part.Parent then
                    return;
                end;

                Part.CFrame = CFrame.new(v8:calcFixed(i));
                RunService.Heartbeat:Wait();
                local _ = i;
            end;

            GlobalFunctions.Tween({
                Duration = 2,
                Instance = Part
            }, {
                Size = Vector3.new(10, 10, 10)
            });
        end;

        local u9 = u5:GetMarkerReachedSignal("Generate"):Once(generate);
        local u10 = u5:GetMarkerReachedSignal("Throw"):Once(throw);
        task.spawn(function() -- Line: 83
            -- upvalues: GlobalFunctions (ref), Character (copy), u5 (copy), u9 (copy), u10 (copy)
            GlobalFunctions.SkillWait(Character, 4);
            u5:Stop();
            u9:Disconnect();
            u10:Disconnect();
        end);
    end
};