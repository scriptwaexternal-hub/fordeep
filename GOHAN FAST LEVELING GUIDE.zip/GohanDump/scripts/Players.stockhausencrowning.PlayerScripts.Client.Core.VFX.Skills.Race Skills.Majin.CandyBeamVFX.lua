-- Decompiled with Potassium's decompiler.

local Debris = game:GetService("Debris");
local ReplicatedStorage = game:GetService("ReplicatedStorage");
local Modules = ReplicatedStorage:WaitForChild("Modules");
local GlobalFunctions = require(Modules.GlobalFunctions);
local SoundManager = require(Modules.Shared.SoundManager);
local Visuals = workspace.World.Visuals;
local Particles = ReplicatedStorage.Assets.Effects.Particles;
local Color3_fromRGB_ret = Color3.fromRGB(255, 105, 180);

return {
    Dust = function(p1) -- Line: 26
        -- upvalues: GlobalFunctions (copy), Particles (copy), Visuals (copy), Debris (copy), Color3_fromRGB_ret (copy), SoundManager (copy)
        local Character = p1.Character;

        if not Character then
            return;
        end;

        local RootAndHumanoid = GlobalFunctions.GetRootAndHumanoid(Character);

        if not RootAndHumanoid then
            return;
        end;

        local v2 = Particles.Dust:Clone();
        v2.CFrame = RootAndHumanoid.CFrame;
        v2.Parent = Visuals;
        Debris:AddItem(v2, 3);
        local Effect = v2.Effect;
        Effect.LightEmission = 0.8;
        Effect.LightInfluence = 1;
        Effect.Brightness = 2;
        Effect.Lifetime = NumberRange.new(1);
        Effect.Color = ColorSequence.new({ ColorSequenceKeypoint.new(0, Color3_fromRGB_ret), ColorSequenceKeypoint.new(1, Color3_fromRGB_ret) });
        Effect:Emit(30);
        SoundManager.AddSound("Aura Burst", {
            Parent = RootAndHumanoid
        }, "Client");
    end
};