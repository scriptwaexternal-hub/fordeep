-- Decompiled with Potassium's decompiler.

return function(u1) -- Line: 1
    u1.Registry.registerType("command", {
        transform = function(p2) -- Line: 3, Name: transform
            -- upvalues: u1 (copy)
            local string_lower_ret = string.lower(p2);
            local v3 = u1.Registry.commands[string_lower_ret];

            if v3 and v3.LocalPlayerAuthorized then
                return v3;
            end;

            for i, v in u1.Registry.commands do
                if v.LocalPlayerAuthorized then
                    if string.find(string.lower(i), string_lower_ret, 1, true) then
                        return v;
                    end;

                    if v.aliases then
                        local v4 = v;

                        for _, v2 in v.aliases do
                            if string.find(string.lower(v2), string_lower_ret, 1, true) then
                                return v4;
                            end;
                        end;
                    end;
                end;
            end;
        end,

        validate = function(p5) -- Line: 28, Name: validate
            return p5 and true or false, "No command with that name could be found.";
        end,

        suggestions = function(p6) -- Line: 32, Name: suggestions
            -- upvalues: u1 (copy)
            if not u1.client.settings.onlyShowUsableCommands._value then
                return u1.Registry.commandNames, u1.Registry.commands;
            end;

            local v7 = {};

            for _, v in u1.Registry.commandNames do
                local v8 = u1.Registry.commands[v];

                if v8 and v8.LocalPlayerAuthorized then
                    table.insert(v7, v);
                end;
            end;

            return v7, u1.Registry.commands;
        end,

        parse = function(p9) -- Line: 46, Name: parse
            return p9;
        end
    });
end;