-- Decompiled with Potassium's decompiler.

local Debris = game:GetService("Debris");
local Particles = game:GetService("ReplicatedStorage").Assets.Effects.Particles;

return {
    Fire = function(p1) -- Line: 17
        -- upvalues: Particles (copy), Debris (copy)
        local Character = p1.Character;

        if not Character then
            return;
        end;

        local Head = Character:FindFirstChild("Head");

        if not Head then
            return;
        end;

        local u2 = Particles.FlameBreath.FlameAttachment:Clone();
        u2.Parent = Head;
        u2.LitPFX.Enabled = true;
        task.delay(0.5, function() -- Line: 27
            -- upvalues: u2 (copy), Debris (ref)
            if not u2.Parent then
                return;
            end;

            u2.LitPFX.Enabled = false;
            Debris:AddItem(u2, 2);
        end);
    end
};