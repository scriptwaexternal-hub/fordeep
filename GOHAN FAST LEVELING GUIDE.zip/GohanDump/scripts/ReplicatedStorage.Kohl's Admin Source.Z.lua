-- Decompiled with Potassium's decompiler.

local function isZType(p1) -- Line: 37
    local v2;

    if type(p1) == "table" and type(p1.read) == "function" then
        v2 = type(p1.write) == "function";
    else
        v2 = false;
    end;

    return v2;
end;

local u3 = {
    TRIM_STRINGS = false,
    BUFFER = buffer.create(1048576)
};
local u4 = {};

function u3.some(p5: table) -- Line: 51
    -- upvalues: u4 (copy)
    local v6 = u4[p5];

    if not v6 then
        local read = p5.read;
        local write = p5.write;
        v6 = table.freeze({
            name = `some({p5.name})`,

            write = function(p7: buffer, p8: number, p9: any) -- Line: 58, Name: write
                -- upvalues: write (copy)
                if p9 == nil then
                    buffer.writeu8(p7, p8, 0);

                    return p8 + 1;
                end;

                buffer.writeu8(p7, p8, 1);

                return write(p7, p8 + 1, p9);
            end,

            read = function(p10: buffer, p11: number, p12: boolean?) -- Line: 67, Name: read
                -- upvalues: read (copy)
                if buffer.readu8(p10, p11) == 1 then
                    return read(p10, p11 + 1, p12);
                end;

                return nil, p11 + 1;
            end
        });
        u4[p5] = v6;
    end;

    return v6;
end;

local function readBool(p13: buffer, p14: number) -- Line: 83
    local buffer_readu8_ret = buffer.readu8(p13, p14);

    return bit32.btest(buffer_readu8_ret, 1), bit32.btest(buffer_readu8_ret, 2), bit32.btest(buffer_readu8_ret, 4), bit32.btest(buffer_readu8_ret, 8), bit32.btest(buffer_readu8_ret, 16), bit32.btest(buffer_readu8_ret, 32), bit32.btest(buffer_readu8_ret, 64), bit32.btest(buffer_readu8_ret, 128);
end;

local function writeBool(p15: buffer, p16: number, p17: boolean, p18: boolean?, p19: boolean?, p20: boolean?, p21: boolean?, p22: boolean?, p23: boolean?, p24: boolean?) -- Line: 95
    local v25 = p17 and 1 or 0;

    if p18 then
        v25 = v25 + 2;
    end;

    if p19 then
        v25 = v25 + 4;
    end;

    if p20 then
        v25 = v25 + 8;
    end;

    if p21 then
        v25 = v25 + 16;
    end;

    if p22 then
        v25 = v25 + 32;
    end;

    if p23 then
        v25 = v25 + 64;
    end;

    if p24 then
        v25 = v25 + 128;
    end;

    buffer.writeu8(p15, p16, v25);

    return p16 + 1;
end;

u3.bool = {
    read = function(p26: buffer, p27: number) -- Line: 125, Name: read
        return buffer.readu8(p26, p27) == 1, p27 + 1;
    end,

    write = function(p28: buffer, p29: number, p30: boolean) -- Line: 128, Name: write
        if type(p30) ~= "boolean" then
            error((`boolean expected, got {typeof(p30)}`));
        end;

        buffer.writeu8(p28, p29, p30 and 1 or 0);

        return p29 + 1;
    end
};
u3.bools = {
    read = function(p31: buffer, p32: number) -- Line: 138, Name: read
        -- upvalues: readBool (copy)
        return { readBool(p31, p32) }, p32 + 1;
    end,

    write = function(p33: buffer, p34: number, p35: table) -- Line: 141, Name: write
        local v36 = p35[1] and 1 or 0;

        if p35[2] then
            v36 = v36 + 2;
        end;

        if p35[3] then
            v36 = v36 + 4;
        end;

        if p35[4] then
            v36 = v36 + 8;
        end;

        if p35[5] then
            v36 = v36 + 16;
        end;

        if p35[6] then
            v36 = v36 + 32;
        end;

        if p35[7] then
            v36 = v36 + 64;
        end;

        if p35[8] then
            v36 = v36 + 128;
        end;

        buffer.writeu8(p33, p34, v36);

        return p34 + 1;
    end
};
u3.boolean = u3.bool;
u3.u8 = {
    read = function(p37: buffer, p38: number) -- Line: 149, Name: read
        return buffer.readu8(p37, p38), p38 + 1;
    end,

    write = function(p39: buffer, p40: number, p41: number) -- Line: 152, Name: write
        buffer.writeu8(p39, p40, p41);

        return p40 + 1;
    end
};
u3.u16 = {
    read = function(p42: buffer, p43: number) -- Line: 159, Name: read
        return buffer.readu16(p42, p43), p43 + 2;
    end,

    write = function(p44: buffer, p45: number, p46: number) -- Line: 162, Name: write
        buffer.writeu16(p44, p45, p46);

        return p45 + 2;
    end
};
u3.u32 = {
    read = function(p47: buffer, p48: number) -- Line: 169, Name: read
        return buffer.readu32(p47, p48), p48 + 4;
    end,

    write = function(p49: buffer, p50: number, p51: number) -- Line: 172, Name: write
        buffer.writeu32(p49, p50, p51);

        return p50 + 4;
    end
};

local function readVarIntFallback(p52: buffer, p53: number, p54: number) -- Line: 178
    local buffer_readu8_ret = buffer.readu8(p52, p53 + 5);
    local v55 = p54 + buffer_readu8_ret % 128 * 34359738368;

    if buffer_readu8_ret < 128 then
        return v55, p53 + 6;
    end;

    local buffer_readu8_ret2 = buffer.readu8(p52, p53 + 6);
    local v56 = v55 + buffer_readu8_ret2 % 128 * 4398046511104;

    if buffer_readu8_ret2 < 128 then
        return v56, p53 + 7;
    end;

    local buffer_readu8_ret3 = buffer.readu8(p52, p53 + 7);
    local v57 = v56 + buffer_readu8_ret3 % 128 * 562949953421312;

    if buffer_readu8_ret3 < 128 then
        return v57, p53 + 8;
    end;

    return v57 + buffer.readu8(p52, p53 + 8) * 7.205759403792794e16, p53 + 9;
end;

local function writeVarIntFallback(p58: buffer, p59: number, p60: number) -- Line: 202
    while p60 >= 128 do
        buffer.writeu8(p58, p59, p60 % 128 + 128);
        p59 = p59 + 1;
        p60 = p60 // 128;
    end;

    buffer.writeu8(p58, p59, p60);

    return p59 + 1;
end;

local function writeVarIntUnsigned(p61: buffer, p62: number, p63: number) -- Line: 213
    if p63 >= 0 then
        if p63 < 128 then
            buffer.writeu8(p61, p62, p63);

            return p62 + 1;
        end;

        if p63 < 16384 then
            buffer.writeu16(p61, p62, p63 % 128 + 128 + p63 // 128 * 256);

            return p62 + 2;
        end;

        if p63 < 2097152 then
            buffer.writeu16(p61, p62, p63 % 128 + 128 + (p63 // 128 % 128 + 128) * 256);
            buffer.writeu8(p61, p62 + 2, p63 // 16384);

            return p62 + 3;
        end;

        if p63 < 268435456 then
            buffer.writeu32(p61, p62, p63 % 128 + 128 + (p63 // 128 % 128 + 128) * 256 + (p63 // 16384 % 128 + 128) * 65536 + p63 // 2097152 * 16777216);

            return p62 + 4;
        end;

        if p63 < 34359738368 then
            buffer.writeu32(p61, p62, p63 % 128 + 128 + (p63 // 128 % 128 + 128) * 256 + (p63 // 16384 % 128 + 128) * 65536 + (p63 // 2097152 % 128 + 128) * 16777216);
            buffer.writeu8(p61, p62 + 4, p63 // 268435456);

            return p62 + 5;
        end;

        while p63 >= 128 do
            buffer.writeu8(p61, p62, p63 % 128 + 128);
            p62 = p62 + 1;
            p63 = p63 // 128;
        end;

        buffer.writeu8(p61, p62, p63);

        return p62 + 1;
    end;

    error((`unsigned integer expected, got negative number: {p63}`));
end;

u3.uint = {
    read = function(p64: buffer, p65: number) -- Line: 253, Name: read
        -- upvalues: readVarIntFallback (copy)
        local buffer_readu8_ret = buffer.readu8(p64, p65);

        if buffer_readu8_ret < 128 then
            return buffer_readu8_ret, p65 + 1;
        end;

        local buffer_readu8_ret2 = buffer.readu8(p64, p65 + 1);

        if buffer_readu8_ret2 < 128 then
            return buffer_readu8_ret - 128 + buffer_readu8_ret2 * 128, p65 + 2;
        end;

        local buffer_readu8_ret3 = buffer.readu8(p64, p65 + 2);

        if buffer_readu8_ret3 < 128 then
            return buffer_readu8_ret - 128 + (buffer_readu8_ret2 - 128) * 128 + buffer_readu8_ret3 * 16384, p65 + 3;
        end;

        local buffer_readu8_ret4 = buffer.readu8(p64, p65 + 3);

        if buffer_readu8_ret4 < 128 then
            return buffer_readu8_ret - 128 + (buffer_readu8_ret2 - 128) * 128 + (buffer_readu8_ret3 - 128) * 16384 + buffer_readu8_ret4 * 2097152, p65 + 4;
        end;

        local buffer_readu8_ret5 = buffer.readu8(p64, p65 + 4);

        if buffer_readu8_ret5 < 128 then
            return buffer_readu8_ret - 128 + (buffer_readu8_ret2 - 128) * 128 + (buffer_readu8_ret3 - 128) * 16384 + (buffer_readu8_ret4 - 128) * 2097152 + buffer_readu8_ret5 * 268435456, p65 + 5;
        end;

        return readVarIntFallback(p64, p65, buffer_readu8_ret - 128 + (buffer_readu8_ret2 - 128) * 128 + (buffer_readu8_ret3 - 128) * 16384 + (buffer_readu8_ret4 - 128) * 2097152 + (buffer_readu8_ret5 - 128) * 268435456);
    end,

    write = writeVarIntUnsigned
};
u3.i8 = {
    read = function(p66: buffer, p67: number) -- Line: 290, Name: read
        return buffer.readi8(p66, p67), p67 + 1;
    end,

    write = function(p68: buffer, p69: number, p70: number) -- Line: 293, Name: write
        buffer.writei8(p68, p69, p70);

        return p69 + 1;
    end
};
u3.i16 = {
    read = function(p71: buffer, p72: number) -- Line: 300, Name: read
        return buffer.readi16(p71, p72), p72 + 2;
    end,

    write = function(p73: buffer, p74: number, p75: number) -- Line: 303, Name: write
        buffer.writei16(p73, p74, p75);

        return p74 + 2;
    end
};
u3.i32 = {
    read = function(p76: buffer, p77: number) -- Line: 310, Name: read
        return buffer.readi32(p76, p77), p77 + 4;
    end,

    write = function(p78: buffer, p79: number, p80: number) -- Line: 313, Name: write
        buffer.writei32(p78, p79, p80);

        return p79 + 4;
    end
};
u3.int = {
    read = function(p81: buffer, p82: number) -- Line: 320, Name: read
        -- upvalues: readVarIntFallback (copy)
        local buffer_readu8_ret = buffer.readu8(p81, p82);
        local v83 = buffer_readu8_ret % 2 == 1;

        if buffer_readu8_ret < 128 then
            local v84;

            if v83 then
                v84 = -(buffer_readu8_ret + 1) / 2;
            else
                v84 = buffer_readu8_ret / 2;
            end;

            return v84, p82 + 1;
        end;

        local buffer_readu8_ret2 = buffer.readu8(p81, p82 + 1);

        if buffer_readu8_ret2 < 128 then
            local v85 = buffer_readu8_ret - 128 + buffer_readu8_ret2 * 128;
            local v86;

            if v83 then
                v86 = -(v85 + 1) / 2;
            else
                v86 = v85 / 2;
            end;

            return v86, p82 + 2;
        end;

        local buffer_readu8_ret3 = buffer.readu8(p81, p82 + 2);

        if buffer_readu8_ret3 < 128 then
            local v87 = buffer_readu8_ret - 128 + (buffer_readu8_ret2 - 128) * 128 + buffer_readu8_ret3 * 16384;
            local v88;

            if v83 then
                v88 = -(v87 + 1) / 2;
            else
                v88 = v87 / 2;
            end;

            return v88, p82 + 3;
        end;

        local buffer_readu8_ret4 = buffer.readu8(p81, p82 + 3);

        if buffer_readu8_ret4 < 128 then
            local v89 = buffer_readu8_ret - 128 + (buffer_readu8_ret2 - 128) * 128 + (buffer_readu8_ret3 - 128) * 16384 + buffer_readu8_ret4 * 2097152;
            local v90;

            if v83 then
                v90 = -(v89 + 1) / 2;
            else
                v90 = v89 / 2;
            end;

            return v90, p82 + 4;
        end;

        local buffer_readu8_ret5 = buffer.readu8(p81, p82 + 4);

        if buffer_readu8_ret5 < 128 then
            local v91 = buffer_readu8_ret - 128 + (buffer_readu8_ret2 - 128) * 128 + (buffer_readu8_ret3 - 128) * 16384 + (buffer_readu8_ret4 - 128) * 2097152 + buffer_readu8_ret5 * 268435456;
            local v92;

            if v83 then
                v92 = -(v91 + 1) / 2;
            else
                v92 = v91 / 2;
            end;

            return v92, p82 + 5;
        end;

        local v93, v94 = readVarIntFallback(p81, p82, buffer_readu8_ret - 128 + (buffer_readu8_ret2 - 128) * 128 + (buffer_readu8_ret3 - 128) * 16384 + (buffer_readu8_ret4 - 128) * 2097152 + (buffer_readu8_ret5 - 128) * 268435456);
        local v95;

        if v83 then
            v95 = -(v93 + 1) / 2;
        else
            v95 = v93 / 2;
        end;

        return v95, v94;
    end,

    write = function(p96: buffer, p97: number, p98: number) -- Line: 362, Name: write
        -- upvalues: writeVarIntUnsigned (copy)
        local v99, v100;

        if p98 >= 0 then
            v99 = p98 % 64 * 2;
            v100 = p98 // 64;
        else
            local v101 = -p98;
            v99 = (v101 % 64 * 2 - 1) % 128;
            v100 = (v101 - 1) // 64;
        end;

        if v100 == 0 then
            buffer.writeu8(p96, p97, v99);

            return p97 + 1;
        end;

        buffer.writeu8(p96, p97, v99 + 128);

        return writeVarIntUnsigned(p96, p97 + 1, v100);
    end
};
u3.f32 = {
    read = function(p102: buffer, p103: number) -- Line: 386, Name: read
        return buffer.readf32(p102, p103), p103 + 4;
    end,

    write = function(p104: buffer, p105: number, p106: number) -- Line: 389, Name: write
        buffer.writef32(p104, p105, p106);

        return p105 + 4;
    end
};
u3.f64 = {
    read = function(p107: buffer, p108: number) -- Line: 396, Name: read
        return buffer.readf64(p107, p108), p108 + 8;
    end,

    write = function(p109: buffer, p110: number, p111: number) -- Line: 399, Name: write
        buffer.writef64(p109, p110, p111);

        return p110 + 8;
    end
};
u3.number = u3.f64;
u3.byte = {
    read = function(p112: buffer, p113: number) -- Line: 408, Name: read
        return buffer.readstring(p112, p113, 1), p113 + 1;
    end,

    write = function(p114: buffer, p115: number, p116: string) -- Line: 411, Name: write
        buffer.writestring(p114, p115, p116, 1);

        return p115 + 1;
    end
};

local function createStringType(u117: number, u118: function, u119: function, u120: number) -- Line: 417
    -- upvalues: u3 (copy)
    return {
        read = function(p121: buffer, p122: number) -- Line: 424, Name: read
            -- upvalues: u118 (copy), u120 (copy)
            local v123 = u118(p121, p122);

            return buffer.readstring(p121, p122 + u120, v123), p122 + u120 + v123;
        end,

        write = function(p124: buffer, p125: number, p126: string) -- Line: 428, Name: write
            -- upvalues: u117 (copy), u3 (ref), u119 (copy), u120 (copy)
            local string_len_ret = string.len(p126);

            if u117 < string_len_ret and not u3.TRIM_STRINGS then
                error("string exceeds bounds");
            end;

            local math_min_ret = math.min(string_len_ret, u117);
            u119(p124, p125, math_min_ret);
            buffer.writestring(p124, p125 + u120, p126, math_min_ret);

            return p125 + u120 + math_min_ret;
        end
    };
end;

u3.str8 = createStringType(255, buffer.readu8, buffer.writeu8, 1);
u3.str16 = createStringType(65535, buffer.readu16, buffer.writeu16, 2);
u3.str32 = createStringType(4294967295, buffer.readu32, buffer.writeu32, 4);
u3.string = u3.str32;

local function createBufferType(u127: number, u128: function, u129: function, u130: number) -- Line: 446
    return {
        read = function(p131: buffer, p132: number) -- Line: 453, Name: read
            -- upvalues: u128 (copy), u130 (copy)
            local v133 = u128(p131, p132);
            local buffer_create_ret = buffer.create(v133);
            buffer.copy(buffer_create_ret, 0, p131, p132 + u130, v133);

            return buffer_create_ret, p132 + u130 + v133;
        end,

        write = function(p134: buffer, p135: number, p136: buffer) -- Line: 459, Name: write
            -- upvalues: u127 (copy), u129 (copy), u130 (copy)
            local buffer_len_ret = buffer.len(p136);

            if u127 < buffer_len_ret then
                error("buffer exceeds bounds");
            end;

            u129(p134, p135, buffer_len_ret);
            buffer.copy(p134, p135 + u130, p136);

            return p135 + u130 + buffer_len_ret;
        end
    };
end;

u3.buffer8 = createBufferType(255, buffer.readu8, buffer.writeu8, 1);
u3.buffer16 = createBufferType(65535, buffer.readu16, buffer.writeu16, 2);
u3.buffer32 = createBufferType(4294967295, buffer.readu32, buffer.writeu32, 4);
u3.buffer = u3.buffer32;

local function Angle8(p137: number) -- Line: 478
    return math.floor(p137 % 6.283185307179586 * 255 / 6.265732014659643 + 0.5);
end;

local u138 = {};

for i = 0, 255 do
    u138[i] = i * 6.265732014659643 / 255;
    local _ = i;
end;

for i = 0, 315, 45 do
    local math_rad_ret = math.rad(i);
    u138[math.floor(math_rad_ret % 6.283185307179586 * 255 / 6.265732014659643 + 0.5)] = math_rad_ret;
    local _ = i;
end;

u3.Angle8 = {
    read = function(p139: buffer, p140: number) -- Line: 494, Name: read
        -- upvalues: u138 (copy)
        return u138[buffer.readu8(p139, p140)], p140 + 1;
    end,

    write = function(p141: buffer, p142: number, p143: number) -- Line: 497, Name: write
        local math_floor_ret = math.floor(p143 % 6.283185307179586 * 255 / 6.265732014659643 + 0.5);
        buffer.writeu8(p141, p142, math_floor_ret);

        return p142 + 1;
    end
};

if Axes then
    u3.Axes = {
        read = function(p144: buffer, p145: number) -- Line: 505, Name: read
            local buffer_readu8_ret = buffer.readu8(p144, p145);
            local bit32_btest_ret = bit32.btest(buffer_readu8_ret, 1);
            local bit32_btest_ret2 = bit32.btest(buffer_readu8_ret, 2);
            local bit32_btest_ret3 = bit32.btest(buffer_readu8_ret, 4);
            bit32.btest(buffer_readu8_ret, 8);
            bit32.btest(buffer_readu8_ret, 16);
            bit32.btest(buffer_readu8_ret, 32);
            bit32.btest(buffer_readu8_ret, 64);
            bit32.btest(buffer_readu8_ret, 128);
            local buffer_readu8_ret2 = buffer.readu8(p144, p145 + 1);
            local bit32_btest_ret4 = bit32.btest(buffer_readu8_ret2, 1);
            local bit32_btest_ret5 = bit32.btest(buffer_readu8_ret2, 2);
            local bit32_btest_ret6 = bit32.btest(buffer_readu8_ret2, 4);
            local bit32_btest_ret7 = bit32.btest(buffer_readu8_ret2, 8);
            local bit32_btest_ret8 = bit32.btest(buffer_readu8_ret2, 16);
            local bit32_btest_ret9 = bit32.btest(buffer_readu8_ret2, 32);
            bit32.btest(buffer_readu8_ret2, 64);
            bit32.btest(buffer_readu8_ret2, 128);

            if bit32_btest_ret then
                bit32_btest_ret = Enum.Axis.X;
            end;

            if bit32_btest_ret2 then
                bit32_btest_ret2 = Enum.Axis.Y;
            end;

            if bit32_btest_ret3 then
                bit32_btest_ret3 = Enum.Axis.Z;
            end;

            if bit32_btest_ret4 then
                bit32_btest_ret4 = Enum.NormalId.Back;
            end;

            if bit32_btest_ret5 then
                bit32_btest_ret5 = Enum.NormalId.Bottom;
            end;

            if bit32_btest_ret6 then
                bit32_btest_ret6 = Enum.NormalId.Front;
            end;

            if bit32_btest_ret7 then
                bit32_btest_ret7 = Enum.NormalId.Left;
            end;

            if bit32_btest_ret8 then
                bit32_btest_ret8 = Enum.NormalId.Right;
            end;

            if bit32_btest_ret9 then
                bit32_btest_ret9 = Enum.NormalId.Top;
            end;

            return Axes.new(bit32_btest_ret, bit32_btest_ret2, bit32_btest_ret3, bit32_btest_ret4, bit32_btest_ret5, bit32_btest_ret6, bit32_btest_ret7, bit32_btest_ret8, bit32_btest_ret9), p145 + 2;
        end,

        write = function(p146: buffer, p147: number, p148: userdata) -- Line: 521, Name: write
            local v149 = p148.X and 1 or 0;

            if p148.Y then
                v149 = v149 + 2;
            end;

            if p148.Z then
                v149 = v149 + 4;
            end;

            buffer.writeu8(p146, p147, v149);
            local _ = p147 + 1;
            local v150 = p147 + 1;
            local v151 = p148.Back and 1 or 0;

            if p148.Bottom then
                v151 = v151 + 2;
            end;

            if p148.Front then
                v151 = v151 + 4;
            end;

            if p148.Left then
                v151 = v151 + 8;
            end;

            if p148.Right then
                v151 = v151 + 16;
            end;

            if p148.Top then
                v151 = v151 + 32;
            end;

            buffer.writeu8(p146, v150, v151);
            local _ = v150 + 1;

            return p147 + 2;
        end
    };
end;

if BrickColor then
    u3.BrickColor = {
        read = function(p152: buffer, p153: number) -- Line: 531, Name: read
            return BrickColor.new((buffer.readu16(p152, p153))), p153 + 2;
        end,

        write = function(p154: buffer, p155: number, p156: userdata) -- Line: 534, Name: write
            buffer.writeu16(p154, p155, p156.Number);

            return p155 + 2;
        end
    };
end;

if CFrame then
    u3.CFrame = {
        read = function(p157: buffer, p158: number) -- Line: 543, Name: read
            return CFrame.new(buffer.readf32(p157, p158), buffer.readf32(p157, p158 + 4), buffer.readf32(p157, p158 + 8), buffer.readf32(p157, p158 + 12), buffer.readf32(p157, p158 + 16), buffer.readf32(p157, p158 + 20), buffer.readf32(p157, p158 + 24), buffer.readf32(p157, p158 + 28), buffer.readf32(p157, p158 + 32), buffer.readf32(p157, p158 + 36), buffer.readf32(p157, p158 + 40), (buffer.readf32(p157, p158 + 44))), p158 + 48;
        end,

        write = function(p159: buffer, p160: number, p161) -- Line: 560, Name: write
            local Components, v162, v163, v164, v165, v166, v167, v168, v169, v170, v171, v172 = p161:GetComponents();
            buffer.writef32(p159, p160, Components);
            buffer.writef32(p159, p160 + 4, v162);
            buffer.writef32(p159, p160 + 8, v163);
            buffer.writef32(p159, p160 + 12, v164);
            buffer.writef32(p159, p160 + 16, v165);
            buffer.writef32(p159, p160 + 20, v166);
            buffer.writef32(p159, p160 + 24, v167);
            buffer.writef32(p159, p160 + 28, v168);
            buffer.writef32(p159, p160 + 32, v169);
            buffer.writef32(p159, p160 + 36, v170);
            buffer.writef32(p159, p160 + 40, v171);
            buffer.writef32(p159, p160 + 44, v172);

            return p160 + 48;
        end
    };
    u3.CFrame28 = {
        read = function(p173: buffer, p174: number) -- Line: 579, Name: read
            local CFrame_fromAxisAngle = CFrame.fromAxisAngle;
            local buffer_readf32_ret = buffer.readf32(p173, p174 + 12);
            local buffer_readf32_ret2 = buffer.readf32(p173, p174 + 16);
            local buffer_readf32_ret3 = buffer.readf32(p173, p174 + 20);
            local v175 = CFrame_fromAxisAngle(Vector3.new(buffer_readf32_ret, buffer_readf32_ret2, buffer_readf32_ret3), (buffer.readf32(p173, p174 + 24)));
            local buffer_readf32_ret4 = buffer.readf32(p173, p174);
            local buffer_readf32_ret5 = buffer.readf32(p173, p174 + 4);
            local buffer_readf32_ret6 = buffer.readf32(p173, p174 + 8);

            return v175 + Vector3.new(buffer_readf32_ret4, buffer_readf32_ret5, buffer_readf32_ret6), p174 + 28;
        end,

        write = function(p176: buffer, p177: number, p178) -- Line: 590, Name: write
            local v179, v180 = p178:ToAxisAngle();
            buffer.writef32(p176, p177, p178.X);
            buffer.writef32(p176, p177 + 4, p178.Y);
            buffer.writef32(p176, p177 + 8, p178.Z);
            buffer.writef32(p176, p177 + 12, v179.X);
            buffer.writef32(p176, p177 + 16, v179.Y);
            buffer.writef32(p176, p177 + 20, v179.Z);
            buffer.writef32(p176, p177 + 24, v180);

            return p177 + 28;
        end
    };
    u3.CFrame15 = {
        read = function(p181: buffer, p182: number) -- Line: 604, Name: read
            -- upvalues: u138 (copy)
            local CFrame_Angles_ret = CFrame.Angles(u138[buffer.readu8(p181, p182 + 12)], u138[buffer.readu8(p181, p182 + 13)], u138[buffer.readu8(p181, p182 + 14)]);
            local buffer_readf32_ret = buffer.readf32(p181, p182);
            local buffer_readf32_ret2 = buffer.readf32(p181, p182 + 4);
            local buffer_readf32_ret3 = buffer.readf32(p181, p182 + 8);

            return CFrame_Angles_ret + Vector3.new(buffer_readf32_ret, buffer_readf32_ret2, buffer_readf32_ret3), p182 + 15;
        end,

        write = function(p183: buffer, p184: number, p185) -- Line: 612, Name: write
            local v186, v187, v188 = p185:ToOrientation();
            buffer.writef32(p183, p184, p185.X);
            buffer.writef32(p183, p184 + 4, p185.Y);
            buffer.writef32(p183, p184 + 8, p185.Z);
            local v189 = math.floor(v186 % 6.283185307179586 * 255 / 6.265732014659643 + 0.5) + math.floor(v187 % 6.283185307179586 * 255 / 6.265732014659643 + 0.5) * 256 + math.floor(v188 % 6.283185307179586 * 255 / 6.265732014659643 + 0.5) * 65536;
            buffer.writeu32(p183, p184 + 12, v189);

            return p184 + 15;
        end
    };
end;

if Color3 then
    u3.Color3 = {
        read = function(p190: buffer, p191: number) -- Line: 625, Name: read
            return Color3.fromRGB(buffer.readu8(p190, p191), buffer.readu8(p190, p191 + 1), (buffer.readu8(p190, p191 + 2))), p191 + 3;
        end,

        write = function(p192: buffer, p193: number, p194) -- Line: 629, Name: write
            local math_floor_ret = math.floor(p194.R * 255 + 0.5);
            local math_floor_ret2 = math.floor(p194.G * 255 + 0.5);
            local math_floor_ret3 = math.floor(p194.B * 255 + 0.5);
            buffer.writeu32(p192, p193, math_floor_ret + math_floor_ret2 * 256 + math_floor_ret3 * 65536);

            return p193 + 3;
        end
    };
end;

if ColorSequenceKeypoint then
    u3.ColorSequenceKeypoint = {
        read = function(p195: buffer, p196: number) -- Line: 641, Name: read
            return ColorSequenceKeypoint.new(buffer.readu8(p195, p196) / 255, Color3.fromRGB(buffer.readu8(p195, p196 + 1), buffer.readu8(p195, p196 + 2), (buffer.readu8(p195, p196 + 3)))), p196 + 4;
        end,

        write = function(p197: buffer, p198: number, p199: userdata) -- Line: 648, Name: write
            local Value = p199.Value;
            local math_floor_ret = math.floor(p199.Time * 255 + 0.5);
            local math_floor_ret2 = math.floor(Value.R * 255 + 0.5);
            local math_floor_ret3 = math.floor(Value.G * 255 + 0.5);
            local math_floor_ret4 = math.floor(Value.B * 255 + 0.5);
            buffer.writeu32(p197, p198, math_floor_ret + math_floor_ret2 * 256 + math_floor_ret3 * 65536 + math_floor_ret4 * 16777216);

            return p198 + 4;
        end
    };
end;

if ColorSequence then
    u3.ColorSequence = {
        read = function(p200: buffer, p201: number) -- Line: 662, Name: read
            -- upvalues: u3 (copy)
            local buffer_readu8_ret = buffer.readu8(p200, p201);
            local v202 = {};

            for i = 1, buffer_readu8_ret do
                local v203 = u3.ColorSequenceKeypoint.read(p200, p201 + 1 + (i - 1) * 4);
                table.insert(v202, v203);
                local _ = i;
            end;

            return ColorSequence.new(v202), p201 + 1 + buffer_readu8_ret * 4;
        end,

        write = function(p204: buffer, p205: number, p206: userdata) -- Line: 671, Name: write
            -- upvalues: u3 (copy)
            local v207 = #p206.Keypoints;
            buffer.writeu8(p204, p205, v207);

            for i, v in p206.Keypoints do
                u3.ColorSequenceKeypoint.write(p204, p205 + 1 + (i - 1) * 4, v);
            end;

            return p205 + 1 + v207 * 4;
        end
    };
end;

if DateTime then
    u3.DateTime = {
        read = function(p208: buffer, p209: number) -- Line: 684, Name: read
            return DateTime.fromUnixTimestampMillis((buffer.readf64(p208, p209))), p209 + 8;
        end,

        write = function(p210: buffer, p211: number, p212: userdata) -- Line: 687, Name: write
            buffer.writef64(p210, p211, p212.UnixTimestampMillis);

            return p211 + 8;
        end
    };
end;

if Enum then
    local u213 = {};
    u3.EnumItem = setmetatable({
        read = function(p214: buffer, p215: number) -- Line: 698, Name: read
            -- upvalues: u3 (copy)
            local v216, v217 = u3.str8.read(p214, p215);

            return u3.EnumItem(Enum[v216]).read(p214, v217);
        end,

        write = function(p218: buffer, p219: number, p220: userdata) -- Line: 702, Name: write
            -- upvalues: u3 (copy)
            local v221 = u3.str8.write(p218, p219, (tostring(p220.EnumType)));

            return u3.EnumItem(p220.EnumType).write(p218, v221, p220);
        end
    }, {
        __call = function(p222: any, p223: userdata) -- Line: 707, Name: __call
            -- upvalues: u213 (copy)
            if not u213[p223] then
                local EnumItems = p223:GetEnumItems();
                table.sort(EnumItems, function(p224: userdata, p225: userdata) -- Line: 711
                    return p224.Value < p225.Value;
                end);
                local table_create_ret = table.create(#EnumItems);
                local u226 = {};

                for i, v in EnumItems do
                    table_create_ret[i] = v;
                    u226[v] = i;
                end;

                local u227 = 4;
                local buffer_readu32 = buffer.readu32;
                local buffer_writeu32 = buffer.writeu32;
                local v228 = #EnumItems;

                if v228 <= 255 then
                    buffer_readu32 = buffer.readu8;
                    buffer_writeu32 = buffer.writeu8;
                    u227 = 1;
                elseif v228 <= 65535 then
                    buffer_readu32 = buffer.readu16;
                    buffer_writeu32 = buffer.writeu16;
                    u227 = 2;
                end;

                u213[p223] = table.freeze({
                    name = tostring(p223),

                    read = function(p229: buffer, p230: number) -- Line: 733, Name: read
                        -- upvalues: table_create_ret (copy), buffer_readu32 (ref), u227 (ref)
                        return table_create_ret[buffer_readu32(p229, p230)], p230 + u227;
                    end,

                    write = function(p231: buffer, p232: number, p233: userdata) -- Line: 736, Name: write
                        -- upvalues: buffer_writeu32 (ref), u226 (copy), u227 (ref)
                        buffer_writeu32(p231, p232, u226[p233]);

                        return p232 + u227;
                    end
                });
            end;

            return u213[p223];
        end
    });
end;

if Faces then
    u3.Faces = {
        read = function(p234: buffer, p235: number) -- Line: 750, Name: read
            local buffer_readu8_ret = buffer.readu8(p234, p235);
            local bit32_btest_ret = bit32.btest(buffer_readu8_ret, 1);
            local bit32_btest_ret2 = bit32.btest(buffer_readu8_ret, 2);
            local bit32_btest_ret3 = bit32.btest(buffer_readu8_ret, 4);
            local bit32_btest_ret4 = bit32.btest(buffer_readu8_ret, 8);
            local bit32_btest_ret5 = bit32.btest(buffer_readu8_ret, 16);
            local bit32_btest_ret6 = bit32.btest(buffer_readu8_ret, 32);
            bit32.btest(buffer_readu8_ret, 64);
            bit32.btest(buffer_readu8_ret, 128);

            if bit32_btest_ret then
                bit32_btest_ret = Enum.NormalId.Back;
            end;

            if bit32_btest_ret2 then
                bit32_btest_ret2 = Enum.NormalId.Bottom;
            end;

            if bit32_btest_ret3 then
                bit32_btest_ret3 = Enum.NormalId.Front;
            end;

            if bit32_btest_ret4 then
                bit32_btest_ret4 = Enum.NormalId.Left;
            end;

            if bit32_btest_ret5 then
                bit32_btest_ret5 = Enum.NormalId.Right;
            end;

            if bit32_btest_ret6 then
                bit32_btest_ret6 = Enum.NormalId.Top;
            end;

            return Faces.new(bit32_btest_ret, bit32_btest_ret2, bit32_btest_ret3, bit32_btest_ret4, bit32_btest_ret5, bit32_btest_ret6), p235 + 1;
        end,

        write = function(p236: buffer, p237: number, p238: userdata) -- Line: 762, Name: write
            local v239 = p238.Back and 1 or 0;

            if p238.Bottom then
                v239 = v239 + 2;
            end;

            if p238.Front then
                v239 = v239 + 4;
            end;

            if p238.Left then
                v239 = v239 + 8;
            end;

            if p238.Right then
                v239 = v239 + 16;
            end;

            if p238.Top then
                v239 = v239 + 32;
            end;

            buffer.writeu8(p236, p237, v239);
            local _ = p237 + 1;

            return p237 + 1;
        end
    };
end;

if FloatCurveKey then
    u3.FloatCurveKey = {
        read = function(p240: buffer, p241: number) -- Line: 771, Name: read
            -- upvalues: u3 (copy)
            local v242 = u3.EnumItem(Enum.KeyInterpolationMode).read(p240, p241);
            local buffer_readf32_ret = buffer.readf32(p240, p241 + 1);
            local buffer_readf32_ret2 = buffer.readf32(p240, p241 + 5);
            local FloatCurveKey_new_ret = FloatCurveKey.new(buffer_readf32_ret, buffer_readf32_ret2, v242);
            local v243 = p241 + 9;

            if v242 == Enum.KeyInterpolationMode.Cubic then
                local v244, v245 = u3.some(u3.f32).read(p240, v243);
                FloatCurveKey_new_ret.LeftTangent = v244;
                local v246;
                v246, v243 = u3.some(u3.f32).read(p240, v245);
                FloatCurveKey_new_ret.RightTangent = v246;
            end;

            return FloatCurveKey_new_ret, v243;
        end,

        write = function(p247: buffer, p248: number, p249: userdata) -- Line: 783, Name: write
            -- upvalues: u3 (copy)
            u3.EnumItem(Enum.KeyInterpolationMode).write(p247, p248, p249.Interpolation);
            buffer.writef32(p247, p248 + 1, p249.Time);
            buffer.writef32(p247, p248 + 5, p249.Value);
            local v250 = p248 + 9;

            if p249.Interpolation == Enum.KeyInterpolationMode.Cubic then
                local v251 = u3.some(u3.f32).write(p247, v250, p249.LeftTangent);
                v250 = u3.some(u3.f32).write(p247, v251, p249.RightTangent);
            end;

            return v250;
        end
    };
end;

if Font then
    local EnumItems = Enum.FontWeight:GetEnumItems();
    table.sort(EnumItems, function(p252: userdata, p253: userdata) -- Line: 800
        return p252.Value < p253.Value;
    end);
    local table_create_ret = table.create(#EnumItems);
    local u254 = {};

    for i, v in EnumItems do
        table_create_ret[i] = v;
        u254[v] = i;
    end;

    u3.Font = {
        read = function(p255: buffer, p256: number) -- Line: 813, Name: read
            -- upvalues: u3 (copy), table_create_ret (copy)
            local buffer_readu8_ret = buffer.readu8(p255, p256);
            local v257, v258 = u3.str8.read(p255, p256 + 1);
            local v259;

            if buffer_readu8_ret % 4 >= 2 then
                v259 = Enum.FontStyle.Italic;
            else
                v259 = Enum.FontStyle.Normal;
            end;

            local Font_new_ret = Font.new(v257, table_create_ret[buffer_readu8_ret // 4], v259);

            if buffer_readu8_ret % 2 == 1 then
                Font_new_ret.Bold = true;
            end;

            return Font_new_ret, v258;
        end,

        write = function(p260: buffer, p261: number, p262: userdata) -- Line: 826, Name: write
            -- upvalues: u254 (copy), u3 (copy)
            local v263 = p262.Bold and 1 or 0;

            if p262.Style == Enum.FontStyle.Italic then
                v263 = v263 + 2;
            end;

            buffer.writeu8(p260, p261, v263 + u254[p262.Weight] * 4);

            return u3.str8.write(p260, p261 + 1, p262.Family);
        end
    };
end;

if NumberRange then
    u3.NumberRange = {
        read = function(p264: buffer, p265: number) -- Line: 840, Name: read
            local buffer_readf64_ret = buffer.readf64(p264, p265);
            local buffer_readf64_ret2 = buffer.readf64(p264, p265 + 8);

            return NumberRange.new(buffer_readf64_ret, buffer_readf64_ret2), p265 + 16;
        end,

        write = function(p266: buffer, p267: number, p268) -- Line: 845, Name: write
            buffer.writef64(p266, p267, p268.Min);
            buffer.writef64(p266, p267 + 8, p268.Max);

            return p267 + 16;
        end
    };
end;

if NumberSequenceKeypoint then
    u3.NumberSequenceKeypoint = {
        read = function(p269: buffer, p270: number) -- Line: 855, Name: read
            return NumberSequenceKeypoint.new(buffer.readf32(p269, p270), buffer.readf32(p269, p270 + 4), (buffer.readf32(p269, p270 + 8))), p270 + 12;
        end,

        write = function(p271: buffer, p272: number, p273: userdata) -- Line: 863, Name: write
            buffer.writef32(p271, p272, p273.Time);
            buffer.writef32(p271, p272 + 4, p273.Value);
            buffer.writef32(p271, p272 + 8, p273.Envelope);

            return p272 + 12;
        end
    };
end;

if NumberSequence then
    u3.NumberSequence = {
        read = function(p274: buffer, p275: number) -- Line: 874, Name: read
            -- upvalues: u3 (copy)
            local buffer_readu8_ret = buffer.readu8(p274, p275);
            local v276 = {};

            for i = 1, buffer_readu8_ret do
                v276[i] = u3.NumberSequenceKeypoint.read(p274, p275 + 1 + (i - 1) * 12);
                local _ = i;
            end;

            return NumberSequence.new(v276), p275 + 1 + buffer_readu8_ret * 12;
        end,

        write = function(p277: buffer, p278: number, p279: userdata) -- Line: 882, Name: write
            -- upvalues: u3 (copy)
            local v280 = #p279.Keypoints;
            buffer.writeu8(p277, p278, v280);

            for i, v in p279.Keypoints do
                u3.NumberSequenceKeypoint.write(p277, p278 + 1 + (i - 1) * 12, v);
            end;

            return p278 + 1 + v280 * 12;
        end
    };
end;

if UDim then
    u3.UDim = {
        read = function(p281: buffer, p282: number) -- Line: 895, Name: read
            return UDim.new(buffer.readf32(p281, p282), (buffer.readf32(p281, p282 + 4))), p282 + 8;
        end,

        write = function(p283: buffer, p284: number, p285) -- Line: 898, Name: write
            buffer.writef32(p283, p284, p285.Scale);
            buffer.writef32(p283, p284 + 4, p285.Offset);

            return p284 + 8;
        end
    };
end;

if UDim2 then
    u3.UDim2 = {
        read = function(p286: buffer, p287: number) -- Line: 908, Name: read
            return UDim2.new(buffer.readf32(p286, p287), buffer.readf32(p286, p287 + 4), buffer.readf32(p286, p287 + 8), (buffer.readf32(p286, p287 + 12))), p287 + 16;
        end,

        write = function(p288: buffer, p289: number, p290) -- Line: 917, Name: write
            buffer.writef32(p288, p289, p290.X.Scale);
            buffer.writef32(p288, p289 + 4, p290.X.Offset);
            buffer.writef32(p288, p289 + 8, p290.Y.Scale);
            buffer.writef32(p288, p289 + 12, p290.Y.Offset);

            return p289 + 16;
        end
    };
end;

if Vector2 then
    u3.Vector2 = {
        read = function(p291: buffer, p292: number) -- Line: 929, Name: read
            return Vector2.new(buffer.readf32(p291, p292), (buffer.readf32(p291, p292 + 4))), p292 + 8;
        end,

        write = function(p293: buffer, p294: number, p295) -- Line: 932, Name: write
            buffer.writef32(p293, p294, p295.X);
            buffer.writef32(p293, p294 + 4, p295.Y);

            return p294 + 8;
        end
    };
end;

if Vector2int16 then
    u3.Vector2i16 = {
        read = function(p296: buffer, p297: number) -- Line: 942, Name: read
            return Vector2int16.new(buffer.readi16(p296, p297), (buffer.readi16(p296, p297 + 2))), p297 + 4;
        end,

        write = function(p298: buffer, p299: number, p300: userdata) -- Line: 945, Name: write
            buffer.writei16(p298, p299, p300.X);
            buffer.writei16(p298, p299 + 2, p300.Y);

            return p299 + 4;
        end
    };
    u3.Vector2int16 = u3.Vector2i16;
end;

if Vector3 then
    u3.Vector3 = {
        read = function(p301: buffer, p302: number) -- Line: 956, Name: read
            local buffer_readf32_ret = buffer.readf32(p301, p302);
            local buffer_readf32_ret2 = buffer.readf32(p301, p302 + 4);
            local buffer_readf32_ret3 = buffer.readf32(p301, p302 + 8);

            return Vector3.new(buffer_readf32_ret, buffer_readf32_ret2, buffer_readf32_ret3), p302 + 12;
        end,

        write = function(p303: buffer, p304: number, p305: vector) -- Line: 960, Name: write
            buffer.writef32(p303, p304, p305.X);
            buffer.writef32(p303, p304 + 4, p305.Y);
            buffer.writef32(p303, p304 + 8, p305.Z);

            return p304 + 12;
        end
    };
end;

if Vector3int16 then
    u3.Vector3i16 = {
        read = function(p306: buffer, p307: number) -- Line: 971, Name: read
            return Vector3int16.new(buffer.readi16(p306, p307), buffer.readi16(p306, p307 + 2), (buffer.readi16(p306, p307 + 4))), p307 + 6;
        end,

        write = function(p308: buffer, p309: number, p310: userdata) -- Line: 979, Name: write
            buffer.writei16(p308, p309, p310.X);
            buffer.writei16(p308, p309 + 2, p310.Y);
            buffer.writei16(p308, p309 + 4, p310.Z);

            return p309 + 6;
        end
    };
    u3.Vector3int16 = u3.Vector3i16;
end;

if Path2DControlPoint then
    local UDim2_new_ret = UDim2.new(0, 0, 0, 0);
    u3.Path2DControlPoint = {
        read = function(p311: buffer, p312: number) -- Line: 993, Name: read
            -- upvalues: u3 (copy), UDim2_new_ret (copy)
            local v313, v314 = u3.some(u3.UDim2).read(p311, p312);
            local v315, v316 = u3.some(u3.UDim2).read(p311, v314);
            local v317, v318 = u3.some(u3.UDim2).read(p311, v316);

            return Path2DControlPoint.new(v313 or UDim2_new_ret, v315 or UDim2_new_ret, v317 or UDim2_new_ret), v318;
        end,

        write = function(p319: buffer, p320: number, p321: userdata) -- Line: 999, Name: write
            -- upvalues: u3 (copy), UDim2_new_ret (copy)
            local write = u3.some(u3.UDim2).write;
            local v322;

            if p321.Position == UDim2_new_ret then
                v322 = nil;
            else
                v322 = p321.Position;
            end;

            local v323 = write(p319, p320, v322);
            local write2 = u3.some(u3.UDim2).write;
            local v324;

            if p321.LeftTangent == UDim2_new_ret then
                v324 = nil;
            else
                v324 = p321.LeftTangent;
            end;

            local v325 = write2(p319, v323, v324);
            local write3 = u3.some(u3.UDim2).write;
            local v326;

            if p321.RightTangent == UDim2_new_ret then
                v326 = nil;
            else
                v326 = p321.RightTangent;
            end;

            return write3(p319, v325, v326);
        end
    };
end;

if PathWaypoint then
    u3.PathWaypoint = {
        read = function(p327: buffer, p328: number) -- Line: 1009, Name: read
            -- upvalues: u3 (copy)
            local v329, v330 = u3.str8.read(p327, p328 + 13);

            return PathWaypoint.new(u3.Vector3.read(p327, p328 + 1), Enum.PathWaypointAction:FromValue((buffer.readu8(p327, p328))) or Enum.PathWaypointAction.Walk, v329), v330;
        end,

        write = function(p331: buffer, p332: number, p333: userdata) -- Line: 1018, Name: write
            -- upvalues: u3 (copy)
            buffer.writeu8(p331, p332, p333.Action.Value);

            return u3.str8.write(p331, u3.Vector3.write(p331, p332 + 1, p333.Position), p333.Label);
        end
    };
end;

if PhysicalProperties then
    u3.PhysicalProperties = {
        read = function(p334: buffer, p335: number) -- Line: 1027, Name: read
            return PhysicalProperties.new(buffer.readf32(p334, p335), buffer.readf32(p334, p335 + 4), buffer.readf32(p334, p335 + 8), buffer.readf32(p334, p335 + 12), (buffer.readf32(p334, p335 + 16))), p335 + 20;
        end,

        write = function(p336: buffer, p337: number, p338: userdata) -- Line: 1037, Name: write
            buffer.writef32(p336, p337, p338.Density);
            buffer.writef32(p336, p337 + 4, p338.Friction);
            buffer.writef32(p336, p337 + 8, p338.Elasticity);
            buffer.writef32(p336, p337 + 12, p338.FrictionWeight);
            buffer.writef32(p336, p337 + 16, p338.ElasticityWeight);

            return p337 + 20;
        end
    };
end;

if Ray then
    u3.Ray = {
        read = function(p339: buffer, p340: number) -- Line: 1050, Name: read
            -- upvalues: u3 (copy)
            local v341 = u3.Vector3.read(p339, p340);
            local v342 = u3.Vector3.read(p339, p340 + 12);

            return Ray.new(v341, v342), p340 + 24;
        end,

        write = function(p343: buffer, p344: number, p345) -- Line: 1055, Name: write
            -- upvalues: u3 (copy)
            return u3.Vector3.write(p343, u3.Vector3.write(p343, p344, p345.Origin), p345.Direction);
        end
    };
end;

if Rect then
    u3.Rect = {
        read = function(p346: buffer, p347: number) -- Line: 1063, Name: read
            -- upvalues: u3 (copy)
            local v348 = u3.Vector2.read(p346, p347);
            local v349 = u3.Vector2.read(p346, p347 + 8);

            return Rect.new(v348, v349), p347 + 16;
        end,

        write = function(p350: buffer, p351: number, p352) -- Line: 1068, Name: write
            -- upvalues: u3 (copy)
            return u3.Vector2.write(p350, u3.Vector2.write(p350, p351, p352.Min), p352.Max);
        end
    };
end;

if Region3 then
    u3.Region3 = {
        read = function(p353: buffer, p354: number) -- Line: 1076, Name: read
            -- upvalues: u3 (copy)
            local v355 = u3.Vector3.read(p353, p354);
            local v356 = u3.Vector3.read(p353, p354 + 12);

            return Region3.new(v355, v356), p354 + 24;
        end,

        write = function(p357: buffer, p358: number, p359: userdata) -- Line: 1081, Name: write
            -- upvalues: u3 (copy)
            local v360 = p359.Size / 2;
            local Position = p359.CFrame.Position;

            return u3.Vector3.write(p357, u3.Vector3.write(p357, p358, Position - v360), Position + v360);
        end
    };
end;

if Region3int16 then
    u3.Region3int16 = {
        read = function(p361: buffer, p362: number) -- Line: 1091, Name: read
            -- upvalues: u3 (copy)
            local v363 = u3.Vector3i16.read(p361, p362);
            local v364 = u3.Vector3i16.read(p361, p362 + 6);

            return Region3int16.new(v363, v364), p362 + 12;
        end,

        write = function(p365: buffer, p366: number, p367: userdata) -- Line: 1096, Name: write
            -- upvalues: u3 (copy)
            return u3.Vector3i16.write(p365, u3.Vector3i16.write(p365, p366, p367.Min), p367.Max);
        end
    };
end;

if RotationCurveKey then
    u3.RotationCurveKey = {
        read = function(p368: buffer, p369: number) -- Line: 1104, Name: read
            -- upvalues: u3 (copy)
            local v370 = u3.EnumItem(Enum.KeyInterpolationMode).read(p368, p369);
            local buffer_readf32_ret = buffer.readf32(p368, p369 + 1);
            local v371 = u3.CFrame.read(p368, p369 + 5);
            local RotationCurveKey_new_ret = RotationCurveKey.new(buffer_readf32_ret, v371, v370);
            local v372 = p369 + 53;

            if v370 == Enum.KeyInterpolationMode.Cubic then
                local v373, v374 = u3.some(u3.f32).read(p368, v372);
                RotationCurveKey_new_ret.LeftTangent = v373;
                local v375;
                v375, v372 = u3.some(u3.f32).read(p368, v374);
                RotationCurveKey_new_ret.RightTangent = v375;
            end;

            return RotationCurveKey_new_ret, v372;
        end,

        write = function(p376: buffer, p377: number, p378: userdata) -- Line: 1116, Name: write
            -- upvalues: u3 (copy)
            u3.EnumItem(Enum.KeyInterpolationMode).write(p376, p377, p378.Interpolation);
            buffer.writef32(p376, p377 + 1, p378.Time);
            local v379 = u3.CFrame.write(p376, p377 + 5, p378.Value);

            if p378.Interpolation ~= Enum.KeyInterpolationMode.Cubic then
                return v379;
            end;

            local v380 = u3.some(u3.f32).write(p376, v379, p378.LeftTangent);

            return u3.some(u3.f32).write(p376, v380, p378.RightTangent);
        end
    };
end;

if TweenInfo then
    local u381 = u3.EnumItem(Enum.EasingDirection);
    local u382 = u3.EnumItem(Enum.EasingStyle);
    u3.TweenInfo = {
        read = function(p383: buffer, p384: number) -- Line: 1134, Name: read
            -- upvalues: u382 (copy), u381 (copy)
            return TweenInfo.new(buffer.readf32(p383, p384), u382.read(p383, p384 + 11), u381.read(p383, p384 + 12), buffer.readi16(p383, p384 + 8), buffer.readu8(p383, p384 + 10) == 255, (buffer.readf32(p383, p384 + 4))), p384 + 13;
        end,

        write = function(p385: buffer, p386: number, p387: userdata) -- Line: 1145, Name: write
            -- upvalues: u381 (copy), u382 (copy)
            buffer.writef32(p385, p386, p387.Time);
            buffer.writef32(p385, p386 + 4, p387.DelayTime);
            buffer.writei16(p385, p386 + 8, p387.RepeatCount);
            buffer.writeu8(p385, p386 + 10, p387.Reverses and 255 or 0);

            return u381.write(p385, u382.write(p385, p386 + 11, p387.EasingStyle), p387.EasingDirection);
        end
    };
end;

local u388 = { u3.EnumItem };
local u389 = {};
u3.table = {
    read = function(p390: buffer, p391: number) -- Line: 1159, Name: read
        -- upvalues: u388 (copy)
        local buffer_readu32_ret = buffer.readu32(p390, p391);
        local table_create_ret = table.create(buffer_readu32_ret);
        local v392 = p391 + 4;

        for i = 1, buffer_readu32_ret do
            local v393 = u388[buffer.readu8(p390, v392)];
            local v394 = u388[buffer.readu8(p390, v392 + 1)];
            local v395, v396 = v393.read(p390, v392 + 2);
            local v397;
            v397, v392 = v394.read(p390, v396);
            table_create_ret[v395] = v397;
            local _ = i;
        end;

        return table_create_ret, v392;
    end,

    write = function(p398: buffer, p399: number, p400: table) -- Line: 1173, Name: write
        -- upvalues: u3 (copy), u389 (copy)
        local v401 = p399 + 4;
        local v402 = 0;

        for i, v in p400 do
            local v403 = typeof(i);
            local v404 = u3[v403];

            if not v404 then
                error((`unsupported type "{v403}" for key "{i}"`));
            end;

            local v405 = typeof(v);
            local v406 = u3[v405];

            if not v406 then
                error((`unsupported type "{v405}" for value "{tostring(v)}" of key "{i}"`));
            end;

            buffer.writeu16(p398, v401, u389[v404] + u389[v406] * 256);
            local v407 = v404.write(p398, v401 + 2, i);
            v401 = v406.write(p398, v407, v);
            v402 = v402 + 1;
        end;

        buffer.writeu32(p398, p399, v402);

        return v401;
    end
};

for i, v in next, u3 do
    local v408;

    if type(v) == "table" and type(v.read) == "function" then
        v408 = type(v.write) == "function";
    else
        v408 = false;
    end;

    if v408 then
        if not v.name then
            v.name = i;
        end;

        if not table.isfrozen(v) then
            table.freeze(v);
        end;

        if not table.find(u388, v) then
            table.insert(u388, v);
        end;
    end;
end;

table.sort(u388, function(p409, p410) -- Line: 1212
    return p409.name < p410.name;
end);

for i, v in u388 do
    u389[v] = i;
end;

local function serializeUnsafe(p411: table, p412: table, p413: buffer, p414: number) -- Line: 1220
    local keys = p411.keys;
    local writes = p411.writes;

    for i = 1, p411.count do
        p414 = writes[i](p413, p414, p412[keys[i]]);
        local _ = i;
    end;

    return p414;
end;

local function serializeListUnsafe(p415: table, p416: table, p417: buffer, p418: number) -- Line: 1231
    if #p416 > p415.maxItems then
        error((`List length exceeds bounds of {p415.maxItems}, got {#p416}`));
    end;

    p415.writeLen(p417, p418, #p416);
    local v419 = p418 + p415.sizeLen;
    local v420 = p415.writes[1];

    for _, v in p416 do
        v419 = v420(p417, v419, v);
    end;

    return v419;
end;

local function serializeMapUnsafe(p421: table, p422: table, p423: buffer, p424: number) -- Line: 1250
    local write = p421.fields[1].key.write;
    local v425 = p421.writes[1];
    local writeLen = p421.writeLen;
    local v426 = p424 + p421.sizeLen;
    local v427 = 0;

    for i, v in p422 do
        v426 = v425(p423, write(p423, v426, i), v);
        v427 = v427 + 1;
    end;

    if p421.maxItems < v427 then
        error((`Map length exceeds bounds of {p421.maxItems}, got {v427}`));
    end;

    writeLen(p423, p424, v427);

    return v426;
end;

local function deserialize(p428: table, p429: buffer, p430: number, p431: boolean?) -- Line: 1274
    local v432 = {};
    local keys = p428.keys;
    local reads = p428.reads;
    local count = p428.count;

    if p431 then
        for i = 1, count do
            local v433, v434, v435 = pcall(reads[i], p429, p430, p431);
            local v436;

            if v433 then
                v432[keys[i]] = v434;
                p430 = v435;
                v436 = i;
            else
                v436 = i;
            end;
        end;
    else
        for i = 1, count do
            local v437 = keys[i];
            local v438;
            v438, p430 = reads[i](p429, p430);
            v432[v437] = v438;
            local _ = i;
        end;
    end;

    return v432, p430;
end;

local function deserializeList(p439: table, p440: buffer, p441: number, p442: boolean?) -- Line: 1296
    local readLen = p439.readLen;
    local read = p439.fields[1].read;
    local v443 = nil;
    local v444, v445;

    if p442 then
        local success, result = pcall(readLen, p440, p441);

        if not success then
            return v443, p441;
        end;

        v444 = table.create(result);
        v445 = p441 + p439.sizeLen;

        for i = 1, result do
            local v446, v447, v448 = pcall(read, p440, v445, p442);

            if not v446 then
                break;
            end;

            v444[i] = v447;
            v445 = v448;
            local _ = i;
        end;
    else
        local v449 = readLen(p440, p441);
        v445 = p441 + p439.sizeLen;
        v444 = table.create(v449);

        for i = 1, v449 do
            local v450;
            v450, v445 = read(p440, v445);
            v444[i] = v450;
            local _ = i;
        end;
    end;

    return v444, v445;
end;

local function deserializeMap(p451: table, p452: buffer, p453: number, p454: boolean?) -- Line: 1333
    local readLen = p451.readLen;
    local read = p451.fields[1].key.read;
    local v455 = p451.reads[1];
    local v456 = nil;
    local v457, v458;

    if p454 then
        local success, result = pcall(readLen, p452, p453);

        if not success then
            return v456, p453;
        end;

        v457 = table.create(result);
        v458 = p453 + p451.sizeLen;

        for i = 1, result do
            local v459, v460, v461 = pcall(read, p452, v458, p454);

            if not v459 then
                break;
            end;

            local v462, v463, v464 = pcall(v455, p452, v461, p454);

            if not v462 then
                break;
            end;

            v457[v460] = v463;
            v458 = v464;
            local _ = i;
        end;
    else
        local v465 = readLen(p452, p453);
        v458 = p453 + p451.sizeLen;
        v457 = table.create(v465);

        for i = 1, v465 do
            local v466, v467 = read(p452, v458);
            local v468;
            v468, v458 = v455(p452, v467);
            v457[v466] = v468;
            local _ = i;
        end;
    end;

    return v457, v458;
end;

function u3.ser(p469: table, p470: any, p471: buffer?, p472: number?, p473: number?) -- Line: 1381
    -- upvalues: u3 (copy)
    local v474 = p471 or u3.BUFFER;
    local v475 = p472 or 0;
    local success, result = pcall(p469.write, v474, v475, p470);

    if not success then
        if p469.isList or (p469.isMap or p469.name ~= "Schema") then
            return nil, result;
        end;

        for _, v in p469.fields do
            local v476 = p470[v.key];

            if v476 == nil then
                return nil, `Missing field "{v.key}"`;
            end;

            local v477;
            v477, v475 = pcall(v.write, v474, v475, v476);

            if not v477 then
                local key = v.key;
                local v478;

                if type(key) == "table" and type(key.read) == "function" then
                    v478 = type(key.write) == "function";
                else
                    v478 = false;
                end;

                local v479;

                if v478 then
                    v479 = v.key.name;
                else
                    v479 = v.key;
                end;

                if not v478 then
                    return nil, `Failed to serialize field '["{v479}"] = Z.{v.type}': {v475}`;
                end;

                if v479 == "Schema" then
                    return nil, v475;
                end;

                return nil, `Failed to serialize field '[Z.{v479}] = Z.{v.type}': {v475}`;
            end;
        end;

        return nil, result;
    end;

    if p471 then
        return result, nil;
    end;

    if not p473 then
        local buffer_create_ret = buffer.create(result);
        buffer.copy(buffer_create_ret, 0, u3.BUFFER, 0, result);

        return buffer_create_ret, nil;
    end;

    local math_min_ret = math.min(result, p473);
    local buffer_create_ret = buffer.create(math_min_ret);
    buffer.copy(buffer_create_ret, 0, u3.BUFFER, 0, math_min_ret);

    return buffer_create_ret, nil;
end;

function u3.des(p480: table, p481: buffer, p482: number?, p483: boolean?) -- Line: 1438
    return p480.read(p481, p482 or 0, p483);
end;

function u3.migrate(p484: table, p485: table, p486: buffer, p487: function?) -- Line: 1443
    -- upvalues: u3 (copy)
    local v488, v489 = u3.des(p484, p486, 0, true);

    if v489 ~= buffer.len(p486) then
        return nil, `Incomplete data: {v489} bytes read, {buffer.len(p486)} bytes expected`;
    end;

    local ser = u3.ser;

    if p487 then
        v488 = p487(v488);
    end;

    return ser(p485, v488);
end;

local function sortByKey(p490: table, p491: table) -- Line: 1452
    return p490.key < p491.key;
end;

function u3.schema(p492: table, p493: number?) -- Line: 1457
    -- upvalues: sortByKey (copy), deserializeList (copy), deserializeMap (copy), deserialize (copy), serializeListUnsafe (copy), serializeMapUnsafe (copy), serializeUnsafe (copy)
    local v494 = {};
    local v495 = #p492 == 1;
    local v496 = next(p492);
    local v497;

    if type(v496) == "table" and type(v496.read) == "function" then
        v497 = type(v496.write) == "function";
    else
        v497 = false;
    end;

    local v498 = nil;
    local v499 = nil;
    local v500;

    if v495 or v497 then
        v500 = 2 ^ (p493 or 32) - 1;

        if p493 == 8 then
            v498 = buffer.readu8;
            v499 = buffer.writeu8;
        elseif p493 == 16 then
            v498 = buffer.readu16;
            v499 = buffer.writeu16;
        elseif p493 == 32 or p493 == nil then
            v498 = buffer.readu32;
            v499 = buffer.writeu32;
        else
            error((`Expected 8, 16, or 32 for parameter "bits", got {p493}`));
        end;
    else
        v500 = nil;
    end;

    for i, v in next, p492 do
        if v495 and i ~= 1 then
            error((`Expected \{ Z.{p492[1]} } for list schema, got field "{i}"`));
        elseif v497 then
            if i ~= v496 then
                error((`Expected \{ [Z.{i.name}] = Z.{v.name} } for map schema, got field "{i}"`));
            end;
        elseif type(i) ~= "string" and type(i) ~= "number" then
            error((`Expected "string" or "number" for field "{tostring(i)}", got "{typeof(i)}"`));
        end;

        local v501;

        if type(v) == "table" and type(v.read) == "function" then
            v501 = type(v.write) == "function";
        else
            v501 = false;
        end;

        if not v501 then
            error((`Expected "ZType" for field "{tostring(i)}", got incompatible "{typeof(i)}"`));
        end;

        table.insert(v494, {
            key = i,
            read = v.read,
            write = v.write,
            type = v.name
        });
    end;

    if #v494 == 0 then
        error("Empty schema");
    end;

    table.sort(v494, sortByKey);
    local table_create_ret = table.create(#v494);
    local table_create_ret2 = table.create(#v494);
    local table_create_ret3 = table.create(#v494);

    for i, v in v494 do
        table_create_ret[i] = v.key;
        table_create_ret2[i] = v.read;
        table_create_ret3[i] = v.write;
    end;

    local u502;

    if v495 then
        u502 = deserializeList;
    elseif v497 then
        u502 = deserializeMap;
    else
        u502 = deserialize;
    end;

    local u503;

    if v495 then
        u503 = serializeListUnsafe;
    elseif v497 then
        u503 = serializeMapUnsafe;
    else
        u503 = serializeUnsafe;
    end;

    local u504 = nil;
    u504 = table.freeze({
        name = "Schema",
        count = #v494,
        fields = v494,
        keys = table_create_ret,
        reads = table_create_ret2,
        writes = table_create_ret3,

        read = function(p505: buffer, p506: number, p507: boolean?) -- Line: 1529, Name: read
            -- upvalues: u502 (copy), u504 (ref)
            return u502(u504, p505, p506, p507);
        end,

        write = function(p508: buffer, p509: number, p510: any) -- Line: 1532, Name: write
            -- upvalues: u503 (copy), u504 (ref)
            if type(p510) ~= "buffer" then
                return u503(u504, p510, p508, p509);
            end;

            buffer.copy(p508, p509, p510);

            return p509 + buffer.len(p510);
        end,

        isList = v495,
        isMap = v497,
        maxItems = v500,
        readLen = v498,
        writeLen = v499,
        sizeLen = math.ceil((p493 or 32) / 8)
    });

    return u504;
end;

function u3.schema8(p511: table) -- Line: 1553
    -- upvalues: u3 (copy)
    return u3.schema(p511, 8);
end;

function u3.schema16(p512: table) -- Line: 1558
    -- upvalues: u3 (copy)
    return u3.schema(p512, 16);
end;

function u3.schema32(p513: table) -- Line: 1563
    -- upvalues: u3 (copy)
    return u3.schema(p513, 32);
end;

return u3;