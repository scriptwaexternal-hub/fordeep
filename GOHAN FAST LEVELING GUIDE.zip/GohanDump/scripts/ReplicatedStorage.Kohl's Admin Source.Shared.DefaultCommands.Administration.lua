-- Decompiled with Potassium's decompiler.

return {
    {
        name = "announce",
        description = "Shows a message to everyone in the game, saves and shows to new users until it has been cleared.",
        args = { {
                type = "string",
                name = "Message",
                description = "The message to send."
            } },

        env = function(u1) -- Line: 14, Name: env
            task.spawn(u1.Util.Retry, function() -- Line: 15
                -- upvalues: u1 (copy)
                u1.Service.Messaging:SubscribeAsync("KA_Announcement", function(p2) -- Line: 16
                    -- upvalues: u1 (ref)
                    if type(p2.Data) == "string" then
                        p2.Data = u1.Service.Http:JSONDecode(p2.Data);
                    end;

                    if type(p2.Data) ~= "table" then
                        u1.Data.savedSettings.announcement = false;

                        return;
                    end;

                    local v3, v4, v5 = unpack(p2.Data);
                    u1.Data.savedSettings.announcement = p2.Data;
                    u1.Remote.Announce:FireAll({
                        From = v4,
                        Text = v3,
                        Duration = v5 or 0
                    });
                end);
            end, (1 / 0));
        end,

        run = function(u6, p7) -- Line: 36, Name: run
            if u6._K.Data.SEPARATE_DATASTORE or u6.global then
                return "Announcements are disabled in private servers.";
            end;

            local u8 = { p7, u6.from };
            u6._K.Data.savedSettings.announcement = u8;
            u6._K.Data.Sync.settings.announcement = u8;
            task.spawn(u6._K.Util.Retry, function() -- Line: 44
                -- upvalues: u6 (copy), u8 (copy)
                u6._K.Service.Messaging:PublishAsync("KA_Announcement", u8);
            end, (1 / 0));
        end
    },
    {
        name = "unannounce",
        description = "Removes the pinned announcement.",
        aliases = { "clearannounce" },
        args = {},

        run = function(p9) -- Line: 56, Name: run
            if p9._K.Data.SEPARATE_DATASTORE then
                return "Announcements are disabled in private servers.";
            end;

            p9._K.Data.savedSettings.announcement = false;
            p9._K.Data.Sync.settings.announcement = p9._K.Data.REMOVE;
            p9._K.Service.Messaging:PublishAsync("KA_Announcement", nil);
        end
    },
    {
        name = "role",
        description = "Assigns a role(s) to one or more user(s).",
        aliases = { "rank" },
        args = { {
                type = "userIds",
                name = "Users(s)",
                description = "The user(s) to assign roles."
            }, {
                type = "roles",
                name = "Roles(s)",
                description = "The roles(s) to assign."
            }, {
                type = "boolean",
                name = "Temporary",
                description = "Assigns the role(s) only for the current server.",
                optional = true,
                permissions = {
                    saveRoles = true
                }
            } },

        run = function(u10, u11, u12, p13) -- Line: 91, Name: run
            local v14 = not p13 and u10._K.Auth.hasPermission(u10.from, "saveRoles") and true or false;

            for _, v in u11 do
                local v15 = v;
                local v16 = {};

                for _, v2 in u12 do
                    if u10._K.Auth.userRoleAdd(v15, v2, v14) then
                        local v17 = u10._K.Data.roles[v2];
                        local v18 = `<b><font color="{v17.color}">{v17.name}</font></b>`;
                        table.insert(v16, v18);
                    end;
                end;

                local PlayerByUserId = u10._K.Service.Players:GetPlayerByUserId(v15);

                if PlayerByUserId and #v16 > 0 then
                    local CommandPrefix = u10._K.getCommandPrefix(PlayerByUserId.UserId);
                    u10._K.Remote.Notify:Fire(PlayerByUserId, {
                        Text = `Gave you the {table.concat(v16, ", ")} role{#v16 > 1 and "s" or ""}!\nSay <b>{CommandPrefix}cmds</b> or <b>{CommandPrefix}info</b> for details.`,
                        From = u10.from
                    });
                end;
            end;

            task.spawn(function() -- Line: 115
                -- upvalues: u12 (copy), u10 (copy), u11 (copy)
                local v19 = {};

                for _, v in u12 do
                    local v20 = u10._K.Data.roles[v];
                    local v21 = `<b><font color="{v20.color}">{v20.name}</font></b>`;
                    table.insert(v19, v21);
                end;

                local v22 = {};

                for _, v in u11 do
                    local DisplayName = u10._K.Util.getUserInfo(v).DisplayName;
                    table.insert(v22, DisplayName);
                end;

                u10._K.Remote.Notify:Fire(u10.fromPlayer, {
                    From = "_K",
                    Text = `<b>Gave Roles:</b> {table.concat(v19, ", ")}\n<b>To:</b> <i>{table.concat(v22, ", ")}</i>`
                });
            end);
        end
    },
    {
        name = "temprole",
        description = "Assigns a temporary role(s) to one or more user(s).",
        aliases = { "temprank" },
        args = { {
                type = "userIds",
                name = "Users(s)",
                description = "The user(s) to assign roles."
            }, {
                type = "roles",
                name = "Roles(s)",
                description = "The roles(s) to assign."
            } },

        run = function(u23, u24, u25) -- Line: 154, Name: run
            for _, v in u24 do
                local v26 = v;
                local v27 = {};

                for _, v2 in u25 do
                    if u23._K.Auth.userRoleAdd(v26, v2) then
                        local v28 = u23._K.Data.roles[v2];
                        local v29 = `<b><font color="{v28.color}">{v28.name}</font></b>`;
                        table.insert(v27, v29);
                    end;
                end;

                local PlayerByUserId = u23._K.Service.Players:GetPlayerByUserId(v26);

                if PlayerByUserId and #v27 > 0 then
                    local CommandPrefix = u23._K.getCommandPrefix(PlayerByUserId.UserId);
                    u23._K.Remote.Notify:Fire(PlayerByUserId, {
                        Text = `Gave you the {table.concat(v27, ", ")} role{#v27 > 1 and "s" or ""}!\nSay <b>{CommandPrefix}cmds</b> or <b>{CommandPrefix}info</b> for details.`,
                        From = u23.from
                    });
                end;
            end;

            task.spawn(function() -- Line: 174
                -- upvalues: u25 (copy), u23 (copy), u24 (copy)
                local v30 = {};

                for _, v in u25 do
                    local v31 = u23._K.Data.roles[v];
                    local v32 = `<b><font color="{v31.color}">{v31.name}</font></b>`;
                    table.insert(v30, v32);
                end;

                local v33 = {};

                for _, v in u24 do
                    local DisplayName = u23._K.Util.getUserInfo(v).DisplayName;
                    table.insert(v33, DisplayName);
                end;

                u23._K.Remote.Notify:Fire(u23.fromPlayer, {
                    From = "_K",
                    Text = `<b>Gave Roles:</b> {table.concat(v30, ", ")}\n<b>To:</b> <i>{table.concat(v33, ", ")}</i>`
                });
            end);
        end
    },
    {
        name = "unrole",
        description = "Removes one or more role(s) from one or more member(s).",
        aliases = { "removerole", "unrank", "removerank" },
        args = { {
                type = "members",
                name = "Member(s)",
                description = "The member(s) to remove roles from.",
                lowerRank = true
            }, {
                type = "roles",
                name = "Roles(s)",
                description = "The roles(s) to remove."
            } },

        run = function(p34, p35, p36) -- Line: 214, Name: run
            local v37 = {};

            for _, v in p35 do
                local v38 = p34._K.Data.members[tostring(v)];
                local v39 = v;

                for _, v2 in p36 do
                    if p34._K.Auth.userRoleRemove(v39, v2) then
                        local v40;

                        if v38 then
                            v40 = v38.name or v39;
                        else
                            v40 = v39;
                        end;

                        table.insert(v37, v40);
                    end;
                end;
            end;

            if #v37 == 0 then
                return;
            end;

            local v41 = {};

            for _, v in p36 do
                local v42 = p34._K.Data.roles[v];
                local v43 = `<b><font color="{v42.color}">{v42.name}</font></b>`;
                table.insert(v41, v43);
            end;

            p34._K.Remote.Notify:Fire(p34.fromPlayer, {
                Text = `<b>Removed Roles:</b> {table.concat(v41, ", ")}\n<b>From:</b> <i>{table.concat(v37, ", ")}</i>`
            });
        end
    },
    {
        name = "removemember",
        description = "Removes all roles and permissions from one or more member(s).",
        aliases = { "removepermissions", "removeroles" },
        args = { {
                type = "members",
                name = "Members(s)",
                description = "The member(s) to remove all roles and permissions from.",
                lowerRank = true,
                ignoreSelf = true
            } },

        run = function(p44, p45) -- Line: 256, Name: run
            local v46 = {};

            for _, v in p45 do
                local v47 = tostring(v);
                local v48 = p44._K.Data.members[v47];

                if v48 then
                    p44._K.Data.members[v47] = nil;
                    p44._K.Data.Sync.members[v47] = p44._K.Data.REMOVE;
                    p44._K.Remote.Member:FireAll(v47);

                    if v48 then
                        v47 = v48.name or v47;
                    end;

                    table.insert(v46, v47);
                end;
            end;

            if #v46 == 0 then
                return;
            end;

            p44._K.Remote.Notify:Fire(p44.fromPlayer, {
                Text = `<b>Removed member{#v46 > 1 and "s" or ""}:</b> <i>{table.concat(v46, ", ")}</i>`
            });
        end
    },
    {
        name = "gear",
        description = "Gives one or more player(s) a gear.",
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) to give the gear."
            }, {
                type = "integer",
                name = "AssetId",
                description = "The assetId of the gear."
            } },

        run = function(p49, p50, p51) -- Line: 297, Name: run
            local v52 = p49._K.Service.Insert:LoadAsset(p51);

            for _, child in v52:GetChildren() do
                if child:IsA("BackpackItem") then
                    local v53 = child:Clone();

                    for _, v in p50 do
                        v53:Clone().Parent = v:FindFirstChild("Backpack") or v.Character;
                    end;
                end;
            end;

            v52:Destroy();
        end
    },
    {
        name = "insert",
        description = "Inserts a model at the player\'s position.",
        aliases = { "ins" },
        args = { {
                type = "integer",
                name = "AssetId",
                description = "The assetId of the model."
            } },

        env = function(p54) -- Line: 322, Name: env
            return {
                blocked = { 59524079, 59524162, 59524102, 59524044, 59524124, 59524006 }
            };
        end,

        run = function(u55, u56) -- Line: 327, Name: run
            if table.find(u55.env.blocked, u56) then
                return "Model has been blocked.";
            end;

            local success, result = pcall(function() -- Line: 331
                -- upvalues: u55 (copy), u56 (copy)
                return u55._K.Service.Insert:LoadAsset(u56);
            end);

            if not success then
                if string.find(result, "authorized") then
                    return `{result} It must be added to the Game Creator's inventory!`;
                end;

                return result;
            end;

            local packageRef = result:FindFirstChild("packageRef", true);

            if packageRef and packageRef:FindFirstChildOfClass("ObjectValue") then
                result:Destroy();

                return "Model has been blocked.";
            end;

            result.Parent = workspace;
            result:MoveTo(u55.fromPlayer.Character:GetPivot().Position);
            result:MakeJoints();
            table.insert(u55._K.cleanupCommands, result);
        end
    },
    {
        name = "place",
        description = "Teleports one or more player(s) to a place.",
        aliases = { "pl" },
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) to teleport to a place.",
                shouldRequest = true
            }, {
                type = "integer @ reservedServer",
                name = "PlaceId",
                description = "The identifier of the place or reserved server."
            } },

        run = function(p57, p58, p59) -- Line: 370, Name: run
            if type(p59) == "number" then
                p57._K.Util.SafeTeleport(p59, p58);
            else
                local TeleportOptions = Instance.new("TeleportOptions");
                TeleportOptions.ReservedServerAccessCode = p59[2];
                p57._K.Util.SafeTeleport(p59[3], p58, TeleportOptions);
            end;

            for _, v in p58 do
                p57._K.Remote.Notify:Fire(v, {
                    From = "_K",
                    Text = "Teleport initiated..."
                });
            end;
        end
    },
    {
        name = "serverlock",
        description = "Locks the server preventing new players from joining.",
        aliases = { "slock" },
        args = {},

        run = function(p60) -- Line: 391, Name: run
            if not p60._K._serverLock then
                p60._K._serverLock = p60.fromPlayer.Name;
                p60._K.Remote.Notify:FireAll({
                    Text = "The server has been <b>locked</b>.",
                    From = p60.from
                });
            end;
        end
    },
    {
        name = "unserverlock",
        description = "Unlocks the server allowing new players to join again.",
        aliases = { "unslock" },
        args = {},

        run = function(p61) -- Line: 406, Name: run
            p61._K._serverLock = nil;
            p61._K.Remote.Notify:FireAll({
                Text = "The server has been <b>unlocked</b>.",
                From = p61.from
            });
        end
    }
};