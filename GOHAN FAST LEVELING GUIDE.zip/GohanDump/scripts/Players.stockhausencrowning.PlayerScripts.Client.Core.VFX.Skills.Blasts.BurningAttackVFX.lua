-- Decompiled with Potassium's decompiler.

local Debris = game:GetService("Debris");
local Particles = game:GetService("ReplicatedStorage").Assets.Effects.Particles;

return {
    Execute = function(p1) -- Line: 12
        -- upvalues: Particles (copy), Debris (copy)
        local Character = p1.Character;

        if not Character then
            return;
        end;

        for _, v in ipairs({ "Right Arm", "Left Arm" }) do
            local v2 = Character:FindFirstChild(v);

            if v2 then
                local u3 = Particles.Shunpo:Clone();
                u3.Parent = v2;
                u3:Emit(10);
                task.delay(1, function() -- Line: 23
                    -- upvalues: u3 (copy), Debris (ref)
                    u3.Enabled = false;
                    Debris:AddItem(u3, 1);
                end);
            end;
        end;
    end
};