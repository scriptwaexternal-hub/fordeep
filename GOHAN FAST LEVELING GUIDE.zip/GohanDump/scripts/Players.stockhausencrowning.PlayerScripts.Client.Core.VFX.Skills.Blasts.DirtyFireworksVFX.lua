-- Decompiled with Potassium's decompiler.

local Debris = game:GetService("Debris");
local ReplicatedStorage = game:GetService("ReplicatedStorage");
local Modules = ReplicatedStorage:WaitForChild("Modules");
local SoundManager = require(Modules.Shared.SoundManager);
local GlobalFunctions = require(Modules.GlobalFunctions);
local Visuals = workspace.World.Visuals;
local Meshes = ReplicatedStorage.Assets.Effects.Meshes;

return {
    Create = function(p1) -- Line: 24
        -- upvalues: Meshes (copy), Visuals (copy), SoundManager (copy)
        local Character = p1.Character;

        if not Character then
            return;
        end;

        local v2 = Meshes.Skills.Blasts["Dirty Fireworks"]["Dirty Firework"]:Clone();
        v2.Name = "Dirty_Firework" .. Character.Name;
        v2.Position = p1.Origin;
        v2.Parent = Visuals;
        SoundManager.AddSound("Dirty Fireworks", {
            Parent = v2
        }, "Client");
    end,

    Execute = function(p3) -- Line: 36
        -- upvalues: Meshes (copy), Visuals (copy), Debris (copy), SoundManager (copy), GlobalFunctions (copy)
        local Location = p3.Location;
        local Size = p3.Size;

        if not (Location and Size) then
            return;
        end;

        local v4 = Meshes.Skills.Blasts["Dirty Fireworks"]["Red Explosion"]:Clone();
        v4.Handle.CFrame = Location;
        v4.Parent = Visuals;
        Debris:AddItem(v4, 5);
        SoundManager.AddSound("Explosion (DBZ)", {
            Parent = v4.Handle
        }, "Client");
        local math_random_ret = math.random(1, 60);
        local math_random_ret2 = math.random(50, 170);
        local Vector3_new_ret = Vector3.new(math_random_ret, math_random_ret2, math.random(1, 60));

        for _, child in ipairs(v4:GetChildren()) do
            GlobalFunctions.Tween({
                Duration = 2,
                Instance = child,
                EasingStyle = Enum.EasingStyle.Exponential
            }, {
                Size = Vector3.new(1, 1, 1) * Size,
                Orientation = Vector3_new_ret
            });
            task.delay(0.5, function() -- Line: 56
                -- upvalues: GlobalFunctions (ref), child (copy)
                GlobalFunctions.TransparencyTween({
                    Duration = 1,
                    Instance = child,
                    EasingStyle = Enum.EasingStyle.Exponential
                });
            end);
        end;
    end
};