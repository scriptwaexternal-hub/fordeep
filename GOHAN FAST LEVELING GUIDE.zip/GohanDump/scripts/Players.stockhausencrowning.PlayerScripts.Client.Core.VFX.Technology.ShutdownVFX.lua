-- Decompiled with Potassium's decompiler.

local Players = game:GetService("Players");
local TweenService = game:GetService("TweenService");
local LocalPlayer = Players.LocalPlayer;
local u1 = {};
local u2 = nil;

function u1.Clear() -- Line: 16
    -- upvalues: u2 (ref)
    if u2 then
        u2:Destroy();
        u2 = nil;
    end;
end;

function u1.Dim(p3) -- Line: 20
    -- upvalues: u1 (copy), LocalPlayer (copy), u2 (ref), TweenService (copy)
    u1.Clear();

    if p3 then
        p3 = p3.Duration;
    end;

    local u4 = tonumber(p3) or 15;
    local ScreenGui = Instance.new("ScreenGui");
    ScreenGui.Name = "ShutdownTint";
    ScreenGui.IgnoreGuiInset = true;
    ScreenGui.DisplayOrder = 200;
    ScreenGui.ResetOnSpawn = true;
    ScreenGui.Parent = LocalPlayer:WaitForChild("PlayerGui");
    u2 = ScreenGui;
    local Frame = Instance.new("Frame");
    Frame.Size = UDim2.fromScale(1, 1);
    Frame.BackgroundColor3 = Color3.new(0, 0, 0);
    Frame.BackgroundTransparency = 1;
    Frame.BorderSizePixel = 0;
    Frame.Parent = ScreenGui;
    task.spawn(function() -- Line: 37
        -- upvalues: u2 (ref), ScreenGui (copy), Frame (copy), u4 (copy), TweenService (ref)
        for _, v in ipairs({ 0.2, 0.9, 0.1, 0.7, 0.08 }) do
            if u2 ~= ScreenGui then
                return;
            end;

            Frame.BackgroundTransparency = v;
            task.wait(0.07);
        end;

        task.wait((math.max(u4 - 0.35 - 1.2, 0)));

        if u2 ~= ScreenGui then
            return;
        end;

        local v5 = TweenService:Create(Frame, TweenInfo.new(1.2, Enum.EasingStyle.Quad, Enum.EasingDirection.In), {
            BackgroundTransparency = 1
        });
        v5:Play();
        v5.Completed:Once(function() -- Line: 48
            -- upvalues: u2 (ref), ScreenGui (ref)
            if u2 == ScreenGui then
                ScreenGui:Destroy();
                u2 = nil;
            end;
        end);
    end);
end;

return u1;