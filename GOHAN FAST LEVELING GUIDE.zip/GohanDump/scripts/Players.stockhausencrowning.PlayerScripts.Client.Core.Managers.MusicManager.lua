-- Decompiled with Potassium's decompiler.

local ReplicatedStorage = game:GetService("ReplicatedStorage");
game:GetService("UserInputService");
local Players = game:GetService("Players");
game:GetService("Debris");
local Modules = ReplicatedStorage:WaitForChild("Modules");
ReplicatedStorage:WaitForChild("Remotes");
local _ = Modules.Metadata;
local _ = Modules.Shared;
local _ = Modules.Utility;
local _ = ReplicatedStorage.Assets;
local GlobalFunctions = require(Modules.GlobalFunctions);
local LocalPlayer = Players.LocalPlayer;
local script_Music = script.Music;
script_Music:FindFirstChild("Combat Music");
local u1 = {};
local u2 = {};

for _, child in pairs(script_Music:GetChildren()) do
    u1[child.Name] = child;
end;

local function inCombat(p3) -- Line: 43
    if p3 and p3.Parent then
        return p3:GetAttribute("State_InCombat") ~= nil and true or p3:FindFirstChild("InCombat") ~= nil;
    end;

    return false;
end;

local u4 = 0;

local function settingVolume(p5) -- Line: 103
    local Volume = script:FindFirstChild("Volume");

    return (p5 or 1) * ((Volume and Volume.Value or 100) / 100);
end;

local function stopTrack(u6: userdata?) -- Line: 108
    -- upvalues: GlobalFunctions (copy)
    if not (u6 and u6.Parent) then
        return;
    end;

    GlobalFunctions.Tween({
        Duration = 1,
        Instance = u6
    }, {
        Volume = 0
    });
    task.delay(1, function() -- Line: 114
        -- upvalues: u6 (copy)
        if not u6.Parent then
            return;
        end;

        u6:Stop();
        u6:Destroy();
    end);
end;

function u2.Fire() -- Line: 122
    -- upvalues: u2 (copy)
    u2.PlayMusic("Default Music");
end;

function u2.Combat() -- Line: 127
    -- upvalues: LocalPlayer (copy), u2 (copy)
    local v7 = LocalPlayer.Character or LocalPlayer.CharacterAdded:Wait();
    u2.PlayCombatMusic(v7, "Combat Music");
end;

function u2.PlayCombatMusic(p8, p9) -- Line: 134
    -- upvalues: u1 (copy), u4 (ref), LocalPlayer (copy), stopTrack (copy)
    local v10 = u1[p9];

    if not v10 then
        warn("No Music Found");

        return;
    end;

    local Children = v10:GetChildren();

    if #Children == 0 then
        return;
    end;

    local CurrentTrack = script:WaitForChild("CurrentTrack");
    u4 = u4 + 1;
    local u11 = u4;

    local function stillMine() -- Line: 144
        -- upvalues: u4 (ref), u11 (copy)
        return u4 == u11;
    end;

    local v12 = os.clock() + 1.5;

    while true do
        local v13;

        if true then
            if p8 and p8.Parent then
                v13 = p8:GetAttribute("State_InCombat") ~= nil and true or p8:FindFirstChild("InCombat") ~= nil;
            else
                v13 = false;
            end;
        end;

        if v13 or os.clock() >= v12 or u4 ~= u11 then
            break;
        end;

        task.wait();
    end;

    local v14;

    if p8 and p8.Parent then
        v14 = p8:GetAttribute("State_InCombat") ~= nil and true or p8:FindFirstChild("InCombat") ~= nil;
    else
        v14 = false;
    end;

    if not v14 or u4 ~= u11 then
        return;
    end;

    CurrentTrack.Value = "...";
    local v15 = nil;

    while true do
        local v16;

        if true then
            if p8 and p8.Parent then
                v16 = p8:GetAttribute("State_InCombat") ~= nil and true or p8:FindFirstChild("InCombat") ~= nil;
            else
                v16 = false;
            end;
        end;

        if not v16 or u4 ~= u11 then
            break;
        end;

        v15 = Children[math.random(1, #Children)]:Clone();
        local Volume = script:FindFirstChild("Volume");
        v15.Volume = 1 * ((Volume and Volume.Value or 100) / 100);
        v15.Parent = LocalPlayer;
        CurrentTrack.Value = "...";
        task.wait();
        v15:Play();
        CurrentTrack.Value = v15.Name;

        while v15.IsPlaying do
            local v17;

            if p8 and p8.Parent then
                v17 = p8:GetAttribute("State_InCombat") ~= nil and true or p8:FindFirstChild("InCombat") ~= nil;
            else
                v17 = false;
            end;

            if not v17 or u4 ~= u11 then
                break;
            end;

            task.wait();
        end;

        local v18;

        if p8 and p8.Parent then
            v18 = p8:GetAttribute("State_InCombat") ~= nil and true or p8:FindFirstChild("InCombat") ~= nil;
        else
            v18 = false;
        end;

        if not v18 or u4 ~= u11 then
            break;
        end;

        v15:Destroy();
        v15 = nil;
    end;

    stopTrack(v15);

    if u4 == u11 then
        CurrentTrack.Value = "...";
    end;
end;

function u2.PlayMusic(p19) -- Line: 182
    -- upvalues: u1 (copy), LocalPlayer (copy)
    local v20 = u1[p19];

    if not v20 then
        warn("No Music Found");

        return;
    end;

    local Children = v20:GetChildren();
    local CurrentTrack = script:WaitForChild("CurrentTrack");

    while LocalPlayer.Parent ~= nil do
        local v21 = Children[math.random(1, #Children)]:Clone();
        v21.Parent = LocalPlayer;
        CurrentTrack.Value = "...";
        v21:Play();
        CurrentTrack.Value = v21.Name;
        task.wait();

        while v21.IsPlaying and LocalPlayer.Parent ~= nil do
            local Character = LocalPlayer.Character;
            local v22;

            if Character and Character.Parent then
                v22 = Character:GetAttribute("State_InCombat") ~= nil and true or Character:FindFirstChild("InCombat") ~= nil;
            else
                v22 = false;
            end;

            if v22 then
                v21.Volume = 0;
            else
                local Volume = script:FindFirstChild("Volume");
                v21.Volume = 1 * ((Volume and Volume.Value or 100) / 100);
            end;

            task.wait();
        end;

        v21:Stop();
        v21:Destroy();
    end;
end;

return u2;