-- Decompiled with Potassium's decompiler.

game:GetService("Players");
local Debris = game:GetService("Debris");
local RaceChat = require(game:GetService("ReplicatedStorage"):WaitForChild("Modules"):WaitForChild("Shared"):WaitForChild("RaceChat"));
local ReplicatedStorage = game:GetService("ReplicatedStorage");
game:GetService("RunService");
local Assets = ReplicatedStorage.Assets;
local Modules = ReplicatedStorage:WaitForChild("Modules");
ReplicatedStorage:WaitForChild("Remotes");
local _ = Modules.Metadata;
local _ = Modules.Utility;
local SoundManager = require(Modules.Shared.SoundManager);
local GlobalFunctions = require(Modules.GlobalFunctions);
local _ = workspace.World.Visuals;
local Particles = Assets.Effects.Particles;

return {
    Fire = function(p1) -- Line: 30
        -- upvalues: GlobalFunctions (copy), SoundManager (copy), Particles (copy), Debris (copy)
        local RootAndHumanoid = GlobalFunctions.GetRootAndHumanoid(p1.Character);
        SoundManager.AddSound("Skill Gained", {
            Parent = RootAndHumanoid
        }, "Client");
        local v2 = Particles.SkillPFX.Attachment:Clone();
        v2.Parent = RootAndHumanoid;
        v2.SkillPFX:Emit(1);
        Debris:AddItem(v2, 2);
    end,

    LevelUp = function(p3) -- Line: 42
        -- upvalues: GlobalFunctions (copy), Assets (copy), Debris (copy)
        local RootAndHumanoid = GlobalFunctions.GetRootAndHumanoid(p3.Character);
        local v4 = Assets.Effects.Particles["Level Up Effect"]:Clone();
        local Attachment = v4.Attachment;
        Attachment.Parent = RootAndHumanoid;

        for _, child in pairs(Attachment:GetChildren()) do
            child:Emit(1);
        end;

        Debris:AddItem(v4, 2);
        Debris:AddItem(Attachment, 1);
    end,

    ["Base Level Up"] = function(p5) -- Line: 57
        -- upvalues: GlobalFunctions (copy), Assets (copy), Debris (copy)
        local RootAndHumanoid = GlobalFunctions.GetRootAndHumanoid(p5.Character);
        local v6 = Assets.Effects.Particles["Golden Level Up"]:Clone();
        local Attachment = v6.Attachment;
        Attachment.Parent = RootAndHumanoid;

        for _, child in pairs(Attachment:GetChildren()) do
            child:Emit(1);
        end;

        Debris:AddItem(v6, 2);
        Debris:AddItem(Attachment, 1);
    end,

    ["Ki Unlocked"] = function(p7) -- Line: 71
        -- upvalues: GlobalFunctions (copy), SoundManager (copy), RaceChat (copy)
        local Character = p7.Character;
        local RootAndHumanoid = GlobalFunctions.GetRootAndHumanoid(Character);
        Color3.fromRGB(255, 255, 255);
        local Color3_fromRGB_ret = Color3.fromRGB(100, 200, 255);
        local Highlight = Instance.new("Highlight");
        Highlight.Parent = Character;
        Highlight.FillTransparency = 0;
        Highlight.OutlineTransparency = 0;
        Highlight.OutlineColor = Color3_fromRGB_ret;
        Highlight.FillColor = Color3_fromRGB_ret;
        GlobalFunctions.Tween({
            Duration = 1,
            Instance = Highlight
        }, {
            OutlineTransparency = 1,
            FillTransparency = 1
        });
        SoundManager.AddSound("Ki Unlocked", {
            Parent = RootAndHumanoid
        }, "Client");
        RaceChat.Say(Character, "What is this new energy I feel...?");
        task.delay(1, function() -- Line: 92
            -- upvalues: Highlight (copy)
            game.Debris:AddItem(Highlight, 2);
        end);
    end
};