-- Decompiled with Potassium's decompiler.

local u17 = {
    concat = function(p1: table, p2: string) -- Line: 6, Name: concat
        local v3 = {};

        for _, v in p1 do
            local v4 = tostring(v);
            table.insert(v3, v4);
        end;

        return table.concat(v3, p2);
    end,

    countKeys = function(p5: table) -- Line: 14, Name: countKeys
        local v6 = 0;

        for _ in p5 do
            v6 = v6 + 1;
        end;

        return v6;
    end,

    toHashMap = function(p7: table) -- Line: 22, Name: toHashMap
        local v8 = {};

        for _, v in p7 do
            v8[v] = true;
        end;

        return v8;
    end,

    map = function(p9: table, p10: function) -- Line: 30, Name: map
        for i, v in p9 do
            p9[i] = p10(v, i);
        end;

        return p9;
    end,

    isArray = function(p11: table) -- Line: 37, Name: isArray
        local v12 = 1;

        for _ in p11 do
            if p11[v12] == nil then
                return false;
            end;

            v12 = v12 + 1;
        end;

        return true;
    end,

    merge = function(p13: table, p14: table) -- Line: 48, Name: merge
        for i, v in p14 do
            p13[i] = v;
        end;

        return p13;
    end,

    mergeList = function(p15: table, p16: table) -- Line: 55, Name: mergeList
        table.move(p16, 1, #p16, #p15 + 1, p15);
    end
};

function u17.deepCompare(p18, p19) -- Line: 59
    -- upvalues: u17 (copy)
    if type(p18) ~= "table" or type(p19) ~= "table" then
        return p18 == p19;
    end;

    for i, v in p18 do
        if not u17.deepCompare(v, p19[i]) then
            return false;
        end;
    end;

    return true;
end;

function u17.deepMerge(p20: table, p21: table, p22: boolean?) -- Line: 71
    -- upvalues: u17 (copy)
    if not (p22 and u17.isArray(p21)) then
        for i, v in p21 do
            if p20[i] and type(v) == "table" then
                u17.deepMerge(p20[i], v, p22);
            else
                p20[i] = v;
            end;
        end;

        return p20;
    end;

    if u17.isArray(p20) then
        u17.mergeList(p20, p21);

        return p20;
    end;

    for _, v in p21 do
        table.insert(p20, v);
    end;

    return p20;
end;

function u17.deepCopy(p23: table) -- Line: 92
    -- upvalues: u17 (copy)
    local table_clone_ret = table.clone(p23);

    for i, v in table_clone_ret do
        if type(v) == "table" then
            table_clone_ret[i] = u17.deepCopy(v);
        end;
    end;

    return table_clone_ret;
end;

function u17.settle(p24: table) -- Line: 102
    local v25 = 1;

    for i, v in p24 do
        p24[v25] = v;
        p24[i] = nil;
        v25 = v25 + 1;
    end;

    return p24;
end;

function u17.fastRemove(p26: table, p27: number, p28: number?) -- Line: 111
    -- upvalues: u17 (copy)
    for i = p27, p28 or p27 do
        p26[i] = nil;
        local _ = i;
    end;

    return u17.settle(p26);
end;

function u17.shuffle(p29: table) -- Line: 118
    for i = #p29, 2, -1 do
        local math_random_ret = math.random(i);
        local v30 = p29[i];
        p29[i] = p29[math_random_ret];
        p29[math_random_ret] = v30;
        local _ = i;
    end;

    return p29;
end;

return u17;