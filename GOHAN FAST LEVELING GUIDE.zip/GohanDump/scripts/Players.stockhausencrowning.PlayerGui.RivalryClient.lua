-- Decompiled with Potassium's decompiler.

local Players = game:GetService("Players");
local ReplicatedStorage = game:GetService("ReplicatedStorage");
local LocalPlayer = Players.LocalPlayer;
local RivalryRemote = ReplicatedStorage:WaitForChild("Remotes"):WaitForChild("RivalryRemote");
Color3.fromRGB(44, 44, 45);
local Color3_fromRGB_ret = Color3.fromRGB(28, 28, 30);
local Color3_fromRGB_ret2 = Color3.fromRGB(216, 213, 205);
local Color3_fromRGB_ret3 = Color3.fromRGB(201, 198, 191);
local Color3_fromRGB_ret4 = Color3.fromRGB(225, 100, 90);
Color3.fromRGB(88, 214, 106);
local Color3_fromRGB_ret5 = Color3.fromRGB(0, 0, 0);
local Arcade = Enum.Font.Arcade;
local Bangers = Enum.Font.Bangers;

local function stroke(p1, p2) -- Line: 28
    -- upvalues: Color3_fromRGB_ret5 (copy)
    local UIStroke = Instance.new("UIStroke");
    UIStroke.Color = Color3_fromRGB_ret5;
    UIStroke.Thickness = p2 or 2;
    UIStroke.Parent = p1;
end;

local function corner(p3, p4) -- Line: 34
    local UICorner = Instance.new("UICorner");
    UICorner.CornerRadius = UDim.new(0, p4 or 6);
    UICorner.Parent = p3;
end;

local u5 = {};
local u6 = {};

local function removeTag(p7) -- Line: 46
    -- upvalues: u6 (copy)
    local v8 = u6[p7];

    if v8 then
        v8:Destroy();
        u6[p7] = nil;
    end;
end;

local function tagCharacter(p9, p10) -- Line: 51
    -- upvalues: u6 (copy), Color3_fromRGB_ret (copy), Arcade (copy), Color3_fromRGB_ret4 (copy), Color3_fromRGB_ret5 (copy)
    local UserId = p9.UserId;
    local v11 = u6[UserId];

    if v11 then
        v11:Destroy();
        u6[UserId] = nil;
    end;

    local Head = p10:WaitForChild("Head", 5);

    if not Head then
        return;
    end;

    local BillboardGui = Instance.new("BillboardGui");
    BillboardGui.Name = "RivalTag";
    BillboardGui.Adornee = Head;
    BillboardGui.Size = UDim2.fromOffset(110, 22);
    BillboardGui.StudsOffset = Vector3.new(0, 2.6, 0);
    BillboardGui.MaxDistance = 120;
    BillboardGui.AlwaysOnTop = false;
    BillboardGui.Parent = p10;
    local TextLabel = Instance.new("TextLabel");
    TextLabel.Size = UDim2.fromScale(1, 1);
    TextLabel.BackgroundColor3 = Color3_fromRGB_ret;
    TextLabel.BackgroundTransparency = 0.2;
    TextLabel.Font = Arcade;
    TextLabel.TextSize = 13;
    TextLabel.TextColor3 = Color3_fromRGB_ret4;
    TextLabel.Text = ("RIVAL  Lv.%d"):format(p9.Level or 1);
    TextLabel.Parent = BillboardGui;
    local UICorner = Instance.new("UICorner");
    UICorner.CornerRadius = UDim.new(0, 4);
    UICorner.Parent = TextLabel;
    local UIStroke = Instance.new("UIStroke");
    UIStroke.Color = Color3_fromRGB_ret5;
    UIStroke.Thickness = 2;
    UIStroke.Parent = TextLabel;
    u6[p9.UserId] = BillboardGui;
end;

local function refreshTags() -- Line: 80
    -- upvalues: u6 (copy), u5 (ref), Players (copy), tagCharacter (copy)
    for i in pairs(u6) do
        if not u5[i] then
            local v12 = u6[i];

            if v12 then
                v12:Destroy();
                u6[i] = nil;
            end;
        end;
    end;

    for i, v in pairs(u5) do
        local PlayerByUserId = Players:GetPlayerByUserId(i);

        if PlayerByUserId then
            PlayerByUserId = PlayerByUserId.Character;
        end;

        if PlayerByUserId and (not u6[i] or u6[i].Parent ~= PlayerByUserId) then
            task.spawn(tagCharacter, v, PlayerByUserId);
        elseif not PlayerByUserId then
            local v13 = u6[i];

            if v13 then
                v13:Destroy();
                u6[i] = nil;
            end;
        end;
    end;
end;

Players.PlayerAdded:Connect(function(p14) -- Line: 97
    -- upvalues: refreshTags (copy)
    p14.CharacterAdded:Connect(function() -- Line: 98
        -- upvalues: refreshTags (ref)
        task.wait(1);
        refreshTags();
    end);
end);
local u15 = {};

for _, v in ipairs(Players:GetPlayers()) do
    if v ~= LocalPlayer then
        v.CharacterAdded:Connect(function() -- Line: 105
            -- upvalues: refreshTags (copy)
            task.wait(1);
            refreshTags();
        end);
    end;
end;

Players.PlayerRemoving:Connect(function(p16) -- Line: 111
    -- upvalues: u6 (copy)
    local UserId = p16.UserId;
    local v17 = u6[UserId];

    if v17 then
        v17:Destroy();
        u6[UserId] = nil;
    end;
end);
local u18 = nil;
local u19 = nil;

local function renderPanel() -- Line: 125
    -- upvalues: u18 (ref), u19 (ref), u15 (ref), Color3_fromRGB_ret (copy), Arcade (copy), Color3_fromRGB_ret3 (copy), Color3_fromRGB_ret5 (copy), Bangers (copy), Color3_fromRGB_ret2 (copy), Color3_fromRGB_ret4 (copy)
    if not (u18 and u19) then
        return;
    end;

    for _, child in ipairs(u19:GetChildren()) do
        if child:IsA("Frame") then
            child:Destroy();
        end;
    end;

    if #u15 ~= 0 then
        for _, v in ipairs(u15) do
            local Frame = Instance.new("Frame");
            Frame.Size = UDim2.new(1, -6, 0, 46);
            Frame.BackgroundColor3 = Color3_fromRGB_ret;
            Frame.Parent = u19;
            local UICorner = Instance.new("UICorner");
            UICorner.CornerRadius = UDim.new(0, 6);
            UICorner.Parent = Frame;
            local UIStroke = Instance.new("UIStroke");
            UIStroke.Color = Color3_fromRGB_ret5;
            UIStroke.Thickness = 2;
            UIStroke.Parent = Frame;
            local TextLabel = Instance.new("TextLabel");
            TextLabel.BackgroundTransparency = 1;
            TextLabel.Position = UDim2.new(0, 10, 0, 4);
            TextLabel.Size = UDim2.new(1, -120, 0, 20);
            TextLabel.Font = Bangers;
            TextLabel.TextSize = 18;
            TextLabel.TextXAlignment = Enum.TextXAlignment.Left;
            TextLabel.TextColor3 = Color3_fromRGB_ret2;
            TextLabel.Text = v.Name or "?";
            TextLabel.Parent = Frame;
            local TextLabel2 = Instance.new("TextLabel");
            TextLabel2.BackgroundTransparency = 1;
            TextLabel2.Position = UDim2.new(0, 10, 0, 25);
            TextLabel2.Size = UDim2.new(1, -120, 0, 16);
            TextLabel2.Font = Arcade;
            TextLabel2.TextSize = 12;
            TextLabel2.TextXAlignment = Enum.TextXAlignment.Left;
            TextLabel2.TextColor3 = Color3_fromRGB_ret3;
            TextLabel2.Text = ("W: %d   L: %d"):format(v.Wins or 0, v.Losses or 0);
            TextLabel2.Parent = Frame;
            local TextLabel3 = Instance.new("TextLabel");
            TextLabel3.BackgroundTransparency = 1;
            TextLabel3.AnchorPoint = Vector2.new(1, 0.5);
            TextLabel3.Position = UDim2.new(1, -10, 0.5, 0);
            TextLabel3.Size = UDim2.fromOffset(100, 20);
            TextLabel3.Font = Arcade;
            TextLabel3.TextSize = 13;
            TextLabel3.TextXAlignment = Enum.TextXAlignment.Right;
            TextLabel3.TextColor3 = v.IsRival and Color3_fromRGB_ret4 or Color3_fromRGB_ret3;
            TextLabel3.Text = v.IsRival and ("RIVAL Lv.%d"):format(v.Level or 1) or ("%d/%d fights"):format(v.Fights or 0, v.Needed or 3);
            TextLabel3.Parent = Frame;
            local UIStroke2 = Instance.new("UIStroke");
            UIStroke2.Color = Color3_fromRGB_ret5;
            UIStroke2.Thickness = 1;
            UIStroke2.Parent = TextLabel3;
        end;

        return;
    end;

    local Frame = Instance.new("Frame");
    Frame.Size = UDim2.new(1, -6, 0, 52);
    Frame.BackgroundColor3 = Color3_fromRGB_ret;
    Frame.Parent = u19;
    local UICorner = Instance.new("UICorner");
    UICorner.CornerRadius = UDim.new(0, 6);
    UICorner.Parent = Frame;
    local TextLabel = Instance.new("TextLabel");
    TextLabel.BackgroundTransparency = 1;
    TextLabel.Position = UDim2.new(0, 8, 0, 0);
    TextLabel.Size = UDim2.new(1, -16, 1, 0);
    TextLabel.Font = Arcade;
    TextLabel.TextSize = 13;
    TextLabel.TextWrapped = true;
    TextLabel.TextColor3 = Color3_fromRGB_ret3;
    TextLabel.Text = "No rivals yet. Keep fighting the same people...";
    TextLabel.Parent = Frame;
end;

RivalryRemote.OnClientEvent:Connect(function(p20) -- Line: 195
    -- upvalues: u15 (ref), u5 (ref), refreshTags (copy), u18 (ref), renderPanel (copy)
    if type(p20) ~= "table" or p20.Action ~= "List" then
        return;
    end;

    u15 = p20.List or {};
    u5 = {};

    for _, v in ipairs(u15) do
        if v.IsRival and v.UserId then
            u5[v.UserId] = v;
        end;
    end;

    refreshTags();

    if u18 and u18.Visible then
        renderPanel();
    end;
end);
task.delay(3, function() -- Line: 205
    -- upvalues: RivalryRemote (copy)
    RivalryRemote:FireServer({
        Action = "Request"
    });
end);
task.spawn(function() -- Line: 210
    -- upvalues: LocalPlayer (copy), u18 (ref), Bangers (copy), Color3_fromRGB_ret2 (copy), Color3_fromRGB_ret5 (copy), u19 (ref), renderPanel (copy), RivalryRemote (copy)
    local HUD = LocalPlayer:WaitForChild("PlayerGui"):WaitForChild("HUD", 30);

    if not HUD then
        return;
    end;

    local Inventory = HUD:WaitForChild("Inventory", 30);

    if not Inventory then
        return;
    end;

    local StatFrame = Inventory:WaitForChild("StatFrame");
    local Tabs = StatFrame:WaitForChild("Tabs");
    local LoreTab = Tabs:WaitForChild("LoreTab");
    local Lore = StatFrame:WaitForChild("Lore");

    if Tabs:FindFirstChild("RivalTab") then
        return;
    end;

    local u21 = LoreTab:Clone();
    u21.Name = "RivalTab";
    u21.LayoutOrder = 5;
    u21.Image = "rbxassetid://126454867112626";
    local v22 = u21:FindFirstChildWhichIsA("TextLabel");

    if v22 then
        v22.Text = "Rivals";
    end;

    u21.Parent = Tabs;
    local v23 = {};

    for _, child in ipairs(Tabs:GetChildren()) do
        if child:IsA("ImageButton") then
            v23[#v23 + 1] = child;
        end;
    end;

    for _, v in ipairs(v23) do
        v.Size = UDim2.new(1, 0, 0.1, 0);
    end;

    u18 = Instance.new("Frame");
    u18.Name = "Rivals";
    u18.AnchorPoint = Lore.AnchorPoint;
    u18.Position = Lore.Position;
    u18.Size = Lore.Size;
    u18.BackgroundColor3 = Lore.BackgroundColor3;
    u18.BackgroundTransparency = Lore.BackgroundTransparency;
    u18.BorderSizePixel = 0;
    u18.Visible = false;
    u18.ZIndex = 12;
    u18.DescendantAdded:Connect(function(p24) -- Line: 264
        if p24:IsA("GuiObject") then
            p24.ZIndex = 13;
        end;
    end);
    u18.Parent = StatFrame;
    local v25 = Lore:FindFirstChildOfClass("UICorner");

    if v25 then
        local Offset = v25.CornerRadius.Offset;
        local UICorner = Instance.new("UICorner");
        UICorner.CornerRadius = UDim.new(0, Offset or 6);
        UICorner.Parent = u18;
    end;

    local TextLabel = Instance.new("TextLabel");
    TextLabel.BackgroundTransparency = 1;
    TextLabel.Position = UDim2.new(0, 12, 0, 6);
    TextLabel.Size = UDim2.new(1, -24, 0, 24);
    TextLabel.Font = Bangers;
    TextLabel.TextSize = 20;
    TextLabel.TextColor3 = Color3_fromRGB_ret2;
    TextLabel.TextXAlignment = Enum.TextXAlignment.Left;
    TextLabel.Text = "RIVALS";
    TextLabel.Parent = u18;
    local UIStroke = Instance.new("UIStroke");
    UIStroke.Color = Color3_fromRGB_ret5;
    UIStroke.Thickness = 2;
    UIStroke.Parent = TextLabel;
    u19 = Instance.new("ScrollingFrame");
    u19.BackgroundTransparency = 1;
    u19.BorderSizePixel = 0;
    u19.Position = UDim2.new(0, 12, 0, 36);
    u19.Size = UDim2.new(1, -24, 1, -46);
    u19.ScrollBarThickness = 4;
    u19.AutomaticCanvasSize = Enum.AutomaticSize.Y;
    u19.CanvasSize = UDim2.new();
    u19.Parent = u18;
    local UIListLayout = Instance.new("UIListLayout");
    UIListLayout.Padding = UDim.new(0, 8);
    UIListLayout.Parent = u19;
    u21.Activated:Connect(function() -- Line: 298
        -- upvalues: Tabs (copy), StatFrame (copy), u21 (copy), u18 (ref), renderPanel (ref), RivalryRemote (ref)
        for _, child in ipairs(Tabs:GetChildren()) do
            if child:IsA("ImageButton") then
                child.Image = "rbxassetid://126454867112626";
            end;
        end;

        for _, child in ipairs(StatFrame:GetChildren()) do
            if child:IsA("Frame") and child.Name ~= "Tabs" then
                child.Visible = false;
            end;
        end;

        u21.Image = "rbxassetid://126781002557225";
        u18.Visible = true;
        renderPanel();
        RivalryRemote:FireServer({
            Action = "Request"
        });
    end);
end);