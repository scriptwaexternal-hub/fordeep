-- Decompiled with Potassium's decompiler.

local Players = game:GetService("Players");
local Debris = game:GetService("Debris");
local ReplicatedStorage = game:GetService("ReplicatedStorage");
game:GetService("TweenService");
game:GetService("RunService");
local UserInputService = game:GetService("UserInputService");
local GuiService = game:GetService("GuiService");
local RaceChat = require(game:GetService("ReplicatedStorage"):WaitForChild("Modules"):WaitForChild("Shared"):WaitForChild("RaceChat"));
local Assets = ReplicatedStorage.Assets;
local Modules = ReplicatedStorage:WaitForChild("Modules");
local Remotes = ReplicatedStorage:WaitForChild("Remotes");
local Metadata = Modules.Metadata;
local Shared = Modules.Shared;
local Utility = Modules.Utility;
local Gui = Assets.Gui;
local Particles = Assets.Effects.Particles;
local Models = Assets.Models;
local SoundManager = require(Shared.SoundManager);
local GlobalFunctions = require(Modules.GlobalFunctions);
require(Shared.CamManager);
require(Shared.CinemaManager);
local StatData = require(Metadata.StatData.StatData);
require(Shared.CamShakeHandler);
local GameMessage = require(Utility.GameMessage);
require(Utility.Create);
local AnimationManager = require(Shared.AnimationManager);
local HitboxHandler = require(Utility.HitboxHandler);
local FindCharacters = require(Shared.FindCharacters);
local StateManager = require(Metadata.ControlData.StateManager);
local ControlData = require(Metadata.ControlData.ControlData);
local Platform = require(Shared.Platform);
local StatRetrieveRemote = Remotes.StatRetrieveRemote;
local ServerRemote = ReplicatedStorage.Remotes.ServerRemote;
local LocalPlayer = Players.LocalPlayer;
local workspace_World = workspace.World;
local Live = workspace_World.Live;
local Visuals = workspace_World.Visuals;
local u1 = StatData.MaxMeditation["MAX REQ"];
local Meditate = Assets.Gui.Meditate;

function Reset_Gui()
    -- upvalues: LocalPlayer (copy)
    local MeditateGui = LocalPlayer.PlayerGui:FindFirstChild("MeditateGui");

    if not MeditateGui then
        return;
    end;

    for _, child in pairs(MeditateGui:GetChildren()) do
        child:Destroy();
    end;
end;

local function isKiBlastInput(p2) -- Line: 77
    -- upvalues: ControlData (copy), Platform (copy)
    local v3 = ControlData.Controls.Combat and ControlData.Controls.Combat["Ki Blast"];

    if type(v3) ~= "table" then
        return p2.KeyCode == Enum.KeyCode.E;
    end;

    local v4 = nil;
    local UserInputType = p2.UserInputType;
    local v5;

    if UserInputType == Enum.UserInputType.Keyboard or Platform.IsGamepadInput(UserInputType) then
        v5 = p2.KeyCode.Name;
    else
        v5 = UserInputType == Enum.UserInputType.MouseButton1 and "MouseButton1" or (UserInputType == Enum.UserInputType.MouseButton2 and "MouseButton2" or v4);
    end;

    if not v5 then
        return false;
    end;

    for _, v in ipairs(v3) do
        if v == v5 then
            return true;
        end;
    end;

    return false;
end;

local u67 = {
    Control = function() -- Line: 101
        -- upvalues: LocalPlayer (copy), GlobalFunctions (copy), StatRetrieveRemote (copy), ServerRemote (copy), StateManager (copy), Platform (copy), SoundManager (copy), AnimationManager (copy), Assets (copy), Visuals (copy), Debris (copy), HitboxHandler (copy), FindCharacters (copy), Models (copy), Gui (copy), Live (copy), UserInputService (copy), isKiBlastInput (copy), GameMessage (copy)
        local u6 = LocalPlayer.Character or LocalPlayer.CharacterAdded:Wait();
        local RootAndHumanoid = GlobalFunctions.GetRootAndHumanoid(u6);
        local v7 = StatRetrieveRemote:InvokeServer("KiControl", "Core");
        local u8 = v7.BaseKiControl + v7.EnhancedKiControl;
        local u9 = true;
        local u10 = nil;
        local u11 = {};
        local u12 = {};
        local u13 = tick();

        local function Award_Player() -- Line: 124
            -- upvalues: u8 (copy), ServerRemote (ref)
            if u8 >= 45 then
                ServerRemote:FireServer(
                    nil,
                    {
                        Module = "StatManager",
                        Action = "Gain",
                        Stat = "KiControl",
                        StatType = "KiCtrl",
                        ItemType = "Enhanced KiCtrl",
                        ClientVerified = true
                    }
                );

                return;
            end;

            ServerRemote:FireServer(
                nil,
                {
                    Module = "StatManager",
                    Action = "Gain",
                    Stat = "KiControl",
                    StatType = "KiCtrl",
                    ClientVerified = true
                }
            );
        end;

        local function Stop_Meditating() -- Line: 145
            -- upvalues: ServerRemote (ref)
            ServerRemote:FireServer(nil, {
                Module = "CoreControlHandler",
                Action = "Meditate"
            });
        end;

        (function() -- Line: 149, Name: Start_Target_Training
            -- upvalues: StateManager (ref), u6 (copy), Platform (ref), LocalPlayer (ref), SoundManager (ref), RootAndHumanoid (copy), AnimationManager (ref), Assets (ref), Visuals (ref), Debris (ref), HitboxHandler (ref), FindCharacters (ref), GlobalFunctions (ref), Award_Player (copy), Models (ref), Gui (ref), Live (ref), u12 (copy), u10 (ref), u11 (copy), u9 (ref), UserInputService (ref), isKiBlastInput (ref), GameMessage (ref), ServerRemote (ref), u13 (copy)
            StateManager.ClearState(u6, "Meditating");
            StateManager.SetState(u6, "Training");

            local function Shoot_Fake_Blast() -- Line: 163
                -- upvalues: Platform (ref), LocalPlayer (ref), SoundManager (ref), RootAndHumanoid (ref), AnimationManager (ref), u6 (ref), Assets (ref), Visuals (ref), Debris (ref), HitboxHandler (ref), FindCharacters (ref), GlobalFunctions (ref), Award_Player (ref)
                local function getMouseWorldPosition() -- Line: 164
                    -- upvalues: Platform (ref), LocalPlayer (ref)
                    local workspace_Camera = workspace.Camera;
                    local Position = workspace_Camera.CFrame.Position;
                    local v14;

                    if Platform.IsTouch() then
                        local ViewportSize = workspace_Camera.ViewportSize;
                        local v15 = workspace_Camera:ViewportPointToRay(ViewportSize.X / 2, ViewportSize.Y / 2);
                        Position = v15.Origin;
                        v14 = v15.Direction * 10000;
                    else
                        v14 = (LocalPlayer:GetMouse().Hit.Position - Position).Unit * 10000;
                    end;

                    local v16 = workspace:Raycast(Position, v14);

                    if v16 then
                        return v16.Position;
                    end;

                    return Position + v14;
                end;

                SoundManager.AddSound("Ki Blast", {
                    Parent = RootAndHumanoid
                }, "Client");
                AnimationManager.PlayAnimation(u6, "Ki Blast");
                local v17 = getMouseWorldPosition();
                local CFrame_new_ret = CFrame.new(0, 1, -4);
                local u18 = Assets.Effects.Skills["Ki Blast"]:Clone();
                u18.Parent = Visuals;
                u18.CFrame = RootAndHumanoid.CFrame * CFrame_new_ret;
                u18.Anchored = false;
                local _ = (v17 - u18.Position).Unit;
                local LinearVelocity = Instance.new("LinearVelocity");
                LinearVelocity.Parent = u18;
                LinearVelocity.MaxForce = math.max(u18.AssemblyMass, 1) * 12000;
                LinearVelocity.VectorVelocity = (v17 - u18.Position).Unit * 200;
                LinearVelocity.Attachment0 = Instance.new("Attachment", u18);
                Debris:AddItem(u18, 3);

                local function Hitbox_Function() -- Line: 217
                    -- upvalues: u18 (copy), HitboxHandler (ref), FindCharacters (ref), u6 (ref), SoundManager (ref), GlobalFunctions (ref), Debris (ref), Award_Player (ref)
                    local v19 = {
                        Size = Vector3.new(u18.Size.X, u18.Size.Y, u18.Size.Z),
                        Location = u18.CFrame
                    };
                    local _, v20 = HitboxHandler.New(v19);
                    local v21 = FindCharacters.Find(u6, v20);

                    for _, v in pairs(v21) do
                        if v.Name == "Target" and not v:GetAttribute("TargetHit") then
                            v:SetAttribute("TargetHit", true);
                            u18:Destroy();
                            SoundManager.AddSound("Lego Break", {
                                Parent = v.HumanoidRootPart
                            }, "Client");
                            GlobalFunctions.Tween({
                                Instance = v.HumanoidRootPart
                            }, {
                                Transparency = 2
                            });
                            Debris:AddItem(v, 1);
                            Award_Player();

                            return;
                        end;
                    end;
                end;

                task.spawn(function() -- Line: 244
                    -- upvalues: u18 (copy), Hitbox_Function (copy)
                    while u18.Parent do
                        Hitbox_Function();
                        task.wait();
                    end;
                end);
            end;

            local function Create_Target() -- Line: 253
                -- upvalues: Models (ref), Gui (ref), Live (ref), RootAndHumanoid (ref), Debris (ref), u12 (ref)
                local v22 = Models:FindFirstChild("Target"):Clone();
                Gui.Trainings.KiControl:FindFirstChild("Marker"):Clone().Parent = v22;
                v22.Parent = Live;
                local math_random_ret = math.random(-70, 70);
                local math_random_ret2 = math.random(30, 50);
                local v23 = -math.random(50, 70);
                v22.HumanoidRootPart.CFrame = RootAndHumanoid.CFrame * CFrame.new(math_random_ret, math_random_ret2, v23);
                v22.HumanoidRootPart.CFrame = CFrame.lookAt(v22.HumanoidRootPart.Position, RootAndHumanoid.Position);
                Debris:AddItem(v22, 15);
                table.insert(u12, v22);
            end;

            local function End_Training() -- Line: 270
                -- upvalues: u12 (ref), StateManager (ref), u6 (ref), u10 (ref), u11 (ref)
                for _, v in pairs(u12) do
                    v:Destroy();
                end;

                StateManager.ClearState(u6, "Training");
                u10:Disconnect();

                for _, v in ipairs(u11) do
                    v:Disconnect();
                end;

                table.clear(u11);
                pcall(function() -- Line: 281
                    game:GetService("ContextActionService"):UnbindAction("ControlTrainingShoot");
                end);
            end;

            for i = 1, 15 do
                Create_Target();
                local _ = i;
            end;

            local function TryShoot() -- Line: 290
                -- upvalues: u9 (ref), Shoot_Fake_Blast (copy)
                if not u9 then
                    return;
                end;

                u9 = false;
                Shoot_Fake_Blast();
                task.delay(0.25, function() -- Line: 294
                    -- upvalues: u9 (ref)
                    u9 = true;
                end);
            end;

            u10 = UserInputService.InputBegan:Connect(function(p24, p25) -- Line: 299
                -- upvalues: isKiBlastInput (ref), u9 (ref), Shoot_Fake_Blast (copy)
                if p25 then
                    return;
                end;

                if isKiBlastInput(p24) then
                    if not u9 then
                        return;
                    end;

                    u9 = false;
                    Shoot_Fake_Blast();
                    task.delay(0.25, function() -- Line: 294
                        -- upvalues: u9 (ref)
                        u9 = true;
                    end);
                end;
            end);

            if Platform.IsTouch() then
                local v26 = false;
                local MobileControls = LocalPlayer.PlayerGui:FindFirstChild("MobileControls");

                if MobileControls then
                    for _, descendant in ipairs(MobileControls:GetDescendants()) do
                        if descendant:IsA("TextButton") and descendant.Name == "Ki Blast" then
                            table.insert(u11, descendant.MouseButton1Down:Connect(TryShoot));
                            v26 = true;
                        end;
                    end;
                end;

                if not v26 then
                    local ContextActionService = game:GetService("ContextActionService");
                    ContextActionService:BindAction("ControlTrainingShoot", function(p27, p28) -- Line: 332
                        -- upvalues: u9 (ref), Shoot_Fake_Blast (copy)
                        if p28 ~= Enum.UserInputState.Begin then
                            return;
                        end;

                        if not u9 then
                            return;
                        end;

                        u9 = false;
                        Shoot_Fake_Blast();
                        task.delay(0.25, function() -- Line: 294
                            -- upvalues: u9 (ref)
                            u9 = true;
                        end);
                    end, true);
                    ContextActionService:SetTitle("ControlTrainingShoot", "SHOOT");
                end;
            end;

            GameMessage.SendMessage(LocalPlayer, "Hit the Targets to improve your Ki Control!");
            ServerRemote:FireServer(nil, {
                Module = "CoreControlHandler",
                Action = "Meditate"
            });
            local u29 = { "Stunned", "Knocked", "KO", "Dead" };

            local function interruptReason() -- Line: 358
                -- upvalues: u29 (copy), u6 (ref)
                for _, v in ipairs(u29) do
                    if u6:GetAttribute("State_" .. v) == true then
                        return "State_" .. v;
                    end;
                end;

                if not u6.Parent then
                    return "character removed";
                end;

                local Humanoid = u6:FindFirstChild("Humanoid");

                return Humanoid and Humanoid.Health <= 0 and "died" or nil;
            end;

            task.spawn(function() -- Line: 371
                -- upvalues: u13 (ref), interruptReason (copy), GameMessage (ref), LocalPlayer (ref), End_Training (copy)
                local v30 = nil;
                local v31 = nil;
                local v32;

                while true do
                    if tick() - u13 >= 15 then
                        v32 = v31;
                        break;
                    end;

                    v32 = interruptReason();

                    if v32 then
                        v30 = v30 or os.clock();

                        if os.clock() - v30 >= 0.5 or (v32 == "died" or v32 == "character removed") then
                            break;
                        end;
                    else
                        v30 = nil;
                    end;

                    task.wait();
                end;

                if v32 then
                    local v33 = tick() - u13;
                    warn(("[KiControl] training ended after %.1fs of %ds -- %s"):format(v33, 15, v32));
                    GameMessage.SendMessage(LocalPlayer, ("Training interrupted (%s)."):format(v32:gsub("State_", "")));
                end;

                End_Training();
            end);
        end)();
    end,

    Dmg = function() -- Line: 407
        -- upvalues: LocalPlayer (copy), StatRetrieveRemote (copy), SoundManager (copy), ServerRemote (copy), Gui (copy), GlobalFunctions (copy), Debris (copy), Platform (copy), GuiService (copy), GameMessage (copy)
        local MeditateGui = LocalPlayer.PlayerGui.MeditateGui;
        local u34 = LocalPlayer.Character or LocalPlayer.CharacterAdded:Wait();
        local HumanoidRootPart = u34:FindFirstChild("HumanoidRootPart");
        u34:FindFirstChild("Humanoid");
        local u35 = StatRetrieveRemote:InvokeServer("KiDmg", "Core");
        local u36 = u35.BaseKiDmg + u35.EnhancedKiDmg;

        local function Send_Exp() -- Line: 420
            -- upvalues: SoundManager (ref), HumanoidRootPart (copy), u35 (ref), StatRetrieveRemote (ref), u36 (ref), ServerRemote (ref)
            SoundManager.AddSound("Burst", {
                Parent = HumanoidRootPart
            }, "Client");
            u35 = StatRetrieveRemote:InvokeServer("KiDmg", "Core");
            u36 = u35.BaseKiDmg + u35.EnhancedKiDmg;

            if u36 >= 45 then
                ServerRemote:FireServer(
                    nil,
                    {
                        Module = "StatManager",
                        Action = "Gain",
                        Stat = "KiDmg",
                        StatType = "KiDmg",
                        ItemType = "Enhanced KiDmg",
                        ClientVerified = true
                    }
                );

                return;
            end;

            ServerRemote:FireServer(
                nil,
                {
                    Module = "StatManager",
                    Action = "Gain",
                    Stat = "KiDmg",
                    StatType = "KiDmg",
                    ClientVerified = true
                }
            );
        end;

        local function Create_Goal_Gui() -- Line: 446
            -- upvalues: Gui (ref), MeditateGui (copy), GlobalFunctions (ref), Debris (ref), Send_Exp (copy), Platform (ref), GuiService (ref)
            local v37 = math.random(10, 30) / 100;
            local v38 = math.random(20, 80) / 100;
            local v39 = math.random(20, 80) / 100;
            local u40 = Gui.Trainings.KiDmg.Goal:Clone();
            u40.Parent = MeditateGui;
            u40.Size = UDim2.new(v37, 0, v37, 0);
            u40.Position = UDim2.new(v38, 0, v39, 0);
            GlobalFunctions.Tween({
                Duration = 2,
                Instance = u40
            }, {
                ImageTransparency = 1,
                Size = UDim2.new(0, 0, 0, 0)
            });
            Debris:AddItem(u40, 2);
            local u41 = false;

            local function pop() -- Line: 463
                -- upvalues: u41 (ref), Send_Exp (ref), u40 (copy)
                if u41 then
                    return;
                end;

                u41 = true;
                Send_Exp();
                u40:Destroy();
            end;

            u40.MouseButton1Down:Once(pop);
            u40.Activated:Connect(pop);

            if Platform.PreferGamepadGlyphs() then
                local SelectedObject = GuiService.SelectedObject;

                if not (SelectedObject and SelectedObject.Parent) then
                    GuiService.SelectedObject = u40;
                end;
            end;
        end;

        (function() -- Line: 483, Name: Start_KIDMG_Training
            -- upvalues: GameMessage (ref), LocalPlayer (ref), u34 (copy), Create_Goal_Gui (copy), GuiService (ref)
            GameMessage.SendMessage(LocalPlayer, "Press the Circles to Gain Exp!");

            while u34:GetAttribute("Meditating") do
                Create_Goal_Gui();
                task.wait(0.5);
            end;

            local SelectedObject = GuiService.SelectedObject;

            if SelectedObject and SelectedObject.Name == "Goal" then
                GuiService.SelectedObject = nil;
            end;
        end)();
    end,

    Motivation = function() -- Line: 505
        -- upvalues: LocalPlayer (copy), StatRetrieveRemote (copy), RaceChat (copy), ServerRemote (copy)
        local u42 = LocalPlayer.Character or LocalPlayer.CharacterAdded:Wait();
        local u43 = { "I have the power to achieve anything I set my mind to!", "Every challenge is an opportunity to grow stronger!", "My energy is limitless; I can conquer any obstacle!", "In this moment, I am unstoppable!", "I will rise above every doubt and fear!", "With every breath, I become more powerful and confident!", "I am a force of nature, destined for greatness!", "No setback can break my spirit; I will always persevere!", "My potential is boundless; I will reach new heights!", "I am filled with energy and determination to succeed!" };
        local u44 = { "I must focus my energy and clear my mind.", "Feel the ki flowing through my body, becoming one with the universe.", "I can sense my power growing stronger with each breath.", "In this calm, I find my true strength.", "Centering my mind brings balance to my soul.", "Every breath takes me closer to my ultimate potential.", "Patience and discipline will unlock my hidden power.", "I can feel the presence of every living being around me.", "Through meditation, I will achieve perfect harmony.", "This stillness is the key to mastering my energy." };
        local u45 = { "Am I really capable of focusing my energy?", "Why can\'t I feel the ki flowing through my body?", "Is my power truly growing stronger with each breath?", "Can I find my true strength in this calm?", "Why can\'t I center my mind and bring balance to my soul?", "Will I ever get closer to my ultimate potential?", "Do I have the patience and discipline to unlock my hidden power?", "Why can\'t I feel the presence of every living being around me?", "Will I ever achieve perfect harmony through meditation?", "Why does this stillness feel like it\'s hindering my energy?" };
        local u46 = nil;
        local u47 = false;
        local u48 = nil;
        local u49 = tick();
        task.spawn(function() -- Line: 552
            -- upvalues: u42 (copy), u47 (ref), StatRetrieveRemote (ref), u49 (ref), u48 (ref), u46 (ref), u45 (copy), u44 (copy), u43 (copy), RaceChat (ref), ServerRemote (ref)
            while u42:GetAttribute("Meditating") do
                if u47 == false then
                    local v50 = StatRetrieveRemote:InvokeServer("Motivation");
                    u47 = true;
                    u49 = tick();
                    u48 = math.random(10, 25);

                    if v50 < 35 then
                        u46 = u45[math.random(1, #u45)];
                    elseif v50 < 70 then
                        u46 = u44[math.random(1, #u44)];
                    else
                        u46 = u43[math.random(1, #u43)];
                    end;

                    RaceChat.Say(u42, u46);
                    ServerRemote:FireServer(nil, {
                        Module = "StatManager",
                        Action = "IncreaseMotivation"
                    });
                elseif u48 <= tick() - u49 then
                    u47 = false;
                end;

                task.wait();
            end;
        end);
    end,

    ["Ki Meditation"] = function() -- Line: 587
        -- upvalues: StatRetrieveRemote (copy), LocalPlayer (copy), GlobalFunctions (copy), Meditate (copy), Platform (copy), Particles (copy), Visuals (copy), u1 (copy), ServerRemote (copy), SoundManager (copy), UserInputService (copy)
        local u51 = StatRetrieveRemote:InvokeServer("MaxMeditation");
        local MeditateGui = LocalPlayer.PlayerGui.MeditateGui;
        local v52 = LocalPlayer.Character or LocalPlayer.CharacterAdded:Wait();
        local RootAndHumanoid = GlobalFunctions.GetRootAndHumanoid(v52);
        local u53 = Meditate.OuterFrame:Clone();
        local v54 = Meditate.InnerFrame:Clone();
        u53.Parent = MeditateGui;
        v54.Parent = u53;
        local TextLabel = u53:FindFirstChild("TextLabel");

        if TextLabel then
            if Platform.PreferGamepadGlyphs() then
                TextLabel.Text = "Press and Hold A to breathe in!";
            elseif Platform.IsTouch() then
                TextLabel.Text = "Press and Hold anywhere to breathe in!";
            end;
        end;

        local u55 = 0;
        local u56 = false;
        local u57 = false;
        local BackgroundColor3 = u53.BackgroundColor3;
        local Color3_fromRGB_ret = Color3.fromRGB(155, 255, 155);
        local v58 = Particles.BurstPFX:Clone();
        v58.Parent = Visuals;
        v58.CFrame = RootAndHumanoid.CFrame;
        v58.Anchored = true;
        v58.CanCollide = false;
        v58.Size = Vector3.new(1, 1, 1);
        v58.Transparency = 1;
        local u59 = v58["Lines [2]"]["Lines [2]"];
        u59.Enabled = true;
        u59.Rate = 10 * u51;

        local function Successful_Breathe() -- Line: 640
            -- upvalues: u56 (ref), u51 (ref), StatRetrieveRemote (ref), u53 (copy), Color3_fromRGB_ret (copy), u59 (copy), u1 (ref), ServerRemote (ref), u55 (ref), SoundManager (ref), RootAndHumanoid (copy), BackgroundColor3 (copy)
            u56 = true;
            u51 = StatRetrieveRemote:InvokeServer("MaxMeditation");
            u53.BackgroundColor3 = Color3_fromRGB_ret;
            u59.Rate = 10 * u51;

            if u1 <= u51 then
                ServerRemote:FireServer(nil, {
                    Module = "CoreControlHandler",
                    Action = "Meditate"
                });
                ServerRemote:FireServer(nil, {
                    Module = "KiManager",
                    Action = "Unlock"
                });
            else
                u55 = 1;
                SoundManager.AddSound("Exhale", {
                    Parent = RootAndHumanoid
                }, "Client");
                ServerRemote:FireServer(
                    nil,
                    {
                        Module = "StatManager",
                        Action = "Gain",
                        Stat = "MaxMeditation",
                        StatType = "MaxMeditation",
                        UsesGTP = false,
                        ClientVerified = true
                    }
                );
            end;

            task.delay(2, function() -- Line: 664
                -- upvalues: u53 (ref), BackgroundColor3 (ref), u56 (ref)
                u53.BackgroundColor3 = BackgroundColor3;
                u56 = false;
            end);
        end;

        local u60 = false;
        local v63 = UserInputService.InputBegan:Connect(function(p61, p62) -- Line: 674
            -- upvalues: u60 (ref)
            if p62 then
                return;
            end;

            if p61.UserInputType == Enum.UserInputType.Touch then
                u60 = true;
            end;
        end);
        local v65 = UserInputService.InputEnded:Connect(function(p64) -- Line: 678
            -- upvalues: u60 (ref)
            if p64.UserInputType == Enum.UserInputType.Touch then
                u60 = false;
            end;
        end);

        while u53.Parent ~= nil do
            local v66 = Platform.IsButtonDown(Enum.KeyCode.ButtonA);

            if (UserInputService:IsKeyDown("Space") or (u60 or v66)) and u56 == false then
                u55 = u55 + 0.008;

                if u57 == false then
                    SoundManager.AddSound("Inhale", {
                        Parent = RootAndHumanoid
                    }, "Client");
                    u57 = true;
                    task.delay(3.5, function() -- Line: 691
                        -- upvalues: u57 (ref)
                        u57 = false;
                    end);
                end;
            else
                u55 = u55 - 0.008;
            end;

            if u55 < 0 then
                u55 = 0;
            elseif u55 >= 1 then
                Successful_Breathe();
            end;

            v54.Size = UDim2.new(u55, 0, u55, 0);
            task.wait();
        end;

        v63:Disconnect();
        v65:Disconnect();
        v58:Destroy();
    end
};

return {
    MeditateActions = u67,

    Dmg = function() -- Line: 730
        -- upvalues: u67 (copy)
        u67.Dmg();
    end,

    Control = function() -- Line: 733
        -- upvalues: u67 (copy)
        u67.Control();
    end,

    Motivation = function() -- Line: 736
        -- upvalues: u67 (copy)
        u67.Motivation();
    end,

    Meditate = function(p68) -- Line: 740
        -- upvalues: StatRetrieveRemote (copy), ServerRemote (copy), u67 (copy)
        local Action = p68.Action;
        local MeditationMenu = require(script.Parent.MeditationMenu);
        ({
            Execute = function() -- Line: 744
                -- upvalues: StatRetrieveRemote (ref), MeditationMenu (copy), ServerRemote (ref), u67 (ref)
                local v69 = StatRetrieveRemote:InvokeServer("KiUnlocked");
                local v70 = StatRetrieveRemote:InvokeServer("KiControl", "Core");
                local v71 = StatRetrieveRemote:InvokeServer("KiDmg", "Core");
                MeditationMenu.Show({
                    enlightenedBase = 45,
                    kiUnlocked = v69,
                    kiControl = v70.BaseKiControl + v70.EnhancedKiControl,
                    kiDmg = v71.BaseKiDmg + v71.EnhancedKiDmg,

                    onSelectKi = function(p72) -- Line: 755, Name: onSelectKi
                        -- upvalues: MeditationMenu (ref), ServerRemote (ref), u67 (ref)
                        MeditationMenu.Hide();
                        MeditationMenu.Busy = true;
                        ServerRemote:FireServer(nil, {
                            Module = "CoreControlHandler",
                            Action = "KiMinigame",
                            TrainType = p72
                        });
                        u67[p72]();
                    end,

                    onSelectBasic = function(p73) -- Line: 770, Name: onSelectBasic
                        -- upvalues: MeditationMenu (ref), ServerRemote (ref)
                        MeditationMenu.Hide();
                        ServerRemote:FireServer(nil, {
                            Module = "CoreControlHandler",
                            Action = "Meditate",
                            TrainType = p73
                        });
                    end,

                    onClose = function() -- Line: 787, Name: onClose
                        -- upvalues: ServerRemote (ref)
                        ServerRemote:FireServer(nil, {
                            Module = "CoreControlHandler",
                            Action = "Meditate"
                        });
                    end
                });
            end,

            Terminate = function() -- Line: 793
                -- upvalues: MeditationMenu (copy)
                MeditationMenu.Busy = false;
                MeditationMenu.Hide();
                Reset_Gui();
            end
        })[Action]();
    end,

    Sleep = function(p74) -- Line: 803
        -- upvalues: Assets (copy)
        local Character = p74.Character;
        local Head = Character:FindFirstChild("Head");
        local v75 = Assets.Effects.Particles.Z_PFX:Clone();
        v75.Parent = Head;

        while Character:FindFirstChild("DeepSleep") do
            task.wait();
        end;

        v75:Destroy();
    end
};