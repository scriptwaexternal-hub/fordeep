-- Decompiled with Potassium's decompiler.

local Players = game:GetService("Players");
local ReplicatedStorage = game:GetService("ReplicatedStorage");
game:GetService("ServerStorage");
game:GetService("ServerScriptService");
game:GetService("RunService");
local Modules = ReplicatedStorage:WaitForChild("Modules");
ReplicatedStorage:WaitForChild("Remotes");
local _ = Modules.Metadata;
local _ = Modules.Shared;
local _ = Modules.Utility;
local Children = ReplicatedStorage:WaitForChild("Remotes"):GetChildren();
local u1 = {};

for _, v in ipairs(Children) do
    if v:IsA("RemoteEvent") or v:IsA("RemoteFunction") then
        u1[v.Name] = v;
    end;
end;

local function GetOriginPart(p2) -- Line: 38
    if not p2 then
        return nil;
    end;

    if p2:IsA("BasePart") then
        return p2;
    end;

    return p2:FindFirstChild("HumanoidRootPart") or p2:IsA("Model") and p2.PrimaryPart or p2:FindFirstChildWhichIsA("BasePart");
end;

function GetNearPlayers(p3, p4)
    -- upvalues: Players (copy)
    local v5 = {};
    local Players2 = Players:GetPlayers();
    local v6;

    if p3 then
        if p3:IsA("BasePart") then
            v6 = p3;
        else
            v6 = p3:FindFirstChild("HumanoidRootPart") or (p3:IsA("Model") and p3.PrimaryPart or p3:FindFirstChildWhichIsA("BasePart"));
        end;
    else
        v6 = nil;
    end;

    for _, v in ipairs(Players2) do
        local Character = v.Character;

        if Character then
            local HumanoidRootPart = Character:FindFirstChild("HumanoidRootPart");

            if p3 and (Character and (v6 and (HumanoidRootPart and ((v6.Position - HumanoidRootPart.Position).Magnitude <= p4 and Character)))) then
                v5[#v5 + 1] = v;
            end;
        end;
    end;

    return v5;
end;

return {
    FireMultipleClient = function(p7, p8, ...) -- Line: 77, Name: FireMultipleClient
        -- upvalues: Players (copy), u1 (copy)
        for _, child in ipairs(Players:GetChildren()) do
            u1[p8]:FireClient(child, ...);
        end;
    end,

    FireMultipleClientRange = function(p9, p10, p11, ...) -- Line: 83, Name: FireMultipleClientRange
        -- upvalues: u1 (copy)
        local v12 = GetNearPlayers(p9, p11 or 100);

        for _, v in ipairs(v12) do
            u1[p10]:FireClient(v, ...);
        end;
    end,

    FireOneClient = function(p13, p14, ...) -- Line: 91, Name: FireOneClient
        -- upvalues: u1 (copy)
        if not p13 then
            return;
        end;

        u1[p14]:FireClient(p13, ...);
    end
};