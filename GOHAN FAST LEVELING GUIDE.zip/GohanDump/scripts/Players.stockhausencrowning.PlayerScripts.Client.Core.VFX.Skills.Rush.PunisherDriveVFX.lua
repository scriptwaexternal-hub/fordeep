-- Decompiled with Potassium's decompiler.

local Debris = game:GetService("Debris");
local ReplicatedStorage = game:GetService("ReplicatedStorage");
local Visuals = workspace.World.Visuals;
local Effects = ReplicatedStorage.Assets.Effects;

return {
    Execute = function(p1) -- Line: 18
        -- upvalues: Effects (copy), Visuals (copy), Debris (copy)
        local Character = p1.Character;
        local Location = p1.Location;

        if not (Character and Location) then
            return;
        end;

        local v2 = p1.MOVE_TIME or 1;
        local v3 = Effects.Skills.Rush.PunisherDrive:Clone();
        v3.Name = "PunisherDrive:" .. Character.Name;
        v3.CFrame = Location * CFrame.Angles(0, 3.141592653589793, 0);
        v3.Anchored = true;
        v3.Parent = Visuals;
        Debris:AddItem(v3, v2 + 1);

        for _, child in ipairs(v3:GetChildren()) do
            if child:IsA("ParticleEmitter") then
                child.Enabled = true;
                task.delay(v2, function() -- Line: 34
                    -- upvalues: child (copy)
                    child.Enabled = false;
                end);
            end;
        end;
    end
};