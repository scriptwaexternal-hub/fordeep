-- Decompiled with Potassium's decompiler.

local function validateVector(p1, p2) -- Line: 1
    if p1 == nil then
        return false, `Invalid or missing number at position {p2} in Vector type.`;
    end;

    return true;
end;

return function(p3) -- Line: 8
    -- upvalues: validateVector (copy)
    local v4 = p3.Registry.makeSequenceType({
        length = 3,
        validate = validateVector,
        transform = tonumber,
        constructor = Vector3.new
    });
    local v5 = p3.Registry.makeSequenceType({
        length = 2,
        validate = validateVector,
        transform = tonumber,
        constructor = Vector2.new
    });
    p3.Registry.registerType("vector3", v4);
    p3.Registry.registerType("vector2", v5);
end;