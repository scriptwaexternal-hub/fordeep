-- Decompiled with Potassium's decompiler.

local Players = game:GetService("Players");
local Debris = game:GetService("Debris");
local ReplicatedStorage = game:GetService("ReplicatedStorage");
local TweenService = game:GetService("TweenService");
game:GetService("RunService");
game:GetService("UserInputService");
local Assets = ReplicatedStorage.Assets;
local Modules = ReplicatedStorage:WaitForChild("Modules");
ReplicatedStorage:WaitForChild("Remotes");
local _ = Modules.Metadata;
local _ = Modules.Utility;
local u1 = Assets.Gui["Ki Sense"];
require(Modules.Shared.SoundManager);
local GlobalFunctions = require(Modules.GlobalFunctions);
require(Modules.Effects.VfxHandler);
local LocalPlayer = Players.LocalPlayer;
local Live = workspace.World.Live;
local u2 = {
    {
        ratio = 0.34,
        color = Color3.fromRGB(95, 170, 255)
    },
    {
        ratio = 0.75,
        color = Color3.fromRGB(120, 235, 195)
    },
    {
        ratio = 1.5,
        color = Color3.fromRGB(240, 240, 240)
    },
    {
        ratio = 4,
        color = Color3.fromRGB(255, 210, 70)
    },
    {
        ratio = 12,
        color = Color3.fromRGB(255, 130, 40)
    },
    {
        ratio = (1 / 0),
        color = Color3.fromRGB(255, 60, 60)
    }
};
local u3 = {};
local u4 = {};
local u5 = {};
local u6 = {};

local function studsFor(p7) -- Line: 75
    local math_max_ret = math.max(p7, 1);
    local v8 = (math.log10(math_max_ret) - 2) / 6;

    return math.clamp(v8, 0, 1) * 24.5 + 1.5;
end;

local function tierColor(p9) -- Line: 80
    -- upvalues: u2 (copy)
    for _, v in ipairs(u2) do
        if p9 <= v.ratio then
            return v.color;
        end;
    end;

    return u2[#u2].color;
end;

local function localPowerValue() -- Line: 87
    -- upvalues: LocalPlayer (copy)
    local v10 = LocalPlayer:FindFirstChild("PlayerStats") or LocalPlayer.Character and LocalPlayer.Character:FindFirstChild("PlayerStats");

    if v10 then
        v10 = v10:FindFirstChild("PowerLevel", true);
    end;

    return v10;
end;

local function localPower() -- Line: 93
    -- upvalues: LocalPlayer (copy)
    local v11 = LocalPlayer:FindFirstChild("PlayerStats") or LocalPlayer.Character and LocalPlayer.Character:FindFirstChild("PlayerStats");

    if v11 then
        v11 = v11:FindFirstChild("PowerLevel", true);
    end;

    return v11 and v11.Value or 0;
end;

local function teardown() -- Line: 115
    -- upvalues: u3 (copy), u4 (copy), u6 (copy), u5 (copy)
    for _, v in ipairs(u3) do
        if v and v.Parent then
            v:Destroy();
        end;
    end;

    table.clear(u3);

    for _, v in ipairs(u4) do
        if v and v.Connected then
            v:Disconnect();
        end;
    end;

    table.clear(u4);

    for _, v in ipairs(u6) do
        pcall(v);
    end;

    table.clear(u6);
    table.clear(u5);
end;

local function GenerateWorld() -- Line: 136
    -- upvalues: u1 (copy), GlobalFunctions (copy), LocalPlayer (copy), u2 (copy), TweenService (copy), u3 (copy), u4 (copy), u5 (copy), u6 (copy), Players (copy), Live (copy)
    local function CreateOrb(p12: any, u13: userdata) -- Line: 137
        -- upvalues: u1 (ref), GlobalFunctions (ref), LocalPlayer (ref), u2 (ref), TweenService (ref), u3 (ref), u4 (ref), u5 (ref), u6 (ref)
        local HumanoidRootPart = p12:FindFirstChild("HumanoidRootPart");

        if not HumanoidRootPart then
            return;
        end;

        local u14 = u1["Ki Bubble"]:Clone();
        u14.Adornee = HumanoidRootPart;
        u14.ExtentsOffset = Vector3.new(0, 0, 0);
        u14.ExtentsOffsetWorldSpace = Vector3.new(0, 0, 0);
        u14.StudsOffset = Vector3.new(0, 0, 0);
        u14.StudsOffsetWorldSpace = Vector3.new(0, 0, 0);
        u14.SizeOffset = Vector2.zero;
        u14.Parent = p12;
        local Frame = u14.Frame;
        Frame.AnchorPoint = Vector2.new(0.5, 0.5);
        Frame.Position = UDim2.fromScale(0.5, 0.5);
        Frame.Size = UDim2.fromScale(1, 1);
        local u15 = nil;

        local function refresh(p16) -- Line: 171
            -- upvalues: u13 (copy), GlobalFunctions (ref), u14 (copy), LocalPlayer (ref), Frame (copy), u2 (ref), u15 (ref), TweenService (ref)
            local math_max_ret = math.max(u13.Value, 1);
            local v17 = (math.log10(math_max_ret) - 2) / 6;
            local v18 = math.clamp(v17, 0, 1) * 24.5 + 1.5;
            local UDim2_new_ret = UDim2.new(v18, 10, v18, 10);

            if p16 then
                GlobalFunctions.Tween({
                    Duration = 0.4,
                    Instance = u14
                }, {
                    Size = UDim2_new_ret
                });
            else
                u14.Size = UDim2_new_ret;
            end;

            local v19 = LocalPlayer:FindFirstChild("PlayerStats") or LocalPlayer.Character and LocalPlayer.Character:FindFirstChild("PlayerStats");

            if v19 then
                v19 = v19:FindFirstChild("PowerLevel", true);
            end;

            local v20 = v19 and v19.Value or 0;
            local v21 = v20 > 0 and u13.Value / v20 or 1;
            local v22;

            for _, v in ipairs(u2) do
                if v21 <= v.ratio then
                    v22 = v.color;
                    break;
                end;
            end;

            v22 = u2[#u2].color;
            Frame.BackgroundColor3 = v22;

            if u15 then
                u15:Cancel();
                u15 = nil;
            end;

            Frame.BackgroundTransparency = 0.45;

            if v21 >= 4 then
                u15 = TweenService:Create(Frame, TweenInfo.new(0.7, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut, -1, true), {
                    BackgroundTransparency = 0.12
                });
                u15:Play();
            end;
        end;

        refresh(false);
        table.insert(u3, u14);
        table.insert(u4, u13.Changed:Connect(function() -- Line: 204
            -- upvalues: refresh (copy)
            refresh(true);
        end));
        table.insert(u5, refresh);
        table.insert(u6, function() -- Line: 206
            -- upvalues: u15 (ref)
            if u15 then
                u15:Cancel();
            end;
        end);
    end;

    local function assign_character(p23) -- Line: 211
        -- upvalues: Players (ref), CreateOrb (copy)
        local PlayerFromCharacter = Players:GetPlayerFromCharacter(p23);
        local v24 = PlayerFromCharacter and PlayerFromCharacter:FindFirstChild("PlayerStats") or p23:FindFirstChild("PlayerStats");

        if not v24 then
            return;
        end;

        local PowerLevel = v24:FindFirstChild("PowerLevel", true);

        if not PowerLevel then
            return;
        end;

        local Race = v24:FindFirstChild("Race", true);

        if (Race and Race.Value ~= "" and Race.Value or p23:GetAttribute("Race")) == "Android" then
            return;
        end;

        CreateOrb(p23, PowerLevel);
    end;

    for _, child in pairs(Live:GetChildren()) do
        if child:IsA("Folder") then
            for _, child2 in pairs(child:GetChildren()) do
                assign_character(child2);
            end;
        else
            assign_character(child);
        end;
    end;

    local v25 = LocalPlayer:FindFirstChild("PlayerStats") or LocalPlayer.Character and LocalPlayer.Character:FindFirstChild("PlayerStats");

    if v25 then
        v25 = v25:FindFirstChild("PowerLevel", true);
    end;

    if v25 then
        table.insert(u4, v25.Changed:Connect(function() -- Line: 247
            -- upvalues: u5 (ref)
            for _, v in ipairs(u5) do
                v(false);
            end;
        end));
    end;
end;

LocalPlayer.CharacterRemoving:Connect(function() -- Line: 327
    -- upvalues: teardown (copy), LocalPlayer (copy)
    teardown();
    local PlayerGui = LocalPlayer:FindFirstChild("PlayerGui");

    if PlayerGui then
        PlayerGui = PlayerGui:FindFirstChild("KiSenseGui");
    end;

    if PlayerGui then
        PlayerGui = PlayerGui:FindFirstChild("Dark Frame");
    end;

    if PlayerGui then
        PlayerGui.BackgroundTransparency = 1;
    end;
end);

return {
    On = function() -- Line: 257
        -- upvalues: LocalPlayer (copy), teardown (copy), GlobalFunctions (copy), GenerateWorld (copy)
        local v26 = LocalPlayer.PlayerGui.KiSenseGui["Dark Frame"];
        teardown();
        GlobalFunctions.Tween({
            Duration = 0.5,
            Instance = v26
        }, {
            BackgroundTransparency = 0.35
        });
        GenerateWorld();
    end,

    Off = function() -- Line: 268
        -- upvalues: LocalPlayer (copy), GlobalFunctions (copy), teardown (copy)
        GlobalFunctions.Tween({
            Duration = 0.5,
            Instance = LocalPlayer.PlayerGui.KiSenseGui["Dark Frame"]
        }, {
            BackgroundTransparency = 1
        });
        teardown();
    end,

    Reveal = function() -- Line: 275
        -- upvalues: LocalPlayer (copy), Assets (copy), Debris (copy)
        local Character = LocalPlayer.Character;
        Character.Archivable = true;
        local PopupGui = LocalPlayer.PlayerGui.PopupGui;
        local v27 = Assets.Gui.Combat.Reveal.RevealGui:Clone();
        v27.Parent = PopupGui;
        local v28 = v27.Background["Red Line"];
        v28.Size = UDim2.new(0, 0, 0.046, 0);
        local Camera = Instance.new("Camera");
        Camera.Parent = v27;
        v27.CurrentCamera = Camera;
        local v29 = Character:Clone();
        v29.Parent = v27;
        Camera.CFrame = v29.HumanoidRootPart.CFrame * CFrame.new(2.2, 1, -2.2);
        Camera.CFrame = CFrame.lookAt(Camera.CFrame.Position, v29.Head.CFrame.Position);
        v28:TweenSize(UDim2.new(1, 0, 0.046, 0), "Out", "Sine", 0.5);
        Debris:AddItem(v27, 2);
    end
};