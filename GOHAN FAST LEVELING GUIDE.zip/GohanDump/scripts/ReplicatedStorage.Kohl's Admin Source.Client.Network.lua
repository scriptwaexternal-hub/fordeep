-- Decompiled with Potassium's decompiler.

local Parent = require(script.Parent.Parent);
local UI = Parent.UI;
Parent.client.updateInterfaceAuth = Parent.Util.Function.debounce(0.2, function() -- Line: 4
    -- upvalues: Parent (copy)
    local UserId = Parent.LocalPlayer.UserId;
    local Rank = Parent.Auth.getRank(UserId);
    Parent.client.rank(Rank);
    local _value = Parent.client.settings.commandBarRank._value;
    local _value2 = Parent.client.settings.dashboardRank._value;
    local _value3 = Parent.client.settings.commandsButtonRank._value;
    local _value4 = Parent.client.settings.dashboardButtonRank._value;
    local v1 = _value == nil and 0 or _value;
    local v2 = _value2 == nil and 0 or _value2;
    local v3 = _value4 == nil and 0 or _value4;

    if v1 then
        v1 = v1 <= Rank;
    end;

    Parent.client.commandBarEnabled = v1;

    if v2 then
        v2 = v2 <= Rank;
    end;

    Parent.client.dashboardEnabled = v2;
    local dashboardEnabled = Parent.client.dashboardEnabled;

    if dashboardEnabled then
        if v3 then
            v3 = v3 <= Rank;
        end;
    else
        v3 = dashboardEnabled;
    end;

    Parent.client.dashboardButtonEnabled = v3;
    local v4 = not Parent.client.dashboardButtonEnabled;

    if v4 then
        if _value3 then
            _value3 = _value3 <= Rank;
        end;
    else
        _value3 = v4;
    end;

    Parent.client.commandsButtonEnabled = _value3;
    Parent.client.toggleCommandBar._instance.Visible = Parent.client.commandBarEnabled;

    if not Parent.client.commandBarEnabled and (Parent.client.CommandBar and Parent.client.CommandBar.Bar.Visible) then
        Parent.client.CommandBar.hide();
    end;

    if typeof(Parent.client.dashboardButton) == "Instance" and Parent.client.dashboardButton:IsA("GuiObject") then
        Parent.client.dashboardButton.Visible = Parent.client.dashboardButtonEnabled;
    else
        Parent.client.dashboardButton:setEnabled(Parent.client.dashboardButtonEnabled);
    end;

    if typeof(Parent.client.commandsButton) == "Instance" and Parent.client.commandsButton:IsA("GuiObject") then
        Parent.client.commandsButton.Visible = Parent.client.commandsButtonEnabled;
    else
        Parent.client.commandsButton:setEnabled(Parent.client.commandsButtonEnabled);
    end;

    if not Parent.client.dashboardEnabled then
        Parent.client.dashboard.Window._instance.Visible = false;
    end;

    Parent.client.dashboard.Bans._instance:SetAttribute("Enabled", Parent.Auth.hasCommand(UserId, "bans"));
    Parent.client.dashboard.Logs._instance:SetAttribute("Enabled", Parent.Auth.hasCommand(UserId, "logs"));
    Parent.client.dashboard.Members._instance:SetAttribute("Enabled", Parent.Auth.hasCommand(UserId, "members"));
    Parent.client.dashboard.Settings._instance:SetAttribute("Enabled", Parent.Auth.hasCommand(UserId, "settings"));

    for _, v in Parent.Registry.commands do
        v.LocalPlayerAuthorized = Parent.Auth.hasCommand(UserId, v);

        if not v.RestrictedToRole then
            local v5 = v;

            for _, v6 in Parent.Data.rolesList do
                if Parent.Auth.roleCanUseCommand(v6._key, v5) then
                    v5.RestrictedToRole = v6;
                    break;
                end;
            end;
        end;
    end;

    Parent.client.dashboard.Commands:updateList();
    Parent.client.CommandBar.updateCompletionData();

    if Parent.Registry.commands.tools and Parent.Registry.commands.tools.LocalPlayerAuthorized then
        Parent.Remote.Tools:Fire();
    end;

    Parent.Hook.authChanged:Fire();
end);
Parent.client.settings.commandBarRank:Connect(Parent.client.updateInterfaceAuth);
Parent.client.settings.dashboardRank:Connect(Parent.client.updateInterfaceAuth);
Parent.client.settings.dashboardButtonRank:Connect(Parent.client.updateInterfaceAuth);
Parent.Remote.Announce:Connect(Parent.Announce);
Parent.Remote.Notify:Connect(Parent.Notify);
Parent.Remote.SetCore:Connect(function(p6: string, p7: any) -- Line: 87
    -- upvalues: Parent (copy)
    Parent.Service.StarterGui:SetCore(p6, p7);
end);
local u8 = {};

function Parent.Remote.RequestCommand.OnInvoke(p9: userdata, p10: string) -- Line: 92
    -- upvalues: u8 (copy), Parent (copy), UI (copy)
    if not u8[p9.UserId] then
        u8[p9.UserId] = true;
        local u11 = Parent.Util.Signal.new();
        Parent.Notify({
            Text = `\t<font transparency="0.5">{p10}</font>`,
            ActionText = "Permit this action?",
            Action = true,
            ExitButton = false,
            LeftAction = true,
            RightAction = true,
            Duration = 30,
            Parent.client.UserFrame(p9.UserId, p9.DisplayName),
            [UI.Hook] = {
                Action = function(p12) -- Line: 111, Name: Action
                    -- upvalues: u11 (copy)
                    u11:Fire(p12);
                end
            }
        });
        task.delay(30, u11.Fire, u11, false);
        local v13 = u11:Wait() == true;
        u8[p9.UserId] = nil;

        return v13;
    end;
end;

Parent.Remote.Ban:Connect(function(p14, p15) -- Line: 126
    -- upvalues: Parent (copy)
    Parent.Data.bans[p14] = p15;
    Parent.client.bans(Parent.Data.bans);
end);
Parent.Remote.Bans:Connect(function(p16) -- Line: 131
    -- upvalues: Parent (copy)
    if p16 then
        Parent.Data.bans = p16;
        Parent.client.bans(Parent.Data.bans);
    end;
end);
Parent.Remote.DisplayBubble:Connect(function(p17: userdata, p18: string) -- Line: 138
    -- upvalues: Parent (copy)
    Parent.Service.TextChat:DisplayBubble(p17, p18);
end);
Parent.Remote.Member:Connect(function(p19, p20) -- Line: 142
    -- upvalues: Parent (copy)
    local viewas = Parent.Registry.commands.viewas;

    if viewas.env.originalMember and p19 == tostring(Parent.LocalPlayer.UserId) then
        viewas.env.originalMember = p20;
        p20 = Parent.Data.members[p19];
    end;

    Parent.Data.members[p19] = p20;
    Parent.client.members(Parent.Data.members);
    Parent.client.updateInterfaceAuth();
end);
Parent.Remote.Members:Connect(function(p21) -- Line: 154
    -- upvalues: Parent (copy)
    local viewas = Parent.Registry.commands.viewas;

    if viewas.env.originalMember then
        local v22 = tostring(Parent.LocalPlayer.UserId);

        for i, v in p21 do
            if i == v22 then
                viewas.env.originalMember = v;
                p21[i] = Parent.Data.members[i];
                break;
            end;
        end;
    end;

    Parent.Data.members = p21;
    Parent.client.members(Parent.Data.members);
    Parent.client.updateInterfaceAuth();
end);
Parent.Remote.Log:Connect(function(p23) -- Line: 172
    -- upvalues: Parent (copy)
    if not Parent.ready then
        return;
    end;

    table.insert(Parent.Data.logs, p23);
    Parent.removeExcessLogs();
    task.defer(Parent.client.dashboard.Logs.updateList, Parent.client.dashboard.Logs);
end);
Parent.Remote.Logs:Connect(function(p24) -- Line: 184
    -- upvalues: Parent (copy)
    if not Parent.ready then
        return;
    end;

    Parent.Util.Defer.reset();
    local success, result = pcall(Parent.Z.des, Parent.Data.Schema.logsRemote, p24);

    if not success then
        warn(result);

        return;
    end;

    Parent.Util.Defer.wait();
    table.move(result, 1, #result, #Parent.Data.logs + 1, Parent.Data.logs);
    Parent.Util.Defer.wait();
    table.sort(Parent.Data.logs, Parent.Logger.sortTime);
    Parent.Util.Defer.wait();
    Parent.removeExcessLogs();
    Parent.client.dashboard.Logs:updateList();
end);
Parent.Remote.Settings:Connect(function(p25) -- Line: 211
    -- upvalues: Parent (copy), UI (copy)
    if p25.announcement and not Parent.Data.savedSettings.announcement then
        local v26, v27 = unpack(p25.announcement);
        Parent.Announce({
            Duration = 0,
            From = v27,
            Text = v26
        });
    end;

    local v28 = Parent.Data.savedSettings.useSavedSettings or p25.useSavedSettings;

    for i, v in p25 do
        local v29 = UI.raw(v);

        if i == "theme" or (string.find(i, "theme", 1, true) ~= 1 or Parent.Data.settings.changeThemeAuthority ~= "Studio" and p25.theme == "Custom (DataStore)") then
            Parent.Data.savedSettings[i] = v29;

            if v28 and Parent.client.settings[i] then
                Parent.client.settings[i](v29);
            end;
        end;
    end;

    Parent.client.updateInterfaceAuth();
end);
Parent.Remote.Role:Connect(function(p30, p31) -- Line: 239
    -- upvalues: Parent (copy)
    Parent.Data.roles[p30] = p31;
    Parent.client.updateInterfaceAuth();
end);
Parent.Remote.Roles:Connect(function(p32) -- Line: 244
    -- upvalues: Parent (copy)
    Parent.Util.Table.merge(Parent.Data.roles, p32);
    Parent.client.updateInterfaceAuth();
end);
Parent.Remote.RolesNotification:Connect(function() -- Line: 249
    -- upvalues: Parent (copy)
    Parent.client.rolesNotification();
end);

return true;