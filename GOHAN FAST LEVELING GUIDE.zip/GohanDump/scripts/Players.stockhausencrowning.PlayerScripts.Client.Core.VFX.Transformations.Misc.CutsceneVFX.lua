-- Decompiled with Potassium's decompiler.

local Players = game:GetService("Players");
local Debris = game:GetService("Debris");
local ReplicatedStorage = game:GetService("ReplicatedStorage");
local RunService = game:GetService("RunService");
game:GetService("CollectionService");
game:GetService("UserInputService");
local Modules = ReplicatedStorage:WaitForChild("Modules");
ReplicatedStorage:WaitForChild("Remotes");
ReplicatedStorage:WaitForChild("Assets");
local Metadata = Modules.Metadata;
local Shared = Modules.Shared;
local _ = Modules.Utility;
local u1 = ReplicatedStorage.Assets.Effects["Cutscene Effects"];
require(Shared.SoundManager);
local GlobalFunctions = require(Modules.GlobalFunctions);
require(Shared.SoundManager);
require(Shared.CamManager);
local CinemaManager = require(Shared.CinemaManager);
local CoreControls = require(Metadata.ControlData.ControlData).Controls.CoreControls;
local v2 = script:FindFirstAncestor("VFX");
require(v2:FindFirstChild("ChargeVFX", true));
local AnimationManager = require(Shared.AnimationManager);
local _ = ReplicatedStorage.Remotes.ServerRemote;
local LocalPlayer = Players.LocalPlayer;
local Visuals = workspace.World.Visuals;
local u3 = nil;

return {
    SSJ2 = function(p4) -- Line: 81
        -- upvalues: GlobalFunctions (copy), u3 (ref), u1 (copy), Visuals (copy), Debris (copy), CoreControls (copy), CinemaManager (copy), LocalPlayer (copy), AnimationManager (copy), RunService (copy)
        local Character = p4.Character;
        local RootAndHumanoid = GlobalFunctions.GetRootAndHumanoid(Character);

        if not RootAndHumanoid then
            return;
        end;

        if u3 then
            u3.finish();
        end;

        local u5 = u1.SSJ2["SSJ2 Cam Rig"]:Clone();
        u5.Parent = Visuals;
        u5:SetPrimaryPartCFrame(RootAndHumanoid.CFrame * CFrame.new(0, -2, 0) * CFrame.Angles(0, 3.141592653589793, 0));
        Debris:AddItem(u5, 15);
        local u6 = {};
        local u7 = false;
        local u8 = {};
        local u9 = false;

        local function finish() -- Line: 99
            -- upvalues: u7 (ref), u3 (ref), u8 (copy), u6 (copy), u9 (ref), CoreControls (ref), CinemaManager (ref), LocalPlayer (ref), u5 (copy)
            if u7 then
                return;
            end;

            u7 = true;

            if u3 == u8 then
                u3 = nil;
            end;

            for _, v in ipairs(u6) do
                pcall(function() -- Line: 104
                    -- upvalues: v (copy)
                    v:Disconnect();
                end);
            end;

            if not u3 and workspace.Camera.CameraType == Enum.CameraType.Scriptable then
                workspace.Camera.CameraType = Enum.CameraType.Custom;
            end;

            if u9 and CoreControls.CinemaOn then
                CoreControls.CinemaOn = false;
                CinemaManager.FadeOut(LocalPlayer);
            end;

            if u5.Parent then
                u5:Destroy();
            end;
        end;

        u8.finish = finish;
        u3 = u8;

        if CoreControls.CinemaOn then
            u9 = false;
        else
            CoreControls.CinemaOn = true;
            CinemaManager.FadeIn(LocalPlayer, nil, {
                Strict = true
            });
            u9 = true;
        end;

        local v10 = AnimationManager.PlayAnimation(u5, "SSJ2 Cutscene [Camera]", {
            Looped = false
        });

        if not v10 then
            finish();

            return;
        end;

        workspace.Camera.CameraType = Enum.CameraType.Scriptable;
        table.insert(u6, RunService.Heartbeat:Connect(function() -- Line: 130
            -- upvalues: u5 (copy), finish (copy)
            local v11 = u5.Parent and u5:FindFirstChild("Torso");

            if v11 then
                workspace.Camera.CFrame = v11.CFrame;

                return;
            end;

            finish();
        end));
        v10.Ended:Once(finish);
        v10.Stopped:Once(finish);
        local v12 = Character:FindFirstChildOfClass("Humanoid");

        if v12 then
            table.insert(u6, v12.Died:Once(finish));
        end;

        table.insert(u6, Character.AncestryChanged:Connect(function() -- Line: 147
            -- upvalues: Character (copy), finish (copy)
            if not Character.Parent then
                finish();
            end;
        end));
        task.delay(12, finish);
    end,

    ForceCinemaOn = function() -- Line: 66, Name: forceCinemaOn
        -- upvalues: CoreControls (copy), CinemaManager (copy), LocalPlayer (copy)
        if CoreControls.CinemaOn then
            return false;
        end;

        CoreControls.CinemaOn = true;
        CinemaManager.FadeIn(LocalPlayer, nil, {
            Strict = true
        });

        return true;
    end,

    ReleaseCinema = function(p13) -- Line: 73, Name: releaseCinema
        -- upvalues: CoreControls (copy), CinemaManager (copy), LocalPlayer (copy)
        if not p13 then
            return;
        end;

        if not CoreControls.CinemaOn then
            return;
        end;

        CoreControls.CinemaOn = false;
        CinemaManager.FadeOut(LocalPlayer);
    end
};