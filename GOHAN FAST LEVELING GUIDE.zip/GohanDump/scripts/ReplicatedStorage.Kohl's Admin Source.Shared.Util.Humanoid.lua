-- Decompiled with Potassium's decompiler.

local u1 = {};
local u2 = { "Head", "Face", "Shirt", "Pants", "GraphicTShirt", "HeadColor", "LeftArmColor", "LeftLegColor", "RightArmColor", "RightLegColor", "TorsoColor" };
local u3 = { "_KFire", "_KSmoke", "_KSparkles", "_KLight", "_KParticleEffect" };

function u1.applyDescription(p4, p5) -- Line: 18
    p4:ApplyDescriptionReset(p5);
    p4:ApplyDescription(p5);
end;

function u1.updateDescription(p6, p7, p8, p9, p10) -- Line: 23
    local v11 = ("_K" .. p9) .. "Original";

    if not p6:GetAttribute(v11) then
        p6:SetAttribute(v11, p8[p9]);
    end;

    p8[p9] = p10 or p6:GetAttribute(v11);
end;

function u1.reapplyDescription(p12) -- Line: 32
    -- upvalues: u2 (copy), u1 (copy)
    local v13 = p12.Character and p12.Character:FindFirstChildOfClass("Humanoid");
    local v14;

    if v13 then
        v14 = v13:FindFirstChildOfClass("HumanoidDescription");
    else
        v14 = v13;
    end;

    if not v14 then
        return;
    end;

    local v15 = nil;

    for _, v in u2 do
        local Attribute = p12:GetAttribute("_K" .. v);

        if Attribute then
            u1.updateDescription(p12, v13, v14, v, Attribute);
            v15 = true;
        end;
    end;

    if v15 then
        u1.applyDescription(v13, v14);
    end;
end;

function u1.attributeDescription(p16, p17, p18) -- Line: 53
    -- upvalues: u1 (copy)
    local v19 = p16.Character and p16.Character:FindFirstChildOfClass("Humanoid");
    local v20;

    if v19 then
        v20 = v19:FindFirstChildOfClass("HumanoidDescription");
    else
        v20 = v19;
    end;

    if not v20 then
        return;
    end;

    u1.updateDescription(p16, v19, v20, p17, p18);
    p16:SetAttribute("_K" .. p17, p18);
    u1.applyDescription(v19, v20);
end;

function u1.resetDescription(p21) -- Line: 66
    -- upvalues: u3 (copy), u2 (copy), u1 (copy)
    local v22 = p21.Character and p21.Character:FindFirstChild("HumanoidRootPart") or p21.Character.PrimaryPart;

    if v22 then
        for _, v in u3 do
            local v23 = v22:FindFirstChild(v);

            if v23 then
                v23:Destroy();
            end;
        end;
    end;

    local v24 = p21.Character and p21.Character:FindFirstChildOfClass("Humanoid");
    local v25;

    if v24 then
        v25 = v24:FindFirstChildOfClass("HumanoidDescription");
    else
        v25 = v24;
    end;

    local _KHumanoidDescription = p21:FindFirstChild("_KHumanoidDescription");

    if _KHumanoidDescription then
        v25:Destroy();
        _KHumanoidDescription.Name = "HumanoidDescription";
        _KHumanoidDescription.Parent = v24;
    else
        _KHumanoidDescription = v25;
    end;

    for _, v in u2 do
        local v26 = ("_K" .. v) .. "Original";
        local Attribute = p21:GetAttribute(v26);

        if Attribute ~= nil then
            p21:SetAttribute(v26, nil);

            if _KHumanoidDescription then
                _KHumanoidDescription[v] = Attribute;
            end;
        end;
    end;

    if v24 and _KHumanoidDescription then
        u1.applyDescription(v24, _KHumanoidDescription);
    end;
end;

return u1;