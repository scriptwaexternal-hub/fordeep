-- Decompiled with Potassium's decompiler.

game:GetService("Players");
local ReplicatedStorage = game:GetService("ReplicatedStorage");
game:GetService("ServerScriptService");
local Debris = game:GetService("Debris");
game:GetService("Chat");
local Modules = ReplicatedStorage:WaitForChild("Modules");
local Metadata = Modules.Metadata;
local Shared = Modules.Shared;
local _ = Modules.Utility;
ReplicatedStorage:WaitForChild("Remotes");
local u1 = {};
local Assets = ReplicatedStorage.Assets;
local SkinColorHandler = require(Metadata.CharacterData.SkinColorHandler);
require(Metadata.RaceData.Arcosian.ArmorColorData);
local ScaleModel = require(Shared.ScaleModel);
local GlobalFunctions = require(Modules.GlobalFunctions);
local RaceParts = Assets.RaceParts;
local Clothing = Assets.Clothing;

local function Change_Clothes_And_Color(p2, p3) -- Line: 40
    -- upvalues: Clothing (copy), SkinColorHandler (copy)
    local Race = p3.CharacterData.Race.Race;

    for _, child in pairs(p2:GetChildren()) do
        if child:IsA("Clothing") then
            child:Destroy();
        elseif child:IsA("BodyColors") then
            child:Destroy();
        end;
    end;

    local Children = Clothing["Race Clothes"][Race]["Starter Clothes"]["Outfit 1"]:GetChildren();

    for _, v in pairs(Children) do
        v:Clone().Parent = p2;
    end;

    SkinColorHandler.Give(p3, p2);
end;

function u1.Fire(u4, u5, u6) -- Line: 62
    -- upvalues: RaceParts (copy), Change_Clothes_And_Color (copy)
    local u7 = RaceParts.Arcosian:FindFirstChild(u5, true):Clone();

    if not u7 then
        warn("Armor Not Found");

        return;
    end;

    local SkinColor = u6.CharacterData.SkinColor;
    local SecondarySkinColor = u6.CharacterData.SecondarySkinColor;
    local u8 = typeof(SkinColor) ~= "table" and {
        Red = 255,
        Green = 255,
        Blue = 255
    } or SkinColor;
    local u9 = typeof(SecondarySkinColor) ~= "table" and {
        Red = 0,
        Green = 0,
        Blue = 0
    } or SecondarySkinColor;

    if not u4 then
        return;
    end;

    local u10 = {
        Armor4 = true
    };
    local u11 = {
        Armor5 = true
    };

    local function Find_Tail_Change_Color() -- Line: 89
        -- upvalues: u8 (ref), u4 (copy), u11 (copy), u5 (copy), u10 (copy), u9 (ref)
        local Color3_fromRGB_ret = Color3.fromRGB(u8.Red, u8.Green, u8.Blue);

        for _, descendant in pairs(u4:GetDescendants()) do
            if descendant.Name == "Arcosian Tail" then
                if u11[u5] then
                    if descendant.Tail then
                        descendant.Tail.Color = Color3_fromRGB_ret;
                    end;

                    if descendant.Tail_End then
                        descendant.Tail_End.Color = Color3_fromRGB_ret;
                    end;
                elseif u10[u5] then
                    if descendant.Tail then
                        descendant.Tail.Color = Color3.fromRGB(255, 255, 255);
                    end;

                    if descendant.Tail_End then
                        descendant.Tail_End.Color = Color3.fromRGB(255, 255, 255);
                    end;
                else
                    if descendant.Tail then
                        descendant.Tail.Color = Color3_fromRGB_ret;
                    end;

                    if descendant.Tail_End then
                        descendant.Tail_End.Color = Color3.fromRGB(u9.Red, u9.Green, u9.Blue);
                    end;
                end;
            end;
        end;
    end;

    local function Arcosian_Head() -- Line: 124
        -- upvalues: u6 (copy), RaceParts (ref), u4 (copy), u9 (ref)
        local SkinColor2 = u6.CharacterData.SkinColor;
        local v12 = u6.CharacterData.HairType or 1;
        local v13 = typeof(SkinColor2) == "string" and {
            Red = 255,
            Green = 255,
            Blue = 255
        } or SkinColor2;

        for _, child in pairs(RaceParts.Arcosian.Form1.Heads:GetChildren()) do
            if child.Name == "Head" .. v12 then
                local v14 = child:Clone();
                v14.Name = "Bio-Armor";
                require(game:GetService("ReplicatedStorage").Modules.Metadata.CharacterData.ClothesHandler).AttachCosmetic(u4, v14);
                v14:ScaleTo(u4:GetScale());
                local v15 = v14["Second Color"]:FindFirstChildOfClass("Attachment");

                if v15 then
                    local Weld = Instance.new("Weld");
                    Weld.Parent = v14;
                    Weld.Part0 = v14["Second Color"];
                    Weld.Part1 = u4.Head;
                    Weld.C0 = v15.CFrame;
                end;

                for _, descendant in pairs(v14:GetDescendants()) do
                    if descendant.Name == "Colorable" and (descendant:IsA("Part") or descendant:IsA("MeshPart")) then
                        descendant.Color = Color3.fromRGB(v13.Red * 0.5, v13.Green * 0.5, v13.Blue * 0.5);
                        local SurfaceAppearance = descendant:FindFirstChild("SurfaceAppearance");

                        if SurfaceAppearance then
                            SurfaceAppearance.Color = descendant.Color;
                        end;
                    elseif descendant.Name == "Second Color" and (descendant:IsA("Part") or descendant:IsA("MeshPart")) then
                        descendant.Color = Color3.fromRGB(u9.Red, u9.Green, u9.Blue);
                        local SurfaceAppearance = descendant:FindFirstChild("SurfaceAppearance");

                        if SurfaceAppearance then
                            SurfaceAppearance.Color = descendant.Color;
                        end;
                    end;
                end;

                return;
            end;
        end;
    end;

    local function Color_Armor() -- Line: 176
        -- upvalues: u10 (copy), u5 (copy), Change_Clothes_And_Color (ref), u4 (copy), u6 (copy), u7 (copy), u8 (ref), u9 (ref)
        if not u10[u5] then
            Change_Clothes_And_Color(u4, u6);
        end;

        for _, descendant in pairs(u7:GetDescendants()) do
            if descendant.Name == "Colorable" and (descendant:IsA("Part") or descendant:IsA("MeshPart")) then
                descendant.Color = Color3.fromRGB(u8.Red, u8.Green, u8.Blue);
                local SurfaceAppearance = descendant:FindFirstChild("SurfaceAppearance");

                if SurfaceAppearance then
                    SurfaceAppearance.Color = Color3.fromRGB(u8.Red, u8.Green, u8.Blue);
                end;
            elseif descendant.Name == "Second Color" and (descendant:IsA("Part") or descendant:IsA("MeshPart")) then
                descendant.Color = Color3.fromRGB(u9.Red, u9.Green, u9.Blue);
                local SurfaceAppearance = descendant:FindFirstChild("SurfaceAppearance");

                if SurfaceAppearance then
                    SurfaceAppearance.Color = descendant.Color;
                end;
            end;
        end;
    end;

    local function Attach_Armor() -- Line: 203
        -- upvalues: u7 (copy), u4 (copy)
        for _, child in pairs(u7:GetChildren()) do
            local v16 = child;

            for _, child2 in pairs(u4:GetChildren()) do
                if child2:IsA("BasePart") and (v16.Name == child2.Name and (child2.Transparency ~= 1 or child2.Name ~= "Left Arm")) then
                    local v17 = v16:Clone();
                    v17.Name = "Bio-Armor";
                    require(game:GetService("ReplicatedStorage").Modules.Metadata.CharacterData.ClothesHandler).AttachCosmetic(u4, v17);
                    local v18 = child2;

                    for _, child3 in pairs(v17:GetChildren()) do
                        local v19 = child3:FindFirstChildOfClass("Attachment");

                        if child3 and v19 then
                            local Weld = Instance.new("Weld");
                            Weld.Parent = v17;
                            Weld.Part0 = child3;
                            Weld.Part1 = v18;
                            Weld.C0 = v19.CFrame;
                        end;
                    end;
                end;
            end;
        end;
    end;

    u7:ScaleTo(u4:GetScale());

    if u5 == "Armor1" then
        Arcosian_Head();
    end;

    if u9 then
        for _, descendant in ipairs(u7:GetDescendants()) do
            if descendant:IsA("BasePart") and descendant:GetAttribute("SecondaryColor") then
                descendant.Color = Color3.fromRGB(u9.Red, u9.Green, u9.Blue);
            end;
        end;
    end;

    Find_Tail_Change_Color();
    Color_Armor();
    Attach_Armor();

    if u5 == "Armor5" then
        for _, descendant in ipairs(u4:GetDescendants()) do
            if descendant:IsA("Weld") and (descendant.Part0 and descendant.Part0.Name:sub(1, 10) == "Face Guard") then
                descendant.C0 = descendant.C0 * CFrame.new(0, 0.3, 0);
                descendant.Part0:SetAttribute("GuardTransparency", descendant.Part0.Transparency);
                descendant.Part0.Transparency = 1;
            end;
        end;
    end;

    u7:Destroy();
end;

function u1.Remove(p20, p21) -- Line: 289
    -- upvalues: GlobalFunctions (copy), Debris (copy)
    if not p21 then
        p21 = {};

        for _, descendant in ipairs(p20:GetDescendants()) do
            if descendant.Name == "Bio-Armor" then
                table.insert(p21, descendant);
            end;
        end;
    end;

    for _, v in ipairs(p21) do
        if v.Parent then
            for _, descendant in pairs(v:GetDescendants()) do
                if descendant:IsA("MeshPart") or descendant:IsA("Part") then
                    GlobalFunctions.Tween({
                        Duration = 1,
                        Instance = descendant
                    }, {
                        Size = descendant.Size * 0.01
                    });
                end;
            end;

            Debris:AddItem(v, 1);
        end;
    end;
end;

function u1.Revert(p22, p23) -- Line: 337
    -- upvalues: GlobalFunctions (copy), ScaleModel (copy), u1 (copy)
    local Form = p22:FindFirstChild("PlayerStats"):FindFirstChild("Form", true);
    local Character = p22.Character;
    local Height = p23.CharacterData.Height;
    Form.Value = "None";
    (function() -- Line: 345, Name: Highlight
        -- upvalues: Character (copy), GlobalFunctions (ref)
        local Highlight = Instance.new("Highlight");
        Highlight.Parent = Character;
        Highlight.OutlineColor = Color3.fromRGB(255, 255, 255);
        Highlight.FillColor = Color3.fromRGB(255, 255, 255);
        Highlight.OutlineTransparency = 0;
        Highlight.FillTransparency = 0;
        GlobalFunctions.Tween({
            Duration = 0.1,
            Instance = Highlight
        }, {
            FillTransparency = 0,
            OutlineTransparency = 0
        });
        task.delay(2, function() -- Line: 356
            -- upvalues: GlobalFunctions (ref), Highlight (copy)
            GlobalFunctions.Tween({
                Duration = 0.1,
                Instance = Highlight
            }, {
                FillTransparency = 1,
                OutlineTransparency = 1
            });
        end);
    end)();
    ScaleModel.ScaleDown({
        Speed = 1,
        MaxScale = Height,
        ModelToScale = Character
    });
    u1.Remove(Character);
    u1.Fire(Character, "Armor1", p23);
end;

function u1.RaiseFaceGuards(p24) -- Line: 382
    -- upvalues: GlobalFunctions (copy)
    if not p24 then
        return;
    end;

    local v25 = {};

    for _, descendant in ipairs(p24:GetDescendants()) do
        if descendant:IsA("Weld") and (descendant.Part0 and (descendant.Part0.Name:sub(1, 10) == "Face Guard" and not descendant:GetAttribute("GuardRaised"))) then
            descendant:SetAttribute("GuardRaised", true);
            v25[#v25 + 1] = descendant;
        end;
    end;

    table.sort(v25, function(p26, p27) -- Line: 393
        return p26.Part0.Name < p27.Part0.Name;
    end);

    for i, v in ipairs(v25) do
        task.delay((i - 1) * 0.5, function() -- Line: 396
            -- upvalues: v (copy), GlobalFunctions (ref)
            local Part0 = v.Part0;

            if not (v.Parent and (Part0 and Part0.Parent)) then
                return;
            end;

            local v28 = Part0:GetAttribute("GuardTransparency") or 0;
            GlobalFunctions.Tween({
                Duration = 0.25,
                Instance = Part0
            }, {
                Transparency = v28
            });
            task.delay(0.25, function() -- Line: 403
                -- upvalues: v (ref), GlobalFunctions (ref)
                if not v.Parent then
                    return;
                end;

                GlobalFunctions.Tween({
                    Duration = 0.5,
                    Instance = v
                }, {
                    C0 = v.C0 * CFrame.new(0, -0.3, 0)
                });
            end);
        end);
    end;
end;

return u1;