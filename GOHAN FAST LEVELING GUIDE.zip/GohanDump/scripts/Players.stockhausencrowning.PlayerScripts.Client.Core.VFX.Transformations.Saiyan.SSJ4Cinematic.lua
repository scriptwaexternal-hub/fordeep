-- Decompiled with Potassium's decompiler.

local Players = game:GetService("Players");
local ReplicatedStorage = game:GetService("ReplicatedStorage");
local TweenService = game:GetService("TweenService");
local RunService = game:GetService("RunService");
local LocalPlayer = Players.LocalPlayer;
local ServerRemote = ReplicatedStorage:WaitForChild("Remotes"):WaitForChild("ServerRemote");
local Assets = ReplicatedStorage:WaitForChild("Assets");
local SoundManager = require(ReplicatedStorage:WaitForChild("Modules"):WaitForChild("Shared"):WaitForChild("SoundManager"));
local Color3_new_ret = Color3.new(0, 0, 0);

local function clear() -- Line: 29
    -- upvalues: LocalPlayer (copy)
    local SSJ4Cinematic = LocalPlayer.PlayerGui:FindFirstChild("SSJ4Cinematic");

    if SSJ4Cinematic then
        SSJ4Cinematic:Destroy();
    end;
end;

local function collectVisuals(p1) -- Line: 35
    local v2 = {};

    for _, descendant in ipairs(p1:GetDescendants()) do
        if descendant:IsA("BasePart") and descendant.Name ~= "HumanoidRootPart" or (descendant:IsA("Decal") or descendant:IsA("Texture")) then
            v2[#v2 + 1] = {
                Inst = descendant,
                Base = descendant.Transparency
            };
        end;
    end;

    return v2;
end;

local function setAlpha(p3, p4) -- Line: 44
    for _, v in ipairs(p3) do
        v.Inst.Transparency = 1 - (1 - v.Base) * p4;
    end;
end;

local function tweenAlpha(p5, p6, p7, p8) -- Line: 49
    -- upvalues: RunService (copy)
    local os_clock_ret = os.clock();

    for _, v in ipairs(p5) do
        v.Inst.Transparency = 1 - (1 - v.Base) * p6;
    end;

    while true do
        local v9 = (os.clock() - os_clock_ret) / p8;
        local math_clamp_ret = math.clamp(v9, 0, 1);
        local v10 = p6 + (p7 - p6) * math_clamp_ret;

        for _, v in ipairs(p5) do
            v.Inst.Transparency = 1 - (1 - v.Base) * v10;
        end;

        if math_clamp_ret >= 1 then
            return;
        end;

        RunService.RenderStepped:Wait();
    end;
end;

local StatRetrieveRemote = ReplicatedStorage:WaitForChild("Remotes"):WaitForChild("StatRetrieveRemote");
local ClothesHandler = require(ReplicatedStorage:WaitForChild("Modules"):WaitForChild("Metadata"):WaitForChild("CharacterData"):WaitForChild("ClothesHandler"));
local u11 = nil;

local function getAppearance() -- Line: 64
    -- upvalues: u11 (ref), StatRetrieveRemote (copy)
    if u11 then
        return u11;
    end;

    local success, result = pcall(function() -- Line: 66
        -- upvalues: StatRetrieveRemote (ref)
        return StatRetrieveRemote:InvokeServer("AppearanceData");
    end);

    if success and type(result) == "table" then
        u11 = result;
    end;

    return u11;
end;

local function cloneCharacter() -- Line: 73
    -- upvalues: LocalPlayer (copy)
    local Character = LocalPlayer.Character;

    if not Character then
        return nil;
    end;

    Character.Archivable = true;
    local v12 = Character:Clone();

    for _, descendant in ipairs(v12:GetDescendants()) do
        if descendant:IsA("Script") or (descendant:IsA("LocalScript") or (descendant:IsA("Sound") or (descendant:IsA("ParticleEmitter") or (descendant:IsA("Beam") or (descendant:IsA("Trail") or descendant:IsA("Highlight")))))) then
            descendant:Destroy();
        elseif descendant:IsA("BasePart") then
            descendant.Anchored = false;
            descendant.CanCollide = false;
        end;
    end;

    if v12:GetScale() ~= 1 then
        v12:ScaleTo(1);
    end;

    local v13 = v12:FindFirstChildOfClass("Humanoid");

    if v13 then
        v13.DisplayDistanceType = Enum.HumanoidDisplayDistanceType.None;
        v13.HealthDisplayType = Enum.HumanoidHealthDisplayType.AlwaysOff;
    end;

    return v12;
end;

local function buildRig() -- Line: 97
    -- upvalues: u11 (ref), StatRetrieveRemote (copy), cloneCharacter (copy), LocalPlayer (copy), Players (copy), ClothesHandler (copy)
    local v14;

    if u11 then
        v14 = u11;
    else
        local success, result = pcall(function() -- Line: 66
            -- upvalues: StatRetrieveRemote (ref)
            return StatRetrieveRemote:InvokeServer("AppearanceData");
        end);

        if success and type(result) == "table" then
            u11 = result;
        end;

        v14 = u11;
    end;

    if not v14 then
        return cloneCharacter();
    end;

    local v15 = nil;
    local v16;

    if LocalPlayer.UserId > 0 then
        local v17;
        v17, v16 = pcall(Players.CreateHumanoidModelFromUserId, Players, LocalPlayer.UserId);

        if not v17 then
            v16 = v15;
        end;
    else
        v16 = v15;
    end;

    local v18 = v16 or Players:CreateHumanoidModelFromDescription(Instance.new("HumanoidDescription"), Enum.HumanoidRigType.R15);

    for _, descendant in ipairs(v18:GetDescendants()) do
        if descendant:IsA("BaseScript") then
            descendant:Destroy();
        end;
    end;

    local v19 = v18:FindFirstChildOfClass("Humanoid");
    local HumanoidDescription = Instance.new("HumanoidDescription");
    HumanoidDescription.Head = 0;
    HumanoidDescription.Torso = 0;
    HumanoidDescription.LeftArm = 0;
    HumanoidDescription.RightArm = 0;
    HumanoidDescription.LeftLeg = 0;
    HumanoidDescription.RightLeg = 0;
    HumanoidDescription.Shirt = 0;
    HumanoidDescription.Pants = 0;
    HumanoidDescription.GraphicTShirt = 0;
    HumanoidDescription.Face = 7074764;
    local v20 = {};

    for _, descendant in ipairs(v18:GetDescendants()) do
        if descendant:IsA("Accessory") and descendant.AccessoryType == Enum.AccessoryType.Hair then
            table.insert(v20, descendant:Clone());
        end;
    end;

    if v19 then
        pcall(v19.ApplyDescription, v19, HumanoidDescription);

        for _, v in ipairs(v20) do
            v19:AddAccessory(v);
        end;

        v19.DisplayDistanceType = Enum.HumanoidDisplayDistanceType.None;
        v19.HealthDisplayType = Enum.HumanoidHealthDisplayType.AlwaysOff;
    end;

    pcall(ClothesHandler.GiveClothes, LocalPlayer, v18, v14);

    for _, descendant in ipairs(v18:GetDescendants()) do
        if descendant:IsA("BasePart") then
            descendant.Anchored = false;
            descendant.CanCollide = false;
        end;
    end;

    local v21 = LocalPlayer.Character and LocalPlayer.Character:FindFirstChildOfClass("Humanoid");

    if v21 then
        v21 = v21:FindFirstChildOfClass("Animator");
    end;

    if v19 then
        v19 = v19:FindFirstChildOfClass("Animator");
    end;

    if v21 and (v19 and v18:FindFirstChild("MonkeyTail", true)) then
        for _, v in ipairs(v21:GetPlayingAnimationTracks()) do
            local Animation = v.Animation;

            if Animation and Animation.Name:lower():find("tail") then
                local success, result = pcall(v19.LoadAnimation, v19, Animation);

                if success and result then
                    result.Looped = true;
                    result.Priority = v.Priority;
                    result:Play(0, v.WeightCurrent, v.Speed);
                    result.TimePosition = v.TimePosition;
                end;
            end;
        end;
    end;

    return v18;
end;

local function buildMiniApe() -- Line: 146
    -- upvalues: cloneCharacter (copy), Assets (copy)
    local v22 = cloneCharacter();

    if not v22 then
        return nil;
    end;

    for _, descendant in ipairs(v22:GetDescendants()) do
        if descendant:IsA("Accessory") or (descendant.Name == "Cosmetics" or (descendant:IsA("Shirt") or descendant:IsA("Pants"))) then
            descendant:Destroy();
        end;
    end;

    for _, descendant in ipairs(v22:GetDescendants()) do
        if descendant:IsA("BasePart") then
            descendant.Transparency = 1;
        elseif descendant:IsA("Decal") then
            descendant.Transparency = 1;
        end;
    end;

    local GoldenGreatApeBody = Assets.RaceParts.Saiyan:FindFirstChild("GoldenGreatApeBody");
    local v23;

    if GoldenGreatApeBody then
        v23 = GoldenGreatApeBody:FindFirstChild("ApeBody");
    else
        v23 = GoldenGreatApeBody;
    end;

    if not v23 then
        return v22;
    end;

    local v24 = v23:Clone();
    v24.Name = "ApeBody";
    v24.Parent = v22;

    for _, child in ipairs(v24:GetChildren()) do
        local v25 = v22:FindFirstChild(child.Name);
        local v26 = GoldenGreatApeBody:FindFirstChild(child.Name);
        local v27 = v23:FindFirstChild(child.Name);

        if v25 and (v26 and v27) then
            for _, descendant in ipairs(child:GetDescendants()) do
                if descendant:IsA("BasePart") then
                    local v28 = v27:FindFirstChild(descendant.Name, true);

                    if v28 then
                        local v29 = v26.CFrame:Inverse() * v28.CFrame;
                        descendant.Size = v28.Size;
                        descendant.CFrame = v25.CFrame * v29;
                    end;

                    descendant.Anchored = false;
                    descendant.CanCollide = false;
                    descendant.Massless = true;
                    local Weld = Instance.new("Weld");
                    Weld.Part0 = v25;
                    Weld.Part1 = descendant;
                    Weld.C0 = v25.CFrame:Inverse() * descendant.CFrame;
                    Weld.Parent = descendant;
                end;
            end;
        end;
    end;

    return v22;
end;

local function findAnimation(p30) -- Line: 188
    -- upvalues: Assets (copy)
    local v31 = Assets:FindFirstChild("Animations") and Assets.Animations:FindFirstChild(p30, true);

    return v31;
end;

local function shot(p32, p33, p34, p35) -- Line: 193
    -- upvalues: TweenService (copy), RunService (copy)
    local Unit = (p33 - p34).Unit;
    local os_clock_ret = os.clock();

    while true do
        local v36 = (os.clock() - os_clock_ret) / 2.5;
        local math_clamp_ret = math.clamp(v36, 0, 1);
        local Value = TweenService:GetValue(math_clamp_ret, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut);
        p32.CFrame = CFrame.lookAt(p33 + Unit * p35 * Value, p34);

        if math_clamp_ret >= 1 then
            break;
        end;

        RunService.RenderStepped:Wait();
    end;
end;

return {
    Play = function(p37) -- Line: 207
        -- upvalues: LocalPlayer (copy), Color3_new_ret (copy), buildRig (copy), collectVisuals (copy), RunService (copy), tweenAlpha (copy), shot (copy), buildMiniApe (copy), Assets (copy), SoundManager (copy), ServerRemote (copy), TweenService (copy)
        local SSJ4Cinematic = LocalPlayer.PlayerGui:FindFirstChild("SSJ4Cinematic");

        if SSJ4Cinematic then
            SSJ4Cinematic:Destroy();
        end;

        local ScreenGui = Instance.new("ScreenGui");
        ScreenGui.Name = "SSJ4Cinematic";
        ScreenGui.ResetOnSpawn = false;
        ScreenGui.IgnoreGuiInset = true;
        ScreenGui.DisplayOrder = 100;
        local ViewportFrame = Instance.new("ViewportFrame");
        ViewportFrame.Name = "Viewport";
        ViewportFrame.Size = UDim2.fromScale(1, 1);
        ViewportFrame.BackgroundColor3 = Color3_new_ret;
        ViewportFrame.BackgroundTransparency = 0;
        ViewportFrame.BorderSizePixel = 0;
        ViewportFrame.Ambient = Color3.fromRGB(175, 175, 185);
        ViewportFrame.LightColor = Color3.fromRGB(255, 245, 230);
        ViewportFrame.LightDirection = Vector3.new(-1, -1.2, -0.6);
        ViewportFrame.Parent = ScreenGui;
        local Camera = Instance.new("Camera");
        Camera.FieldOfView = 10;
        Camera.Parent = ViewportFrame;
        ViewportFrame.CurrentCamera = Camera;
        local WorldModel = Instance.new("WorldModel");
        WorldModel.Parent = ViewportFrame;
        ScreenGui.Parent = LocalPlayer.PlayerGui;
        local u38 = CFrame.new(0, 0, 0) * CFrame.Angles(0, 3.141592653589793, 0);

        local function place(p39, p40) -- Line: 236
            -- upvalues: WorldModel (copy)
            p39.Parent = WorldModel;
            p39:PivotTo(p40);
        end;

        task.spawn(function() -- Line: 241
            -- upvalues: Camera (copy), ViewportFrame (copy), buildRig (ref), collectVisuals (ref), u38 (copy), WorldModel (copy), RunService (ref), ScreenGui (copy), tweenAlpha (ref), shot (ref), buildMiniApe (ref), Assets (ref), SoundManager (ref), ServerRemote (ref), TweenService (ref)
            Camera.FieldOfView = 30;
            Camera.CFrame = CFrame.lookAt(Vector3.new(0, 0, 16), Vector3.new(0, 0, 0));
            local v41 = 4.287187078897963 * (ViewportFrame.AbsoluteSize.X / math.max(ViewportFrame.AbsoluteSize.Y, 1));
            local v42 = v41 + 4;
            local v43 = -(v41 + 4);
            local v44 = buildRig();
            local v45 = buildRig();

            if v44 and v45 then
                local v46 = {
                    {
                        Start = 0,
                        Z = 0,
                        Model = v44,
                        Vis = collectVisuals(v44)
                    },
                    {
                        Start = 2,
                        Z = 1.5,
                        Model = v45,
                        Vis = collectVisuals(v45)
                    }
                };

                for _, v in ipairs(v46) do
                    local Model = v.Model;
                    local v47 = u38 * CFrame.new(v42, 0, v.Z);
                    Model.Parent = WorldModel;
                    Model:PivotTo(v47);

                    for _, v2 in ipairs(v.Vis) do
                        v2.Inst.Transparency = 1 - (1 - v2.Base) * 1;
                    end;
                end;

                local os_clock_ret = os.clock();

                while true do
                    local v48 = os.clock() - os_clock_ret;
                    local v49 = true;

                    for _, v in ipairs(v46) do
                        local math_clamp_ret = math.clamp((v48 - v.Start) / 5, 0, 1);

                        if math_clamp_ret < 1 then
                            v49 = false;
                        end;

                        v.Model:PivotTo(u38 * CFrame.new(v42 + (v43 - v42) * math_clamp_ret, 0, v.Z));
                    end;

                    if v49 then
                        break;
                    end;

                    RunService.RenderStepped:Wait();
                end;

                v44:Destroy();
                v45:Destroy();
            end;

            task.wait(1);
            local v50 = buildRig();

            if not v50 then
                ScreenGui:Destroy();

                return;
            end;

            v50.Parent = WorldModel;
            v50:PivotTo(u38);
            local v51 = collectVisuals(v50);

            for _, v in ipairs(v51) do
                v.Inst.Transparency = 1 - (1 - v.Base) * 0;
            end;

            local Head = v50:FindFirstChild("Head");
            local v52 = v50:FindFirstChild("HumanoidRootPart") or Head;
            local LookVector = v52.CFrame.LookVector;
            local RightVector = v52.CFrame.RightVector;
            local Position = Head.Position;
            Camera.FieldOfView = 10;
            Camera.CFrame = CFrame.lookAt(Position + LookVector * 50, Position);
            tweenAlpha(v51, 0, 1, 2);
            shot(Camera, Position + RightVector * 8, Position, 3);
            shot(Camera, Position + LookVector * 50, Position, 6);
            shot(Camera, Position + LookVector * 10 + Vector3.new(0, 4, 0) + RightVector * 6, Position, 5);
            Camera.FieldOfView = 40;
            Camera.CFrame = CFrame.lookAt(Position + LookVector * 3, Position);
            local v53 = buildMiniApe();

            if v53 then
                local CFrame_lookAt_ret = CFrame.lookAt(Position + LookVector * 1.3, Position + LookVector * 1.3 - LookVector);
                v53.Parent = WorldModel;
                v53:PivotTo(CFrame_lookAt_ret);
                v53:ScaleTo(0.1);
                v53:PivotTo(CFrame.lookAt(Position + LookVector * 1.4 - Vector3.new(0, 0.15, 0), Position + LookVector * 1.4 + LookVector));
                local v54 = {};

                for _, descendant in ipairs(v53:GetDescendants()) do
                    if descendant:IsA("BasePart") and descendant:FindFirstAncestor("ApeBody") then
                        v54[#v54 + 1] = {
                            Base = 0,
                            Inst = descendant
                        };
                    end;
                end;

                for _, v in ipairs(v54) do
                    v.Inst.Transparency = 1 - (1 - v.Base) * 0;
                end;

                local v55 = Assets:FindFirstChild("Animations") and Assets.Animations:FindFirstChild("Great Ape Roar", true);
                local v56 = v53:FindFirstChildOfClass("Humanoid") and v53.Humanoid:FindFirstChildOfClass("Animator");
                local v57;

                if v55 and v56 then
                    v57 = v56:LoadAnimation(v55);
                    v57.Looped = true;
                    v57.Priority = Enum.AnimationPriority.Action;
                    v57:Play();
                else
                    v57 = nil;
                end;

                SoundManager.AddSound("Oozaru Roar", {
                    Parent = workspace.CurrentCamera
                }, "Client");
                tweenAlpha(v54, 0, 1, 1.5);
                task.wait(2);
                local os_clock_ret = os.clock();

                while true do
                    local v58 = (os.clock() - os_clock_ret) / 2.5;
                    local math_clamp_ret = math.clamp(v58, 0, 1);
                    v53:ScaleTo((1 - math_clamp_ret * 0.95) * 0.1);
                    local v59 = 1 - math_clamp_ret;

                    for _, v in ipairs(v54) do
                        v.Inst.Transparency = 1 - (1 - v.Base) * v59;
                    end;

                    if math_clamp_ret >= 1 then
                        break;
                    end;

                    RunService.RenderStepped:Wait();
                end;

                if v57 then
                    v57:Stop();
                end;

                v53:Destroy();
            end;

            tweenAlpha(v51, 1, 0, 1);
            v50:Destroy();
            ServerRemote:FireServer(nil, {
                Module = "Ape Transformation",
                Action = "SSJ4CinematicDone"
            });
            local v60 = TweenService:Create(ViewportFrame, TweenInfo.new(1.5, Enum.EasingStyle.Sine), {
                BackgroundTransparency = 1
            });
            v60:Play();
            v60.Completed:Wait();
            ScreenGui:Destroy();
        end);
    end,

    Clear = function() -- Line: 346
        -- upvalues: LocalPlayer (copy)
        local SSJ4Cinematic = LocalPlayer.PlayerGui:FindFirstChild("SSJ4Cinematic");

        if SSJ4Cinematic then
            SSJ4Cinematic:Destroy();
        end;
    end
};