-- Decompiled with Potassium's decompiler.

local ReplicatedStorage = game:GetService("ReplicatedStorage");
game:GetService("UserInputService");
local Players = game:GetService("Players");
local Debris = game:GetService("Debris");
local Modules = ReplicatedStorage:WaitForChild("Modules");
ReplicatedStorage:WaitForChild("Remotes");
local _ = Modules.Metadata;
local _ = Modules.Shared;
local _ = Modules.Utility;
local Assets = ReplicatedStorage.Assets;
local GlobalFunctions = require(Modules.GlobalFunctions);
local LocalPlayer = Players.LocalPlayer;

return {
    Update = function(p1) -- Line: 31
        -- upvalues: LocalPlayer (copy), Assets (copy), GlobalFunctions (copy), Debris (copy)
        local TextName = p1.TextName;
        local Description = p1.Description;
        local ImageID = p1.ImageID;
        local Popup_Time = p1.Popup_Time;
        local v2 = Popup_Time or 0.5;
        local v3 = p1.Delay_Time or 1;
        local PopupGui = LocalPlayer.PlayerGui:FindFirstChild("PopupGui");
        local v4 = Assets.Gui.Misc.Popup:Clone();
        v4.Parent = PopupGui;
        v4.NameLabel.Text = TextName or "NameLabel";
        v4.Desc.Text = Description or "Insert Description here";
        v4.ImageLabel.Image = (ImageID == nil or (ImageID == "" or not ImageID)) and "rbxassetid://10639165493" or ImageID;
        v4.Size = UDim2.new(0, 0, 0, 0);
        v4:TweenSize(UDim2.new(0.4, 0, 0.4, 0), Enum.EasingDirection.Out, Enum.EasingStyle.Back, Popup_Time or v2);
        wait(v2 + v3);
        local v5 = {
            Instance = nil,
            Duration = 1,
            EasingStyle = Enum.EasingStyle.Linear,
            EasingDirection = Enum.EasingDirection.Out
        };

        for _, child in pairs(v4:GetChildren()) do
            if child:IsA("TextLabel") then
                v5.Instance = child;
                GlobalFunctions.Tween(v5, {
                    TextTransparency = 1
                });
            elseif child:IsA("ImageLabel") then
                v5.Instance = child;
                GlobalFunctions.Tween(v5, {
                    ImageTransparency = 1
                });
            end;
        end;

        v5.Instance = v4;
        GlobalFunctions.Tween(v5, {
            Transparency = 1
        });
        Debris:AddItem(v4, 1);
    end,

    ["Data log"] = function(p6) -- Line: 86
        -- upvalues: LocalPlayer (copy), Assets (copy), GlobalFunctions (copy), Debris (copy)
        local Popup_Time = p6.Popup_Time;
        local Delay_Time = p6.Delay_Time;
        local Data_Info = p6.Data_Info;
        local v7 = Popup_Time or 0.5;
        LocalPlayer.PlayerGui:FindFirstChild("PopupGui");
        local v8 = Assets.Gui.Tech.GravityChamber.DataReport:Clone();
        v8.Parent = LocalPlayer.PlayerGui.PopupGui;
        v8.Size = UDim2.new(0, 0, 0, 0);
        v8:TweenSize(UDim2.new(0.4, 0, 0.4, 0), Enum.EasingDirection.Out, Enum.EasingStyle.Back, Popup_Time or v7);

        for _, v in pairs(Data_Info) do
            local v9 = Assets.Gui.Tech.GravityChamber.Data_Log_Example:Clone();
            v9.Parent = v8.MainFrame;
            v9.Text = v;
        end;

        wait(v7 + (Delay_Time or 1));
        local v10 = {
            Instance = nil,
            Duration = 1,
            EasingStyle = Enum.EasingStyle.Linear,
            EasingDirection = Enum.EasingDirection.Out
        };

        for _, descendant in pairs(v8:GetDescendants()) do
            if descendant:IsA("TextLabel") then
                v10.Instance = descendant;
                GlobalFunctions.Tween(v10, {
                    TextTransparency = 1
                });
            elseif descendant:IsA("ImageLabel") then
                v10.Instance = descendant;
                GlobalFunctions.Tween(v10, {
                    ImageTransparency = 1
                });
            end;
        end;

        v10.Instance = v8;
        GlobalFunctions.Tween(v10, {
            Transparency = 1
        });
        Debris:AddItem(v8, 1);
    end
};