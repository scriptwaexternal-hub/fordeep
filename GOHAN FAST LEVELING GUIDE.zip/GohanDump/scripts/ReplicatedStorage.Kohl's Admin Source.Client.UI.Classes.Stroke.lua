-- Decompiled with Potassium's decompiler.

local Parent = require(script.Parent.Parent);
local BaseClass = require(script.Parent:WaitForChild("BaseClass"));
local u1 = {};
local u2 = {};
u2.__index = u2;
setmetatable(u2, BaseClass);

function u2.new(p3) -- Line: 12
    -- upvalues: u1 (copy), Parent (copy), u2 (copy)
    local table_clone_ret = table.clone(u1);
    Parent.makeStatefulDefaults(table_clone_ret, p3);
    table_clone_ret._instance = Parent.new("UIStroke")({
        Enabled = Parent.Theme.StrokeEnabled,
        ApplyStrokeMode = Enum.ApplyStrokeMode.Border,
        Transparency = Parent.Theme.TransparencyLight,
        Color = Color3.new(1, 1, 1),
        Parent.new("UIGradient")({
            Color = function() -- Line: 23, Name: Color
                -- upvalues: Parent (ref)
                return ColorSequence.new(Parent.Theme.Border(), Parent.Theme.BorderStop());
            end,

            Rotation = Parent.Theme.BorderAngle
        })
    });

    return setmetatable(table_clone_ret, u2);
end;

return u2;