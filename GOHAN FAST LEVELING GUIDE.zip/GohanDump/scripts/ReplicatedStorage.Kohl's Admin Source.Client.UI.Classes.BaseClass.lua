-- Decompiled with Potassium's decompiler.

local v1 = {};
v1.__index = v1;

function v1.Destroy(p2) -- Line: 4
    for _, v in p2 do
        if typeof(v) == "Instance" then
            v:Destroy();
        end;
    end;
end;

return v1;