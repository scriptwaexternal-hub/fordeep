-- Decompiled with Potassium's decompiler.

local u1 = nil;

local function parseMember(p2: string, p3: any) -- Line: 3
    -- upvalues: u1 (ref)
    local string_lower_ret = string.lower(p2);
    local v4 = tostring(p3.command.from);

    if p2 == "" or p2 == "me" and u1.Data.members[v4] then
        return p3._K.Auth.targetUserArgument(p3, p3.command.from, v4);
    end;

    local v5 = nil;

    for i, v in u1.Data.members do
        local string_lower_ret2 = string.lower(v.name);

        if i == string_lower_ret or string_lower_ret2 == string_lower_ret then
            return p3._K.Auth.targetUserArgument(p3, tonumber(i), i);
        end;

        if not v5 and string.find(string_lower_ret2, string_lower_ret, 1, true) == 1 then
            v5 = i;
        end;
    end;

    if v5 then
        return p3._K.Auth.targetUserArgument(p3, tonumber(v5), v5);
    end;

    return nil, "Invalid member";
end;

local function parseAll(p6, p7) -- Line: 29
    -- upvalues: u1 (ref)
    local v8 = {};
    local v9 = {};

    for i, _ in u1.Data.members do
        local v10, v11 = p7._K.Auth.targetUserArgument(p7, tonumber(i), i);

        if v10 then
            table.insert(v8, v10);
        elseif not table.find(v9, v11) then
            table.insert(v9, v11);
        end;
    end;

    if #v8 > 0 then
        return v8;
    end;

    return nil, #v9 > 0 and table.concat(v9, "\n") or "No targetable member found";
end;

local u16 = {
    listable = true,
    transform = string.lower,

    validate = function(p12, p13) -- Line: 52, Name: validate
        -- upvalues: parseAll (copy)
        local v14, v15 = parseAll(p12, p13);

        return v14, v15 or "Invalid member";
    end,

    suggestions = { { { "*", "all" }, "*  [all] (Everyone)" } },
    parse = parseAll
};

local function nameSort(p17, p18) -- Line: 60
    return string.lower(p17[1][1]) < string.lower(p18[1][1]);
end;

local u29 = {
    validate = parseMember,
    parse = parseMember,
    prefixes = {
        ["^%*$"] = "allMembers",
        ["^all$"] = "allMembers"
    },

    suggestions = function(p19: string, p20: number, p21: any) -- Line: 71, Name: suggestions
        -- upvalues: u1 (ref), nameSort (copy)
        local v22 = { { { "*", "all" }, "*  [all] (Everyone)" } };
        local v23 = tostring(p20);
        local Rank = u1.Auth.getRank(p20);
        local v24 = p21.lowerRank or p21.shouldRequest and u1.Data.settings.commandRequests ~= false;

        for i, v in u1.Data.members do
            local Rank2 = u1.Auth.getRank(i);

            if i ~= v23 and (p20 == u1.creatorId or not (v24 and (v23 ~= i and Rank2 >= Rank))) then
                local v25 = {
                    { v.name, i },
                    (`{v.name} [{i}]`)
                };
                table.insert(v22, v25);
            end;
        end;

        table.sort(v22, nameSort);
        local v26 = u1.Data.members[v23];

        if v26 and not p21.ignoreSelf then
            local v27 = {
                { "me", v26.name, p20 },
                (`me [{v26.name}] [{p20}]`)
            };
            table.insert(v22, 1, v27);
        end;

        return v22;
    end,

    log = function(p28) -- Line: 97, Name: log
        return p28.rawArg;
    end
};
local u30 = {
    listable = true
};

return function(p31) -- Line: 106
    -- upvalues: u1 (ref), u29 (copy), u30 (copy), u16 (copy)
    u1 = p31;
    u1.Registry.registerType("member", u29);
    u1.Registry.registerType("members", u30, u29);
    u1.Registry.registerType("allMembers", u16);
end;