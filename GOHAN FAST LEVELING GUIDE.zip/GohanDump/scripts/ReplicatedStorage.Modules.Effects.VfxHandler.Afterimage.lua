-- Decompiled with Potassium's decompiler.

local ReplicatedStorage = game:GetService("ReplicatedStorage");
game:GetService("PhysicsService");
game:GetService("UserInputService");
local Debris = game:GetService("Debris");
game:GetService("Players");
local Modules = ReplicatedStorage:WaitForChild("Modules");
ReplicatedStorage:WaitForChild("Remotes");
local _ = ReplicatedStorage.Assets;
local _ = Modules.Metadata;
local Shared = Modules.Shared;
local Utility = Modules.Utility;
require(Utility.Create);
require(Utility.ReplicationModule);
require(Modules.Effects.VfxHandler.Invisibility);
local GlobalFunctions = require(Modules.GlobalFunctions);
require(Shared.SoundManager);
local Visuals = workspace.World.Visuals;

return {
    New = function(p1, p2) -- Line: 35, Name: New
        -- upvalues: GlobalFunctions (copy), Visuals (copy), Debris (copy)
        p1.Archivable = true;
        local v3 = p2 and p2.Duration or 1;
        local v4 = p1:Clone();
        local v5 = { "MeshPart", "Part", "Accessory", "SpecialMesh", "Clothing", "Model", "Humanoid" };

        for _, descendant in pairs(v4:GetDescendants()) do
            if not table.find(v5, descendant.ClassName) then
                descendant:Destroy();
            end;

            if descendant:IsA("Part") or descendant:IsA("MeshPart") then
                descendant.Anchored = true;
                descendant.CollisionGroup = "Phase";
                descendant.CanCollide = false;
                GlobalFunctions.TransparencyTween({
                    Duration = v3,
                    Instance = descendant
                });
            end;

            if descendant:IsA("Decal") then
                GlobalFunctions.TransparencyTween({
                    Duration = v3,
                    Instance = descendant
                });
            end;
        end;

        v4.Parent = Visuals;
        v4.Name = "AfterImage";
        Debris:AddItem(v4, v3);
        local Humanoid = v4:FindFirstChild("Humanoid");

        if Humanoid then
            Humanoid.DisplayDistanceType = Enum.HumanoidDisplayDistanceType.None;
        end;

        return v4;
    end
};