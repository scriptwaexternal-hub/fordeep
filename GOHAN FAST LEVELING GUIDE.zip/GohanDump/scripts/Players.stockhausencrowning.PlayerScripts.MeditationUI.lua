-- Decompiled with Potassium's decompiler.

local Players = game:GetService("Players");
local ReplicatedStorage = game:GetService("ReplicatedStorage");
local LocalPlayer = Players.LocalPlayer;
local Remotes = ReplicatedStorage:WaitForChild("Remotes");
local ServerRemote = Remotes:WaitForChild("ServerRemote");
local StatRetrieveRemote = Remotes:WaitForChild("StatRetrieveRemote");
local MeditationMenu = require(script.Parent.Client.Core.VFX.CoreControls.MeditationMenu);
local CoreControlVFX = require(script.Parent.Client.Core.VFX.CoreControls.CoreControlVFX);

local function showMenu() -- Line: 26
    -- upvalues: StatRetrieveRemote (copy), LocalPlayer (copy), MeditationMenu (copy), ServerRemote (copy), CoreControlVFX (copy)
    task.spawn(function() -- Line: 28
        -- upvalues: StatRetrieveRemote (ref), LocalPlayer (ref), MeditationMenu (ref), ServerRemote (ref), CoreControlVFX (ref)
        local v4, v5, v6, v7 = pcall(function() -- Line: 29
            -- upvalues: StatRetrieveRemote (ref)
            local v1 = StatRetrieveRemote:InvokeServer("KiUnlocked");
            local v2 = StatRetrieveRemote:InvokeServer("KiControl", "Core");
            local v3 = StatRetrieveRemote:InvokeServer("KiDmg", "Core");

            return v1, v2.BaseKiControl + v2.EnhancedKiControl, v3.BaseKiDmg + v3.EnhancedKiDmg;
        end);

        if not v4 then
            v5 = false;
            v6 = 0;
            v7 = 0;
        end;

        local Character = LocalPlayer.Character;

        if not (Character and Character:GetAttribute("Meditating")) then
            return;
        end;

        MeditationMenu.Show({
            enlightenedBase = 45,
            kiUnlocked = v5,
            kiControl = v6,
            kiDmg = v7,

            onSelectKi = function(p8) -- Line: 49, Name: onSelectKi
                -- upvalues: MeditationMenu (ref), ServerRemote (ref), CoreControlVFX (ref)
                MeditationMenu.Hide();
                MeditationMenu.Busy = true;
                ServerRemote:FireServer(nil, {
                    Module = "CoreControlHandler",
                    Action = "KiMinigame",
                    TrainType = p8
                });
                local v9 = CoreControlVFX.MeditateActions and CoreControlVFX.MeditateActions[p8];

                if v9 then
                    task.spawn(v9);
                end;
            end,

            onSelectBasic = function(p10) -- Line: 64, Name: onSelectBasic
                -- upvalues: MeditationMenu (ref), ServerRemote (ref)
                MeditationMenu.Hide();
                ServerRemote:FireServer(nil, {
                    Module = "CoreControlHandler",
                    Action = "Meditate",
                    TrainType = p10
                });
            end,

            onClose = function() -- Line: 82, Name: onClose
                -- upvalues: ServerRemote (ref)
                ServerRemote:FireServer(nil, {
                    Module = "CoreControlHandler",
                    Action = "Meditate"
                });
            end
        });
    end);
end;

local function watchCharacter(u11) -- Line: 90
    -- upvalues: StatRetrieveRemote (copy), LocalPlayer (copy), MeditationMenu (copy), ServerRemote (copy), CoreControlVFX (copy)
    if u11:GetAttribute("MeditatingSeated") then
        task.spawn(function() -- Line: 28
            -- upvalues: StatRetrieveRemote (ref), LocalPlayer (ref), MeditationMenu (ref), ServerRemote (ref), CoreControlVFX (ref)
            local v15, v16, v17, v18 = pcall(function() -- Line: 29
                -- upvalues: StatRetrieveRemote (ref)
                local v12 = StatRetrieveRemote:InvokeServer("KiUnlocked");
                local v13 = StatRetrieveRemote:InvokeServer("KiControl", "Core");
                local v14 = StatRetrieveRemote:InvokeServer("KiDmg", "Core");

                return v12, v13.BaseKiControl + v13.EnhancedKiControl, v14.BaseKiDmg + v14.EnhancedKiDmg;
            end);

            if not v15 then
                v16 = false;
                v17 = 0;
                v18 = 0;
            end;

            local Character = LocalPlayer.Character;

            if not (Character and Character:GetAttribute("Meditating")) then
                return;
            end;

            MeditationMenu.Show({
                enlightenedBase = 45,
                kiUnlocked = v16,
                kiControl = v17,
                kiDmg = v18,

                onSelectKi = function(p19) -- Line: 49, Name: onSelectKi
                    -- upvalues: MeditationMenu (ref), ServerRemote (ref), CoreControlVFX (ref)
                    MeditationMenu.Hide();
                    MeditationMenu.Busy = true;
                    ServerRemote:FireServer(nil, {
                        Module = "CoreControlHandler",
                        Action = "KiMinigame",
                        TrainType = p19
                    });
                    local v20 = CoreControlVFX.MeditateActions and CoreControlVFX.MeditateActions[p19];

                    if v20 then
                        task.spawn(v20);
                    end;
                end,

                onSelectBasic = function(p21) -- Line: 64, Name: onSelectBasic
                    -- upvalues: MeditationMenu (ref), ServerRemote (ref)
                    MeditationMenu.Hide();
                    ServerRemote:FireServer(nil, {
                        Module = "CoreControlHandler",
                        Action = "Meditate",
                        TrainType = p21
                    });
                end,

                onClose = function() -- Line: 82, Name: onClose
                    -- upvalues: ServerRemote (ref)
                    ServerRemote:FireServer(nil, {
                        Module = "CoreControlHandler",
                        Action = "Meditate"
                    });
                end
            });
        end);
    end;

    u11:GetAttributeChangedSignal("MeditatingSeated"):Connect(function() -- Line: 100
        -- upvalues: u11 (copy), StatRetrieveRemote (ref), LocalPlayer (ref), MeditationMenu (ref), ServerRemote (ref), CoreControlVFX (ref)
        if u11:GetAttribute("MeditatingSeated") then
            task.spawn(function() -- Line: 28
                -- upvalues: StatRetrieveRemote (ref), LocalPlayer (ref), MeditationMenu (ref), ServerRemote (ref), CoreControlVFX (ref)
                local v25, v26, v27, v28 = pcall(function() -- Line: 29
                    -- upvalues: StatRetrieveRemote (ref)
                    local v22 = StatRetrieveRemote:InvokeServer("KiUnlocked");
                    local v23 = StatRetrieveRemote:InvokeServer("KiControl", "Core");
                    local v24 = StatRetrieveRemote:InvokeServer("KiDmg", "Core");

                    return v22, v23.BaseKiControl + v23.EnhancedKiControl, v24.BaseKiDmg + v24.EnhancedKiDmg;
                end);

                if not v25 then
                    v26 = false;
                    v27 = 0;
                    v28 = 0;
                end;

                local Character = LocalPlayer.Character;

                if not (Character and Character:GetAttribute("Meditating")) then
                    return;
                end;

                MeditationMenu.Show({
                    enlightenedBase = 45,
                    kiUnlocked = v26,
                    kiControl = v27,
                    kiDmg = v28,

                    onSelectKi = function(p29) -- Line: 49, Name: onSelectKi
                        -- upvalues: MeditationMenu (ref), ServerRemote (ref), CoreControlVFX (ref)
                        MeditationMenu.Hide();
                        MeditationMenu.Busy = true;
                        ServerRemote:FireServer(nil, {
                            Module = "CoreControlHandler",
                            Action = "KiMinigame",
                            TrainType = p29
                        });
                        local v30 = CoreControlVFX.MeditateActions and CoreControlVFX.MeditateActions[p29];

                        if v30 then
                            task.spawn(v30);
                        end;
                    end,

                    onSelectBasic = function(p31) -- Line: 64, Name: onSelectBasic
                        -- upvalues: MeditationMenu (ref), ServerRemote (ref)
                        MeditationMenu.Hide();
                        ServerRemote:FireServer(nil, {
                            Module = "CoreControlHandler",
                            Action = "Meditate",
                            TrainType = p31
                        });
                    end,

                    onClose = function() -- Line: 82, Name: onClose
                        -- upvalues: ServerRemote (ref)
                        ServerRemote:FireServer(nil, {
                            Module = "CoreControlHandler",
                            Action = "Meditate"
                        });
                    end
                });
            end);
        end;
    end);
    u11:GetAttributeChangedSignal("Meditating"):Connect(function() -- Line: 106
        -- upvalues: u11 (copy), MeditationMenu (ref)
        if not u11:GetAttribute("Meditating") then
            MeditationMenu.Busy = false;
            MeditationMenu.Hide();
        end;
    end);
end;

if LocalPlayer.Character then
    watchCharacter(LocalPlayer.Character);
end;

LocalPlayer.CharacterAdded:Connect(watchCharacter);