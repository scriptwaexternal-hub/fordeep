-- Decompiled with Potassium's decompiler.

local Debris = game:GetService("Debris");
local Particles = game:GetService("ReplicatedStorage").Assets.Effects.Particles;
local Color3_fromRGB_ret = Color3.fromRGB(253, 255, 129);

return {
    Charge = function(p1) -- Line: 19
        -- upvalues: Color3_fromRGB_ret (copy), Particles (copy), Debris (copy)
        local Character = p1.Character;

        if not Character then
            return;
        end;

        local v2 = p1.Color or Color3_fromRGB_ret;
        local Aura = Particles:FindFirstChild("Default Aura", true).Aura;

        for _, child in ipairs(Character:GetChildren()) do
            if child:IsA("Part") or child:IsA("MeshPart") then
                local u3 = Aura:Clone();
                u3.Color = ColorSequence.new(v2);
                u3.Enabled = true;
                u3.Parent = child;
                task.delay(1, function() -- Line: 33
                    -- upvalues: u3 (copy), Debris (ref)
                    u3.Enabled = false;
                    Debris:AddItem(u3, 2);
                end);
            end;
        end;
    end
};