-- Decompiled with Potassium's decompiler.

local LocalPlayer = game:GetService("Players").LocalPlayer;
LocalPlayer:WaitForChild("PlayerGui");
local v1 = script.Parent:FindFirstChild("Client") and script.Parent.Client:FindFirstChild("Core");

if v1 then
    v1 = v1:FindFirstChild("NpcMarkers", true);
end;

if not v1 then
    warn("[NpcMarkerLoader] NpcMarkers module not found -- no NPC nameplates");

    return;
end;

local u2 = require(v1);

local function start(p3) -- Line: 29
    -- upvalues: u2 (copy)
    p3:WaitForChild("Head", 10);
    task.wait(0.5);
    local success, result = pcall(u2.Start, p3);

    if not success then
        warn("[NpcMarkerLoader] NpcMarkers.Start failed: " .. tostring(result));
    end;
end;

if LocalPlayer.Character then
    task.spawn(start, LocalPlayer.Character);
end;

LocalPlayer.CharacterAdded:Connect(function(p4) -- Line: 44
    -- upvalues: start (copy)
    task.spawn(start, p4);
end);