-- Decompiled with Potassium's decompiler.

local Players = game:GetService("Players");
local ReplicatedStorage = game:GetService("ReplicatedStorage");
local RunService = game:GetService("RunService");
game:GetService("UserInputService");
local ContextActionService = game:GetService("ContextActionService");
local SpaceshipConfig = require(ReplicatedStorage.Modules.Metadata.MiscData.TechData.SpaceshipConfig);
local SpaceshipRemote = ReplicatedStorage.Remotes:WaitForChild("SpaceshipRemote");
local LocalPlayer = Players.LocalPlayer;
local workspace_CurrentCamera = workspace.CurrentCamera;
local u1 = {};
local u2 = nil;

local function bindVerticalControls() -- Line: 58
    -- upvalues: ContextActionService (copy), u2 (ref), SpaceshipRemote (copy)
    ContextActionService:BindAction("ShipAscend", function(p3, p4) -- Line: 59
        -- upvalues: u2 (ref)
        if not u2 then
            return Enum.ContextActionResult.Pass;
        end;

        u2.vertical.up = p4 == Enum.UserInputState.Begin;

        return Enum.ContextActionResult.Sink;
    end, true, Enum.KeyCode.Space, Enum.KeyCode.ButtonR2);
    ContextActionService:BindAction("ShipDescend", function(p5, p6) -- Line: 65
        -- upvalues: u2 (ref)
        if not u2 then
            return Enum.ContextActionResult.Pass;
        end;

        u2.vertical.down = p6 == Enum.UserInputState.Begin;

        return Enum.ContextActionResult.Sink;
    end, true, Enum.KeyCode.LeftControl, Enum.KeyCode.ButtonL2);
    ContextActionService:BindAction("ShipExit", function(p7, p8) -- Line: 71
        -- upvalues: SpaceshipRemote (ref)
        if p8 ~= Enum.UserInputState.Begin then
            return Enum.ContextActionResult.Pass;
        end;

        SpaceshipRemote:FireServer("Exit", {});

        return Enum.ContextActionResult.Sink;
    end, true, Enum.KeyCode.F, Enum.KeyCode.ButtonY);
    ContextActionService:BindAction("ShipLand", function(p9, p10) -- Line: 77
        -- upvalues: SpaceshipRemote (ref)
        if p10 ~= Enum.UserInputState.Begin then
            return Enum.ContextActionResult.Pass;
        end;

        SpaceshipRemote:FireServer("Land", {});

        return Enum.ContextActionResult.Sink;
    end, true, Enum.KeyCode.G, Enum.KeyCode.ButtonX);
    ContextActionService:BindAction("ShipAutopilot", function(p11, p12) -- Line: 83
        -- upvalues: SpaceshipRemote (ref)
        if p12 ~= Enum.UserInputState.Begin then
            return Enum.ContextActionResult.Pass;
        end;

        SpaceshipRemote:FireServer("Autopilot", {
            Enable = true
        });

        return Enum.ContextActionResult.Sink;
    end, true, Enum.KeyCode.R, Enum.KeyCode.ButtonL1);
    ContextActionService:SetTitle("ShipAscend", "Up");
    ContextActionService:SetTitle("ShipDescend", "Down");
    ContextActionService:SetTitle("ShipExit", "Eject");
    ContextActionService:SetTitle("ShipLand", "Land");
    ContextActionService:SetTitle("ShipAutopilot", "Orbit");
    ContextActionService:SetPosition("ShipAscend", UDim2.new(1, -175, 1, -290));
    ContextActionService:SetPosition("ShipDescend", UDim2.new(1, -175, 1, -215));
    ContextActionService:SetPosition("ShipLand", UDim2.new(1, -250, 1, -290));
    ContextActionService:SetPosition("ShipAutopilot", UDim2.new(1, -250, 1, -215));
    ContextActionService:SetPosition("ShipExit", UDim2.new(1, -325, 1, -215));
end;

local function unbindVerticalControls() -- Line: 103
    -- upvalues: ContextActionService (copy)
    ContextActionService:UnbindAction("ShipAscend");
    ContextActionService:UnbindAction("ShipDescend");
    ContextActionService:UnbindAction("ShipExit");
    ContextActionService:UnbindAction("ShipLand");
    ContextActionService:UnbindAction("ShipAutopilot");
end;

local function computeDirection() -- Line: 116
    -- upvalues: u2 (ref), workspace_CurrentCamera (copy)
    local seat = u2.seat;

    if not (seat and seat.Parent) then
        return Vector3.new(0, 0, 0);
    end;

    local CFrame2 = workspace_CurrentCamera.CFrame;
    local v13 = 0;

    if u2.vertical.up then
        v13 = v13 + 1;
    end;

    if u2.vertical.down then
        v13 = v13 - 1;
    end;

    local v14 = CFrame2.LookVector * (seat.Throttle or 0) + CFrame2.RightVector * (seat.Steer or 0) + Vector3.new(0, 1, 0) * v13;

    return v14.Magnitude < 0.05 and Vector3.new(0, 0, 0) or v14.Unit;
end;

local function resolveShip(p15) -- Line: 149
    -- upvalues: LocalPlayer (copy)
    if p15 and p15.Parent then
        return p15;
    end;

    local Character = LocalPlayer.Character;

    if Character then
        Character = Character:FindFirstChildOfClass("Humanoid");
    end;

    if Character then
        Character = Character.SeatPart;
    end;

    if Character and Character:IsA("VehicleSeat") then
        return Character:FindFirstAncestorWhichIsA("Model");
    end;

    return nil;
end;

local u16 = nil;

local function beginSession(u17, u18) -- Line: 163
    -- upvalues: u2 (ref), workspace_CurrentCamera (copy), bindVerticalControls (copy), RunService (copy), u1 (copy), computeDirection (copy), SpaceshipConfig (copy), SpaceshipRemote (copy)
    u2 = {
        accumulator = 0,
        lastDir = Vector3.new(0, 0, 0),
        ship = u17,
        seat = u18,
        vertical = {
            up = false,
            down = false
        },
        startedAt = os.clock(),
        connections = {},
        cameraAnchor = u17.PrimaryPart or u17:FindFirstChild("Pod")
    };

    if u2.cameraAnchor then
        u2.previousSubject = workspace_CurrentCamera.CameraSubject;
        workspace_CurrentCamera.CameraSubject = u2.cameraAnchor;
    end;

    bindVerticalControls();
    u2.connections[#u2.connections + 1] = RunService.Heartbeat:Connect(function(p19) -- Line: 194
        -- upvalues: u2 (ref), u17 (copy), u1 (ref), u18 (copy), workspace_CurrentCamera (ref), computeDirection (ref), SpaceshipConfig (ref), SpaceshipRemote (ref)
        if not u2 then
            return;
        end;

        if not u17.Parent then
            u1.Stop();

            return;
        end;

        if os.clock() - u2.startedAt > 1.5 and (not u18.Parent or u18.Occupant == nil) then
            u1.Stop();

            return;
        end;

        local v20 = u2;
        v20.accumulator = v20.accumulator + p19;

        if u2.cameraAnchor and (u2.cameraAnchor.Parent and workspace_CurrentCamera.CameraSubject ~= u2.cameraAnchor) then
            workspace_CurrentCamera.CameraSubject = u2.cameraAnchor;
        end;

        if u2.accumulator < 0.06666666666666667 then
            return;
        end;

        u2.accumulator = 0;
        local v21 = computeDirection();
        local LookVector = workspace_CurrentCamera.CFrame.LookVector;
        local Vector3_new_ret = Vector3.new(LookVector.X, 0, LookVector.Z);
        local v22;

        if Vector3_new_ret.Magnitude > 0.05 then
            local math_rad_ret = math.rad(SpaceshipConfig.MAX_PITCH_DEG);
            local math_clamp_ret = math.clamp(LookVector.Y, -1, 1);
            local math_asin_ret = math.asin(math_clamp_ret);
            local math_clamp_ret2 = math.clamp(math_asin_ret, -math_rad_ret, math_rad_ret);
            local v23 = Vector3_new_ret.Unit * math.cos(math_clamp_ret2);
            local math_sin_ret = math.sin(math_clamp_ret2);
            local v24 = v23 + Vector3.new(0, math_sin_ret, 0);
            v22 = CFrame.lookAt(Vector3.new(0, 0, 0), v24.Unit);
        else
            v22 = u2.lastLook or CFrame.identity;
        end;

        u2.lastLook = v22;
        SpaceshipRemote:FireServer("Input", {
            Direction = v21,
            Look = v22
        });
        u2.lastDir = v21;
    end);
end;

function u1.Start(u25) -- Line: 260
    -- upvalues: u1 (copy), u16 (ref), LocalPlayer (copy), beginSession (copy), RunService (copy)
    u1.Stop();
    local u26 = {};
    u16 = u26;
    task.spawn(function() -- Line: 267
        -- upvalues: u16 (ref), u26 (copy), u25 (copy), LocalPlayer (ref), beginSession (ref), RunService (ref)
        local v27 = os.clock() + 3;

        while u16 == u26 and os.clock() < v27 do
            local v28 = u25;

            if not (v28 and v28.Parent) then
                local Character = LocalPlayer.Character;

                if Character then
                    Character = Character:FindFirstChildOfClass("Humanoid");
                end;

                if Character then
                    Character = Character.SeatPart;
                end;

                if Character and Character:IsA("VehicleSeat") then
                    v28 = Character:FindFirstAncestorWhichIsA("Model");
                else
                    v28 = nil;
                end;
            end;

            local v29;

            if v28 then
                v29 = v28:FindFirstChildOfClass("VehicleSeat");
            else
                v29 = v28;
            end;

            if v28 and v29 then
                if u16 ~= u26 then
                    return;
                end;

                beginSession(v28, v29);

                return;
            end;

            RunService.Heartbeat:Wait();
        end;

        if u16 == u26 then
            warn("[SpaceshipFlight] ship never resolved - flight controller not started");
        end;
    end);
end;

function u1.Stop() -- Line: 285
    -- upvalues: u16 (ref), u2 (ref), ContextActionService (copy), LocalPlayer (copy), workspace_CurrentCamera (copy), SpaceshipRemote (copy)
    u16 = nil;

    if not u2 then
        return;
    end;

    for _, v in ipairs(u2.connections) do
        if v.Connected then
            v:Disconnect();
        end;
    end;

    ContextActionService:UnbindAction("ShipAscend");
    ContextActionService:UnbindAction("ShipDescend");
    ContextActionService:UnbindAction("ShipExit");
    ContextActionService:UnbindAction("ShipLand");
    ContextActionService:UnbindAction("ShipAutopilot");
    local previousSubject = u2.previousSubject;
    local ship = u2.ship;
    local v30 = previousSubject and (ship and ship.Parent) and (previousSubject == ship and true or previousSubject:IsDescendantOf(ship));

    if v30 or not (previousSubject and previousSubject.Parent) then
        previousSubject = LocalPlayer.Character;

        if previousSubject then
            previousSubject = previousSubject:FindFirstChildOfClass("Humanoid");
        end;
    end;

    if previousSubject then
        workspace_CurrentCamera.CameraSubject = previousSubject;
    end;

    pcall(function() -- Line: 309
        -- upvalues: SpaceshipRemote (ref)
        SpaceshipRemote:FireServer("Input", {
            Direction = Vector3.new(0, 0, 0)
        });
    end);
    u2 = nil;
end;

function u1.IsActive() -- Line: 315
    -- upvalues: u2 (ref)
    return u2 ~= nil;
end;

return u1;