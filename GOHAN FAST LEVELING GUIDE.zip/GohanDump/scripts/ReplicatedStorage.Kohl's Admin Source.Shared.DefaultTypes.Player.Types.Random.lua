-- Decompiled with Potassium's decompiler.

local Players = game:GetService("Players");

local function parseRandom(p1, p2) -- Line: 5
    -- upvalues: Players (copy)
    local v3 = p1 == "" and 1 or tonumber(p1);

    if not v3 or math.floor(v3) ~= v3 then
        return nil, "Invalid integer";
    end;

    local v4 = {};
    local v5 = {};
    local v6 = {};

    for _, v in Players:GetPlayers() do
        local v7, v8 = p2._K.Auth.targetUserArgument(p2, v.UserId, v);

        if v7 then
            table.insert(v4, v7);
        elseif not table.find(v5, v8) then
            table.insert(v5, v8);
        end;
    end;

    if #v4 == 0 then
        return nil, #v5 > 0 and table.concat(v5, "\n") or "No targetable player found";
    end;

    for i = 1, v3 do
        local v9 = #v4;

        if v9 == 0 then
            break;
        end;

        table.insert(v6, table.remove(v4, math.random(v9)));
        local _ = i;
    end;

    return v6;
end;

local u10 = {
    listable = true,
    validate = require(script.Parent.Parent:WaitForChild("generateValidate"))(parseRandom),
    parse = parseRandom
};

return function(p11) -- Line: 46
    -- upvalues: u10 (copy)
    p11.Registry.registerType("randomPlayers", u10);
end;