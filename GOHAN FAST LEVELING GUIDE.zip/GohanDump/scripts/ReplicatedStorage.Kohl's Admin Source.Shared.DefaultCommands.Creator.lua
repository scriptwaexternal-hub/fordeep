-- Decompiled with Potassium's decompiler.

return {
    {
        name = "clearlogs",
        description = "Removes all Kohl\'s Admin server logs.",
        aliases = { "clrlogs" },
        args = {},

        envClient = function(u1) -- Line: 9, Name: envClient
            u1.Remote.ClearLogs:Connect(function() -- Line: 10
                -- upvalues: u1 (copy)
                local logs = u1.Data.logs;

                for i, v in logs do
                    if not v.client then
                        logs[i] = nil;
                    end;
                end;

                u1.Util.Table.settle(logs);
            end);
        end,

        env = function(u2) -- Line: 21, Name: env
            local u3 = {
                remote = u2.Remote.ClearLogs,

                clearLogs = function() -- Line: 24, Name: clearLogs
                    -- upvalues: u2 (copy)
                    table.clear(u2.Data.logs);
                    table.clear(u2.Data.Sync.logs);
                end
            };
            task.spawn(function() -- Line: 29
                -- upvalues: u2 (copy), u3 (copy)
                u2.Service.Messaging:SubscribeAsync("KA_ClearLogs", u3.clearLogs);
            end);

            return u3;
        end,

        run = function(p4) -- Line: 35, Name: run
            for i = 1, 4 do
                task.spawn(p4._K.Data.Store.removeAsync, "Logs_" .. i);
                local _ = i;
            end;

            p4._K.Service.Messaging:PublishAsync("KA_ClearLogs");

            for _, v in p4._K.Service.Players:GetPlayers() do
                p4._K.Remote.ClearLogs:Fire(v);
            end;
        end
    },
    {
        name = "hidelogs",
        description = "Hides the Kohl\'s Admin logs of one or more player(s).",
        aliases = { "unhidelogs" },
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) whose logs to hide.",
                shouldRequest = true
            } },

        run = function(u5, u6) -- Line: 57, Name: run
            if u5.undo then
                task.defer(function() -- Line: 59
                    -- upvalues: u6 (copy), u5 (copy)
                    for _, v in u6 do
                        u5._K.Data.logsHidden[v.UserId] = not u5.undo;
                    end;
                end);

                return;
            end;

            for _, v in u6 do
                u5._K.Data.logsHidden[v.UserId] = true;
            end;
        end
    },
    {
        name = "script",
        description = "Runs a script.",
        aliases = { "s", "loadstring" },
        args = { {
                type = "rawString",
                name = "Source",
                description = "The source of the script."
            } },

        run = function(p7: any, p8: string) -- Line: 82, Name: run
            if p7._K.Data.SEPARATE_DATASTORE then
                return "Script commands are disabled in private servers.";
            end;

            table.insert(p7._K.cleanupCommands, p7._K.LoadScript(p8, "Server"));
        end
    },
    {
        name = "localscript",
        description = "Runs a script locally for one or more player(s).",
        aliases = { "ls" },
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) to run the localscript on.",
                shouldRequest = true
            }, {
                type = "rawString",
                name = "Source",
                description = "The source of the localscript."
            } },

        run = function(p9: any, p10: table, p11: string) -- Line: 107, Name: run
            if p9._K.Data.SEPARATE_DATASTORE then
                return "Script commands are disabled in private servers.";
            end;

            for _, _ in p10 do
                local v12 = p9.fromPlayer:FindFirstChildOfClass("PlayerGui");

                if v12 then
                    table.insert(p9._K.cleanupCommands, p9._K.LoadScript(p11, "Client", v12));
                end;
            end;
        end
    }
};