-- Decompiled with Potassium's decompiler.

local AvatarEditorService = game:GetService("AvatarEditorService");
local InsertService = game:GetService("InsertService");
local MarketplaceService = game:GetService("MarketplaceService");
local RunService = game:GetService("RunService");
local Util = require(script.Parent.Parent:WaitForChild("Util"));
local EmoteType = Util.Remote.EmoteType;
local u1 = nil;
local u2 = {};
local u3 = {};
local u4 = {};
local u5 = {};

local function isEmote(p6: number) -- Line: 17
    -- upvalues: u3 (copy), MarketplaceService (copy), u2 (copy), u1 (ref)
    if u3[p6] then
        return u3[p6];
    end;

    local success, result = pcall(MarketplaceService.GetProductInfoAsync, MarketplaceService, p6);

    if not (success and (type(result) == "table" and result.AssetTypeId == Enum.AssetType.EmoteAnimation.Value)) then
        return false;
    end;

    local v7 = {
        name = result.Name,
        nameLower = string.lower(result.Name),
        emoteId = p6
    };
    local IsForSale = result.IsForSale;

    if IsForSale then
        IsForSale = not (result.isLimited or result.isLimitedUnique);
    end;

    v7.canSell = IsForSale;
    table.insert(u2, v7);
    u3[p6] = v7;

    if v7.canSell then
        u1.VIP.allowedBulkPurchaseIds[p6] = true;
    end;

    return v7;
end;

local function getAnimationIdFromEmoteId(u8: number) -- Line: 41
    -- upvalues: u5 (copy), isEmote (copy), RunService (copy), InsertService (copy), u4 (copy), u3 (copy), EmoteType (copy)
    if u5[u8] then
        return u5[u8];
    end;

    if not isEmote(u8) then
        return;
    end;

    if RunService:IsClient() then
        return 0;
    end;

    local success, result = pcall(function() -- Line: 55
        -- upvalues: InsertService (ref), u8 (copy)
        local v9 = InsertService:LoadAsset(u8);
        local v10 = v9:FindFirstChildWhichIsA("Animation");

        if v10 then
            v10 = v10.AnimationId;
        end;

        v9:Destroy();

        return v10;
    end);

    if not (success and result) then
        warn(result);

        return;
    end;

    local string_match_ret = string.match(result, "%d+$");

    if string_match_ret then
        local v11 = tonumber(string_match_ret);
        u4[v11] = u8;
        u5[u8] = v11;
        local v12 = u3[u8];

        if v12 then
            v12.animationId = v11;
            EmoteType:FireAll({ v12 });
        end;

        return v11;
    end;

    warn("Invalid animationId");
end;

local function pagesToTable(p13) -- Line: 86
    local v14 = {};

    while true do
        local CurrentPage = p13:GetCurrentPage();
        table.move(CurrentPage, 1, #CurrentPage, #v14 + 1, v14);

        if p13.IsFinished then
            break;
        end;

        p13:AdvanceToNextPageAsync();
    end;

    return v14;
end;

task.spawn(function() -- Line: 99
    -- upvalues: RunService (copy), Util (copy), AvatarEditorService (copy), pagesToTable (copy), u2 (copy), u3 (copy), u1 (ref), getAnimationIdFromEmoteId (copy), EmoteType (copy), u5 (copy), u4 (copy)
    if not RunService:IsServer() then
        EmoteType:Connect(function(p15) -- Line: 144
            -- upvalues: u5 (ref), u4 (ref), u3 (ref), u2 (ref), u1 (ref)
            for _, v in p15 do
                u5[v.emoteId] = v.animationId;
                u4[v.animationId] = v.emoteId;
                local v16 = u3[v.emoteId];

                if v16 then
                    table.clear(v16);

                    for i, v2 in v do
                        v16[i] = v2;
                    end;
                else
                    table.insert(u2, v);
                    u3[v.emoteId] = v;
                end;
            end;

            if u1 and (u1.Registry.commands.emotes and (u1.Registry.commands.emotes.env and u1.Registry.commands.emotes.env.scroller)) then
                u1.Registry.commands.emotes.env.scroller:refreshList();
            end;
        end);
        EmoteType:Fire();

        return;
    end;

    local CatalogSearchParams_new_ret = CatalogSearchParams.new();
    CatalogSearchParams_new_ret.AssetTypes = { Enum.AvatarAssetType.EmoteAnimation };
    CatalogSearchParams_new_ret.CreatorId = 3403354;
    CatalogSearchParams_new_ret.CreatorType = Enum.CreatorTypeFilter.Group;
    local v17, u18 = Util.Retry(function() -- Line: 106
        -- upvalues: AvatarEditorService (ref), CatalogSearchParams_new_ret (copy)
        return AvatarEditorService:SearchCatalogAsync(CatalogSearchParams_new_ret);
    end);

    if not v17 then
        warn(u18);

        return;
    end;

    local v19, v20 = Util.Retry(function() -- Line: 115
        -- upvalues: pagesToTable (ref), u18 (copy)
        return pagesToTable(u18);
    end);

    if not v19 then
        warn(v20);

        return;
    end;

    local v21 = Util.Tasks.new();

    for _, v in v20 do
        local v22 = {
            default = true,
            animationId = 0,
            emoteId = v.Id,
            name = v.Name,
            nameLower = string.lower(v.Name)
        };
        table.insert(u2, v22);
        u3[v.Id] = v22;
        u1.VIP.allowedBulkPurchaseIds[v.Id] = true;
        v21:add(getAnimationIdFromEmoteId, v.Id);
    end;

    v21:wait();
    EmoteType:Connect(function(p23) -- Line: 140
        -- upvalues: EmoteType (ref), u2 (ref)
        EmoteType:Fire(p23, u2);
    end);
end);
local u32 = {
    filterLog = true,

    transform = function(p24) -- Line: 175, Name: transform
        return tonumber(p24) or p24;
    end,

    validate = function(p25) -- Line: 178, Name: validate
        if type(p25) == "number" and p25 ~= math.floor(p25) then
            return false, "Only whole numbers are valid";
        end;

        return p25 ~= nil, "Invalid emote";
    end,

    parse = function(p26, p27) -- Line: 184, Name: parse
        -- upvalues: getAnimationIdFromEmoteId (copy), u2 (copy)
        if type(p26) == "number" then
            local v28 = getAnimationIdFromEmoteId(p26);

            if v28 then
                return v28;
            end;
        elseif type(p26) == "string" then
            local string_lower_ret = string.lower(p26);
            local v29 = nil;

            for _, v in u2 do
                if string_lower_ret == v.nameLower then
                    return v.animationId;
                end;

                if not v29 and string.find(v.nameLower, string_lower_ret, 1, true) == 1 then
                    v29 = v;
                end;
            end;

            if v29 then
                return v29.animationId;
            end;
        end;

        if p27.definition.optional and p27.rawArg == "" then
            return "";
        end;

        return nil, "Could not parse emote";
    end,

    suggestions = function(p30) -- Line: 210, Name: suggestions
        -- upvalues: u2 (copy)
        local v31 = {};

        if not tonumber(p30) then
            p30 = nil;
        end;

        v31[1] = p30;

        for _, v in u2 do
            table.insert(v31, v.name);
        end;

        return v31;
    end
};

return function(p33) -- Line: 219
    -- upvalues: u1 (ref), u4 (copy), u5 (copy), u3 (copy), u2 (copy), u32 (copy)
    u1 = p33;
    u1.Data.animationToEmoteId = u4;
    u1.Data.emoteToAnimationId = u5;
    u1.Data.emoteItemFromId = u3;
    u1.Data.emotes = u2;
    u1.Registry.registerType("emote", u32);
    u1.Registry.registerType("emotes", {
        listable = true
    }, u32);
end;