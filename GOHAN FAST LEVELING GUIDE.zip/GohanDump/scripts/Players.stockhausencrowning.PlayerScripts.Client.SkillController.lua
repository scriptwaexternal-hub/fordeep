-- Decompiled with Potassium's decompiler.

local ReplicatedStorage = game:GetService("ReplicatedStorage");
local Players = game:GetService("Players");
game:GetService("UserInputService");
local Modules = ReplicatedStorage:WaitForChild("Modules");
local Metadata = Modules.Metadata;
local Remotes = ReplicatedStorage:WaitForChild("Remotes");
local SkillData = require(Metadata.SkillData.SkillData);
local StateManager = require(ReplicatedStorage.Modules.Metadata.ControlData.StateManager);
local CooldownHandler = require(ReplicatedStorage.Modules.Utility.CooldownHandler);
local SoundManager = require(ReplicatedStorage.Modules.Shared.SoundManager);
local TweenService = game:GetService("TweenService");
local SkillRemote = Remotes.SkillRemote;
local StatRetrieveRemote = Remotes:WaitForChild("StatRetrieveRemote");
local LocalPlayer = Players.LocalPlayer;
local Color3_fromRGB_ret = Color3.fromRGB(255, 60, 60);

local function flashSlotsNoKi(p1) -- Line: 56
    -- upvalues: SoundManager (copy), LocalPlayer (copy), Color3_fromRGB_ret (copy), TweenService (copy)
    SoundManager.AddSound("Incorrect", {
        Parent = workspace.CurrentCamera
    }, "Client");
    local PlayerGui = LocalPlayer:FindFirstChild("PlayerGui");

    if PlayerGui then
        PlayerGui = PlayerGui:FindFirstChild("HUD");
    end;

    if PlayerGui then
        PlayerGui = PlayerGui:FindFirstChild("Inventory");
    end;

    if PlayerGui then
        PlayerGui = PlayerGui:FindFirstChild("RegSlots");
    end;

    if not PlayerGui then
        return;
    end;

    for _, child in ipairs(PlayerGui:GetChildren()) do
        local u2 = child:IsA("Frame") and child:FindFirstChild("ItemFrame");
        local v3;

        if u2 then
            v3 = u2:FindFirstChild("ItemName");
        else
            v3 = u2;
        end;

        if v3 and (v3.Text == p1 and not u2:GetAttribute("NoKiFlashing")) then
            u2:SetAttribute("NoKiFlashing", true);
            local Frame = Instance.new("Frame");
            Frame.Name = "NoKiFlash";
            Frame.Size = UDim2.fromScale(1, 1);
            Frame.BackgroundColor3 = Color3_fromRGB_ret;
            Frame.BackgroundTransparency = 0.45;
            Frame.BorderSizePixel = 0;
            Frame.ZIndex = (u2.ZIndex or 1) + 5;
            local UICorner = Instance.new("UICorner");
            UICorner.CornerRadius = UDim.new(0, 6);
            UICorner.Parent = Frame;
            Frame.Parent = u2;
            task.spawn(function() -- Line: 78
                -- upvalues: u2 (copy), Frame (copy), TweenService (ref)
                local Position = u2.Position;
                local os_clock_ret = os.clock();

                while os.clock() - os_clock_ret < 0.45 and u2.Parent do
                    local v4 = os.clock() - os_clock_ret;
                    local v5 = 5 * (1 - v4 / 0.45);
                    u2.Position = Position + UDim2.fromOffset(math.random(-v5, v5), math.random(-v5, v5));
                    local math_sin_ret = math.sin(v4 * 22);
                    Frame.BackgroundTransparency = math.abs(math_sin_ret) * 0.4 + 0.35;
                    task.wait();
                end;

                if u2.Parent then
                    u2.Position = Position;
                end;

                TweenService:Create(Frame, TweenInfo.new(0.2), {
                    BackgroundTransparency = 1
                }):Play();
                task.wait(0.2);
                Frame:Destroy();
                u2:SetAttribute("NoKiFlashing", nil);
            end);
        end;
    end;
end;

local u6 = false;

local function refreshAutoFire() -- Line: 106
    -- upvalues: StatRetrieveRemote (copy), u6 (ref)
    task.spawn(function() -- Line: 107
        -- upvalues: StatRetrieveRemote (ref), u6 (ref)
        local success, result = pcall(function() -- Line: 108
            -- upvalues: StatRetrieveRemote (ref)
            return StatRetrieveRemote:InvokeServer("AutoFire");
        end);

        if success then
            u6 = result == true;
        end;
    end);
end;

local function readAutoFire() -- Line: 116
    -- upvalues: StatRetrieveRemote (copy), u6 (ref)
    local success, result = pcall(function() -- Line: 117
        -- upvalues: StatRetrieveRemote (ref)
        return StatRetrieveRemote:InvokeServer("AutoFire");
    end);

    if success then
        u6 = result == true;
    end;

    return u6;
end;

task.spawn(function() -- Line: 107
    -- upvalues: StatRetrieveRemote (copy), u6 (ref)
    local success, result = pcall(function() -- Line: 108
        -- upvalues: StatRetrieveRemote (ref)
        return StatRetrieveRemote:InvokeServer("AutoFire");
    end);

    if success then
        u6 = result == true;
    end;
end);
local u7 = {};
local Skills = Modules:FindFirstChild("Skills");

if Skills then
    for _, descendant in pairs(Skills:GetDescendants()) do
        if descendant:IsA("ModuleScript") then
            u7[descendant.Name] = require(descendant);
        end;
    end;
end;

local u8 = {};

local function getPlayerStats() -- Line: 147
    -- upvalues: LocalPlayer (copy)
    return LocalPlayer:FindFirstChild("PlayerStats");
end;

local function getCooldownDuration(p9, p10, p11) -- Line: 151
    -- upvalues: SkillData (copy), LocalPlayer (copy)
    local Any = SkillData.GetAny(p10, p9, p11);
    local v12 = Any and Any.Cooldown or 5;
    local PlayerStats = LocalPlayer:FindFirstChild("PlayerStats");

    if PlayerStats then
        PlayerStats = PlayerStats:FindFirstChild("CooldownFactor", true);
    end;

    local Character = LocalPlayer.Character;
    local v13 = Character and Character:GetAttribute("CD_" .. tostring(p9):gsub("%W", "")) or 1;

    if PlayerStats then
        v12 = PlayerStats.Value * v12 or v12;
    end;

    return v12 * v13;
end;

local function startCooldown(u14, p15, p16, p17) -- Line: 161
    -- upvalues: u8 (copy), getCooldownDuration (copy), CooldownHandler (copy), LocalPlayer (copy)
    local v18 = u8[u14];

    if not v18 then
        return;
    end;

    v18.onCooldown = true;
    local v19 = getCooldownDuration(p15, p16, p17);
    CooldownHandler.Start(LocalPlayer, u14.Name, v19);
    task.delay(v19, function() -- Line: 169
        -- upvalues: u8 (ref), u14 (copy)
        if u8[u14] then
            u8[u14].onCooldown = false;
        end;
    end);
end;

local function resetToolState(p20) -- Line: 176
    -- upvalues: u8 (copy)
    local v21 = u8[p20];

    if not v21 then
        return;
    end;

    v21.canFire = false;
end;

local function finishTouchCast(u22, u23, p24) -- Line: 185
    if not u22:GetAttribute("TouchCast") then
        return;
    end;

    u22:SetAttribute("TouchCast", nil);

    if p24 then
        return;
    end;

    task.delay(0.1, function() -- Line: 189
        -- upvalues: u23 (copy), u22 (copy)
        local character = u23.character;
        local v25;

        if character then
            v25 = character:FindFirstChildOfClass("Humanoid");
        else
            v25 = character;
        end;

        if v25 and u22.Parent == character then
            v25:UnequipTools();
        end;
    end);
end;

local function disconnectTool(p26) -- Line: 196
    -- upvalues: u8 (copy)
    local v27 = u8[p26];

    if not v27 then
        return;
    end;

    for _, v in pairs(v27.connections) do
        v:Disconnect();
    end;

    u8[p26] = nil;
end;

local function fireSkill(p28, p29, p30, p31, p32, p33) -- Line: 211
    -- upvalues: SkillRemote (copy), startCooldown (copy)
    if p33 and (p33.OnDeactivated and p33.OnDeactivated(p29.character, p28)) then
        return;
    end;

    SkillRemote:InvokeServer({
        Module = "SkillHandler",
        Action = "Fire",
        SkillModule = p30,
        Attack_Name = p30,
        Attack_Type = p31,
        Race_Type = p32
    });
    startCooldown(p28, p30, p31, p32);
end;

local function connectTool(u34) -- Line: 229
    -- upvalues: u8 (copy), LocalPlayer (copy), u7 (copy), StatRetrieveRemote (copy), u6 (ref), finishTouchCast (copy), StateManager (copy), startCooldown (copy), SkillData (copy), SkillRemote (copy), flashSlotsNoKi (copy), fireSkill (copy)
    local Attribute = u34:GetAttribute("SkillName");
    local Attribute2 = u34:GetAttribute("AttackType");
    local Attribute3 = u34:GetAttribute("RaceType");

    if Attribute == nil and Attribute2 == nil then
        return;
    end;

    if Attribute == nil or (Attribute == "" or (Attribute2 == nil or Attribute2 == "")) then
        warn("SkillController: skill tool \'" .. u34.Name .. "\' has empty SkillName or AttackType — not connected");

        return;
    end;

    u8[u34] = {
        onCooldown = false,
        canFire = false,
        charging = false,
        pendingFire = false,
        connections = {},
        character = LocalPlayer.Character
    };
    local u35 = u8[u34];
    local u36 = u7[Attribute];
    u35.connections[1] = u34.Equipped:Connect(function() -- Line: 268
        -- upvalues: u35 (copy), LocalPlayer (ref), u34 (copy), u8 (ref), u36 (copy), StatRetrieveRemote (ref), u6 (ref)
        u35.character = LocalPlayer.Character or LocalPlayer.CharacterAdded:Wait();
        local v37 = u8[u34];

        if v37 then
            v37.canFire = false;
        end;

        if u36 and u36.OnEquipped then
            u36.OnEquipped(u35.character, u34);
        end;

        local success, result = pcall(function() -- Line: 117
            -- upvalues: StatRetrieveRemote (ref)
            return StatRetrieveRemote:InvokeServer("AutoFire");
        end);

        if success then
            u6 = result == true;
        end;

        if u6 and not (u36 or u34:GetAttribute("TouchCast")) then
            task.defer(function() -- Line: 292
                -- upvalues: u34 (ref), u35 (ref)
                if u34.Parent ~= u35.character then
                    return;
                end;

                if u35.onCooldown then
                    local v38 = u35.character and u35.character:FindFirstChildOfClass("Humanoid");

                    if v38 then
                        v38:UnequipTools();
                    end;

                    return;
                end;

                u34:Activate();
                task.wait();
                u34:Deactivate();
                local v39 = os.clock() + 8;

                while os.clock() < v39 and (u35.charging or u35.canFire) do
                    task.wait();
                end;

                task.wait(0.1);
                local v40 = u35.character and u35.character:FindFirstChildOfClass("Humanoid");

                if v40 and u34.Parent == u35.character then
                    v40:UnequipTools();
                end;
            end);
        end;
    end);
    u35.connections[2] = u34.Unequipped:Connect(function() -- Line: 318
        -- upvalues: u34 (copy), u8 (ref), u36 (copy), u35 (copy)
        local v41 = u8[u34];

        if v41 then
            v41.canFire = false;
        end;

        if u36 and u36.OnUnequipped then
            u36.OnUnequipped(u35.character, u34);
        end;
    end);
    u35.connections[3] = u34.Activated:Connect(function() -- Line: 327
        -- upvalues: u35 (copy), LocalPlayer (ref), finishTouchCast (ref), u34 (copy), u36 (copy), StateManager (ref), Attribute (copy), startCooldown (ref), Attribute2 (copy), Attribute3 (copy), SkillData (ref), SkillRemote (ref), flashSlotsNoKi (ref), fireSkill (ref)
        u35.character = u35.character or LocalPlayer.Character;

        if not u35.character then
            return;
        end;

        if u35.onCooldown then
            finishTouchCast(u34, u35, u36);

            return;
        end;

        if not StateManager.CanPerformAction(u35.character, Attribute, "Skill") then
            finishTouchCast(u34, u35, u36);

            return;
        end;

        if u36 and u36.OnActivated then
            local v42, v43 = u36.OnActivated(u35.character, u34);

            if v42 then
                if v43 then
                    startCooldown(u34, Attribute, Attribute2, Attribute3);
                end;

                finishTouchCast(u34, u35, u36);

                return;
            end;
        end;

        local Any = SkillData.GetAny(Attribute2, Attribute, Attribute3);

        if Any then
            Any = Any.KiCost;
        end;

        u35.charging = true;
        u35.pendingFire = false;
        local v44 = SkillRemote:InvokeServer({
            Module = "SkillHandler",
            Action = "Charge",
            SkillModule = Attribute,
            KiCost = Any,
            Attack_Name = Attribute,
            Attack_Type = Attribute2,
            Race_Type = Attribute3
        });
        u35.charging = false;

        if v44 == "QuickFired" then
            startCooldown(u34, Attribute, Attribute2, Attribute3);
        elseif v44 == "NoKi" then
            flashSlotsNoKi(u34.Name);
            local v45 = u35.character and u35.character:FindFirstChild("Humanoid");

            if v45 then
                v45:UnequipTools();
            end;
        elseif v44 then
            u35.canFire = true;

            if u35.pendingFire then
                u35.pendingFire = false;
                u35.canFire = false;
                fireSkill(u34, u35, Attribute, Attribute2, Attribute3, u36);
            end;
        end;

        if not u35.canFire then
            finishTouchCast(u34, u35, u36);
        end;
    end);
    u35.connections[4] = u34.Deactivated:Connect(function() -- Line: 399
        -- upvalues: u35 (copy), fireSkill (ref), u34 (copy), Attribute (copy), Attribute2 (copy), Attribute3 (copy), u36 (copy), finishTouchCast (ref)
        if u35.charging then
            u35.pendingFire = true;

            return;
        end;

        if not u35.canFire then
            return;
        end;

        if not u35.character then
            return;
        end;

        u35.canFire = false;
        fireSkill(u34, u35, Attribute, Attribute2, Attribute3, u36);
        finishTouchCast(u34, u35, u36);
    end);
end;

local function watchCharacter(u46) -- Line: 420
    -- upvalues: LocalPlayer (copy), connectTool (copy), u8 (copy)
    local Backpack = LocalPlayer:WaitForChild("Backpack");

    for _, child in pairs(Backpack:GetChildren()) do
        if child:IsA("Tool") then
            connectTool(child);
        end;
    end;

    Backpack.ChildAdded:Connect(function(p47) -- Line: 431
        -- upvalues: u8 (ref), connectTool (ref)
        if p47:IsA("Tool") and not u8[p47] then
            connectTool(p47);
        end;
    end);
    Backpack.ChildRemoved:Connect(function(p48) -- Line: 441
        -- upvalues: u46 (copy), u8 (ref)
        if p48:IsA("Tool") and p48.Parent ~= u46 then
            local v49 = u8[p48];

            if not v49 then
                return;
            end;

            for _, v in pairs(v49.connections) do
                v:Disconnect();
            end;

            u8[p48] = nil;
        end;
    end);
    u46.ChildAdded:Connect(function(p50) -- Line: 448
        -- upvalues: u8 (ref), connectTool (ref)
        if p50:IsA("Tool") and not u8[p50] then
            connectTool(p50);
        end;
    end);
    u46.ChildRemoved:Connect(function(p51) -- Line: 455
        -- upvalues: Backpack (copy), u8 (ref)
        if p51:IsA("Tool") and p51.Parent ~= Backpack then
            local v52 = u8[p51];

            if not v52 then
                return;
            end;

            for _, v in pairs(v52.connections) do
                v:Disconnect();
            end;

            u8[p51] = nil;
        end;
    end);
end;

if LocalPlayer.Character then
    watchCharacter(LocalPlayer.Character);
end;

LocalPlayer.CharacterAdded:Connect(watchCharacter);