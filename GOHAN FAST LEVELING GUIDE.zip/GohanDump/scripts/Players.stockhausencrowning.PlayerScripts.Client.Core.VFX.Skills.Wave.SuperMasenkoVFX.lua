-- Decompiled with Potassium's decompiler.

local ReplicatedStorage = game:GetService("ReplicatedStorage");
local RunService = game:GetService("RunService");
local Modules = ReplicatedStorage:WaitForChild("Modules");
local GlobalFunctions = require(Modules.GlobalFunctions);
local SoundManager = require(Modules.Shared.SoundManager);
local Lightning = require(Modules.Effects.VfxHandler.Lightning);
local BeamRigVFX = require(script.Parent.BeamRigVFX);
local Color3_fromRGB_ret = Color3.fromRGB(255, 245, 160);

return {
    Fire = function(p1) -- Line: 34
        -- upvalues: GlobalFunctions (copy), Lightning (copy), Color3_fromRGB_ret (copy), RunService (copy), BeamRigVFX (copy), SoundManager (copy)
        local Character = p1.Character;

        if not Character then
            return;
        end;

        local RootAndHumanoid = GlobalFunctions.GetRootAndHumanoid(Character);

        if not RootAndHumanoid then
            return;
        end;

        local v2 = p1.StartSize or 5;
        local u3 = p1.Length or 10;
        local u4 = p1.Speed or 5;
        local u5 = p1.Duration or 4;
        local u6 = p1.CloseDuration or 0.5;
        local v7 = p1.StartLocation or RootAndHumanoid.CFrame * CFrame.new(0, 0, -5);
        local Position = v7.Position;
        local v8 = (p1.MousePosition or (p1.DefaultEndLocation or (v7 * CFrame.new(0, 0, -u3)).Position)) - Position;

        if v8.Magnitude < 0.01 then
            v8 = v7.LookVector;
        end;

        local Unit = v8.Unit;
        local u9 = v2 * 0.5 * 1.3 + 1.5 + 1.575;

        local function spawnStream(p10, p11) -- Line: 59
            -- upvalues: u9 (copy), Lightning (ref), Color3_fromRGB_ret (ref)
            local math_floor_ret = math.floor(p11 / 8);
            local math_clamp_ret = math.clamp(math_floor_ret, 4, 16);
            local v12 = math.random() * 3.141592653589793 * 2;
            local v13 = (math.random() - 0.5) * 0.9;
            local v14 = {};

            for i = 0, math_clamp_ret do
                local v15;

                if i == math_clamp_ret then
                    v15 = p11 + 2;
                else
                    v15 = i / math_clamp_ret * p11 + (math.random() - 0.5) * 8 * 0.5;
                end;

                local v16 = u9 + math.random() * 4;

                if i == math_clamp_ret then
                    v16 = u9 * 0.6;
                end;

                v12 = v12 + (v13 + (math.random() - 0.5) * 0.4);
                v14[#v14 + 1] = (p10 * CFrame.new(math.cos(v12) * v16, math.sin(v12) * v16, -math.max(v15, 0))).Position;
                local _ = i;
            end;

            task.spawn(Lightning.New, v14[1], v14[#v14], math_clamp_ret, {
                NoSound = true,
                Points = v14,
                MINWIDTH = 2.1 + math.random() * 1.0499999999999998,
                Color = Color3_fromRGB_ret
            });
        end;

        local os_clock_ret = os.clock();
        local u17 = 0;
        local u18 = 0;
        local u19 = nil;
        u19 = RunService.Heartbeat:Connect(function() -- Line: 88
            -- upvalues: os_clock_ret (copy), u4 (copy), u5 (copy), u6 (copy), Character (copy), u19 (ref), BeamRigVFX (ref), Position (copy), Unit (ref), u3 (copy), u18 (ref), SoundManager (ref), RootAndHumanoid (copy), u17 (ref), spawnStream (copy)
            local v20 = os.clock() - os_clock_ret;

            if u4 + u5 + u6 < v20 or not Character.Parent then
                u19:Disconnect();

                return;
            end;

            local v21 = BeamRigVFX.Active and BeamRigVFX.Active[Character];
            local v22 = Position;
            local v23 = Unit;
            local v24 = u3;

            if v21 then
                v22 = v21.StartPos or v22;
                v23 = v21.Dir or v23;
                v24 = v21.Length or v24;
            end;

            local v25 = math.min(v20 / u4, 1) * v24;

            if v21 and v21.ClashDist then
                v25 = math.clamp(v21.ClashDist, 1, v24);
            end;

            if v25 < 6 then
                return;
            end;

            if v20 - u18 > 0.3 then
                u18 = v20;
                SoundManager.AddSound("Sparks", {
                    Parent = RootAndHumanoid,
                    PlaybackSpeed = math.random(80, 120) / 100
                }, "Client", {
                    Duration = 0.6
                });
            end;

            if v20 < u17 then
                return;
            end;

            u17 = v20 + 0.14;
            local v26 = v23:Dot(Vector3.new(0, 1, 0));
            local v27 = math.abs(v26) > 0.99 and Vector3.new(0, 0, 1) or Vector3.new(0, 1, 0);
            local CFrame_lookAt_ret = CFrame.lookAt(v22, v22 + v23, v27);
            spawnStream(CFrame_lookAt_ret, v25);
            spawnStream(CFrame_lookAt_ret, v25);
            spawnStream(CFrame_lookAt_ret, v25);
            spawnStream(CFrame_lookAt_ret, v25);
        end);
    end
};