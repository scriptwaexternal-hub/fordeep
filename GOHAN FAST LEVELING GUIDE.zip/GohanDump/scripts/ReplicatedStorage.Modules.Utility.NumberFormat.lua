-- Decompiled with Potassium's decompiler.

local v1 = {};

local function groupDigits(p2) -- Line: 30
    return p2:reverse():gsub("(%d%d%d)", "%1,"):reverse():gsub("^,", "");
end;

function v1.Comma(p3, p4) -- Line: 44
    if type(p3) ~= "number" then
        return "0";
    end;

    if p3 ~= p3 then
        return "0";
    end;

    if p3 == (1 / 0) then
        return "∞";
    end;

    if p3 == (-1 / 0) then
        return "-∞";
    end;

    local math_abs_ret = math.abs(p3);
    local string_format_ret = string.format("%." .. (p4 or 0) .. "f", math_abs_ret);
    local v5, v6 = string_format_ret:match("^(%d+)%.?(%d*)$");

    if not v5 then
        return string_format_ret;
    end;

    local v7 = v5:reverse():gsub("(%d%d%d)", "%1,"):reverse():gsub("^,", "");

    if v6 ~= "" then
        v7 = v7 .. "." .. v6;
    end;

    if p3 < 0 then
        v7 = "-" .. v7;
    end;

    return v7;
end;

local u8 = { "", "K", "M", "B", "T", "Qa", "Qi", "Sx", "Sp", "Oc", "No", "Dc" };

function v1.Short(p9) -- Line: 74
    -- upvalues: u8 (copy)
    if type(p9) ~= "number" then
        return "0";
    end;

    if p9 ~= p9 then
        return "0";
    end;

    if p9 == (1 / 0) then
        return "∞";
    end;

    if p9 == (-1 / 0) then
        return "-∞";
    end;

    local math_abs_ret = math.abs(p9);
    local v10 = 1;

    while math_abs_ret >= 1000 and v10 < #u8 do
        math_abs_ret = math_abs_ret / 1000;
        v10 = v10 + 1;
    end;

    local v11;

    if v10 == 1 then
        v11 = string.format("%.0f", math_abs_ret);
    else
        v11 = string.format("%.2f", math_abs_ret):gsub("%.?0+$", "") .. u8[v10];
    end;

    if math_abs_ret >= 1000 then
        v11 = string.format("%.2e", math_abs_ret * 1000 ^ (v10 - 1));
    end;

    if p9 < 0 then
        v11 = "-" .. v11 or v11;
    end;

    return v11;
end;

return v1;