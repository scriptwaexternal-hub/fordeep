-- Decompiled with Potassium's decompiler.

local LocalPlayer = game:GetService("Players").LocalPlayer;
local HUDMAIN = script:FindFirstAncestor("HUD").MainFrame.HUDisplay.HUDMAIN;
local KiLabel = HUDMAIN.KiLabel;
local FalseKiMeter = HUDMAIN.FalseKiMeter;
local PlayerStats = LocalPlayer:WaitForChild("PlayerStats");
local Ki = PlayerStats:FindFirstChild("Ki", true);
local MaxKi = PlayerStats:FindFirstChild("MaxKi", true);
local v1 = {};
local ImageColor3 = KiLabel.ImageColor3;
local Color3_fromRGB_ret = Color3.fromRGB(170, 80, 255);

local function bindBurstTint(u2) -- Line: 37
    -- upvalues: KiLabel (copy), Color3_fromRGB_ret (copy), ImageColor3 (copy)
    local function apply() -- Line: 38
        -- upvalues: KiLabel (ref), u2 (copy), Color3_fromRGB_ret (ref), ImageColor3 (ref)
        KiLabel.ImageColor3 = u2:GetAttribute("State_KiBurst") ~= nil and Color3_fromRGB_ret or ImageColor3;
    end;

    u2:GetAttributeChangedSignal("State_KiBurst"):Connect(apply);
    KiLabel.ImageColor3 = u2:GetAttribute("State_KiBurst") ~= nil and Color3_fromRGB_ret or ImageColor3;
end;

if LocalPlayer.Character then
    local Character = LocalPlayer.Character;
    Character:GetAttributeChangedSignal("State_KiBurst"):Connect(function() -- Line: 38, Name: apply
        -- upvalues: KiLabel (copy), Character (copy), Color3_fromRGB_ret (copy), ImageColor3 (copy)
        KiLabel.ImageColor3 = Character:GetAttribute("State_KiBurst") ~= nil and Color3_fromRGB_ret or ImageColor3;
    end);

    if Character:GetAttribute("State_KiBurst") ~= nil and Color3_fromRGB_ret then
        ImageColor3 = Color3_fromRGB_ret;
    end;

    KiLabel.ImageColor3 = ImageColor3;
end;

LocalPlayer.CharacterAdded:Connect(bindBurstTint);

function v1.Update() -- Line: 48
    -- upvalues: Ki (copy), MaxKi (copy), KiLabel (copy), FalseKiMeter (copy)
    local math_min_ret = math.min(Ki.Value / MaxKi.Value, 1);
    KiLabel:TweenSize(UDim2.new(math_min_ret * 0.595, 0, 0.099, 0), "Out", "Sine", 0.1, true);
    FalseKiMeter:TweenSize(UDim2.new(math_min_ret * 0.595, 0, 0.099, 0), "Out", "Sine", 0.7, true);
end;

return v1;