-- Decompiled with Potassium's decompiler.

local Players = game:GetService("Players");
local Debris = game:GetService("Debris");
local ReplicatedStorage = game:GetService("ReplicatedStorage");
local RunService = game:GetService("RunService");
local ContextActionService = game:GetService("ContextActionService");
local TweenService = game:GetService("TweenService");
local UserInputService = game:GetService("UserInputService");
local Assets = ReplicatedStorage.Assets;
local Modules = ReplicatedStorage:WaitForChild("Modules");
local Remotes = ReplicatedStorage:WaitForChild("Remotes");
local TouchActionRemote = Remotes:WaitForChild("TouchActionRemote");
local Shared = Modules.Shared;
local SoundManager = require(Shared.SoundManager);
require(Modules.GlobalFunctions);
local CinemaManager = require(Shared.CinemaManager);
local BeamRigVFX = require(script.Parent.BeamRigVFX);
local BeamClashRemote = Remotes:WaitForChild("BeamClashRemote");
local LocalPlayer = Players.LocalPlayer;
local workspace_CurrentCamera = workspace.CurrentCamera;
local Visuals = workspace.World.Visuals;
local Wave = Assets.Effects.Skills.Wave;
local Particles = Assets.Effects.Particles;
local u1 = { "W", "A", "S", "D" };
local u2 = {
    Enum.KeyCode.W,
    Enum.KeyCode.A,
    Enum.KeyCode.S,
    Enum.KeyCode.D,
    Enum.KeyCode.X,
    Enum.KeyCode.F,
    Enum.KeyCode.Space,
    Enum.KeyCode.ButtonY,
    Enum.KeyCode.ButtonX,
    Enum.KeyCode.ButtonA,
    Enum.KeyCode.ButtonB
};
local u3 = {
    ButtonY = "W",
    ButtonX = "A",
    ButtonA = "S",
    ButtonB = "D"
};
local u4 = {
    W = "Y",
    A = "X",
    S = "A",
    D = "B"
};
local Color3_fromRGB_ret = Color3.fromRGB(245, 245, 245);
local Color3_fromRGB_ret2 = Color3.fromRGB(255, 90, 90);
local Color3_fromRGB_ret3 = Color3.fromRGB(80, 220, 120);
local Color3_fromRGB_ret4 = Color3.fromRGB(255, 200, 40);
local TweenInfo_new_ret = TweenInfo.new(0.15, Enum.EasingStyle.Quad, Enum.EasingDirection.Out);
local u5 = UserInputService.TouchEnabled and not UserInputService.KeyboardEnabled;

local function gamepadActive() -- Line: 83
    -- upvalues: UserInputService (copy)
    return UserInputService:GetLastInputType().Name:find("Gamepad") ~= nil;
end;

local function multNumberSequence(p6, p7) -- Line: 87
    local v8 = {};

    for _, v in ipairs(p6.Keypoints) do
        table.insert(v8, NumberSequenceKeypoint.new(v.Time, v.Value * p7, v.Envelope * p7));
    end;

    return NumberSequence.new(v8);
end;

local u9 = {};
local u10 = nil;
local u11 = false;

local function getHUD() -- Line: 108
    -- upvalues: LocalPlayer (copy)
    local ClashGui = LocalPlayer.PlayerGui:FindFirstChild("ClashGui");

    if ClashGui then
        ClashGui = ClashGui:FindFirstChild("ClashHUD");
    end;

    return ClashGui;
end;

local function getSpamBanner(p12) -- Line: 114
    -- upvalues: Color3_fromRGB_ret4 (copy)
    local SpamBanner = p12:FindFirstChild("SpamBanner");

    if SpamBanner then
        return SpamBanner;
    end;

    local KeyPrompt = p12.KeyPrompt;
    local TextLabel = Instance.new("TextLabel");
    TextLabel.Name = "SpamBanner";
    TextLabel.AnchorPoint = Vector2.new(KeyPrompt.AnchorPoint.X, 1);
    TextLabel.Position = UDim2.new(KeyPrompt.Position.X.Scale, KeyPrompt.Position.X.Offset, KeyPrompt.Position.Y.Scale, KeyPrompt.Position.Y.Offset - 10);
    TextLabel.Size = UDim2.new(0, 280, 0, 36);
    TextLabel.BackgroundColor3 = Color3.fromRGB(20, 20, 22);
    TextLabel.BackgroundTransparency = 0.15;
    TextLabel.BorderSizePixel = 0;
    TextLabel.Font = Enum.Font.Arcade;
    TextLabel.TextScaled = true;
    TextLabel.TextColor3 = Color3.new(1, 1, 1);
    TextLabel.Text = "SPAM NOW!";
    TextLabel.Visible = false;
    TextLabel.ZIndex = KeyPrompt.ZIndex + 1;
    local UIStroke = Instance.new("UIStroke");
    UIStroke.Color = Color3_fromRGB_ret4;
    UIStroke.Thickness = 2;
    UIStroke.Parent = TextLabel;
    TextLabel.Parent = p12;

    return TextLabel;
end;

local function setSpamVisible(p13) -- Line: 140
    -- upvalues: LocalPlayer (copy), getSpamBanner (copy), TweenService (copy)
    local ClashGui = LocalPlayer.PlayerGui:FindFirstChild("ClashGui");

    if ClashGui then
        ClashGui = ClashGui:FindFirstChild("ClashHUD");
    end;

    if not ClashGui then
        return;
    end;

    local v14 = getSpamBanner(ClashGui);
    v14.Visible = p13;

    if p13 then
        v14.TextTransparency = 0;
        local v15 = v14:FindFirstChildOfClass("UIScale") or Instance.new("UIScale");
        v15.Scale = 1.25;
        v15.Parent = v14;
        TweenService:Create(v15, TweenInfo.new(0.15, Enum.EasingStyle.Back, Enum.EasingDirection.Out), {
            Scale = 1
        }):Play();
    end;
end;

local function buildStruggle(p16, p17, p18, p19, p20) -- Line: 158
    -- upvalues: Wave (copy), multNumberSequence (copy), Visuals (copy)
    local math_clamp_ret = math.clamp((p19 + p20) * 1.2, 8, 24);
    local v21 = Wave["Wave End"]:Clone();
    local v22 = v21["Inner Wave Point"];
    v21.Name = "BeamClashStruggle";
    v21.Anchored = true;
    v21.CanCollide = false;
    v21.CFrame = CFrame.new(p16);
    v21.Color = p17;
    v21.Size = Vector3.new(1, 1, 1) * math_clamp_ret;
    v21.Transparency = 1;
    v22.Color = p18;
    v22.Size = Vector3.new(1, 1, 1) * math_clamp_ret * 0.85;
    v22.Transparency = 1;
    local v23 = 0;

    for _, child in ipairs(v21.BeamEnd:GetChildren()) do
        if child:IsA("ParticleEmitter") then
            child.Enabled = true;
            child.Size = multNumberSequence(child.Size, math_clamp_ret / 3);

            if child.Name == "Circle0" then
                child.Rate = 150;
            else
                v23 = v23 + 1;
                local v24 = v23 % 2 == 0 and p17 and p17 or p18;
                child.Color = ColorSequence.new({ ColorSequenceKeypoint.new(0, v24), ColorSequenceKeypoint.new(1, v24) });
                child.Rate = child.Rate * 1.5;
            end;
        end;
    end;

    local PointLight = Instance.new("PointLight");
    PointLight.Color = p17;
    PointLight.Range = math_clamp_ret * 1.6;
    PointLight.Brightness = 1.5;
    PointLight.Parent = v21;
    local PointLight2 = Instance.new("PointLight");
    PointLight2.Color = p18;
    PointLight2.Range = math_clamp_ret * 1.2;
    PointLight2.Brightness = 1.5;
    PointLight2.Parent = v22;
    v21.Parent = Visuals;

    return v21;
end;

local function destroyVisual(p25, p26) -- Line: 211
    -- upvalues: Particles (copy), Visuals (copy), Debris (copy), SoundManager (copy)
    if not p25 then
        return;
    end;

    if p25.Conn then
        p25.Conn:Disconnect();
    end;

    local Part = p25.Part;

    if Part and Part.Parent then
        if p26 then
            local v27 = Particles.Clash_Part:Clone();
            v27.CFrame = Part.CFrame;
            v27.Parent = Visuals;
            Debris:AddItem(v27, 4);
            local v28 = Particles.Clash_PFX:Clone();
            v28.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(0.2, Part.Size.X * 2.5), NumberSequenceKeypoint.new(1, Part.Size.X * 2.5) });
            v28.Parent = v27;
            v28:Emit(1);
            SoundManager.AddSound("Heavy_Punch", {
                Parent = v27
            }, "Client");
        end;

        for _, descendant in ipairs(Part:GetDescendants()) do
            if descendant:IsA("ParticleEmitter") then
                descendant.Enabled = false;
            elseif descendant:IsA("PointLight") then
                descendant.Enabled = false;
            end;
        end;

        Debris:AddItem(Part, 2);
    end;
end;

local function stopCamera() -- Line: 244
    -- upvalues: u10 (ref), workspace_CurrentCamera (copy), LocalPlayer (copy)
    if u10 and u10.camConn then
        u10.camConn:Disconnect();
        u10.camConn = nil;
    end;

    workspace_CurrentCamera.CameraType = Enum.CameraType.Custom;
    local Character = LocalPlayer.Character;

    if Character then
        Character = Character:FindFirstChildOfClass("Humanoid");
    end;

    if Character then
        workspace_CurrentCamera.CameraSubject = Character;
    end;
end;

local function startCamera(u29) -- Line: 255
    -- upvalues: u10 (ref), workspace_CurrentCamera (copy), RunService (copy)
    if not u10 then
        return;
    end;

    workspace_CurrentCamera.CameraType = Enum.CameraType.Scriptable;
    local HumanoidRootPart = u10.charA:FindFirstChild("HumanoidRootPart");
    local HumanoidRootPart2 = u10.charB:FindFirstChild("HumanoidRootPart");

    if not (HumanoidRootPart and HumanoidRootPart2) then
        return;
    end;

    local v30 = ((HumanoidRootPart2.Position - HumanoidRootPart.Position) * Vector3.new(1, 0, 1)):Cross(Vector3.new(0, 1, 0));
    local u31 = (workspace_CurrentCamera.CFrame.Position - (HumanoidRootPart.Position + HumanoidRootPart2.Position) / 2):Dot(v30.Magnitude > 0.05 and v30.Unit or Vector3.new(0, 0, 1)) >= 0 and 1 or -1;
    local u32 = 0;
    u10.camConn = RunService.RenderStepped:Connect(function(p33) -- Line: 272
        -- upvalues: HumanoidRootPart (copy), HumanoidRootPart2 (copy), u32 (ref), u31 (copy), u29 (copy), workspace_CurrentCamera (ref)
        if not (HumanoidRootPart.Parent and HumanoidRootPart2.Parent) then
            return;
        end;

        u32 = u32 + p33 * 0.05;
        local Position = HumanoidRootPart.Position;
        local Position2 = HumanoidRootPart2.Position;
        local v34 = (Position + Position2) / 2;
        local v35 = (Position2 - Position) * Vector3.new(1, 0, 1);
        local math_max_ret = math.max(v35.Magnitude, 8);
        local v36 = v35:Cross(Vector3.new(0, 1, 0));
        local v37 = (v36.Magnitude > 0.05 and v36.Unit or Vector3.new(0, 0, 1)) * u31;
        local v38 = CFrame.fromAxisAngle(Vector3.new(0, 1, 0), u32) * v37;
        local math_clamp_ret = math.clamp(math_max_ret * 0.85, 18, 90);
        local v39 = u29.Part and (u29.Part.Parent and u29.Part.Position) or v34 + Vector3.new(0, 2, 0);
        local CFrame_lookAt_ret = CFrame.lookAt(v34 + v38 * math_clamp_ret + Vector3.new(0, math_max_ret * 0.12 + 4, 0), v39);
        workspace_CurrentCamera.CameraType = Enum.CameraType.Scriptable;
        workspace_CurrentCamera.CFrame = workspace_CurrentCamera.CFrame:Lerp(CFrame_lookAt_ret, 1 - math.exp(-p33 * 3.5));
    end);
end;

local function setCapFeedback(p40, p41) -- Line: 300
    -- upvalues: Color3_fromRGB_ret (copy)
    local KeyPrompt = p40.KeyPrompt;
    KeyPrompt.Letter.TextColor3 = p41;
    local v42 = KeyPrompt:FindFirstChildOfClass("UIStroke");

    if v42 then
        if p41 == Color3_fromRGB_ret then
            v42.Color = Color3_fromRGB_ret;
            v42.Transparency = 0.55;

            return;
        end;

        v42.Color = p41;
        v42.Transparency = 0;
    end;
end;

local function rollLetter() -- Line: 315
    -- upvalues: LocalPlayer (copy), u10 (ref), u1 (copy), UserInputService (copy), u4 (copy), Color3_fromRGB_ret (copy)
    local ClashGui = LocalPlayer.PlayerGui:FindFirstChild("ClashGui");

    if ClashGui then
        ClashGui = ClashGui:FindFirstChild("ClashHUD");
    end;

    if not (ClashGui and u10) then
        return;
    end;

    local v43;

    repeat
        v43 = u1[math.random(1, #u1)];
    until v43 ~= u10.letter;

    u10.letter = v43;
    local Letter = ClashGui.KeyPrompt.Letter;

    if UserInputService:GetLastInputType().Name:find("Gamepad") ~= nil then
        v43 = u4[v43] or v43;
    end;

    Letter.Text = v43;
    local v44 = Color3_fromRGB_ret;
    local KeyPrompt = ClashGui.KeyPrompt;
    KeyPrompt.Letter.TextColor3 = v44;
    local v45 = KeyPrompt:FindFirstChildOfClass("UIStroke");

    if v45 then
        if v44 == Color3_fromRGB_ret then
            v45.Color = Color3_fromRGB_ret;
            v45.Transparency = 0.55;

            return;
        end;

        v45.Color = v44;
        v45.Transparency = 0;
    end;
end;

local function handleKeyPress(p46) -- Line: 327
    -- upvalues: u10 (ref), LocalPlayer (copy), u1 (copy), BeamClashRemote (copy), Color3_fromRGB_ret3 (copy), Color3_fromRGB_ret2 (copy), Color3_fromRGB_ret (copy), SoundManager (copy), workspace_CurrentCamera (copy), Color3_fromRGB_ret4 (copy), rollLetter (copy)
    if not u10 then
        return;
    end;

    local ClashGui = LocalPlayer.PlayerGui:FindFirstChild("ClashGui");

    if ClashGui then
        ClashGui = ClashGui:FindFirstChild("ClashHUD");
    end;

    if not ClashGui then
        return;
    end;

    if u10.spam then
        if not table.find(u1, p46) then
            return;
        end;

        BeamClashRemote:FireServer(p46);
        local v47 = p46 == u10.spam.key;
        local v48 = v47 and Color3_fromRGB_ret3 or Color3_fromRGB_ret2;
        local KeyPrompt = ClashGui.KeyPrompt;
        KeyPrompt.Letter.TextColor3 = v48;
        local v49 = KeyPrompt:FindFirstChildOfClass("UIStroke");

        if v49 then
            if v48 == Color3_fromRGB_ret then
                v49.Color = Color3_fromRGB_ret;
                v49.Transparency = 0.55;
            else
                v49.Color = v48;
                v49.Transparency = 0;
            end;
        end;

        if v47 then
            SoundManager.AddSound("Osu Hit", {
                Parent = workspace_CurrentCamera
            }, "Client");
        end;

        task.delay(0.06, function() -- Line: 340
            -- upvalues: u10 (ref), ClashGui (copy), Color3_fromRGB_ret4 (ref), Color3_fromRGB_ret (ref)
            if u10 and u10.spam then
                local v50 = Color3_fromRGB_ret4;
                local KeyPrompt2 = ClashGui.KeyPrompt;
                KeyPrompt2.Letter.TextColor3 = v50;
                local v51 = KeyPrompt2:FindFirstChildOfClass("UIStroke");

                if v51 then
                    if v50 == Color3_fromRGB_ret then
                        v51.Color = Color3_fromRGB_ret;
                        v51.Transparency = 0.55;

                        return;
                    end;

                    v51.Color = v50;
                    v51.Transparency = 0;
                end;
            end;
        end);

        return;
    end;

    if not u10.canGuess then
        return;
    end;

    if p46 ~= u10.letter then
        if table.find(u1, p46) then
            u10.canGuess = false;
            local v52 = Color3_fromRGB_ret2;
            local KeyPrompt = ClashGui.KeyPrompt;
            KeyPrompt.Letter.TextColor3 = v52;
            local v53 = KeyPrompt:FindFirstChildOfClass("UIStroke");

            if v53 then
                if v52 == Color3_fromRGB_ret then
                    v53.Color = Color3_fromRGB_ret;
                    v53.Transparency = 0.55;
                else
                    v53.Color = v52;
                    v53.Transparency = 0;
                end;
            end;

            task.delay(0.2, function() -- Line: 362
                -- upvalues: u10 (ref), ClashGui (copy), Color3_fromRGB_ret (ref)
                if u10 then
                    local v54 = Color3_fromRGB_ret;
                    local KeyPrompt2 = ClashGui.KeyPrompt;
                    KeyPrompt2.Letter.TextColor3 = v54;
                    local v55 = KeyPrompt2:FindFirstChildOfClass("UIStroke");

                    if v55 then
                        if v54 == Color3_fromRGB_ret then
                            v55.Color = Color3_fromRGB_ret;
                            v55.Transparency = 0.55;
                        else
                            v55.Color = v54;
                            v55.Transparency = 0;
                        end;
                    end;

                    u10.canGuess = true;
                end;
            end);
        end;

        return;
    end;

    u10.canGuess = false;
    BeamClashRemote:FireServer(p46);
    local v56 = Color3_fromRGB_ret3;
    local KeyPrompt = ClashGui.KeyPrompt;
    KeyPrompt.Letter.TextColor3 = v56;
    local v57 = KeyPrompt:FindFirstChildOfClass("UIStroke");

    if v57 then
        if v56 == Color3_fromRGB_ret then
            v57.Color = Color3_fromRGB_ret;
            v57.Transparency = 0.55;
        else
            v57.Color = v56;
            v57.Transparency = 0;
        end;
    end;

    SoundManager.AddSound("Osu Hit", {
        Parent = workspace_CurrentCamera
    }, "Client");
    task.delay(0.1, function() -- Line: 353
        -- upvalues: u10 (ref), rollLetter (ref)
        if u10 then
            rollLetter();
            u10.canGuess = true;
        end;
    end);
end;

local function bindMobilePad() -- Line: 371
    -- upvalues: u5 (copy), u10 (ref), LocalPlayer (copy), u11 (ref), TouchActionRemote (copy), handleKeyPress (copy)
    if not (u5 and u10) then
        return;
    end;

    local ClashGui = LocalPlayer.PlayerGui:FindFirstChild("ClashGui");

    if ClashGui then
        ClashGui = ClashGui:FindFirstChild("ClashHUD");
    end;

    if ClashGui then
        ClashGui = ClashGui:FindFirstChild("MobilePad");
    end;

    if not ClashGui then
        warn("[BeamClashVFX] ClashHUD.MobilePad missing -- mobile cannot clash");

        return;
    end;

    if not u11 then
        u11 = true;
        TouchActionRemote:Fire("TouchPad", "EventFocus", true);
    end;

    u10.padConns = {};

    for _, child in ipairs(ClashGui:GetChildren()) do
        if child:IsA("TextButton") then
            local Name = child.Name;
            table.insert(u10.padConns, child.Activated:Connect(function() -- Line: 387
                -- upvalues: handleKeyPress (ref), Name (copy)
                handleKeyPress(Name);
            end));
        end;
    end;

    ClashGui.Visible = true;
end;

local function unbindMobilePad() -- Line: 395
    -- upvalues: u10 (ref), LocalPlayer (copy), u11 (ref), TouchActionRemote (copy)
    if u10 and u10.padConns then
        for _, v in ipairs(u10.padConns) do
            pcall(function() -- Line: 398
                -- upvalues: v (copy)
                v:Disconnect();
            end);
        end;

        u10.padConns = nil;
    end;

    local ClashGui = LocalPlayer.PlayerGui:FindFirstChild("ClashGui");

    if ClashGui then
        ClashGui = ClashGui:FindFirstChild("ClashHUD");
    end;

    if ClashGui then
        ClashGui = ClashGui:FindFirstChild("MobilePad");
    end;

    if ClashGui then
        ClashGui.Visible = false;
    end;

    if u11 then
        u11 = false;
        TouchActionRemote:Fire("TouchPad", "EventFocus", false);
    end;
end;

local function updateBar(p58) -- Line: 411
    -- upvalues: LocalPlayer (copy), u10 (ref), TweenService (copy), TweenInfo_new_ret (copy)
    local ClashGui = LocalPlayer.PlayerGui:FindFirstChild("ClashGui");

    if ClashGui then
        ClashGui = ClashGui:FindFirstChild("ClashHUD");
    end;

    if not (ClashGui and u10) then
        return;
    end;

    local math_clamp_ret = math.clamp(u10.isA and 0.5 + p58 / 2 or 0.5 - p58 / 2, 0, 1);
    local TugBar = ClashGui.TugBar;
    TweenService:Create(TugBar.PlayerFill, TweenInfo_new_ret, {
        Size = UDim2.fromScale(math_clamp_ret, 1)
    }):Play();
    TweenService:Create(TugBar.EnemyFill, TweenInfo_new_ret, {
        Size = UDim2.fromScale(1 - math_clamp_ret, 1)
    }):Play();
    TweenService:Create(TugBar.Divider, TweenInfo_new_ret, {
        Position = UDim2.fromScale(math_clamp_ret, 0.5)
    }):Play();
    local math_round_ret = math.round(math_clamp_ret * 100);
    ClashGui.PlayerTag.Text = string.format("%s  %d%%", LocalPlayer.Name, math_round_ret);
    ClashGui.EnemyTag.Text = string.format("%d%%  %s", 100 - math_round_ret, u10.opponentName or "Enemy");
end;

local function endSession() -- Line: 426
    -- upvalues: u10 (ref), workspace_CurrentCamera (copy), LocalPlayer (copy), unbindMobilePad (ref), ContextActionService (copy), getSpamBanner (copy), CinemaManager (copy)
    if not u10 then
        return;
    end;

    if u10 and u10.camConn then
        u10.camConn:Disconnect();
        u10.camConn = nil;
    end;

    workspace_CurrentCamera.CameraType = Enum.CameraType.Custom;
    local Character = LocalPlayer.Character;

    if Character then
        Character = Character:FindFirstChildOfClass("Humanoid");
    end;

    if Character then
        workspace_CurrentCamera.CameraSubject = Character;
    end;

    unbindMobilePad();
    pcall(ContextActionService.UnbindAction, ContextActionService, "BeamClashInputSink");
    local ClashGui = LocalPlayer.PlayerGui:FindFirstChild("ClashGui");

    if ClashGui then
        ClashGui = ClashGui:FindFirstChild("ClashHUD");
    end;

    if ClashGui then
        getSpamBanner(ClashGui).Visible = false;
    end;

    local ClashGui2 = LocalPlayer.PlayerGui:FindFirstChild("ClashGui");

    if ClashGui2 then
        ClashGui2 = ClashGui2:FindFirstChild("ClashHUD");
    end;

    if ClashGui2 then
        ClashGui2.KeyPrompt.Visible = false;
        ClashGui2.Visible = false;
    end;

    CinemaManager.FadeOut(LocalPlayer);
    u10 = nil;
end;

local function startSession(p59, p60, p61) -- Line: 441
    -- upvalues: endSession (copy), LocalPlayer (copy), u10 (ref), CinemaManager (copy), ContextActionService (copy), handleKeyPress (copy), u3 (copy), u2 (copy), rollLetter (copy), updateBar (copy), bindMobilePad (copy), startCamera (copy)
    endSession();
    local Character = LocalPlayer.Character;
    local v62 = Character == p59 and p60 and p60 or p59;
    u10 = {
        canGuess = true,
        charA = p59,
        charB = p60,
        isA = Character == p59,
        opponentName = v62 and v62.Name or "Enemy"
    };
    CinemaManager.FadeIn(LocalPlayer, 0.3);
    ContextActionService:BindActionAtPriority("BeamClashInputSink", function(p63, p64, p65) -- Line: 455
        -- upvalues: handleKeyPress (ref), u3 (ref)
        if p64 == Enum.UserInputState.Begin then
            handleKeyPress(u3[p65.KeyCode.Name] or p65.KeyCode.Name);
        end;

        return Enum.ContextActionResult.Sink;
    end, false, Enum.ContextActionPriority.High.Value + 500, table.unpack(u2));
    local ClashGui = LocalPlayer.PlayerGui:FindFirstChild("ClashGui");

    if ClashGui then
        ClashGui = ClashGui:FindFirstChild("ClashHUD");
    end;

    if ClashGui then
        ClashGui.Parent.Enabled = true;
        u10.letter = nil;
        rollLetter();
        ClashGui.KeyPrompt.Visible = true;
        updateBar(p61.Progress or 0);
        ClashGui.Visible = true;
    end;

    bindMobilePad();
    startCamera(p61);
end;

local v83 = {
    Begin = function(p66) -- Line: 484
        -- upvalues: u9 (copy), destroyVisual (copy), BeamRigVFX (copy), buildStruggle (copy), SoundManager (copy), RunService (copy), LocalPlayer (copy), startSession (copy)
        local CharacterA = p66.CharacterA;
        local CharacterB = p66.CharacterB;

        if not (CharacterA and CharacterB) then
            return;
        end;

        if u9[CharacterA] then
            destroyVisual(u9[CharacterA], false);
            u9[CharacterA] = nil;
        end;

        local v67 = BeamRigVFX.Active[CharacterA];
        local v68 = BeamRigVFX.Active[CharacterB];
        local v69 = v67 and v67.Color or Color3.fromRGB(0, 200, 255);
        local v70 = v68 and v68.Color or Color3.fromRGB(255, 255, 101);
        local Position = p66.Position;
        local u71 = {
            Part = buildStruggle(Position, v69, v70, v67 and (v67.StartSize or 3) or 3, v68 and (v68.StartSize or 3) or 3),
            Target = Position,
            CtrlA = v67,
            CtrlB = v68,
            Progress = p66.Progress or 0
        };
        u9[CharacterA] = u71;
        SoundManager.AddSound("Beam Charge", {
            Parent = u71.Part
        }, "Client");
        u71.Conn = RunService.Heartbeat:Connect(function(p72) -- Line: 516
            -- upvalues: u71 (copy)
            local Part = u71.Part;

            if not (Part and Part.Parent) then
                return;
            end;

            local v73 = 1 - math.exp(-p72 * 8);
            Part.CFrame = Part.CFrame:Lerp(CFrame.new(u71.Target), v73);

            if u71.CtrlA then
                u71.CtrlA.SetClashPoint(Part.Position);
            end;

            if u71.CtrlB then
                u71.CtrlB.SetClashPoint(Part.Position);
            end;
        end);
        local Character = LocalPlayer.Character;

        if Character == CharacterA or Character == CharacterB then
            startSession(CharacterA, CharacterB, u71);
        end;
    end,

    Progress = function(p74) -- Line: 532
        -- upvalues: u9 (copy), u10 (ref), updateBar (copy)
        local v75 = u9[p74.CharacterA];

        if not v75 then
            return;
        end;

        v75.Target = p74.Position or v75.Target;
        v75.Progress = p74.Progress or v75.Progress;

        if u10 and u10.charA == p74.CharacterA then
            updateBar(v75.Progress);
        end;
    end,

    End = function(p76) -- Line: 542
        -- upvalues: u9 (copy), destroyVisual (copy), u10 (ref), endSession (copy)
        local u77 = u9[p76.CharacterA];

        if u77 then
            u9[p76.CharacterA] = nil;

            if u77.Conn then
                u77.Conn:Disconnect();
                u77.Conn = nil;
            end;

            local function ctrlFor(p78) -- Line: 556
                -- upvalues: u77 (copy)
                if u77.CtrlA and u77.CtrlA.Character == p78 then
                    return u77.CtrlA;
                end;

                if u77.CtrlB and u77.CtrlB.Character == p78 then
                    return u77.CtrlB;
                end;

                return nil;
            end;

            if p76.Draw then
                if u77.CtrlA then
                    u77.CtrlA.Release("collapse");
                end;

                if u77.CtrlB then
                    u77.CtrlB.Release("collapse");
                end;
            else
                local Winner = p76.Winner;

                if Winner then
                    local Winner2 = p76.Winner;

                    if u77.CtrlA and u77.CtrlA.Character == Winner2 then
                        Winner = u77.CtrlA;
                    elseif u77.CtrlB and u77.CtrlB.Character == Winner2 then
                        Winner = u77.CtrlB;
                    else
                        Winner = nil;
                    end;
                end;

                local Loser = p76.Loser;

                if Loser then
                    local Loser2 = p76.Loser;

                    if u77.CtrlA and u77.CtrlA.Character == Loser2 then
                        Loser = u77.CtrlA;
                    elseif u77.CtrlB and u77.CtrlB.Character == Loser2 then
                        Loser = u77.CtrlB;
                    else
                        Loser = nil;
                    end;
                end;

                if Winner then
                    Winner.Release("continue", p76.WinBeamTime);
                end;

                if Loser then
                    Loser.Release("collapse");
                end;

                for _, v in ipairs({ u77.CtrlA, u77.CtrlB }) do
                    if v and (v ~= Winner and v ~= Loser) then
                        v.Release("collapse");
                    end;
                end;
            end;

            destroyVisual(u77, not p76.Draw);
        end;

        if u10 and (u10.charA == p76.CharacterA or u10.charB == p76.CharacterA) then
            endSession();
        end;
    end,

    Spam = function(p79) -- Line: 584
        -- upvalues: u10 (ref), LocalPlayer (copy), UserInputService (copy), u4 (copy), Color3_fromRGB_ret4 (copy), Color3_fromRGB_ret (copy), setSpamVisible (copy), SoundManager (copy), workspace_CurrentCamera (copy)
        if not u10 or u10.charA ~= p79.CharacterA then
            return;
        end;

        local ClashGui = LocalPlayer.PlayerGui:FindFirstChild("ClashGui");

        if ClashGui then
            ClashGui = ClashGui:FindFirstChild("ClashHUD");
        end;

        if not ClashGui then
            return;
        end;

        local Key = p79.Key;
        u10.spam = {
            key = Key,
            endsAt = os.clock() + (p79.Duration or 3)
        };
        u10.letter = Key;
        local Letter = ClashGui.KeyPrompt.Letter;

        if UserInputService:GetLastInputType().Name:find("Gamepad") ~= nil then
            Key = u4[Key] or Key;
        end;

        Letter.Text = Key;
        local v80 = Color3_fromRGB_ret4;
        local KeyPrompt = ClashGui.KeyPrompt;
        KeyPrompt.Letter.TextColor3 = v80;
        local v81 = KeyPrompt:FindFirstChildOfClass("UIStroke");

        if v81 then
            if v80 == Color3_fromRGB_ret then
                v81.Color = Color3_fromRGB_ret;
                v81.Transparency = 0.55;
            else
                v81.Color = v80;
                v81.Transparency = 0;
            end;
        end;

        setSpamVisible(true);
        SoundManager.AddSound("Osu Hit", {
            Parent = workspace_CurrentCamera
        }, "Client");
    end,

    SpamEnd = function(p82) -- Line: 597
        -- upvalues: u10 (ref), LocalPlayer (copy), getSpamBanner (copy), rollLetter (copy)
        if not u10 or u10.charA ~= p82.CharacterA then
            return;
        end;

        u10.spam = nil;
        local ClashGui = LocalPlayer.PlayerGui:FindFirstChild("ClashGui");

        if ClashGui then
            ClashGui = ClashGui:FindFirstChild("ClashHUD");
        end;

        if ClashGui then
            getSpamBanner(ClashGui).Visible = false;
        end;

        u10.canGuess = true;
        rollLetter();
    end
};
LocalPlayer.CharacterAdded:Connect(function() -- Line: 606
    -- upvalues: u10 (ref), endSession (copy)
    if u10 then
        endSession();
    end;
end);

return v83;