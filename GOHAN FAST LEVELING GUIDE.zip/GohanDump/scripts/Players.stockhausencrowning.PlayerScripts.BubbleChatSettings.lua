-- Decompiled with Potassium's decompiler.

local TextChatService = game:GetService("TextChatService");
local Players = game:GetService("Players");
local ReplicatedStorage = game:GetService("ReplicatedStorage");
local ChatRemote = ReplicatedStorage.Remotes.ChatRemote;
local Modules = ReplicatedStorage:WaitForChild("Modules");
local RaceChat = require(Modules:WaitForChild("Shared"):WaitForChild("RaceChat"));
local RaceChatData = require(Modules:WaitForChild("Metadata"):WaitForChild("ChatData"):WaitForChild("RaceChatData"));
local BubbleChatConfiguration = TextChatService.BubbleChatConfiguration;
BubbleChatConfiguration.BubblesSpacing = 1;
BubbleChatConfiguration.BackgroundTransparency = 0;
BubbleChatConfiguration.LocalPlayerStudsOffset = Vector3.new(0, 2, 0);
local v1 = BubbleChatConfiguration:FindFirstChildOfClass("UICorner");

if not v1 then
    v1 = Instance.new("UICorner");
    v1.Parent = BubbleChatConfiguration;
end;

v1.CornerRadius = UDim.new(0, 12);

local function applyRaceProps(p2, p3, p4, p5) -- Line: 45
    -- upvalues: Players (copy), ChatRemote (copy)
    if p3.TextColor then
        p2.TextColor3 = p3.TextColor;
    end;

    if p3.BackgroundColor then
        p2.BackgroundColor3 = p3.BackgroundColor;
    end;

    if p3.Font then
        p2.FontFace = Font.fromEnum(p3.Font);
    end;

    if p3.FontWeight then
        local FontFace = p2.FontFace;
        p2.FontFace = Font.new(FontFace.Family, p3.FontWeight, FontFace.Style);
    end;

    if p3.TextSize then
        p2.TextSize = p3.TextSize;
    end;

    if p3.TailVisible ~= nil then
        p2.TailVisible = p3.TailVisible;
    end;

    if p3.SquareCorners then
        local UICorner = Instance.new("UICorner");
        UICorner.CornerRadius = UDim.new(0, 0);
        UICorner.Parent = p2;
    end;

    local v6 = p3.ChatSound and (p4 and Players:GetPlayerFromCharacter(p4));

    if v6 then
        ChatRemote:FireServer("Chat Sound", {
            SetPlayer = v6,
            SetPlayerRace = p5
        });
    end;

    return p2;
end;

function TextChatService.OnBubbleAdded(p7: userdata, p8: userdata) -- Line: 76
    -- upvalues: Players (copy), RaceChat (copy), RaceChatData (copy), applyRaceProps (copy)
    local BubbleChatMessageProperties = Instance.new("BubbleChatMessageProperties");
    BubbleChatMessageProperties.BackgroundTransparency = 0;
    local v9;

    if p7.TextSource then
        v9 = Players:GetPlayerByUserId(p7.TextSource.UserId);

        if v9 then
            v9 = v9.Character;
        end;
    else
        v9 = nil;
    end;

    if not v9 and p8 then
        v9 = p8:IsA("Model") and p8 and p8 or p8:FindFirstAncestorOfClass("Model");
    end;

    local v10 = RaceChat.PeekBubbleRace(p8) or (v9 and (v9:GetAttribute("ChatRace") or "Default") or "Default");

    return applyRaceProps(BubbleChatMessageProperties, RaceChatData[v10] or RaceChatData.Default, v9, v10);
end;