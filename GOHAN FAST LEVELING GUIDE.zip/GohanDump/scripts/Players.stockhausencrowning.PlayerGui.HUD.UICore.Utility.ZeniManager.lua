-- Decompiled with Potassium's decompiler.

local Players = game:GetService("Players");
local Debris = game:GetService("Debris");
local ReplicatedStorage = game:GetService("ReplicatedStorage");
local Modules = ReplicatedStorage:WaitForChild("Modules");
local Shared = Modules.Shared;
local Utility = Modules.Utility;
local GlobalFunctions = require(Modules.GlobalFunctions);
local SoundManager = require(Shared.SoundManager);
local GameMessage = require(Utility.GameMessage);
local CurrencyRemote = ReplicatedStorage.Remotes.CurrencyRemote;
local Currency = script:FindFirstAncestor("HUD").Currency;
local CurrencyNum = Currency.CurrencyNum;
local ZeniImage = Currency.ZeniImage;
local DropCash = CurrencyNum.DropCash;
local LocalPlayer = Players.LocalPlayer;
local Value = LocalPlayer:WaitForChild("PlayerStats"):WaitForChild("CharacterData").Zeni.Value;
local Color3_fromRGB_ret = Color3.fromRGB(0, 255, 0);
local Color3_fromRGB_ret2 = Color3.fromRGB(255, 0, 0);

local function round2(p1) -- Line: 45
    return math.floor(p1 * 100) / 100;
end;

local function sendUp(p2, p3) -- Line: 50
    -- upvalues: CurrencyNum (copy), Currency (copy), Debris (copy), GlobalFunctions (copy)
    local v4 = CurrencyNum:Clone();
    v4.DropCash:Destroy();
    v4.TextColor3 = p3;
    local v5 = math.floor(p2 * 100) / 100;
    v4.Text = tostring(v5);
    v4.Parent = Currency;
    v4:TweenPosition(v4.Position + UDim2.new(0, 0, -1.5, 0), Enum.EasingDirection.Out, Enum.EasingStyle.Linear, 0.5, true);
    Debris:AddItem(v4, 1);
    GlobalFunctions.Tween({
        Duration = 1,
        Instance = v4
    }, {
        TextTransparency = 1,
        TextStrokeTransparency = 1
    });
end;

local v7 = {
    Update = function(p6) -- Line: 67, Name: Update
        -- upvalues: CurrencyNum (copy), LocalPlayer (copy), SoundManager (copy), Value (ref), sendUp (copy), Color3_fromRGB_ret (copy), Color3_fromRGB_ret2 (copy)
        CurrencyNum.Text = math.floor(p6 * 100) / 100;
        local Character = LocalPlayer.Character;

        if Character then
            Character = Character:FindFirstChild("HumanoidRootPart");
        end;

        if Character then
            SoundManager.AddSound("MoneySound", {
                Parent = Character
            }, "Client");
        end;

        sendUp(math.abs(p6 - Value), Value <= p6 and Color3_fromRGB_ret or Color3_fromRGB_ret2);
        Value = p6;
    end
};
ZeniImage.MouseButton1Up:Connect(function() -- Line: 82
    -- upvalues: DropCash (copy)
    DropCash.Visible = not DropCash.Visible;
end);
DropCash.TextButton.MouseButton1Up:Connect(function() -- Line: 86
    -- upvalues: DropCash (copy), GameMessage (copy), LocalPlayer (copy), CurrencyRemote (copy)
    local v8 = tonumber(DropCash.Text);

    if not v8 then
        DropCash.Visible = false;

        return;
    end;

    if v8 ~= v8 then
        GameMessage.SendMessage(LocalPlayer, "Nice Try Monkey.");

        return;
    end;

    if v8 <= 0 or v8 > 50000 then
        GameMessage.SendMessage(LocalPlayer, v8 > 50000 and "Cash Limit is " .. 50000 .. "!" or "You can\'t drop negative cash!");

        return;
    end;

    CurrencyRemote:FireServer((math.floor(v8)));
    DropCash.Visible = false;
end);

return v7;