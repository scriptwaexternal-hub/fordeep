-- Decompiled with Potassium's decompiler.

local Modules = game:GetService("ReplicatedStorage"):WaitForChild("Modules");
local VfxHandler = require(Modules.Effects.VfxHandler);

return {
    Fire = function(p1) -- Line: 17
        -- upvalues: VfxHandler (copy)
        local Character = p1.Character;

        if not Character then
            return;
        end;

        VfxHandler.Lightning.Aura(Character);
    end
};