-- Decompiled with Potassium's decompiler.

local function pagesToTable(p1) -- Line: 1
    local v2 = {};

    while true do
        table.insert(v2, p1:GetCurrentPage());

        if p1.IsFinished then
            break;
        end;

        p1:AdvanceToNextPageAsync();
    end;

    return v2;
end;

return function(p3) -- Line: 13, Name: iterPageItems
    -- upvalues: pagesToTable (copy)
    local u4 = pagesToTable(p3);
    local u5 = 1;
    local u6 = #u4;

    return coroutine.wrap(function() -- Line: 18
        -- upvalues: u5 (ref), u6 (copy), u4 (copy)
        while u5 <= u6 do
            for _, v in ipairs(u4[u5]) do
                coroutine.yield(v, u5);
            end;

            u5 = u5 + 1;
        end;
    end);
end;