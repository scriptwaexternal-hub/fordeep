-- Decompiled with Potassium's decompiler.

local ReplicatedStorage = game:GetService("ReplicatedStorage");
game:GetService("ServerStorage");
local Players = game:GetService("Players");
game:GetService("Debris");
local RunService = game:GetService("RunService");
local Modules = ReplicatedStorage:WaitForChild("Modules");
ReplicatedStorage:WaitForChild("Remotes");
local _ = Modules.Metadata;
local _ = Modules.Shared;
local _ = Modules.Utility;
local Gui = ReplicatedStorage.Assets.Gui;
local LocalPlayer = Players.LocalPlayer;
local u1 = nil;

local function stopBarrier() -- Line: 25
    -- upvalues: u1 (ref)
    if u1 then
        u1:Disconnect();
        u1 = nil;
    end;
end;

return {
    ["Create Mission"] = function(p2) -- Line: 30
        -- upvalues: LocalPlayer (copy), Gui (copy)
        local MissionGui = LocalPlayer.PlayerGui:FindFirstChild("MissionGui");

        if not MissionGui then
            return;
        end;

        local Hold_Frame = MissionGui:FindFirstChild("M_Frame").Hold_Frame;
        local MissionName = p2.MissionName;
        local MissionDesc = p2.MissionDesc;
        local MissionInfo = p2.MissionInfo;
        local MissionTime = p2.MissionTime;
        local MarkerItems = p2.MarkerItems;
        local MarkPlayers = p2.MarkPlayers;
        local u3 = {};
        local u4 = {};
        (function() -- Line: 47, Name: Add_Mission_Template
            -- upvalues: MissionGui (copy), Gui (ref), Hold_Frame (copy), MissionDesc (copy), MissionName (copy), MissionInfo (copy), MissionTime (ref), MarkerItems (copy), u3 (copy), MarkPlayers (copy), u4 (copy)
            if not MissionGui then
                warn("MISSION GUI NOT FOUND");

                return;
            end;

            local u5 = Gui.Mission["Task Frame"]:Clone();
            u5.Parent = Hold_Frame;
            u5.Desc.Text = MissionDesc or "No Desc";
            u5.MissionName.Text = MissionName or "Blank Mission";
            u5.Info.Text = MissionInfo or "Info Not Set";
            u5.Timer.Text = MissionTime or "300";

            if MarkerItems then
                for _, v in pairs(MarkerItems) do
                    local v6 = Gui.Mission.Marker:Clone();
                    v6.Parent = v;
                    table.insert(u3, v6);
                end;
            end;

            if MarkPlayers then
                for _, v in pairs(MarkPlayers) do
                    local Character = v.Character;

                    if Character then
                        local v7 = Gui.Mission.Marker:Clone();
                        v7.Parent = Character;
                        table.insert(u4, v7);
                    end;
                end;
            end;

            task.spawn(function() -- Line: 80
                -- upvalues: u5 (copy), MissionTime (ref), u3 (ref), u4 (ref)
                local success, result = pcall(function() -- Line: 81
                    -- upvalues: u5 (ref), MissionTime (ref)
                    while u5.Parent and MissionTime ~= 0 do
                        task.wait(1);
                        MissionTime = MissionTime - 1;

                        if u5:FindFirstChild("Timer") then
                            u5.Timer.Text = tostring(MissionTime);
                        end;
                    end;
                end);

                if not success then
                    warn(result);
                end;

                for _, v in pairs(u3) do
                    v:Destroy();
                end;

                for _, v in pairs(u4) do
                    v:Destroy();
                end;

                u5:Destroy();
            end);
        end)();
    end,

    ["Remove Mission"] = function(p8) -- Line: 117
        -- upvalues: LocalPlayer (copy)
        local MissionGui = LocalPlayer.PlayerGui:FindFirstChild("MissionGui");

        if not MissionGui then
            return;
        end;

        local Hold_Frame = MissionGui:FindFirstChild("M_Frame").Hold_Frame;
        local MissionName = p8.MissionName;
        (function() -- Line: 126, Name: Remove_Mission_Template
            -- upvalues: Hold_Frame (copy), MissionName (copy)
            for _, child in pairs(Hold_Frame:GetChildren()) do
                if child:IsA("Frame") and child.MissionName.Text == MissionName then
                    child:Destroy();
                end;
            end;
        end)();
    end,

    ["Arena Barrier"] = function(p9) -- Line: 137
        -- upvalues: u1 (ref), RunService (copy), LocalPlayer (copy)
        if u1 then
            u1:Disconnect();
            u1 = nil;
        end;

        local Center = p9.Center;
        local Radius = p9.Radius;
        local Top = p9.Top;

        if typeof(Center) ~= "Vector3" or type(Radius) ~= "number" then
            return;
        end;

        local u10 = Radius - 2;
        local u11;

        if type(Top) == "number" then
            u11 = Top - 2 or nil;
        else
            u11 = nil;
        end;

        u1 = RunService.Heartbeat:Connect(function() -- Line: 144
            -- upvalues: LocalPlayer (ref), Center (copy), Radius (copy), u10 (copy), u11 (copy)
            local Character = LocalPlayer.Character;

            if Character then
                Character = Character:FindFirstChild("HumanoidRootPart");
            end;

            if not Character or Character.Anchored then
                return;
            end;

            local Position = Character.Position;
            local Vector3_new_ret = Vector3.new(Position.X - Center.X, 0, Position.Z - Center.Z);
            local Magnitude = Vector3_new_ret.Magnitude;

            if Radius + 60 < Magnitude then
                return;
            end;

            local AssemblyLinearVelocity = Character.AssemblyLinearVelocity;
            local v12;

            if u10 < Magnitude then
                local v13 = Vector3_new_ret / Magnitude;
                v12 = Vector3.new(Center.X, Position.Y, Center.Z) + v13 * u10;
                local v14 = AssemblyLinearVelocity:Dot(v13);

                if v14 > 0 then
                    AssemblyLinearVelocity = AssemblyLinearVelocity - v13 * v14;
                end;
            else
                v12 = Position;
            end;

            if u11 and u11 < v12.Y then
                v12 = Vector3.new(v12.X, u11, v12.Z);

                if AssemblyLinearVelocity.Y > 0 then
                    AssemblyLinearVelocity = Vector3.new(AssemblyLinearVelocity.X, 0, AssemblyLinearVelocity.Z);
                end;
            end;

            if v12 ~= Position then
                Character.CFrame = Character.CFrame + (v12 - Position);
                Character.AssemblyLinearVelocity = AssemblyLinearVelocity;
            end;
        end);
    end,

    ["Arena Barrier End"] = function() -- Line: 172
        -- upvalues: u1 (ref)
        if u1 then
            u1:Disconnect();
            u1 = nil;
        end;
    end,

    ["Update Mission"] = function(p15) -- Line: 176
        -- upvalues: LocalPlayer (copy)
        local MissionGui = LocalPlayer.PlayerGui:FindFirstChild("MissionGui");

        if not MissionGui then
            return;
        end;

        local Hold_Frame = MissionGui:FindFirstChild("M_Frame").Hold_Frame;
        local MissionName = p15.MissionName;
        local MissionInfo = p15.MissionInfo;
        local v16 = (function() -- Line: 186, Name: Get_Mission_Template
            -- upvalues: Hold_Frame (copy), MissionName (copy)
            for _, child in pairs(Hold_Frame:GetChildren()) do
                if child:IsA("Frame") and child.MissionName.Text == MissionName then
                    return child;
                end;
            end;
        end)();

        if v16 then
            v16.Info.Text = MissionInfo or "Info Not Updated properly.";
        end;
    end
};