-- Decompiled with Potassium's decompiler.

local UI = require(script.Parent:WaitForChild("UI"));
local v1 = {};
v1.__index = v1;

function v1.new(u2) -- Line: 6
    -- upvalues: UI (copy)
    local bans = u2.Data.bans;
    local escapeRichText = u2.Util.String.escapeRichText;

    local function close(p3) -- Line: 11
        p3.Activated(false);
    end;

    local u4 = nil;
    local u5 = nil;
    u5 = UI.new("Dialog")({
        LayoutOrder = 9,
        BackgroundTransparency = 0.875,
        BackgroundColor3 = UI.Theme.Secondary,
        AutomaticSize = Enum.AutomaticSize.Y,
        Size = UDim2.fromScale(1, 0),
        ActionText = "Unban this user?",
        Action = true,
        LeftAction = true,
        RightAction = true,
        Visible = false,

        Close = function(p6) -- Line: 27, Name: Close
            -- upvalues: close (copy)
            task.defer(close, p6);
        end,

        [UI.Hook] = {
            Action = function(p7) -- Line: 32, Name: Action
                -- upvalues: u5 (ref), u2 (copy)
                u5.Visible(false);

                if p7 and u5.userId then
                    u2.Remote.Unban:Fire((tonumber(u5.userId)));
                end;

                u5.userId = nil;
            end
        }
    });
    u5._content:Destroy();

    local function v8() -- Line: 43
        -- upvalues: UI (ref)
        return UDim2.fromOffset(0, UI.Theme.FontSize + UI.Theme.PaddingWithStroke().Offset);
    end;

    local u9 = UI.state("Server");
    local v10 = UI.state({ "Forever", "Timed", "Server" });
    local u11 = UI.state();
    local u12 = nil;
    local u13 = 1;
    local u14 = UI.new("Select")({
        Value = "Hour",
        AutomaticSize = Enum.AutomaticSize.X,
        Choices = { "Hour", "Day", "Week", "Month", "Year" }
    });
    local u15 = nil;

    local function resetbanTargetInput() -- Line: 59
        -- upvalues: u15 (ref)
        u15.Value("");
    end;

    u15 = UI.new("Input")({
        AutomaticSize = Enum.AutomaticSize.X,
        FontFace = UI.Theme.FontMono,
        FontSize = UI.Theme.FontSize,
        MaxChars = 20,
        Placeholder = "UserId or Username",
        Size = v8,
        Value = "",
        UI.new("UIFlexItem")({
            FlexMode = Enum.UIFlexMode.Shrink
        }),
        [UI.Hook] = {
            Value = function(p16) -- Line: 77, Name: Value
                -- upvalues: u2 (copy), resetbanTargetInput (copy), u11 (copy)
                local v17;

                if tonumber(p16) then
                    v17 = tonumber(p16);
                else
                    local success, result = pcall(u2.Service.Players.GetUserIdFromNameAsync, u2.Service.Players, p16);
                    v17 = success and result;
                end;

                local v18 = {
                    _K = u2,
                    definition = u2.Registry.commands.ban.args[1],
                    command = {
                        from = u2.LocalPlayer.UserId,
                        fromRank = u2.Auth.getRank(u2.LocalPlayer.UserId),
                        fromRole = {},
                        rank = u2.Auth.hasCommand(u2.LocalPlayer.UserId, "ban") or 0
                    }
                };
                u2.Data.targetLimits[u2.LocalPlayer.UserId] = 0;

                if v17 and not u2.Auth.targetUserArgument(v18, v17, v17) then
                    task.defer(resetbanTargetInput);
                    v17 = nil;
                end;

                u11(v17);
            end
        }
    });
    local u20 = UI.new("Input")({
        AutomaticSize = Enum.AutomaticSize.X,
        FontFace = UI.Theme.FontMono,
        FontSize = UI.Theme.FontSize,
        MaxChars = 400,
        Placeholder = "No reason.",
        Size = v8,
        Value = "",
        [UI.Hook] = {
            Value = function(p19) -- Line: 116, Name: Value
                -- upvalues: u12 (ref)
                if p19 == "" then
                    p19 = false;
                end;

                u12 = p19;
            end
        }
    });

    local function createItem(p21) -- Line: 122
        -- upvalues: UI (ref), u9 (copy), u11 (copy), u15 (ref), u12 (ref), u20 (copy), u4 (ref), u5 (ref)
        local u22 = UI.new("Tooltip")({
            Text = "Loading...",
            FontFace = UI.Theme.FontMono
        });
        local v23 = { u22 };
        local u24 = {
            userId = 0,
            reason = nil,
            term = nil,
            name = "",
            tipText = ""
        };
        local v25 = UI.new("Button")({
            LayoutOrder = 9,
            Text = "",
            Size = UDim2.new(1, 0, 1, 0),
            SizeConstraint = Enum.SizeConstraint.RelativeYY,
            Icon = UI.Theme.Image.Edit,
            IconProperties = {
                ImageColor3 = UI.Theme.PrimaryText,
                Size = UDim2.fromScale(0.625, 0.625)
            },

            Activated = function() -- Line: 147, Name: Activated
                -- upvalues: u9 (ref), u24 (copy), u11 (ref), u15 (ref), u12 (ref), u20 (ref), u4 (ref)
                u9(u24.term ~= "Server" and u24.term ~= "Forever" and "Timed" or u24.term);
                u11((tonumber(u24.userId)));
                u15.Value(u24.userId);
                u12 = u24.reason;
                u20.Value(u24.reason or "");
                u4.Title("Edit Ban");
                u4.Visible(true);
            end
        });
        local Tooltip = UI.new("Tooltip");
        table.insert(v23, Tooltip({
            Text = "Edit Ban",
            Parent = v25,
            Hovering = v25._hovering
        }));
        local v26 = UI.new("Button")({
            LayoutOrder = 9,
            Text = "",
            BackgroundColor3 = UI.Theme.Invalid,
            Size = UDim2.new(1, 0, 1, 0),
            SizeConstraint = Enum.SizeConstraint.RelativeYY,
            Icon = UI.Theme.Image.Close_Bold,
            IconProperties = {
                ImageColor3 = UI.Theme.PrimaryText,
                Size = UDim2.fromScale(0.5, 0.5)
            },

            Activated = function() -- Line: 173, Name: Activated
                -- upvalues: u5 (ref), u24 (copy)
                u5.userId = u24.userId;
                u5.ActionText((`Unban {u24.name} [{u24.userId}]?`));
                u5.Visible(true);
            end
        });
        local Tooltip2 = UI.new("Tooltip");
        table.insert(v23, Tooltip2({
            Text = "Remove Ban",
            Parent = v26,
            Hovering = v26._hovering
        }));
        UI.edit(v25._instance.UICorner, {
            CornerRadius = UI.Theme.CornerPadded
        });
        UI.edit(v26._instance.UICorner, {
            CornerRadius = UI.Theme.CornerPadded
        });
        u24._instance = UI.new("Frame")({
            BackgroundTransparency = 1,
            Size = p21.ItemSize,
            UI.new("UIPadding")({
                PaddingBottom = UI.Theme.PaddingWithStroke
            }),
            UI.new("UIListLayout")({
                VerticalAlignment = Enum.VerticalAlignment.Center,
                FillDirection = Enum.FillDirection.Horizontal,
                SortOrder = Enum.SortOrder.LayoutOrder,
                Padding = UI.Theme.PaddingWithStroke
            }),
            UI.new("ImageLabel")({
                BackgroundTransparency = UI.Theme.TransparencyHeavy,
                BackgroundColor3 = UI.Theme.PrimaryText,
                Size = UDim2.new(1, 0, 1, 0),
                SizeConstraint = Enum.SizeConstraint.RelativeYY,
                UI.new("UICorner")({
                    CornerRadius = UI.Theme.CornerPadded
                }),
                UI.new("Stroke")({})
            }),
            UI.new("TextLabel")({
                Name = "Left",
                AutoLocalize = false,
                BackgroundTransparency = 1,
                RichText = true,
                AutomaticSize = Enum.AutomaticSize.X,
                Size = UDim2.new(0, 0, 1, 0),
                FontFace = UI.Theme.Font,
                TextSize = UI.Theme.FontSize,
                TextColor3 = UI.Theme.PrimaryText,
                TextStrokeColor3 = UI.Theme.Primary,
                TextStrokeTransparency = UI.Theme.TextStrokeTransparency,
                TextTruncate = Enum.TextTruncate.SplitWord,
                TextXAlignment = Enum.TextXAlignment.Left
            }),
            UI.new("TextLabel")({
                Name = "Right",
                AutoLocalize = false,
                AutomaticSize = Enum.AutomaticSize.X,
                BackgroundTransparency = 1,
                Size = UDim2.new(0, 0, 1, 0),
                RichText = true,
                FontFace = UI.Theme.Font,
                TextSize = UI.Theme.FontSize,
                TextColor3 = UI.Theme.PrimaryText,
                TextStrokeColor3 = UI.Theme.Primary,
                TextStrokeTransparency = UI.Theme.TextStrokeTransparency,
                TextTruncate = Enum.TextTruncate.SplitWord,
                TextXAlignment = Enum.TextXAlignment.Right,
                UI.new("UIFlexItem")({
                    FlexMode = Enum.UIFlexMode.Fill
                })
            }),
            v25,
            v26,
            u22,
            [UI.Clean] = v23
        });
        table.insert(v23, u22.Visible:Connect(function() -- Line: 255
            -- upvalues: u22 (copy), u24 (copy)
            if u22.Visible._value then
                u22.Text(u24.tipText);
            end;
        end));

        return u24;
    end;

    local u27 = UI.new("Button")({
        Label = "Create a new ban",

        Activated = function() -- Line: 284, Name: Activated
            -- upvalues: u4 (ref), u11 (copy), u15 (ref), u12 (ref), u20 (copy), UI (ref)
            if not u4.Visible._value then
                u11(nil);
                u15.Value("");
                u12 = nil;
                u20.Value("");
                u4.Title("New Ban");
                UI.Sound.Hover03:Play();
            end;

            u4.Visible(not u4.Visible._value);
        end
    });
    u27._instance.Visible = u2.Util.Table.countKeys(u2.client.bans._value) == 0;
    u2.client.bans:Connect(function() -- Line: 298
        -- upvalues: u27 (copy), u2 (copy)
        u27._instance.Visible = u2.Util.Table.countKeys(u2.client.bans._value) == 0;
    end);
    local u32 = UI.new("ScrollerFast")({
        Name = "Bans",
        List = u2.client.bans,
        Enabled = false,
        DictList = true,
        FilterInput = true,
        Visible = false,
        CreateItem = createItem,

        RenderItem = function(p28, p29, p30) -- Line: 265, Name: renderItem
            -- upvalues: u2 (copy)
            local v31 = u2.Data.bans[p30];

            if v31 and v31.renderTextLeft then
                local _instance = p29._instance;
                _instance.Left.Text = v31.renderTextLeft;
                _instance.Right.Text = v31.renderTextRight;
                _instance.ImageLabel.Image = `rbxthumb://type=AvatarHeadShot&id={v31.userId}&w=48&h=48`;
                p29.name = v31[1];
                p29.tipText = v31.tipText;
                p29.userId = v31.userId;
                p29.reason = v31.reason;
                p29.term = v31.term;
            end;
        end,

        u27,
        u5
    });
    u32._filterUpdate = true;
    task.defer(u32.filter, u32, function(p33, p34) -- Line: 317, Name: filterTest
        -- upvalues: u32 (copy), u2 (copy), escapeRichText (copy)
        local string_lower_ret = string.lower(u32._input._input.Text);
        p33._filter = string_lower_ret;
        local string_find_ret = string.find(string_lower_ret, "^%s*$");
        local v35 = {};

        for _, v in p34 do
            local u36 = u2.Data.bans[v];

            if u36 then
                if not u36.filterText then
                    u36.userId = v;
                    u36.reason = (not u36[2] or u2.Util.String.trim(u36[2]) == "") and "No reason." or u36[2];
                    u36.term = (not u36[3] or u36[3] == 0) and "Server" or ((u36[3] <= 0 or u36[3] == (1 / 0)) and "Forever" or os.date("%y-%m-%d %X", u36[3]));
                    u36.rawTextLeft = `@{u36[1] or "UNKNOWN"} [{u36.userId}]}`;
                    u36.rawTextRight = `{u36.term}`;
                    u36.richTextLeft = `<b>@{not u36[1] and "UNKNOWN" or escapeRichText(u36[1])}</b> [{v}]`;
                    u36.richTextRight = `<font transparency="0.5">{u36.term}</font>`;
                    u36.filterTextLeft = string.lower(u36.rawTextLeft);
                    u36.filterTextRight = string.lower(u36.rawTextRight);
                    u36.filterText = `{u36.filterTextLeft}\t{u36.filterTextRight}`;
                    u36.tipText = `<b>Reason:</b> {escapeRichText(u36.reason)}`;
                    task.spawn(function() -- Line: 349
                        -- upvalues: u36 (copy), u2 (ref), u32 (ref)
                        u36.tipText = `<b>Author:</b> @{not u36[4] and "SYSTEM" or u2.Util.getUserInfo(u36[4]).Username}\n{u36.tipText}`;
                        u32:render(true);
                    end);
                end;

                if string_find_ret then
                    u36.renderTextLeft = u36.richTextLeft;
                    u36.renderTextRight = u36.richTextRight;
                    table.insert(v35, v);
                elseif string.find(u36.filterText, string_lower_ret, 1, true) then
                    local string_find_ret2 = string.find(u36.filterTextLeft, p33._filter, 1, true);
                    local string_find_ret3 = string.find(u36.filterTextRight, p33._filter, 1, true);

                    if string_find_ret2 then
                        u36.renderTextLeft = `<font transparency="0.5">{escapeRichText((string.sub(u36.rawTextLeft, 1, string_find_ret2 - 1)))}</font><b>{escapeRichText((string.sub(u36.rawTextLeft, string_find_ret2, string_find_ret2 + #p33._filter - 1)))}</b><font transparency="0.5">{escapeRichText((string.sub(u36.rawTextLeft, string_find_ret2 + #p33._filter)))}</font>`;
                    else
                        u36.renderTextLeft = `<font transparency="0.5">{u36.rawTextLeft}</font>`;
                    end;

                    if string_find_ret3 then
                        u36.renderTextRight = `<font transparency="0.5">{escapeRichText((string.sub(u36.rawTextRight, 1, string_find_ret3 - 1)))}</font><b>{escapeRichText((string.sub(u36.rawTextRight, string_find_ret3, string_find_ret3 + #p33._filter - 1)))}</b><font transparency="0.5">{escapeRichText((string.sub(u36.rawTextRight, string_find_ret3 + #p33._filter)))}</font>`;
                    else
                        u36.renderTextRight = `<font transparency="0.5">{u36.rawTextRight}</font>`;
                    end;

                    table.insert(v35, v);
                end;
            end;
        end;

        return v35;
    end);

    local function termWeight(p37) -- Line: 394
        return p37 and (p37[3] and p37[3] ~= 0) and (p37[3] > 0 and p37[3] ~= (1 / 0) and 1000 or 2000) or 0;
    end;

    task.defer(u32.sort, u32, function(p38, p39) -- Line: 398
        -- upvalues: bans (copy)
        local v40 = bans[p38];
        local v41 = bans[p39];
        local v42 = v40 and (v40[3] and v40[3] ~= 0) and (v40[3] > 0 and v40[3] ~= (1 / 0) and 1000 or 2000) or 0;
        local v43 = v41 and (v41[3] and v41[3] ~= 0) and (v41[3] > 0 and v41[3] ~= (1 / 0) and 1000 or 2000) or 0;

        if v42 ~= v43 then
            return v42 < v43;
        end;

        return v40 and (v41 and (v40[1] and v41[1])) and v40[1] < v41[1];
    end);
    local u45 = UI.new("ListItem")({
        Text = "Type",
        UI.new("Select")({
            Value = u9,
            Choices = v10,
            [UI.Hook] = {
                Value = function(p44) -- Line: 414, Name: Value
                    -- upvalues: u9 (copy)
                    u9(p44);
                end
            }
        })
    });
    u2.Hook.authChanged:Connect(function() -- Line: 421, Name: updateAuth
        -- upvalues: u2 (copy), u9 (copy), u45 (copy)
        local v46 = u2.Auth.hasPermission(u2.LocalPlayer.UserId, "banasync");

        if v46 then
            u9("Forever");
        else
            u9("Server");
        end;

        u45._instance.Visible = v46;
    end);
    local v47 = u2.Auth.hasPermission(u2.LocalPlayer.UserId, "banasync");

    if v47 then
        u9("Forever");
    else
        u9("Server");
    end;

    u45._instance.Visible = v47;
    u4 = UI.new("Dialog")({
        Parent = UI.LayerTop,
        BackgroundTransparency = 0,
        Draggable = true,
        Title = "New Ban",
        Visible = false,
        ExitButton = true,
        Modal = true,

        Close = function() -- Line: 441, Name: Close
            -- upvalues: u4 (ref)
            u4.Visible(false);
        end,

        UI.new("UIPadding")({
            PaddingTop = UI.Theme.PaddingWithStroke,
            PaddingBottom = UI.Theme.PaddingWithStroke,
            PaddingLeft = UI.Theme.PaddingWithStroke,
            PaddingRight = UI.Theme.PaddingWithStroke
        }),
        UI.new("ListItem")({
            Text = "User",
            UI.new("ImageLabel")({
                BackgroundTransparency = UI.Theme.TransparencyHeavy,
                BackgroundColor3 = UI.Theme.PrimaryText,
                Size = v8,

                Image = function() -- Line: 458, Name: Image
                    -- upvalues: u11 (copy)
                    return `rbxthumb://type=AvatarHeadShot&id={u11()}&w=48&h=48`;
                end,

                UI.new("UIAspectRatioConstraint")({
                    AspectType = Enum.AspectType.ScaleWithParentSize,
                    DominantAxis = Enum.DominantAxis.Height
                }),
                UI.new("UICorner")({
                    CornerRadius = UI.Theme.CornerPadded
                })
            }),
            u15
        }),
        UI.new("ListItem")({
            Text = "Reason",
            u20
        }),
        u45,
        UI.new("ListItem")({
            Text = "Duration",

            Visible = function() -- Line: 480, Name: Visible
                -- upvalues: u9 (copy)
                return u9() == "Timed";
            end,

            UI.new("Input")({
                AutomaticSize = Enum.AutomaticSize.X,
                FontFace = UI.Theme.FontMono,
                FontSize = UI.Theme.FontSize,
                MaxChars = 3,
                NumberOnly = true,
                NumberRange = NumberRange.new(1, 999),
                Placeholder = "",
                Size = v8,
                Value = 1,
                [UI.Hook] = {
                    Value = function(p48) -- Line: 494, Name: Value
                        -- upvalues: u13 (ref)
                        u13 = p48;
                    end
                }
            }),
            u14
        }),
        UI.new("Button")({
            Label = "Ban",

            Activated = function() -- Line: 504, Name: Activated
                -- upvalues: u11 (copy), u4 (ref), u9 (copy), u13 (ref), u2 (copy), u14 (copy), u12 (ref)
                if u11._value then
                    u4.Visible(false);
                    local v49 = u9._value == "Server" and 0 or (u9._value == "Forever" and -1 or u13 * u2.Util.Time.fromUnit(u14.Value._value));
                    u2.Remote.Ban:Fire(u11._value, u12, v49);
                end;
            end
        })
    });
    local v50 = UI.new("Button")({
        LayoutOrder = 3,
        ActiveSound = false,
        Icon = UI.Theme.Image.Add,
        IconProperties = {
            ImageColor3 = UI.Theme.PrimaryText
        },
        Size = UDim2.new(1, 0, 1, 0),
        SizeConstraint = Enum.SizeConstraint.RelativeYY,
        UI.new("UIPadding")({
            PaddingTop = UI.Theme.Padding,
            PaddingBottom = UI.Theme.Padding,
            PaddingLeft = UI.Theme.Padding,
            PaddingRight = UI.Theme.Padding
        }),

        Activated = function() -- Line: 534, Name: Activated
            -- upvalues: u4 (ref), u11 (copy), u15 (ref), u12 (ref), u20 (copy), UI (ref)
            if not u4.Visible._value then
                u11(nil);
                u15.Value("");
                u12 = nil;
                u20.Value("");
                u4.Title("New Ban");
                UI.Sound.Hover03:Play();
            end;

            u4.Visible(not u4.Visible._value);
        end
    });
    UI.new("Tooltip")({
        Text = "New Ban",
        Parent = v50,
        Hovering = v50._hovering
    });
    UI.edit(v50._instance.UICorner, {
        CornerRadius = UI.Theme.CornerPadded
    });
    u32._input._instance = UI.new("Frame")({
        Parent = u32,
        Name = "FilterInput",
        BackgroundTransparency = 1,

        Size = function() -- Line: 554, Name: Size
            -- upvalues: UI (ref)
            return UDim2.new(0, 0, 0, UI.Theme.FontSize() + UI.Theme.PaddingDouble().Offset);
        end,

        UI.new("UIListLayout")({
            FillDirection = Enum.FillDirection.Horizontal,
            Padding = UI.Theme.PaddingWithStroke,
            SortOrder = Enum.SortOrder.LayoutOrder
        }),
        UI.edit(u32._input, { UI.new("UIFlexItem")({
                FlexMode = Enum.UIFlexMode.Fill
            }) }),
        v50
    });

    return u32;
end;

return v1;