-- Decompiled with Potassium's decompiler.

local Players = game:GetService("Players");
game:GetService("TweenService");
local ReplicatedStorage = game:GetService("ReplicatedStorage");
local RunService = game:GetService("RunService");
game:GetService("ContentProvider");
local RaceChat = require(game:GetService("ReplicatedStorage"):WaitForChild("Modules"):WaitForChild("Shared"):WaitForChild("RaceChat"));
local Modules = ReplicatedStorage:WaitForChild("Modules");
local Remotes = ReplicatedStorage:WaitForChild("Remotes");
local Assets = ReplicatedStorage.Assets;
local Metadata = Modules.Metadata;
local _ = Modules.Shared;
local UtilityHandler = require(Modules.Utility.UtilityHandler);
require(Metadata.PlanetData.GravityData);
local StatRetrieveRemote = ReplicatedStorage.Remotes.StatRetrieveRemote;
local BindStatRetrieveRemote = Remotes.BindStatRetrieveRemote;
local AnimationRemote = Remotes.AnimationRemote;
local workspace_World = workspace.World;
local _ = workspace_World.Visuals;
local _ = workspace_World.Map.CurrentPlanet.Planet;
local Animations = Assets.Animations;
local Descendants = Animations:GetDescendants();
local u1 = {
    CachedAnimation = {}
};

function u1.CreateProfile(p2) -- Line: 54
    -- upvalues: u1 (copy)
    if u1[p2.Name] == true then
        return;
    end;

    u1[p2.Name] = {
        LoadedAnimations = {}
    };
end;

local u3 = { "This gravity makes it so hard to move...", "I can\'t move as fast as I usually do... is it this planet...?", "I Feel so Heavy...", "I Definently Need to train in a Gravity Chamber..." };

for _, v in pairs(Descendants) do
    if v:IsA("Animation") then
        u1.CachedAnimation[v.Name] = v;
    end;
end;

u1.CombatAnimation = {};

for _, v in ipairs({ "Combat/Light Attacks", "Combat/Heavy", "Combat/Block", "Combat/Dodge" }) do
    local v4 = v;
    local v5 = Animations;

    for i in v:gmatch("[^/]+") do
        if Animations then
            Animations = Animations:FindFirstChild(i);
        end;
    end;

    if Animations then
        for _, descendant in ipairs(Animations:GetDescendants()) do
            if descendant:IsA("Animation") then
                u1.CombatAnimation[descendant.Name] = true;
            end;
        end;

        Animations = v5;
    else
        warn("[AnimationManager] weighted anim folder not found:", v4);
        Animations = v5;
    end;
end;

function u1.WeightAnimScale(p6) -- Line: 124
    if not p6 then
        return 1;
    end;

    if not p6:FindFirstChild("Weighted Gear") then
        return 1;
    end;

    local Attribute = p6:GetAttribute("WeightAnimScale");

    return (type(Attribute) ~= "number" or (Attribute <= 0 or Attribute >= 1)) and 1 or Attribute;
end;

local function attackSpeedScale(p7) -- Line: 135
    -- upvalues: Players (copy)
    if p7 then
        p7 = Players:GetPlayerFromCharacter(p7);
    end;

    if p7 then
        p7 = p7:FindFirstChild("PlayerStats");
    end;

    if p7 then
        p7 = p7:FindFirstChild("AttackSpeedMultiplier", true);
    end;

    return p7 and (p7.Value > 0 and p7.Value) or 1;
end;

local function GetAnimator(p8) -- Line: 142
    local v9 = p8:FindFirstChildOfClass("Humanoid");
    local v10 = v9 and v9:FindFirstChildOfClass("Animator");

    if v10 then
        return v10;
    end;

    local v11 = p8:FindFirstChildOfClass("AnimationController");
    local v12 = v11 and v11:FindFirstChildOfClass("Animator");

    if v12 then
        return v12;
    end;

    local AnimationController = Instance.new("AnimationController");
    AnimationController.Parent = p8;
    local Animator = Instance.new("Animator");
    Animator.Parent = AnimationController;

    return Animator;
end;

function u1.GetProfile(p13, p14) -- Line: 166
    -- upvalues: u1 (copy)
    if p14 then
        if u1[p14.Name] == true then
            return true, u1[p14.Name];
        end;

        u1.CreateProfile(p14);

        return true, u1[p14.Name];
    end;
end;

function u1.CleanupCharacter(p15) -- Line: 186
    -- upvalues: u1 (copy)
    if not p15 then
        return;
    end;

    local v16 = u1[p15];

    if type(v16) == "table" and type(v16.LoadedAnimations) == "table" then
        for i, v in pairs(v16.LoadedAnimations) do
            pcall(function() -- Line: 194
                -- upvalues: v (copy)
                if v.IsPlaying then
                    v:Stop(0);
                end;

                v:Destroy();
            end);
            v16.LoadedAnimations[i] = nil;
        end;
    end;

    u1[p15] = nil;

    if typeof(p15) == "Instance" then
        u1[p15.Name] = nil;
    end;
end;

function u1.AdjustAnimationSpeed(p17, p18, p19) -- Line: 217
    -- upvalues: RunService (copy), Players (copy), AnimationRemote (copy), u1 (copy)
    if not p17 then
        return;
    end;

    local v20 = tonumber(p19) or 1;
    local v21 = RunService:IsServer() and Players:GetPlayerFromCharacter(p17);

    if v21 then
        AnimationRemote:FireClient(v21, p18, "Adjust", {
            AdjustSpeed = v20
        }, p17);
    end;

    local v22 = u1[p17];
    local v23 = v22 and v22.LoadedAnimations and v22.LoadedAnimations[p18];

    if v23 and v23.IsPlaying then
        v23:AdjustSpeed(v20);
    end;
end;

function u1.LoadAnimations(p24, p25) -- Line: 237
    -- upvalues: u1 (copy), GetAnimator (copy), Animations (copy), UtilityHandler (copy)
    local _, _ = u1:GetProfile(p24);
    local v26 = typeof(p25) == "string" and ({ p25 } or p25) or p25;
    p24:WaitForChild("Humanoid");
    local v27 = GetAnimator(p24);

    for _, _ in ipairs(v26) do
        local v28 = UtilityHandler:deepSearchFolder(Animations, "Animation");

        for _, v in ipairs(v28) do
            if not u1[p24.Name].LoadedAnimations[v.Name] then
                u1[p24.Name].LoadedAnimations[v.Name] = v27:LoadAnimation(v);
            end;
        end;
    end;
end;

function u1.PlayAnimation(u29, p30, p31) -- Line: 257
    -- upvalues: u1 (copy), GetAnimator (copy), Players (copy), RunService (copy), AnimationRemote (copy), BindStatRetrieveRemote (copy), StatRetrieveRemote (copy), u3 (copy), RaceChat (copy)
    if u1.CachedAnimation[p30] then
        local v32 = p31 and (p31.FadeTime or 0.2) or 0.2;
        local v33 = p31 and (p31.Weight or 1) or 1;
        local v34 = p31 and (p31.AdjustSpeed or 1) or 1;
        local v35;

        if p31 then
            v35 = p31.Looped or false;
        else
            v35 = false;
        end;

        local v36;

        if p31 then
            v36 = p31.Priority;
        else
            v36 = p31;
        end;

        local v37;

        if p31 then
            v37 = p31.SkipIfPlaying;
        else
            v37 = p31;
        end;

        local v38 = GetAnimator(u29);
        local v39 = u1.CachedAnimation[p30];

        if not u1[u29] then
            u1[u29] = {};
            u1[u29].LoadedAnimations = {};
            u1[u29]._animator = v38;
            local u40 = u1[u29];
            u29.Destroying:Once(function() -- Line: 312
                -- upvalues: u1 (ref), u29 (copy), u40 (copy)
                if u1[u29] == u40 then
                    u1.CleanupCharacter(u29);
                end;
            end);
        end;

        if u1[u29]._animator ~= v38 then
            u1[u29].LoadedAnimations = {};
            u1[u29]._animator = v38;
        end;

        if not u1[u29].LoadedAnimations[p30] then
            u1[u29].LoadedAnimations[p30] = v38:LoadAnimation(v39);
        end;

        local v41 = u1[u29].LoadedAnimations[p30];

        if v37 and v41.IsPlaying then
            v41:AdjustSpeed(v34);
            v41.Looped = v35;

            return v41;
        end;

        if u1.CombatAnimation[p30] then
            local v42;

            if u29 and u29:FindFirstChild("Weighted Gear") then
                local Attribute = u29:GetAttribute("WeightAnimScale");
                v42 = (type(Attribute) ~= "number" or (Attribute <= 0 or Attribute >= 1)) and 1 or Attribute;
            else
                v42 = 1;
            end;

            local v43;

            if u29 then
                v43 = Players:GetPlayerFromCharacter(u29);
            else
                v43 = u29;
            end;

            if v43 then
                v43 = v43:FindFirstChild("PlayerStats");
            end;

            if v43 then
                v43 = v43:FindFirstChild("AttackSpeedMultiplier", true);
            end;

            v34 = v34 * v42 * (v43 and (v43.Value > 0 and v43.Value) or 1);
        end;

        if v36 then
            v41.Priority = v36;
        end;

        v41:Play(v32, v33);
        v41:AdjustSpeed(v34);
        v41.Looped = v35;
        local v44 = RunService:IsServer() and Players:GetPlayerFromCharacter(u29);

        if v44 then
            AnimationRemote:FireClient(v44, p30, "Play", p31, u29);
        end;

        local function Gravity_Stuff(p45) -- Line: 383
            -- upvalues: RunService (ref), BindStatRetrieveRemote (ref), StatRetrieveRemote (ref), u3 (ref), RaceChat (ref), u29 (copy)
            local CurrentGravity = p45:WaitForChild("PlayerStats"):FindFirstChild("CurrentGravity", true);
            local v46;

            if RunService:IsServer() then
                v46 = BindStatRetrieveRemote:Invoke(p45, "GravityMastery");
            else
                v46 = StatRetrieveRemote:InvokeServer("GravityMastery");
            end;

            local math_clamp_ret = math.clamp(v46 / CurrentGravity.Value, 0.75, 1);

            if math.random(1, 1000) == 1 and math_clamp_ret < 1 then
                local v47 = u3[math.random(1, #u3)];
                RaceChat.Say(u29, v47);
            end;
        end;

        local PlayerFromCharacter = Players:GetPlayerFromCharacter(u29);

        if PlayerFromCharacter then
            task.spawn(function() -- Line: 420
                -- upvalues: Gravity_Stuff (copy), PlayerFromCharacter (copy)
                Gravity_Stuff(PlayerFromCharacter);
            end);
        end;

        return v41;
    end;

    warn("\'" .. p30 .. "\'", "Requested Animation is an invalid type");
end;

function u1.ReloadAnimation(p48, p49, p50) -- Line: 440
    -- upvalues: RunService (copy), Players (copy), AnimationRemote (copy), u1 (copy)
    local v51 = RunService:IsServer() and Players:GetPlayerFromCharacter(p48);

    if v51 then
        AnimationRemote:FireClient(v51, p49, "Reload", p50, p48);
    end;

    local v52 = u1[p48];
    local u53 = v52 and v52.LoadedAnimations and v52.LoadedAnimations[p49];

    if u53 then
        if u53.IsPlaying then
            u53:Stop(0);
        end;

        pcall(function() -- Line: 452
            -- upvalues: u53 (copy)
            u53:Destroy();
        end);
        v52.LoadedAnimations[p49] = nil;
    end;

    return u1.PlayAnimation(p48, p49, p50);
end;

function u1.StopAnimation(p54, p55, p56) -- Line: 458
    -- upvalues: RunService (copy), Players (copy), AnimationRemote (copy), u1 (copy)
    local v57 = typeof(p55) == "string" and p55 and p55 or warn("Requested Animation is an invalid type");
    local v58 = RunService:IsServer() and v57 and Players:GetPlayerFromCharacter(p54);

    if v58 then
        AnimationRemote:FireClient(v58, v57, "Stop", p56, p54);
    end;

    if not (u1[p54] and u1[p54].LoadedAnimations[v57]) then
        return;
    end;

    local v59 = p56 and (p56.FadeTime or 0.1) or 0.1;
    local v60 = p56 and p56.Weight or 1;
    p54:WaitForChild("Humanoid"):FindFirstChildOfClass("Animator");
    local v61 = u1[p54].LoadedAnimations[v57];
    v61.Looped = false;
    v61:Stop(v59, v60);
    v61:AdjustWeight(0);
end;

local u62 = {
    ["Saiyan Tail Wag"] = true,
    ["Arcosian Tail Wag"] = true,
    ["Bio Tail Wag"] = true,
    ["Tail Tuck"] = true
};
u1.PersistentLoops = u62;

function u1.StopAllAnimations(p63) -- Line: 511
    -- upvalues: RunService (copy), Players (copy), AnimationRemote (copy), u1 (copy), u62 (copy)
    local v64 = RunService:IsServer() and Players:GetPlayerFromCharacter(p63);

    if v64 then
        AnimationRemote:FireClient(v64, "", "StopAll", nil, p63);
    end;

    local v65 = p63:FindFirstChildOfClass("Humanoid");

    if v65 then
        v65 = v65:FindFirstChildOfClass("Animator");
    end;

    if not v65 then
        return;
    end;

    local v66 = {};
    local v67 = u1[p63];

    if v67 and v67.LoadedAnimations then
        for i, v in pairs(v67.LoadedAnimations) do
            if u62[i] then
                v66[v] = true;
            end;
        end;
    end;

    for _, v in ipairs(v65:GetPlayingAnimationTracks()) do
        local v68 = v66[v];

        if not v68 then
            local Animation = v.Animation;

            if Animation == nil then
                v68 = false;
            else
                v68 = u62[Animation.Name] == true;
            end;
        end;

        if not v68 then
            v:Stop();
        end;
    end;
end;

return u1;