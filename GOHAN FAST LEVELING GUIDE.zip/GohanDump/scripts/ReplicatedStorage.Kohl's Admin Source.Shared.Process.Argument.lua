-- Decompiled with Potassium's decompiler.

local u1 = {};
u1.__index = u1;

function u1.parseTypeUnion(p2: string, p3: string) -- Line: 6
    local string_split_ret = string.split(p2, " ");
    local v4 = {};

    for i = 1, #string_split_ret, 2 do
        v4[#v4 + 1] = {
            prefix = string_split_ret[i - 1] or "",
            type = string_split_ret[i]
        };
        local _ = i;
    end;

    table.sort(v4, function(p5, p6) -- Line: 18
        return #p5.prefix > #p6.prefix;
    end);

    for _, v in v4 do
        if string.sub(p3, 1, #v.prefix) == v.prefix then
            return v.type, p3:sub(#v.prefix + 1), v.prefix;
        end;
    end;
end;

function u1.new(p7, p8, p9, p10) -- Line: 30
    -- upvalues: u1 (copy)
    local v11, v12, v13 = u1.parseTypeUnion(p8.type, p10);
    local v14 = p7._K.Registry.types[v11];
    local v15 = `Invalid argument type {v11}, did it fail to register?`;
    assert(v14, v15);
    local v16 = not v14.listable and { v12 } or p7._K.Util.String.splitOutsideQuotes(v12);

    return setmetatable({
        validated = false,
        _K = p7._K,
        command = p7,
        commandArray = p7.array,
        definition = p8,
        argPos = p9,
        prefix = v13,
        rawArg = p10,
        rawType = v14,
        rawArgs = v16,
        transformedArgs = {},
        transformedTypes = {},
        parsedArgs = {}
    }, u1);
end;

function u1.invalidate(p17, p18, p19, p20) -- Line: 57
    p17.invalid = {
        arg = p18,
        pos = p19,
        message = p20
    };

    return false, p17.invalid;
end;

function u1.transform(p21) -- Line: 62
    local argPos = p21.argPos;

    for _, v in p21.rawArgs do
        local v22 = p21._K.Util.String.stripQuotes(p21._K.Util.String.trim(v));
        local rawType = p21.rawType;
        local v23;

        if rawType.prefixes then
            v23 = v;

            for i, v2 in rawType.prefixes do
                local string_find_ret, v24 = string.find(v22, i);

                if string_find_ret == 1 then
                    rawType = p21._K.Registry.types[v2];
                    v22 = string.sub(v22, v24 + 1);
                    break;
                end;
            end;
        else
            v23 = v;
        end;

        if rawType.transform then
            local v25 = not string.find(v22, "%S") and p21.definition.optional;
            local v26;
            v22, v26 = rawType.transform(v22);

            if v22 == nil and not v25 then
                return p21:invalidate(v23, argPos, v26 or "Invalid transform: " .. (string.find(v23, "^%s*$") and "nil" or v23));
            end;
        end;

        table.insert(p21.transformedArgs, v22);
        table.insert(p21.transformedTypes, rawType);
        argPos = argPos + (#v23 + 1);
    end;

    return true;
end;

function u1.validate(p27) -- Line: 95
    if p27.validated then
        return true;
    end;

    if p27.definition.optional and #p27.rawArg == 0 then
        return true;
    end;

    if p27.invalid then
        return false, p27.invalid.message;
    end;

    local argPos = p27.argPos;

    for i, v in p27.transformedArgs do
        local v28 = p27.rawArgs[i];
        local v29, v30 = p27.transformedTypes[i].validate(v, p27);

        if not v29 then
            return p27:invalidate(v28, argPos, v30 or "Invalid argument: " .. v28);
        end;

        argPos = argPos + (#v28 + 1);
    end;

    p27.validated = true;

    return true;
end;

function u1.parse(p31) -- Line: 123
    if not (p31.validated or p31.definition.optional) then
        return false, "Argument must be validated before parsing";
    end;

    local argPos = p31.argPos;

    for i, v in p31.transformedArgs do
        local v32 = p31.rawArgs[i];
        local v33 = p31.transformedTypes[i];
        local v34, v35, v36 = pcall(v33.parse, v, p31);

        if not v34 or v35 == nil then
            return p31:invalidate(v32, argPos, v36 or (v35 or "Invalid argument: " .. v32));
        end;

        if v33.listable and not p31.rawType.listable then
            table.insert(p31.parsedArgs, v35[1]);
        elseif v33.listable and (p31.rawType.listable and v33 ~= p31.rawType) then
            for _, v2 in v35 do
                table.insert(p31.parsedArgs, v2);
            end;
        else
            table.insert(p31.parsedArgs, v35);
        end;

        argPos = argPos + (#v32 + 1);
    end;

    if p31.rawType.postParse then
        local success, result = pcall(p31.rawType.postParse, p31.parsedArgs, p31);
        _ = success;
        p31.parsedArgs = result;
    end;

    local v37 = true;

    if p31.rawType.listable then
        return v37, p31.parsedArgs;
    end;

    return v37, p31.parsedArgs[1];
end;

function u1.prepare(p38) -- Line: 157
    p38._K.Data.targetLimits[p38.command.from] = 0;

    if p38.validated then
        local v39 = true;

        if p38.rawType.listable then
            return v39, p38.parsedArgs;
        end;

        return v39, p38.parsedArgs[1];
    end;

    local v40, v41 = p38:transform();

    if not v40 then
        return false, v41;
    end;

    local v42, v43 = p38:validate();

    if v42 then
        return p38:parse();
    end;

    return false, v43;
end;

return u1;