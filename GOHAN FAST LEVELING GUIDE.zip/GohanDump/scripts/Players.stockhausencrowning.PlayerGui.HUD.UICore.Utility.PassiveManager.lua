-- Decompiled with Potassium's decompiler.

local Utility = game:GetService("ReplicatedStorage"):WaitForChild("Modules").Utility;
local PassiveHud = require(Utility.PassiveHud);
local u1 = {
    Race = 1,
    RaceTrait = 2,
    Misc = 3
};

local function collect(p2, p3, p4, p5) -- Line: 31
    if type(p4) ~= "table" then
        return;
    end;

    for i, v in pairs(p4) do
        if not (p3[i] or (type(v) ~= "table" or v.Unlocked ~= true)) then
            p3[i] = true;
            p2[#p2 + 1] = {
                Name = i,
                Category = p5,
                Count = v.Bodies
            };
        end;
    end;
end;

return {
    Update = function(p6) -- Line: 47, Name: Update
        -- upvalues: collect (copy), u1 (copy), PassiveHud (copy)
        if type(p6) ~= "table" then
            return;
        end;

        local Race = p6.CharacterData.Race.Race;
        local SubType = p6.CharacterData.Race.SubType;
        local Passives = p6.StatData.Passives;
        local v7 = {};
        local v8 = {};
        collect(v7, v8, Passives.Race and Passives.Race[Race], "Race");
        collect(v7, v8, Passives.RaceTrait and Passives.RaceTrait[Race] and Passives.RaceTrait[Race][SubType], "RaceTrait");
        collect(v7, v8, Passives.Misc, "Misc");
        table.sort(v7, function(p9, p10) -- Line: 63
            -- upvalues: u1 (ref)
            if p9.Category == p10.Category then
                return p9.Name < p10.Name;
            end;

            return u1[p9.Category] < u1[p10.Category];
        end);
        PassiveHud.Render(v7);
    end
};