-- Decompiled with Potassium's decompiler.

game:GetService("Players");
local Debris = game:GetService("Debris");
local ReplicatedStorage = game:GetService("ReplicatedStorage");
game:GetService("RunService");
local Assets = ReplicatedStorage.Assets;
local Modules = ReplicatedStorage:WaitForChild("Modules");
ReplicatedStorage:WaitForChild("Remotes");
local _ = Modules.Metadata;
local Shared = Modules.Shared;
local _ = Modules.Utility;
local GlobalFunctions = require(Modules.GlobalFunctions);
require(Shared.SoundManager);
local _ = workspace.World.Visuals;
local _ = Assets.Effects.Particles;
local Gui = Assets.Gui;

return {
    Execute = function(p1, p2) -- Line: 35
        -- upvalues: Gui (copy), Debris (copy), GlobalFunctions (copy)
        local math_random_ret = math.random(3, 5);
        local math_random_ret2 = math.random(3, 5);
        local math_random_ret3 = math.random(0, 1);
        local u3 = math.random(-5, 5) / 2;
        local math_floor_ret = math.floor((p2 or 1) + 0.5);
        local math_max_ret = math.max(1, math_floor_ret);
        local u4 = Gui.DamageGui:Clone();
        u4.Parent = p1;
        u4.TextLabel.Text = math_max_ret;
        Debris:AddItem(u4, 1);
        local v5 = {
            Duration = 0.5,
            Instance = u4,
            EasingStyle = Enum.EasingStyle.Linear,
            EasingDirection = Enum.EasingDirection.Out
        };
        local v6 = {
            StudsOffset = Vector3.new(u3, math_random_ret2, 0),
            Size = UDim2.new(math_random_ret, 0, math_random_ret, 0)
        };
        GlobalFunctions.Tween(v5, v6);
        task.delay(0.5, function() -- Line: 65, Name: Fall
            -- upvalues: u4 (copy), u3 (copy), math_random_ret3 (copy), GlobalFunctions (ref)
            local v7 = {
                Duration = 0.5,
                Instance = u4,
                EasingStyle = Enum.EasingStyle.Linear,
                EasingDirection = Enum.EasingDirection.Out
            };
            local v8 = {
                StudsOffset = Vector3.new(u3 * 2, math_random_ret3, 0)
            };
            local v9 = {
                Duration = 0.5,
                Instance = u4.TextLabel,
                EasingStyle = Enum.EasingStyle.Linear,
                EasingDirection = Enum.EasingDirection.Out
            };
            local v10 = {
                TextTransparency = 1,
                TextStrokeTransparency = 1,
                TextColor3 = Color3.fromRGB(255, 0, 0)
            };
            GlobalFunctions.Tween(v7, v8);
            GlobalFunctions.Tween(v9, v10);
        end);
    end,

    Visual = function(p11) -- Line: 97
        -- upvalues: Debris (copy)
        local Color3_fromRGB_ret = Color3.fromRGB(255, 255, 255);
        local Highlight = Instance.new("Highlight");
        Highlight.Parent = p11;
        Highlight.FillColor = Color3_fromRGB_ret;
        Highlight.OutlineColor = Color3_fromRGB_ret;
        Highlight.FillTransparency = 0.8;
        Highlight.OutlineTransparency = 0.8;
        Highlight.DepthMode = Enum.HighlightDepthMode.Occluded;
        Debris:AddItem(Highlight, 0.2);
    end,

    Crit = function(p12) -- Line: 113
        -- upvalues: Gui (copy), Debris (copy), GlobalFunctions (copy)
        local math_random_ret = math.random(3, 5);
        local math_random_ret2 = math.random(3, 5);
        local math_random_ret3 = math.random(0, 1);
        local u13 = math.random(-5, 5) / 2;
        local u14 = Gui.DamageGui:Clone();
        u14.Parent = p12;
        u14.TextLabel.Text = "CRIT";
        u14.TextLabel.TextColor3 = Color3.fromRGB(135, 0, 0);
        Debris:AddItem(u14, 1);
        local v15 = {
            Duration = 0.5,
            Instance = u14,
            EasingStyle = Enum.EasingStyle.Linear,
            EasingDirection = Enum.EasingDirection.Out
        };
        local v16 = {
            StudsOffset = Vector3.new(u13, math_random_ret2, 0),
            Size = UDim2.new(math_random_ret, 0, math_random_ret, 0)
        };
        GlobalFunctions.Tween(v15, v16);
        task.delay(0.5, function() -- Line: 140, Name: Fall
            -- upvalues: u14 (copy), u13 (copy), math_random_ret3 (copy), GlobalFunctions (ref)
            local v17 = {
                Duration = 0.5,
                Instance = u14,
                EasingStyle = Enum.EasingStyle.Linear,
                EasingDirection = Enum.EasingDirection.Out
            };
            local v18 = {
                StudsOffset = Vector3.new(u13 * 2, math_random_ret3, 0)
            };
            local v19 = {
                Duration = 0.5,
                Instance = u14.TextLabel,
                EasingStyle = Enum.EasingStyle.Linear,
                EasingDirection = Enum.EasingDirection.Out
            };
            local v20 = {
                TextTransparency = 1,
                TextStrokeTransparency = 1,
                TextColor3 = Color3.fromRGB(255, 0, 0)
            };
            GlobalFunctions.Tween(v17, v18);
            GlobalFunctions.Tween(v19, v20);
        end);
    end,

    Miss = function(p21) -- Line: 172
        -- upvalues: Gui (copy), Debris (copy), GlobalFunctions (copy)
        local math_random_ret = math.random(3, 5);
        local math_random_ret2 = math.random(3, 5);
        local math_random_ret3 = math.random(0, 1);
        local u22 = math.random(-5, 5) / 2;
        local u23 = Gui.DamageGui:Clone();
        u23.Parent = p21;
        u23.TextLabel.Text = "MISS";
        u23.TextLabel.TextColor3 = Color3.fromRGB(255, 255, 0);
        Debris:AddItem(u23, 1);
        local v24 = {
            Duration = 0.5,
            Instance = u23,
            EasingStyle = Enum.EasingStyle.Linear,
            EasingDirection = Enum.EasingDirection.Out
        };
        local v25 = {
            StudsOffset = Vector3.new(u22, math_random_ret2, 0),
            Size = UDim2.new(math_random_ret, 0, math_random_ret, 0)
        };
        GlobalFunctions.Tween(v24, v25);
        task.delay(0.5, function() -- Line: 199, Name: Fall
            -- upvalues: u23 (copy), u22 (copy), math_random_ret3 (copy), GlobalFunctions (ref)
            local v26 = {
                Duration = 0.5,
                Instance = u23,
                EasingStyle = Enum.EasingStyle.Linear,
                EasingDirection = Enum.EasingDirection.Out
            };
            local v27 = {
                StudsOffset = Vector3.new(u22 * 2, math_random_ret3, 0)
            };
            local v28 = {
                Duration = 0.5,
                Instance = u23.TextLabel,
                EasingStyle = Enum.EasingStyle.Linear,
                EasingDirection = Enum.EasingDirection.Out
            };
            local v29 = {
                TextTransparency = 1,
                TextStrokeTransparency = 1,
                TextColor3 = Color3.fromRGB(255, 255, 255)
            };
            GlobalFunctions.Tween(v26, v27);
            GlobalFunctions.Tween(v28, v29);
        end);
    end
};