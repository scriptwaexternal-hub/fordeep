-- Decompiled with Potassium's decompiler.

game:GetService("Players");
game:GetService("Debris");
local ReplicatedStorage = game:GetService("ReplicatedStorage");
game:GetService("RunService");
game:GetService("CollectionService");
local _ = ReplicatedStorage.Assets;
local Modules = ReplicatedStorage:WaitForChild("Modules");
ReplicatedStorage:WaitForChild("Remotes");
local _ = Modules.Metadata;
local _ = Modules.Utility;
local u1 = require(Modules.Shared["Destroy Terrain"]);

return {
    Fire = function(p2) -- Line: 22
        -- upvalues: u1 (copy)
        u1.Destroy(p2.PartToDestroy);
    end
};