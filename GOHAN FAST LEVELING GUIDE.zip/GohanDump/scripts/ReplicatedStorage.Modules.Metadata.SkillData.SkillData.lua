-- Decompiled with Potassium's decompiler.

local u1 = {
    Blasts = {
        ["Ki Blast"] = {
            Voxelize = false,
            Damage = 8.8,
            AimAssist = true,
            KiCost = 10,
            InitialCharge = 1,
            Scale = 2
        },
        ["Big Bang Attack"] = {
            Damage = 50.1,
            AimAssist = true,
            Cooldown = 45,
            KiCost = 210,
            InitialCharge = 1,
            Scale = 2
        },
        ["Milky Cannon"] = {
            Damage = 60.1,
            AimAssist = true,
            Cooldown = 45,
            KiCost = 210,
            InitialCharge = 1,
            Scale = 2
        },
        ["Eraser Cannon"] = {
            Damage = 78.1,
            AimAssist = true,
            SkillUseTime = 1.5,
            Cooldown = 60,
            KiCost = 350,
            InitialCharge = 3,
            Scale = 5
        },
        ["Energy Crash"] = {
            Damage = 67.5,
            AimAssist = true,
            SkillUseTime = 0.5,
            Cooldown = 45,
            KiCost = 225,
            InitialCharge = 3,
            Scale = 2
        },
        ["Ki Barrage"] = {
            Damage = 2,
            Cooldown = 35,
            KiCost = 120,
            AimAssist = false,
            Scale = 0.35,
            SkillUseTime = 0.5
        },
        ["Dirty Fireworks"] = {
            Damage = 45,
            Cooldown = 45,
            KiCost = 150,
            AimAssist = false,
            Scale = 1
        },
        ["Hellzone Grenade"] = {
            Damage = 45,
            Cooldown = 35,
            KiCost = 200,
            AimAssist = false,
            Scale = 1
        },
        ["Burning Attack"] = {
            Damage = 45,
            Cooldown = 40,
            AimAssist = false,
            KiCost = 250,
            Scale = 1
        },
        ["Tri-Beam"] = {
            Damage = 22.5,
            Cooldown = 8,
            AimAssist = true,
            KiCost = 150,
            Scale = 2
        },
        ["Neo Tri-Beam"] = {
            Damage = 15.1,
            Cooldown = 50,
            AimAssist = true,
            KiCost = 150,
            Scale = 1.5
        },
        ["Blazing Storm"] = {
            Damage = 46.4,
            Cooldown = 35,
            AimAssist = true,
            KiCost = 90,
            Scale = 2
        },
        Kienzan = {
            Damage = 63,
            AimAssist = false,
            Cooldown = 70,
            KiCost = 250,
            Scale = 4
        },
        ["Spread Energy Blast"] = {
            Damage = 39.9,
            Cooldown = 40,
            KiCost = 150,
            AimAssist = false,
            Scale = 2
        },
        ["Super Energy Wave Volley"] = {
            Damage = 27,
            AimAssist = false,
            Cooldown = 20,
            KiCost = 180,
            Scale = 1
        },
        ["Light Grenade"] = {
            Damage = 47.9,
            AimAssist = false,
            Cooldown = 30,
            KiCost = 90,
            InitialCharge = 3,
            Scale = 1
        }
    },
    Explosion = {
        ["Final Explosion"] = {
            Cooldown = 3,
            KiCost = 1
        },
        ["Explosion Wave"] = {
            Damage = 38.9,
            Cooldown = 30,
            KiCost = 140,
            AimAssist = false,
            Scale = 3
        },
        ["Rage Explosion"] = {
            Damage = 52,
            SkillUseTime = 4,
            Cooldown = 45,
            KiCost = 190,
            AimAssist = false,
            Scale = 3.5
        },
        ["Ultra Fighting Bomber"] = {
            Damage = 74.9,
            Cooldown = 60,
            KiCost = 250,
            AimAssist = false,
            Scale = 2.5
        },
        ["Volcano Explosion"] = {
            Damage = 43.4,
            Cooldown = 25,
            KiCost = 170,
            AimAssist = false,
            Scale = 3
        }
    },
    Melee = {
        ["Afterimage Strike"] = {
            Cooldown = 15,
            KiCost = 60
        },
        ["Dragon Throw"] = {
            Damage = 30,
            Cooldown = 30,
            KiCost = 150,
            Scale = 2.5
        },
        ["Bone Crusher"] = {
            Damage = 67.5,
            ExplosionDamage = 375,
            Cooldown = 35,
            KiCost = 175,
            Scale = 3
        },
        ["Assault Combo"] = {
            Cooldown = 50,
            KiCost = 175,
            Damage = 78,
            Scale = 1
        },
        ["Arm Break"] = {
            Damage = 78.8,
            Cooldown = 30,
            KiCost = 110,
            Scale = 3.5
        },
        SledgeHammer = {
            Damage = 45,
            Cooldown = 25,
            KiCost = 220,
            Scale = 3
        },
        ["Behind You"] = {
            Damage = 18,
            Cooldown = 35,
            KiCost = 110,
            Scale = 1.8
        }
    },
    Misc = {
        ["Instant Transmission"] = {
            Cooldown = 15,
            KiCost = 0.25
        },
        ["Solar Flare"] = {
            Cooldown = 35,
            KiCost = 100
        },
        ["Body Swap"] = {
            Cooldown = 150,
            KiCost = 500
        },
        ["Ginyu Pose"] = {
            Cooldown = 150,
            KiCost = 150
        }
    },
    Rush = {
        ["Amazing Impact"] = {
            Cooldown = 30,
            KiCost = 250,
            Damage = 63,
            Scale = 1
        },
        ["Punisher Drive"] = {
            Cooldown = 30,
            KiCost = 175,
            Damage = 55,
            Scale = 1
        },
        ["Meteor Combination"] = {
            Cooldown = 45,
            KiCost = 150,
            Damage = 67.5,
            Scale = 1
        }
    },
    Wave = {
        ["Double Sunday"] = {
            Damage = 7,
            Scale = 1.6,
            AimAssist = true,
            SkillUseTime = 0.5,
            Cooldown = 30,
            KiCost = 135,
            InitialCharge = 1
        },
        ["Dodon Ray"] = {
            Damage = 7,
            Scale = 1,
            Cooldown = 35,
            AimAssist = true,
            SkillUseTime = 1,
            KiCost = 140,
            InitialCharge = 0.5
        },
        ["Final Flash"] = {
            Damage = 8.4,
            Scale = 1,
            AimAssist = true,
            Cooldown = 50,
            KiCost = 250,
            InitialCharge = 4
        },
        ["Galick Gun"] = {
            Damage = 6.1,
            SkillUseTime = 1.5,
            Scale = 2,
            AimAssist = true,
            Cooldown = 40,
            KiCost = 175,
            InitialCharge = 0.85
        },
        ["Eraser Gun"] = {
            Damage = 14.9,
            SkillUseTime = 1.5,
            Scale = 2.3,
            AimAssist = true,
            Cooldown = 40,
            KiCost = 275,
            InitialCharge = 1.5
        },
        ["Galaxy Breaker"] = {
            Damage = 6.1,
            Scale = 2,
            Cooldown = 45,
            KiCost = 125,
            InitialCharge = 1
        },
        Kamehameha = {
            Damage = 8.8,
            Scale = 2.5,
            AimAssist = true,
            SkillUseTime = 1,
            Cooldown = 45,
            KiCost = 125,
            InitialCharge = 0.85
        },
        Masenko = {
            Damage = 7.4,
            Scale = 1,
            Cooldown = 25,
            SkillUseTime = 3,
            AimAssist = true,
            KiCost = 125,
            InitialCharge = 1.3
        },
        ["Super Masenko"] = {
            Damage = 9.4,
            Scale = 1.5,
            Cooldown = 35,
            SkillUseTime = 3,
            AimAssist = true,
            KiCost = 175
        },
        ["Special Beam Cannon"] = {
            Damage = 10.4,
            Scale = 3,
            Cooldown = 45,
            SkillUseTime = 1,
            AimAssist = true,
            KiCost = 250,
            InitialCharge = 1
        },
        ["Default Beam"] = {
            Damage = 3.4,
            Scale = 1,
            Cooldown = 10,
            SkillUseTime = 3.5,
            AimAssist = true,
            KiCost = 0,
            InitialCharge = 3
        }
    },
    ["Race Skills"] = {
        ["Bio-Android"] = {
            Mitosis = {
                Cooldown = 90,
                KiCost = 120
            },
            ["Solar Kamehameha"] = {
                Damage = 15.4,
                Scale = 2.5,
                AimAssist = true,
                SkillUseTime = 2,
                Cooldown = 60,
                KiCost = 200,
                InitialCharge = 0
            }
        },
        Saiyan = {
            ["Wild Sense"] = {
                Cooldown = 45,
                KiCost = 50,
                SkillUseTime = 0.5
            },
            ["Fake Moon"] = {
                Cooldown = 450,
                KiCost = 100
            },
            ["Ape Transformation"] = {
                Cooldown = 150,
                KiCost = 1
            }
        },
        Namekian = {
            Healing = {
                Cooldown = 1,
                KiCost = 50,
                Scale = 1
            },
            ["Super Regen"] = {
                Cooldown = 180,
                KiCost = 150,
                Scale = 1
            },
            ["Arm Stretch"] = {
                Damage = 27,
                Scale = 1,
                Cooldown = 10,
                KiCost = 50,
                SkillUseTime = 1
            },
            ["Magic Creation"] = {
                Cooldown = 10,
                KiCost = 100
            },
            ["Potential Unlock"] = {
                Cooldown = 10,
                KiCost = 200
            },
            ["Namekian Fusion"] = {
                Cooldown = 120,
                KiCost = 100
            },
            ["Dragonball Creation"] = {
                Cooldown = 180,
                KiCost = 320
            },
            ["Elder\'s Blessing"] = {
                Cooldown = 600,
                KiCost = 300,
                SkillUseTime = 1
            },
            ["Mouth Cannon"] = {
                Cooldown = 45,
                KiCost = 150,
                Damage = 6.5,
                Scale = 5,
                AimAssist = true,
                SkillUseTime = 1.2
            }
        },
        Majin = {
            Absorption = {
                Cooldown = 10,
                KiCost = 50
            },
            ["Candy Beam"] = {
                Damage = 5,
                Scale = 1,
                AimAssist = true,
                SkillUseTime = 0.5,
                Cooldown = 35,
                KiCost = 150,
                InitialCharge = 0.5
            }
        },
        Arcosian = {
            Supernova = {
                Damage = 90,
                AimAssist = true,
                SkillUseTime = 2,
                Cooldown = 70,
                KiCost = 350,
                InitialCharge = 2,
                Scale = 3
            },
            ["Death Beam"] = {
                Damage = 8.1,
                Scale = 2,
                AimAssist = true,
                SkillUseTime = 0,
                Cooldown = 45,
                KiCost = 100,
                InitialCharge = 0
            }
        },
        Human = {
            ["Hidden Power"] = {
                Cooldown = 45,
                KiCost = 45,
                SkillUseTime = 0.5
            },
            ["Third Eye"] = {
                Cooldown = 60,
                KiCost = 90,
                SkillUseTime = 0.5
            }
        },
        Android = {
            ["Energy Barrier"] = {
                Cooldown = 60,
                KiCost = 45,
                SkillUseTime = 0.5
            },
            ["Energy Steal"] = {
                Cooldown = 110,
                KiCost = 45,
                SkillUseTime = 0.5
            },
            ["Integrated Arsenal"] = {
                Damage = 72.5,
                AimAssist = true,
                Scale = 1.5,
                Cooldown = 28,
                KiCost = 85,
                SkillUseTime = 0.5
            },
            ["Self Destruct"] = {
                Damage = 188,
                Scale = 1.5,
                Cooldown = 150,
                KiCost = 1,
                SkillUseTime = 0.5
            }
        },
        Demon = {
            ["Dimensional Clones"] = {
                Cooldown = 120,
                KiCost = 150
            },
            ["Majin Mark"] = {
                Cooldown = 5,
                KiCost = 25,
                SkillUseTime = 0.5
            },
            ["Hell Portal"] = {
                Cooldown = 20,
                KiCost = 30,
                SkillUseTime = 0.5
            },
            ["Stone Spit"] = {
                Damage = 47,
                Scale = 2,
                Cooldown = 35,
                KiCost = 50,
                SkillUseTime = 0.5
            },
            ["Evil Spear"] = {
                Damage = 63,
                Scale = 4,
                Cooldown = 40,
                KiCost = 150,
                SkillUseTime = 0.5
            },
            ["Demon Breath"] = {
                Damage = 53,
                BurnDamage = 126,
                Scale = 2,
                Cooldown = 30,
                KiCost = 200,
                SkillUseTime = 0.5
            },
            ["Dimension Sword Attack"] = {
                Damage = 25,
                Scale = 1.5,
                Cooldown = 35,
                KiCost = 150,
                SkillUseTime = 0.5
            },
            ["Super Breath Cannon"] = {
                Damage = 7.6,
                Scale = 1.75,
                Cooldown = 30,
                KiCost = 150,
                SkillUseTime = 0.5
            },
            ["Bunkai Teleport"] = {
                Cooldown = 10,
                KiCost = 70,
                SkillUseTime = 0.5
            }
        }
    }
};
local u2 = {};
local u3 = {};

local function warnThrottled(p4) -- Line: 794
    -- upvalues: u2 (copy), u3 (copy)
    local os_clock_ret = os.clock();
    local v5 = u2[p4];

    if v5 and os_clock_ret - v5 < 3 then
        u3[p4] = (u3[p4] or 0) + 1;

        return;
    end;

    u2[p4] = os_clock_ret;
    local v6 = u3[p4];
    local v7;

    if v6 and v6 > 0 then
        u3[p4] = 0;
        v7 = (" (x%d more suppressed)"):format(v6);
    else
        v7 = "";
    end;

    warn(p4 .. v7 .. "\n" .. debug.traceback("  asked from", 3));
end;

function u1.Get(p8, p9) -- Line: 821
    -- upvalues: u1 (copy), warnThrottled (copy)
    local v10 = u1[p8];

    if not v10 then
        warnThrottled("SkillData.Get: unknown attack type \'" .. tostring(p8) .. "\' (wanted skill \'" .. tostring(p9) .. "\')");

        return nil;
    end;

    local v11 = v10[p9];

    if v11 then
        return v11;
    end;

    warnThrottled("SkillData.Get: unknown skill \'" .. tostring(p9) .. "\' in \'" .. tostring(p8) .. "\'");

    return nil;
end;

function u1.GetRace(p12, p13) -- Line: 840
    -- upvalues: u1 (copy), warnThrottled (copy)
    local v14 = u1["Race Skills"][p12];

    if not v14 then
        warnThrottled("SkillData.GetRace: unknown race \'" .. tostring(p12) .. "\' (wanted skill \'" .. tostring(p13) .. "\')");

        return nil;
    end;

    local v15 = v14[p13];

    if v15 then
        return v15;
    end;

    warnThrottled("SkillData.GetRace: unknown skill \'" .. tostring(p13) .. "\' for race \'" .. tostring(p12) .. "\'");

    return nil;
end;

function u1.GetAny(p16, p17, p18) -- Line: 860
    -- upvalues: u1 (copy)
    if p16 == "Race Skills" and p18 then
        return u1.GetRace(p18, p17);
    end;

    return u1.Get(p16, p17);
end;

return u1;