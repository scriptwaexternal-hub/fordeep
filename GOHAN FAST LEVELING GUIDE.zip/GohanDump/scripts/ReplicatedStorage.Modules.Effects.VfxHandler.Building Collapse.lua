-- Decompiled with Potassium's decompiler.

local TweenService = game:GetService("TweenService");
local u2 = {
    FindBuilding = function(p1) -- Line: 41, Name: FindBuilding
        while p1 and (p1 ~= workspace and p1 ~= game) do
            if p1:IsA("Model") or p1:IsA("Folder") then
                local Attribute = p1:GetAttribute("Building");

                if Attribute ~= nil then
                    return Attribute == true and p1 and p1 or nil;
                end;
            end;

            p1 = p1.Parent;
        end;

        return nil;
    end
};

function u2.IsBuildingPart(p3) -- Line: 55
    -- upvalues: u2 (copy)
    return u2.FindBuilding(p3) ~= nil;
end;

function u2.Collapse(u4, p5) -- Line: 59
    -- upvalues: TweenService (copy)
    if not (u4 and u4.Parent) then
        return;
    end;

    if u4:GetAttribute("Collapsing") then
        return;
    end;

    u4:SetAttribute("Collapsing", true);
    local v6 = p5 or (u4:IsA("Model") and (u4:GetPivot().Position or Vector3.new(0, 0, 0)) or Vector3.new(0, 0, 0));
    local u7 = {};
    local u8 = {};

    for _, descendant in ipairs(u4:GetDescendants()) do
        if descendant:IsA("BasePart") then
            u7[#u7 + 1] = {
                part = descendant,
                cf = descendant.CFrame,
                anchored = descendant.Anchored,
                canCollide = descendant.CanCollide,
                transparency = descendant.Transparency
            };
        elseif descendant:IsA("JointInstance") then
            u8[#u8 + 1] = {
                joint = descendant,
                enabled = descendant.Enabled
            };
        end;
    end;

    if #u7 == 0 then
        u4:SetAttribute("Collapsing", nil);

        return;
    end;

    for _, v in ipairs(u8) do
        v.joint.Enabled = false;
    end;

    local TweenInfo_new_ret = TweenInfo.new(2.5, Enum.EasingStyle.Quad, Enum.EasingDirection.In);

    for _, v in ipairs(u7) do
        local part = v.part;
        part.Anchored = false;
        part.CanCollide = false;
        local v9 = part.Position - v6;

        if v9.Magnitude < 0.1 then
            local math_random_ret = math.random(-1, 1);
            v9 = Vector3.new(math_random_ret, 1, math.random(-1, 1));
        end;

        part.AssemblyLinearVelocity = (v9.Unit + Vector3.new(0, 0.35, 0)) * 55;
        local math_random_ret = math.random(-12, 12);
        local math_random_ret2 = math.random(-12, 12);
        part.AssemblyAngularVelocity = Vector3.new(math_random_ret, math_random_ret2, math.random(-12, 12));
        TweenService:Create(part, TweenInfo_new_ret, {
            Transparency = 1
        }):Play();
    end;

    task.delay(2.5, function() -- Line: 110
        -- upvalues: u7 (copy)
        for _, v in ipairs(u7) do
            if v.part.Parent then
                v.part.Anchored = true;
                v.part.AssemblyLinearVelocity = Vector3.new(0, 0, 0);
                v.part.AssemblyAngularVelocity = Vector3.new(0, 0, 0);
                v.part.Transparency = 1;
            end;
        end;
    end);
    task.delay(47.5, function() -- Line: 122
        -- upvalues: u4 (copy), u7 (copy), TweenService (ref), u8 (copy)
        if not u4.Parent then
            return;
        end;

        local TweenInfo_new_ret2 = TweenInfo.new(1.2, Enum.EasingStyle.Quad, Enum.EasingDirection.Out);

        for _, v in ipairs(u7) do
            local part = v.part;

            if part.Parent then
                part.Anchored = true;
                part.CFrame = v.cf;
                part.CanCollide = v.canCollide;
                TweenService:Create(part, TweenInfo_new_ret2, {
                    Transparency = v.transparency
                }):Play();
            end;
        end;

        task.delay(1.2, function() -- Line: 138
            -- upvalues: u8 (ref), u7 (ref), u4 (ref)
            for _, v in ipairs(u8) do
                if v.joint.Parent then
                    v.joint.Enabled = v.enabled;
                end;
            end;

            for _, v in ipairs(u7) do
                if v.part.Parent then
                    v.part.Anchored = v.anchored;
                end;
            end;

            if u4.Parent then
                u4:SetAttribute("Collapsing", nil);
            end;
        end);
    end);
end;

return u2;