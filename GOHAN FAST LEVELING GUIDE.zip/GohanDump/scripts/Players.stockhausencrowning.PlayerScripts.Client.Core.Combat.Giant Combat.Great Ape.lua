-- Decompiled with Potassium's decompiler.

local ReplicatedStorage = game:GetService("ReplicatedStorage");
local Players = game:GetService("Players");
local Modules = ReplicatedStorage:WaitForChild("Modules");
ReplicatedStorage:WaitForChild("Remotes");
local Metadata = Modules.Metadata;
local Shared = Modules.Shared;
local Utility = Modules.Utility;
local HitboxHandler = require(Utility.HitboxHandler);
local FindCharacters = require(Shared.FindCharacters);
local ControlData = require(Metadata.ControlData.ControlData);
local CombatPresets = require(Metadata.CombatData.CombatPresets);
local GlobalFunctions = require(Modules.GlobalFunctions);
local AnimationManager = require(Shared.AnimationManager);
local UtilityHandler = require(Utility.UtilityHandler);
local CombatClassSpeed = require(Metadata.CombatClassData.CombatClassSpeed);
local StateManager = require(ReplicatedStorage.Modules.Metadata.ControlData.StateManager);
local v1 = script:FindFirstAncestor("Core");
local CombatVFX = require(v1:FindFirstChild("CombatVFX", true));
local ServerRemote = ReplicatedStorage.Remotes.ServerRemote;
local StatRetrieveRemote = ReplicatedStorage.Remotes.StatRetrieveRemote;
local _ = workspace.World.Visuals;
local LocalPlayer = Players.LocalPlayer;
local PlayerStats = LocalPlayer:WaitForChild("PlayerStats");
local SpeedMultiplier = PlayerStats:FindFirstChild("SpeedMultiplier", true);
local Hitbox = PlayerStats:FindFirstChild("Hitbox", true);
local AgilityBoost = PlayerStats:FindFirstChild("Boosters", true):FindFirstChild("AgilityBoost");
local u2 = UtilityHandler:DeepCopy(CombatPresets);
local u3 = UtilityHandler:DeepCopy(ControlData.Controls.Run);
local u4 = UtilityHandler:DeepCopy(ControlData.Controls.Dash);
local u5 = UtilityHandler:DeepCopy(ControlData.Controls["Great Ape"].Beam_Controls);
local u6 = UtilityHandler:DeepCopy(ControlData.Controls["Great Ape"].Grab_Controls);
local u7 = UtilityHandler:DeepCopy(ControlData.Controls["Great Ape"].Push_Controls);
local u8 = {
    BaseAgility = 1,
    EnhancedAgility = 0
};

local function fetchAgility() -- Line: 142
    -- upvalues: StatRetrieveRemote (copy), u8 (copy)
    local success, result = pcall(function() -- Line: 143
        -- upvalues: StatRetrieveRemote (ref)
        return StatRetrieveRemote:InvokeServer("Agility", "Core");
    end);

    if success and type(result) == "table" then
        return result;
    end;

    return u8;
end;

local success, result = pcall(function() -- Line: 143
    -- upvalues: StatRetrieveRemote (copy)
    return StatRetrieveRemote:InvokeServer("Agility", "Core");
end);

if not success or type(result) ~= "table" then
    result = u8;
end;

local function overallAgilityValue(p9) -- Line: 154
    -- upvalues: result (ref), AgilityBoost (copy), SpeedMultiplier (copy)
    return ((tonumber(result.BaseAgility) or 1) + (tonumber(result.EnhancedAgility) or 0) + (AgilityBoost and AgilityBoost.Value or 0) / (p9 or 1)) * (SpeedMultiplier and SpeedMultiplier.Value or 1);
end;

local u10 = {};
local u11 = 0;
local u12 = 0;
local u13 = {
    light = true,
    heavy = true
};

local function disableJump(u14, p15) -- Line: 185
    -- upvalues: u10 (copy)
    if not (u14 and u14.Parent) then
        return;
    end;

    if u14:GetStateEnabled(Enum.HumanoidStateType.Jumping) then
        u14:SetStateEnabled(Enum.HumanoidStateType.Jumping, false);
    end;

    local os_clock_ret = os.clock();
    u10[u14] = os_clock_ret;
    task.delay(p15, function() -- Line: 192
        -- upvalues: u10 (ref), u14 (copy), os_clock_ret (copy)
        if u10[u14] == os_clock_ret then
            u14:SetStateEnabled(Enum.HumanoidStateType.Jumping, true);
            u10[u14] = nil;
        end;
    end);
end;

local function calculateAnimationSpeed(p16) -- Line: 200
    return math.clamp(0.7 + p16 / 1000, 0.7, 1.8);
end;

local function calculatePunchWait(p17) -- Line: 205
    -- upvalues: CombatClassSpeed (copy), u2 (ref)
    local math_clamp_ret = math.clamp(p17 / 3000, 0, 0.04);

    return math.clamp((CombatClassSpeed["Great Ape"] and CombatClassSpeed["Great Ape"]["Punch Wait"] or u2.Punch_Wait) - math_clamp_ret, 0.1, 2);
end;

local function resetCombo(u18, p19, p20, p21) -- Line: 222
    -- upvalues: LocalPlayer (copy), u2 (ref), u13 (copy), StateManager (copy), u3 (ref)
    local Character = LocalPlayer.Character;

    if not Character then
        return;
    end;

    local v22 = p19 or u2.Punch_Wait;
    local ApeCooldown = u2.ApeCooldown;

    if u2.Combo2 > 0 then
        ApeCooldown = p20 and ApeCooldown and ApeCooldown or ApeCooldown * 1.5;
    end;

    if u2.Combo >= (u2.ApeMaxCombo or 2) and true or u2.Combo2 > 0 then
        u13.light = false;
        u13.heavy = false;
        task.wait(ApeCooldown);
        u2.Combo = 0;
        u2.Combo2 = 0;
        u13.light = true;
        u13.heavy = true;
    else
        task.wait(v22);
        u13.light = true;
    end;

    if p21 and Character.Parent then
        StateManager.ClearState(Character, p21);
    end;

    u3.Can_Run = true;
    task.spawn(function() -- Line: 255
        -- upvalues: u18 (copy), u2 (ref)
        local v23 = tick();
        local v24 = u18;

        while tick() - v23 < u2.TimeToAttack do
            if u2.Combo ~= v24 or u2.Combo == 0 then
                return;
            end;

            task.wait();
        end;

        u2.Combo = 0;
    end);
end;

local function resetControlsOnRespawn() -- Line: 266
    -- upvalues: u2 (ref), UtilityHandler (copy), CombatPresets (copy), u3 (ref), ControlData (copy), u4 (ref), u5 (ref), u6 (ref), u7 (ref), u12 (ref), u13 (copy), result (ref), StatRetrieveRemote (copy), u8 (copy)
    u2 = UtilityHandler:DeepCopy(CombatPresets);
    u3 = UtilityHandler:DeepCopy(ControlData.Controls.Run);
    u4 = UtilityHandler:DeepCopy(ControlData.Controls.Dash);
    u5 = UtilityHandler:DeepCopy(ControlData.Controls["Great Ape"].Beam_Controls);
    u6 = UtilityHandler:DeepCopy(ControlData.Controls["Great Ape"].Grab_Controls);
    u7 = UtilityHandler:DeepCopy(ControlData.Controls["Great Ape"].Push_Controls);
    u12 = 0;
    u13.light = true;
    u13.heavy = true;
    task.spawn(function() -- Line: 281
        -- upvalues: result (ref), StatRetrieveRemote (ref), u8 (ref)
        local success2, result2 = pcall(function() -- Line: 143
            -- upvalues: StatRetrieveRemote (ref)
            return StatRetrieveRemote:InvokeServer("Agility", "Core");
        end);

        if not success2 or type(result2) ~= "table" then
            result2 = u8;
        end;

        result = result2;
    end);
end;

local function guaranteedReset(p25, u26, u27, u28, p29, u30, u31) -- Line: 296
    -- upvalues: u12 (ref), resetCombo (copy)
    local u32 = false;

    local function release() -- Line: 302
        -- upvalues: u12 (ref), u31 (copy)
        if u12 == u31 then
            u12 = 0;
        end;
    end;

    local function fire() -- Line: 305
        -- upvalues: u32 (ref), u12 (ref), u31 (copy), resetCombo (ref), u26 (copy), u27 (copy), u28 (copy), u30 (copy)
        if u32 then
            return;
        end;

        u32 = true;

        if u12 == u31 then
            u12 = 0;
        end;

        resetCombo(u26, u27, u28, u30);
    end;

    local function claim() -- Line: 311
        -- upvalues: u32 (ref), u12 (ref), u31 (copy)
        u32 = true;

        if u12 == u31 then
            u12 = 0;
        end;
    end;

    if p25 then
        p25.Stopped:Once(fire);
    end;

    task.delay(p29 or 2, fire);

    return fire, claim;
end;

local v68 = {
    Run = {
        Execute = function(p33, p34) -- Line: 329
            -- upvalues: u3 (ref), ServerRemote (copy)
            if not u3.Can_Run then
                return;
            end;

            if u3.Enabled ~= false then
                ServerRemote:FireServer(p33, {
                    Action = "Execute"
                });

                return;
            end;

            u3.Enabled = true;
            task.wait(u3.Tap_Time);
            u3.Enabled = false;
        end,

        Terminate = function(p35, p36) -- Line: 339
            -- upvalues: ServerRemote (copy)
            ServerRemote:FireServer(p35, {
                Action = "Terminate"
            });
        end
    },

    Light = function(u37, p38) -- Line: 344
        -- upvalues: LocalPlayer (copy), StateManager (copy), u13 (copy), u12 (ref), GlobalFunctions (copy), u2 (ref), u11 (ref), u3 (ref), ServerRemote (copy), result (ref), AgilityBoost (copy), SpeedMultiplier (copy), CombatClassSpeed (copy), AnimationManager (copy), Hitbox (copy), HitboxHandler (copy), FindCharacters (copy), CombatVFX (copy), guaranteedReset (copy), disableJump (copy)
        local u39 = LocalPlayer.Character or LocalPlayer.CharacterAdded:Wait();

        if not StateManager.CanPerformAction(u39, "Light") then
            return;
        end;

        if not u13.light then
            return;
        end;

        if u12 ~= 0 then
            return;
        end;

        local _, v40 = GlobalFunctions.GetRootAndHumanoid(u39);
        local v41 = u2.ApeMaxCombo or 2;
        u13.light = false;
        u11 = u11 + 1;
        local v42 = u11;
        u12 = v42;
        u3.Can_Run = false;
        u2.Combo = math.min(u2.Combo + 1, v41);
        StateManager.SetState(u39, "LightAttacking");
        ServerRemote:FireServer("Run", {
            Action = "Terminate"
        });
        local v43 = ((tonumber(result.BaseAgility) or 1) + (tonumber(result.EnhancedAgility) or 0) + (AgilityBoost and AgilityBoost.Value or 0) / 1.5) * (SpeedMultiplier and SpeedMultiplier.Value or 1);
        local math_clamp_ret = math.clamp(0.7 + v43 / 1000, 0.7, 1.8);
        local math_clamp_ret2 = math.clamp(v43 / 3000, 0, 0.04);
        local math_clamp_ret3 = math.clamp((CombatClassSpeed["Great Ape"] and CombatClassSpeed["Great Ape"]["Punch Wait"] or u2.Punch_Wait) - math_clamp_ret2, 0.1, 2);
        local v44 = AnimationManager.PlayAnimation(u39, "Great Ape" .. " Atk " .. u2.Combo, {
            AdjustSpeed = math_clamp_ret
        });

        if not v44 then
            u12 = 0;
            u13.light = true;
            u2.Combo = math.max(u2.Combo - 1, 0);
            StateManager.ClearState(u39, "LightAttacking");
            u3.Can_Run = true;

            return;
        end;

        local function hitPeople(p45) -- Line: 399
            -- upvalues: u39 (copy), Hitbox (ref), HitboxHandler (ref), FindCharacters (ref), CombatVFX (ref), ServerRemote (ref), u37 (copy), u2 (ref)
            local HumanoidRootPart = u39:FindFirstChild("HumanoidRootPart");

            if not HumanoidRootPart then
                return;
            end;

            local v46 = {
                Size = Vector3.new(8, 9, 8) * Hitbox.Value,
                Location = HumanoidRootPart.CFrame * CFrame.new(0, 0, -4 * Hitbox.Value)
            };
            local _, v47 = HitboxHandler.New(v46);
            local v48 = FindCharacters.Find(u39, v47);

            for _, v in pairs(v48) do
                CombatVFX.Light({
                    Character = u39,
                    Victim = v
                });
            end;

            ServerRemote:FireServer(u37, {
                GuardBreak = true,
                Combo = u2.Combo,
                Victims = v48,
                MaxCombo = u2.ApeMaxCombo,
                Uptilt = p45 or false,
                RegionHitbox = {
                    Location = v46.Location,
                    Size = v46.Size
                }
            });
        end;

        ServerRemote:FireServer("Swing", {
            SwingType = "LightSwing"
        });
        local u49 = guaranteedReset(v44, u2.Combo, math_clamp_ret3, false, nil, "LightAttacking", v42);
        local u50 = nil;
        local u51 = nil;

        local function dropMarkers() -- Line: 444
            -- upvalues: u50 (ref), u51 (ref)
            if u50 and u50.Connected then
                u50:Disconnect();
            end;

            if u51 and u51.Connected then
                u51:Disconnect();
            end;
        end;

        u50 = v44:GetMarkerReachedSignal("Punch"):Once(function(p52) -- Line: 449
            -- upvalues: hitPeople (copy), u50 (ref), u51 (ref), u49 (copy)
            hitPeople(p52 == "UpTilt");

            if u50 and u50.Connected then
                u50:Disconnect();
            end;

            if u51 and u51.Connected then
                u51:Disconnect();
            end;

            u49();
        end);
        u51 = v44:GetMarkerReachedSignal("Second Punch"):Once(function() -- Line: 454
            -- upvalues: hitPeople (copy)
            hitPeople(false);
        end);
        v44.Stopped:Once(dropMarkers);
        disableJump(v40, 0.75);
    end,

    Heavy = function(u53, p54) -- Line: 462
        -- upvalues: LocalPlayer (copy), StateManager (copy), u13 (copy), u12 (ref), u11 (ref), u2 (ref), ServerRemote (copy), result (ref), AgilityBoost (copy), SpeedMultiplier (copy), CombatClassSpeed (copy), AnimationManager (copy), guaranteedReset (copy), Hitbox (copy), HitboxHandler (copy), FindCharacters (copy), GlobalFunctions (copy), CombatVFX (copy), resetCombo (copy)
        local u55 = LocalPlayer.Character or LocalPlayer.CharacterAdded:Wait();

        if not StateManager.CanPerformAction(u55, "Heavy") then
            return;
        end;

        if not u13.heavy then
            return;
        end;

        if u12 ~= 0 then
            return;
        end;

        u55:FindFirstChild("Humanoid");
        local u56 = false;
        u13.heavy = false;
        u11 = u11 + 1;
        local v57 = u11;
        u12 = v57;
        local v58 = u2;
        v58.Combo2 = v58.Combo2 + 1;
        StateManager.SetState(u55, "HeavyAttacking");
        ServerRemote:FireServer("Run", {
            Action = "Terminate"
        });
        local v59 = ((tonumber(result.BaseAgility) or 1) + (tonumber(result.EnhancedAgility) or 0) + (AgilityBoost and AgilityBoost.Value or 0) / 1) * (SpeedMultiplier and SpeedMultiplier.Value or 1);
        local math_clamp_ret = math.clamp(0.7 + v59 / 700, 0.7, 1.8);
        local math_clamp_ret2 = math.clamp(v59 / 3000, 0, 0.04);
        local math_clamp_ret3 = math.clamp((CombatClassSpeed["Great Ape"] and CombatClassSpeed["Great Ape"]["Punch Wait"] or u2.Punch_Wait) - math_clamp_ret2, 0.1, 2);
        local v60 = AnimationManager.PlayAnimation(u55, "Great Ape Heavy", {
            AdjustSpeed = math_clamp_ret
        });

        if not v60 then
            u12 = 0;
            u13.heavy = true;
            u2.Combo2 = math.max(u2.Combo2 - 1, 0);
            StateManager.ClearState(u55, "HeavyAttacking");

            return;
        end;

        task.spawn(function() -- Line: 508
            -- upvalues: u56 (ref)
            local v61 = tick();

            while tick() - v61 < 1.25 and not u56 do
                task.wait();
            end;
        end);
        ServerRemote:FireServer("Swing", {
            SwingType = "HeavySwing"
        });
        local u62, u63 = guaranteedReset(v60, u2.Combo, math_clamp_ret3, false, 2.75, "HeavyAttacking", v57);
        local u64 = nil;
        v60.Stopped:Once(function() -- Line: 528, Name: dropHeavyMarker
            -- upvalues: u64 (ref)
            if u64 and u64.Connected then
                u64:Disconnect();
            end;
        end);
        u64 = v60:GetMarkerReachedSignal("Punch"):Once(function() -- Line: 533
            -- upvalues: u64 (ref), u55 (copy), u62 (copy), Hitbox (ref), HitboxHandler (ref), FindCharacters (ref), GlobalFunctions (ref), u56 (ref), CombatVFX (ref), ServerRemote (ref), u53 (copy), u2 (ref), u63 (copy), resetCombo (ref), math_clamp_ret3 (copy)
            if u64 and u64.Connected then
                u64:Disconnect();
            end;

            local HumanoidRootPart = u55:FindFirstChild("HumanoidRootPart");

            if not HumanoidRootPart then
                u62();

                return;
            end;

            local v65 = {
                Size = Vector3.new(8, 9, 8) * Hitbox.Value,
                Location = HumanoidRootPart.CFrame * CFrame.new(0, 0, -4 * Hitbox.Value)
            };
            local _, v66 = HitboxHandler.New(v65);
            local v67 = FindCharacters.Find(u55, v66);

            if GlobalFunctions.Count(v67) > 0 then
                u56 = true;
            end;

            for _, v in pairs(v67) do
                CombatVFX.Heavy({
                    Character = u55,
                    Victim = v
                });
            end;

            ServerRemote:FireServer(u53, {
                GuardBreak = true,
                Combo = u2.Combo,
                Victims = v67,
                RegionHitbox = {
                    Location = v65.Location,
                    Size = v65.Size
                }
            });
            u63();
            resetCombo(u2.Combo, math_clamp_ret3, u56, "HeavyAttacking");
        end);
    end
};

local function markCooldown(u69, p70, p71) -- Line: 583
    if not u69 then
        return;
    end;

    local u72 = "ApeCD_" .. p70;
    u69:SetAttribute(u72, workspace:GetServerTimeNow() + p71);
    task.delay(p71, function() -- Line: 587
        -- upvalues: u69 (copy), u72 (copy)
        if u69.Parent and (u69:GetAttribute(u72) or 0) <= workspace:GetServerTimeNow() then
            u69:SetAttribute(u72, nil);
        end;
    end);
end;

function v68.Beam(p73, p74) -- Line: 597
    -- upvalues: LocalPlayer (copy), StateManager (copy), u5 (ref), markCooldown (copy), ServerRemote (copy)
    local v75 = LocalPlayer.Character or LocalPlayer.CharacterAdded:Wait();

    if not StateManager.CanPerformAction(v75, "Beam") then
        return;
    end;

    if not u5.Enabled then
        return;
    end;

    u5.Enabled = false;
    markCooldown(v75, "Beam", u5.CD);
    task.delay(u5.CD, function() -- Line: 604
        -- upvalues: u5 (ref)
        u5.Enabled = true;
    end);
    ServerRemote:FireServer(nil, {
        Module = "Ape Combat",
        Action = "Beam"
    });
end;

function v68.Push(p76, p77) -- Line: 617
    -- upvalues: LocalPlayer (copy), StateManager (copy), u7 (ref), markCooldown (copy), ServerRemote (copy)
    local v78 = LocalPlayer.Character or LocalPlayer.CharacterAdded:Wait();

    if not StateManager.CanPerformAction(v78, "Push") then
        return;
    end;

    if not u7.Enabled then
        return;
    end;

    u7.Enabled = false;
    markCooldown(v78, "Push", u7.CD);
    task.delay(u7.CD, function() -- Line: 624
        -- upvalues: u7 (ref)
        u7.Enabled = true;
    end);
    ServerRemote:FireServer(nil, {
        Module = "Ape Combat",
        Action = "Push"
    });
end;

function v68.Grab(p79, p80) -- Line: 634
    -- upvalues: LocalPlayer (copy), StateManager (copy), u6 (ref), markCooldown (copy), ServerRemote (copy)
    local v81 = LocalPlayer.Character or LocalPlayer.CharacterAdded:Wait();

    if not StateManager.CanPerformAction(v81, "Grab") then
        return;
    end;

    if not u6.Enabled then
        return;
    end;

    u6.Enabled = false;
    markCooldown(v81, "Grab", u6.CD);
    task.delay(u6.CD, function() -- Line: 641
        -- upvalues: u6 (ref)
        u6.Enabled = true;
    end);
    ServerRemote:FireServer(nil, {
        Module = "Ape Combat",
        Action = "Grab"
    });
end;

LocalPlayer.CharacterAdded:Connect(function(p82) -- Line: 653
    -- upvalues: resetControlsOnRespawn (copy), StateManager (copy)
    resetControlsOnRespawn();
    StateManager.CleanupCharacter(p82);
end);

return v68;