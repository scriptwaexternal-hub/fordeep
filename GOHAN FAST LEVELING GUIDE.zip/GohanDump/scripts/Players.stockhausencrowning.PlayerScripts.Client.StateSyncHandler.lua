-- Decompiled with Potassium's decompiler.

local Players = game:GetService("Players");
local ReplicatedStorage = game:GetService("ReplicatedStorage");
local StateManager = require(ReplicatedStorage.Modules.Metadata.ControlData.StateManager);
local LocalPlayer = Players.LocalPlayer;
ReplicatedStorage.Remotes.StateSyncRemote.OnClientEvent:Connect(function(p1: string, p2: string) -- Line: 39
    -- upvalues: LocalPlayer (copy), StateManager (copy)
    local Character = LocalPlayer.Character;

    if not Character then
        return;
    end;

    if p1 == "Set" then
        StateManager.SyncState(Character, p2);

        return;
    end;

    if p1 == "Clear" then
        StateManager.UnsyncState(Character, p2);
    end;
end);
LocalPlayer.CharacterRemoving:Connect(function(p3) -- Line: 56
    -- upvalues: StateManager (copy)
    StateManager.CleanupCharacter(p3);
end);