-- Decompiled with Potassium's decompiler.

require(script.Parent.TypeDefinitions);
local TypeMarshaller = require(script.Parent.TypeMarshaller);
local u1 = {};
u1.__index = u1;
u1.__type = "ActiveCast";
local RunService = game:GetService("RunService");
local Table = require(script.Parent.Table);
local u2 = nil;

local function GetFastCastVisualizationContainer() -- Line: 61
    local FastCastVisualizationObjects = workspace.Terrain:FindFirstChild("FastCastVisualizationObjects");

    if FastCastVisualizationObjects ~= nil then
        return FastCastVisualizationObjects;
    end;

    local Folder = Instance.new("Folder");
    Folder.Name = "FastCastVisualizationObjects";
    Folder.Archivable = false;
    Folder.Parent = workspace.Terrain;

    return Folder;
end;

local function printDebug(p3: string) -- Line: 79
    -- upvalues: u2 (ref)
    local _ = u2.DebugLogging == true;
end;

function DbgVisualizeSegment(p4, p5: number)
    -- upvalues: u2 (ref)
    if u2.VisualizeCasts ~= true then
        return nil;
    end;

    local ConeHandleAdornment = Instance.new("ConeHandleAdornment");
    ConeHandleAdornment.Adornee = workspace.Terrain;
    ConeHandleAdornment.CFrame = p4;
    ConeHandleAdornment.Height = p5;
    ConeHandleAdornment.Color3 = Color3.new();
    ConeHandleAdornment.Radius = 0.25;
    ConeHandleAdornment.Transparency = 0.5;
    local FastCastVisualizationObjects = workspace.Terrain:FindFirstChild("FastCastVisualizationObjects");

    if FastCastVisualizationObjects == nil then
        FastCastVisualizationObjects = Instance.new("Folder");
        FastCastVisualizationObjects.Name = "FastCastVisualizationObjects";
        FastCastVisualizationObjects.Archivable = false;
        FastCastVisualizationObjects.Parent = workspace.Terrain;
    end;

    ConeHandleAdornment.Parent = FastCastVisualizationObjects;

    return ConeHandleAdornment;
end;

function DbgVisualizeHit(p6, p7: boolean)
    -- upvalues: u2 (ref)
    if u2.VisualizeCasts ~= true then
        return nil;
    end;

    local SphereHandleAdornment = Instance.new("SphereHandleAdornment");
    SphereHandleAdornment.Adornee = workspace.Terrain;
    SphereHandleAdornment.CFrame = p6;
    SphereHandleAdornment.Radius = 0.4;
    SphereHandleAdornment.Transparency = 0.25;
    SphereHandleAdornment.Color3 = p7 == false and Color3.new(0.2, 1, 0.5) or Color3.new(1, 0.2, 0.2);
    local FastCastVisualizationObjects = workspace.Terrain:FindFirstChild("FastCastVisualizationObjects");

    if FastCastVisualizationObjects == nil then
        FastCastVisualizationObjects = Instance.new("Folder");
        FastCastVisualizationObjects.Name = "FastCastVisualizationObjects";
        FastCastVisualizationObjects.Archivable = false;
        FastCastVisualizationObjects.Parent = workspace.Terrain;
    end;

    SphereHandleAdornment.Parent = FastCastVisualizationObjects;

    return SphereHandleAdornment;
end;

local function GetPositionAtTime(p8: number, p9: vector, p10: vector, p11: vector) -- Line: 120
    local Vector3_new_ret = Vector3.new(p11.X * p8 ^ 2 / 2, p11.Y * p8 ^ 2 / 2, p11.Z * p8 ^ 2 / 2);

    return p9 + p10 * p8 + Vector3_new_ret;
end;

local function GetVelocityAtTime(p12: number, p13: vector, p14: vector) -- Line: 126
    return p13 + p14 * p12;
end;

local function GetTrajectoryInfo(p15: any, p16: number) -- Line: 130
    assert(p15.StateInfo.UpdateConnection ~= nil, "This ActiveCast has been terminated. It can no longer be used.");
    local v17 = p15.StateInfo.Trajectories[p16];
    local v18 = v17.EndTime - v17.StartTime;
    local Origin = v17.Origin;
    local InitialVelocity = v17.InitialVelocity;
    local Acceleration = v17.Acceleration;
    local v19 = {};
    local Vector3_new_ret = Vector3.new(Acceleration.X * v18 ^ 2 / 2, Acceleration.Y * v18 ^ 2 / 2, Acceleration.Z * v18 ^ 2 / 2);
    v19[1], v19[2] = Origin + InitialVelocity * v18 + Vector3_new_ret, InitialVelocity + Acceleration * v18;

    return v19;
end;

local function GetLatestTrajectoryEndInfo(p20) -- Line: 143
    -- upvalues: GetTrajectoryInfo (copy)
    assert(p20.StateInfo.UpdateConnection ~= nil, "This ActiveCast has been terminated. It can no longer be used.");

    return GetTrajectoryInfo(p20, #p20.StateInfo.Trajectories);
end;

local function CloneCastParams(p21: userdata) -- Line: 148
    local RaycastParams_new_ret = RaycastParams.new();
    RaycastParams_new_ret.CollisionGroup = p21.CollisionGroup;
    RaycastParams_new_ret.FilterType = p21.FilterType;
    RaycastParams_new_ret.FilterDescendantsInstances = p21.FilterDescendantsInstances;
    RaycastParams_new_ret.IgnoreWater = p21.IgnoreWater;

    return RaycastParams_new_ret;
end;

local function SendRayHit(p22: any, p23, p24: vector, p25: userdata?) -- Line: 157
    p22.Caster.RayHit:Fire(p22, p23, p24, p25);
end;

local function SendRayPierced(p26: any, p27, p28: vector, p29: userdata?) -- Line: 162
    p26.Caster.RayPierced:Fire(p26, p27, p28, p29);
end;

local function SendLengthChanged(p30: any, p31: vector, p32: vector, p33: number, p34: vector, p35: userdata?) -- Line: 167
    p30.Caster.LengthChanged:Fire(p30, p31, p32, p33, p34, p35);
end;

local function SimulateCast(p36: any, p37: number, p38: boolean) -- Line: 173
    -- upvalues: Table (copy)
    assert(p36.StateInfo.UpdateConnection ~= nil, "This ActiveCast has been terminated. It can no longer be used.");
    local v39 = p36.StateInfo.Trajectories[#p36.StateInfo.Trajectories];
    local Origin = v39.Origin;
    local v40 = p36.StateInfo.TotalRuntime - v39.StartTime;
    local InitialVelocity = v39.InitialVelocity;
    local Acceleration = v39.Acceleration;
    local Vector3_new_ret = Vector3.new(Acceleration.X * v40 ^ 2 / 2, Acceleration.Y * v40 ^ 2 / 2, Acceleration.Z * v40 ^ 2 / 2);
    local v41 = Origin + InitialVelocity * v40 + Vector3_new_ret;
    local _ = InitialVelocity + Acceleration * v40;
    local v42 = p36.StateInfo.TotalRuntime - v39.StartTime;
    local StateInfo = p36.StateInfo;
    StateInfo.TotalRuntime = StateInfo.TotalRuntime + p37;
    local v43 = p36.StateInfo.TotalRuntime - v39.StartTime;
    local Vector3_new_ret2 = Vector3.new(Acceleration.X * v43 ^ 2 / 2, Acceleration.Y * v43 ^ 2 / 2, Acceleration.Z * v43 ^ 2 / 2);
    local v44 = Origin + InitialVelocity * v43 + Vector3_new_ret2;
    local v45 = InitialVelocity + Acceleration * v43;
    local v46 = (v44 - v41).Unit * v45.Magnitude * p37;
    local WorldRoot = p36.RayInfo.WorldRoot;
    local v47 = WorldRoot:Raycast(v41, v46, p36.RayInfo.Parameters);
    local Air = Enum.Material.Air;
    Vector3.new();
    local v48, v49;

    if v47 == nil then
        v48 = v44;
        v49 = nil;
    else
        v48 = v47.Position;
        v49 = v47.Instance;
        Air = v47.Material;
        local _ = v47.Normal;
    end;

    local Magnitude = (v48 - v41).Magnitude;
    p36.Caster.LengthChanged:Fire(p36, v41, v46.Unit, Magnitude, v45, p36.RayInfo.CosmeticBulletObject);
    local StateInfo2 = p36.StateInfo;
    StateInfo2.DistanceCovered = StateInfo2.DistanceCovered + Magnitude;
    local v50;

    if p37 > 0 then
        v50 = DbgVisualizeSegment(CFrame.new(v41, v41 + v46), Magnitude);
    else
        v50 = nil;
    end;

    if v49 and v49 ~= p36.RayInfo.CosmeticBulletObject then
        tick();

        if p36.RayInfo.CanPierceCallback ~= nil then
            if p38 == false and p36.StateInfo.IsActivelySimulatingPierce then
                p36:Terminate();
                error("ERROR: The latest call to CanPierceCallback took too long to complete! This cast is going to suffer desyncs which WILL cause unexpected behavior and errors. Please fix your performance problems, or remove statements that yield (e.g. wait() calls)");
            end;

            p36.StateInfo.IsActivelySimulatingPierce = true;
        end;

        if p36.RayInfo.CanPierceCallback == nil or p36.RayInfo.CanPierceCallback ~= nil and p36.RayInfo.CanPierceCallback(p36, v47, v45, p36.RayInfo.CosmeticBulletObject) == false then
            p36.StateInfo.IsActivelySimulatingPierce = false;

            if p36.StateInfo.HighFidelityBehavior == 2 and (v39.Acceleration ~= Vector3.new() and p36.StateInfo.HighFidelitySegmentSize ~= 0) then
                p36.StateInfo.CancelHighResCast = false;

                if p36.StateInfo.IsActivelyResimulating then
                    p36:Terminate();
                    error("Cascading cast lag encountered! The caster attempted to perform a high fidelity cast before the previous one completed, resulting in exponential cast lag. Consider increasing HighFidelitySegmentSize.");
                end;

                p36.StateInfo.IsActivelyResimulating = true;
                local math_floor_ret = math.floor(Magnitude / p36.StateInfo.HighFidelitySegmentSize);
                local _ = Magnitude / math_floor_ret;
                local v51 = p37 / math_floor_ret;

                for i = 1, math_floor_ret do
                    if p36.StateInfo.CancelHighResCast then
                        p36.StateInfo.CancelHighResCast = false;
                        break;
                    end;

                    local v52 = v42 + v51 * i;
                    local Vector3_new_ret3 = Vector3.new(Acceleration.X * v52 ^ 2 / 2, Acceleration.Y * v52 ^ 2 / 2, Acceleration.Z * v52 ^ 2 / 2);
                    local v53 = Origin + InitialVelocity * v52 + Vector3_new_ret3;
                    local v54 = InitialVelocity + Acceleration * (v42 + v51 * i);
                    local v55 = WorldRoot:Raycast(v53, v54 * p37, p36.RayInfo.Parameters);
                    local Magnitude2 = (v53 - (v53 + v54)).Magnitude;
                    local v56;

                    if v55 == nil then
                        local v57 = DbgVisualizeSegment(CFrame.new(v53, v53 + v54), Magnitude2);

                        if v57 == nil then
                            v56 = i;
                        else
                            v57.Color3 = Color3.new(0.286275, 0.329412, 0.247059);
                            v56 = i;
                        end;
                    else
                        local Magnitude3 = (v53 - v55.Position).Magnitude;
                        local v58 = DbgVisualizeSegment(CFrame.new(v53, v53 + v54), Magnitude3);

                        if v58 ~= nil then
                            v58.Color3 = Color3.new(0.286275, 0.329412, 0.247059);
                        end;

                        if p36.RayInfo.CanPierceCallback == nil or p36.RayInfo.CanPierceCallback ~= nil and p36.RayInfo.CanPierceCallback(p36, v55, v54, p36.RayInfo.CosmeticBulletObject) == false then
                            p36.StateInfo.IsActivelyResimulating = false;
                            p36.Caster.RayHit:Fire(p36, v55, v54, p36.RayInfo.CosmeticBulletObject);
                            p36:Terminate();
                            local v59 = DbgVisualizeHit(CFrame.new(v48), false);

                            if v59 ~= nil then
                                v59.Color3 = Color3.new(0.0588235, 0.87451, 1);
                            end;

                            return;
                        end;

                        p36.Caster.RayPierced:Fire(p36, v55, v54, p36.RayInfo.CosmeticBulletObject);
                        local v60 = DbgVisualizeHit(CFrame.new(v48), true);

                        if v60 ~= nil then
                            v60.Color3 = Color3.new(1, 0.113725, 0.588235);
                        end;

                        if v58 == nil then
                            v56 = i;
                        else
                            v58.Color3 = Color3.new(0.305882, 0.243137, 0.329412);
                            v56 = i;
                        end;
                    end;
                end;

                p36.StateInfo.IsActivelyResimulating = false;
            else
                if p36.StateInfo.HighFidelityBehavior == 1 or p36.StateInfo.HighFidelityBehavior == 3 then
                    p36.Caster.RayHit:Fire(p36, v47, v45, p36.RayInfo.CosmeticBulletObject);
                    p36:Terminate();
                    DbgVisualizeHit(CFrame.new(v48), false);

                    return;
                end;

                p36:Terminate();
                error("Invalid value " .. p36.StateInfo.HighFidelityBehavior .. " for HighFidelityBehavior.");
            end;
        else
            if v50 ~= nil then
                v50.Color3 = Color3.new(0.4, 0.05, 0.05);
            end;

            DbgVisualizeHit(CFrame.new(v48), true);
            local Parameters = p36.RayInfo.Parameters;
            local FilterDescendantsInstances = Parameters.FilterDescendantsInstances;
            local v61 = {};
            local v62 = false;
            local v63 = 0;

            while true do
                if v47.Instance:IsA("Terrain") then
                    if Air == Enum.Material.Water then
                        p36:Terminate();
                        error(
                            "Do not add Water as a piercable material. If you need to pierce water, set cast.RayInfo.Parameters.IgnoreWater = true instead",
                            0
                        );
                    end;

                    warn("WARNING: The pierce callback for this cast returned TRUE on Terrain! This can cause severely adverse effects.");
                end;

                if Parameters.FilterType == Enum.RaycastFilterType.Blacklist then
                    local FilterDescendantsInstances2 = Parameters.FilterDescendantsInstances;
                    Table.insert(FilterDescendantsInstances2, v47.Instance);
                    Table.insert(v61, v47.Instance);
                    Parameters.FilterDescendantsInstances = FilterDescendantsInstances2;
                else
                    local FilterDescendantsInstances2 = Parameters.FilterDescendantsInstances;
                    Table.removeObject(FilterDescendantsInstances2, v47.Instance);
                    Table.insert(v61, v47.Instance);
                    Parameters.FilterDescendantsInstances = FilterDescendantsInstances2;
                end;

                p36.Caster.RayPierced:Fire(p36, v47, v45, p36.RayInfo.CosmeticBulletObject);
                v47 = WorldRoot:Raycast(v41, v46, Parameters);

                if v47 == nil then
                    break;
                end;

                if v63 >= 100 then
                    warn("WARNING: Exceeded maximum pierce test budget for a single ray segment (attempted to test the same segment " .. 100 .. " times!)");
                    break;
                end;

                v63 = v63 + 1;

                if p36.RayInfo.CanPierceCallback(p36, v47, v45, p36.RayInfo.CosmeticBulletObject) == false then
                    v62 = true;
                    break;
                end;
            end;

            p36.RayInfo.Parameters.FilterDescendantsInstances = FilterDescendantsInstances;
            p36.StateInfo.IsActivelySimulatingPierce = false;

            if v62 then
                p36.Caster.RayHit:Fire(p36, v47, v45, p36.RayInfo.CosmeticBulletObject);
                p36:Terminate();
                DbgVisualizeHit(CFrame.new(v47.Position), false);

                return;
            end;
        end;
    end;

    if p36.StateInfo.DistanceCovered >= p36.RayInfo.MaxDistance then
        p36:Terminate();
        DbgVisualizeHit(CFrame.new(v44), false);
    end;
end;

function u1.new(p64: any, p65: vector, p66: vector, p67: any, p68: any) -- Line: 422
    -- upvalues: TypeMarshaller (copy), Table (copy), RunService (copy), u1 (copy), SimulateCast (copy)
    if TypeMarshaller(p67) == "number" then
        p67 = p66.Unit * p67;
    end;

    if p68.HighFidelitySegmentSize <= 0 then
        error("Cannot set FastCastBehavior.HighFidelitySegmentSize <= 0!", 0);
    end;

    local u69 = {
        Caster = p64,
        StateInfo = {
            UpdateConnection = nil,
            Paused = false,
            TotalRuntime = 0,
            DistanceCovered = 0,
            IsActivelySimulatingPierce = false,
            IsActivelyResimulating = false,
            CancelHighResCast = false,
            HighFidelitySegmentSize = p68.HighFidelitySegmentSize,
            HighFidelityBehavior = p68.HighFidelityBehavior,
            Trajectories = {
                {
                    StartTime = 0,
                    EndTime = -1,
                    Origin = p65,
                    InitialVelocity = p67,
                    Acceleration = p68.Acceleration
                }
            }
        },
        RayInfo = {
            Parameters = p68.RaycastParams,
            WorldRoot = workspace,
            MaxDistance = p68.MaxDistance or 1000,
            CosmeticBulletObject = p68.CosmeticBulletTemplate,
            CanPierceCallback = p68.CanPierceFunction
        },
        UserData = {}
    };

    if u69.StateInfo.HighFidelityBehavior == 2 then
        u69.StateInfo.HighFidelityBehavior = 3;
    end;

    if u69.RayInfo.Parameters == nil then
        u69.RayInfo.Parameters = RaycastParams.new();
    else
        local RayInfo = u69.RayInfo;
        local Parameters = u69.RayInfo.Parameters;
        local RaycastParams_new_ret = RaycastParams.new();
        RaycastParams_new_ret.CollisionGroup = Parameters.CollisionGroup;
        RaycastParams_new_ret.FilterType = Parameters.FilterType;
        RaycastParams_new_ret.FilterDescendantsInstances = Parameters.FilterDescendantsInstances;
        RaycastParams_new_ret.IgnoreWater = Parameters.IgnoreWater;
        RayInfo.Parameters = RaycastParams_new_ret;
    end;

    local v70 = false;

    if p68.CosmeticBulletProvider == nil then
        if u69.RayInfo.CosmeticBulletObject ~= nil then
            u69.RayInfo.CosmeticBulletObject = u69.RayInfo.CosmeticBulletObject:Clone();
            u69.RayInfo.CosmeticBulletObject.CFrame = CFrame.new(p65, p65 + p66);
            u69.RayInfo.CosmeticBulletObject.Parent = p68.CosmeticBulletContainer;
        end;
    elseif TypeMarshaller(p68.CosmeticBulletProvider) == "PartCache" then
        if u69.RayInfo.CosmeticBulletObject ~= nil then
            warn("Do not define FastCastBehavior.CosmeticBulletTemplate and FastCastBehavior.CosmeticBulletProvider at the same time! The provider will be used, and CosmeticBulletTemplate will be set to nil.");
            u69.RayInfo.CosmeticBulletObject = nil;
            p68.CosmeticBulletTemplate = nil;
        end;

        u69.RayInfo.CosmeticBulletObject = p68.CosmeticBulletProvider:GetPart();
        u69.RayInfo.CosmeticBulletObject.CFrame = CFrame.new(p65, p65 + p66);
        v70 = true;
    else
        warn("FastCastBehavior.CosmeticBulletProvider was not an instance of the PartCache module (an external/separate model)! Are you inputting an instance created via PartCache.new? If so, are you on the latest version of PartCache? Setting FastCastBehavior.CosmeticBulletProvider to nil.");
        p68.CosmeticBulletProvider = nil;
    end;

    local v71;

    if v70 then
        v71 = p68.CosmeticBulletProvider.CurrentCacheParent;
    else
        v71 = p68.CosmeticBulletContainer;
    end;

    if p68.AutoIgnoreContainer == true and v71 ~= nil then
        local FilterDescendantsInstances = u69.RayInfo.Parameters.FilterDescendantsInstances;

        if Table.find(FilterDescendantsInstances, v71) == nil then
            Table.insert(FilterDescendantsInstances, v71);
            u69.RayInfo.Parameters.FilterDescendantsInstances = FilterDescendantsInstances;
        end;
    end;

    local v72;

    if RunService:IsClient() then
        v72 = RunService.RenderStepped;
    else
        v72 = RunService.Heartbeat;
    end;

    setmetatable(u69, u1);
    u69.StateInfo.UpdateConnection = v72:Connect(function(p73) -- Line: 535
        -- upvalues: u69 (copy), SimulateCast (ref)
        if u69.StateInfo.Paused then
            return;
        end;

        local v74 = u69.StateInfo.Trajectories[#u69.StateInfo.Trajectories];

        if u69.StateInfo.HighFidelityBehavior == 3 and (v74.Acceleration ~= Vector3.new() and u69.StateInfo.HighFidelitySegmentSize > 0) then
            local v75 = tick();

            if u69.StateInfo.IsActivelyResimulating then
                u69:Terminate();
                error("Cascading cast lag encountered! The caster attempted to perform a high fidelity cast before the previous one completed, resulting in exponential cast lag. Consider increasing HighFidelitySegmentSize.");
            end;

            u69.StateInfo.IsActivelyResimulating = true;
            local Origin = v74.Origin;
            local v76 = u69.StateInfo.TotalRuntime - v74.StartTime;
            local InitialVelocity = v74.InitialVelocity;
            local Acceleration = v74.Acceleration;
            local Vector3_new_ret = Vector3.new(Acceleration.X * v76 ^ 2 / 2, Acceleration.Y * v76 ^ 2 / 2, Acceleration.Z * v76 ^ 2 / 2);
            local v77 = Origin + InitialVelocity * v76 + Vector3_new_ret;
            local _ = InitialVelocity + Acceleration * v76;
            local _ = u69.StateInfo.TotalRuntime - v74.StartTime;
            local StateInfo = u69.StateInfo;
            StateInfo.TotalRuntime = StateInfo.TotalRuntime + p73;
            local v78 = u69.StateInfo.TotalRuntime - v74.StartTime;
            local Vector3_new_ret2 = Vector3.new(Acceleration.X * v78 ^ 2 / 2, Acceleration.Y * v78 ^ 2 / 2, Acceleration.Z * v78 ^ 2 / 2);
            local v79 = Origin + InitialVelocity * v78 + Vector3_new_ret2;
            local v80 = u69.RayInfo.WorldRoot:Raycast(v77, (v79 - v77).Unit * (InitialVelocity + Acceleration * v78).Magnitude * p73, u69.RayInfo.Parameters);

            if v80 ~= nil then
                v79 = v80.Position;
            end;

            local Magnitude = (v79 - v77).Magnitude;
            local StateInfo2 = u69.StateInfo;
            StateInfo2.TotalRuntime = StateInfo2.TotalRuntime - p73;
            local math_floor_ret = math.floor(Magnitude / u69.StateInfo.HighFidelitySegmentSize);
            local v81 = math_floor_ret == 0 and 1 or math_floor_ret;
            local v82 = p73 / v81;

            for i = 1, v81 do
                if getmetatable(u69) == nil then
                    return;
                end;

                if u69.StateInfo.CancelHighResCast then
                    u69.StateInfo.CancelHighResCast = false;
                    break;
                end;

                SimulateCast(u69, v82, true);
                local _ = i;
            end;

            if getmetatable(u69) == nil then
                return;
            end;

            u69.StateInfo.IsActivelyResimulating = false;

            if tick() - v75 > 0.08 then
                warn("Extreme cast lag encountered! Consider increasing HighFidelitySegmentSize.");
            end;
        else
            SimulateCast(u69, p73, false);
        end;
    end);

    return u69;
end;

function u1.SetStaticFastCastReference(p83) -- Line: 619
    -- upvalues: u2 (ref)
    u2 = p83;
end;

local function ModifyTransformation(p84: any, p85: vector?, p86: vector?, p87: vector?) -- Line: 625
    -- upvalues: GetTrajectoryInfo (copy), Table (copy)
    local Trajectories = p84.StateInfo.Trajectories;
    local v88 = Trajectories[#Trajectories];

    if v88.StartTime == p84.StateInfo.TotalRuntime then
        if p85 == nil then
            p85 = v88.InitialVelocity;
        end;

        if p86 == nil then
            p86 = v88.Acceleration;
        end;

        if p87 == nil then
            p87 = v88.Origin;
        end;

        v88.Origin = p87;
        v88.InitialVelocity = p85;
        v88.Acceleration = p86;

        return;
    end;

    v88.EndTime = p84.StateInfo.TotalRuntime;
    assert(p84.StateInfo.UpdateConnection ~= nil, "This ActiveCast has been terminated. It can no longer be used.");
    local v89 = GetTrajectoryInfo(p84, #p84.StateInfo.Trajectories);
    local v90, v91 = unpack(v89);

    if p85 == nil then
        p85 = v91;
    end;

    if p86 == nil then
        p86 = v88.Acceleration;
    end;

    if p87 ~= nil then
        v90 = p87;
    end;

    Table.insert(p84.StateInfo.Trajectories, {
        EndTime = -1,
        StartTime = p84.StateInfo.TotalRuntime,
        Origin = v90,
        InitialVelocity = p85,
        Acceleration = p86
    });
    p84.StateInfo.CancelHighResCast = true;
end;

function u1.SetVelocity(p92: table, p93: vector) -- Line: 671
    -- upvalues: u1 (copy), ModifyTransformation (copy)
    local v94 = getmetatable(p92) == u1;
    assert(v94, ("Cannot statically invoke method \'%s\' - It is an instance method. Call it on an instance of this class created via %s"):format("SetVelocity", "ActiveCast.new(...)"));
    assert(p92.StateInfo.UpdateConnection ~= nil, "This ActiveCast has been terminated. It can no longer be used.");
    ModifyTransformation(p92, p93, nil, nil);
end;

function u1.SetAcceleration(p95: table, p96: vector) -- Line: 677
    -- upvalues: u1 (copy), ModifyTransformation (copy)
    local v97 = getmetatable(p95) == u1;
    assert(v97, ("Cannot statically invoke method \'%s\' - It is an instance method. Call it on an instance of this class created via %s"):format("SetAcceleration", "ActiveCast.new(...)"));
    assert(p95.StateInfo.UpdateConnection ~= nil, "This ActiveCast has been terminated. It can no longer be used.");
    ModifyTransformation(p95, nil, p96, nil);
end;

function u1.SetPosition(p98: table, p99: vector) -- Line: 683
    -- upvalues: u1 (copy), ModifyTransformation (copy)
    local v100 = getmetatable(p98) == u1;
    assert(v100, ("Cannot statically invoke method \'%s\' - It is an instance method. Call it on an instance of this class created via %s"):format("SetPosition", "ActiveCast.new(...)"));
    assert(p98.StateInfo.UpdateConnection ~= nil, "This ActiveCast has been terminated. It can no longer be used.");
    ModifyTransformation(p98, nil, nil, p99);
end;

function u1.GetVelocity(p101) -- Line: 689
    -- upvalues: u1 (copy)
    local v102 = getmetatable(p101) == u1;
    assert(v102, ("Cannot statically invoke method \'%s\' - It is an instance method. Call it on an instance of this class created via %s"):format("GetVelocity", "ActiveCast.new(...)"));
    assert(p101.StateInfo.UpdateConnection ~= nil, "This ActiveCast has been terminated. It can no longer be used.");
    local v103 = p101.StateInfo.Trajectories[#p101.StateInfo.Trajectories];

    return v103.InitialVelocity + v103.Acceleration * (p101.StateInfo.TotalRuntime - v103.StartTime);
end;

function u1.GetAcceleration(p104) -- Line: 696
    -- upvalues: u1 (copy)
    local v105 = getmetatable(p104) == u1;
    assert(v105, ("Cannot statically invoke method \'%s\' - It is an instance method. Call it on an instance of this class created via %s"):format("GetAcceleration", "ActiveCast.new(...)"));
    assert(p104.StateInfo.UpdateConnection ~= nil, "This ActiveCast has been terminated. It can no longer be used.");

    return p104.StateInfo.Trajectories[#p104.StateInfo.Trajectories].Acceleration;
end;

function u1.GetPosition(p106) -- Line: 703
    -- upvalues: u1 (copy)
    local v107 = getmetatable(p106) == u1;
    assert(v107, ("Cannot statically invoke method \'%s\' - It is an instance method. Call it on an instance of this class created via %s"):format("GetPosition", "ActiveCast.new(...)"));
    assert(p106.StateInfo.UpdateConnection ~= nil, "This ActiveCast has been terminated. It can no longer be used.");
    local v108 = p106.StateInfo.Trajectories[#p106.StateInfo.Trajectories];
    local v109 = p106.StateInfo.TotalRuntime - v108.StartTime;
    local Origin = v108.Origin;
    local InitialVelocity = v108.InitialVelocity;
    local Acceleration = v108.Acceleration;
    local Vector3_new_ret = Vector3.new(Acceleration.X * v109 ^ 2 / 2, Acceleration.Y * v109 ^ 2 / 2, Acceleration.Z * v109 ^ 2 / 2);

    return Origin + InitialVelocity * v109 + Vector3_new_ret;
end;

function u1.AddVelocity(p110: table, p111: vector) -- Line: 712
    -- upvalues: u1 (copy)
    local v112 = getmetatable(p110) == u1;
    assert(v112, ("Cannot statically invoke method \'%s\' - It is an instance method. Call it on an instance of this class created via %s"):format("AddVelocity", "ActiveCast.new(...)"));
    assert(p110.StateInfo.UpdateConnection ~= nil, "This ActiveCast has been terminated. It can no longer be used.");
    p110:SetVelocity(p110:GetVelocity() + p111);
end;

function u1.AddAcceleration(p113: table, p114: vector) -- Line: 718
    -- upvalues: u1 (copy)
    local v115 = getmetatable(p113) == u1;
    assert(v115, ("Cannot statically invoke method \'%s\' - It is an instance method. Call it on an instance of this class created via %s"):format("AddAcceleration", "ActiveCast.new(...)"));
    assert(p113.StateInfo.UpdateConnection ~= nil, "This ActiveCast has been terminated. It can no longer be used.");
    p113:SetAcceleration(p113:GetAcceleration() + p114);
end;

function u1.AddPosition(p116: table, p117: vector) -- Line: 724
    -- upvalues: u1 (copy)
    local v118 = getmetatable(p116) == u1;
    assert(v118, ("Cannot statically invoke method \'%s\' - It is an instance method. Call it on an instance of this class created via %s"):format("AddPosition", "ActiveCast.new(...)"));
    assert(p116.StateInfo.UpdateConnection ~= nil, "This ActiveCast has been terminated. It can no longer be used.");
    p116:SetPosition(p116:GetPosition() + p117);
end;

function u1.Pause(p119) -- Line: 732
    -- upvalues: u1 (copy)
    local v120 = getmetatable(p119) == u1;
    assert(v120, ("Cannot statically invoke method \'%s\' - It is an instance method. Call it on an instance of this class created via %s"):format("Pause", "ActiveCast.new(...)"));
    assert(p119.StateInfo.UpdateConnection ~= nil, "This ActiveCast has been terminated. It can no longer be used.");
    p119.StateInfo.Paused = true;
end;

function u1.Resume(p121) -- Line: 738
    -- upvalues: u1 (copy)
    local v122 = getmetatable(p121) == u1;
    assert(v122, ("Cannot statically invoke method \'%s\' - It is an instance method. Call it on an instance of this class created via %s"):format("Resume", "ActiveCast.new(...)"));
    assert(p121.StateInfo.UpdateConnection ~= nil, "This ActiveCast has been terminated. It can no longer be used.");
    p121.StateInfo.Paused = false;
end;

function u1.Terminate(p123) -- Line: 744
    -- upvalues: u1 (copy)
    local v124 = getmetatable(p123) == u1;
    assert(v124, ("Cannot statically invoke method \'%s\' - It is an instance method. Call it on an instance of this class created via %s"):format("Terminate", "ActiveCast.new(...)"));
    assert(p123.StateInfo.UpdateConnection ~= nil, "This ActiveCast has been terminated. It can no longer be used.");
    local Trajectories = p123.StateInfo.Trajectories;
    Trajectories[#Trajectories].EndTime = p123.StateInfo.TotalRuntime;
    p123.StateInfo.UpdateConnection:Disconnect();
    p123.Caster.CastTerminating:FireSync(p123);
    p123.StateInfo.UpdateConnection = nil;
    p123.Caster = nil;
    p123.StateInfo = nil;
    p123.RayInfo = nil;
    p123.UserData = nil;
    setmetatable(p123, nil);
end;

return u1;