-- Decompiled with Potassium's decompiler.

local Players = game:GetService("Players");
local Command = require(script.Parent.Parent.Parent.Shared.Process:WaitForChild("Command"));
local LocalPlayer = Players.LocalPlayer;

return function(p1, p2, p3) -- Line: 9
    -- upvalues: LocalPlayer (copy), Command (copy)
    local UserId = LocalPlayer.UserId;
    local v4 = {
        commands = {},
        message = p2,
        cursorPosition = p3,
        invalid = {}
    };
    local CommandPrefix = p1.getCommandPrefix(UserId);

    if p2 == CommandPrefix then
        v4.argPos = 2;
        v4.argIndex = 0;
        v4.rawArg = "";
        v4.query = "";
        v4.suggestionType = "History";

        return v4;
    end;

    local v5 = p1.Process.rawParse(p2, { CommandPrefix, unpack(p1.Data.settings.prefix) }, p1.Data.settings.splitKey or " ");

    if not v5 then
        local invalid = v4.invalid;
        local v6 = { "Invalid command string", 2, (string.sub(p2, 2)) };
        table.insert(invalid, v6);

        return v4;
    end;

    for _, v in v5 do
        local v7, v8 = unpack(v[1]);
        local string_lower_ret = string.lower(v8);
        local v9 = p1.Registry.commands[string_lower_ret];
        local v10;

        if v9 then
            v10 = v9.args[#v9.args];
        else
            v10 = v9;
        end;

        local v11 = v[#v];
        local v12 = v11[1] + #v11[2];

        if v10 then
            v10 = v10.type == "string" and true or v10.type == "strings";
        end;

        if p3 < v[1][1] or v12 < p3 then
            if not (v9 or v10) then
                v4.argIndex = 1;
                v4.argPos = v7;
                v4.rawArg = v8;
                v4.query = v8;
                local v13 = { `Invalid command: {v8}, did you mean "{p1.Registry.suggestCommandAlias(string_lower_ret)}"?`, v7, v8 };
                table.insert(v4.invalid, v13);

                return v4;
            end;

            if v9 then
                local v14 = Command.new(p1, string_lower_ret, v9, v, UserId, p2);
                table.insert(v4.commands, v14);

                if v9.LocalPlayerAuthorized then
                    v14:validate();
                    table.insert(v4.commands, v14);

                    if v14.invalidArg then
                        table.insert(v4.invalid, { v14.argMissing or v14.invalidMessage, v14.invalidPos, v14.invalidArg });

                        return v4;
                    end;
                else
                    local v15 = { `"{v8}" command restricted to {v9.RestrictedToRole.name}`, v7, v8 };
                    table.insert(v4.invalid, v15);
                end;
            end;
        else
            if p3 <= v7 + #v8 then
                v4.argIndex = 1;
                v4.argPos = v7;
                v4.rawArg = v8;
                v4.query = string.sub(v8, 1, p3 - v7);
                v4.suggestionType = p1.Registry.types.command;
                v4.suggestions = p1.Util.Suggest.query(v4.query, p1.Registry.types.command.suggestions(v4.query, UserId));
                local suggestions = v4.suggestions;
                v4.suggestions = table.create(#v4.suggestions);
                local v16 = v;
                local v17 = {};

                for _, v2 in suggestions do
                    local _, _, v18 = unpack(v2);

                    if v18 then
                        if v18.LocalPlayerAuthorized then
                            table.insert(v4.suggestions, v2);
                            v4.validSuggestion = true;
                        else
                            v2[4] = true;
                            table.insert(v17, v2);
                        end;
                    end;
                end;

                if #v17 > 0 then
                    table.move(v17, 1, #v17, #v4.suggestions + 1, v4.suggestions);
                end;

                v4.commandDefinition = v9 or v4.suggestions[1][3];

                if v9 then
                    if v9.LocalPlayerAuthorized then
                        local v19 = Command.new(p1, string_lower_ret, v9, v16, UserId, p2);
                        v19:validate();
                        table.insert(v4.commands, v19);

                        return v4;
                    end;

                    if #v4.suggestions == 0 or not string.find(string.lower(v4.suggestions[1][1]), string.lower(v4.query), 1, true) then
                        local v20 = { `"{v8}" command restricted to {v9.RestrictedToRole.name}`, v7, v8 };
                        table.insert(v4.invalid, v20);
                    end;
                end;

                return v4;
            end;

            if not v9 then
                local v21 = { `Invalid command: {v8}, did you mean "{p1.Registry.suggestCommandAlias(string_lower_ret)}"?`, v7, v8 };
                table.insert(v4.invalid, v21);

                return v4;
            end;

            if not v9.LocalPlayerAuthorized then
                local v22 = { `"{v8}" command restricted to {v9.RestrictedToRole.name}`, v7, v8 };
                table.insert(v4.invalid, v22);

                return v4;
            end;

            v4.commandDefinition = v9;
            local v23 = Command.new(p1, string_lower_ret, v9, v, UserId, p2);
            local v24, v25 = v23:validate();
            table.insert(v4.commands, v23);

            for i, v2 in v23.args do
                local v26;

                if v10 then
                    v26 = i == #v9.args;
                else
                    v26 = v10;
                end;

                if p3 >= v2.argPos and (v26 or v2.argPos + #v2.rawArg >= p3) then
                    v4.arg = v2;
                    v4.argIndex = i + 1;
                    v4.argPos = v2.argPos;
                    v4.rawArg = v2.rawArg;
                    v4.rawQuery = string.sub(v2.rawArg, 1, p3 - v2.argPos);
                    v4.query = p1.Util.String.stripQuotes(v4.rawQuery);
                    v4.argDefinition = v2.definition;
                    v4.suggestionType = v2.rawType;

                    if v2.skipped and (v2.argPos <= p3 and (v26 or p3 < v2.argPos + #v2.rawArg)) then
                        v4.skipped = true;
                        v4.rawQuery = string.sub(v2.skipped, 1, p3 - v2.argPos);
                        v4.query = p1.Util.String.stripQuotes(v4.rawQuery);
                        local suggestions = v2.rawType.suggestions;
                        local v27;

                        if type(suggestions) == "function" then
                            suggestions, v27 = v2.rawType.suggestions(v4.query, UserId, v2.definition);
                        else
                            v27 = nil;
                        end;

                        if suggestions then
                            suggestions = p1.Util.Suggest.query(v4.query, suggestions, v27);
                        end;

                        v4.suggestions = suggestions;

                        if v4.suggestions and #v4.suggestions > 0 then
                            break;
                        end;
                    end;

                    local argPos = v2.argPos;
                    local v28 = v2;

                    for i2, v3 in v2.rawArgs do
                        local v29 = v28.transformedArgs[i2];
                        local v30 = v28.transformedTypes[i2];
                        local v31 = argPos + (#v3 + 1);

                        if p3 < argPos or not v26 and v31 < p3 then
                            argPos = v31;
                        else
                            local v32;

                            if v28.prefix then
                                v32 = argPos + #v28.prefix;
                            else
                                v32 = argPos;
                            end;

                            v4.argPos = v32;
                            v4.rawArg = v3;
                            v4.rawQuery = string.sub(v3, 1, p3 - argPos);
                            v4.query = p1.Util.String.stripQuotes(v4.rawQuery);
                            v4.transformedArg = v29;
                            v4.suggestionType = v30 or v4.suggestionType;
                            local v33;

                            if v30 then
                                v33 = v30.suggestions;
                            else
                                v33 = v30;
                            end;

                            local v34;

                            if type(v33) == "function" then
                                v33, v34 = v30.suggestions(v4.query, UserId, v28.definition);
                            else
                                v34 = nil;
                            end;

                            if v33 then
                                v33 = p1.Util.Suggest.query(v4.query, v33, v34);
                            end;

                            v4.suggestions = v33;
                            argPos = v31;
                        end;
                    end;
                end;
            end;

            if not v24 then
                local v35, v36;

                if not v4.suggestionType then
                    v23.Error = v25;

                    if v23.invalidArg then
                        if not v23.argMissing then
                            table.insert(v4.invalid, { v25, v23.invalidPos, v23.invalidArg });

                            return v4;
                        end;
                    else
                        v35 = v4.invalid;
                        v36 = { v25, v7, (string.sub(p2, v7, v12)) };
                        table.insert(v35, v36);
                    end;

                    return v4;
                end;

                if v4.rawArg ~= "" then
                    if not v4.suggestions or #v4.suggestions <= 1 then
                        v23.Error = v25;

                        if v23.invalidArg then
                            if not v23.argMissing then
                                table.insert(v4.invalid, { v25, v23.invalidPos, v23.invalidArg });

                                return v4;
                            end;
                        else
                            v35 = v4.invalid;
                            v36 = { v25, v7, (string.sub(p2, v7, v12)) };
                            table.insert(v35, v36);
                        end;

                        return v4;
                    end;

                    local v37;

                    if type(v4.suggestions[1]) == "table" then
                        v37 = v4.suggestions[1][1] ~= v4.rawArg;
                    else
                        v37 = v4.suggestions[1] ~= v4.rawArg;
                    end;

                    if not v37 then
                        v23.Error = v25;

                        if v23.invalidArg then
                            if not v23.argMissing then
                                table.insert(v4.invalid, { v25, v23.invalidPos, v23.invalidArg });

                                return v4;
                            end;
                        else
                            v35 = v4.invalid;
                            v36 = { v25, v7, (string.sub(p2, v7, v12)) };
                            table.insert(v35, v36);
                        end;

                        return v4;
                    end;
                end;
            end;
        end;
    end;

    return v4;
end;