-- Decompiled with Potassium's decompiler.

local u1 = 0;
local u3 = {
    reset = function(p2: number?) -- Line: 6, Name: reset
        -- upvalues: u1 (ref)
        u1 = tick() + 0.004166666666666667;
    end
};

function u3.wait(p4: number?) -- Line: 10
    -- upvalues: u1 (ref), u3 (copy)
    if u1 <= tick() then
        task.wait();
        u3.reset(p4);
    end;
end;

return u3;