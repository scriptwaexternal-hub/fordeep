-- Decompiled with Potassium's decompiler.

local Players = game:GetService("Players");
local ReplicatedStorage = game:GetService("ReplicatedStorage");
local RunService = game:GetService("RunService");
local TextChatService = game:GetService("TextChatService");
local Chat = game:GetService("Chat");
ReplicatedStorage:WaitForChild("Modules");
local RaceChatRemote = ReplicatedStorage:WaitForChild("Remotes"):WaitForChild("RaceChatRemote");
local u1 = {};

local function resolve(p2) -- Line: 38
    if not p2 then
        return nil, nil;
    end;

    local v3 = p2:IsA("Model") and p2 and p2 or p2:FindFirstAncestorOfClass("Model");

    if v3 then
        return v3, v3:FindFirstChild("Head") or (v3:FindFirstChild("HumanoidRootPart") or v3.PrimaryPart);
    end;

    return nil, nil;
end;

function u1.GetRaceOf(p4) -- Line: 50
    -- upvalues: RunService (copy), Players (copy)
    if not p4 then
        return "Default";
    end;

    local Attribute = p4:GetAttribute("ChatRace");

    if Attribute and Attribute ~= "" then
        return Attribute;
    end;

    local u5 = RunService:IsServer() and Players:GetPlayerFromCharacter(p4);

    if u5 then
        local success, result = pcall(function() -- Line: 57
            -- upvalues: u5 (copy)
            local Server = game:GetService("ServerScriptService"):WaitForChild("Server");

            return require(Server.ProfileService.PlayerData.DataManager).GetRace(u5);
        end);

        if success and (result and result ~= "") then
            return result;
        end;
    end;

    return "Default";
end;

local u6 = {};

function u1.PeekBubbleRace(p7) -- Line: 73
    -- upvalues: u6 (copy)
    if p7 then
        p7 = u6[p7];
    end;

    if p7 and os.clock() < p7.Expires then
        return p7.Race;
    end;

    return nil;
end;

local function display(p8, u9, u10, p11) -- Line: 82
    -- upvalues: u6 (copy), TextChatService (copy), Chat (copy)
    if not (u9 and u9.Parent) then
        return;
    end;

    u6[u9] = {
        Race = p11 or "Default",
        Expires = os.clock() + 2
    };

    if not pcall(function() -- Line: 85
        -- upvalues: TextChatService (ref), u9 (copy), u10 (copy)
        TextChatService:DisplayBubble(u9, u10);
    end) then
        pcall(function() -- Line: 91
            -- upvalues: Chat (ref), u9 (copy), u10 (copy)
            Chat:Chat(u9, u10);
        end);
    end;
end;

function u1.Say(p12, p13) -- Line: 96
    -- upvalues: resolve (copy), RunService (copy), u1 (copy), RaceChatRemote (copy), display (copy)
    if type(p13) ~= "string" or p13 == "" then
        return;
    end;

    local v14, v15 = resolve(p12);

    if not v14 then
        return;
    end;

    if RunService:IsServer() then
        RaceChatRemote:FireAllClients({
            Character = v14,
            Message = p13,
            Race = u1.GetRaceOf(v14)
        });

        return;
    end;

    display(v14, v15, p13, u1.GetRaceOf(v14));
end;

function u1.SayTo(p16, p17, p18) -- Line: 115
    -- upvalues: RunService (copy), resolve (copy), RaceChatRemote (copy), u1 (copy)
    if not RunService:IsServer() then
        return;
    end;

    if typeof(p16) ~= "Instance" or not p16:IsA("Player") then
        return;
    end;

    if type(p18) ~= "string" or p18 == "" then
        return;
    end;

    local v19 = resolve(p17);

    if not v19 then
        return;
    end;

    RaceChatRemote:FireClient(p16, {
        Character = v19,
        Message = p18,
        Race = u1.GetRaceOf(v19)
    });
end;

if not RunService:IsServer() then
    RaceChatRemote.OnClientEvent:Connect(function(p20) -- Line: 130
        -- upvalues: resolve (copy), display (copy)
        if type(p20) ~= "table" then
            return;
        end;

        local v21, v22 = resolve(p20.Character);

        if not v21 then
            return;
        end;

        display(v21, v22, tostring(p20.Message or ""), p20.Race);
    end);
end;

return u1;