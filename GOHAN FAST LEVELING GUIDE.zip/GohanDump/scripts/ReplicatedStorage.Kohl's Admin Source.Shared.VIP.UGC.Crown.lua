-- Decompiled with Potassium's decompiler.

local CollectionService = game:GetService("CollectionService");
local InsertService = game:GetService("InsertService");
local RunService = game:GetService("RunService");
local Parent = script.Parent.Parent.Parent.Parent;
local Flux = require(Parent:WaitForChild("Flux"));
local Util = require(Parent.Shared:WaitForChild("Util"));
local Oklab = Flux.Color.Oklab;
local Accessory = Instance.new("Accessory");
Accessory.AccessoryType = Enum.AccessoryType.Hat;
Accessory.Name = "SuperCrown";
Accessory.AttachmentPoint = CFrame.new(0, -1, 0);
Accessory:AddTag("_KSuperCrown");
task.spawn(function() -- Line: 18
    -- upvalues: Util (copy), InsertService (copy), Accessory (copy)
    local v1, v2 = Util.Retry(function() -- Line: 19
        -- upvalues: InsertService (ref)
        return InsertService:CreateMeshPartAsync("rbxassetid://18966762965", Enum.CollisionFidelity.Box, Enum.RenderFidelity.Automatic);
    end);

    if not v1 then
        warn(v2);

        return;
    end;

    v2.Parent = Accessory;
    v2.Name = "Handle";
    v2.Color = Color3.new(1, 1, 1);
    v2.CastShadow = false;
    v2.CanCollide = false;
    v2.CanQuery = false;
    v2.CanTouch = false;
    v2.Massless = true;
    v2.Locked = true;
    v2.Material = Enum.Material.Neon;
    local Attachment = Instance.new("Attachment", v2);
    Attachment.Name = "HatAttachment";
    Attachment.CFrame = CFrame.new(0, -1.5, 0);
    local Fire = Instance.new("Fire", v2);
    Fire.Color = Color3.new(0, 0, 0);
    Fire.SecondaryColor = Color3.new(0, 0, 0);
    Fire.Heat = 4;
    Fire.Size = 2;
end);

if RunService:IsClient() then
    local u3 = {};
    local u4 = {};
    RunService.Heartbeat:Connect(function() -- Line: 57
        -- upvalues: u3 (copy), Oklab (copy), u4 (copy)
        if next(u3) then
            local v5 = time();
            local v6 = v5 % 6.283185307179586;
            local v7 = CFrame.new(0, math.sin(v6) / 8, 0) * CFrame.Angles(0, v6, 0);

            for i in u3 do
                if i and (i.Parent and i:FindFirstChild("Handle")) then
                    if i.Handle:FindFirstChild("AccessoryWeld") then
                        i.Handle.AccessoryWeld.C1 = v7;
                    end;
                else
                    u3[i] = nil;
                end;
            end;

            local v8 = Oklab.toRGB(Oklab.fromHCL((Vector3.new(v5 / 10 % 1, 0.4, 1))));

            for i in u4 do
                if i and (i.Parent and i:FindFirstChild("Handle")) then
                    i.Handle.Color = v8;
                    local Fire = i.Handle:FindFirstChild("Fire");

                    if Fire then
                        Fire.SecondaryColor = v8;
                    end;
                else
                    u3[i] = nil;
                end;
            end;
        end;
    end);

    for i, v in {
        _KSuperCrown = u3,
        _KSuperCrownRainbow = u4
    } do
        CollectionService:GetInstanceAddedSignal(i):Connect(function(p9) -- Line: 87
            -- upvalues: v (copy)
            v[p9] = true;
        end);
        CollectionService:GetInstanceRemovedSignal(i):Connect(function(p10) -- Line: 90
            -- upvalues: v (copy)
            v[p10] = nil;
        end);
        local v11 = v;

        for _, v2 in CollectionService:GetTagged(i) do
            v11[v2] = true;
        end;
    end;
end;

local u12 = {
    dark = { Color3.new(), Color3.new(1, 1, 1) },
    gold = { Color3.fromRGB(170, 125, 0), Color3.new() }
};

return {
    MatchId = "rbxassetid://18966762965",
    Name = Accessory.Name,

    Method = function(p13: userdata, p14: userdata) -- Line: 107, Name: Method
        -- upvalues: u12 (copy), Accessory (copy)
        local v15 = nil;

        if p14 then
            if typeof(p14) == "Instance" then
                local Handle = p14:FindFirstChild("Handle");

                if Handle:IsA("MeshPart") then
                    if string.find(Handle.TextureID, "74391200400192") then
                        v15 = u12.dark;
                    elseif string.find(Handle.TextureID, "115319077247149") then
                        v15 = u12.gold;
                    end;
                end;

                p14:Destroy();
            elseif typeof(p14) == "string" then
                for i, v in u12 do
                    if string.find(string.lower(p14), i, 1, true) then
                        v15 = v;
                        break;
                    end;
                end;
            end;
        end;

        local v16 = p13:FindFirstChild(Accessory.Name);

        if v16 then
            v16:Destroy();
        end;

        local v17 = Accessory:Clone();

        if v17:FindFirstChild("Handle") then
            if v15 then
                local v18, v19 = unpack(v15);
                v17.Handle.Color = v18;
                v17.Handle.Fire.Color = v19;
                v17.Handle.Fire.SecondaryColor = v19;
            end;

            v17:SetAttribute("_KCrownColor", v17.Handle.Color);
            v17:SetAttribute("_KCrownFireColor", v17.Handle.Fire.Color);
        end;

        v17.Parent = p13;

        return v17;
    end
};