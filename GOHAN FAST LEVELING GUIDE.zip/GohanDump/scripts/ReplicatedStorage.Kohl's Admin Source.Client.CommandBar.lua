-- Decompiled with Potassium's decompiler.

local UserInputService = game:GetService("UserInputService");
local StarterGui = game:GetService("StarterGui");
local Parent = require(script.Parent.Parent);
local CompletionData = require(script:WaitForChild("CompletionData"));
local UI = require(script.Parent:WaitForChild("UI"));
local u1 = UI.state(nil);
local u3 = UI.compute(function() -- Line: 10
    -- upvalues: u1 (copy), UI (copy)
    local v2 = u1();

    if v2 == true then
        return UI.Theme.Valid();
    end;

    if v2 == false then
        return UI.Theme.Invalid();
    end;

    return UI.Theme.PrimaryText();
end);
local u4 = nil;
u4 = UI.new("Input")({
    AnchorPoint = Vector2.new(0, 0.5),
    ClearTextButton = true,
    Placeholder = "Search",
    BackgroundColor3 = UI.Theme.Primary,
    BackgroundTransparency = UI.Theme.Transparency,
    Fill = true,
    FontFace = UI.Theme.FontMono,
    FontSize = 20,
    Position = UDim2.fromScale(0, 0.5),
    Size = UDim2.new(1, 0, 1, 0),
    UI.new("TextButton")({
        AutoLocalize = false,
        Name = "CircleIndicator",
        BackgroundTransparency = 1,
        TextTransparency = 1,
        Size = UDim2.new(0, 20, 0, 20),
        UI.new("Frame")({
            BackgroundTransparency = 1,
            Size = UDim2.new(1, 0, 1, 0),
            SizeConstraint = Enum.SizeConstraint.RelativeYY,
            UI.new("UICorner")({
                CornerRadius = UDim.new(1, 0)
            }),
            UI.new("UIStroke")({
                Thickness = 2,
                Color = u3
            }),
            UI.new("ImageLabel")({
                Name = "Valid",
                BackgroundTransparency = 1,
                AnchorPoint = Vector2.new(0.55, 0.45),
                Position = UDim2.new(0.5, 0, 0.5, 0),
                Size = UDim2.fromScale(0.75, 0.75),
                ImageColor3 = UI.Theme.Valid,
                Image = UI.Theme.Image.Check_Bold,

                Visible = function() -- Line: 62, Name: Visible
                    -- upvalues: u1 (copy)
                    return u1() == true;
                end
            }),
            UI.new("ImageLabel")({
                Name = "Invalid",
                BackgroundTransparency = 1,
                AnchorPoint = Vector2.new(0.5, 0.5),
                Position = UDim2.new(0.5, 0, 0.5, 0),
                Size = UDim2.fromScale(0.5, 0.5),
                ImageColor3 = UI.Theme.Invalid,
                Image = UI.Theme.Image.Close_Bold,

                Visible = function() -- Line: 75, Name: Visible
                    -- upvalues: u1 (copy)
                    return u1() == false;
                end
            })
        }),

        Activated = function() -- Line: 81, Name: Activated
            -- upvalues: u4 (ref)
            u4._input:CaptureFocus();
            u4._input:ReleaseFocus(true);
        end
    })
});
UI.edit(u4._instance.ImageButton, {
    Size = UDim2.new(0, 16, 0, 16)
});
UI.edit(u4._instance.UICorner, {
    CornerRadius = UDim.new(1, 0)
});
UI.edit(u4._instance.UIListLayout, {
    Padding = UDim.new(0, 8)
});
UI.edit(u4._instance.UIPadding, {
    PaddingLeft = UDim.new(0, 14),
    PaddingRight = UDim.new(0, 12),
    PaddingTop = UDim.new(0, 0),
    PaddingBottom = UDim.new(0, 0)
});
UI.edit(u4._instance.InputFrame, {
    AutomaticSize = Enum.AutomaticSize.None
});
local u5 = UI.new("Frame")({
    Name = "CommandBar",
    AnchorPoint = Vector2.new(0.5, 0),
    Size = UDim2.new(1, 0, 1, 0),
    Position = UDim2.fromScale(0.5, 0),
    BackgroundTransparency = 1,
    ZIndex = 100,
    Visible = false,
    u4,
    UI.new("UIFlexItem")({
        FlexMode = Enum.UIFlexMode.Fill
    })
});
UI.edit(u4._instance.UIStroke, {
    Thickness = 2,
    Color = UI.Theme.Invalid,

    Enabled = function() -- Line: 125, Name: Enabled
        -- upvalues: u1 (copy)
        return u1() == false;
    end
});
local u6 = UI.new("Frame")({
    Parent = u5,
    Name = "Tooltip",
    Active = true,
    BackgroundColor3 = UI.Theme.Primary,
    BackgroundTransparency = UI.Theme.Transparency,
    Size = UDim2.fromOffset(256, 32),
    Visible = false,
    UI.new("UICorner")({
        CornerRadius = UI.Theme.CornerRadius
    }),
    UI.new("Stroke")({})
});
local u7 = UI.new("UIListLayout")({
    Parent = u6,
    SortOrder = Enum.SortOrder.LayoutOrder,
    Padding = UDim.new(0, 0)
});
local u8 = UI.new("TextLabel")({
    Parent = u6,
    LayoutOrder = -1,
    AutoLocalize = false,
    AutomaticSize = Enum.AutomaticSize.Y,
    Size = UDim2.new(1, 0, 0, 32),
    Name = "Tooltip",
    BackgroundTransparency = 1,
    TextWrapped = true,
    RichText = true,
    FontFace = UI.Theme.FontMono,
    TextSize = 20,
    TextColor3 = UI.Theme.PrimaryText,
    TextStrokeColor3 = UI.Theme.Primary,
    TextStrokeTransparency = UI.Theme.TextStrokeTransparency,
    TextXAlignment = Enum.TextXAlignment.Left,
    UI.new("UIPadding")({
        PaddingTop = UI.Theme.Padding,
        PaddingBottom = UI.Theme.Padding,
        PaddingLeft = UI.Theme.Padding,
        PaddingRight = UI.Theme.Padding
    })
});
u7:GetPropertyChangedSignal("AbsoluteContentSize"):Connect(function() -- Line: 176
    -- upvalues: u7 (copy), u6 (copy), UI (copy)
    u6.Size = UDim2.fromOffset(u6.AbsoluteSize.X, u7.AbsoluteContentSize.Y + UI.Theme.PaddingHalf._value.Offset);
end);
local u9 = UI.new("TextButton")({
    AutoLocalize = false,
    AutomaticSize = Enum.AutomaticSize.X,
    Name = "Suggestion",
    BackgroundTransparency = 0.9,
    BackgroundColor3 = UI.Theme.Secondary,

    Size = function() -- Line: 187, Name: Size
        -- upvalues: u8 (copy), UI (copy)
        return UDim2.new(1, 0, 0, u8.TextSize + UI.Theme.Padding().Offset);
    end,

    Text = "",
    TextTransparency = 1,
    UI.new("TextLabel")({
        LayoutOrder = 0,
        AutoLocalize = false,
        AutomaticSize = Enum.AutomaticSize.X,
        BackgroundTransparency = 1,
        Size = UDim2.new(0, 0, 1, 0),
        RichText = true,
        FontFace = UI.Theme.FontMono,
        TextSize = u8.TextSize,
        TextColor3 = UI.Theme.PrimaryText,
        TextStrokeColor3 = UI.Theme.Primary,
        TextStrokeTransparency = UI.Theme.TextStrokeTransparency,
        TextXAlignment = Enum.TextXAlignment.Left,
        UI.new("UIPadding")({
            PaddingTop = UI.Theme.PaddingHalf,
            PaddingBottom = UI.Theme.PaddingHalf,
            PaddingLeft = UI.Theme.Padding,
            PaddingRight = UI.Theme.Padding
        })
    })
});
local u10 = "<font color=\"#f00\">%s</font>";
local string_format_ret = string.format(u10, "<font transparency=\"0.5\">%s</font>%s<font transparency=\"0.5\">%s</font>");
local u11 = "<font transparency=\"0.33\">%s<b><font color=\"#f00\" transparency=\"0.66\">%s<font transparency=\"0\">%s</font>%s</font></b>%s</font>";
UI.Theme.Invalid:Connect(function(p12) -- Line: 226, Name: updateInvalidColor
    -- upvalues: u10 (ref), string_format_ret (ref), u11 (ref)
    local v13 = p12:ToHex();
    u10 = `<font color="#{v13}">%s</font>`;
    string_format_ret = string.format(u10, "<font transparency=\"0.5\">%s</font>%s<font transparency=\"0.5\">%s</font>");
    u11 = `<font transparency="0.33">%s<b><font color="#{v13}" transparency="0.66">%s<font transparency="0">%s</font>%s</font></b>%s</font>`;
end);
local v14 = UI.Theme.Invalid._value:ToHex();
u10 = `<font color="#{v14}">%s</font>`;
string_format_ret = string.format(u10, "<font transparency=\"0.5\">%s</font>%s<font transparency=\"0.5\">%s</font>");
u11 = `<font transparency="0.33">%s<b><font color="#{v14}" transparency="0.66">%s<font transparency="0">%s</font>%s</font></b>%s</font>`;
local u15 = 1;
local u16 = {};
local u17 = nil;
local u18 = nil;
local u19 = nil;

local function updateCompletionData() -- Line: 240
    -- upvalues: u4 (ref), u15 (ref), u19 (ref), CompletionData (copy), Parent (copy), u17 (ref)
    if u4._input.SelectionStart ~= -1 then
        return;
    end;

    u15 = 1;
    u19 = CompletionData(Parent, u4._input.Text, u4._input.CursorPosition);
    u17();
end;

local function fillSuggestion() -- Line: 249
    -- upvalues: u18 (ref), u4 (ref)
    local v20, v21 = unpack(u18);

    if not string.find(v21, " $") then
        v21 = v21 .. " ";
        v20 = v20 + 1;
    end;

    u18 = nil;
    u4.Value(v21, true);
    u4._input.CursorPosition = v20 + 1;
end;

local u24 = Parent.Util.Function.throttle(0.1, function() -- Line: 261
    -- upvalues: u18 (ref), u4 (ref), updateCompletionData (copy)
    if not u18 then
        return;
    end;

    local v22, v23 = unpack(u18);

    if not string.find(v23, " $") then
        v23 = v23 .. " ";
        v22 = v22 + 1;
    end;

    u18 = nil;
    u4.Value(v23, true);
    u4._input.CursorPosition = v22 + 1;
    task.defer(updateCompletionData);
end);

local function formatSuggestionLabel(p25, p26, p27, p28) -- Line: 270
    -- upvalues: string_format_ret (ref), Parent (copy), UI (copy)
    local string_find_ret, v29 = string.find(string.lower(p26), p27, 1, true);

    if not string_find_ret then
        string_find_ret = 0;
        v29 = 0;
    end;

    p25.Text = string.format(not p28 and "<font transparency=\"0.5\">%s</font>%s<font transparency=\"0.5\">%s</font>" or string_format_ret, string_find_ret <= 1 and "" or Parent.Util.String.escapeRichText((string.sub(p26, 1, string_find_ret - 1))), Parent.Util.String.escapeRichText((string.sub(p26, string_find_ret, v29))), Parent.Util.String.escapeRichText((string.sub(p26, v29 + 1))));
    local GetTextBoundsParams = Instance.new("GetTextBoundsParams");
    GetTextBoundsParams.Text = p26;
    GetTextBoundsParams.Font = p25.FontFace;
    GetTextBoundsParams.Size = p25.TextSize;
    GetTextBoundsParams.Width = (1 / 0);
    GetTextBoundsParams.RichText = true;

    return UI.retryGetTextBoundsAsync(GetTextBoundsParams).X + UI.Theme.PaddingDouble._value.Offset;
end;

local u30 = nil;

local function updateSuggestionLabels(p31) -- Line: 294
    -- upvalues: u30 (ref), Parent (copy), u15 (ref), u9 (copy), UI (copy), formatSuggestionLabel (copy), u6 (copy), u7 (copy), u4 (ref), u17 (ref), u24 (copy), u16 (copy)
    if u30 then
        return;
    end;

    u30 = true;
    local string_lower_ret = string.lower(Parent.Util.String.trim(p31.query));
    local math_min_ret = math.min(7, #p31.suggestions - 1);
    local math_max_ret = math.max(1, u15 - 7);
    local u32 = 256;

    for i = math_max_ret, math_max_ret + math_min_ret do
        local v33, v34, u35, u36 = unpack(p31.suggestions[i]);
        local v37 = u9:Clone();
        local u38 = v37:FindFirstChildOfClass("TextLabel");
        v37.LayoutOrder = i;
        v37.BackgroundTransparency = i == u15 and 0.9 or 0.95;
        local u39 = v34 or v33;
        local u40 = 0;
        local v41 = typeof(u35);

        if v41 == "Instance" and u35:IsA("Player") then
            UI.new("ImageLabel")({
                BackgroundTransparency = 1,
                Parent = v37,
                AnchorPoint = Vector2.new(1, 0),
                Position = UDim2.new(1, 0, 0, 0),
                Size = UDim2.new(1, 0, 1, 0),
                SizeConstraint = Enum.SizeConstraint.RelativeYY,
                Image = `rbxthumb://type=AvatarHeadShot&id={u35.UserId}&w=48&h=48`
            });
            u40 = u38.AbsoluteSize.Y;
        elseif v41 == "Color3" or v41 == "BrickColor" then
            local Frame = UI.new("Frame");
            local v42 = {
                Parent = v37
            };

            if v41 == "BrickColor" then
                u35 = u35.Color;
            end;

            v42.BackgroundColor3 = u35;
            v42.AnchorPoint = Vector2.new(1, 0);
            v42.Position = UDim2.new(1, 0, 0, 0);
            v42.Size = UDim2.new(1, 0, 1, 0);
            v42.SizeConstraint = Enum.SizeConstraint.RelativeYY;
            Frame(v42);
            u40 = u38.AbsoluteSize.Y;
        elseif v41 == "EnumItem" then
            if u35.EnumType == Enum.Font then
                v37.TextLabel.Font = u35;
            end;
        elseif v41 == "Font" then
            v37.TextLabel.FontFace = u35;
        elseif v41 == "table" then
            if u35.userId or u35.UserId then
                UI.new("ImageLabel")({
                    BackgroundTransparency = 1,
                    Parent = v37,
                    AnchorPoint = Vector2.new(1, 0),
                    Position = UDim2.new(1, 0, 0, 0),
                    Size = UDim2.new(1, 0, 1, 0),
                    SizeConstraint = Enum.SizeConstraint.RelativeYY,
                    Image = `rbxthumb://type=AvatarHeadShot&id={u35.userId or u35.UserId}&w=48&h=48`
                });
                u40 = u38.AbsoluteSize.Y;
                task.spawn(function() -- Line: 356
                    -- upvalues: u39 (ref), u35 (copy), Parent (ref), formatSuggestionLabel (ref), u38 (copy), string_lower_ret (copy), u36 (copy), u32 (ref), u40 (ref), u6 (ref), u7 (ref)
                    u39 = u39 .. ` ({u35.Name or Parent.Util.getUserInfo(u35.UserId).Username})`;
                    local v43 = formatSuggestionLabel(u38, u39, string_lower_ret, u36) + u40;
                    u32 = math.max(u32, v43);
                    u6.Size = UDim2.fromOffset(u32, u7.AbsoluteContentSize.Y);
                end);
            end;
        elseif p31.suggestionType.name == "image" or p31.suggestionType.name == "images" and p31.arg then
            UI.new("ImageLabel")({
                BackgroundTransparency = 1,
                Parent = v37,
                AnchorPoint = Vector2.new(1, 0),
                Position = UDim2.new(1, 0, 0, 0),
                Size = UDim2.new(1, 0, 1, 0),
                SizeConstraint = Enum.SizeConstraint.RelativeYY,
                Image = p31.arg.parsedArgs[1]
            });
            u40 = u38.AbsoluteSize.Y;
        end;

        local v44 = formatSuggestionLabel(u38, u39, string_lower_ret, u36) + u40;
        u32 = math.max(u32, v44);
        v37.Activated:Connect(function() -- Line: 380
            -- upvalues: u4 (ref), u15 (ref), i (copy), u17 (ref), u24 (ref)
            u4._input:CaptureFocus();
            u15 = i;
            u17();
            u24();
        end);
        v37.Parent = u6;
        table.insert(u16, v37);
        local _ = i;
    end;

    u6.Size = UDim2.fromOffset(u32, u7.AbsoluteContentSize.Y);
    u30 = false;
end;

local function clearCompletion() -- Line: 395
    -- upvalues: u6 (copy), u4 (ref), Parent (copy), u16 (copy)
    u6.Visible = false;
    u4.DisplayText(Parent.Util.String.escapeRichText(u4._input.Text));

    for _, v in u16 do
        v:Destroy();
    end;

    table.clear(u16);
end;

local u45 = {
    role = nil,
    gamepass = nil
};
local u46 = UI.new("Button")({
    Label = "Loading...",
    Icon = "rbxasset://textures/ui/common/robux.png",
    IconProperties = {
        ImageColor3 = UI.Theme.PrimaryText
    },
    IconRightAlign = true,
    TextXAlignment = Enum.TextXAlignment.Left,
    Size = UDim2.new(1, 0, 0, 32),
    UI.new("TextLabel")({
        Name = "Price",
        LayoutOrder = 8,
        AutoLocalize = false,
        BackgroundTransparency = 1,
        TextWrapped = true,
        Text = "<b>?</b>",
        RichText = true,
        AutomaticSize = Enum.AutomaticSize.XY,
        FontFace = UI.Theme.FontMono,
        TextSize = UI.Theme.FontSizeLarge,
        TextColor3 = UI.Theme.PrimaryText,
        TextStrokeColor3 = UI.Theme.Primary,
        TextStrokeTransparency = UI.Theme.TextStrokeTransparency,

        Size = function() -- Line: 428, Name: Size
            -- upvalues: UI (copy)
            return UDim2.new(0, UI.Theme.FontSizeLarge(), 0, 32);
        end
    }),

    Activated = function() -- Line: 435, Name: Activated
        -- upvalues: u45 (copy), Parent (copy)
        if u45.role == "vip" and Parent.Data.settings.vip then
            Parent.PromptPurchaseVIP();

            return;
        end;

        if u45.gamepass then
            Parent.Service.Marketplace:PromptGamePassPurchase(Parent.LocalPlayer, u45.gamepass);
        end;
    end
});

local function updateSuggestionPurchasePrice() -- Line: 444
    -- upvalues: u45 (copy), Parent (copy), u46 (copy)
    local success, result = pcall(function() -- Line: 445
        -- upvalues: u45 (ref), Parent (ref)
        local v47;

        if u45.role == "vip" and Parent.Data.settings.vip then
            v47 = Enum.InfoType.Asset;
        else
            v47 = Enum.InfoType.GamePass;
        end;

        return Parent.Service.Marketplace:GetProductInfoAsync(u45.gamepass, v47).PriceInRobux;
    end);
    u46._content.Price.Text = `<b>{success and result and result or "?"}</b>`;
end;

local function invalidSuggestion(p48, p49, p50, p51) -- Line: 454
    -- upvalues: u1 (copy), u4 (ref), string_format_ret (ref), Parent (copy), u8 (copy), u9 (copy), UI (copy), u6 (copy), u16 (copy), u7 (copy), u15 (ref)
    u1(false);
    u4.DisplayText(string.format(string_format_ret, Parent.Util.String.escapeRichText((string.sub(p48.message, 1, p50 - 1))), Parent.Util.String.escapeRichText(p51), Parent.Util.String.escapeRichText((string.sub(p48.message, p50 + #p51)))));
    u8.Visible = p48.argDefinition ~= nil;
    u8.Text = not p48.argDefinition and "" or string.format("<b><sc>%s</sc> <font transparency=\"0.66\"><i>&lt;%s&gt;</i></font></b>\n%s", Parent.Util.String.escapeRichText(p48.argDefinition.displayName or p48.argDefinition.name), Parent.Util.String.escapeRichText(p48.suggestionType.name) .. (p48.argDefinition.optional and "?" or ""), p48.argDefinition.description or "No description.");
    local v52 = u9:Clone();
    local v53 = v52:FindFirstChildOfClass("TextLabel");
    v53.Text = `<font color="#{UI.Theme.Invalid._value:ToHex()}"><b>{Parent.Util.String.escapeRichText(p49)}</b></font>`;
    v52.Parent = u6;
    table.insert(u16, v52);
    u6.Size = UDim2.fromOffset(math.max(u6.AbsoluteSize.X, v53.AbsoluteSize.X), u7.AbsoluteContentSize.Y);
    u6.Visible = true;

    if not (p48.suggestions and p48.suggestions[u15]) then
        return;
    end;

    local v54, _, v55 = unpack(p48.suggestions[u15]);

    if p48.argIndex == 1 then
        local v56 = v55.description or "No description.";
        local v57 = (type(v55) ~= "table" or type(v56) ~= "string") and "?" or v56;
        u8.Text = string.format("<b><sc>%s</sc> <font transparency=\"0.66\"><i>&lt;%s&gt;</i></font></b>\n%s", Parent.Util.String.escapeRichText(v54), "command", v57);
    end;
end;

local u58 = {};

u17 = function() -- Line: 504
    -- upvalues: u19 (ref), u18 (ref), u4 (ref), Parent (copy), u16 (copy), u6 (copy), u58 (copy), u1 (copy), invalidSuggestion (copy), u8 (copy), UI (copy), u15 (ref), u46 (copy), u10 (ref), u45 (copy), updateSuggestionPurchasePrice (copy), u11 (ref), updateSuggestionLabels (copy)
    local v59 = u19;
    u18 = nil;
    u4.DisplayText(Parent.Util.String.escapeRichText(u4._input.Text));

    for _, v in u16 do
        v:Destroy();
    end;

    table.clear(u16);

    if v59.suggestionType == "History" then
        u6.Visible = false;
        v59.suggestions = table.create(#u58);

        for _, v in u58 do
            table.insert(v59.suggestions, { v });
        end;
    end;

    u1(nil);

    for _, v in v59.invalid do
        invalidSuggestion(v59, unpack(v));
    end;

    if not v59.suggestionType or #v59.invalid > 0 then
        return;
    end;

    if #v59.commands > 0 then
        local v60 = true;

        for _, v in v59.commands do
            if not v.validated then
                v60 = false;
                break;
            end;
        end;

        if v60 then
            u1(true);
        end;
    end;

    if v59.argDefinition then
        u8.Text = string.format("<b><sc>%s</sc> <font transparency=\"0.66\"><i>&lt;%s&gt;</i></font></b>\n%s", Parent.Util.String.escapeRichText(v59.argDefinition.displayName or v59.argDefinition.name), Parent.Util.String.escapeRichText(v59.suggestionType.name) .. (v59.argDefinition.optional and "?" or ""), v59.argDefinition.description or "No description.");
        u8.Visible = true;
        u6.Visible = true;
    end;

    local GetTextBoundsParams = Instance.new("GetTextBoundsParams");
    local string_gsub_ret = string.gsub(string.gsub(v59.message, "\n", " "), "\r", " ");
    GetTextBoundsParams.Text = string.sub(string_gsub_ret, 1, v59.argPos - 1);
    GetTextBoundsParams.Font = u8.FontFace;
    GetTextBoundsParams.Size = u8.TextSize;
    GetTextBoundsParams.Width = (1 / 0);
    GetTextBoundsParams.RichText = true;
    local X = UI.retryGetTextBoundsAsync(GetTextBoundsParams).X;
    u6.Position = UDim2.new(0, math.floor(X) + u4._input.AbsolutePosition.X - u4._instance.AbsolutePosition.X - UI.Theme.Padding._value.Offset, 0.5, u4._instance.AbsoluteSize.Y / 2 + 6);

    if not v59.suggestions or #v59.suggestions <= 0 then
        return;
    end;

    local v61 = Parent.Util.String.trim(v59.rawArg);
    local v62 = v59.argPos + #v61;
    local v63, _, v64, v65 = unpack(v59.suggestions[u15]);
    u46._instance.Parent = nil;

    if v59.argIndex == 1 then
        u8.Text = string.format("<b><sc>%s</sc> <font transparency=\"0.66\"><i>&lt;%s&gt;</i></font></b>\n%s", Parent.Util.String.escapeRichText(v63), "command", v64.description);

        if v65 then
            local v66 = u8;
            v66.Text = v66.Text .. string.format(u10, (`\n<b>Restricted to {v64.RestrictedToRole.name}</b>`));

            for _, v in Parent.Data.rolesList do
                local _key = v._key;

                if (_key == "vip" and Parent.Data.settings.vip or v.gamepasses) and Parent.Auth.roleCanUseCommand(_key, v64) then
                    u45.role = _key;
                    u45.gamepass = _key == "vip" and Parent.Data.settings.vip and 110019084552349 or v.gamepasses[1];

                    if u45.gamepass then
                        u46._instance.Parent = u6;
                        u46.Label((`<b>Unlock <font color="{v.color}">{v.name or _key}</font> Commands</b>`));
                        task.spawn(updateSuggestionPurchasePrice);
                        break;
                    end;
                end;
            end;
        end;
    end;

    if not string.find(string.lower(v63), `{string.lower(Parent.Util.String.stripQuotes(v61))}`, 1, true) then
        v59.validSuggestion = false;
        v65 = true;
    end;

    if v65 and not v59.validSuggestion then
        u1(false);
    end;

    local string_sub_ret = string.sub(v59.message, 1, v59.argPos - 1);
    local string_sub_ret2 = string.sub(v59.message, v62);
    local string_match_ret = string.match(string_sub_ret, "([\"`])$");
    local v67;

    if string_match_ret and not string.match(string_sub_ret2, "^[\"`]") then
        v67 = v63 .. string_match_ret;
    elseif string_match_ret or (v59.suggestionType == "History" or not string.find(v63, (`[ {Parent.Util.String.escapePattern(Parent.getCommandPrefix())}]`))) then
        v67 = v63;
    else
        v67 = `"{v63}"`;
    end;

    u18 = { v59.argPos + #v67, string_sub_ret .. v67 .. string_sub_ret2, v65 };
    local string_lower_ret = string.lower(Parent.Util.String.trim(v59.query));
    local string_find_ret, v68 = string.find(string.lower(v63), string_lower_ret, 1, true);

    if not string_find_ret then
        v68 = #v63;
        string_find_ret = 1;
    end;

    if not v65 and (v59.commandDefinition and (v59.commandDefinition.args and not string.find(string_sub_ret2, "%S"))) then
        local v69 = {};

        for i = v59.argIndex, #v59.commandDefinition.args do
            local v70 = v59.commandDefinition.args[i];
            local v71 = `{v70.name}{v70.optional and "?" or ""}`;
            table.insert(v69, v71);
            local _ = i;
        end;

        if #v69 > 0 then
            v63 = `{v63} {table.concat(v69, " ")}`;
        end;
    end;

    u4.DisplayText(string.format(not v65 and "<font transparency=\"0.33\">%s<font transparency=\"0.66\">%s<font transparency=\"0\">%s</font>%s</font>%s</font>" or u11, Parent.Util.String.escapeRichText(string_sub_ret), string_find_ret <= 1 and "" or Parent.Util.String.escapeRichText((string.sub(v63, 1, string_find_ret - 1))), Parent.Util.String.escapeRichText(v59.rawQuery or v59.query), Parent.Util.String.escapeRichText((string.sub(v63, v68 + 1))), Parent.Util.String.escapeRichText(string_sub_ret2)), true);

    if v59.argDefinition or v59.argIndex == 1 then
        updateSuggestionLabels(v59);
        u8.Visible = true;
        u6.Visible = true;
    end;
end;

local u72 = {};
local u73 = nil;

local function coreGuiEnabled(p74: boolean) -- Line: 694
    -- upvalues: StarterGui (copy), u73 (ref), u72 (copy)
    if p74 then
        StarterGui:SetCore("ChatActive", u73);
        u73 = nil;

        for i, v in u72 do
            u72[i] = nil;
            StarterGui:SetCoreGuiEnabled(i, v);
        end;

        return;
    end;

    if u73 == nil then
        u73 = StarterGui:GetCore("ChatActive");
    end;

    StarterGui:SetCore("ChatActive", false);

    for _, v in Enum.CoreGuiType:GetEnumItems() do
        if (v == Enum.CoreGuiType.Chat or v == Enum.CoreGuiType.Health) and u72[v] == nil then
            local CoreGuiEnabled = StarterGui:GetCoreGuiEnabled(v);
            StarterGui:SetCoreGuiEnabled(v, false);

            if CoreGuiEnabled == true then
                u72[v] = CoreGuiEnabled;
            end;
        end;
    end;
end;

local function hideCommandBar() -- Line: 722
    -- upvalues: u5 (copy), Parent (copy), StarterGui (copy), u73 (ref), u72 (copy)
    if u5.Visible then
        u5.Visible = false;

        if Parent.client then
            if Parent.client.TopbarPlus then
                Parent.client.TopbarPlus.setTopbarEnabled(true);
            else
                Parent.client.dashboardButton.Visible = Parent.client.dashboardButtonEnabled;
            end;
        end;

        StarterGui:SetCore("ChatActive", u73);
        u73 = nil;

        for i, v in u72 do
            u72[i] = nil;
            StarterGui:SetCoreGuiEnabled(i, v);
        end;
    end;
end;

local function suggestionUp() -- Line: 736
    -- upvalues: u19 (ref), u15 (ref), u17 (ref)
    if u19.suggestionType == "History" then
        local math_max_ret = math.max(1, u19.suggestions and #u19.suggestions or 1);
        u15 = math.min(math_max_ret, u15 + 1);
    else
        u15 = math.max(1, u15 - 1);
    end;

    u17();
end;

local function suggestionDown() -- Line: 748
    -- upvalues: u19 (ref), u15 (ref), u17 (ref)
    if u19.suggestionType == "History" then
        u15 = math.max(1, u15 - 1);
    else
        local math_max_ret = math.max(1, u19.suggestions and #u19.suggestions or 1);
        u15 = math.min(math_max_ret, u15 + 1);
    end;

    u17();
end;

local u75 = nil;

return {
    Bar = u5,
    Input = u4,
    updateCompletionData = updateCompletionData,

    init = function(p76, u77) -- Line: 765, Name: init
        -- upvalues: u75 (ref), u4 (ref), u5 (copy), UI (copy), u1 (copy), u3 (copy), u6 (copy), suggestionUp (copy), suggestionDown (copy), UserInputService (copy), u19 (ref), u15 (ref), u17 (ref), Parent (copy), StarterGui (copy), u73 (ref), u72 (copy), updateCompletionData (copy), clearCompletion (copy), CompletionData (copy), u18 (ref), u58 (copy), u24 (copy)
        if u75 then
            return;
        end;

        u75 = true;
        u4.Value(u77.getCommandPrefix(), true);
        u5.Parent = UI.TopbarFrame;
        u77.client.hotkeys.commandBar = {
            key = UI.state(Enum.KeyCode.Semicolon),
            mods = UI.state({}),
            callback = p76.show
        };
        u77.client.CommandBarState = { u1, u3 };
        local CommandPrefix = u77.getCommandPrefix();

        local function updatePrefix() -- Line: 778
            -- upvalues: u77 (copy), u4 (ref), CommandPrefix (ref)
            local CommandPrefix2 = u77.getCommandPrefix();
            u4.Value(CommandPrefix2 .. string.sub(u4._input.Text, #CommandPrefix + 1), true);
            CommandPrefix = CommandPrefix2;
        end;

        u77.client.settings.prefix:Connect(updatePrefix);
        u77.client.playerPrefix:Connect(updatePrefix);
        u6.MouseWheelForward:Connect(suggestionUp);
        u6.MouseWheelBackward:Connect(suggestionDown);
        UserInputService.InputBegan:Connect(function(p78, p79) -- Line: 789
            -- upvalues: u4 (ref), u19 (ref), u15 (ref), u17 (ref), u5 (ref), Parent (ref), StarterGui (ref), u73 (ref), u72 (ref)
            if p78.UserInputType == Enum.UserInputType.Keyboard then
                if not u4._input:IsFocused() then
                    return;
                end;

                if p78.KeyCode == Enum.KeyCode.Up then
                    if u19.suggestionType == "History" then
                        local math_max_ret = math.max(1, u19.suggestions and #u19.suggestions or 1);
                        u15 = math.min(math_max_ret, u15 + 1);
                    else
                        u15 = math.max(1, u15 - 1);
                    end;

                    u17();

                    return;
                end;

                if p78.KeyCode == Enum.KeyCode.Down then
                    if u19.suggestionType == "History" then
                        u15 = math.max(1, u15 - 1);
                    else
                        local math_max_ret = math.max(1, u19.suggestions and #u19.suggestions or 1);
                        u15 = math.min(math_max_ret, u15 + 1);
                    end;

                    u17();
                end;
            elseif p78.UserInputType == Enum.UserInputType.MouseButton1 or p78.UserInputType == Enum.UserInputType.Touch then
                if p79 then
                    return;
                end;

                if u5.Visible then
                    u5.Visible = false;

                    if Parent.client then
                        if Parent.client.TopbarPlus then
                            Parent.client.TopbarPlus.setTopbarEnabled(true);
                        else
                            Parent.client.dashboardButton.Visible = Parent.client.dashboardButtonEnabled;
                        end;
                    end;

                    StarterGui:SetCore("ChatActive", u73);
                    u73 = nil;

                    for i, v in u72 do
                        u72[i] = nil;
                        StarterGui:SetCoreGuiEnabled(i, v);
                    end;
                end;
            end;
        end);
        u4._input:GetPropertyChangedSignal("CursorPosition"):Connect(function() -- Line: 810
            -- upvalues: u4 (ref), u77 (copy), UserInputService (ref), updateCompletionData (ref)
            local CursorPosition = u4._input.CursorPosition;

            if CursorPosition ~= -1 then
                local v80 = #u77.getCommandPrefix() + 1;

                if CursorPosition < v80 then
                    u4._input.CursorPosition = v80;

                    return;
                end;

                if not UserInputService:IsKeyDown(Enum.KeyCode.Tab) then
                    task.defer(updateCompletionData);
                end;
            end;
        end);
        u4._input:GetPropertyChangedSignal("SelectionStart"):Connect(function() -- Line: 824
            -- upvalues: u4 (ref), u1 (ref), clearCompletion (ref), u15 (ref), u19 (ref), CompletionData (ref), Parent (ref), u17 (ref)
            if u4._input.SelectionStart ~= -1 then
                if u1._value == false then
                    u1(nil);
                end;

                clearCompletion();

                return;
            end;

            if u4._input.SelectionStart ~= -1 then
                return;
            end;

            u15 = 1;
            u19 = CompletionData(Parent, u4._input.Text, u4._input.CursorPosition);
            u17();
        end);
        u4._input.Focused:Connect(function() -- Line: 835
            -- upvalues: u4 (ref), u77 (copy)
            u4.Value(u77.Util.String.trimEnd(u4._input.Text), true);
        end);
        u4._input.FocusLost:Connect(function(p81) -- Line: 839
            -- upvalues: u19 (ref), UI (ref), u4 (ref), u77 (copy), u5 (ref), Parent (ref), StarterGui (ref), u73 (ref), u72 (ref), u18 (ref), u58 (ref)
            if p81 then
                local v82 = u19;

                if #v82.invalid > 0 then
                    UI.Sound.Negative:Play();

                    return u4._input:CaptureFocus();
                end;

                local CommandPrefix2 = u77.getCommandPrefix();

                if u4._input.Text ~= CommandPrefix2 and #v82.commands < 1 then
                    UI.Sound.Negative:Play();

                    return u4._input:CaptureFocus();
                end;

                for _, v in v82.commands do
                    if v.invalidArg then
                        UI.Sound.Negative:Play();

                        return u4._input:CaptureFocus();
                    end;
                end;

                if u5.Visible then
                    u5.Visible = false;

                    if Parent.client then
                        if Parent.client.TopbarPlus then
                            Parent.client.TopbarPlus.setTopbarEnabled(true);
                        else
                            Parent.client.dashboardButton.Visible = Parent.client.dashboardButtonEnabled;
                        end;
                    end;

                    StarterGui:SetCore("ChatActive", u73);
                    u73 = nil;

                    for i, v in u72 do
                        u72[i] = nil;
                        StarterGui:SetCoreGuiEnabled(i, v);
                    end;
                end;

                if u4._input.Text == CommandPrefix2 then
                    return;
                end;

                if u18 and not (u18[4] or (v82.suggestionType == "History" or #v82.suggestions <= 1)) then
                    local v83, v84 = unpack(u18);

                    if not string.find(v84, " $") then
                        v84 = v84 .. " ";
                        v83 = v83 + 1;
                    end;

                    u18 = nil;
                    u4.Value(v84, true);
                    u4._input.CursorPosition = v83 + 1;
                    task.defer(u4._input.ReleaseFocus, u4._input);
                end;

                local v85 = u77.Util.String.trimEnd(u4._input.Text);
                task.spawn(u77.Process.runCommands, u77, u77.LocalPlayer.UserId, v85);
                local string_sub_ret = string.sub(v85, 2);
                local table_find_ret = table.find(u58, string_sub_ret);

                if table_find_ret ~= 1 then
                    if table_find_ret then
                        table.remove(u58, table_find_ret);
                    end;

                    table.insert(u58, 1, string_sub_ret);

                    if #u58 > 32 then
                        table.remove(u58);
                    end;
                end;

                u4.Value(CommandPrefix2, true);
            end;
        end);
        local u86 = {};

        local function updateInput(p87: any, p88: boolean?) -- Line: 898
            -- upvalues: u86 (copy), u18 (ref), UserInputService (ref), u24 (ref), u77 (copy)
            if u86[p87] then
                return;
            end;

            u86[p87] = true;

            if p88 and (u18 and UserInputService:IsKeyDown(Enum.KeyCode.Tab)) then
                u24();
                u86[p87] = false;

                return;
            end;

            local CommandPrefix2 = u77.getCommandPrefix();
            local v89 = #CommandPrefix2;
            local Text = p87._input.Text;

            if string.find(Text, CommandPrefix2, 1, true) ~= 1 then
                local _input = p87._input;
                _input.CursorPosition = _input.CursorPosition + v89;
                Text = CommandPrefix2 .. Text;
                p87.Value(Text, true);
                local _input2 = p87._input;
                _input2.CursorPosition = _input2.CursorPosition + v89;
            end;

            local v90 = CommandPrefix2 .. u77.Util.String.trimStart((string.sub(Text, v89 + 1)));

            if v90 == p87._input.Text then
                v90 = Text;
            else
                p87.Value(v90, true);
            end;

            if v90 ~= CommandPrefix2 then
                if string.find(v90, CommandPrefix2, v89 + 1, true) == v89 + 1 then
                    local string_sub_ret = string.sub(v90, v89 + 1);
                    p87.Value(string_sub_ret, true);
                else
                    p87.DisplayText(u77.Util.String.escapeRichText(v90), true);
                end;
            end;

            u86[p87] = false;
        end;

        u77.client.updateCommandInput = updateInput;
        u4._input:GetPropertyChangedSignal("Text"):Connect(function() -- Line: 944
            -- upvalues: updateInput (copy), u4 (ref)
            updateInput(u4, true);
        end);
    end,

    show = function() -- Line: 948, Name: show
        -- upvalues: Parent (copy), coreGuiEnabled (copy), u5 (copy), u4 (ref)
        if Parent.client.commandBarEnabled then
            if Parent.client.TopbarPlus then
                Parent.client.TopbarPlus.setTopbarEnabled(false);
            else
                Parent.client.dashboardButton.Visible = false;
            end;

            coreGuiEnabled(false);
            u5.Visible = true;
            task.wait();
            u4._input:CaptureFocus();
        end;
    end,

    hide = hideCommandBar
};