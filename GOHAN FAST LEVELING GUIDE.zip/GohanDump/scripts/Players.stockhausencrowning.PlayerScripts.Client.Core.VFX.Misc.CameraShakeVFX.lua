-- Decompiled with Potassium's decompiler.

game:GetService("Players");
game:GetService("Debris");
local ReplicatedStorage = game:GetService("ReplicatedStorage");
game:GetService("TweenService");
game:GetService("RunService");
game:GetService("UserInputService");
local Assets = ReplicatedStorage.Assets;
local Modules = ReplicatedStorage:WaitForChild("Modules");
ReplicatedStorage:WaitForChild("Remotes");
local _ = Modules.Metadata;
local Shared = Modules.Shared;
local _ = Modules.Utility;
local _ = Assets.Gui;
require(Shared.SoundManager);
require(Modules.GlobalFunctions);
require(Shared.CamManager);
require(Shared.CinemaManager);
local CamShakeHandler = require(Shared.CamShakeHandler);

return {
    Shake = function(p1) -- Line: 30
        -- upvalues: CamShakeHandler (copy)
        CamShakeHandler.Shake(p1.ShakeData);
    end
};