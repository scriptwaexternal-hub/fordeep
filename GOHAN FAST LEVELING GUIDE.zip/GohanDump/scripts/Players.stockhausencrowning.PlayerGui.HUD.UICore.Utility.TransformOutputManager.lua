-- Decompiled with Potassium's decompiler.

local OutputBar = script:FindFirstAncestor("HUD").MainFrame.HUDisplay.HUDMAIN.OutputBar;

return {
    Update = function(p1) -- Line: 9, Name: Update
        -- upvalues: OutputBar (copy)
        OutputBar:TweenSize(UDim2.new(0.602 * (p1 / 100), 0, 0.04, 0), "Out", "Sine", 0.1, true);
    end
};