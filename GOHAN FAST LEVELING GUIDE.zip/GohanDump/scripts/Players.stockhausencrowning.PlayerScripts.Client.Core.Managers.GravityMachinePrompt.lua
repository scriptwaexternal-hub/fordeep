-- Decompiled with Potassium's decompiler.

local Players = game:GetService("Players");
local ReplicatedStorage = game:GetService("ReplicatedStorage");
local RunService = game:GetService("RunService");
local ContextActionService = game:GetService("ContextActionService");
local UserInputService = game:GetService("UserInputService");
local TweenService = game:GetService("TweenService");
local LocalPlayer = Players.LocalPlayer;
local Platform = require(ReplicatedStorage:WaitForChild("Modules"):WaitForChild("Shared"):WaitForChild("Platform"));
local GravityMachineVFX = require(script.Parent.Parent.VFX.Technology.GravityMachineVFX);
local ServerRemote = ReplicatedStorage:WaitForChild("Remotes"):WaitForChild("ServerRemote");
local u1 = { Enum.KeyCode.E, Enum.KeyCode.ButtonX };
local Color3_fromRGB_ret = Color3.fromRGB(44, 44, 45);
local Color3_fromRGB_ret2 = Color3.fromRGB(28, 28, 30);
local Color3_fromRGB_ret3 = Color3.fromRGB(255, 255, 255);
local Color3_fromRGB_ret4 = Color3.fromRGB(216, 213, 205);
local Color3_fromRGB_ret5 = Color3.fromRGB(201, 198, 191);
local Color3_fromRGB_ret6 = Color3.fromRGB(0, 0, 0);
local Color3_fromRGB_ret7 = Color3.fromRGB(88, 214, 106);
local Color3_fromRGB_ret8 = Color3.fromRGB(72, 160, 255);
local Color3_fromRGB_ret9 = Color3.fromRGB(225, 70, 60);
local Arcade = Enum.Font.Arcade;
local Bangers = Enum.Font.Bangers;
local v2 = {};
local u3 = {};
local u4 = nil;
local u5 = nil;
local u6 = nil;
local u7 = nil;
local u8 = nil;
local u9 = nil;
local u10 = nil;
local u11 = nil;
local u12 = false;
local u13 = 0;
local u14 = 0;
local u15 = nil;

local function register(p16) -- Line: 59
    -- upvalues: u3 (copy)
    if p16:IsA("Model") and (p16:GetAttribute("Interact") == "GravityMachine" or p16:GetAttribute("Interact") == "KiJammer") then
        u3[p16] = true;
    end;
end;

local function anchorOf(p17) -- Line: 65
    return p17.PrimaryPart or p17:FindFirstChildWhichIsA("BasePart");
end;

local function use() -- Line: 69
    -- upvalues: u11 (ref), u14 (ref), ServerRemote (copy), GravityMachineVFX (copy)
    if not u11 then
        return;
    end;

    local os_clock_ret = os.clock();

    if os_clock_ret - u14 < 0.5 then
        return;
    end;

    u14 = os_clock_ret;

    if u11:GetAttribute("Interact") == "KiJammer" then
        ServerRemote:FireServer(nil, {
            Module = "DeployableTechHandler",
            Action = "PickUp"
        });

        return;
    end;

    if u11:GetAttribute("Planted") == false then
        ServerRemote:FireServer(nil, {
            Module = "GravityMachineHandler",
            Action = "PickUp"
        });

        return;
    end;

    GravityMachineVFX.Open({
        Machine = u11
    });
end;

local function startHold() -- Line: 88
    -- upvalues: u4 (ref), u12 (ref), u13 (ref)
    if not u4 or u12 then
        return;
    end;

    local os_clock_ret = os.clock();
    u12 = true;
    u13 = os_clock_ret;
end;

local function stopHold() -- Line: 93
    -- upvalues: u12 (ref), u6 (ref)
    u12 = false;

    if u6 then
        u6.Size = UDim2.new(0, 0, 1, 0);
    end;
end;

local function bindKey() -- Line: 98
    -- upvalues: ContextActionService (copy), u4 (ref), u12 (ref), u13 (ref), u6 (ref), u1 (copy)
    ContextActionService:BindActionAtPriority("GravityMachinePromptUse", function(p18, p19) -- Line: 99
        -- upvalues: u4 (ref), u12 (ref), u13 (ref), u6 (ref)
        if p19 == Enum.UserInputState.Begin then
            if u4 and not u12 then
                local os_clock_ret = os.clock();
                u12 = true;
                u13 = os_clock_ret;
            end;
        else
            u12 = false;

            if u6 then
                u6.Size = UDim2.new(0, 0, 1, 0);
            end;
        end;

        return Enum.ContextActionResult.Sink;
    end, false, Enum.ContextActionPriority.High.Value, table.unpack(u1));
end;

local function unbindKey() -- Line: 105
    -- upvalues: ContextActionService (copy)
    ContextActionService:UnbindAction("GravityMachinePromptUse");
end;

local function stroked(p20) -- Line: 111
    -- upvalues: Color3_fromRGB_ret6 (copy)
    p20.TextStrokeColor3 = Color3_fromRGB_ret6;
    p20.TextStrokeTransparency = 0.5;

    return p20;
end;

local function outline(p21, p22) -- Line: 117
    -- upvalues: Color3_fromRGB_ret6 (copy)
    local UIStroke = Instance.new("UIStroke");
    UIStroke.Color = Color3_fromRGB_ret6;
    UIStroke.Thickness = p22 or 1.5;
    UIStroke.Parent = p21;

    return UIStroke;
end;

local function label(p23, p24, p25, p26, p27) -- Line: 123
    -- upvalues: Color3_fromRGB_ret6 (copy)
    local TextLabel = Instance.new("TextLabel");
    TextLabel.BackgroundTransparency = 1;
    TextLabel.Font = p24;
    TextLabel.TextSize = p25;
    TextLabel.TextColor3 = p26;
    TextLabel.TextXAlignment = p27 or Enum.TextXAlignment.Left;
    TextLabel.Text = "";
    TextLabel.Parent = p23;
    TextLabel.TextStrokeColor3 = Color3_fromRGB_ret6;
    TextLabel.TextStrokeTransparency = 0.5;

    return TextLabel;
end;

local function updateChip() -- Line: 133
    -- upvalues: u7 (ref), Platform (copy), u8 (ref)
    if not u7 then
        return;
    end;

    if Platform.IsTouch() and not Platform.PreferGamepadGlyphs() then
        u7.Text = "USE";
        u8.Text = "HOLD";

        return;
    end;

    if Platform.PreferGamepadGlyphs() then
        u7.Text = "X";
        u8.Text = "HOLD";

        return;
    end;

    u7.Text = "E";
    u8.Text = "HOLD";
end;

local function refreshStatus() -- Line: 144
    -- upvalues: u9 (ref), u11 (ref), Color3_fromRGB_ret9 (copy), u10 (ref), Color3_fromRGB_ret4 (copy), Color3_fromRGB_ret8 (copy)
    if not (u9 and u11) then
        return;
    end;

    if u11:GetAttribute("Interact") == "KiJammer" then
        u9.Text = "JAMMING";
        u9.TextColor3 = Color3_fromRGB_ret9;

        if u10 then
            u10.Text = "Hold to pick it up";
        end;

        return;
    end;

    local v28 = u11:GetAttribute("On") == true;
    local v29 = u11:GetAttribute("Gravity") or 10;

    if u11:GetAttribute("Planted") == false then
        u9.Text = "TOPPLED";
        u9.TextColor3 = Color3_fromRGB_ret4;

        if u10 then
            u10.Text = "Hold to pick it up";
        end;

        return;
    end;

    if u10 then
        u10.Text = "Hold to use the terminal";
    end;

    u9.Text = v28 and "FIELD ACTIVE  " .. tostring(v29) .. " G" or "OFF  " .. tostring(v29) .. " G";
    u9.TextColor3 = v28 and Color3_fromRGB_ret9 or Color3_fromRGB_ret8;
end;

local function build(p30) -- Line: 165
    -- upvalues: u4 (ref), LocalPlayer (copy), u5 (ref), Color3_fromRGB_ret (copy), Color3_fromRGB_ret6 (copy), Arcade (copy), Color3_fromRGB_ret3 (copy), u9 (ref), Bangers (copy), Color3_fromRGB_ret8 (copy), Color3_fromRGB_ret5 (copy), u10 (ref), u7 (ref), Color3_fromRGB_ret2 (copy), u8 (ref), Color3_fromRGB_ret4 (copy), u6 (ref), Color3_fromRGB_ret7 (copy), u12 (ref), u13 (ref), Platform (copy), TweenService (copy)
    local v31 = p30.PrimaryPart or p30:FindFirstChildWhichIsA("BasePart");

    if not v31 then
        return false;
    end;

    local BoundingBox, v32 = p30:GetBoundingBox();
    local v33 = BoundingBox.Position.Y + v32.Y * 0.5;
    u4 = Instance.new("BillboardGui");
    u4.Name = "GravityMachinePrompt";
    u4.Adornee = v31;
    u4.AlwaysOnTop = true;
    u4.Active = true;
    u4.ResetOnSpawn = false;
    u4.Size = UDim2.fromOffset(138.60000000000002, 46.2);
    u4.StudsOffsetWorldSpace = Vector3.new(0, v33 - v31.Position.Y + 1.2, 0);
    u4.Parent = LocalPlayer:WaitForChild("PlayerGui");
    u5 = Instance.new("CanvasGroup");
    u5.AnchorPoint = Vector2.new(0.5, 0.5);
    u5.Position = UDim2.fromScale(0.5, 0.5);
    u5.Size = UDim2.fromOffset(252, 84);
    u5.BackgroundTransparency = 1;
    u5.GroupTransparency = 1;
    u5.Parent = u4;
    local UIScale = Instance.new("UIScale");
    UIScale.Scale = 0.4675;
    UIScale.Parent = u5;
    local Frame = Instance.new("Frame");
    Frame.Size = UDim2.fromScale(1, 1);
    Frame.BackgroundColor3 = Color3_fromRGB_ret;
    Frame.BorderSizePixel = 0;
    Frame.Parent = u5;
    local UIStroke = Instance.new("UIStroke");
    UIStroke.Color = Color3_fromRGB_ret6;
    UIStroke.Thickness = 2;
    UIStroke.Parent = Frame;
    local TextLabel = Instance.new("TextLabel");
    TextLabel.BackgroundTransparency = 1;
    TextLabel.Font = Arcade;
    TextLabel.TextSize = 16;
    TextLabel.TextColor3 = Color3_fromRGB_ret3;
    TextLabel.TextXAlignment = Enum.TextXAlignment.Left;
    TextLabel.Text = "";
    TextLabel.Parent = Frame;
    TextLabel.TextStrokeColor3 = Color3_fromRGB_ret6;
    TextLabel.TextStrokeTransparency = 0.5;
    TextLabel.Position = UDim2.fromOffset(12, 8);
    TextLabel.Size = UDim2.new(1, -92, 0, 20);
    TextLabel.Text = p30:GetAttribute("Interact") == "KiJammer" and "KI JAMMER" or "GRAVITY MACHINE";
    local TextLabel2 = Instance.new("TextLabel");
    TextLabel2.BackgroundTransparency = 1;
    TextLabel2.Font = Bangers;
    TextLabel2.TextSize = 20;
    TextLabel2.TextColor3 = Color3_fromRGB_ret8;
    TextLabel2.TextXAlignment = Enum.TextXAlignment.Left;
    TextLabel2.Text = "";
    TextLabel2.Parent = Frame;
    TextLabel2.TextStrokeColor3 = Color3_fromRGB_ret6;
    TextLabel2.TextStrokeTransparency = 0.5;
    u9 = TextLabel2;
    u9.Position = UDim2.fromOffset(12, 30);
    u9.Size = UDim2.new(1, -92, 0, 22);
    local TextLabel3 = Instance.new("TextLabel");
    TextLabel3.BackgroundTransparency = 1;
    TextLabel3.Font = Bangers;
    TextLabel3.TextSize = 13;
    TextLabel3.TextColor3 = Color3_fromRGB_ret5;
    TextLabel3.TextXAlignment = Enum.TextXAlignment.Left;
    TextLabel3.Text = "";
    TextLabel3.Parent = Frame;
    TextLabel3.TextStrokeColor3 = Color3_fromRGB_ret6;
    TextLabel3.TextStrokeTransparency = 0.5;
    TextLabel3.Position = UDim2.fromOffset(12, 52);
    TextLabel3.Size = UDim2.new(1, -92, 0, 16);
    TextLabel3.Text = "Hold to use the terminal";
    u10 = TextLabel3;
    u7 = Instance.new("TextButton");
    u7.AnchorPoint = Vector2.new(1, 0);
    u7.Position = UDim2.new(1, -12, 0, 12);
    u7.Size = UDim2.fromOffset(60, 38);
    u7.BackgroundColor3 = Color3_fromRGB_ret2;
    u7.BorderSizePixel = 0;
    u7.AutoButtonColor = false;
    u7.Font = Arcade;
    u7.TextSize = 20;
    u7.TextColor3 = Color3_fromRGB_ret3;
    u7.Text = "E";
    local v34 = u7;
    v34.TextStrokeColor3 = Color3_fromRGB_ret6;
    v34.TextStrokeTransparency = 0.5;
    v34.Parent = Frame;
    local UIStroke2 = Instance.new("UIStroke");
    UIStroke2.Color = Color3_fromRGB_ret6;
    UIStroke2.Thickness = 1.5;
    UIStroke2.Parent = u7;
    local Center = Enum.TextXAlignment.Center;
    local TextLabel4 = Instance.new("TextLabel");
    TextLabel4.BackgroundTransparency = 1;
    TextLabel4.Font = Bangers;
    TextLabel4.TextSize = 12;
    TextLabel4.TextColor3 = Color3_fromRGB_ret4;
    TextLabel4.TextXAlignment = Center or Enum.TextXAlignment.Left;
    TextLabel4.Text = "";
    TextLabel4.Parent = Frame;
    TextLabel4.TextStrokeColor3 = Color3_fromRGB_ret6;
    TextLabel4.TextStrokeTransparency = 0.5;
    u8 = TextLabel4;
    u8.AnchorPoint = Vector2.new(1, 0);
    u8.Position = UDim2.new(1, -12, 0, 52);
    u8.Size = UDim2.fromOffset(60, 14);
    u8.Text = "HOLD";
    local Frame2 = Instance.new("Frame");
    Frame2.AnchorPoint = Vector2.new(0, 1);
    Frame2.Position = UDim2.new(0, 0, 1, 0);
    Frame2.Size = UDim2.new(1, 0, 0, 5);
    Frame2.BackgroundColor3 = Color3_fromRGB_ret2;
    Frame2.BorderSizePixel = 0;
    Frame2.Parent = Frame;
    u6 = Instance.new("Frame");
    u6.Size = UDim2.new(0, 0, 1, 0);
    u6.BackgroundColor3 = Color3_fromRGB_ret7;
    u6.BorderSizePixel = 0;
    u6.Parent = Frame2;
    u7.InputBegan:Connect(function(p35) -- Line: 248
        -- upvalues: u4 (ref), u12 (ref), u13 (ref)
        if (p35.UserInputType == Enum.UserInputType.Touch or p35.UserInputType == Enum.UserInputType.MouseButton1) and u4 then
            if u12 then
                return;
            end;

            local os_clock_ret = os.clock();
            u12 = true;
            u13 = os_clock_ret;
        end;
    end);
    u7.InputEnded:Connect(function(p36) -- Line: 251
        -- upvalues: u12 (ref), u6 (ref)
        if p36.UserInputType == Enum.UserInputType.Touch or p36.UserInputType == Enum.UserInputType.MouseButton1 then
            u12 = false;

            if u6 then
                u6.Size = UDim2.new(0, 0, 1, 0);
            end;
        end;
    end);

    if u7 then
        if Platform.IsTouch() and not Platform.PreferGamepadGlyphs() then
            u7.Text = "USE";
            u8.Text = "HOLD";
        elseif Platform.PreferGamepadGlyphs() then
            u7.Text = "X";
            u8.Text = "HOLD";
        else
            u7.Text = "E";
            u8.Text = "HOLD";
        end;
    end;

    TweenService:Create(u5, TweenInfo.new(0.15, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
        GroupTransparency = 0
    }):Play();
    TweenService:Create(UIScale, TweenInfo.new(0.18, Enum.EasingStyle.Back, Enum.EasingDirection.Out), {
        Scale = 0.55
    }):Play();

    return true;
end;

local function hide() -- Line: 263
    -- upvalues: ContextActionService (copy), u12 (ref), u6 (ref), u15 (ref), u11 (ref), u4 (ref), u5 (ref), u7 (ref), u8 (ref), u9 (ref), u10 (ref), TweenService (copy)
    ContextActionService:UnbindAction("GravityMachinePromptUse");
    u12 = false;

    if u6 then
        u6.Size = UDim2.new(0, 0, 1, 0);
    end;

    if u15 then
        u15:Disconnect();
        u15 = nil;
    end;

    u11 = nil;

    if u4 then
        local u37 = u4;
        local v38 = u5;
        u4 = nil;
        u5 = nil;
        u6 = nil;
        u7 = nil;
        u8 = nil;
        u9 = nil;
        u10 = nil;
        local v39 = TweenService:Create(v38, TweenInfo.new(0.12), {
            GroupTransparency = 1
        });
        v39.Completed:Once(function() -- Line: 272
            -- upvalues: u37 (copy)
            u37:Destroy();
        end);
        v39:Play();
    end;
end;

local function show(p40) -- Line: 277
    -- upvalues: u4 (ref), hide (copy), build (copy), u11 (ref), refreshStatus (copy), u15 (ref), ContextActionService (copy), u12 (ref), u13 (ref), u6 (ref), u1 (copy)
    if u4 then
        hide();
    end;

    if not build(p40) then
        return;
    end;

    u11 = p40;
    refreshStatus();
    u15 = p40.AttributeChanged:Connect(refreshStatus);
    ContextActionService:BindActionAtPriority("GravityMachinePromptUse", function(p41, p42) -- Line: 99
        -- upvalues: u4 (ref), u12 (ref), u13 (ref), u6 (ref)
        if p42 == Enum.UserInputState.Begin then
            if u4 and not u12 then
                local os_clock_ret = os.clock();
                u12 = true;
                u13 = os_clock_ret;
            end;
        else
            u12 = false;

            if u6 then
                u6.Size = UDim2.new(0, 0, 1, 0);
            end;
        end;

        return Enum.ContextActionResult.Sink;
    end, false, Enum.ContextActionPriority.High.Value, table.unpack(u1));
end;

local function eligible(p43) -- Line: 287
    local v44;

    if p43.Parent == nil or p43:GetAttribute("Carried") == true then
        v44 = false;
    else
        v44 = p43:GetAttribute("Interact") ~= nil;
    end;

    return v44;
end;

local function nearest(p45) -- Line: 291
    -- upvalues: u3 (copy)
    local v46 = (1 / 0);
    local v47 = nil;

    for i in pairs(u3) do
        if i.Parent then
            local v48;

            if i.Parent == nil or i:GetAttribute("Carried") == true then
                v48 = false;
            else
                v48 = i:GetAttribute("Interact") ~= nil;
            end;

            if v48 then
                local Magnitude = (i:GetPivot().Position - p45).Magnitude;

                if Magnitude < v46 then
                    v47 = i;
                    v46 = Magnitude;
                end;
            end;
        else
            u3[i] = nil;
        end;
    end;

    return v47, v46;
end;

local u49 = 0;
RunService.Heartbeat:Connect(function(p50) -- Line: 307
    -- upvalues: u12 (ref), u6 (ref), u13 (ref), use (copy), u49 (ref), LocalPlayer (copy), u4 (ref), hide (copy), nearest (copy), u11 (ref), build (copy), refreshStatus (copy), u15 (ref), ContextActionService (copy), u1 (copy)
    if u12 and u6 then
        local v51 = (os.clock() - u13) / 0.6;
        local math_clamp_ret = math.clamp(v51, 0, 1);
        u6.Size = UDim2.new(math_clamp_ret, 0, 1, 0);

        if math_clamp_ret >= 1 then
            u12 = false;

            if u6 then
                u6.Size = UDim2.new(0, 0, 1, 0);
            end;

            use();
        end;
    end;

    u49 = u49 + p50;

    if u49 < 0.15 then
        return;
    end;

    u49 = 0;
    local Character = LocalPlayer.Character;
    local v52;

    if Character then
        v52 = Character:FindFirstChild("HumanoidRootPart");
    else
        v52 = Character;
    end;

    if Character then
        Character = Character:FindFirstChildOfClass("Humanoid");
    end;

    if not (v52 and (Character and Character.Health > 0)) then
        if u4 then
            hide();
        end;

        return;
    end;

    local v53, v54 = nearest(v52.Position);

    if u4 then
        if u11 then
            local v55 = u11;
            local v56;

            if v55.Parent == nil or v55:GetAttribute("Carried") == true then
                v56 = false;
            else
                v56 = v55:GetAttribute("Interact") ~= nil;
            end;

            if v56 then
                local Magnitude = (u11:GetPivot().Position - v52.Position).Magnitude;

                if Magnitude <= 14 then
                    if v53 ~= u11 and (v54 <= 12 and v54 < Magnitude - 2) then
                        if u4 then
                            hide();
                        end;

                        if not build(v53) then
                            return;
                        end;

                        u11 = v53;
                        refreshStatus();
                        u15 = v53.AttributeChanged:Connect(refreshStatus);
                        ContextActionService:BindActionAtPriority("GravityMachinePromptUse", function(p57, p58) -- Line: 99
                            -- upvalues: u4 (ref), u12 (ref), u13 (ref), u6 (ref)
                            if p58 == Enum.UserInputState.Begin then
                                if u4 and not u12 then
                                    local os_clock_ret = os.clock();
                                    u12 = true;
                                    u13 = os_clock_ret;
                                end;
                            else
                                u12 = false;

                                if u6 then
                                    u6.Size = UDim2.new(0, 0, 1, 0);
                                end;
                            end;

                            return Enum.ContextActionResult.Sink;
                        end, false, Enum.ContextActionPriority.High.Value, table.unpack(u1));
                    end;

                    return;
                end;
            end;
        end;

        hide();
    end;

    if v53 and v54 <= 12 then
        if u4 then
            hide();
        end;

        if not build(v53) then
            return;
        end;

        u11 = v53;
        refreshStatus();
        u15 = v53.AttributeChanged:Connect(refreshStatus);
        ContextActionService:BindActionAtPriority("GravityMachinePromptUse", function(p59, p60) -- Line: 99
            -- upvalues: u4 (ref), u12 (ref), u13 (ref), u6 (ref)
            if p60 == Enum.UserInputState.Begin then
                if u4 and not u12 then
                    local os_clock_ret = os.clock();
                    u12 = true;
                    u13 = os_clock_ret;
                end;
            else
                u12 = false;

                if u6 then
                    u6.Size = UDim2.new(0, 0, 1, 0);
                end;
            end;

            return Enum.ContextActionResult.Sink;
        end, false, Enum.ContextActionPriority.High.Value, table.unpack(u1));
    end;
end);
UserInputService.LastInputTypeChanged:Connect(updateChip);

for _, descendant in ipairs(workspace:GetDescendants()) do
    if descendant:IsA("Model") and (descendant:GetAttribute("Interact") == "GravityMachine" or descendant:GetAttribute("Interact") == "KiJammer") then
        u3[descendant] = true;
    end;
end;

workspace.DescendantAdded:Connect(register);
workspace.DescendantRemoving:Connect(function(p61) -- Line: 348
    -- upvalues: u3 (copy), u11 (ref), hide (copy)
    if u3[p61] then
        u3[p61] = nil;

        if p61 == u11 then
            hide();
        end;
    end;
end);

return v2;