-- Decompiled with Potassium's decompiler.

local Players = game:GetService("Players");
local TweenService = game:GetService("TweenService");
local LocalPlayer = Players.LocalPlayer;
local Color3_fromRGB_ret = Color3.fromRGB(44, 44, 45);
local Color3_fromRGB_ret2 = Color3.fromRGB(28, 28, 30);
local Color3_fromRGB_ret3 = Color3.fromRGB(255, 255, 255);
local Color3_fromRGB_ret4 = Color3.fromRGB(216, 213, 205);
local Color3_fromRGB_ret5 = Color3.fromRGB(201, 198, 191);
local Color3_fromRGB_ret6 = Color3.fromRGB(0, 0, 0);
local Color3_fromRGB_ret7 = Color3.fromRGB(88, 214, 106);
local Color3_fromRGB_ret8 = Color3.fromRGB(72, 160, 255);
local Arcade = Enum.Font.Arcade;
local Bangers = Enum.Font.Bangers;
local u1 = {};
u1.__index = u1;

local function stroked(p2) -- Line: 56
    -- upvalues: Color3_fromRGB_ret6 (copy)
    p2.TextStrokeColor3 = Color3_fromRGB_ret6;
    p2.TextStrokeTransparency = 0.5;

    return p2;
end;

local function outline(p3, p4) -- Line: 62
    -- upvalues: Color3_fromRGB_ret6 (copy)
    local UIStroke = Instance.new("UIStroke");
    UIStroke.Color = Color3_fromRGB_ret6;
    UIStroke.Thickness = p4 or 1.5;
    UIStroke.Parent = p3;

    return UIStroke;
end;

local function label(p5, p6, p7, p8, p9) -- Line: 70
    -- upvalues: Color3_fromRGB_ret6 (copy)
    local TextLabel = Instance.new("TextLabel");
    TextLabel.BackgroundTransparency = 1;
    TextLabel.Font = p6;
    TextLabel.TextSize = p7;
    TextLabel.TextColor3 = p8;
    TextLabel.TextXAlignment = p9 or Enum.TextXAlignment.Left;
    TextLabel.Text = "";
    TextLabel.Parent = p5;
    TextLabel.TextStrokeColor3 = Color3_fromRGB_ret6;
    TextLabel.TextStrokeTransparency = 0.5;

    return TextLabel;
end;

local function chip(p10, p11) -- Line: 83
    -- upvalues: Color3_fromRGB_ret2 (copy), Color3_fromRGB_ret3 (copy), Arcade (copy), Color3_fromRGB_ret6 (copy)
    local TextLabel = Instance.new("TextLabel");
    TextLabel.Size = UDim2.new(0, math.max(42, #p11 * 13 + 20), 0, 28);
    TextLabel.BackgroundColor3 = Color3_fromRGB_ret2;
    TextLabel.BorderSizePixel = 0;
    TextLabel.TextColor3 = Color3_fromRGB_ret3;
    TextLabel.Font = Arcade;
    TextLabel.TextSize = 17;
    TextLabel.Text = p11;
    TextLabel.TextStrokeColor3 = Color3_fromRGB_ret6;
    TextLabel.TextStrokeTransparency = 0.5;
    TextLabel.Parent = p10;
    local UIStroke = Instance.new("UIStroke");
    UIStroke.Color = Color3_fromRGB_ret6;
    UIStroke.Thickness = 1.5;
    UIStroke.Parent = TextLabel;

    return TextLabel;
end;

function u1.new(p12) -- Line: 113
    -- upvalues: u1 (copy), LocalPlayer (copy), Color3_fromRGB_ret (copy), Arcade (copy), Color3_fromRGB_ret3 (copy), Color3_fromRGB_ret6 (copy), Color3_fromRGB_ret5 (copy), Color3_fromRGB_ret7 (copy), Bangers (copy), Color3_fromRGB_ret4 (copy), Color3_fromRGB_ret2 (copy), Color3_fromRGB_ret8 (copy)
    local v13 = p12 or {};
    local u14 = setmetatable({}, u1);
    u14.Width = v13.Width or 560;
    u14.Height = v13.Height or 158;
    local workspace_CurrentCamera = workspace.CurrentCamera;
    local v15 = -(math.floor((workspace_CurrentCamera and workspace_CurrentCamera.ViewportSize.Y or 720) * 0.115) + 10);
    u14.RestY = math.min(v13.BottomOffset or -28, v15);
    u14._rows = {};
    u14._dismissed = false;
    local PlayerGui = LocalPlayer:WaitForChild("PlayerGui");
    local v16 = PlayerGui:FindFirstChild(v13.Name or "KamiCard");

    if v16 then
        v16:Destroy();
    end;

    local ScreenGui = Instance.new("ScreenGui");
    ScreenGui.Name = v13.Name or "KamiCard";
    ScreenGui.ResetOnSpawn = false;
    ScreenGui.DisplayOrder = v13.DisplayOrder or 60;
    ScreenGui.IgnoreGuiInset = true;
    ScreenGui.Parent = PlayerGui;
    u14.Gui = ScreenGui;
    local Frame = Instance.new("Frame");
    Frame.Name = "Card";
    Frame.AnchorPoint = Vector2.new(0.5, 1);
    Frame.Position = UDim2.new(0.5, 0, 1, u14.RestY);
    Frame.Size = UDim2.fromOffset(u14.Width, u14.Height);
    Frame.BackgroundColor3 = Color3_fromRGB_ret;
    Frame.BorderSizePixel = 0;
    Frame.Visible = false;
    Frame.Parent = ScreenGui;
    u14.Card = Frame;
    local UIScale = Instance.new("UIScale");
    UIScale.Parent = Frame;
    u14._scale = UIScale;
    local workspace_CurrentCamera2 = workspace.CurrentCamera;

    local function fit() -- Line: 167
        -- upvalues: u14 (copy), UIScale (copy)
        local workspace_CurrentCamera3 = workspace.CurrentCamera;

        if workspace_CurrentCamera3 then
            workspace_CurrentCamera3 = workspace_CurrentCamera3.ViewportSize;
        end;

        if not (workspace_CurrentCamera3 and (workspace_CurrentCamera3.X > 0 and workspace_CurrentCamera3.Y > 0)) then
            return;
        end;

        local math_min_ret = math.min(workspace_CurrentCamera3.X * 0.92 / (u14.Width * 1.2), workspace_CurrentCamera3.Y * 0.42 / u14.Height);
        UIScale.Scale = math.clamp(math_min_ret, 0.55, 1);
    end;

    local workspace_CurrentCamera3 = workspace.CurrentCamera;

    if workspace_CurrentCamera3 then
        workspace_CurrentCamera3 = workspace_CurrentCamera3.ViewportSize;
    end;

    if workspace_CurrentCamera3 and (workspace_CurrentCamera3.X > 0 and workspace_CurrentCamera3.Y > 0) then
        local math_min_ret = math.min(workspace_CurrentCamera3.X * 0.92 / (u14.Width * 1.2), workspace_CurrentCamera3.Y * 0.42 / u14.Height);
        UIScale.Scale = math.clamp(math_min_ret, 0.55, 1);
    end;

    if workspace_CurrentCamera2 then
        u14._fitConn = workspace_CurrentCamera2:GetPropertyChangedSignal("ViewportSize"):Connect(fit);
    end;

    local ImageLabel = Instance.new("ImageLabel");
    ImageLabel.Name = "Portrait";
    ImageLabel.AnchorPoint = Vector2.new(1, 0.5);
    ImageLabel.Position = UDim2.new(-0.015, 0, 0.5, 0);
    ImageLabel.Size = UDim2.new(0.35, 0, 0.72, 0);
    ImageLabel.BackgroundTransparency = 1;
    ImageLabel.Image = "rbxassetid://85725203749860";
    ImageLabel.ScaleType = Enum.ScaleType.Fit;
    ImageLabel.Parent = Frame;
    local UIAspectRatioConstraint = Instance.new("UIAspectRatioConstraint");
    UIAspectRatioConstraint.AspectRatio = 1;
    UIAspectRatioConstraint.Parent = ImageLabel;
    u14.Portrait = ImageLabel;

    if v13.Portrait == false then
        ImageLabel.Visible = false;
    end;

    local TextLabel = Instance.new("TextLabel");
    TextLabel.BackgroundTransparency = 1;
    TextLabel.Font = Arcade;
    TextLabel.TextSize = 23;
    TextLabel.TextColor3 = Color3_fromRGB_ret3;
    TextLabel.TextXAlignment = Enum.TextXAlignment.Left;
    TextLabel.Text = "";
    TextLabel.Parent = Frame;
    TextLabel.TextStrokeColor3 = Color3_fromRGB_ret6;
    TextLabel.TextStrokeTransparency = 0.5;
    TextLabel.Name = "NameLabel";
    TextLabel.Position = UDim2.new(0, 18, 0, -27);
    TextLabel.Size = UDim2.new(0, 240, 0, 26);
    TextLabel.Text = "KAMI";
    u14.NameLabel = TextLabel;
    local Right = Enum.TextXAlignment.Right;
    local TextLabel2 = Instance.new("TextLabel");
    TextLabel2.BackgroundTransparency = 1;
    TextLabel2.Font = Arcade;
    TextLabel2.TextSize = 15;
    TextLabel2.TextColor3 = Color3_fromRGB_ret5;
    TextLabel2.TextXAlignment = Right or Enum.TextXAlignment.Left;
    TextLabel2.Text = "";
    TextLabel2.Parent = Frame;
    TextLabel2.TextStrokeColor3 = Color3_fromRGB_ret6;
    TextLabel2.TextStrokeTransparency = 0.5;
    TextLabel2.Name = "Counter";
    TextLabel2.AnchorPoint = Vector2.new(1, 0);
    TextLabel2.Position = UDim2.new(1, -18, 0, 13);
    TextLabel2.Size = UDim2.new(0, 220, 0, 20);
    u14.Counter = TextLabel2;
    local TextLabel3 = Instance.new("TextLabel");
    TextLabel3.BackgroundTransparency = 1;
    TextLabel3.Font = Arcade;
    TextLabel3.TextSize = 24;
    TextLabel3.TextColor3 = Color3_fromRGB_ret3;
    TextLabel3.TextXAlignment = Enum.TextXAlignment.Left;
    TextLabel3.Text = "";
    TextLabel3.Parent = Frame;
    TextLabel3.TextStrokeColor3 = Color3_fromRGB_ret6;
    TextLabel3.TextStrokeTransparency = 0.5;
    TextLabel3.Name = "Title";
    TextLabel3.Position = UDim2.new(0, 18, 0, 12);
    TextLabel3.Size = UDim2.new(1, -240, 0, 28);
    u14.Title = TextLabel3;
    local TextLabel4 = Instance.new("TextLabel");
    TextLabel4.BackgroundTransparency = 1;
    TextLabel4.Font = Arcade;
    TextLabel4.TextSize = 19;
    TextLabel4.TextColor3 = Color3_fromRGB_ret7;
    TextLabel4.TextXAlignment = Enum.TextXAlignment.Left;
    TextLabel4.Text = "";
    TextLabel4.Parent = Frame;
    TextLabel4.TextStrokeColor3 = Color3_fromRGB_ret6;
    TextLabel4.TextStrokeTransparency = 0.5;
    TextLabel4.Name = "Objective";
    TextLabel4.Position = UDim2.new(0, 18, 0, 44);
    TextLabel4.Size = UDim2.new(1, -36, 0, 24);
    TextLabel4.RichText = true;
    u14.Objective = TextLabel4;
    local TextLabel5 = Instance.new("TextLabel");
    TextLabel5.BackgroundTransparency = 1;
    TextLabel5.Font = Bangers;
    TextLabel5.TextSize = 18;
    TextLabel5.TextColor3 = Color3_fromRGB_ret4;
    TextLabel5.TextXAlignment = Enum.TextXAlignment.Left;
    TextLabel5.Text = "";
    TextLabel5.Parent = Frame;
    TextLabel5.TextStrokeColor3 = Color3_fromRGB_ret6;
    TextLabel5.TextStrokeTransparency = 0.5;
    TextLabel5.Name = "Detail";
    TextLabel5.Position = UDim2.new(0, 18, 0, 72);
    TextLabel5.Size = UDim2.new(1, -36, 1, -116);
    TextLabel5.TextWrapped = true;
    TextLabel5.TextYAlignment = Enum.TextYAlignment.Top;
    u14.Detail = TextLabel5;
    local Frame2 = Instance.new("Frame");
    Frame2.Name = "Rows";
    Frame2.Position = UDim2.new(0, 18, 0, 44);
    Frame2.Size = UDim2.new(1, -36, 1, -96);
    Frame2.BackgroundTransparency = 1;
    Frame2.Visible = false;
    Frame2.Parent = Frame;
    local UIListLayout = Instance.new("UIListLayout");
    UIListLayout.FillDirection = Enum.FillDirection.Vertical;
    UIListLayout.SortOrder = Enum.SortOrder.LayoutOrder;
    UIListLayout.Padding = UDim.new(0, 6);
    UIListLayout.Parent = Frame2;
    u14.RowHolder = Frame2;
    local Frame3 = Instance.new("Frame");
    Frame3.Name = "KeysRow";
    Frame3.Position = UDim2.new(0, 18, 1, -40);
    Frame3.Size = UDim2.new(0.6, 0, 0, 28);
    Frame3.BackgroundTransparency = 1;
    Frame3.Parent = Frame;
    local UIListLayout2 = Instance.new("UIListLayout");
    UIListLayout2.FillDirection = Enum.FillDirection.Horizontal;
    UIListLayout2.Padding = UDim.new(0, 8);
    UIListLayout2.Parent = Frame3;
    u14.KeysRow = Frame3;
    local TextLabel6 = Instance.new("TextLabel");
    TextLabel6.BackgroundTransparency = 1;
    TextLabel6.Font = Bangers;
    TextLabel6.TextSize = 15;
    TextLabel6.TextColor3 = Color3_fromRGB_ret5;
    TextLabel6.TextXAlignment = Enum.TextXAlignment.Left;
    TextLabel6.Text = "";
    TextLabel6.Parent = Frame;
    TextLabel6.TextStrokeColor3 = Color3_fromRGB_ret6;
    TextLabel6.TextStrokeTransparency = 0.5;
    TextLabel6.Name = "Footnote";
    TextLabel6.Position = UDim2.new(0, 18, 1, -38);
    TextLabel6.Size = UDim2.new(0.62, 0, 0, 24);
    TextLabel6.Visible = false;
    u14.Footnote = TextLabel6;
    local TextButton = Instance.new("TextButton");
    TextButton.Name = "Continue";
    TextButton.AnchorPoint = Vector2.new(1, 1);
    TextButton.Position = UDim2.new(1, -18, 1, -14);
    TextButton.Size = UDim2.fromOffset(130, 32);
    TextButton.BackgroundColor3 = Color3_fromRGB_ret2;
    TextButton.BorderSizePixel = 0;
    TextButton.TextColor3 = Color3_fromRGB_ret3;
    TextButton.Font = Arcade;
    TextButton.TextSize = 18;
    TextButton.Text = "CONTINUE";
    TextButton.AutoButtonColor = true;
    TextButton.TextStrokeColor3 = Color3_fromRGB_ret6;
    TextButton.TextStrokeTransparency = 0.5;
    TextButton.Parent = Frame;
    local UIStroke = Instance.new("UIStroke");
    UIStroke.Color = Color3_fromRGB_ret6;
    UIStroke.Thickness = 1.5;
    UIStroke.Parent = TextButton;
    u14.Button = TextButton;

    if v13.ProgressBar then
        local Frame4 = Instance.new("Frame");
        Frame4.Name = "BarBack";
        Frame4.AnchorPoint = Vector2.new(0.5, 1);
        Frame4.Position = UDim2.new(0.5, 0, 1, 0);
        Frame4.Size = UDim2.new(1, 0, 0, 5);
        Frame4.BackgroundColor3 = Color3.fromRGB(26, 26, 27);
        Frame4.BorderSizePixel = 0;
        Frame4.Parent = Frame;
        local Frame5 = Instance.new("Frame");
        Frame5.Name = "BarFill";
        Frame5.Size = UDim2.new(0, 0, 1, 0);
        Frame5.BackgroundColor3 = Color3_fromRGB_ret8;
        Frame5.BorderSizePixel = 0;
        Frame5.Parent = Frame4;
        u14.BarFill = Frame5;
    end;

    return u14;
end;

function u1.Render(p17, p18) -- Line: 330
    -- upvalues: Arcade (copy), Color3_fromRGB_ret7 (copy), Color3_fromRGB_ret6 (copy), Bangers (copy), Color3_fromRGB_ret4 (copy), chip (copy), TweenService (copy)
    p17.NameLabel.Text = string.upper(p18.Speaker or "Kami");
    p17.Portrait.Image = p18.Portrait or "rbxassetid://85725203749860";
    p17.Counter.Text = p18.Counter or "";
    p17.Title.Text = string.upper(p18.Title or "");
    local v19 = p18.Rows ~= nil;
    p17.RowHolder.Visible = v19;
    p17.Objective.Visible = not v19;
    p17.Detail.Visible = not v19;

    if v19 then
        for _, v in ipairs(p17._rows) do
            v:Destroy();
        end;

        table.clear(p17._rows);

        for i, v in ipairs(p18.Rows) do
            local Frame = Instance.new("Frame");
            Frame.Size = UDim2.new(1, 0, 0, 46);
            Frame.BackgroundTransparency = 1;
            Frame.LayoutOrder = i;
            Frame.Parent = p17.RowHolder;
            local TextLabel = Instance.new("TextLabel");
            TextLabel.BackgroundTransparency = 1;
            TextLabel.Font = Arcade;
            TextLabel.TextSize = 19;
            TextLabel.TextColor3 = Color3_fromRGB_ret7;
            TextLabel.TextXAlignment = Enum.TextXAlignment.Left;
            TextLabel.Text = "";
            TextLabel.Parent = Frame;
            TextLabel.TextStrokeColor3 = Color3_fromRGB_ret6;
            TextLabel.TextStrokeTransparency = 0.5;
            TextLabel.Position = UDim2.fromOffset(0, 0);
            TextLabel.Size = UDim2.new(0.55, 0, 0, 22);
            TextLabel.Text = "[ " .. string.upper(v.Name or "") .. " ]";
            local TextLabel2 = Instance.new("TextLabel");
            TextLabel2.BackgroundTransparency = 1;
            TextLabel2.Font = Bangers;
            TextLabel2.TextSize = 17;
            TextLabel2.TextColor3 = Color3_fromRGB_ret4;
            TextLabel2.TextXAlignment = Enum.TextXAlignment.Left;
            TextLabel2.Text = "";
            TextLabel2.Parent = Frame;
            TextLabel2.TextStrokeColor3 = Color3_fromRGB_ret6;
            TextLabel2.TextStrokeTransparency = 0.5;
            TextLabel2.Position = UDim2.fromOffset(0, 22);
            TextLabel2.Size = UDim2.new(0.62, 0, 0, 22);
            TextLabel2.Text = v.Desc or "";
            TextLabel2.TextWrapped = true;
            local Frame2 = Instance.new("Frame");
            Frame2.AnchorPoint = Vector2.new(1, 0);
            Frame2.Position = UDim2.new(1, 0, 0, 4);
            Frame2.Size = UDim2.new(0.36, 0, 0, 28);
            Frame2.BackgroundTransparency = 1;
            Frame2.Parent = Frame;
            local UIListLayout = Instance.new("UIListLayout");
            UIListLayout.FillDirection = Enum.FillDirection.Horizontal;
            UIListLayout.HorizontalAlignment = Enum.HorizontalAlignment.Right;
            UIListLayout.Padding = UDim.new(0, 8);
            UIListLayout.Parent = Frame2;

            for _, v2 in ipairs(v.Keys or {}) do
                chip(Frame2, v2);
            end;

            table.insert(p17._rows, Frame);
        end;
    else
        p17.Objective.Text = p18.Objective and ("[ " .. string.upper(p18.Objective) .. " ]" or "") or "";
        p17.Detail.Text = p18.Detail or "";
    end;

    for _, child in ipairs(p17.KeysRow:GetChildren()) do
        if child:IsA("TextLabel") then
            child:Destroy();
        end;
    end;

    for _, v in ipairs(p18.Keys or {}) do
        chip(p17.KeysRow, v);
    end;

    p17.Footnote.Text = p18.Footnote or "";
    p17.Footnote.Visible = p18.Footnote ~= nil;
    p17.KeysRow.Visible = p18.Footnote == nil;
    p17.Button.Text = p18.Button or "CONTINUE";
    p17.Button.Visible = p18.Button ~= false;

    if p17.BarFill and p18.Progress then
        TweenService:Create(p17.BarFill, TweenInfo.new(0.4, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
            Size = UDim2.new(math.clamp(p18.Progress, 0, 1), 0, 1, 0)
        }):Play();
    end;
end;

function u1.SlideIn(p20) -- Line: 411
    -- upvalues: TweenService (copy)
    p20.Card.Visible = true;
    p20.Card.Position = UDim2.new(0.5, 0, 1, math.abs(p20.RestY) + 68);
    TweenService:Create(p20.Card, TweenInfo.new(0.35, Enum.EasingStyle.Back, Enum.EasingDirection.Out), {
        Position = UDim2.new(0.5, 0, 1, p20.RestY)
    }):Play();
end;

function u1.Dismiss(u21, u22) -- Line: 421
    -- upvalues: TweenService (copy)
    if u21._dismissed then
        return;
    end;

    u21._dismissed = true;
    TweenService:Create(u21.Card, TweenInfo.new(0.25, Enum.EasingStyle.Quad, Enum.EasingDirection.In), {
        Position = UDim2.new(0.5, 0, 1, math.abs(u21.RestY) + 88)
    }):Play();
    task.delay(0.3, function() -- Line: 429
        -- upvalues: u21 (copy), u22 (copy)
        u21:Destroy();

        if u22 then
            u22();
        end;
    end);
end;

function u1.Destroy(p23) -- Line: 435
    if p23._fitConn then
        p23._fitConn:Disconnect();
        p23._fitConn = nil;
    end;

    if p23.Gui then
        p23.Gui:Destroy();
        p23.Gui = nil;
    end;
end;

return u1;