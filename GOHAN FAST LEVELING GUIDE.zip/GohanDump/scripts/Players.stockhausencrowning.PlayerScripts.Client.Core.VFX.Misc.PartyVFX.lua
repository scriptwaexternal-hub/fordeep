-- Decompiled with Potassium's decompiler.

local ReplicatedStorage = game:GetService("ReplicatedStorage");
game:GetService("UserInputService");
local Debris = game:GetService("Debris");
game:GetService("Players");
local Modules = ReplicatedStorage:WaitForChild("Modules");
ReplicatedStorage:WaitForChild("Remotes");
local Assets = ReplicatedStorage.Assets;
local _ = Modules.Metadata;
local Shared = Modules.Shared;
require(Modules.Utility.Create);
local GlobalFunctions = require(Modules.GlobalFunctions);
require(Shared.SoundManager);
local _ = workspace.World.Visuals;

return {
    ["Send Energy"] = function(p1) -- Line: 30
        -- upvalues: Assets (copy), Debris (copy), GlobalFunctions (copy)
        local Character = p1.Character;
        local FriendCharacter = p1.FriendCharacter;
        local v2 = Assets.Effects.Beams["Give Energy Effect"]:Clone();
        Debris:AddItem(v2, 2);
        local Attachment = Instance.new("Attachment");
        Attachment.Name = "SendAttachment";
        local Attachment2 = Instance.new("Attachment");
        Attachment2.Name = "SendAttachment";
        local RootAndHumanoid, _ = GlobalFunctions.GetRootAndHumanoid(Character);
        local RootAndHumanoid2, _ = GlobalFunctions.GetRootAndHumanoid(FriendCharacter);
        Attachment.Parent = RootAndHumanoid;
        Attachment2.Parent = RootAndHumanoid2;

        for _, child in pairs(v2:GetChildren()) do
            if child:IsA("Beam") then
                child.Parent = Attachment;
                child.Attachment0 = Attachment;
                child.Attachment1 = Attachment2;
            end;
        end;
    end,

    ["Stop Energy"] = function(p3) -- Line: 57
        -- upvalues: Debris (copy)
        local FriendCharacter = p3.FriendCharacter;

        for _, descendant in pairs(p3.Character:GetDescendants()) do
            if descendant.Name == "SendAttachment" then
                for _, child in pairs(descendant:GetChildren()) do
                    if child:IsA("Beam") then
                        child.Enabled = false;
                    end;
                end;

                Debris:AddItem(descendant, 1);
            end;
        end;

        for _, descendant in pairs(FriendCharacter:GetDescendants()) do
            if descendant.Name == "SendAttachment" then
                for _, child in pairs(descendant:GetChildren()) do
                    if child:IsA("Beam") then
                        child.Enabled = false;
                    end;
                end;

                Debris:AddItem(descendant, 1);
            end;
        end;
    end
};