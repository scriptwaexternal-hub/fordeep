-- Decompiled with Potassium's decompiler.

local LocalPlayer = game:GetService("Players").LocalPlayer;
local Color3_fromRGB_ret = Color3.fromRGB(28, 28, 30);
local Color3_fromRGB_ret2 = Color3.fromRGB(216, 213, 205);
local Color3_fromRGB_ret3 = Color3.fromRGB(226, 62, 48);
local Color3_fromRGB_ret4 = Color3.fromRGB(0, 0, 0);
local ScreenGui = Instance.new("ScreenGui");
ScreenGui.Name = "KiJammedBadge";
ScreenGui.ResetOnSpawn = false;
ScreenGui.IgnoreGuiInset = false;
ScreenGui.DisplayOrder = 30;
ScreenGui.Enabled = false;
ScreenGui.Parent = LocalPlayer:WaitForChild("PlayerGui");
local Frame = Instance.new("Frame");
Frame.AnchorPoint = Vector2.new(0.5, 0);
Frame.Position = UDim2.new(0.5, 0, 0, 68);
Frame.Size = UDim2.fromOffset(118, 22);
Frame.BackgroundColor3 = Color3_fromRGB_ret;
Frame.BackgroundTransparency = 0.15;
Frame.BorderSizePixel = 0;
Frame.Parent = ScreenGui;
local UICorner = Instance.new("UICorner");
UICorner.CornerRadius = UDim.new(0, 4);
UICorner.Parent = Frame;
local UIStroke = Instance.new("UIStroke");
UIStroke.Color = Color3_fromRGB_ret4;
UIStroke.Thickness = 2;
UIStroke.Parent = Frame;
local Frame2 = Instance.new("Frame");
Frame2.Size = UDim2.fromOffset(8, 8);
Frame2.Position = UDim2.new(0, 8, 0.5, -4);
Frame2.BackgroundColor3 = Color3_fromRGB_ret3;
Frame2.BorderSizePixel = 0;
Frame2.Parent = Frame;
local UICorner2 = Instance.new("UICorner");
UICorner2.CornerRadius = UDim.new(1, 0);
UICorner2.Parent = Frame2;
local TextLabel = Instance.new("TextLabel");
TextLabel.BackgroundTransparency = 1;
TextLabel.Position = UDim2.new(0, 22, 0, 0);
TextLabel.Size = UDim2.new(1, -28, 1, 0);
TextLabel.Font = Enum.Font.Arcade;
TextLabel.Text = "KI JAMMED";
TextLabel.TextSize = 14;
TextLabel.TextColor3 = Color3_fromRGB_ret2;
TextLabel.TextXAlignment = Enum.TextXAlignment.Left;
TextLabel.Parent = Frame;

local function safeGui() -- Line: 40
    -- upvalues: LocalPlayer (copy)
    for _, child in ipairs(LocalPlayer.PlayerGui:GetChildren()) do
        if child:IsA("ScreenGui") and child.Name == "SafeZoneBadge" then
            return child;
        end;
    end;

    return nil;
end;

local function place() -- Line: 49
    -- upvalues: safeGui (copy), Frame (copy)
    local v1 = safeGui();

    if v1 then
        v1 = v1.Enabled;
    end;

    Frame.Position = UDim2.new(0.5, 0, 0, 68 + (v1 and 26 or 0));
end;

local function refresh(p2) -- Line: 56
    -- upvalues: ScreenGui (copy), safeGui (copy), Frame (copy)
    if p2 then
        p2 = p2:GetAttribute("KiJammed");
    end;

    ScreenGui.Enabled = p2 == true;
    local v3 = safeGui();

    if v3 then
        v3 = v3.Enabled;
    end;

    Frame.Position = UDim2.new(0.5, 0, 0, 68 + (v3 and 26 or 0));
end;

local u4 = nil;

local function bind(u5) -- Line: 63
    -- upvalues: u4 (ref), ScreenGui (copy), safeGui (copy), Frame (copy)
    if u4 then
        u4:Disconnect();
    end;

    u4 = u5:GetAttributeChangedSignal("KiJammed"):Connect(function() -- Line: 65
        -- upvalues: u5 (copy), ScreenGui (ref), safeGui (ref), Frame (ref)
        local v6 = u5;

        if v6 then
            v6 = v6:GetAttribute("KiJammed");
        end;

        ScreenGui.Enabled = v6 == true;
        local v7 = safeGui();

        if v7 then
            v7 = v7.Enabled;
        end;

        Frame.Position = UDim2.new(0.5, 0, 0, 68 + (v7 and 26 or 0));
    end);

    if u5 then
        u5 = u5:GetAttribute("KiJammed");
    end;

    ScreenGui.Enabled = u5 == true;
    local v8 = safeGui();

    if v8 then
        v8 = v8.Enabled;
    end;

    Frame.Position = UDim2.new(0.5, 0, 0, 68 + (v8 and 26 or 0));
end;

if LocalPlayer.Character then
    bind(LocalPlayer.Character);
end;

LocalPlayer.CharacterAdded:Connect(bind);
LocalPlayer.CharacterRemoving:Connect(function() -- Line: 71
    -- upvalues: ScreenGui (copy)
    ScreenGui.Enabled = false;
end);
task.spawn(function() -- Line: 74
    -- upvalues: safeGui (copy), place (copy), Frame (copy)
    local v9 = safeGui();
    local os_clock_ret = os.clock();

    while not v9 and os.clock() - os_clock_ret < 30 do
        task.wait(0.5);
        v9 = safeGui();
    end;

    if v9 then
        v9:GetPropertyChangedSignal("Enabled"):Connect(place);
    end;

    local v10 = safeGui();

    if v10 then
        v10 = v10.Enabled;
    end;

    Frame.Position = UDim2.new(0.5, 0, 0, 68 + (v10 and 26 or 0));
end);