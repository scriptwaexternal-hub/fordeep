-- Decompiled with Potassium's decompiler.

local u1 = {
    Items = {
        ["Scouter:V1"] = {
            Model = "Scouter:V1",
            Distance = 5,
            PromptText = "Pick Up"
        },
        ["Scouter:V2"] = {
            Model = "Scouter:V2",
            Distance = 5,
            PromptText = "Pick Up"
        },
        ["Scouter:V3"] = {
            Model = "Scouter:V3",
            Distance = 5,
            PromptText = "Pick Up"
        },
        ["Divine Water"] = {
            Model = "Divine Water",
            Distance = 5,
            PromptText = "Pick Up"
        },
        ["Beacon Scrap"] = {
            Model = "Beacon Scrap",
            Distance = 5,
            PromptText = "Pick Up"
        },
        ["Sub-Commander Core"] = {
            Model = "Sub-Commander Core",
            Distance = 5,
            PromptText = "Pick Up"
        },
        ["Backup Beacon Core"] = {
            Model = "Backup Beacon Core",
            Distance = 5,
            PromptText = "Pick Up"
        }
    }
};

function u1.Get(p2) -- Line: 43
    -- upvalues: u1 (copy)
    if type(p2) == "string" then
        return u1.Items[p2];
    end;

    return nil;
end;

return u1;