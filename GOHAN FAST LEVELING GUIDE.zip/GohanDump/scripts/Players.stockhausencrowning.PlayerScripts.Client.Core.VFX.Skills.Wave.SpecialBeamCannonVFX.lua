-- Decompiled with Potassium's decompiler.

local Debris = game:GetService("Debris");
local ReplicatedStorage = game:GetService("ReplicatedStorage");
local Modules = ReplicatedStorage:WaitForChild("Modules");
local SoundManager = require(Modules.Shared.SoundManager);
local GlobalFunctions = require(Modules.GlobalFunctions);
local Effects = ReplicatedStorage.Assets.Effects;

return {
    Effect = function(p1) -- Line: 22
        -- upvalues: GlobalFunctions (copy), Effects (copy), SoundManager (copy), Debris (copy)
        local Character = p1.Character;

        if not Character then
            return;
        end;

        local RootAndHumanoid = GlobalFunctions.GetRootAndHumanoid(Character);

        if not RootAndHumanoid then
            return;
        end;

        local v2 = Character:FindFirstChild("Right Arm") or RootAndHumanoid;
        local u3 = Effects.Skills.Wave["Special Beam_FX"].BeamFX:Clone();
        u3.Parent = v2;
        SoundManager.AddSound("Electric Arc", {
            Parent = RootAndHumanoid
        }, "Client");
        task.spawn(function() -- Line: 42
            -- upvalues: Character (copy), u3 (copy), Debris (ref)
            local v4 = os.clock() + 6;

            while os.clock() < v4 and (Character:GetAttribute("State_ChargingBeam") ~= nil and u3.Parent) do
                task.wait();
            end;

            Debris:AddItem(u3, 0.5);
        end);
    end
};