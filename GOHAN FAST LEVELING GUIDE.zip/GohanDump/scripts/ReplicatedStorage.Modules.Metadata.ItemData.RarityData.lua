-- Decompiled with Potassium's decompiler.

local u1 = {
    Order = { "Common", "Uncommon", "Rare", "Epic", "Legendary" },
    Colors = {
        Common = Color3.fromRGB(226, 223, 216),
        Uncommon = Color3.fromRGB(120, 214, 126),
        Rare = Color3.fromRGB(84, 162, 255),
        Epic = Color3.fromRGB(186, 118, 255),
        Legendary = Color3.fromRGB(255, 186, 64)
    },
    Items = {
        Scrap = "Common",
        Claw = "Common",
        Gear = "Common",
        ["Tech Chip"] = "Common",
        ["Energy Cell"] = "Uncommon",
        ["Golden Gear"] = "Uncommon",
        Remote = "Uncommon",
        ["Capsule Casing"] = "Uncommon",
        ["Divine Water"] = "Rare",
        Engine = "Rare",
        ["Saibamen Egg"] = "Rare",
        ["Tier 3 Book"] = "Rare",
        Wires = "Rare",
        ["Gravity Chamber Ticket"] = "Epic",
        ["Tier 2 Book"] = "Epic",
        ["Tier 1 Book"] = "Epic",
        ["Senzu Bean"] = "Epic",
        ["Scouter:V1"] = "Legendary",
        ["Gravity Machine"] = "Legendary",
        ["Shut Down Remote"] = "Legendary"
    }
};

function u1.Of(p2) -- Line: 44
    -- upvalues: u1 (copy)
    return u1.Items[p2] or "Common";
end;

function u1.ColorOf(p3) -- Line: 48
    -- upvalues: u1 (copy)
    return u1.Colors[u1.Of(p3)] or u1.Colors.Common;
end;

return u1;