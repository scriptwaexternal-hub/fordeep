-- Decompiled with Potassium's decompiler.

local UI = require(script.Parent:WaitForChild("UI"));
local v1 = {};
v1.__index = v1;

function v1.new(u2) -- Line: 6
    -- upvalues: UI (copy)
    local u3 = UI.new("Scroller")({
        Name = "Market"
    });
    task.defer(function() -- Line: 11
        -- upvalues: u2 (copy), UI (ref), u3 (copy)
        local Attribute = u2.LocalPlayer:GetAttribute("_KDonationLevel");
        local u4 = {};
        local u11 = u2.Util.Function.debounce(0.25, function(p5, p6, p7, p8, p9) -- Line: 15
            -- upvalues: u4 (copy), u2 (ref)
            local v10 = u4[p6];

            if v10 and v10 ~= p9 then
                v10.BackgroundColor3(Color3.fromRGB(0, 200, 0));
                v10.Label("<b>WEAR</b>");
            end;

            if p7 then
                u4[p6] = p9;
                p9.BackgroundColor3(Color3.fromRGB(200, 0, 0));
                p9.Label("<b>HIDE</b>");
            else
                u4[p6] = nil;
                p9.BackgroundColor3(Color3.fromRGB(0, 200, 0));
                p9.Label("<b>WEAR</b>");
            end;

            u2.Remote.VIPUGCMethod:Fire(p5, p6, p7, p8);
        end);
        local u12 = u2.DEBUG and u2.IsStudio;

        local function updateAssetPriceText(u13: userdata, u14: number, u15: string?) -- Line: 40
            -- upvalues: u2 (ref), u12 (copy)
            local v16, u17 = u2.Util.Retry(function() -- Line: 41
                -- upvalues: u2 (ref), u14 (copy)
                return u2.Service.Marketplace:PlayerOwnsAssetAsync(u2.LocalPlayer, u14);
            end);

            if v16 then
                if u17 and not u12 then
                    u13.Text = u15 or "<b>OWNED</b>";
                    u13.TextTransparency = 0.5;

                    return;
                end;

                local u18 = nil;
                u18 = u2.Service.Marketplace.PromptBulkPurchaseFinished:Connect(function(p19, p20, p21) -- Line: 53
                    -- upvalues: u2 (ref), u14 (copy), u18 (ref), u17 (ref), u13 (copy), u15 (copy)
                    if p19 ~= u2.LocalPlayer or p21.Items[1].id ~= tostring(u14) then
                        return;
                    end;

                    if p20 == Enum.MarketplaceBulkPurchasePromptStatus.Completed then
                        u18:Disconnect();
                        u17 = true;
                        u13.Text = u15 or "<b>OWNED</b>";
                        u13.TextTransparency = 0.5;
                    end;
                end);
                local v22, v23 = u2.Util.Retry(function() -- Line: 65
                    -- upvalues: u2 (ref), u14 (copy)
                    return u2.Service.Marketplace:GetProductInfoAsync(u14, Enum.InfoType.Asset).PriceInRobux;
                end);

                if v22 and (not u17 or u12) then
                    u13.Text = `<b>{v23 or "?"}</b>`;
                end;
            end;
        end;

        local function updatePassPriceText(u24: userdata, u25: number, u26: string?) -- Line: 76
            -- upvalues: u2 (ref), u12 (copy)
            local v27, u28 = u2.Util.Retry(function() -- Line: 77
                -- upvalues: u2 (ref), u25 (copy)
                return u2.Service.Marketplace:UserOwnsGamePassAsync(u2.LocalPlayer.UserId, u25);
            end);

            if v27 then
                if u28 and not u12 then
                    u24.Text = u26 or "<b>OWNED</b>";
                    u24.TextTransparency = 0.5;

                    return;
                end;

                local u29 = nil;
                u29 = u2.Service.Marketplace.PromptGamePassPurchaseFinished:Connect(function(p30, p31, p32) -- Line: 89
                    -- upvalues: u25 (copy), u2 (ref), u29 (ref), u28 (ref), u24 (copy), u26 (copy)
                    if p32 and (p31 == u25 and p30 == u2.LocalPlayer.UserId) then
                        u29:Disconnect();
                        u28 = true;
                        u24.Text = u26 or "<b>OWNED</b>";
                        u24.TextTransparency = 0.5;
                    end;
                end);
                local v33, v34 = u2.Util.Retry(function() -- Line: 98
                    -- upvalues: u2 (ref), u25 (copy)
                    return u2.Service.Marketplace:GetProductInfoAsync(u25, Enum.InfoType.GamePass).PriceInRobux;
                end);

                if v33 and (not u28 or u12) then
                    u24.Text = `<b>{v34 or "?"}</b>`;
                end;
            end;
        end;

        local function updateTitleLabel(p35: any, p36: string, p37: string?) -- Line: 109
            -- upvalues: UI (ref)
            local string_lower_ret = string.lower(p36);
            local v38 = shared._KVIPTitle.definition[string_lower_ret];
            local Label = p35._content.Label;
            UI.new("Spacer")({
                LayoutOrder = 2,
                Parent = p35._content
            });
            UI.edit(Label, {
                AutomaticSize = Enum.AutomaticSize.X,
                Size = UDim2.new(0, 0, 1, 0),
                FontFace = Font.fromEnum(Enum.Font.FredokaOne),
                TextSize = UI.Theme.FontSizeLarge,
                TextColor3 = Color3.new(1, 1, 1)
            });
            Label.UIFlexItem.FlexMode = Enum.UIFlexMode.Shrink;

            if not v38 then
                UI.new("UIStroke")({
                    Thickness = 1,
                    Parent = Label
                });

                return;
            end;

            Label.Name = "Title";
            Label.Text = `<stroke thickness="1">{p36}</stroke>{p37 or ""}`;
            UI.new("UIGradient")({
                Parent = Label,
                Color = ColorSequence.new(v38.topColor or Color3.new(1, 1, 1), v38.color or Color3.new(1, 1, 1)),
                Rotation = v38.rotation or 90
            });
            p35._content:AddTag("_K" .. string_lower_ret);
        end;

        local u39 = UI.new("Frame")({
            Name = "UGC",
            AutomaticSize = Enum.AutomaticSize.Y,
            BackgroundTransparency = 1,
            Size = UDim2.new(1, -2, 0, 0),
            UI.new("UIListLayout")({
                Wraps = true,
                SortOrder = Enum.SortOrder.LayoutOrder,
                FillDirection = Enum.FillDirection.Horizontal,
                HorizontalFlex = Enum.UIFlexAlignment.SpaceEvenly,
                HorizontalAlignment = Enum.HorizontalAlignment.Center,
                Padding = UI.Theme.PaddingWithStroke
            })
        });

        for i, v in u2.VIP.purchasables.scriptedUGC do
            task.defer(function() -- Line: 167
                -- upvalues: Attribute (ref), v (copy), UI (ref), u39 (copy), i (copy), u2 (ref), u4 (copy), u11 (copy)
                local u40 = (Attribute or 0) >= (v.level or 3);
                v.price = u40 and "WEAR" or "?";
                local v41 = UI.new("Frame")({
                    Parent = u39,
                    LayoutOrder = i,
                    AutomaticSize = Enum.AutomaticSize.XY,
                    BackgroundTransparency = 1,
                    UI.new("ImageLabel")({
                        BackgroundColor3 = Color3.new(0, 0, 0),
                        BackgroundTransparency = 0.875,
                        Size = UDim2.new(0, 80, 0, 80),
                        Image = "rbxasset://textures/meshPartFallback.png",
                        ImageTransparency = 0.75,
                        ScaleType = Enum.ScaleType.Tile,
                        TileSize = UDim2.fromOffset(16, 16),
                        UI.new("UICorner")({
                            CornerRadius = UI.Theme.CornerPadded
                        }),
                        UI.new("Stroke")({}),
                        UI.new("ImageLabel")({
                            BackgroundTransparency = 1,
                            Size = UDim2.new(1, 0, 1, 0),
                            Image = `rbxthumb://type=Asset&id={v.id}&w=150&h=150`,
                            UI.new("ImageLabel")({
                                BackgroundTransparency = 1,
                                Image = "rbxasset://textures/ui/InspectMenu/ico_favorite@2x.png",
                                ImageTransparency = 0.875,
                                Size = UDim2.new(0, 28, 0, 28),
                                Position = UDim2.new(0, 2, 0, 2),
                                ImageColor3 = Color3.new(0, 0, 0)
                            }),
                            UI.new("ImageButton")({
                                BackgroundTransparency = 1,
                                Position = UDim2.new(0, 4, 0, 4),
                                Size = UDim2.new(0, 24, 0, 24),
                                Image = "rbxasset://textures/ui/InspectMenu/ico_favorite@2x.png",
                                ImageColor3 = Color3.new(1, 0.8, 0),

                                Activated = function() -- Line: 210, Name: Activated
                                    -- upvalues: u2 (ref), v (ref)
                                    pcall(function() -- Line: 211
                                        -- upvalues: u2 (ref), v (ref)
                                        u2.Service.AvatarEditor:PromptSetFavorite(v.id, 1, true);
                                    end);
                                end,

                                UI.new("Tooltip")({
                                    Text = "Add to Favorites"
                                })
                            })
                        })
                    })
                });
                local u42 = nil;
                local u43 = nil;
                local u44 = nil;

                local function tryDone() -- Line: 224
                    -- upvalues: u44 (ref), u40 (ref), u42 (ref), v (ref)
                    u44 = nil;

                    if not u40 then
                        u42.Label((`<b>{v.price}</b>`));
                        u42._content.IconFrame.Visible = true;
                        u42._content.Label.TextXAlignment = Enum.TextXAlignment.Left;
                    end;
                end;

                local Button = UI.new("Button");
                local v45 = {
                    Parent = v41,
                    Icon = not u40 and "rbxasset://textures/ui/common/robux.png" or nil,
                    IconProperties = {
                        ImageColor3 = UI.Theme.PrimaryText
                    },
                    IconRightAlign = not u40,
                    Label = `<b>{v.price}</b>`
                };
                local v46 = {
                    FontFace = UI.Theme.FontMono,
                    TextSize = UI.Theme.FontSizeLarge
                };
                local v47;

                if u40 then
                    v47 = nil;
                else
                    v47 = Enum.TextXAlignment.Left;
                end;

                v46.TextXAlignment = v47;
                v46.TextTruncate = Enum.TextTruncate.None;
                v45.LabelProperties = v46;
                v45.BackgroundColor3 = Color3.fromRGB(0, 200, 0);
                v45.BackgroundTransparency = 0.5;
                v45.Size = UDim2.new(0, 80, 0, 32);
                v45.Position = UDim2.fromOffset(0, 88);
                v45[UI.Attribute] = {
                    Price = v.price
                };

                function v45.Activated() -- Line: 254
                    -- upvalues: u43 (ref), u44 (ref), u4 (ref), v (ref), u11 (ref), u42 (ref), tryDone (copy), u2 (ref), u40 (ref)
                    if not u43 then
                        local v48 = u4[v.equip];

                        if not (u40 or u44 and v48 == u42) then
                            u2.PromptBulkPurchase(v.id);

                            return;
                        end;

                        if v48 then
                            v48 = v48 == u42;
                        end;

                        u11(v.id, v.equip, not v48, v.name, u42);

                        if u44 and v48 then
                            task.delay(0.25, tryDone);
                        end;

                        return;
                    end;

                    u43 = nil;
                    u44 = true;
                    local u49 = u4[v.equip];
                    u11(v.id, v.equip, true, v.name, u42);
                    task.delay(15, function() -- Line: 259
                        -- upvalues: u44 (ref), u4 (ref), v (ref), u42 (ref), u11 (ref), tryDone (ref)
                        if u44 and u4[v.equip] == u42 then
                            u11(v.id, v.equip, false, v.name, u42);
                        end;

                        task.delay(0.25, tryDone);
                    end);
                    u2.Notify({
                        From = "_K",
                        Duration = 15,
                        Text = `Trying <b>{v.name}</b>.`
                    });

                    if u49 and u49 ~= u42 then
                        task.delay(0.25, function() -- Line: 272
                            -- upvalues: u49 (copy)
                            u49.Label((`<b>{u49._instance:GetAttribute("Price")}</b>`));
                            u49._content.IconFrame.Visible = true;
                            u49._content.Label.TextXAlignment = Enum.TextXAlignment.Left;
                        end);
                    end;
                end;

                u42 = Button(v45);

                if not u40 then
                    u43 = true;
                    u42.Label("<b>TRY</b>");
                    u42._content.IconFrame.Visible = false;
                    u42._content.Label.TextXAlignment = Enum.TextXAlignment.Center;
                    local u50 = nil;
                    local u51 = nil;

                    local function setOwned() -- Line: 303
                        -- upvalues: u50 (ref), u51 (ref), u40 (ref), u43 (ref), u42 (ref)
                        if u50 then
                            u50:Disconnect();
                            u50 = nil;
                        end;

                        if u51 then
                            u51:Disconnect();
                            u51 = nil;
                        end;

                        u40 = true;
                        u43 = nil;
                        u42.Label("<b>WEAR</b>");
                        u42._content.IconFrame.Visible = false;
                        u42._content.Label.TextXAlignment = Enum.TextXAlignment.Center;
                    end;

                    u50 = u2.Service.Marketplace.PromptPurchaseFinished:Connect(function(p52, p53, p54) -- Line: 318
                        -- upvalues: v (ref), u2 (ref), setOwned (copy)
                        if p54 and (p53 == v.id and p52 == u2.LocalPlayer) then
                            setOwned();
                        end;
                    end);
                    u51 = u2.LocalPlayer:GetAttributeChangedSignal("_KDonationLevel"):Connect(function() -- Line: 324
                        -- upvalues: Attribute (ref), u2 (ref), v (ref), setOwned (copy)
                        Attribute = math.max(Attribute or 0, u2.LocalPlayer:GetAttribute("_KDonationLevel"));

                        if (Attribute or 0) >= (v.level or 3) then
                            setOwned();
                        end;
                    end);
                    task.spawn(function() -- Line: 331
                        -- upvalues: u2 (ref), u40 (ref), v (ref), setOwned (copy)
                        local v55, v56 = u2.Util.Retry(function() -- Line: 332
                            -- upvalues: u40 (ref), u2 (ref), v (ref)
                            return u40 and true or u2.Service.Marketplace:PlayerOwnsAssetAsync(u2.LocalPlayer, v.id);
                        end);

                        if v55 and v56 then
                            setOwned();
                        end;
                    end);
                    local v57, v58 = u2.Util.Retry(function() -- Line: 343
                        -- upvalues: u2 (ref), v (ref)
                        return u2.Service.Marketplace:GetProductInfoAsync(v.id, Enum.InfoType.Asset).PriceInRobux;
                    end);

                    if v57 then
                        v.price = v58 or "?";
                        u42._instance:SetAttribute("Price", v.price);
                    end;
                end;

                if v.tip then
                    UI.new("Tooltip")({
                        Parent = u42._instance,
                        Text = v.tip,
                        Hovering = u42._hovering
                    });
                end;
            end);
        end;

        local v59 = UI.new("Frame")({
            Name = "GamePasses",
            AutomaticSize = Enum.AutomaticSize.Y,
            BackgroundTransparency = 1,
            Size = UDim2.new(1, -2, 0, 0),
            UI.new("UIListLayout")({
                Wraps = true,
                SortOrder = Enum.SortOrder.LayoutOrder,
                FillDirection = Enum.FillDirection.Horizontal,
                HorizontalFlex = Enum.UIFlexAlignment.SpaceEvenly,
                HorizontalAlignment = Enum.HorizontalAlignment.Center,
                Padding = UI.Theme.PaddingWithStroke
            })
        });
        local u60 = {};

        local function donorEquip(p61, p62, p63) -- Line: 381
            -- upvalues: u60 (copy)
            local v64 = u60[p63];

            if v64 then
                v64._content.Price.Text = "<b>SHOW</b>";
            end;

            if v64 == p62 then
                u60[p63] = nil;
                p63:Fire();

                return;
            end;

            u60[p63] = p62;
            p62._content.Price.Text = "<b>HIDE</b>";
            p63:Fire(p61);
        end;

        local function generateDonationButtons(p65: userdata) -- Line: 396
            -- upvalues: u2 (ref), UI (ref), u60 (copy), updateTitleLabel (copy), u12 (copy), updateAssetPriceText (copy)
            for i, v in u2.VIP.purchasables.donations do
                local u66;

                if u2.Data.settings.vip and i > 4 then
                    u66 = u2.Remote.Title;
                else
                    u66 = u2.Remote.DonorTrail;
                end;

                local u67 = nil;
                u67 = UI.new("Button")({
                    Parent = p65,
                    LayoutOrder = i,
                    Icon = "rbxasset://textures/ui/common/robux.png",
                    IconProperties = {
                        ImageColor3 = UI.Theme.PrimaryText
                    },
                    IconRightAlign = true,
                    Label = `<font color='{v.color}'><b>{v.name}</b></font>`,
                    TextXAlignment = Enum.TextXAlignment.Left,
                    Size = UDim2.new(0, 128, 0, 32),
                    UI.new("TextLabel")({
                        Name = "Price",
                        LayoutOrder = 8,
                        AutoLocalize = false,
                        BackgroundTransparency = 1,
                        TextWrapped = true,
                        Text = "?",
                        RichText = true,
                        AutomaticSize = Enum.AutomaticSize.XY,
                        FontFace = UI.Theme.FontMono,
                        TextSize = UI.Theme.FontSizeLarge,
                        TextColor3 = UI.Theme.PrimaryText,
                        TextStrokeColor3 = UI.Theme.Primary,
                        TextStrokeTransparency = UI.Theme.TextStrokeTransparency,

                        Size = function() -- Line: 423, Name: Size
                            -- upvalues: UI (ref)
                            return UDim2.new(0, UI.Theme.FontSizeLarge(), 0, 32);
                        end
                    }),

                    Activated = function() -- Line: 430, Name: Activated
                        -- upvalues: u67 (ref), v (copy), u66 (copy), u60 (ref), u2 (ref)
                        if u67._content.Price.Text ~= "<b>SHOW</b>" and u67._content.Price.Text ~= "<b>HIDE</b>" then
                            u2.PromptBulkPurchase(v.assetId);

                            return;
                        end;

                        local name = v.name;
                        local v68 = u67;
                        local v69 = u66;
                        local v70 = u60[v69];

                        if v70 then
                            v70._content.Price.Text = "<b>SHOW</b>";
                        end;

                        if v70 == v68 then
                            u60[v69] = nil;
                            v69:Fire();

                            return;
                        end;

                        u60[v69] = v68;
                        v68._content.Price.Text = "<b>HIDE</b>";
                        v69:Fire(name);
                    end
                });
                UI.new("UIFlexItem")({
                    Parent = u67._instance,
                    FlexMode = Enum.UIFlexMode.Fill
                });
                UI.new("Tooltip")({
                    Parent = u67._instance,
                    Text = `We've poured thousands of hours into Kohl's Admin.\nIf you enjoy it, please donate! ❤️\n\n<font color='#0f0'><b>{i > 5 and "Unlocks:</b></font>\n💬 Chat commands\n👑 All animated accessories\n✨ Custom particle effects\n😎 Exclusive title" or (i > 4 and "Unlocks:</b></font>\n💬 Chat commands\n👑 Floating crown\n✨ Custom particle effects\n😎 Exclusive title" or (i > 3 and "Unlocks:</b></font>\n💬 Chat commands\n✨ Custom particle effects" or "Unlocks a particle effect!</b></font>"))}`,
                    Hovering = u67._hovering
                });
                updateTitleLabel(u67, v.name);
                task.spawn(function() -- Line: 462
                    -- upvalues: u12 (ref), u2 (ref), v (copy), u67 (ref), updateAssetPriceText (ref)
                    if not u12 then
                        local v71, v72 = u2.Util.Retry(function() -- Line: 464
                            -- upvalues: u2 (ref), v (ref)
                            return u2.Service.Marketplace:UserOwnsGamePassAsync(u2.LocalPlayer.UserId, v.id);
                        end);

                        if v71 and v72 then
                            u67._content.Price.Text = "<b>SHOW</b>";

                            return;
                        end;
                    end;

                    updateAssetPriceText(u67._content.Price, v.assetId, "<b>SHOW</b>");
                end);
            end;
        end;

        u2.client.generateDonationButtons = generateDonationButtons;
        generateDonationButtons(v59);
        local v73 = UI.new("Frame")({
            Name = "VIP",
            AutomaticSize = Enum.AutomaticSize.Y,
            BackgroundTransparency = 1,
            Size = UDim2.new(1, -2, 0, 0),
            UI.new("UIListLayout")({
                Wraps = true,
                SortOrder = Enum.SortOrder.LayoutOrder,
                FillDirection = Enum.FillDirection.Horizontal,
                HorizontalAlignment = Enum.HorizontalAlignment.Center,
                Padding = UI.Theme.PaddingWithStroke
            })
        });
        local v74 = UI.compute(function() -- Line: 496
            -- upvalues: UI (ref)
            return UDim2.new(0.5, -UI.Theme.Padding().Offset, 0, 32);
        end);
        local u75;

        if u2.Data.roles.vip and u2.Data.roles.vip.gamepasses then
            u75 = u2.Data.roles.vip.gamepasses[1];
        else
            u75 = nil;
        end;

        local u76 = nil;
        u76 = UI.new("Button")({
            Parent = v73,
            LayoutOrder = 3,
            Icon = "rbxasset://textures/ui/common/robux.png",
            IconProperties = {
                ImageColor3 = UI.Theme.PrimaryText
            },
            IconRightAlign = true,
            Label = "VIP",
            TextXAlignment = Enum.TextXAlignment.Left,
            Size = v74,
            UI.new("TextLabel")({
                Name = "Price",
                LayoutOrder = 8,
                AutoLocalize = false,
                BackgroundTransparency = 1,
                TextWrapped = true,
                Text = "?",
                RichText = true,
                AutomaticSize = Enum.AutomaticSize.XY,
                FontFace = UI.Theme.FontMono,
                TextSize = UI.Theme.FontSizeLarge,
                TextColor3 = UI.Theme.PrimaryText,
                TextStrokeColor3 = UI.Theme.Primary,
                TextStrokeTransparency = UI.Theme.TextStrokeTransparency,

                Size = function() -- Line: 527, Name: Size
                    -- upvalues: UI (ref)
                    return UDim2.new(0, UI.Theme.FontSizeLarge(), 0, 32);
                end
            }),

            Activated = function() -- Line: 533, Name: Activated
                -- upvalues: u76 (ref), u2 (ref), u60 (copy)
                if u76._content.Price.Text ~= "<b>SHOW</b>" and u76._content.Price.Text ~= "<b>HIDE</b>" then
                    u2.PromptPurchaseVIP();

                    return;
                end;

                local v77 = u76;
                local Title = u2.Remote.Title;
                local v78 = u60[Title];

                if v78 then
                    v78._content.Price.Text = "<b>SHOW</b>";
                end;

                if v78 == v77 then
                    u60[Title] = nil;
                    Title:Fire();

                    return;
                end;

                u60[Title] = v77;
                v77._content.Price.Text = "<b>HIDE</b>";
                Title:Fire("VIP");
            end
        });
        UI.new("Tooltip")({
            Text = "✨ <b>Become a VIP</b>\n\n<font color=\'#0f0\'>Unlock <b>VIP commands</b> globally!</font>",
            Parent = u76,
            Hovering = u76._hovering
        });
        updateTitleLabel(u76, "VIP", "  <font transparency=\"0.75\"><stroke thickness=\"1\" transparency=\"0.75\">(Global)</stroke></font>");
        local v79 = UI.new("Button")({
            Parent = v73,
            LayoutOrder = 4,
            Icon = "rbxasset://textures/ui/common/robux.png",
            IconProperties = {
                ImageColor3 = UI.Theme.PrimaryText
            },
            IconRightAlign = true,
            Label = "VIP",
            TextXAlignment = Enum.TextXAlignment.Left,
            Size = v74,
            Visible = u75 and true or false,
            UI.new("TextLabel")({
                Name = "Price",
                LayoutOrder = 8,
                AutoLocalize = false,
                BackgroundTransparency = 1,
                TextWrapped = true,
                Text = "?",
                RichText = true,
                AutomaticSize = Enum.AutomaticSize.XY,
                FontFace = UI.Theme.FontMono,
                TextSize = UI.Theme.FontSizeLarge,
                TextColor3 = UI.Theme.PrimaryText,
                TextStrokeColor3 = UI.Theme.Primary,
                TextStrokeTransparency = UI.Theme.TextStrokeTransparency,

                Size = function() -- Line: 580, Name: Size
                    -- upvalues: UI (ref)
                    return UDim2.new(0, UI.Theme.FontSizeLarge(), 0, 32);
                end
            }),

            Activated = function() -- Line: 586, Name: Activated
                -- upvalues: u2 (ref), u75 (copy)
                u2.Service.Marketplace:PromptGamePassPurchase(u2.LocalPlayer, u75);
            end
        });
        updateTitleLabel(v79, "VIP", "  <font transparency=\"0.75\"><stroke thickness=\"1\" transparency=\"0.75\">(Game)</stroke></font>");
        task.defer(function() -- Line: 597
            -- upvalues: u2 (ref), updatePassPriceText (copy), u76 (ref), updateAssetPriceText (copy)
            local v80, v81 = u2.Util.Retry(function() -- Line: 598
                -- upvalues: u2 (ref)
                return u2.Service.Marketplace:UserOwnsGamePassAsync(u2.LocalPlayer.UserId, 5411126);
            end);

            if v80 and v81 then
                task.defer(updatePassPriceText, u76._content.Price, 5411126, "<b>SHOW</b>");

                return;
            end;

            local v82, v83 = u2.Util.Retry(function() -- Line: 606
                -- upvalues: u2 (ref)
                return u2.Service.Marketplace:PlayerOwnsAssetAsync(u2.LocalPlayer, 110019084552349);
            end);
            task.defer(updateAssetPriceText, u76._content.Price, 110019084552349, "<b>SHOW</b>");

            if not v82 or v83 then
                return;
            end;

            task.delay(600, updateAssetPriceText, u76._content.Price, 115444443724463, "<b>SHOW</b>");
        end);

        if u75 then
            task.defer(updatePassPriceText, v79._content.Price, u75);
        end;

        UI.edit(u3._instance, {
            UI.new("TextLabel")({
                Name = "Status",
                AutomaticSize = Enum.AutomaticSize.XY,
                BackgroundColor3 = Color3.new(1, 0, 0),
                BackgroundTransparency = 0.75,
                FontFace = UI.Theme.FontMono,
                TextSize = UI.Theme.FontSizeSmall,
                TextColor3 = Color3.new(1, 1, 1),
                Text = "<sc>VIP benefits are <b>disabled</b> in this game!</sc>",
                TextStrokeTransparency = UI.Theme.TextStrokeTransparency,
                TextWrapped = true,
                RichText = true,

                Visible = function() -- Line: 640, Name: Visible
                    -- upvalues: u2 (ref)
                    return not u2.client.settings.vip();
                end,

                UI.new("UICorner")({
                    CornerRadius = UI.Theme.CornerPadded
                }),
                UI.new("UIPadding")({
                    PaddingLeft = UI.Theme.Padding,
                    PaddingRight = UI.Theme.Padding,
                    PaddingTop = UI.Theme.PaddingHalf,
                    PaddingBottom = UI.Theme.PaddingHalf
                })
            }),
            UI.new("TextLabel")({
                AutoLocalize = false,
                BackgroundTransparency = 1,
                TextWrapped = true,
                Text = "<b>❤️ Kohl\'s Admin?</b>\n<font transparency=\'0.5\'>Donate for cool perks and more updates!</font>",
                RichText = true,
                AutomaticSize = Enum.AutomaticSize.Y,
                FontFace = UI.Theme.Font,
                TextSize = UI.Theme.FontSize,
                TextColor3 = UI.Theme.PrimaryText,
                TextStrokeColor3 = UI.Theme.Primary,
                TextStrokeTransparency = UI.Theme.TextStrokeTransparency,
                Size = UDim2.new(1, 0, 0, 0)
            }),
            v73,
            v59,
            u39,
            UI.new("TextLabel")({
                AutoLocalize = false,
                AutomaticSize = Enum.AutomaticSize.XY,
                BackgroundTransparency = 1,
                FontFace = UI.Theme.Font,
                TextSize = UI.Theme.FontSize,
                TextColor3 = UI.Theme.PrimaryText,
                TextStrokeColor3 = UI.Theme.Primary,
                TextStrokeTransparency = UI.Theme.TextStrokeTransparency,
                TextWrapped = true,
                Size = UDim2.new(0, 0, 0, 0),
                Text = "<b>Looking for more games with Kohl\'s Admin?</b>",
                RichText = true,
                UI.new("Tooltip")({
                    Text = "Find games using Kohl\'s Admin!\n\n<font transparency=\'0.5\'>Check the Kohl\'s Admin <b>Settings</b> script in Studio to add your game to the charts.</font>\n\n<b>Game Creators</b> get up to <font color=\'#0f0\'><b>40%</b></font> when <font transparency=\'0.5\'><b>Third Party Purchases</b></font> are enabled in their Roblox Game Settings!"
                })
            }),
            UI.new("Frame")({
                AutomaticSize = Enum.AutomaticSize.XY,
                BackgroundTransparency = 1,
                UI.new("UIListLayout")({
                    FillDirection = Enum.FillDirection.Horizontal,
                    Padding = UI.Theme.PaddingWithStroke,
                    SortOrder = Enum.SortOrder.LayoutOrder,
                    VerticalAlignment = Enum.VerticalAlignment.Center
                }),
                UI.new("ImageButton")({
                    BackgroundTransparency = 1,
                    Size = UDim2.new(0, 24, 0, 24),
                    Image = "rbxasset://textures/ui/InspectMenu/ico_favorite@2x.png",
                    ImageColor3 = Color3.new(1, 0.8, 0),

                    Activated = function() -- Line: 708, Name: Activated
                        -- upvalues: u2 (ref)
                        pcall(function() -- Line: 709
                            -- upvalues: u2 (ref)
                            u2.Service.AvatarEditor:PromptSetFavorite(17873329124, 1, true);
                        end);
                    end,

                    UI.new("Tooltip")({
                        Text = "Add to Favorites"
                    })
                }),
                UI.new("Link")({
                    Name = "CatalogLink",
                    Text = "roblox.com/games/17873329124",
                    Tooltip = "<b>Copy:</b> Ctrl + C\n\nFind games using Kohl\'s Admin!\n\n<font transparency=\'0.5\'>Check the Kohl\'s Admin <b>Settings</b> script in Studio to add your game to the charts.</font>\n\n<b>Game Creators</b> get up to <font color=\'#0f0\'><b>40%</b></font> when <font transparency=\'0.5\'><b>Third Party Purchases</b></font> are enabled in their Roblox Game Settings!"
                })
            })
        });
        UI.edit(u3._instance.UIListLayout, {
            HorizontalAlignment = "Center",
            Padding = UI.Theme.PaddingWithStroke
        });
    end);

    return u3;
end;

return v1;