-- Decompiled with Potassium's decompiler.

return function(u1) -- Line: 1, Name: generateValidate
    return function(p2, p3) -- Line: 2
        -- upvalues: u1 (copy)
        local v4, v5 = u1(p2, p3);

        return v4, v5 or "Invalid player";
    end;
end;