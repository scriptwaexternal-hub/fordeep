-- Decompiled with Potassium's decompiler.

local u1 = nil;

local function parse(p2: string, p3: any) -- Line: 3
    -- upvalues: u1 (ref)
    local v4 = u1.Data.reservedServers[p2];

    if v4 then
        return v4;
    end;

    local string_lower_ret, v5 = string.lower(p2);

    for i, v in u1.Data.reservedServers do
        local string_lower_ret2 = string.lower(i);

        if string_lower_ret2 == string_lower_ret then
            return v;
        end;

        if string.find(string_lower_ret2, string_lower_ret) and (not v5 or #v5 < #i) then
            v5 = i;
        end;
    end;

    return u1.Data.reservedServers[v5], "Invalid reserveCode";
end;

local u9 = {
    validate = parse,
    parse = parse,

    suggestions = function(p6: string, p7: number) -- Line: 25, Name: suggestions
        -- upvalues: u1 (ref)
        local v8 = {};

        for i in u1.Data.reservedServers do
            table.insert(v8, i);
        end;

        table.sort(v8);

        return v8;
    end
};

return function(p10) -- Line: 35
    -- upvalues: u1 (ref), u9 (copy)
    u1 = p10;
    u1.Registry.registerType("reservedServer", u9);
    u1.Registry.registerType("reservedServers", {
        listable = true
    }, u9);
end;