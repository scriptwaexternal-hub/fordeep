-- Decompiled with Potassium's decompiler.

local Players = game:GetService("Players");
local Debris = game:GetService("Debris");
local ReplicatedStorage = game:GetService("ReplicatedStorage");
game:GetService("RunService");
game:GetService("CollectionService");
local RaceChat = require(game:GetService("ReplicatedStorage"):WaitForChild("Modules"):WaitForChild("Shared"):WaitForChild("RaceChat"));
local Modules = ReplicatedStorage:WaitForChild("Modules");
local Remotes = ReplicatedStorage:WaitForChild("Remotes");
local Assets = ReplicatedStorage.Assets;
local Metadata = Modules.Metadata;
local Shared = Modules.Shared;
local _ = Modules.Utility;
local SoundManager = require(Shared.SoundManager);
local GlobalFunctions = require(Modules.GlobalFunctions);
require(Shared.CamManager);
local CinemaManager = require(Shared.CinemaManager);
local AnimationManager = require(Shared.AnimationManager);
local VfxHandler = require(Modules.Effects.VfxHandler);
local TransformData = require(Metadata.MiscData.TransformData.TransformData);
local ServerRemote = Remotes.ServerRemote;
local Visuals = workspace.World.Visuals;
local LocalPlayer = Players.LocalPlayer;
local _ = Assets.Sounds;
local Effects = Assets.Effects;
local Meshes = Effects.Meshes;
local Particles = Effects.Particles;

return {
    Flash = function(p1) -- Line: 48
        -- upvalues: CinemaManager (copy), LocalPlayer (copy)
        CinemaManager.Flash(LocalPlayer, 0.5);
    end,

    Aura = function(p2) -- Line: 53
        -- upvalues: GlobalFunctions (copy), SoundManager (copy), Particles (copy), Assets (copy)
        local Character = p2.Character;
        local CurrentRate = p2.CurrentRate;
        local _ = p2.RaceTrait;
        local Form = p2.Form;
        local RootAndHumanoid = GlobalFunctions.GetRootAndHumanoid(Character);
        local v3 = Character:FindFirstChild("SSJ Aura");

        if v3 then
            for _, child in pairs(v3:GetChildren()) do
                if child:IsA("ParticleEmitter") then
                    child.Rate = CurrentRate;

                    if Form and Form == "LSSJ" then
                        child.Color = ColorSequence.new({ ColorSequenceKeypoint.new(0, Color3.fromRGB(55, 237, 114)), ColorSequenceKeypoint.new(1, Color3.fromRGB(55, 237, 114)) });

                        if child.Name == "Lightning" then
                            child.Rate = 50;
                        end;
                    end;
                end;
            end;

            return;
        end;

        SoundManager.AddSound("Aura Burst", {
            Parent = RootAndHumanoid
        }, "Client");
        local v4 = Particles["SSJ Aura"]:Clone();
        v4.Parent = Character;
        local Weld = Instance.new("Weld");
        Weld.Parent = v4;
        Weld.Part0 = RootAndHumanoid;
        Weld.Part1 = v4;
        Weld.C0 = Weld.C0 * CFrame.new(0, -2, 0);
        local v5 = Assets.Sounds.Combat.Charging["Aura Loop"]:Clone();
        v5.Parent = v4;
        v5.Name = "SSJ LOOP";
        v5:Play();

        if Form == "LSSJ" then
            local v6 = Particles.Lightning:Clone();
            v6.Parent = v4;
            v6:Emit(50);
        end;

        for _, child in pairs(v4:GetChildren()) do
            if child:IsA("ParticleEmitter") then
                child.Rate = CurrentRate;

                if Form == "LSSJ" then
                    child.Color = ColorSequence.new({ ColorSequenceKeypoint.new(0, Color3.fromRGB(55, 237, 114)), ColorSequenceKeypoint.new(1, Color3.fromRGB(55, 237, 114)) });

                    if child.Name == "Lightning" then
                        child.Rate = 50;
                    end;
                end;
            end;
        end;
    end,

    ["Aura Disable"] = function(p7) -- Line: 122
        -- upvalues: Debris (copy), GlobalFunctions (copy)
        local Character = p7.Character;

        for _, child in pairs(Character:GetChildren()) do
            if child.Name == "SSJ Aura" then
                for _, child2 in pairs(child:GetChildren()) do
                    if child2:IsA("ParticleEmitter") then
                        child2.Enabled = false;
                    end;
                end;

                Debris:AddItem(child, 1);
            elseif child.Name == "Ikari Highlight" then
                GlobalFunctions.Tween({
                    Duration = 1,
                    Instance = child
                }, {
                    OutlineTransparency = 1
                });
                task.delay(1, function() -- Line: 138
                    -- upvalues: child (copy)
                    child:Destroy();
                end);
            end;
        end;

        for _, descendant in ipairs(Character:GetDescendants()) do
            if descendant:GetAttribute("IkariFX") and descendant:IsA("ParticleEmitter") then
                descendant.Enabled = false;
                Debris:AddItem(descendant, 2);
            end;
        end;
    end,

    ["Lightning On"] = function(p8) -- Line: 154
        -- upvalues: Players (copy), VfxHandler (copy)
        local Form_Quota = p8.Form_Quota;
        local Character = p8.Character;
        local v9 = p8.Delay or 3;
        local v10 = p8.LightningAmt or 5;
        local Form = Players:GetPlayerFromCharacter(Character):FindFirstChild("PlayerStats"):FindFirstChild("Form", true);
        local v11 = {
            Amt = v10,
            WidthScale = p8.WidthScale,
            MaxSegments = p8.MaxSegments
        };

        while Form.Value == Form_Quota do
            VfxHandler.Lightning.Aura(Character, v11);

            if p8.DelayMin and p8.DelayMax then
                task.wait(math.random(p8.DelayMin, p8.DelayMax));
            else
                task.wait(v9);
            end;
        end;
    end,

    ["Lightning Off"] = function(p12) -- Line: 190
    end,

    ["First SSJ"] = function(u13) -- Line: 194
        -- upvalues: Players (copy), GlobalFunctions (copy), TransformData (copy), AnimationManager (copy), SoundManager (copy), LocalPlayer (copy), VfxHandler (copy), RaceChat (copy), CinemaManager (copy), ServerRemote (copy)
        local Character = u13.Character;
        local RaceTrait = u13.RaceTrait;
        local PlayerFromCharacter = Players:GetPlayerFromCharacter(Character);
        local RootAndHumanoid, _ = GlobalFunctions.GetRootAndHumanoid(Character);
        local u14 = GlobalFunctions.FindFakeHead(Character);
        local u15, u16;

        if RaceTrait == "C-Type" then
            u15 = TransformData.Saiyan.LSSJCOLOR;
            u16 = Color3.fromRGB(255, 225, 0);
        else
            u15 = TransformData.Saiyan.SSJCOLOR;
            u16 = Color3.fromRGB(0, 255, 255);
        end;

        local v17 = AnimationManager.PlayAnimation(Character, "First SSJ", {
            AdjustSpeed = 0.35
        });

        if not v17 then
            return;
        end;

        SoundManager.AddSound("SS - V Theme", {
            Parent = LocalPlayer
        }, "Client", {
            Duration = 35
        });
        local u18 = {};
        local CutsceneVFX = require(script.Parent.Parent.Misc.CutsceneVFX);
        local Vector3_new_ret = Vector3.new(RootAndHumanoid.CFrame.LookVector.X, 0, RootAndHumanoid.CFrame.LookVector.Z);
        local u19 = Vector3_new_ret.Magnitude > 0.05 and Vector3_new_ret.Unit or Vector3.new(0, 0, 1);
        local u20 = nil;
        local u21 = nil;
        local u22 = nil;
        local u23 = nil;
        local u24 = false;
        local u25 = false;

        local function facePoint() -- Line: 248
            -- upvalues: RootAndHumanoid (copy)
            return RootAndHumanoid.Position + Vector3.new(0, 1.45, 0);
        end;

        local function Cut(p26) -- Line: 252
            -- upvalues: u21 (ref), RootAndHumanoid (copy), u19 (ref)
            u21 = CFrame.lookAt(RootAndHumanoid.Position + Vector3.new(0, 1.45, 0) + u19 * p26, RootAndHumanoid.Position + Vector3.new(0, 1.45, 0));
        end;

        local function EndCinematic() -- Line: 256
            -- upvalues: u25 (ref), u20 (ref), u18 (copy), CutsceneVFX (copy), u24 (ref), GlobalFunctions (ref), Character (copy)
            if u25 then
                return;
            end;

            u25 = true;

            if u20 then
                u20:Disconnect();
                u20 = nil;
            end;

            for _, v in pairs(u18) do
                v:Disconnect();
            end;

            if workspace.Camera.CameraType == Enum.CameraType.Scriptable then
                workspace.Camera.CameraType = Enum.CameraType.Custom;
            end;

            CutsceneVFX.ReleaseCinema(u24);
            GlobalFunctions.UnFreezeCharacter(Character);
        end;

        local function StartCamera() -- Line: 270
            -- upvalues: u20 (ref), u23 (ref), u21 (ref), u22 (ref), RootAndHumanoid (copy), u19 (ref)
            workspace.Camera.CameraType = Enum.CameraType.Scriptable;
            u20 = game:GetService("RunService").Heartbeat:Connect(function() -- Line: 272
                -- upvalues: u23 (ref), u21 (ref), u22 (ref), RootAndHumanoid (ref), u19 (ref)
                if u23 then
                    local v27 = (os.clock() - u23) / 1.5;
                    local math_clamp_ret = math.clamp(v27, 0, 1);
                    u21 = u22:Lerp(CFrame.lookAt(RootAndHumanoid.Position + Vector3.new(0, 1.45, 0) + u19 * 30 + Vector3.new(0, 30, 0), RootAndHumanoid.Position + Vector3.new(0, 1.45, 0)), 1 - (1 - math_clamp_ret) * (1 - math_clamp_ret));
                end;

                if u21 then
                    workspace.Camera.CFrame = u21;
                end;
            end);
        end;

        local function FindHair() -- Line: 283
            -- upvalues: Character (copy)
            local v28 = {};

            for _, descendant in pairs(Character:GetDescendants()) do
                if descendant:IsA("Accessory") and descendant.AccessoryType == Enum.AccessoryType.Hair then
                    v28[#v28 + 1] = descendant;
                end;
            end;

            return v28;
        end;

        local function Hair_Twitch(p29) -- Line: 295
            -- upvalues: FindHair (copy), u15 (ref), GlobalFunctions (ref), u14 (copy), u16 (ref)
            local v30 = FindHair();

            for _, v in pairs(v30) do
                local Handle = v:FindFirstChild("Handle");

                if Handle then
                    GlobalFunctions.Tween({
                        Duration = 1,
                        Instance = Handle,
                        Reverse = p29 or true
                    }, {
                        Color = u15
                    });
                end;
            end;

            for _, child in pairs(u14:GetChildren()) do
                if child:IsA("Decal") then
                    if child.Name == "Eyebrows" then
                        GlobalFunctions.Tween({
                            Duration = 1,
                            Instance = child,
                            Reverse = p29 or true
                        }, {
                            Color3 = u15
                        });
                    elseif child.Name == "Pupils" then
                        GlobalFunctions.Tween({
                            Duration = 1,
                            Instance = child,
                            Reverse = p29 or true
                        }, {
                            Color3 = u16
                        });
                    end;
                end;
            end;
        end;

        local function Change_Hair_Color() -- Line: 345
            -- upvalues: FindHair (copy), u15 (ref), GlobalFunctions (ref), Character (copy)
            local v31 = FindHair();
            local v32 = {
                Color = u15
            };

            for _, v in pairs(v31) do
                local Handle = v:FindFirstChild("Handle");

                if Handle then
                    GlobalFunctions.Tween({
                        Duration = 1,
                        Instance = Handle
                    }, v32);
                end;
            end;

            local MonkeyTail = Character:FindFirstChild("MonkeyTail", true);

            if not MonkeyTail then
                return;
            end;

            GlobalFunctions.Tween({
                Duration = 0.5,
                Instance = MonkeyTail
            }, v32);
        end;

        local function Generate_Lightning() -- Line: 377
            -- upvalues: RootAndHumanoid (copy), SoundManager (ref), LocalPlayer (ref), VfxHandler (ref)
            local math_random_ret = math.random(-40, 40);
            local math_random_ret2 = math.random(-40, 40);
            local math_random_ret3 = math.random(40, 50);
            local v33 = RootAndHumanoid.CFrame * CFrame.new(math_random_ret, math_random_ret3, math_random_ret2).Position;
            local v34 = v33 * CFrame.new(0, -60, 0).Position;
            local math_random_ret4 = math.random(2, 5);
            SoundManager.AddSound("lightning_bolt", {
                Parent = LocalPlayer
            }, "Client", {
                Duration = 35
            });
            VfxHandler.Lightning.New(v33, v34, math_random_ret4, {
                MINWIDTH = 3
            });
        end;

        u24 = CutsceneVFX.ForceCinemaOn();
        GlobalFunctions.FreezeCharacter(Character);
        workspace.Camera.CameraType = Enum.CameraType.Scriptable;
        u20 = game:GetService("RunService").Heartbeat:Connect(function() -- Line: 272
            -- upvalues: u23 (ref), u21 (ref), u22 (ref), RootAndHumanoid (copy), u19 (ref)
            if u23 then
                local v35 = (os.clock() - u23) / 1.5;
                local math_clamp_ret = math.clamp(v35, 0, 1);
                u21 = u22:Lerp(CFrame.lookAt(RootAndHumanoid.Position + Vector3.new(0, 1.45, 0) + u19 * 30 + Vector3.new(0, 30, 0), RootAndHumanoid.Position + Vector3.new(0, 1.45, 0)), 1 - (1 - math_clamp_ret) * (1 - math_clamp_ret));
            end;

            if u21 then
                workspace.Camera.CFrame = u21;
            end;
        end);
        u21 = CFrame.lookAt(RootAndHumanoid.Position + Vector3.new(0, 1.45, 0) + u19 * 25, RootAndHumanoid.Position + Vector3.new(0, 1.45, 0));
        task.delay(22, EndCinematic);
        task.spawn(function() -- Line: 402
            -- upvalues: Generate_Lightning (copy)
            for i = 1, 5 do
                task.wait(math.random(5, 10) / 10);
                Generate_Lightning();
                local _ = i;
            end;
        end);
        u18[#u18 + 1] = v17:GetMarkerReachedSignal("Text 1"):Once(function() -- Line: 412
            -- upvalues: RaceChat (ref), Character (copy), u21 (ref), RootAndHumanoid (copy), u19 (ref)
            RaceChat.Say(Character, "You\'re Ruthless.......");
            u21 = CFrame.lookAt(RootAndHumanoid.Position + Vector3.new(0, 1.45, 0) + u19 * 15, RootAndHumanoid.Position + Vector3.new(0, 1.45, 0));
        end);
        u18[#u18 + 1] = v17:GetMarkerReachedSignal("Text 2"):Once(function() -- Line: 417
            -- upvalues: RaceChat (ref), Character (copy), u21 (ref), RootAndHumanoid (copy), u19 (ref)
            RaceChat.Say(Character, " I WON\'T FORGIVE YOU!!!");
            u21 = CFrame.lookAt(RootAndHumanoid.Position + Vector3.new(0, 1.45, 0) + u19 * 5, RootAndHumanoid.Position + Vector3.new(0, 1.45, 0));
        end);
        u18[#u18 + 1] = v17:GetMarkerReachedSignal("Hair Flash"):Once(function() -- Line: 422
            -- upvalues: Hair_Twitch (copy)
            Hair_Twitch();
        end);
        u18[#u18 + 1] = v17:GetMarkerReachedSignal("Text 3"):Once(function() -- Line: 427
            -- upvalues: RaceChat (ref), Character (copy)
            RaceChat.Say(Character, "I\'ll MAKE YOU SUFFER.");
        end);
        u18[#u18 + 1] = v17:GetMarkerReachedSignal("Transformation"):Once(function() -- Line: 431
            -- upvalues: CinemaManager (ref), PlayerFromCharacter (copy), u22 (ref), u21 (ref), u23 (ref), u13 (copy), ServerRemote (ref), LocalPlayer (ref), Character (copy)
            CinemaManager.Flash(PlayerFromCharacter, 0.5);
            u22 = u21;
            u23 = os.clock();

            if u13.Preview then
                return;
            end;

            ServerRemote:FireServer(nil, {
                Module = "SSJ",
                Action = "TriggerEnd",
                Player = LocalPlayer,
                Character = Character
            });
        end);
        u18[#u18 + 1] = v17.Ended:Once(EndCinematic);
    end,

    LSSJ = function(p36) -- Line: 452
        -- upvalues: GlobalFunctions (copy), Meshes (copy), Visuals (copy)
        local Character = p36.Character;
        local v37 = tonumber(p36.Scale) or 1;
        local RootAndHumanoid, _ = GlobalFunctions.GetRootAndHumanoid(Character);

        if not RootAndHumanoid then
            return;
        end;

        local u38 = Meshes["Inverted Sphere"]:Clone();
        u38.Parent = Visuals;
        u38.CFrame = RootAndHumanoid.CFrame;
        u38.Size = Vector3.new(0.1, 0.1, 0.1);
        u38.Color = Color3.fromRGB(0, 255, 0);
        local u39 = Meshes.Cylinder:Clone();
        u39.Parent = Visuals;
        u39.CFrame = RootAndHumanoid.CFrame;
        u39.Size = Vector3.new(0, 100, 0);
        u39.Material = Enum.Material.Neon;
        u39.Color = Color3.fromRGB(0, 255, 0);
        local v40 = math.max(v37, 1) * 0.5;
        local v41 = 100 * v37;
        local v42 = {
            Transparency = 1,
            Size = Vector3.new(1, 1, 1) * v41
        };
        local v43 = {
            Instance = u39,
            Duration = math.max(v37, 1) * 2.5
        };
        local v44 = {
            Transparency = 1,
            Size = Vector3.new(v41, v41 * 10, v41)
        };
        local v45 = GlobalFunctions.Tween({
            Instance = u38,
            Duration = v40
        }, v42);
        local v46 = GlobalFunctions.Tween(v43, v44);
        v45.Completed:Once(function() -- Line: 488
            -- upvalues: u38 (copy)
            u38:Destroy();
        end);
        v46.Completed:Once(function() -- Line: 492
            -- upvalues: u39 (copy)
            u39:Destroy();
        end);
    end,

    Ikari = function(p47) -- Line: 499
        -- upvalues: GlobalFunctions (copy), Particles (copy), Debris (copy)
        local Character = p47.Character;
        local RootAndHumanoid = GlobalFunctions.GetRootAndHumanoid(Character);
        local Highlight = Instance.new("Highlight");
        Highlight.Parent = Character;
        Highlight.Name = "Ikari Highlight";
        Highlight.FillTransparency = 1;
        Highlight.OutlineTransparency = 1;
        Highlight.OutlineColor = Color3.fromRGB(255, 255, 0);
        local v48 = Particles.Wind:Clone();
        v48.Parent = RootAndHumanoid;
        v48:Emit(20);
        Debris:AddItem(v48, 3);
        local IkariAura = Particles:FindFirstChild("IkariAura");

        if IkariAura then
            for _, v in ipairs({ "Head", "Left Arm", "Right Arm", "Left Leg", "Right Leg" }) do
                local v49 = Character:FindFirstChild(v);

                if v49 then
                    for _, child in ipairs(IkariAura.Limb:GetChildren()) do
                        local v50 = child:Clone();
                        v50:SetAttribute("IkariFX", true);
                        v50.Parent = v49;
                    end;
                end;
            end;
        end;

        GlobalFunctions.Tween({
            Duration = 1,
            Instance = Highlight
        }, {
            OutlineTransparency = 0
        });
    end
};