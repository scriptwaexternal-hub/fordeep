-- Decompiled with Potassium's decompiler.

local Flux = require(script.Parent.Parent.Parent:WaitForChild("Flux"));
local Themes = script:WaitForChild("Themes");
local Default = require(script:WaitForChild("Default"));
local compute = Flux.compute;
local state = Flux.state;
local u1 = {};

local function loadTheme(p2: userdata) -- Line: 47
    -- upvalues: u1 (copy), Default (copy)
    if p2:IsA("ModuleScript") then
        if u1[p2.Name] then
            warn("Duplicate theme found, make sure they have different names!");
        end;

        local v3 = require(p2);

        if typeof(v3.Font) == "EnumItem" then
            v3.Font = Font.fromEnum(v3.Font);
        end;

        if typeof(v3.FontMono) == "EnumItem" then
            v3.FontMono = Font.fromEnum(v3.FontMono);
        end;

        for _, v in { v3.Image, v3.Sound } do
            local v4 = v;

            for i, v2 in v do
                v4[i] = "rbxassetid://" .. v2;
            end;
        end;

        if v3 == Default then
            return;
        end;

        if p2.Name == "Default" then
            local v5 = {};

            for i, v in v3 do
                local v6;

                if type(v) == "table" then
                    v6 = table.clone(v);
                else
                    v6 = v;
                end;

                v5[i] = v6;
            end;

            u1[p2.Name] = v5;

            return;
        end;

        u1[p2.Name] = v3;
    end;
end;

loadTheme(script:WaitForChild("Default"));

for _, child in Themes:GetChildren() do
    loadTheme(child);
end;

task.wait();
local Default2 = Themes:FindFirstChild("Default");
local v7 = not Default2 and {} or require(Default2);
local u8 = {
    Themes = u1
};

for i, v in Default do
    u8[i] = v7[i] or v;
end;

local function makeStateful(p9: table) -- Line: 96
    -- upvalues: makeStateful (copy), state (copy)
    for i, v in p9 do
        if type(v) == "table" then
            makeStateful(v);
        else
            p9[i] = state(v);
        end;
    end;
end;

makeStateful(u8);
u8.TransparencySlight = compute(function() -- Line: 109
    -- upvalues: u8 (copy)
    return u8.Transparency * 0.9375 + 0.0625;
end);
u8.TransparencyLight = compute(function() -- Line: 113
    -- upvalues: u8 (copy)
    return u8.Transparency * 0.875 + 0.125;
end);
u8.TransparencyMedium = compute(function() -- Line: 117
    -- upvalues: u8 (copy)
    return u8.Transparency * 0.75 + 0.25;
end);
u8.TransparencyBalanced = compute(function() -- Line: 121
    -- upvalues: u8 (copy)
    return u8.Transparency * 0.5 + 0.5;
end);
u8.TransparencyStrong = compute(function() -- Line: 125
    -- upvalues: u8 (copy)
    return u8.Transparency * 0.25 + 0.75;
end);
u8.TransparencyHeavy = compute(function() -- Line: 129
    -- upvalues: u8 (copy)
    return u8.Transparency * 0.125 + 0.875;
end);
u8.TransparencyMax = compute(function() -- Line: 133
    -- upvalues: u8 (copy)
    return u8.Transparency * 0.0625 + 0.9375;
end);
u8.TransparencyClamped = compute(function() -- Line: 137
    -- upvalues: u8 (copy)
    return u8.Transparency * 0.75;
end);
u8.FontHeavy = compute(function() -- Line: 141
    -- upvalues: u8 (copy)
    return Font.new(u8.Font().Family, Enum.FontWeight.Heavy);
end);
u8.FontBold = compute(function() -- Line: 145
    -- upvalues: u8 (copy)
    return Font.new(u8.Font().Family, Enum.FontWeight.Bold);
end);
u8.FontSemiBold = compute(function() -- Line: 149
    -- upvalues: u8 (copy)
    return Font.new(u8.Font().Family, Enum.FontWeight.SemiBold);
end);
u8.FontLight = compute(function() -- Line: 153
    -- upvalues: u8 (copy)
    return Font.new(u8.Font().Family, Enum.FontWeight.Light);
end);
u8.FontThin = compute(function() -- Line: 157
    -- upvalues: u8 (copy)
    return Font.new(u8.Font().Family, Enum.FontWeight.Thin);
end);
u8.FontSizeDouble = compute(function() -- Line: 161
    -- upvalues: u8 (copy)
    return math.round(u8.FontSize * 2);
end);
u8.FontSizeLargest = compute(function() -- Line: 165
    -- upvalues: u8 (copy)
    return math.round(u8.FontSize * 1.75);
end);
u8.FontSizeLarger = compute(function() -- Line: 169
    -- upvalues: u8 (copy)
    return math.round(u8.FontSize * 1.5);
end);
u8.FontSizeLarge = compute(function() -- Line: 173
    -- upvalues: u8 (copy)
    return math.round(u8.FontSize * 1.25);
end);
u8.FontSizeSmall = compute(function() -- Line: 177
    -- upvalues: u8 (copy)
    return math.round(u8.FontSize * 0.75);
end);
u8.FontSizeSmaller = compute(function() -- Line: 181
    -- upvalues: u8 (copy)
    return math.round(u8.FontSize * 0.5);
end);
u8.FontSizeSmallest = compute(function() -- Line: 185
    -- upvalues: u8 (copy)
    return math.round(u8.FontSize * 0.25);
end);
u8.PaddingHalf = compute(function() -- Line: 189
    -- upvalues: u8 (copy)
    local v10 = u8.Padding();

    return UDim.new(v10.Scale / 2, v10.Offset / 2);
end);
u8.PaddingDouble = compute(function() -- Line: 194
    -- upvalues: u8 (copy)
    local v11 = u8.Padding();

    return UDim.new(v11.Scale * 2, v11.Offset * 2);
end);
u8.PaddingStroke = compute(function() -- Line: 199
    -- upvalues: u8 (copy)
    return UDim.new(0, u8.StrokeEnabled() and 1 or 0);
end);
u8.PaddingWithStroke = compute(function() -- Line: 203
    -- upvalues: u8 (copy)
    return u8.Padding + u8.PaddingStroke;
end);
u8.CornerHalf = compute(function() -- Line: 207
    -- upvalues: u8 (copy)
    local v12 = u8.CornerRadius();

    return UDim.new(v12.Scale / 2, v12.Offset / 2);
end);
u8.CornerDiameter = compute(function() -- Line: 212
    -- upvalues: u8 (copy)
    local v13 = u8.CornerRadius();

    return UDim.new(v13.Scale * 2, v13.Offset * 2);
end);
u8.CornerPadded = compute(function() -- Line: 217
    -- upvalues: u8 (copy)
    local v14 = u8.Padding();
    local v15 = u8.CornerRadius();

    return UDim.new(v15.Scale, v15.Offset - v14.Offset / 2);
end);
u8.CornerPadded2 = compute(function() -- Line: 223
    -- upvalues: u8 (copy)
    local v16 = u8.Padding();
    local v17 = u8.CornerRadius();

    return UDim.new(v17.Scale, v17.Offset - v16.Offset);
end);
u8.CornerPadded3 = compute(function() -- Line: 229
    -- upvalues: u8 (copy)
    local v18 = u8.Padding();
    local v19 = u8.CornerRadius();

    return UDim.new(v19.Scale, v19.Offset - v18.Offset * 1.5);
end);
u8.ScrollMidImage = state("rbxassetid://18370268668");
u8.ScrollTopImage = compute(function() -- Line: 236
    -- upvalues: u8 (copy)
    return u8.CornerRadius().Offset == 0 and "rbxassetid://18370268668" or "rbxassetid://105141456035522";
end);
u8.ScrollBottomImage = compute(function() -- Line: 239
    -- upvalues: u8 (copy)
    return u8.CornerRadius().Offset == 0 and "rbxassetid://18370268668" or "rbxassetid://110012579042362";
end);

return u8;