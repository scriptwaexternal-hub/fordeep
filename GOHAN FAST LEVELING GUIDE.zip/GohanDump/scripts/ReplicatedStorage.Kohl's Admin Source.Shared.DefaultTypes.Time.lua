-- Decompiled with Potassium's decompiler.

local u1 = { "second", "minute", "hour", "day", "week", "month", "year", "millisecond", "s", "m", "h", "d", "w", "y", "hr", "wk", "yr", "ms" };
local u2 = { { "0", "0 Session" }, { "-1", "-1 Forever" } };
local u3 = {};

for i, v in u1 do
    local v4;

    if #v > 2 then
        v4 = string.upper((string.sub(v, 1, 1))) .. string.sub(v, 2);
    else
        v4 = v;
    end;

    u2[i + 2] = { "1" .. v, "1 " .. v4 };

    if #v > 1 then
        u3[i + 2] = v .. "s";
    end;
end;

return function(u5) -- Line: 35
    -- upvalues: u3 (copy), u1 (copy), u2 (copy)
    local function parseTime(p6: string) -- Line: 36
        -- upvalues: u5 (copy)
        if p6 == "" then
            return true, 1;
        end;

        if string.find("-1", p6, 1, true) then
            return true, -1;
        end;

        if tonumber(p6) then
            return true, tonumber(p6);
        end;

        if string.find(p6, "(%d+%.?%d*)%s*(%a+)") == nil then
            return false, "Invalid time format";
        end;

        local v7 = 0;

        for i, v in string.gmatch(string.lower(p6), "(%d+%.?%d*)%s*(%a+)") do
            local v8 = u5.Util.Time.fromUnit(v);

            if v8 == nil then
                return false, "Invalid time format";
            end;

            v7 = v7 + i * v8;
        end;

        return true, v7;
    end;

    u5.Registry.registerType("timeSimple", {
        filterLog = true,

        validate = function(p9) -- Line: 65, Name: validate
            -- upvalues: parseTime (copy)
            return parseTime(p9);
        end,

        parse = function(p10) -- Line: 68, Name: parse
            -- upvalues: parseTime (copy)
            local v11, v12 = parseTime(p10);

            if not v11 then
                error(v12);
            end;

            return v12;
        end,

        suggestions = function(p13) -- Line: 75, Name: suggestions
            -- upvalues: u3 (ref), u1 (ref), u2 (ref)
            local v14 = tonumber(string.match(p13, "^%-?%d*"));
            local v15 = #p13 > 0 and string.find("-1", p13, 1, true) == 1 and -1 or v14;

            if not v15 then
                return u2;
            end;

            local v16 = { { "0", "0 Session" }, { "-1", "-1 Forever" } };

            if v15 > 0 then
                local v17;

                if v15 > 1 then
                    v17 = u3;
                else
                    v17 = u1;
                end;

                for i, v in v17 do
                    local v18;

                    if #v > 2 then
                        v18 = string.upper((string.sub(v, 1, 1))) .. string.sub(v, 2);
                    else
                        v18 = v;
                    end;

                    v16[i + 1] = { v15 .. v, v15 .. " " .. v18 };
                end;
            end;

            return v16;
        end
    });
end;