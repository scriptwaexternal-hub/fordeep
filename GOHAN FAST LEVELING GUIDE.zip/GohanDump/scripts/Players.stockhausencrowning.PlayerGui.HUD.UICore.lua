-- Decompiled with Potassium's decompiler.

local ReplicatedStorage = game:GetService("ReplicatedStorage");
local UserInputService = game:GetService("UserInputService");
local Players = game:GetService("Players");
local Modules = ReplicatedStorage:WaitForChild("Modules");
local Remotes = ReplicatedStorage:WaitForChild("Remotes");
local Shared = Modules.Shared;
local _ = Modules.Utility;
local ControlData = require(Modules.Metadata.ControlData.ControlData);
require(Modules.GlobalFunctions);
local CinemaManager = require(Shared.CinemaManager);
local HealthManager = require(script.Utility.HealthManager);
local HungerManager = require(script.Utility.HungerManager);
local ZeniManager = require(script.Utility.ZeniManager);
local OutputManager = require(script.Utility.OutputManager);
local TransformOutputManager = require(script.Utility.TransformOutputManager);
local KiManager = require(script.Utility.KiManager);
local StaminaManager = require(script.Utility.StaminaManager);
local EvadeManager = require(script.Utility.EvadeManager);
local StateManager = require(ReplicatedStorage.Modules.Metadata.ControlData.StateManager);
local Platform = require(Shared.Platform);
local ServerRemote = ReplicatedStorage.Remotes.ServerRemote;
local ReplicateRemote = ReplicatedStorage.Remotes.ReplicateRemote;
local CinemaRemote = ReplicatedStorage.Remotes.CinemaRemote;
local HUDRemote = ReplicatedStorage.Remotes.HUDRemote;
local LocalPlayer = Players.LocalPlayer;
local _ = script.Parent;
local u1 = {};
local u2 = {};
local u3 = {};

for _, child in pairs(script.Managers:GetChildren()) do
    if child:IsA("ModuleScript") then
        u1[child.Name] = require(child);
    end;
end;

for _, child in pairs(script.MainUI:GetChildren()) do
    if child:IsA("ModuleScript") then
        u2[child.Name] = require(child);
    end;
end;

for _, child in pairs(script.Utility:GetChildren()) do
    if child:IsA("ModuleScript") then
        u3[child.Name] = require(child);
    end;
end;

local PlayerStats = LocalPlayer:WaitForChild("PlayerStats");
local Evade = PlayerStats:FindFirstChild("Evade", true);
local Hunger = PlayerStats:FindFirstChild("Hunger", true);
local Stamina = PlayerStats:FindFirstChild("Stamina", true);
local Ki = PlayerStats:FindFirstChild("Ki", true);
PlayerStats:FindFirstChild("MaxKi", true);
local Zeni = PlayerStats:FindFirstChild("Zeni", true);
local Output = PlayerStats:FindFirstChild("Output", true);
local TransformOutput = PlayerStats:FindFirstChild("TransformOutput", true);
ZeniManager.Update(Zeni.Value);
OutputManager.Update(Output.Value);
StaminaManager.Update(Stamina.Value);
EvadeManager.Update(Evade.Value);
HungerManager.Update(Hunger.Value);
Evade.Changed:Connect(function(p4) -- Line: 95
    -- upvalues: EvadeManager (copy)
    EvadeManager.Update(p4);
end);
Hunger.Changed:Connect(function(p5) -- Line: 99
    -- upvalues: HungerManager (copy)
    HungerManager.Update(p5);
end);
Zeni.Changed:Connect(function(p6) -- Line: 103
    -- upvalues: ZeniManager (copy)
    ZeniManager.Update(p6);
end);
Output.Changed:Connect(function(p7) -- Line: 107
    -- upvalues: OutputManager (copy)
    OutputManager.Update(p7);
end);
TransformOutput.Changed:Connect(function(p8) -- Line: 111
    -- upvalues: TransformOutputManager (copy)
    TransformOutputManager.Update(p8);
end);
Stamina.Changed:Connect(function(p9) -- Line: 115
    -- upvalues: StaminaManager (copy)
    StaminaManager.Update(p9);
end);
Ki.Changed:Connect(function() -- Line: 119
    -- upvalues: KiManager (copy)
    KiManager.Update();
end);
LocalPlayer:GetAttributeChangedSignal("FormFatigue"):Connect(function() -- Line: 123
    -- upvalues: u3 (copy), LocalPlayer (copy)
    u3.FatigueManager.Update(LocalPlayer:GetAttribute("FormFatigue"));
end);
local u10 = {};

local function connectCharacterStats(p11) -- Line: 134
    -- upvalues: u10 (copy), HealthManager (copy)
    for _, v in pairs(u10) do
        v:Disconnect();
    end;

    table.clear(u10);
    local Humanoid = p11:WaitForChild("Humanoid");
    HealthManager.Update({
        Health = Humanoid.Health,
        MaxHealth = Humanoid.MaxHealth
    });
    u10[1] = Humanoid.HealthChanged:Connect(function(p12) -- Line: 149
        -- upvalues: HealthManager (ref), Humanoid (copy)
        HealthManager.Update({
            Health = p12,
            MaxHealth = Humanoid.MaxHealth
        });
    end);
end;

if LocalPlayer.Character then
    connectCharacterStats(LocalPlayer.Character);
end;

LocalPlayer.CharacterAdded:Connect(function(p13) -- Line: 162
    -- upvalues: connectCharacterStats (copy)
    connectCharacterStats(p13);
end);
HUDRemote.OnClientEvent:Connect(function(p14, p15) -- Line: 170
    -- upvalues: u3 (copy)
    local v16 = u3[p14];

    if v16 then
        v16.Update(p15);

        return;
    end;

    warn("HUDRemote: no utility module named \'" .. tostring(p14) .. "\'");
end);
ReplicateRemote.OnClientEvent:Connect(function(p17, p18) -- Line: 179
    -- upvalues: u1 (copy)
    for _, v in pairs(u1) do
        v.Update(p17, p18);
    end;
end);
task.spawn(function() -- Line: 205
    -- upvalues: LocalPlayer (copy), ServerRemote (copy)
    if not LocalPlayer.Character then
        LocalPlayer.CharacterAdded:Wait();
    end;

    local Character = LocalPlayer.Character;
    local v19 = Character and Character:FindFirstChildOfClass("Humanoid");

    if v19 then
        Character = v19;
    elseif Character then
        Character = Character:WaitForChild("Humanoid", 10);
    end;

    if not Character then
        return;
    end;

    ServerRemote:FireServer(nil, {
        Module = "HudSyncHandler",
        Action = "Request"
    });
end);
CinemaRemote.OnClientEvent:Connect(function(p20, p21) -- Line: 221
    -- upvalues: CinemaManager (copy), LocalPlayer (copy)
    CinemaManager[p20](LocalPlayer, p21);
end);

local function getKeyEvaluation(p22) -- Line: 229
    -- upvalues: Platform (copy)
    if p22.UserInputType == Enum.UserInputType.Keyboard then
        return p22.KeyCode.Name;
    end;

    if p22.UserInputType == Enum.UserInputType.MouseButton1 then
        return "MouseButton1";
    end;

    if p22.UserInputType == Enum.UserInputType.MouseButton2 then
        return "MouseButton2";
    end;

    if Platform.IsGamepadInput(p22.UserInputType) then
        return p22.KeyCode.Name;
    end;

    return p22.UserInputType.Name;
end;

local function findUIActionForKey(p23, p24) -- Line: 243
    for i, v in pairs(p24) do
        if typeof(v) == "table" then
            local v25 = i;

            for _, v2 in ipairs(v) do
                if v2 == p23 then
                    return v25;
                end;
            end;
        elseif v == p23 then
            return i;
        end;
    end;

    return nil;
end;

local function formClaimsKey(p26, p27) -- Line: 271
    -- upvalues: ControlData (copy), StateManager (copy), findUIActionForKey (copy)
    local FormStates = ControlData.FormStates;

    if not FormStates then
        return false;
    end;

    for i, v in pairs(FormStates) do
        if StateManager.IsInState(p26, i) then
            local v28 = ControlData.Controls[v];

            if v28 and findUIActionForKey(p27, v28) then
                return true;
            end;
        end;
    end;

    return false;
end;

UserInputService.InputBegan:Connect(function(p29, p30) -- Line: 285
    -- upvalues: getKeyEvaluation (copy), findUIActionForKey (copy), ControlData (copy), LocalPlayer (copy), formClaimsKey (copy), StateManager (copy), u2 (copy)
    if p30 then
        return;
    end;

    local v31 = getKeyEvaluation(p29);
    local v32 = findUIActionForKey(v31, ControlData.Controls.UI);

    if not v32 then
        return;
    end;

    if not ControlData.Controls.UI.Enabled then
        return;
    end;

    local v33 = LocalPlayer.Character or LocalPlayer.CharacterAdded:Wait();

    if formClaimsKey(v33, v31) then
        return;
    end;

    if not StateManager.CanPerformAction(v33, v32) then
        return;
    end;

    ControlData.Controls.UI.Enabled = false;
    task.delay(ControlData.Controls.UI.Debounce_Time, function() -- Line: 304
        -- upvalues: ControlData (ref)
        ControlData.Controls.UI.Enabled = true;
    end);
    local v34 = u2.UIHandler and u2.UIHandler[v32];

    if not v34 then
        warn("HUD: no UIHandler entry for action \'" .. tostring(v32) .. "\'");

        return;
    end;

    if typeof(v34) == "table" then
        v34.Execute(v32, v31);

        return;
    end;

    v34(v32, v31);
end);
Remotes:WaitForChild("TouchActionRemote").Event:Connect(function(p35, p36, p37) -- Line: 327
    -- upvalues: ControlData (copy), LocalPlayer (copy), formClaimsKey (copy), StateManager (copy), u2 (copy)
    if p35 ~= "UI" then
        return;
    end;

    if not ControlData.Controls.UI.Enabled then
        return;
    end;

    local Character = LocalPlayer.Character;

    if not Character then
        return;
    end;

    local v38 = ControlData.Controls.UI[p36];

    if typeof(v38) == "table" then
        v38 = v38[1] or v38;
    end;

    if v38 and formClaimsKey(Character, v38) then
        return;
    end;

    if not StateManager.CanPerformAction(Character, p36) then
        return;
    end;

    ControlData.Controls.UI.Enabled = false;
    task.delay(ControlData.Controls.UI.Debounce_Time, function() -- Line: 342
        -- upvalues: ControlData (ref)
        ControlData.Controls.UI.Enabled = true;
    end);
    local v39 = u2.UIHandler and u2.UIHandler[p36];

    if not v39 then
        warn("HUD: no UIHandler entry for touch action \'" .. tostring(p36) .. "\'");

        return;
    end;

    if typeof(v39) == "table" then
        v39.Execute(p36, p37);

        return;
    end;

    v39(p36, p37);
end);