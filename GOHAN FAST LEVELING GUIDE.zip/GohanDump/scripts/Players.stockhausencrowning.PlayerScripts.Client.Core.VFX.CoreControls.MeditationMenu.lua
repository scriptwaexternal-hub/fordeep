-- Decompiled with Potassium's decompiler.

local TweenService = game:GetService("TweenService");
local Players = game:GetService("Players");
local GuiService = game:GetService("GuiService");
local LocalPlayer = Players.LocalPlayer;
local Platform = require(game:GetService("ReplicatedStorage"):WaitForChild("Modules").Shared.Platform);
local Color3_fromRGB_ret = Color3.fromRGB(18, 18, 22);
local Color3_fromRGB_ret2 = Color3.fromRGB(30, 30, 36);
local Color3_fromRGB_ret3 = Color3.fromRGB(42, 42, 52);
local Color3_fromRGB_ret4 = Color3.fromRGB(235, 235, 235);
local Color3_fromRGB_ret5 = Color3.fromRGB(150, 150, 160);
local Color3_fromRGB_ret6 = Color3.fromRGB(255, 215, 90);
local Color3_fromRGB_ret7 = Color3.fromRGB(120, 190, 255);
local Color3_fromRGB_ret8 = Color3.fromRGB(255, 170, 90);
local TweenInfo_new_ret = TweenInfo.new(0.12, Enum.EasingStyle.Quad, Enum.EasingDirection.Out);
local u1 = {
    {
        name = "Ki Meditation",
        desc = "Unlock your Ki",
        icon = "rbxassetid://18837339886",
        tint = Color3.fromRGB(160, 220, 255)
    }
};
local u2 = {
    {
        name = "Control",
        desc = "Trains Ki Control",
        icon = "rbxassetid://8406398610",
        enlightenStat = "kiControl",
        tint = Color3.fromRGB(120, 190, 255)
    },
    {
        name = "Dmg",
        desc = "Trains Ki Damage",
        icon = "rbxassetid://8406535278",
        enlightenStat = "kiDmg",
        tint = Color3.fromRGB(255, 110, 110)
    },
    {
        name = "Motivation",
        desc = "Trains Motivation",
        icon = "http://www.roblox.com/asset/?id=11183649951",
        tint = Color3.fromRGB(200, 140, 255)
    }
};
local u3 = {
    {
        name = "Pushup",
        desc = "Trains Strength",
        stat = "STR",
        tint = Color3.fromRGB(255, 120, 90)
    },
    {
        name = "Squat",
        desc = "Trains Agility",
        stat = "AGI",
        tint = Color3.fromRGB(140, 255, 140)
    },
    {
        name = "Situp",
        desc = "Trains Durability",
        stat = "DUR",
        tint = Color3.fromRGB(170, 190, 230)
    }
};
local u4 = {
    Busy = false
};
local u5 = nil;

local function makeCard(p6, p7, u8, p9) -- Line: 74
    -- upvalues: Color3_fromRGB_ret2 (copy), Color3_fromRGB_ret6 (copy), Color3_fromRGB_ret4 (copy), Color3_fromRGB_ret5 (copy), TweenService (copy), TweenInfo_new_ret (copy), Color3_fromRGB_ret3 (copy)
    local TextButton = Instance.new("TextButton");
    TextButton.Name = p6.name;
    TextButton.Text = "";
    TextButton.AutoButtonColor = false;
    TextButton.BackgroundColor3 = Color3_fromRGB_ret2;
    TextButton.Size = UDim2.new(0, 110, 0, 110);
    TextButton.Parent = p7;
    Instance.new("UICorner", TextButton).CornerRadius = UDim.new(0, 10);
    local UIStroke = Instance.new("UIStroke", TextButton);
    UIStroke.Color = u8 and Color3_fromRGB_ret6 or p6.tint;
    UIStroke.Transparency = u8 and 0.1 or 0.55;
    UIStroke.Thickness = u8 and 2.5 or 1.5;

    if p6.icon then
        local ImageLabel = Instance.new("ImageLabel");
        ImageLabel.BackgroundTransparency = 1;
        ImageLabel.AnchorPoint = Vector2.new(0.5, 0);
        ImageLabel.Position = UDim2.new(0.5, 0, 0, 10);
        ImageLabel.Size = UDim2.new(0, 46, 0, 46);
        ImageLabel.Image = p6.icon;
        ImageLabel.Parent = TextButton;
    else
        local TextLabel = Instance.new("TextLabel");
        TextLabel.BackgroundTransparency = 1;
        TextLabel.AnchorPoint = Vector2.new(0.5, 0);
        TextLabel.Position = UDim2.new(0.5, 0, 0, 10);
        TextLabel.Size = UDim2.new(0, 46, 0, 46);
        TextLabel.Font = Enum.Font.Arcade;
        TextLabel.Text = p6.stat;
        TextLabel.TextSize = 26;
        TextLabel.TextColor3 = p6.tint;
        TextLabel.Parent = TextButton;
    end;

    local TextLabel = Instance.new("TextLabel");
    TextLabel.BackgroundTransparency = 1;
    TextLabel.AnchorPoint = Vector2.new(0.5, 0);
    TextLabel.Position = UDim2.new(0.5, 0, 0, 60);
    TextLabel.Size = UDim2.new(1, -8, 0, 20);
    TextLabel.Font = Enum.Font.Arcade;
    TextLabel.Text = u8 and "Enlightened " .. p6.name or p6.name;
    TextLabel.TextScaled = true;
    TextLabel.TextColor3 = u8 and Color3_fromRGB_ret6 or Color3_fromRGB_ret4;
    TextLabel.Parent = TextButton;
    local TextLabel2 = Instance.new("TextLabel");
    TextLabel2.BackgroundTransparency = 1;
    TextLabel2.AnchorPoint = Vector2.new(0.5, 0);
    TextLabel2.Position = UDim2.new(0.5, 0, 0, 84);
    TextLabel2.Size = UDim2.new(1, -8, 0, 14);
    TextLabel2.Font = Enum.Font.Arcade;
    TextLabel2.Text = p6.desc;
    TextLabel2.TextSize = 11;
    TextLabel2.TextColor3 = Color3_fromRGB_ret5;
    TextLabel2.Parent = TextButton;
    TextButton.MouseEnter:Connect(function() -- Line: 131
        -- upvalues: TweenService (ref), TextButton (copy), TweenInfo_new_ret (ref), Color3_fromRGB_ret3 (ref), UIStroke (copy)
        TweenService:Create(TextButton, TweenInfo_new_ret, {
            BackgroundColor3 = Color3_fromRGB_ret3,
            Size = UDim2.new(0, 116, 0, 116)
        }):Play();
        TweenService:Create(UIStroke, TweenInfo_new_ret, {
            Transparency = 0
        }):Play();
    end);
    TextButton.MouseLeave:Connect(function() -- Line: 135
        -- upvalues: TweenService (ref), TextButton (copy), TweenInfo_new_ret (ref), Color3_fromRGB_ret2 (ref), UIStroke (copy), u8 (copy)
        TweenService:Create(TextButton, TweenInfo_new_ret, {
            BackgroundColor3 = Color3_fromRGB_ret2,
            Size = UDim2.new(0, 110, 0, 110)
        }):Play();
        TweenService:Create(UIStroke, TweenInfo_new_ret, {
            Transparency = u8 and 0.1 or 0.55
        }):Play();
    end);
    TextButton.SelectionGained:Connect(function() -- Line: 140
        -- upvalues: TweenService (ref), TextButton (copy), TweenInfo_new_ret (ref), Color3_fromRGB_ret3 (ref), UIStroke (copy)
        TweenService:Create(TextButton, TweenInfo_new_ret, {
            BackgroundColor3 = Color3_fromRGB_ret3,
            Size = UDim2.new(0, 116, 0, 116)
        }):Play();
        TweenService:Create(UIStroke, TweenInfo_new_ret, {
            Transparency = 0
        }):Play();
    end);
    TextButton.SelectionLost:Connect(function() -- Line: 144
        -- upvalues: TweenService (ref), TextButton (copy), TweenInfo_new_ret (ref), Color3_fromRGB_ret2 (ref), UIStroke (copy), u8 (copy)
        TweenService:Create(TextButton, TweenInfo_new_ret, {
            BackgroundColor3 = Color3_fromRGB_ret2,
            Size = UDim2.new(0, 110, 0, 110)
        }):Play();
        TweenService:Create(UIStroke, TweenInfo_new_ret, {
            Transparency = u8 and 0.1 or 0.55
        }):Play();
    end);
    TextButton.Activated:Connect(p9);

    return TextButton;
end;

local function makeGroup(p10, p11, p12, p13, p14, u15, u16) -- Line: 154
    -- upvalues: makeCard (copy)
    local TextLabel = Instance.new("TextLabel");
    TextLabel.BackgroundTransparency = 1;
    TextLabel.Position = UDim2.new(0, 20, 0, p13);
    TextLabel.Size = UDim2.new(1, -40, 0, 16);
    TextLabel.Font = Enum.Font.Arcade;
    TextLabel.Text = p11;
    TextLabel.TextSize = 14;
    TextLabel.TextXAlignment = Enum.TextXAlignment.Left;
    TextLabel.TextColor3 = p12;
    TextLabel.Parent = p10;
    local Frame = Instance.new("Frame");
    Frame.BackgroundColor3 = p12;
    Frame.BackgroundTransparency = 0.7;
    Frame.BorderSizePixel = 0;
    Frame.Position = UDim2.new(0, 20, 0, p13 + 18);
    Frame.Size = UDim2.new(1, -40, 0, 1);
    Frame.Parent = p10;
    local Frame2 = Instance.new("Frame");
    Frame2.BackgroundTransparency = 1;
    Frame2.Position = UDim2.new(0, 20, 0, p13 + 24);
    Frame2.Size = UDim2.new(1, -40, 0, 120);
    Frame2.Parent = p10;
    local UIListLayout = Instance.new("UIListLayout", Frame2);
    UIListLayout.FillDirection = Enum.FillDirection.Horizontal;
    UIListLayout.HorizontalAlignment = Enum.HorizontalAlignment.Center;
    UIListLayout.VerticalAlignment = Enum.VerticalAlignment.Center;
    UIListLayout.Padding = UDim.new(0, 10);
    local v17 = nil;

    for _, v in ipairs(p14) do
        local v18;

        if v.enlightenStat and u15[v.enlightenStat] then
            v18 = u15[v.enlightenStat] >= (u15.enlightenedBase or (1 / 0));
        else
            v18 = false;
        end;

        v17 = v17 or makeCard(v, Frame2, v18, function() -- Line: 191
            -- upvalues: u16 (copy), u15 (copy), v (copy)
            if u16 then
                u15.onSelectBasic(v.name);

                return;
            end;

            u15.onSelectKi(v.name);
        end);
    end;

    return v17;
end;

function u4.Show(u19) -- Line: 203
    -- upvalues: u4 (copy), LocalPlayer (copy), Color3_fromRGB_ret (copy), u5 (ref), Color3_fromRGB_ret4 (copy), Color3_fromRGB_ret5 (copy), Color3_fromRGB_ret2 (copy), u2 (copy), u1 (copy), makeGroup (copy), Color3_fromRGB_ret7 (copy), Color3_fromRGB_ret8 (copy), u3 (copy), Platform (copy), GuiService (copy)
    if u4.Busy then
        return;
    end;

    u4.Hide();
    local MeditateGui = LocalPlayer.PlayerGui:FindFirstChild("MeditateGui");

    if not MeditateGui then
        return;
    end;

    local Frame = Instance.new("Frame");
    Frame.Name = "MeditationPanel";
    Frame.AnchorPoint = Vector2.new(0.5, 0.5);
    Frame.Position = UDim2.new(0.5, 0, 0.48, 0);
    Frame.Size = UDim2.new(0, 560, 0, 380);
    Frame.BackgroundColor3 = Color3_fromRGB_ret;
    Frame.BackgroundTransparency = 0.08;
    Frame.Parent = MeditateGui;
    u5 = Frame;
    Instance.new("UICorner", Frame).CornerRadius = UDim.new(0, 12);
    local UIStroke = Instance.new("UIStroke", Frame);
    UIStroke.Color = Color3.fromRGB(90, 90, 110);
    UIStroke.Transparency = 0.4;
    UIStroke.Thickness = 1.5;
    local TextLabel = Instance.new("TextLabel");
    TextLabel.BackgroundTransparency = 1;
    TextLabel.Size = UDim2.new(1, 0, 0, 40);
    TextLabel.Position = UDim2.new(0, 0, 0, 8);
    TextLabel.Font = Enum.Font.Arcade;
    TextLabel.Text = "MEDITATION";
    TextLabel.TextSize = 28;
    TextLabel.TextColor3 = Color3_fromRGB_ret4;
    TextLabel.Parent = Frame;
    local TextLabel2 = Instance.new("TextLabel");
    TextLabel2.BackgroundTransparency = 1;
    TextLabel2.Size = UDim2.new(1, 0, 0, 16);
    TextLabel2.Position = UDim2.new(0, 0, 0, 44);
    TextLabel2.Font = Enum.Font.Arcade;
    TextLabel2.Text = "choose your training";
    TextLabel2.TextSize = 13;
    TextLabel2.TextColor3 = Color3_fromRGB_ret5;
    TextLabel2.Parent = Frame;
    local TextButton = Instance.new("TextButton");
    TextButton.AnchorPoint = Vector2.new(1, 0);
    TextButton.Position = UDim2.new(1, -10, 0, 8);
    TextButton.Size = UDim2.new(0, 26, 0, 26);
    TextButton.BackgroundColor3 = Color3_fromRGB_ret2;
    TextButton.Font = Enum.Font.Arcade;
    TextButton.Text = "X";
    TextButton.TextSize = 14;
    TextButton.TextColor3 = Color3_fromRGB_ret5;
    TextButton.Parent = Frame;
    Instance.new("UICorner", TextButton);
    TextButton.Activated:Connect(function() -- Line: 254
        -- upvalues: u19 (copy)
        if u19.onClose then
            u19.onClose();
        end;
    end);
    local v20 = makeGroup(Frame, "KI TRAINING", Color3_fromRGB_ret7, 66, u19.kiUnlocked and u2 or u1, u19, false);
    makeGroup(Frame, "BASIC TRAINING", Color3_fromRGB_ret8, 214, u3, u19, true);

    if Platform.PreferGamepadGlyphs() then
        GuiService.SelectedObject = v20;
        TextButton.Selectable = true;
    end;

    local ContextActionService = game:GetService("ContextActionService");
    ContextActionService:UnbindAction("MeditationMenuBack");
    ContextActionService:BindActionAtPriority("MeditationMenuBack", function(p21, p22) -- Line: 278
        -- upvalues: u5 (ref), u19 (copy)
        if p22 ~= Enum.UserInputState.Begin then
            return Enum.ContextActionResult.Pass;
        end;

        if not u5 then
            return Enum.ContextActionResult.Pass;
        end;

        if u19.onClose then
            u19.onClose();
        end;

        return Enum.ContextActionResult.Sink;
    end, false, Enum.ContextActionPriority.High.Value, Enum.KeyCode.ButtonB);
    local TextLabel3 = Instance.new("TextLabel");
    TextLabel3.BackgroundTransparency = 1;
    TextLabel3.AnchorPoint = Vector2.new(1, 1);
    TextLabel3.Position = UDim2.new(1, -10, 1, -6);
    TextLabel3.Size = UDim2.new(0, 140, 0, 14);
    TextLabel3.Font = Enum.Font.Arcade;
    TextLabel3.TextSize = 10;
    TextLabel3.TextColor3 = Color3_fromRGB_ret5;
    TextLabel3.TextXAlignment = Enum.TextXAlignment.Right;
    TextLabel3.Text = "B  STOP MEDITATING";
    TextLabel3.Visible = Platform.PreferGamepadGlyphs();
    TextLabel3.Parent = Frame;
end;

function u4.Hide() -- Line: 298
    -- upvalues: u5 (ref), GuiService (copy)
    game:GetService("ContextActionService"):UnbindAction("MeditationMenuBack");

    if u5 then
        local SelectedObject = GuiService.SelectedObject;

        if SelectedObject and SelectedObject:IsDescendantOf(u5) then
            GuiService.SelectedObject = nil;
        end;

        u5:Destroy();
        u5 = nil;
    end;
end;

return u4;