-- Decompiled with Potassium's decompiler.

local Players = game:GetService("Players");
game:GetService("Debris");
local ReplicatedStorage = game:GetService("ReplicatedStorage");
game:GetService("ServerStorage");
game:GetService("ServerScriptService");
game:GetService("RunService");
local Modules = ReplicatedStorage:WaitForChild("Modules");
ReplicatedStorage:WaitForChild("Remotes");
local _ = Modules.Metadata;
local _ = Modules.Utility;
local CameraShaker = require(Modules.Shared.CameraShaker);
local StatRetrieveRemote = ReplicatedStorage.Remotes.StatRetrieveRemote;
local workspace_CurrentCamera = workspace.CurrentCamera;
local _ = Players.LocalPlayer;

function ShakeCamera(p1, p2, p3, p4, p5)
    -- upvalues: CameraShaker (copy), workspace_CurrentCamera (copy)
    local v8 = CameraShaker.new(Enum.RenderPriority.Camera.Value, function(p6) -- Line: 31
        -- upvalues: workspace_CurrentCamera (ref)
        local v7 = workspace_CurrentCamera;
        v7.CFrame = v7.CFrame * p6;
    end);
    v8:Start();
    v8:StartShake(p1, p2, p3, 10, 10);
    wait(p4);
    v8:StopSustained(1);
end;

return {
    Shake = function(p9) -- Line: 42
        -- upvalues: StatRetrieveRemote (copy)
        local v10 = p9 and (p9.Mag or 0.4) or 0.4;
        local v11 = p9 and (p9.Rou or 0.9) or 0.9;
        local v12 = p9 and (p9.FadeInTime or 0) or 0;
        local v13 = p9 and (p9.ShakeTime or 0.1) or 0.1;
        local v14 = p9 and p9.FadeOutTime or 0;

        if StatRetrieveRemote:InvokeServer("CameraShake") == false then
            return;
        end;

        ShakeCamera(v10, v11, v12, v13, v14);
    end
};