-- Decompiled with Potassium's decompiler.

game:GetService("Players");
game:GetService("Debris");
local ReplicatedStorage = game:GetService("ReplicatedStorage");
game:GetService("RunService");
game:GetService("CollectionService");
local _ = ReplicatedStorage.Assets;
local Modules = ReplicatedStorage:WaitForChild("Modules");
ReplicatedStorage:WaitForChild("Remotes");
local _ = Modules.Metadata;
local _ = Modules.Utility;
local SoundManager = require(Modules.Shared.SoundManager);
local GlobalFunctions = require(Modules.GlobalFunctions);
local VfxHandler = require(Modules.Effects.VfxHandler);
local v1 = {};
local u2 = {};

function v1.Destroy(u3) -- Line: 28
    -- upvalues: u2 (copy), SoundManager (copy), VfxHandler (copy), GlobalFunctions (copy)
    if u2[u3] then
        return;
    end;

    u2[u3] = true;
    local Transparency = u3.Transparency;
    u3.Transparency = 1;

    if u3.CanCollide == true then
        u3.CanCollide = false;
        task.delay(15, function() -- Line: 39
            -- upvalues: u3 (copy)
            u3.CanCollide = true;
        end);
    end;

    for _, child in pairs(u3:GetChildren()) do
        if child:IsA("Decal") then
            local Transparency2 = child.Transparency;
            child.Transparency = 1;
            task.delay(15, function() -- Line: 49
                -- upvalues: child (copy), Transparency2 (copy)
                child.Transparency = Transparency2;
            end);
        end;
    end;

    SoundManager.AddSound("Broken Ground", {
        Parent = u3
    }, "Client");
    VfxHandler.BlockDebris.Execute({
        MaxParts = 15,
        Transparency = 0,
        Location = u3.CFrame,
        Material = u3.Material,
        Color = u3.Color
    });
    task.delay(15, function() -- Line: 65
        -- upvalues: u2 (ref), u3 (copy), Transparency (copy), GlobalFunctions (ref)
        u2[u3] = nil;
        GlobalFunctions.Tween({
            Instance = u3
        }, {
            Transparency = Transparency
        });
    end);
end;

return v1;