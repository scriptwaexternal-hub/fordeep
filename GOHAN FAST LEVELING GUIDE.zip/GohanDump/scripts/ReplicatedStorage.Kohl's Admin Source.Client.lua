-- Decompiled with Potassium's decompiler.

local script_Parent = require(script.Parent);
local UI = script_Parent.UI;
script_Parent.Announce = require(script:WaitForChild("Announce"));
script_Parent.Notify = require(script:WaitForChild("Notify"));
script_Parent.LocalPlayer = script_Parent.Service.Players.LocalPlayer;
script_Parent.client = {
    TopbarPlus = nil,
    ready = false,
    playerPrefix = ";",
    Character = require(script:WaitForChild("Character")),
    Explorer = require(script:WaitForChild("Explorer")),
    UserFrame = require(script:WaitForChild("UserFrame")),
    bans = script_Parent.Flux.state(script_Parent.Data.bans),
    logs = script_Parent.Flux.state(script_Parent.Data.logs),
    members = script_Parent.Flux.state(script_Parent.Data.members),
    servers = script_Parent.Flux.state(script_Parent.Data.servers),
    rank = script_Parent.Flux.state(0),
    hotkeys = {
        dashboard = {
            callback = nil,
            key = UI.state(Enum.KeyCode.Quote),
            mods = UI.state({})
        }
    },
    settings = {}
};
task.spawn(function() -- Line: 30
    -- upvalues: script_Parent (copy)
    local TopbarPlusReference = script_Parent.Service.ReplicatedStorage:WaitForChild("TopbarPlusReference", 10);

    if TopbarPlusReference then
        local v1 = TopbarPlusReference.Value or TopbarPlusReference.Changed:Wait();
        script_Parent.client.TopbarPlus = require(v1);
    end;
end);

local function deepMergeTheme(p2: any, p3: any, p4: string?) -- Line: 38
    -- upvalues: UI (copy), script_Parent (copy), deepMergeTheme (copy)
    for i, v in p2 do
        local v5 = UI.raw(v);

        if UI.isState(p3[i]) then
            if p4 then
                local v6 = p4 .. i;
                script_Parent.Data.savedSettings[v6] = v5;
                script_Parent.client.settings[v6](v5);
            else
                p3[i](v5);
            end;
        elseif type(v5) == "table" then
            deepMergeTheme(v5, p3[i]);
        end;
    end;
end;

function UI.changeTheme(p7) -- Line: 55
    -- upvalues: deepMergeTheme (copy), UI (copy)
    deepMergeTheme(p7, UI.Theme, "theme");
end;

local u8 = { "font", "stroke", "b", "i", "u", "s", "uc", "sc", "uppercase", "smallcaps", "mark" };
local u9 = {};

for i, v in u8 do
    u9[i] = "<" .. v;
    u8[i] = "</" .. v .. ">?";
end;

local u10 = nil;
local u11 = script_Parent.Util.String.escapePattern(";:!$~.");

local function Chatted(p12: string) -- Line: 69
    -- upvalues: script_Parent (copy), u11 (ref), u10 (ref), u8 (copy), u9 (copy)
    if not script_Parent.ready or script_Parent.Data.settings.chatCommands == false then
        return;
    end;

    local CommandPrefix = script_Parent.getCommandPrefix();
    local v13 = `%s[^%s{script_Parent.Process.ignoreFormat}{script_Parent.Util.String.escapePattern(script_Parent.Data.settings.splitKey or " ")}]`;
    local v14 = nil;

    for _, v in { CommandPrefix, unpack(script_Parent.Data.settings.prefix) } do
        local v15 = script_Parent.Util.String.escapePattern(v);
        v14 = string.find(p12, string.format(v13, v15, v15));

        if v14 then
            break;
        end;
    end;

    if not v14 then
        local v16 = script_Parent.Registry.commands[string.lower(p12)];

        if not (v16 and v16.optionalPrefix) then
            if script_Parent.Data.settings.wrongPrefixWarning ~= false and #u11 > 0 then
                local v17 = " " .. string.lower(p12);

                for i in script_Parent.Registry.commands do
                    local string_find_ret = string.find(v17, (`[{u11}]{script_Parent.Util.String.escapePattern(i)}`));

                    if string_find_ret then
                        u11 = script_Parent.Util.String.escapePattern(u11:gsub("%%", ""):gsub(v17:sub(string_find_ret, string_find_ret), ""));
                        task.spawn(script_Parent.Notify, {
                            From = "_K",
                            Sound = "Call_Leave",
                            Text = `<b>Invalid command prefix, try "{CommandPrefix}{i}"</b>`,
                            TextColor3 = Color3.new(1, 0, 0)
                        });

                        return;
                    end;

                    script_Parent.Util.Defer.wait();
                end;
            end;

            return;
        end;

        p12 = CommandPrefix .. p12;
        v14 = 1;
    end;

    if not u10 then
        u10 = true;
        local string_sub_ret = string.sub(p12, v14);

        for i, v in u8 do
            local string_find_ret = string.find(string_sub_ret, v, 1, true);

            if string_find_ret and string.find(string_sub_ret, u9[i], 1, true) >= string_find_ret then
                string_sub_ret = string.gsub(string_sub_ret, v, "");
            end;
        end;

        script_Parent.Process.runCommands(script_Parent, script_Parent.LocalPlayer.UserId, string_sub_ret);
        task.wait(0.2);
        u10 = nil;
    end;
end;

if script_Parent.Service.TextChat.ChatVersion == Enum.ChatVersion.TextChatService then
    script_Parent.Service.TextChat.SendingMessage:Connect(function(p18: userdata) -- Line: 134
        -- upvalues: Chatted (copy), script_Parent (copy)
        Chatted(script_Parent.Util.String.unescapeRichText(p18.Text));
    end);
end;

script_Parent.Remote.Command:Connect(Chatted);
local u19 = {};

local function u21() -- Line: 144
    -- upvalues: u19 (copy), script_Parent (copy)
    if next(u19) then
        return true;
    end;

    local v20 = script_Parent.Service.TextChat:FindFirstChildOfClass("ChatInputBarConfiguration");

    return v20 and v20.IsFocused and true or false;
end;

script_Parent.Service.UserInput.TextBoxFocused:Connect(function(p22) -- Line: 155
    -- upvalues: u19 (copy)
    if not (p22 and p22.TextEditable) then
        return;
    end;

    u19[p22] = true;
end);
script_Parent.Service.UserInput.TextBoxFocusReleased:Connect(function(p23) -- Line: 161
    -- upvalues: u19 (copy)
    if not (p23 and p23.TextEditable) then
        return;
    end;

    u19[p23] = nil;
end);
script_Parent.Service.UserInput.InputBegan:Connect(function(p24, p25) -- Line: 169
    -- upvalues: u21 (ref), script_Parent (copy)
    if p24.UserInputType == Enum.UserInputType.Keyboard and not u21() then
        for _, v in script_Parent.client.hotkeys do
            if v.callback and (p24.KeyCode == v.key._value or type(v.key._value) == "table" and table.find(v.key._value, p24.KeyCode)) then
                local v26 = v;
                local v27 = false;

                for _, v2 in Enum.ModifierKey:GetEnumItems() do
                    if p24:IsModifierKeyDown(v2) == not v26.mods._value[v2.Name] then
                        v27 = true;
                        break;
                    end;
                end;

                if v27 then
                    return;
                end;

                task.defer(v26.callback);
            end;
        end;
    end;
end);
script_Parent.Remote.Init:Once(function(p28, p29, p30, p31, p32, p33, p34, p35) -- Line: 198
    -- upvalues: script_Parent (copy), UI (copy)
    if p28 then
        script_Parent.Util.Table.merge(script_Parent.Data.bans, p28);
        script_Parent.client.bans(script_Parent.Data.bans);
    end;

    if p29 then
        local success, result = pcall(script_Parent.Z.des, script_Parent.Data.Schema.logsRemote, p29);

        if not success then
            warn(result);
        end;

        if success and result then
            table.move(result, 1, #result, #script_Parent.Data.logs + 1, script_Parent.Data.logs);
            table.sort(script_Parent.Data.logs, script_Parent.Logger.sortTime);
        end;
    end;

    if p32 then
        script_Parent.Util.Table.merge(script_Parent.Data.reservedServers, p32);
    end;

    if p33 then
        script_Parent.Util.Table.merge(script_Parent.Data.servers, p33);
        script_Parent.client.servers(script_Parent.Data.servers);
    end;

    script_Parent.Util.Table.merge(script_Parent.Data.members, p30);
    script_Parent.client.members(script_Parent.Data.members);
    script_Parent.Data.roles = p31;

    for _, v in p31 do
        if not table.find(script_Parent.Data.rolesList, v) then
            table.insert(script_Parent.Data.rolesList, v);
        end;
    end;

    table.sort(script_Parent.Data.rolesList, function(p36, p37) -- Line: 234
        return p36._rank < p37._rank;
    end);
    local v38 = UI.Themes[p35.theme];

    if v38 then
        for i, v in v38 do
            if v._value ~= nil then
                p35["theme" .. i] = v._value;
            end;
        end;
    end;

    local merge = script_Parent.Util.Table.merge;
    script_Parent.Data.defaultSettings = merge(table.clone(script_Parent.Data.settings), p35);
    script_Parent.Data.savedSettings = merge(script_Parent.Util.Table.deepCopy(script_Parent.Data.defaultSettings), p34);
    local v39;

    if script_Parent.Data.savedSettings.useSavedSettings == false then
        v39 = script_Parent.Data.defaultSettings;
    else
        v39 = script_Parent.Data.savedSettings;
    end;

    script_Parent.Data.settings = v39;
    script_Parent.client.playerPrefix = script_Parent.Flux.state(script_Parent.Data.settings.prefix[1]);

    for i, v in script_Parent.Data.settings do
        local v40;

        if i == "useSavedSettings" then
            v40 = script_Parent.Data.savedSettings.useSavedSettings;
        else
            v40 = v;
        end;

        local v41;

        if i == "theme" or string.find(i, "theme", 1, true) ~= 1 then
            v41 = nil;
        else
            v41 = UI.Theme[string.sub(i, 6)];

            if v41 then
                v41(v40);
            end;
        end;

        local v42 = v41 or script_Parent.Flux.state(v40);
        script_Parent.client.settings[i] = v42;

        if i == "theme" then
            v42:Connect(function(p43) -- Line: 272
                -- upvalues: UI (ref)
                local v44 = UI.Themes[p43];

                if v44 then
                    UI.changeTheme(v44);
                end;
            end);
        elseif string.find(i, "theme", 1, true) == 1 then
            local string_sub_ret = string.sub(i, 6);

            if UI.Theme[string_sub_ret] then
                v42:Connect(function(p45) -- Line: 281
                    -- upvalues: UI (ref), string_sub_ret (ref)
                    UI.Theme[string_sub_ret](p45);
                end);
            end;
        elseif i == "useSavedSettings" then
            v42:Connect(function(p46) -- Line: 286
                -- upvalues: script_Parent (ref)
                local v47;

                if p46 then
                    v47 = script_Parent.Data.savedSettings;
                else
                    v47 = script_Parent.Data.defaultSettings;
                end;

                script_Parent.Data.settings = v47;

                for i2, v2 in v47 do
                    if i2 ~= "useSavedSettings" and script_Parent.client.settings[i2] then
                        script_Parent.client.settings[i2](v2, true);
                    end;
                end;
            end);
        end;
    end;

    script_Parent.client.CommandBar = require(script:WaitForChild("CommandBar"));
    script_Parent.client.CommandBar:init(script_Parent);
    script_Parent.client.Dashboard = require((script:WaitForChild("Dashboard")));
    require(script:WaitForChild("GetKA"));
    require(script:WaitForChild("Network"));

    function script_Parent.client.rolesNotification() -- Line: 304
        -- upvalues: script_Parent (ref), UI (ref)
        local v48 = script_Parent.Data.members[tostring(script_Parent.LocalPlayer.UserId)];
        local v49 = {};

        if v48 and v48.roles then
            for _, v in v48.roles do
                local v50 = script_Parent.Data.roles[v];

                if v50 then
                    local v51 = `<font color="{v50.color}">{v50.name}</font>`;
                    table.insert(v49, v51);
                end;
            end;
        end;

        for _, v in script_Parent.Data.settings.freeAdmin do
            if not (v48 and (v48.roles and table.find(v48.roles, v))) then
                local v52 = script_Parent.Data.roles[v];

                if v52 then
                    local v53 = `<font color="{v52.color}">{v52.name}</font>`;
                    table.insert(v49, v53);
                end;
            end;
        end;

        local v54 = `<font color="{script_Parent.Data.roles.everyone.color}">{script_Parent.Data.roles.everyone.name}</font>`;
        table.insert(v49, v54);
        local table_concat_ret = table.concat(v49, ", ");
        local v55 = table_concat_ret:sub(1, 1):lower():match("aeiou") and "n" or "";
        script_Parent.Notify({
            From = "_K",
            Duration = 15,
            Text = `<font family="{UI.Theme.FontMono._value.Family}"><b>You're a{v55}</b> <sc>{table_concat_ret}</sc></font>\n\n<i>Click to see the commands.</i>`,

            Activated = function() -- Line: 332, Name: Activated
                -- upvalues: script_Parent (ref)
                script_Parent.client.commandsWindowVisible(true);
            end
        });
    end;

    if script_Parent.Data.settings.joinNotificationRank and script_Parent.Auth.getRank(script_Parent.Service.Players.LocalPlayer.UserId) >= script_Parent.Data.settings.joinNotificationRank then
        script_Parent.client.rolesNotification();
    end;

    local u56 = false;

    local function vipNotificationClosed() -- Line: 348
        -- upvalues: u56 (ref)
        u56 = false;
    end;

    local function showPopup() -- Line: 352
        -- upvalues: script_Parent (ref), u56 (ref)
        script_Parent.VIP.popup.Visible = true;
        u56 = false;
    end;

    script_Parent.client.VIPNotification = script_Parent.Util.Function.throttle(300, function() -- Line: 357
        -- upvalues: u56 (ref), script_Parent (ref), showPopup (copy), vipNotificationClosed (copy)
        if u56 or (script_Parent.VIP.popup.Visible or not (script_Parent.Data.settings.vip and (script_Parent.Data.settings.chatCommandsNotification and (script_Parent.LocalPlayer:GetAttribute("_KDonationLevel") or 0) <= 2))) then
            return;
        end;

        u56 = true;
        local Attribute = script_Parent.LocalPlayer:GetAttribute("_KInitialJoin");
        local v57 = workspace:GetServerTimeNow() - Attribute > 600 and "Unlock exclusive chat commands in <b>10k+</b> experiences for <font color=\'#0f0\'><b>40% OFF</b></font>!" or "Unlock <b>exclusive</b> chat commands in <b>10k+</b> experiences!";
        script_Parent.Notify({
            From = "System",
            Duration = 60,
            Sound = "Call_Accept",
            Text = `{v57}\n\n<i>Click for more details.</i>`,
            Activated = showPopup,
            Close = vipNotificationClosed
        });
    end);
    script_Parent.Remote.VIPNotification:Connect(script_Parent.client.VIPNotification);
    script_Parent.Hook.postCommand:Connect(script_Parent.client.VIPNotification);
    script_Parent.client.dashboard.Commands._instance:GetPropertyChangedSignal("Visible"):Once(script_Parent.client.VIPNotification);
    script_Parent.client.dashboard.Window._instance:GetPropertyChangedSignal("Visible"):Once(script_Parent.client.VIPNotification);
    script_Parent.VIP.popup.Parent = UI.LayerTopInset;
    local u58 = nil;

    local function showOnFirstOpen() -- Line: 393
        -- upvalues: script_Parent (ref), u56 (ref), u58 (ref)
        if script_Parent.Data.settings.vip and (not u56 and (script_Parent.LocalPlayer:GetAttribute("_KDonationLevel") or 0) < 3) then
            script_Parent.VIP.popup.Visible = true;
            script_Parent.Flux.cleanup(u58);
        end;
    end;

    u58 = { script_Parent.client.dashboard.Commands._instance:GetPropertyChangedSignal("Visible"):Once(showOnFirstOpen), script_Parent.client.dashboard.Window._instance:GetPropertyChangedSignal("Visible"):Once(showOnFirstOpen) };

    if p34.announcement then
        local v59, v60 = unpack(p34.announcement);
        task.spawn(script_Parent.Announce, {
            Duration = 0,
            From = v60,
            Text = v59
        });
    end;

    if script_Parent.Data.settings.announcements then
        for _, v in script_Parent.Data.settings.announcements do
            task.spawn(script_Parent.Announce, v);
        end;
    end;

    if script_Parent.Data.settings.notifications then
        for _, v in script_Parent.Data.settings.notifications do
            task.spawn(script_Parent.Notify, v);
        end;
    end;

    if not game:IsLoaded() then
        game.Loaded:Wait();
    end;

    local function loadAddons(p61) -- Line: 436
        -- upvalues: script_Parent (ref), loadAddons (copy)
        for _, v in p61 do
            if v:IsA("ModuleScript") then
                task.spawn(function() -- Line: 439
                    -- upvalues: v (copy), script_Parent (ref)
                    require(v)(script_Parent);
                end);
            else
                loadAddons(v:GetChildren());
            end;
        end;
    end;

    loadAddons(script_Parent.script.Shared:WaitForChild("DefaultAddons"):GetChildren());
    loadAddons(script_Parent.script:WaitForChild("Addons"):GetChildren());
    loadAddons(script_Parent.Service.Collection:GetTagged(script_Parent._addonTag));
    script_Parent.client.updateInterfaceAuth();
    script_Parent.ready = true;
    script_Parent.Hook.init:Fire();
    task.spawn(function() -- Line: 457
        -- upvalues: script_Parent (ref)
        local v62;

        if script_Parent.Auth.hasRestrictedRole(script_Parent.LocalPlayer.UserId) then
            v62 = script_Parent.client.dashboard.About;
        else
            v62 = script_Parent.client.dashboard.Market;
        end;

        script_Parent.client.dashboard.Tabs._pages:JumpTo(script_Parent.client.dashboard.Tabs._containerCache[v62._instance]);
    end);
end);
script_Parent.Remote.Init:Fire({
    Attributes = {
        Platform = UI.Platform,
        SessionStart = workspace:GetServerTimeNow()
    }
});
local u63 = time();

local function resetIdle() -- Line: 468
    -- upvalues: u63 (ref), script_Parent (copy)
    if u63 < time() - 30 then
        script_Parent.Remote.Idled:Fire(0);
    end;
end;

script_Parent.Service.Players.LocalPlayer.Idled:Connect(function(p64) -- Line: 474
    -- upvalues: u63 (ref), script_Parent (copy), resetIdle (copy)
    u63 = time();
    script_Parent.Remote.Idled:Fire(p64);
    task.delay(35, resetIdle);
end);