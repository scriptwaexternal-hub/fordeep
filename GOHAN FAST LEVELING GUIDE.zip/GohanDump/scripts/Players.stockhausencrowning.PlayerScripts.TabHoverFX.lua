-- Decompiled with Potassium's decompiler.

local Players = game:GetService("Players");
local ReplicatedStorage = game:GetService("ReplicatedStorage");
local SoundService = game:GetService("SoundService");
local TweenService = game:GetService("TweenService");
local PlayerGui = Players.LocalPlayer:WaitForChild("PlayerGui");
local Color3_fromRGB_ret = Color3.fromRGB(255, 221, 64);
local TweenInfo_new_ret = TweenInfo.new(0.12, Enum.EasingStyle.Quad, Enum.EasingDirection.Out);
local u1 = ReplicatedStorage:WaitForChild("Assets"):WaitForChild("Sounds"):FindFirstChild("Slot Hover", true);
local u2 = 0;

local function tick() -- Line: 17
    -- upvalues: u1 (copy), u2 (ref), SoundService (copy)
    if not u1 or os.clock() - u2 < 0.05 then
        return;
    end;

    u2 = os.clock();
    SoundService:PlayLocalSound(u1);
end;

local u3 = setmetatable({}, {
    __mode = "k"
});

local function wire(p4) -- Line: 24
    -- upvalues: u3 (copy), TweenService (copy), TweenInfo_new_ret (copy), Color3_fromRGB_ret (copy), u1 (copy), u2 (ref), SoundService (copy)
    if u3[p4] or not p4:IsA("GuiButton") then
        return;
    end;

    u3[p4] = true;
    local u5 = p4:FindFirstChild("HoverScale") or Instance.new("UIScale");
    u5.Name = "HoverScale";
    u5.Parent = p4;
    local u6 = p4:FindFirstChildWhichIsA("TextLabel") or p4:IsA("TextButton") and p4;
    local u7 = nil;
    p4.MouseEnter:Connect(function() -- Line: 31
        -- upvalues: TweenService (ref), u5 (copy), TweenInfo_new_ret (ref), u6 (copy), u7 (ref), Color3_fromRGB_ret (ref), u1 (ref), u2 (ref), SoundService (ref)
        TweenService:Create(u5, TweenInfo_new_ret, {
            Scale = 1.08
        }):Play();

        if u6 then
            u7 = u6.TextColor3;
            u6.TextColor3 = Color3_fromRGB_ret;
        end;

        if u1 then
            if os.clock() - u2 < 0.05 then
                return;
            end;

            u2 = os.clock();
            SoundService:PlayLocalSound(u1);
        end;
    end);

    local function leave() -- Line: 36
        -- upvalues: TweenService (ref), u5 (copy), TweenInfo_new_ret (ref), u6 (copy), u7 (ref), Color3_fromRGB_ret (ref)
        TweenService:Create(u5, TweenInfo_new_ret, {
            Scale = 1
        }):Play();

        if u6 and (u7 and u6.TextColor3 == Color3_fromRGB_ret) then
            u6.TextColor3 = u7;
        end;

        u7 = nil;
    end;

    p4.MouseLeave:Connect(leave);
    p4.Activated:Connect(leave);
end;

local function hook(u8) -- Line: 47
    -- upvalues: wire (copy)
    if u8.Name ~= "HUD" then
        return;
    end;

    task.spawn(function() -- Line: 49
        -- upvalues: u8 (copy), wire (ref)
        local Inventory = u8:WaitForChild("Inventory", 30);

        if Inventory then
            Inventory = Inventory:WaitForChild("StatFrame", 30);
        end;

        if Inventory then
            Inventory = Inventory:WaitForChild("Tabs", 30);
        end;

        if not Inventory then
            return;
        end;

        for _, child in ipairs(Inventory:GetChildren()) do
            wire(child);
        end;

        Inventory.ChildAdded:Connect(function(p9) -- Line: 55
            -- upvalues: wire (ref)
            task.defer(wire, p9);
        end);
    end);
end;

for _, child in ipairs(PlayerGui:GetChildren()) do
    if child.Name == "HUD" then
        task.spawn(function() -- Line: 49
            -- upvalues: child (copy), wire (copy)
            local Inventory = child:WaitForChild("Inventory", 30);

            if Inventory then
                Inventory = Inventory:WaitForChild("StatFrame", 30);
            end;

            if Inventory then
                Inventory = Inventory:WaitForChild("Tabs", 30);
            end;

            if not Inventory then
                return;
            end;

            for _, child2 in ipairs(Inventory:GetChildren()) do
                wire(child2);
            end;

            Inventory.ChildAdded:Connect(function(p10) -- Line: 55
                -- upvalues: wire (ref)
                task.defer(wire, p10);
            end);
        end);
    end;
end;

PlayerGui.ChildAdded:Connect(hook);