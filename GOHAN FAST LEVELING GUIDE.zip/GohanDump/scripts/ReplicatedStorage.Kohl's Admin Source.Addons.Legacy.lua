-- Decompiled with Potassium's decompiler.

local u1 = { {
        group = "GameCreator",
        role = "creator"
    }, {
        group = "Creator",
        role = "superadmin"
    }, {
        group = "SuperAdmin",
        role = "admin"
    }, {
        group = "Administration",
        role = "mod"
    }, {
        group = "Administration",
        role = "vip"
    } };

return function(u2) -- Line: 24
    -- upvalues: u1 (copy)
    for _, v in u1 do
        local role = v.role;

        if u2.Data.roles[role] then
            local function run(u3, p4) -- Line: 34
                -- upvalues: role (copy)
                local u5 = u3._K.Data.roles[role];
                local u6 = {};

                for _, v2 in p4 do
                    if u3._K.Auth.userRoleAdd(v2, role, u3.definition.permissions.saveRoles) then
                        table.insert(u6, v2);
                        local PlayerByUserId = u3._K.Service.Players:GetPlayerByUserId(v2);

                        if PlayerByUserId then
                            local CommandPrefix = u3._K.getCommandPrefix(v2);
                            u3._K.Remote.Notify:Fire(PlayerByUserId, {
                                Text = `Gave you the <b><font color="{u5.color}">{u5.name}</font></b> role!\nSay <b>{CommandPrefix}cmds</b> or <b>{CommandPrefix}info</b> for details.`,
                                From = u3.from
                            });
                        end;
                    end;
                end;

                if #u6 == 0 then
                    return;
                end;

                task.spawn(function() -- Line: 56
                    -- upvalues: u6 (copy), u3 (copy), u5 (copy)
                    local v7 = {};

                    for _, v2 in u6 do
                        local DisplayName = u3._K.Util.getUserInfo(v2).DisplayName;
                        table.insert(v7, DisplayName);
                    end;

                    u3._K.Remote.Notify:Fire(u3.fromPlayer, {
                        From = "_K",
                        Text = `<b>Gave Role:</b> <b><font color="{u5.color}">{u5.name}</font></b>\n<b>To:</b> <i>{table.concat(v7, ", ")}</i>`
                    });
                end);
            end;

            u2.Registry.registerCommand(u2, {
                name = role,
                description = `Gives the {role} role to one or more user(s).`,
                group = v.group,
                permissions = {
                    saveRoles = true
                },
                args = {
                    {
                        type = "userIds",
                        name = "Users(s)",
                        description = `The user(s) to give the {role} role to.`
                    }
                },
                run = run
            });
            u2.Registry.registerCommand(u2, {
                name = "temp" .. role,
                description = `Gives the {role} role temporarily to one or more user(s).`,
                group = v.group,
                permissions = {},
                args = {
                    {
                        type = "userIds",
                        name = "Users(s)",
                        description = `The user(s) to give the {role} role to.`
                    }
                },
                run = run
            });
            u2.Registry.registerCommand(u2, {
                name = "un" .. role,
                description = `Removes the {role} role from one or more member(s).`,
                group = v.group,
                args = {
                    {
                        type = "members",
                        name = "Member(s)",
                        lowerRank = true,
                        description = `The member(s) to remove the {role} role from.`
                    }
                },

                run = function(p8, p9) -- Line: 115, Name: run
                    -- upvalues: role (copy)
                    local v10 = {};

                    for _, v2 in p9 do
                        local v11 = p8._K.Data.members[tostring(v2)];

                        if p8._K.Auth.userRoleRemove(v2, role) then
                            local v12;

                            if v11 then
                                v12 = v11.name or v2;
                            else
                                v12 = v2;
                            end;

                            table.insert(v10, v12);
                        end;
                    end;

                    if #v10 == 0 then
                        return;
                    end;

                    local v13 = p8._K.Data.roles[role];
                    p8._K.Remote.Notify:Fire(p8.fromPlayer, {
                        Text = `<b>Removed Roles:</b> <b><font color="{v13.color}">{v13.name}</font></b>\n<b>From:</b> <i>{table.concat(v10, ", ")}</i>`
                    });
                end
            });
        end;
    end;

    task.spawn(function() -- Line: 139
        -- upvalues: u2 (copy)
        local Parent = script.Parent.Parent;
        local v14;

        if Parent then
            v14 = Parent:WaitForChild("Config", 5);
        else
            v14 = Parent;
        end;

        local v15;

        if v14 then
            v15 = v14:FindFirstChild("Legacy") or v14:FindFirstChild("LegacyConfig");
        else
            v15 = v14;
        end;

        if not v15 then
            warn("LegacyConfig was not found", Parent ~= nil, v14 ~= nil);

            return;
        end;

        local Settings = require((v15:WaitForChild("Settings")));
        local v16 = v15:FindFirstChild("Custom_Commands") or v15:FindFirstChild("Custom Commands");

        if v16 then
            v16 = require(v16);
        end;

        if type(v16) == "table" then
            local v17 = {
                player = "players",
                userid = "userIds",
                boolean = "boolean",
                color = "color",
                number = "number",
                string = "rawString",
                word = "rawString",
                time = "timeSimple",
                banned = "ban",
                admin = "member"
            };
            local v18 = {
                [0] = "Utility",
                [1] = "VIP",
                [2] = "Moderation",
                [3] = "Administration",
                [4] = "SuperAdmin",
                [5] = "Creator"
            };

            for _, v in v16 do
                local v19, v20, v21, v22, u23 = unpack(v);
                local v24 = {};

                for _, v2 in v22 do
                    local string_lower_ret = string.lower(v2);
                    local string_find_ret = string.find(string_lower_ret, "/$");

                    if string_find_ret then
                        string_lower_ret = string.sub(string_lower_ret, 1, -2);
                    end;

                    table.insert(v24, {
                        description = "Migrated from Legacy custom commands.",
                        type = v17[string_lower_ret],
                        name = v17[string_lower_ret],
                        optional = string_find_ret
                    });
                end;

                u2.Registry.registerCommand(u2, {
                    name = v19[1],
                    aliases = { unpack(v19, 2) },
                    description = tostring(v20[1]) .. "\nMigrated from Legacy config.",
                    group = v18[math.clamp(v21, 0, 5)],
                    args = v24,

                    run = function(p25, ...) -- Line: 202, Name: run
                        -- upvalues: u23 (copy)
                        u23(p25.fromPlayer, { ... });
                    end
                });
            end;
        end;

        if not u2.IsServer or type(Settings) ~= "table" then
            return;
        end;

        local v26, v27 = unpack(Settings);
        local v28, v29, v30, v31, v32, v33 = unpack(v27);

        local function banUser(u34) -- Line: 220
            -- upvalues: u2 (ref)
            if type(u34) == "string" then
                local v35, v36 = u2.Util.Retry(function() -- Line: 222
                    -- upvalues: u2 (ref), u34 (ref)
                    return u2.Service.Players:GetUserIdFromNameAsync(u34);
                end);

                if v35 then
                    u34 = v36;
                end;
            end;

            if u34 then
                u2.Auth.banUsers({ u34 }, "Migrated from Legacy bans.", 0, u2.creatorId);
            end;
        end;

        for _, v in v33 do
            task.spawn(banUser, v);
        end;

        local u37 = { "vip", "mod", "admin", "superadmin", "creator" };

        local function getRoleFromRank(p38) -- Line: 241
            -- upvalues: u37 (copy), u2 (ref)
            local v39 = tonumber(p38);

            if v39 then
                local math_abs_ret = math.abs(v39);
                local math_clamp_ret = math.clamp(math_abs_ret, 1, 5);
                local v40 = u37[math_clamp_ret];

                if u2.Data.roles[v40] then
                    return v40;
                end;

                for i, v in u2.Data.roles do
                    if v._rank == math_clamp_ret then
                        return i;
                    end;
                end;
            end;
        end;

        local function roleUser(u41, p42) -- Line: 258
            -- upvalues: u37 (copy), u2 (ref)
            local v43 = tonumber(p42);
            local v44;

            if v43 then
                local math_abs_ret = math.abs(v43);
                local math_clamp_ret = math.clamp(math_abs_ret, 1, 5);
                v44 = u37[math_clamp_ret];

                if not u2.Data.roles[v44] then
                    v44 = nil;

                    for i, v in u2.Data.roles do
                        if v._rank == math_clamp_ret then
                            v44 = i;
                            break;
                        end;
                    end;
                end;
            end;

            if v44 then
                if type(u41) == "string" then
                    local v45, v46 = u2.Util.Retry(function() -- Line: 262
                        -- upvalues: u2 (ref), u41 (ref)
                        return u2.Service.Players:GetUserIdFromNameAsync(u41);
                    end);

                    if v45 then
                        u41 = v46;
                    end;
                end;

                if u41 then
                    u2.Auth.userRoleAdd(u41, v44);
                end;
            end;
        end;

        for i, v in {
            v32,
            v31,
            v30,
            v29,
            v28
        } do
            local v47 = i;

            for _, v2 in v do
                task.spawn(roleUser, v2, v47);
            end;
        end;

        if type(v26.GroupAdmin) == "table" then
            local v48 = {};

            for i, v in v26.GroupAdmin do
                local v49 = {};

                for i2, v2 in v do
                    local v50 = tonumber(i2);
                    local v51 = tonumber(v2);
                    local v52;

                    if v51 then
                        local math_abs_ret = math.abs(v51);
                        local math_clamp_ret = math.clamp(math_abs_ret, 1, 5);
                        v52 = u37[math_clamp_ret];

                        if not u2.Data.roles[v52] then
                            v52 = nil;

                            for i3, v3 in u2.Data.roles do
                                if v3._rank == math_clamp_ret then
                                    v52 = i3;
                                    break;
                                end;
                            end;
                        end;
                    end;

                    if v52 and v50 then
                        table.insert(v49, {
                            rank = v50,
                            roles = { v52 }
                        });
                    end;
                end;

                v48[i] = v49;
            end;

            u2.Util.Table.deepMerge(u2.Data.async.group, v48, true);
        end;

        if type(v26.VIPAdmin) == "table" then
            local v53 = {};
            local v54 = {};

            for i, v in v26.VIPAdmin do
                local v55 = tonumber(v);
                local v56, v57;

                if v55 then
                    local math_abs_ret = math.abs(v55);
                    local math_clamp_ret = math.clamp(math_abs_ret, 1, 5);
                    v56 = u37[math_clamp_ret];

                    if u2.Data.roles[v56] then
                        v57 = i;
                    else
                        v57 = i;
                        v56 = nil;

                        for i2, v2 in u2.Data.roles do
                            if v2._rank == math_clamp_ret then
                                v56 = i2;
                                break;
                            end;
                        end;
                    end;
                else
                    v57 = i;
                end;

                if v56 and tonumber(v57) then
                    local v58;

                    if v57 > 0 then
                        v58 = v53;
                    else
                        v58 = v54;
                    end;

                    v58[v57] = { v56 };
                end;
            end;

            u2.Util.Table.deepMerge(u2.Data.async.asset, v53, true);
            u2.Util.Table.deepMerge(u2.Data.async.gamepass, v54, true);
            u2.setupPurchasables(v53, "assets");
            u2.setupPurchasables(v54, "gamepasses");
        end;

        if v26.AdminCredit == false then
            u2.Data.defaultSettings.dashboardButtonRank = false;
        end;

        if v26.CommandBar == false then
            u2.Data.defaultSettings.commandBarRank = false;
        end;

        if v26.JoinMessage == false then
            u2.Data.defaultSettings.joinNotificationRank = false;
        end;

        if v26.PublicLogs == true then
            u2.Data.roles.everyone.permissions.serverlogs = true;
        end;

        if v26.Prefix ~= ";" then
            u2.Data.defaultSettings.prefix = { v26.Prefix };
        end;

        if tonumber(v26.FreeAdmin) then
            local v59 = tonumber(v26.FreeAdmin);
            local v60;

            if v59 then
                local math_abs_ret = math.abs(v59);
                local math_clamp_ret = math.clamp(math_abs_ret, 1, 5);
                v60 = u37[math_clamp_ret];

                if not u2.Data.roles[v60] then
                    v60 = nil;

                    for i, v in u2.Data.roles do
                        if v._rank == math_clamp_ret then
                            v60 = i;
                            break;
                        end;
                    end;
                end;
            end;

            if v60 and not table.find(u2.Data.settings.freeAdmin, v60) then
                table.insert(u2.Data.settings.freeAdmin, v60);
            end;
        end;

        if type(v26.Permissions) == "table" then
            for i, v in v26.Permissions do
                local v61 = tonumber(v);

                if i and v61 then
                    local math_clamp_ret = math.clamp(v61, 0, (1 / 0));
                    local v62 = i;

                    for _, v2 in u2.Data.roles do
                        v2.commands[v62] = math_clamp_ret <= v2._rank;
                    end;
                end;
            end;
        end;
    end);
end;