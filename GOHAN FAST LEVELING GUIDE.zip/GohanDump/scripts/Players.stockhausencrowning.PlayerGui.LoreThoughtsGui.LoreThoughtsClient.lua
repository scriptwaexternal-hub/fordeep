-- Decompiled with Potassium's decompiler.

local Players = game:GetService("Players");
local ReplicatedStorage = game:GetService("ReplicatedStorage");
local TweenService = game:GetService("TweenService");
local LoreThoughtRemote = ReplicatedStorage:WaitForChild("Remotes"):WaitForChild("LoreThoughtRemote");
local RarityData = require(ReplicatedStorage:WaitForChild("Modules"):WaitForChild("Metadata"):WaitForChild("ItemData"):WaitForChild("RarityData"));
local script_Parent = script.Parent;
local ThoughtList = script_Parent:WaitForChild("ThoughtList");
ThoughtList.Position = UDim2.fromScale(0.995, 0.838);
ThoughtList.Size = UDim2.fromScale(0.24, 0.55);
local Color3_fromRGB_ret = Color3.fromRGB(26, 18, 38);
local Color3_fromRGB_ret2 = Color3.fromRGB(122, 92, 170);
local Color3_fromRGB_ret3 = Color3.fromRGB(238, 234, 245);
local Color3_fromRGB_ret4 = Color3.fromRGB(176, 166, 194);
local u1 = { "thinks", "wonders", "considers", "questions" };
local u2 = 0;
local u3 = {};
local u4 = nil;

local function makeClone(p5) -- Line: 49
    p5.Archivable = true;
    local v6 = p5:Clone();

    if not v6 then
        return nil;
    end;

    for _, descendant in ipairs(v6:GetDescendants()) do
        if descendant:IsA("BaseScript") or descendant:IsA("ModuleScript") then
            descendant:Destroy();
        end;
    end;

    return v6;
end;

local function buildPortraitIn(p7, p8) -- Line: 61
    -- upvalues: makeClone (copy)
    local v9 = makeClone(p8);

    if not v9 then
        return;
    end;

    v9.Parent = p7;
    local Head = v9:FindFirstChild("Head");
    local HumanoidRootPart = v9:FindFirstChild("HumanoidRootPart");

    if Head and HumanoidRootPart then
        local Camera = Instance.new("Camera");
        Camera.Parent = p7;
        p7.CurrentCamera = Camera;
        Camera.FieldOfView = 45;
        Camera.CFrame = CFrame.lookAt((HumanoidRootPart.CFrame * CFrame.new(0.25, 0.85, -3.8)).Position, Head.Position);
    end;
end;

local function closeDetail() -- Line: 78
    -- upvalues: u4 (ref)
    if u4 then
        u4:Destroy();
        u4 = nil;
    end;
end;

local function removePrompt(p10) -- Line: 85
    -- upvalues: u3 (copy)
    for i, v in ipairs(u3) do
        if v == p10 then
            table.remove(u3, i);
            break;
        end;
    end;

    p10:Destroy();
end;

local function openDetail(u11, p12, p13, p14) -- Line: 92
    -- upvalues: u4 (ref), Color3_fromRGB_ret (copy), script_Parent (copy), Color3_fromRGB_ret2 (copy), buildPortraitIn (copy), u1 (copy), Color3_fromRGB_ret3 (copy), Color3_fromRGB_ret4 (copy), removePrompt (copy)
    if u4 then
        u4:Destroy();
        u4 = nil;
    end;

    local Frame = Instance.new("Frame");
    Frame.Name = "ThoughtDetail";
    Frame.AnchorPoint = Vector2.new(1, 1);
    Frame.Position = UDim2.fromScale(0.995, 0.9);
    Frame.Size = UDim2.new(0, 300, 0, 0);
    Frame.AutomaticSize = Enum.AutomaticSize.Y;
    Frame.BackgroundColor3 = Color3_fromRGB_ret;
    Frame.BackgroundTransparency = 0.06;
    Frame.BorderSizePixel = 0;
    Frame.ZIndex = 5;
    Frame.Parent = script_Parent;
    local UICorner = Instance.new("UICorner");
    UICorner.CornerRadius = UDim.new(0, 8);
    UICorner.Parent = Frame;
    local UIStroke = Instance.new("UIStroke");
    UIStroke.Color = Color3_fromRGB_ret2;
    UIStroke.Thickness = 1.5;
    UIStroke.Parent = Frame;
    local UIPadding = Instance.new("UIPadding");
    UIPadding.PaddingTop = UDim.new(0, 10);
    UIPadding.PaddingBottom = UDim.new(0, 10);
    UIPadding.PaddingLeft = UDim.new(0, 10);
    UIPadding.PaddingRight = UDim.new(0, 10);
    UIPadding.Parent = Frame;
    local Frame2 = Instance.new("Frame");
    Frame2.Size = UDim2.new(0, 52, 0, 52);
    Frame2.BackgroundColor3 = Color3.fromRGB(16, 11, 24);
    Frame2.BorderSizePixel = 0;
    Frame2.ZIndex = 6;
    Frame2.Parent = Frame;
    local UICorner2 = Instance.new("UICorner");
    UICorner2.CornerRadius = UDim.new(0, 6);
    UICorner2.Parent = Frame2;
    local UIStroke2 = Instance.new("UIStroke");
    UIStroke2.Color = Color3_fromRGB_ret2;
    UIStroke2.Thickness = 1.5;
    UIStroke2.Parent = Frame2;
    local ViewportFrame = Instance.new("ViewportFrame");
    ViewportFrame.Size = UDim2.fromScale(1, 1);
    ViewportFrame.BackgroundTransparency = 1;
    ViewportFrame.Ambient = Color3.fromRGB(120, 105, 140);
    ViewportFrame.LightColor = Color3.fromRGB(235, 225, 250);
    ViewportFrame.LightDirection = Vector3.new(-0.4, -1, -0.6);
    ViewportFrame.ZIndex = 6;
    ViewportFrame.Parent = Frame2;

    if p12 and (p12.Parent and p12.Character) then
        buildPortraitIn(ViewportFrame, p12.Character);
    end;

    local v15 = u1[math.random(#u1)];
    local TextLabel = Instance.new("TextLabel");
    TextLabel.Position = UDim2.new(0, 62, 0, 4);
    TextLabel.Size = UDim2.new(1, -62, 0, 24);
    TextLabel.BackgroundTransparency = 1;
    TextLabel.Font = Enum.Font.Garamond;
    TextLabel.Text = p13 .. " " .. v15 .. "...";
    TextLabel.TextSize = 20;
    TextLabel.TextColor3 = Color3_fromRGB_ret3;
    TextLabel.TextXAlignment = Enum.TextXAlignment.Left;
    TextLabel.TextWrapped = true;
    TextLabel.ZIndex = 6;
    TextLabel.Parent = Frame;
    local TextLabel2 = Instance.new("TextLabel");
    TextLabel2.Position = UDim2.new(0, 0, 0, 62);
    TextLabel2.Size = UDim2.new(1, 0, 0, 0);
    TextLabel2.AutomaticSize = Enum.AutomaticSize.Y;
    TextLabel2.BackgroundTransparency = 1;
    TextLabel2.Font = Enum.Font.Garamond;
    TextLabel2.Text = "\"" .. p14 .. "\"";
    TextLabel2.TextSize = 17;
    TextLabel2.TextColor3 = Color3_fromRGB_ret4;
    TextLabel2.TextWrapped = true;
    TextLabel2.TextXAlignment = Enum.TextXAlignment.Left;
    TextLabel2.TextYAlignment = Enum.TextYAlignment.Top;
    TextLabel2.ZIndex = 6;
    TextLabel2.Parent = Frame;
    local TextButton = Instance.new("TextButton");
    TextButton.Position = UDim2.new(1, 0, 0, 0);
    TextButton.AnchorPoint = Vector2.new(1, 0);
    TextButton.Size = UDim2.new(0, 22, 0, 22);
    TextButton.BackgroundTransparency = 1;
    TextButton.Font = Enum.Font.GothamBold;
    TextButton.Text = "x";
    TextButton.TextSize = 16;
    TextButton.TextColor3 = Color3_fromRGB_ret4;
    TextButton.ZIndex = 7;
    TextButton.Parent = Frame;
    TextButton.MouseButton1Click:Connect(function() -- Line: 175
        -- upvalues: u4 (ref), removePrompt (ref), u11 (copy)
        if u4 then
            u4:Destroy();
            u4 = nil;
        end;

        removePrompt(u11);
    end);
    u4 = Frame;
end;

local function addPrompt(u16, u17, u18) -- Line: 183
    -- upvalues: u2 (ref), Color3_fromRGB_ret (copy), Color3_fromRGB_ret3 (copy), ThoughtList (copy), Color3_fromRGB_ret2 (copy), TweenService (copy), openDetail (copy), u3 (copy)
    u2 = u2 + 1;
    local TextButton = Instance.new("TextButton");
    TextButton.Name = "Thought_" .. u2;
    TextButton.Size = UDim2.new(0, 230, 0, 30);
    TextButton.BackgroundColor3 = Color3_fromRGB_ret;
    TextButton.BackgroundTransparency = 0.15;
    TextButton.BorderSizePixel = 0;
    TextButton.AutoButtonColor = true;
    TextButton.Font = Enum.Font.Garamond;
    TextButton.Text = "  " .. u17 .. " has a thought...";
    TextButton.TextSize = 16;
    TextButton.TextColor3 = Color3_fromRGB_ret3;
    TextButton.TextXAlignment = Enum.TextXAlignment.Left;
    TextButton.LayoutOrder = u2;
    TextButton.Parent = ThoughtList;
    local UICorner = Instance.new("UICorner");
    UICorner.CornerRadius = UDim.new(0, 6);
    UICorner.Parent = TextButton;
    local UIStroke = Instance.new("UIStroke");
    UIStroke.Color = Color3_fromRGB_ret2;
    UIStroke.Thickness = 1;
    UIStroke.Transparency = 0.35;
    UIStroke.Parent = TextButton;
    TextButton.BackgroundTransparency = 1;
    TextButton.TextTransparency = 1;
    UIStroke.Transparency = 1;
    TweenService:Create(TextButton, TweenInfo.new(0.35), {
        BackgroundTransparency = 0.15,
        TextTransparency = 0
    }):Play();
    TweenService:Create(UIStroke, TweenInfo.new(0.35), {
        Transparency = 0.35
    }):Play();
    TextButton.MouseButton1Click:Connect(function() -- Line: 210
        -- upvalues: openDetail (ref), TextButton (copy), u16 (copy), u17 (copy), u18 (copy)
        openDetail(TextButton, u16, u17, u18);
    end);
    table.insert(u3, TextButton);
    local v19 = #u3 > 6 and table.remove(u3, 1);

    if v19 then
        v19:Destroy();
    end;
end;

local u20 = {};
local u21 = false;
local u22 = {
    TextSize = 24,
    HoldBase = 2.6,
    HoldMin = 3.5,
    HoldMax = 7,
    Color = Color3.fromRGB(226, 208, 168)
};

local function playCinematicThought(p23, p24) -- Line: 245
    -- upvalues: u21 (ref), script_Parent (copy), TweenService (copy), u20 (copy), playCinematicThought (copy)
    u21 = true;
    local TextLabel = Instance.new("TextLabel");
    TextLabel.Name = "CinematicThought";
    TextLabel.AnchorPoint = Vector2.new(0.5, 0);
    TextLabel.Position = UDim2.fromScale(0.5, 0.32);
    TextLabel.Size = UDim2.new(0.72, 0, 0, 76);
    TextLabel.BackgroundTransparency = 1;
    TextLabel.Font = Enum.Font.Garamond;
    TextLabel.Text = p23;
    TextLabel.TextSize = p24 and (p24.TextSize or 28) or 28;
    TextLabel.TextColor3 = p24 and p24.Color or Color3.fromRGB(245, 243, 238);
    TextLabel.TextTransparency = 1;
    TextLabel.TextStrokeColor3 = Color3.fromRGB(0, 0, 0);
    TextLabel.TextStrokeTransparency = 1;
    TextLabel.TextWrapped = true;
    TextLabel.TextYAlignment = Enum.TextYAlignment.Top;
    TextLabel.ZIndex = 20;
    TextLabel.Parent = script_Parent;
    local v25;

    if p24 then
        v25 = math.clamp(p24.HoldBase + #p23 * 0.05, p24.HoldMin, p24.HoldMax);
    else
        v25 = math.clamp(#p23 * 0.06 + 4, 5, 12);
    end;

    TweenService:Create(TextLabel, TweenInfo.new(0.8, Enum.EasingStyle.Quad), {
        TextTransparency = 0,
        TextStrokeTransparency = 0.6
    }):Play();
    task.delay(0.8 + v25, function() -- Line: 288
        -- upvalues: TweenService (ref), TextLabel (copy), u21 (ref), u20 (ref), playCinematicThought (ref)
        TweenService:Create(TextLabel, TweenInfo.new(1.2, Enum.EasingStyle.Quad), {
            TextTransparency = 1,
            TextStrokeTransparency = 1
        }):Play();
        task.delay(1.3, function() -- Line: 291
            -- upvalues: TextLabel (ref), u21 (ref), u20 (ref), playCinematicThought (ref)
            TextLabel:Destroy();
            u21 = false;
            local table_remove_ret = table.remove(u20, 1);

            if table_remove_ret then
                playCinematicThought(table_remove_ret.Message, table_remove_ret.Style);
            end;
        end);
    end);
end;

local function queueCinematicThought(p26, p27) -- Line: 300
    -- upvalues: u20 (copy), u21 (ref), playCinematicThought (copy)
    if p27 then
        for _, v in ipairs(u20) do
            if v.Message == p26 then
                return;
            end;
        end;
    end;

    if u21 then
        table.insert(u20, {
            Message = p26,
            Style = p27
        });

        return;
    end;

    playCinematicThought(p26, p27);
end;

local TextService = game:GetService("TextService");
local Color3_fromRGB_ret5 = Color3.fromRGB(0, 170, 255);
local u28 = {};
local u29 = false;

local function makeBracket(p30, p31) -- Line: 339
    -- upvalues: Color3_fromRGB_ret5 (copy)
    local Frame = Instance.new("Frame");
    Frame.Size = UDim2.new(0, 14, 0, 30);
    Frame.BackgroundTransparency = 1;

    local function piece(p32, p33, p34) -- Line: 343
        -- upvalues: Color3_fromRGB_ret5 (ref), Frame (copy)
        local Frame2 = Instance.new("Frame");
        Frame2.Size = p32;
        Frame2.Position = p33;
        Frame2.AnchorPoint = p34;
        Frame2.BackgroundColor3 = Color3_fromRGB_ret5;
        Frame2.BorderSizePixel = 0;
        local UICorner = Instance.new("UICorner");
        UICorner.CornerRadius = UDim.new(0, 2);
        UICorner.Parent = Frame2;
        Frame2.Parent = Frame;

        return Frame2;
    end;

    if p31 then
        local UDim2_new_ret = UDim2.new(0, 3, 1, 0);
        local UDim2_new_ret2 = UDim2.new(1, 0, 0, 0);
        local Vector2_new_ret = Vector2.new(1, 0);
        local Frame2 = Instance.new("Frame");
        Frame2.Size = UDim2_new_ret;
        Frame2.Position = UDim2_new_ret2;
        Frame2.AnchorPoint = Vector2_new_ret;
        Frame2.BackgroundColor3 = Color3_fromRGB_ret5;
        Frame2.BorderSizePixel = 0;
        local UICorner = Instance.new("UICorner");
        UICorner.CornerRadius = UDim.new(0, 2);
        UICorner.Parent = Frame2;
        Frame2.Parent = Frame;
        local UDim2_new_ret3 = UDim2.new(0, 10, 0, 3);
        local UDim2_new_ret4 = UDim2.new(1, 0, 0, 0);
        local Vector2_new_ret2 = Vector2.new(1, 0);
        local Frame3 = Instance.new("Frame");
        Frame3.Size = UDim2_new_ret3;
        Frame3.Position = UDim2_new_ret4;
        Frame3.AnchorPoint = Vector2_new_ret2;
        Frame3.BackgroundColor3 = Color3_fromRGB_ret5;
        Frame3.BorderSizePixel = 0;
        local UICorner2 = Instance.new("UICorner");
        UICorner2.CornerRadius = UDim.new(0, 2);
        UICorner2.Parent = Frame3;
        Frame3.Parent = Frame;
        local UDim2_new_ret5 = UDim2.new(0, 10, 0, 3);
        local UDim2_new_ret6 = UDim2.new(1, 0, 1, 0);
        local Vector2_new_ret3 = Vector2.new(1, 1);
        local Frame4 = Instance.new("Frame");
        Frame4.Size = UDim2_new_ret5;
        Frame4.Position = UDim2_new_ret6;
        Frame4.AnchorPoint = Vector2_new_ret3;
        Frame4.BackgroundColor3 = Color3_fromRGB_ret5;
        Frame4.BorderSizePixel = 0;
        local UICorner3 = Instance.new("UICorner");
        UICorner3.CornerRadius = UDim.new(0, 2);
        UICorner3.Parent = Frame4;
        Frame4.Parent = Frame;
    else
        local UDim2_new_ret = UDim2.new(0, 3, 1, 0);
        local UDim2_new_ret2 = UDim2.new(0, 0, 0, 0);
        local Vector2_new_ret = Vector2.new(0, 0);
        local Frame2 = Instance.new("Frame");
        Frame2.Size = UDim2_new_ret;
        Frame2.Position = UDim2_new_ret2;
        Frame2.AnchorPoint = Vector2_new_ret;
        Frame2.BackgroundColor3 = Color3_fromRGB_ret5;
        Frame2.BorderSizePixel = 0;
        local UICorner = Instance.new("UICorner");
        UICorner.CornerRadius = UDim.new(0, 2);
        UICorner.Parent = Frame2;
        Frame2.Parent = Frame;
        local UDim2_new_ret3 = UDim2.new(0, 10, 0, 3);
        local UDim2_new_ret4 = UDim2.new(0, 0, 0, 0);
        local Vector2_new_ret2 = Vector2.new(0, 0);
        local Frame3 = Instance.new("Frame");
        Frame3.Size = UDim2_new_ret3;
        Frame3.Position = UDim2_new_ret4;
        Frame3.AnchorPoint = Vector2_new_ret2;
        Frame3.BackgroundColor3 = Color3_fromRGB_ret5;
        Frame3.BorderSizePixel = 0;
        local UICorner2 = Instance.new("UICorner");
        UICorner2.CornerRadius = UDim.new(0, 2);
        UICorner2.Parent = Frame3;
        Frame3.Parent = Frame;
        local UDim2_new_ret5 = UDim2.new(0, 10, 0, 3);
        local UDim2_new_ret6 = UDim2.new(0, 0, 1, 0);
        local Vector2_new_ret3 = Vector2.new(0, 1);
        local Frame4 = Instance.new("Frame");
        Frame4.Size = UDim2_new_ret5;
        Frame4.Position = UDim2_new_ret6;
        Frame4.AnchorPoint = Vector2_new_ret3;
        Frame4.BackgroundColor3 = Color3_fromRGB_ret5;
        Frame4.BorderSizePixel = 0;
        local UICorner3 = Instance.new("UICorner");
        UICorner3.CornerRadius = UDim.new(0, 2);
        UICorner3.Parent = Frame4;
        Frame4.Parent = Frame;
    end;

    Frame.Parent = p30;

    return Frame;
end;

local function playInnerThought(p35) -- Line: 368
    -- upvalues: u29 (ref), Players (copy), u28 (copy), playInnerThought (copy), TextService (copy), script_Parent (copy), makeBracket (copy), Color3_fromRGB_ret5 (copy), TweenService (copy)
    u29 = true;
    local Character = Players.LocalPlayer.Character;

    if Character then
        Character = Character:FindFirstChild("Head") or Character:FindFirstChild("HumanoidRootPart");
    end;

    if not Character then
        u29 = false;
        local table_remove_ret = table.remove(u28, 1);

        if table_remove_ret then
            playInnerThought(table_remove_ret);
        end;

        return;
    end;

    local v36 = "INNER THOUGHTS: " .. p35;
    local X = TextService:GetTextSize(v36, 18, Enum.Font.GothamMedium, Vector2.new(1000, 44)).X;
    local BillboardGui = Instance.new("BillboardGui");
    BillboardGui.Name = "InnerThought";
    BillboardGui.Adornee = Character;
    BillboardGui.Size = UDim2.new(0, X + 28 + 20 + 8, 0, 44);
    BillboardGui.StudsOffset = Vector3.new(0, 2.4, 0);
    BillboardGui.AlwaysOnTop = true;
    BillboardGui.ResetOnSpawn = false;
    BillboardGui.Parent = script_Parent;
    local Frame = Instance.new("Frame");
    Frame.Size = UDim2.fromScale(1, 1);
    Frame.BackgroundTransparency = 1;
    Frame.Parent = BillboardGui;
    local UIListLayout = Instance.new("UIListLayout");
    UIListLayout.FillDirection = Enum.FillDirection.Horizontal;
    UIListLayout.HorizontalAlignment = Enum.HorizontalAlignment.Center;
    UIListLayout.VerticalAlignment = Enum.VerticalAlignment.Center;
    UIListLayout.Padding = UDim.new(0, 10);
    UIListLayout.Parent = Frame;
    makeBracket(Frame, false).LayoutOrder = 1;
    local TextLabel = Instance.new("TextLabel");
    TextLabel.LayoutOrder = 2;
    TextLabel.Size = UDim2.new(0, X + 4, 1, 0);
    TextLabel.BackgroundTransparency = 1;
    TextLabel.Font = Enum.Font.GothamMedium;
    TextLabel.Text = v36;
    TextLabel.TextSize = 18;
    TextLabel.TextColor3 = Color3_fromRGB_ret5;
    TextLabel.TextTransparency = 1;
    TextLabel.Parent = Frame;
    makeBracket(Frame, true).LayoutOrder = 3;
    local u37 = {};

    for _, descendant in ipairs(Frame:GetDescendants()) do
        if descendant:IsA("Frame") and descendant.BackgroundTransparency < 1 then
            descendant.BackgroundTransparency = 1;
            table.insert(u37, descendant);
        end;
    end;

    local TweenInfo_new_ret = TweenInfo.new(0.4, Enum.EasingStyle.Quad, Enum.EasingDirection.Out);
    local TweenInfo_new_ret2 = TweenInfo.new(0.6, Enum.EasingStyle.Quad, Enum.EasingDirection.In);
    TweenService:Create(TextLabel, TweenInfo_new_ret, {
        TextTransparency = 0
    }):Play();

    for _, v in ipairs(u37) do
        TweenService:Create(v, TweenInfo_new_ret, {
            BackgroundTransparency = 0
        }):Play();
    end;

    task.delay(2.9, function() -- Line: 441
        -- upvalues: TweenService (ref), TextLabel (copy), TweenInfo_new_ret2 (copy), u37 (copy), BillboardGui (copy), u29 (ref), u28 (ref), playInnerThought (ref)
        TweenService:Create(TextLabel, TweenInfo_new_ret2, {
            TextTransparency = 1
        }):Play();

        for _, v in ipairs(u37) do
            TweenService:Create(v, TweenInfo_new_ret2, {
                BackgroundTransparency = 1
            }):Play();
        end;

        task.delay(0.65, function() -- Line: 446
            -- upvalues: BillboardGui (ref), u29 (ref), u28 (ref), playInnerThought (ref)
            BillboardGui:Destroy();
            u29 = false;
            local table_remove_ret = table.remove(u28, 1);

            if table_remove_ret then
                playInnerThought(table_remove_ret);
            end;
        end);
    end);
end;

local function queueInnerThought(p38) -- Line: 455
    -- upvalues: u29 (ref), u28 (copy), playInnerThought (copy)
    if u29 then
        table.insert(u28, p38);

        return;
    end;

    playInnerThought(p38);
end;

local u39 = nil;
local u40 = 0;
local u41 = 0;

local function ensureLootStack() -- Line: 483
    -- upvalues: u39 (ref), script_Parent (copy)
    if u39 and u39.Parent then
        return u39;
    end;

    u39 = Instance.new("Frame");
    u39.Name = "LootStack";
    u39.AnchorPoint = Vector2.new(0.5, 0);
    u39.Size = UDim2.new(0.72, 0, 0, 272);
    u39.BackgroundTransparency = 1;
    u39.ZIndex = 20;
    local UIListLayout = Instance.new("UIListLayout");
    UIListLayout.SortOrder = Enum.SortOrder.LayoutOrder;
    UIListLayout.HorizontalAlignment = Enum.HorizontalAlignment.Center;
    UIListLayout.Padding = UDim.new(0, 2);
    UIListLayout.Parent = u39;
    u39.Parent = script_Parent;

    return u39;
end;

local function playLootLine(p42, p43) -- Line: 500
    -- upvalues: ensureLootStack (copy), u21 (ref), u40 (ref), RarityData (copy), TweenService (copy)
    local v44 = ensureLootStack();
    v44.Position = u21 and UDim2.new(0.5, 0, 0.32, 84) or UDim2.fromScale(0.5, 0.32);
    local v45 = {};

    for _, child in ipairs(v44:GetChildren()) do
        if child:IsA("TextLabel") then
            table.insert(v45, child);
        end;
    end;

    if #v45 >= 8 then
        table.sort(v45, function(p46, p47) -- Line: 513
            return p46.LayoutOrder < p47.LayoutOrder;
        end);
        v45[1]:Destroy();
    end;

    u40 = u40 + 1;
    local TextLabel = Instance.new("TextLabel");
    TextLabel.Name = "LootLine";
    TextLabel.LayoutOrder = u40;
    TextLabel.Size = UDim2.new(1, 0, 0, 34);
    TextLabel.BackgroundTransparency = 1;
    TextLabel.Font = Enum.Font.Garamond;
    TextLabel.Text = p42;
    TextLabel.TextSize = 26;
    TextLabel.TextColor3 = p43 and RarityData.Colors[p43] or Color3.fromRGB(245, 243, 238);
    TextLabel.TextTransparency = 1;
    TextLabel.TextStrokeColor3 = Color3.fromRGB(0, 0, 0);
    TextLabel.TextStrokeTransparency = 1;
    TextLabel.ZIndex = 21;
    TextLabel.Parent = v44;
    TweenService:Create(TextLabel, TweenInfo.new(0.35, Enum.EasingStyle.Quad), {
        TextTransparency = 0,
        TextStrokeTransparency = 0.6
    }):Play();
    task.delay(2.75, function() -- Line: 538
        -- upvalues: TextLabel (copy), TweenService (ref)
        if not TextLabel.Parent then
            return;
        end;

        TweenService:Create(TextLabel, TweenInfo.new(0.9, Enum.EasingStyle.Quad), {
            TextTransparency = 1,
            TextStrokeTransparency = 1
        }):Play();
        task.delay(0.9500000000000001, function() -- Line: 542
            -- upvalues: TextLabel (ref)
            if TextLabel.Parent then
                TextLabel:Destroy();
            end;
        end);
    end);
end;

local function queueLootLine(u48, u49) -- Line: 549
    -- upvalues: u41 (ref), playLootLine (copy)
    local v50 = u41 * 0.12;
    u41 = u41 + 1;
    task.delay(v50, function() -- Line: 552
        -- upvalues: u41 (ref), playLootLine (ref), u48 (copy), u49 (copy)
        u41 = math.max(u41 - 1, 0);
        playLootLine(u48, u49);
    end);
end;

LoreThoughtRemote.OnClientEvent:Connect(function(p51) -- Line: 562
    -- upvalues: addPrompt (copy), u21 (ref), u20 (copy), playCinematicThought (copy), queueCinematicThought (copy), u22 (copy), u29 (ref), u28 (copy), playInnerThought (copy), u41 (ref), playLootLine (copy)
    if type(p51) ~= "table" then
        return;
    end;

    if p51.Action == "Thought" and (p51.FromName and p51.Message) then
        addPrompt(p51.FromPlayer, p51.FromName, p51.Message);

        return;
    end;

    if p51.Action == "Cinematic" and p51.Message then
        local Message = p51.Message;

        if u21 then
            table.insert(u20, {
                Style = nil,
                Message = Message
            });

            return;
        end;

        playCinematicThought(Message, nil);

        return;
    end;

    if p51.Action == "Hint" and p51.Message then
        queueCinematicThought(p51.Message, u22);

        return;
    end;

    if p51.Action ~= "InnerThought" or not p51.Message then
        if p51.Action == "Loot" then
            if type(p51.Lines) == "table" then
                for _, v in ipairs(p51.Lines) do
                    if type(v) == "string" then
                        local v52 = u41 * 0.12;
                        u41 = u41 + 1;
                        local u53 = nil;
                        task.delay(v52, function() -- Line: 552
                            -- upvalues: u41 (ref), playLootLine (ref), v (copy), u53 (copy)
                            u41 = math.max(u41 - 1, 0);
                            playLootLine(v, u53);
                        end);
                    elseif type(v) == "table" and type(v.Text) == "string" then
                        local Text = v.Text;
                        local Rarity = v.Rarity;
                        local v54 = u41 * 0.12;
                        u41 = u41 + 1;
                        task.delay(v54, function() -- Line: 552
                            -- upvalues: u41 (ref), playLootLine (ref), Text (copy), Rarity (copy)
                            u41 = math.max(u41 - 1, 0);
                            playLootLine(Text, Rarity);
                        end);
                    end;
                end;

                return;
            end;

            if type(p51.Message) == "string" then
                local Message = p51.Message;
                local Rarity = p51.Rarity;
                local v55 = u41 * 0.12;
                u41 = u41 + 1;
                task.delay(v55, function() -- Line: 552
                    -- upvalues: u41 (ref), playLootLine (ref), Message (copy), Rarity (copy)
                    u41 = math.max(u41 - 1, 0);
                    playLootLine(Message, Rarity);
                end);
            end;
        end;

        return;
    end;

    local Message = p51.Message;

    if u29 then
        table.insert(u28, Message);

        return;
    end;

    playInnerThought(Message);
end);