-- Decompiled with Potassium's decompiler.

local Metadata = game:GetService("ReplicatedStorage"):WaitForChild("Modules").Metadata;
local SkinColorData = require(Metadata.RaceData.SkinColorData);
local u1 = {
    Arcosian = SkinColorData.Arcosian_Skin_Colors,
    Namekian = SkinColorData.Namekian_Skin_Colors,
    Humanish = SkinColorData.Humanish_Colors,
    Majin = SkinColorData.Majin_Skin_Colors,
    ["Bio-Android"] = SkinColorData.Bio_Android,
    Angel = SkinColorData.Angel_Skin_Colors,
    Alien = SkinColorData.Alien_Skin_Colors,
    Demon = SkinColorData.Demon_Skin_Colors
};

function u1.Set(p2) -- Line: 21
    -- upvalues: u1 (copy)
    if p2 == "Saiyan" or (p2 == "Human" or p2 == "Android") then
        local math_random_ret = math.random(1, #u1.Humanish);
        local v3 = u1.Humanish[math_random_ret];

        return {
            Red = v3[1],
            Green = v3[2],
            Blue = v3[3]
        };
    end;

    local v4 = u1[p2];
    local v5 = v4[math.random(1, #v4)];

    return {
        Red = v5[1],
        Green = v5[2],
        Blue = v5[3]
    };
end;

function u1.Give(p6, p7) -- Line: 53
    local v8 = p6 and p6.CharacterData and p6.CharacterData.SkinColor;

    if not (p7 and v8) then
        return;
    end;

    local Color3_fromRGB_ret = Color3.fromRGB(v8.Red, v8.Green, v8.Blue);
    local v9 = nil;

    for _, child in ipairs(p7:GetChildren()) do
        if child:IsA("BodyColors") then
            if v9 then
                child:Destroy();
            else
                v9 = child;
            end;
        end;
    end;

    if not v9 then
        v9 = Instance.new("BodyColors");
        v9.Parent = p7;
    end;

    v9.HeadColor3 = Color3_fromRGB_ret;
    v9.LeftArmColor3 = Color3_fromRGB_ret;
    v9.RightArmColor3 = Color3_fromRGB_ret;
    v9.LeftLegColor3 = Color3_fromRGB_ret;
    v9.RightLegColor3 = Color3_fromRGB_ret;
    v9.TorsoColor3 = Color3_fromRGB_ret;
    local HumanoidRootPart = p7:FindFirstChild("HumanoidRootPart");

    if HumanoidRootPart then
        HumanoidRootPart.Color = Color3_fromRGB_ret;
    end;
end;

return u1;