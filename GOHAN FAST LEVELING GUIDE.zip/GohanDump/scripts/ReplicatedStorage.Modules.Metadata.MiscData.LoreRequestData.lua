-- Decompiled with Potassium's decompiler.

local u1 = {
    Requests = { {
            Id = "Tournament",
            Name = "Start a Tournament",
            Cost = 5,
            Enabled = true
        }, {
            Id = "FactionFight",
            Name = "Fight a Faction",
            Cost = 20,
            Enabled = true
        }, {
            Id = "FactionCreate",
            Name = "Create a Faction",
            Cost = 30,
            Enabled = true,
            ButtonText = "CREATE"
        }, {
            Id = "PlanetTakeover",
            Name = "Take Over a Planet",
            Cost = 15,
            Enabled = true
        }, {
            Id = "PlanetDestroy",
            Name = "Destroy a Planet",
            Cost = 25,
            Enabled = true
        } }
};

function u1.Get(p2) -- Line: 26
    -- upvalues: u1 (copy)
    for _, v in ipairs(u1.Requests) do
        if v.Id == p2 then
            return v;
        end;
    end;

    return nil;
end;

return u1;