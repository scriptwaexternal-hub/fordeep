-- Decompiled with Potassium's decompiler.

local u1 = {
    NoSpaceship = { "Otherworld", "HFIL", "Future", "Time Chamber" },
    NoPvP = {},
    NoKi = { "Time Chamber" },
    NoTransform = { "Time Chamber" }
};

function u1.IsRestricted(p2, p3) -- Line: 31
    -- upvalues: u1 (copy)
    local v4 = u1[p2];

    if v4 then
        return table.find(v4, p3) ~= nil;
    end;

    warn("LocationRules.IsRestricted: unknown restriction type \'" .. tostring(p2) .. "\'");

    return false;
end;

return u1;