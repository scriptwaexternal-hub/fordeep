-- Decompiled with Potassium's decompiler.

local UI = require(script.Parent:WaitForChild("UI"));
local v1 = {};
v1.__index = v1;

function v1.new(u2) -- Line: 6
    -- upvalues: UI (copy)
    local servers = u2.Data.servers;
    local u3 = {};

    local function getPlaceName(u4: number) -- Line: 10
        -- upvalues: u3 (copy), u2 (copy)
        if u3[u4] then
            return u3[u4];
        end;

        local success, result = pcall(function() -- Line: 15
            -- upvalues: u2 (ref), u4 (copy)
            return u2.Service.Marketplace:GetProductInfo(u4);
        end);
        local v5 = not success and "Unknown" or result.Name;
        u3[u4] = v5;

        return v5;
    end;

    u2.Remote.Servers:Connect(function(p6: string?, p7: any) -- Line: 25
        -- upvalues: servers (copy), u2 (copy)
        if p6 then
            servers[p6] = p7;
        else
            if type(p7) ~= "table" then
                return;
            end;

            table.clear(servers);

            for i, v in p7 do
                servers[i] = v;
            end;
        end;

        u2.client.servers(servers);
    end);
    local merge = u2.Util.Table.merge;
    local u8 = UI.compute(function() -- Line: 42
        -- upvalues: UI (ref)
        return UDim2.new(0.2, 0, 1, -UI.Theme.Padding().Offset);
    end);

    local function icon(p9) -- Line: 46
        -- upvalues: UI (ref), merge (copy)
        return UI.new("ImageLabel")(merge({
            BackgroundTransparency = 1,
            Size = UDim2.new(0.5, 0, 0.5, 0),
            SizeConstraint = Enum.SizeConstraint.RelativeYY,
            ImageColor3 = UI.Theme.PrimaryText,
            ScaleType = Enum.ScaleType.Fit
        }, p9));
    end;

    local function label(p10) -- Line: 56
        -- upvalues: UI (ref), merge (copy)
        return UI.new("TextLabel")(merge({
            AutoLocalize = false,
            BackgroundTransparency = 1,
            RichText = true,
            AutomaticSize = Enum.AutomaticSize.X,
            Size = UDim2.new(0, 0, 1, 0),
            FontFace = UI.Theme.FontMono,
            TextColor3 = UI.Theme.PrimaryText,
            TextSize = UI.Theme.FontSize,
            TextStrokeColor3 = UI.Theme.Primary,
            TextStrokeTransparency = UI.Theme.TextStrokeTransparency,
            TextTruncate = Enum.TextTruncate.SplitWord,
            TextXAlignment = Enum.TextXAlignment.Left,
            TextYAlignment = Enum.TextYAlignment.Center
        }, p10));
    end;

    local function createItem(p11, p12) -- Line: 74
        -- upvalues: UI (ref), icon (copy), label (copy), u8 (copy), u2 (copy)
        local u13 = {};
        u13._instance = UI.new("Frame")({
            BackgroundTransparency = 1,
            Size = p11.ItemSize,
            UI.new("UIListLayout")({
                Padding = UI.Theme.Padding,
                FillDirection = Enum.FillDirection.Horizontal,
                SortOrder = Enum.SortOrder.LayoutOrder,
                VerticalAlignment = Enum.VerticalAlignment.Center
            }),
            icon({
                Image = UI.Theme.Image.Host
            }),
            label({
                Name = "Id"
            }),
            icon({
                Image = UI.Theme.Image.Graph1
            }),
            label({
                Name = "Place",
                FontFace = UI.Theme.Font,
                UI.new("UIFlexItem")({
                    FlexMode = Enum.UIFlexMode.Shrink
                })
            }),
            UI.new("Spacer")({}),
            icon({
                Image = UI.Theme.Image.Hourglass_Bottom
            }),
            label({
                Name = "Age"
            }),
            icon({
                Image = UI.Theme.Image.Play
            }),
            label({
                Name = "Count"
            }),
            UI.new("Button")({
                Label = "Join",
                Size = u8,
                UI.new("UIFlexItem")({
                    FlexMode = Enum.UIFlexMode.Shrink
                }),

                Activated = function() -- Line: 116, Name: Activated
                    -- upvalues: u13 (copy), u2 (ref)
                    if u13.placeId and u13.jobId then
                        u2.Remote.TeleportToServer:Fire(u13.placeId, u13.jobId);
                    end;
                end
            })
        });

        return u13;
    end;

    local u14 = `%-{#tostring(u2.Service.Players.MaxPlayers)}d`;
    local v15 = UI.compute(function() -- Line: 159
        -- upvalues: UI (ref)
        return UDim2.new(1, 0, 0, UI.Theme.FontSize * 2 + UI.Theme.Padding().Offset);
    end);
    local u16 = label({
        Name = "EmptyListLabel",
        Text = "No other servers found",
        Visible = false,
        FontFace = UI.Theme.Font,
        Size = v15,
        TextXAlignment = Enum.TextXAlignment.Center
    });
    u16.Visible = u2.Util.Table.countKeys(u2.client.servers._value) == 0;
    u2.client.servers:Connect(function() -- Line: 172
        -- upvalues: u16 (copy), u2 (copy)
        u16.Visible = u2.Util.Table.countKeys(u2.client.servers._value) == 0;
    end);
    local v27 = UI.new("ScrollerFast")({
        Name = "Servers",
        List = u2.client.servers,
        DictList = true,
        Enabled = false,
        Visible = false,
        ItemSize = v15,
        CreateItem = createItem,

        RenderItem = function(p17, u18, p19) -- Line: 129, Name: renderItem
            -- upvalues: servers (copy), u14 (copy), u3 (copy), u2 (copy)
            local u20 = tick();
            u18.lastRender = u20;
            u18.jobId = p19;
            local v21 = servers[p19];

            if v21 then
                local u22, v23, u24 = unpack(v21);
                u18.placeId = u22;
                u18._instance.Id.Text = string.sub(p19, -6, -1);
                u18._instance.Count.Text = string.format(u14, v23);
                task.spawn(function() -- Line: 143
                    -- upvalues: u22 (copy), u3 (ref), u2 (ref), u18 (copy), u20 (copy)
                    local u25 = u22;
                    local v26;

                    if u3[u25] then
                        v26 = u3[u25];
                    else
                        local success, result = pcall(function() -- Line: 15
                            -- upvalues: u2 (ref), u25 (copy)
                            return u2.Service.Marketplace:GetProductInfo(u25);
                        end);
                        v26 = not success and "Unknown" or result.Name;
                        u3[u25] = v26;
                    end;

                    if u18.lastRender == u20 then
                        u18._instance.Place.Text = v26;
                    end;
                end);
                task.spawn(function() -- Line: 150
                    -- upvalues: u18 (copy), u20 (copy), u2 (ref), u24 (copy)
                    while u18.lastRender == u20 do
                        u18._instance.Age.Text = u2.Util.Time.clock(DateTime.now().UnixTimestamp - u24);
                        task.wait(1);
                    end;
                end);
            end;
        end,

        u16
    });
    task.defer(v27.filter, v27, function(p28, p29) -- Line: 189
        return p29;
    end);
    task.defer(v27.sort, v27, function(p30, p31) -- Line: 193
        -- upvalues: servers (copy)
        local v32 = servers[p30];
        local v33 = servers[p31];

        if not (v32 and v33) then
            return p30 < p31;
        end;

        if v32[1] == v33[1] then
            return v32[2] > v33[2];
        end;

        return v32[1] < v33[1];
    end);

    return v27;
end;

return v1;