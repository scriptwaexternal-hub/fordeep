-- Decompiled with Potassium's decompiler.

game:GetService("Players");
game:GetService("TweenService");
local ReplicatedStorage = game:GetService("ReplicatedStorage");
game:GetService("RunService");
game:GetService("ContentProvider");
game:GetService("Debris");
local Modules = ReplicatedStorage:WaitForChild("Modules");
ReplicatedStorage:WaitForChild("Remotes");
local _ = ReplicatedStorage.Assets;
local Metadata = Modules.Metadata;
local _ = Modules.Shared;
local _ = Modules.Utility;
local GlobalFunctions = require(Modules.GlobalFunctions);
local ZoneData = require(Metadata.ZoneData.ZoneData);
local u1 = 0;
local u2 = {};
local u3 = {
    Dialogue = true,
    Cinematics = true,
    MessageGui = true,
    ClashGui = true,
    PopupGui = true,
    UI = true,
    SpeakerGui = true,
    LoreThoughtsGui = true,
    MobileControls = true
};
local u4 = {
    Cinematics = true,
    SpeakerGui = true,
    LoreThoughtsGui = true,
    ClashGui = true,
    MobileControls = true
};
local u5 = {
    Dialogue = true,
    UI = true
};
local u6 = {
    CarryGui = true,
    DropChestGui = true
};
local u7 = setmetatable({}, {
    __mode = "k"
});
local v37 = {
    FadeIn = function(p8, p9, p10) -- Line: 122, Name: FadeIn
        -- upvalues: u4 (copy), u3 (copy), u7 (copy)
        local Cinematics = p8.PlayerGui.Cinematics;
        local TopFrame = Cinematics.Cinema:WaitForChild("TopFrame");
        local BottomFrame = Cinematics.Cinema:WaitForChild("BottomFrame");
        local v11 = p9 or 1;
        local v12 = p10 and (p10.Strict and u4) or u3;
        local v13 = u7[p8];
        local v14 = v13 == nil;

        if v14 then
            v13 = {};
            u7[p8] = v13;
        end;

        for _, child in ipairs(p8.PlayerGui:GetChildren()) do
            if child:IsA("ScreenGui") and not v12[child.Name] then
                if v14 then
                    v13[child.Name] = child.Enabled;
                end;

                child.Enabled = false;
            end;
        end;

        TopFrame:TweenPosition(UDim2.new(0.5, 0, -0.075, 0), Enum.EasingDirection.Out, Enum.EasingStyle.Linear, v11, true);
        BottomFrame:TweenPosition(UDim2.new(0.5, 0, 0.925, 0), Enum.EasingDirection.Out, Enum.EasingStyle.Linear, v11, true);
    end,

    FadeOut = function(p15, p16) -- Line: 155, Name: FadeOut
        -- upvalues: u7 (copy), u5 (copy), u6 (copy)
        local Cinematics = p15.PlayerGui.Cinematics;
        local TopFrame = Cinematics.Cinema:WaitForChild("TopFrame");
        local BottomFrame = Cinematics.Cinema:WaitForChild("BottomFrame");
        local v17 = u7[p15];
        local v18 = p16 or 1;

        for _, child in ipairs(p15.PlayerGui:GetChildren()) do
            if child:IsA("ScreenGui") then
                local Name = child.Name;

                if u5[Name] then
                    child.Enabled = false;
                else
                    local v19;

                    if v17 then
                        v19 = v17[Name];
                    else
                        v19 = v17;
                    end;

                    if v19 == nil then
                        if not u6[Name] then
                            if v17 == nil then
                                child.Enabled = true;
                            end;
                        end;
                    else
                        child.Enabled = v19;
                    end;
                end;
            end;
        end;

        u7[p15] = nil;
        TopFrame:TweenPosition(UDim2.new(0.5, 0, -0.125, 0), Enum.EasingDirection.Out, Enum.EasingStyle.Linear, v18, true);
        BottomFrame:TweenPosition(UDim2.new(0.5, 0, 1, 0), Enum.EasingDirection.Out, Enum.EasingStyle.Linear, v18, true);
    end,

    Flash = function(p20, p21, p22) -- Line: 196, Name: Flash
        -- upvalues: GlobalFunctions (copy)
        local WhiteFrame = p20.PlayerGui.Cinematics.Cinema.WhiteFrame;
        WhiteFrame.BackgroundTransparency = 0;
        task.delay(p22 or 0, function() -- Line: 203
            -- upvalues: WhiteFrame (copy), GlobalFunctions (ref)
            GlobalFunctions.Tween({
                Instance = WhiteFrame
            }, {
                BackgroundTransparency = 1
            });
        end);
    end,

    ColorFrame = function(p23, p24) -- Line: 215, Name: ColorFrame
        local Action = p24.Action;
        local v25 = p24.Color or Color3.fromRGB(0, 255, 21);
        local v26 = p24.TweenTime or 0.5;
        local ColorFrame = p23.PlayerGui.Cinematics.Cinema.ColorFrame;
        ColorFrame.BackgroundColor3 = v25;

        if Action == "On" then
            ColorFrame:TweenPosition(UDim2.new(0, 0, 0, 0), Enum.EasingDirection.Out, Enum.EasingStyle.Linear, v26, true);

            return;
        end;

        ColorFrame:TweenPosition(UDim2.new(0, 0, -1, 0), Enum.EasingDirection.Out, Enum.EasingStyle.Linear, v26, true);
    end,

    ChangeZone = function(p27, p28) -- Line: 232, Name: ChangeZone
        -- upvalues: ZoneData (copy), GlobalFunctions (copy)
        local Cinematics = p27.PlayerGui:WaitForChild("Cinematics");

        if not Cinematics:FindFirstChild("Cinema") then
            return;
        end;

        local ZoneLabel = Cinematics.Cinema.ZoneLabel;
        local ZoneDesc = Cinematics.Cinema.ZoneDesc;
        local ZoneName = p28.ZoneName;
        ZoneLabel.Text = ZoneName;
        ZoneDesc.Text = ZoneData[ZoneName] and (ZoneData[ZoneName]["Zone Desc"] or "") or "";
        ZoneLabel.TextTransparency = 1;
        ZoneDesc.TextTransparency = 1;
        local u29 = {
            Instance = ZoneLabel,
            Duration = 1
        };
        local v30 = {
            TextTransparency = 0
        };
        GlobalFunctions.Tween(u29, v30);
        local u31 = {
            Instance = ZoneDesc,
            Duration = 1
        };

        if ZoneData[ZoneName] then
            GlobalFunctions.Tween(u31, v30);
        end;

        task.delay(2, function() -- Line: 267
            -- upvalues: GlobalFunctions (ref), u29 (copy), u31 (copy)
            local v32 = {
                TextTransparency = 1
            };
            GlobalFunctions.Tween(u29, v32);
            GlobalFunctions.Tween(u31, v32);
        end);
    end,

    Transition = function(p33, p34) -- Line: 276, Name: Transition
        local TransitionFrames = p33.PlayerGui.Cinematics.TransitionFrames;
        local v35 = p34 and (p34.TweenDelay or 2.5) or 2.5;
        local u36 = p34 and p34.Tween_Time or 1;

        for _, child in pairs(TransitionFrames:GetChildren()) do
            child:TweenSize(UDim2.new(1, 0, 0.25, 0), Enum.EasingDirection.Out, Enum.EasingStyle.Sine, u36);

            if child.Name == "TFrame_2" then
                child:TweenPosition(UDim2.new(0, 0, 0.25, 0), Enum.EasingDirection.Out, Enum.EasingStyle.Sine, u36);
            elseif child.Name == "TFrame_4" then
                child:TweenPosition(UDim2.new(0, 0, 0.75, 0), Enum.EasingDirection.Out, Enum.EasingStyle.Sine, u36);
            end;
        end;

        task.delay(v35, function() -- Line: 292
            -- upvalues: TransitionFrames (copy), u36 (copy)
            for _, child in pairs(TransitionFrames:GetChildren()) do
                child:TweenSize(UDim2.new(0, 0, 0.25, 0), Enum.EasingDirection.Out, Enum.EasingStyle.Sine, u36, true);

                if child.Name == "TFrame_2" then
                    child:TweenPosition(UDim2.new(1, 0, 0.25, 0), Enum.EasingDirection.Out, Enum.EasingStyle.Sine, u36, true);
                elseif child.Name == "TFrame_4" then
                    child:TweenPosition(UDim2.new(1, 0, 0.75, 0), Enum.EasingDirection.Out, Enum.EasingStyle.Sine, u36, true);
                end;
            end;
        end);
    end
};
local u38 = {
    PanelBg = Color3.fromRGB(26, 19, 12),
    InsetBg = Color3.fromRGB(38, 29, 18),
    DomeBg = Color3.fromRGB(14, 10, 6),
    Stroke = Color3.fromRGB(158, 126, 66),
    NameText = Color3.fromRGB(224, 186, 106),
    BodyText = Color3.fromRGB(233, 221, 196)
};

local function themeRefs(p39) -- Line: 338
    return {
        Panels = {
            p39.MessageBox,
            p39.TopTab,
            p39.NamePlate,
            p39.Dome.Outer
        },
        Inset = p39.MessageBox.TextArea,
        DomeIn = p39.Dome.Inner,
        Strokes = {
            p39.MessageBox.UIStroke,
            p39.MessageBox.TextArea.UIStroke,
            p39.NamePlate.UIStroke,
            p39.Dome.Outer.UIStroke,
            p39.Dome.Inner.UIStroke
        },
        Name = p39.NamePlate.SpeakerName,
        Body = p39.MessageBox.TextArea.Message
    };
end;

local function applyBossTheme(p40) -- Line: 355
    -- upvalues: u38 (copy)
    for _, v in ipairs(p40.Panels) do
        v.BackgroundColor3 = u38.PanelBg;
    end;

    p40.Inset.BackgroundColor3 = u38.InsetBg;
    p40.DomeIn.BackgroundColor3 = u38.DomeBg;

    for _, v in ipairs(p40.Strokes) do
        v.Color = u38.Stroke;
    end;

    p40.Name.TextColor3 = u38.NameText;
    p40.Body.TextColor3 = u38.BodyText;
end;

local function applyDefaultTheme(p41, p42) -- Line: 364
    for i, v in ipairs(p41.Panels) do
        v.BackgroundColor3 = p42.Panels[i];
    end;

    p41.Inset.BackgroundColor3 = p42.Inset;
    p41.DomeIn.BackgroundColor3 = p42.DomeIn;

    for i, v in ipairs(p41.Strokes) do
        v.Color = p42.Strokes[i];
    end;

    p41.Name.TextColor3 = p42.Name;
    p41.Body.TextColor3 = p42.Body;
end;

local function retireAnnouncement(u43) -- Line: 376
    if not (u43 and (u43.Parent and not u43:GetAttribute("Retiring"))) then
        return;
    end;

    u43:SetAttribute("Retiring", true);
    local TweenService = game:GetService("TweenService");
    local TweenInfo_new_ret = TweenInfo.new(0.55, Enum.EasingStyle.Quad, Enum.EasingDirection.In);
    TweenService:Create(u43, TweenInfo_new_ret, {
        BackgroundTransparency = 1,
        Size = UDim2.new(0, 0, 0, 0)
    }):Play();

    for _, descendant in ipairs(u43:GetDescendants()) do
        if descendant:IsA("TextLabel") then
            TweenService:Create(descendant, TweenInfo_new_ret, {
                TextTransparency = 1,
                TextStrokeTransparency = 1,
                BackgroundTransparency = 1
            }):Play();
        elseif descendant:IsA("ImageLabel") or descendant:IsA("ImageButton") then
            TweenService:Create(descendant, TweenInfo_new_ret, {
                ImageTransparency = 1,
                BackgroundTransparency = 1
            }):Play();
        elseif descendant:IsA("ViewportFrame") then
            TweenService:Create(descendant, TweenInfo_new_ret, {
                ImageTransparency = 1,
                BackgroundTransparency = 1
            }):Play();
        elseif descendant:IsA("Frame") then
            TweenService:Create(descendant, TweenInfo_new_ret, {
                BackgroundTransparency = 1
            }):Play();
        elseif descendant:IsA("UIStroke") then
            TweenService:Create(descendant, TweenInfo_new_ret, {
                Transparency = 1
            }):Play();
        end;
    end;

    task.delay(0.6000000000000001, function() -- Line: 395
        -- upvalues: u43 (copy)
        if u43.Parent then
            u43:Destroy();
        end;
    end);
end;

local function dropFromActive(p44) -- Line: 400
    -- upvalues: u2 (copy)
    for i, v in ipairs(u2) do
        if v == p44 then
            table.remove(u2, i);

            return;
        end;
    end;
end;

function v37.Annouce(p45, p46, p47, p48) -- Line: 406
    -- upvalues: u1 (ref), u2 (copy), retireAnnouncement (copy), applyBossTheme (copy), themeRefs (copy), dropFromActive (copy)
    local SpeakerGui = p45.PlayerGui:WaitForChild("SpeakerGui");
    local MainFrame = SpeakerGui.MainFrame;
    local TweenService = game:GetService("TweenService");
    local AnnounceList = SpeakerGui:FindFirstChild("AnnounceList");

    if not AnnounceList then
        AnnounceList = Instance.new("Frame");
        AnnounceList.Name = "AnnounceList";
        AnnounceList.AnchorPoint = Vector2.new(0.5, 1);
        AnnounceList.Position = MainFrame.Position;
        AnnounceList.Size = UDim2.new(MainFrame.Size.X.Scale, MainFrame.Size.X.Offset, 0, 586);
        AnnounceList.BackgroundTransparency = 1;
        AnnounceList.Parent = SpeakerGui;
        local UIListLayout = Instance.new("UIListLayout");
        UIListLayout.FillDirection = Enum.FillDirection.Vertical;
        UIListLayout.HorizontalAlignment = Enum.HorizontalAlignment.Center;
        UIListLayout.VerticalAlignment = Enum.VerticalAlignment.Bottom;
        UIListLayout.SortOrder = Enum.SortOrder.LayoutOrder;
        UIListLayout.Padding = UDim.new(0, 8);
        UIListLayout.Parent = AnnounceList;
    end;

    local v49 = p47 or "";
    local v50 = (p46 == nil or p46 == "") and "Announcer" or p46;

    if p48 and (p48.IsBoss and p48.BossTitle) then
        v50 = p48.BossTitle;
    end;

    u1 = u1 + 1;
    local u51 = MainFrame:Clone();
    u51.Name = "Announcement_" .. u1;
    u51.Visible = true;
    u51.ClipsDescendants = true;
    u51.Size = UDim2.new(1, 0, 0, 0);
    u51.LayoutOrder = u1;
    local UIScale = Instance.new("UIScale");
    UIScale.Scale = 0.675;
    UIScale.Parent = u51;
    u51.Parent = AnnounceList;
    TweenService:Create(u51, TweenInfo.new(0.3, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
        Size = UDim2.new(1, 0, 0, 190)
    }):Play();
    table.insert(u2, u51);

    while #u2 > 3 do
        retireAnnouncement(table.remove(u2, 1));
    end;

    local Message = u51.MessageBox.TextArea.Message;
    local ViewportFrame = u51.Dome.Inner.ViewportFrame;
    u51.NamePlate.SpeakerName.Text = v50;

    if p48 and p48.IsBoss then
        applyBossTheme((themeRefs(u51)));
    end;

    for _, child in ipairs(ViewportFrame:GetChildren()) do
        if child:IsA("Model") or child:IsA("Camera") then
            child:Destroy();
        end;
    end;

    if p48 then
        p48 = p48.PlayerAnnouncing;
    end;

    if p48 then
        p48 = p48.Character;
    end;

    if p48 then
        p48.Archivable = true;
        local v52 = p48:Clone();

        if v52 then
            for _, descendant in ipairs(v52:GetDescendants()) do
                if descendant:IsA("BaseScript") or descendant:IsA("ModuleScript") then
                    descendant:Destroy();
                end;
            end;

            v52.Parent = ViewportFrame;
            local Head = v52:FindFirstChild("Head");

            if Head then
                local Camera = Instance.new("Camera");
                Camera.Parent = ViewportFrame;
                ViewportFrame.CurrentCamera = Camera;
                Camera.CFrame = CFrame.lookAt((Head.CFrame * CFrame.new(0, -0.1, -2.6)).Position, Head.Position - Vector3.new(0, 0.3, 0));
            end;
        end;
    end;

    if string.sub(v49, 1, 1) ~= "\"" then
        v49 = "\"" .. v49 .. "\"";
    end;

    Message.Text = "";

    for i = 1, string.len(v49) do
        if not u51.Parent or u51:GetAttribute("Retiring") then
            return;
        end;

        Message.Text = string.sub(v49, 1, i);
        task.wait(0.01);
        local _ = i;
    end;

    task.delay(5, function() -- Line: 527
        -- upvalues: dropFromActive (ref), u51 (copy), retireAnnouncement (ref)
        dropFromActive(u51);
        retireAnnouncement(u51);
    end);
end;

return v37;