-- Decompiled with Potassium's decompiler.

local ReplicatedStorage = game:GetService("ReplicatedStorage");
local TweenService = game:GetService("TweenService");
local MarketplaceService = game:GetService("MarketplaceService");
local Players = game:GetService("Players");
local Modules = ReplicatedStorage:WaitForChild("Modules");
local Remotes = ReplicatedStorage:WaitForChild("Remotes");
local Metadata = Modules.Metadata;
local Shared = Modules.Shared;
local GlobalFunctions = require(Modules.GlobalFunctions);
local AnimationManager = require(Shared.AnimationManager);
local ClothesHandler = require(Metadata.CharacterData.ClothesHandler);
local SoundManager = require(Shared.SoundManager);
local SlotRemote = Remotes.SlotRemote;
local MarketRemote = Remotes.MarketRemote;
local script_Parent = script.Parent;
local MainFrame = script_Parent:WaitForChild("MainFrame");
local CardHolder = MainFrame:WaitForChild("CardHolder");
local SlotTemplate = MainFrame:WaitForChild("SlotTemplate");
local LocalPlayer = Players.LocalPlayer;

local function lockedSlotStandIn() -- Line: 39
    return {
        CharacterData = {
            Name = "",
            SpawnPlanet = "Earth",
            Rank = "-",
            Race = {
                Race = "???"
            }
        }
    };
end;

local function Random_Animation() -- Line: 45
    local v1 = { "Final Flash", "Kamehameha", "DBZ CHARGE", "Npc Idle", "Healing Chamber", "Sleep", "Walk", "Hover", "GroundSpike", "Run", "Kienzan", "Eraser Cannon", "Dragon Throw", "Rush", "Death Beam", "Squat", "Situp", "Pushup Anim", "One Arm Pushup", "Strike Anim" };

    return v1[math.random(1, #v1)];
end;

local function PlayerOwnsGamepass(u2, u3) -- Line: 56
    -- upvalues: MarketplaceService (copy)
    local success, result = pcall(function() -- Line: 57
        -- upvalues: MarketplaceService (ref), u2 (copy), u3 (copy)
        return MarketplaceService:UserOwnsGamePassAsync(u2.UserId, u3);
    end);

    if success then
        return result;
    end;

    warn("Error checking gamepass ownership for", u2.Name);

    return false;
end;

local function clearExistingSlots() -- Line: 71
    -- upvalues: CardHolder (copy)
    for _, child in ipairs(CardHolder:GetChildren()) do
        if child:IsA("GuiButton") then
            child:Destroy();
        end;
    end;
end;

local function makeBadge(p4, p5, p6, p7, p8) -- Line: 87
    local TextLabel = Instance.new("TextLabel");
    TextLabel.Name = "LoreBadge_" .. p6:gsub("%s", "");
    TextLabel.BackgroundColor3 = Color3.fromRGB(12, 12, 14);
    TextLabel.BackgroundTransparency = 0.25;
    TextLabel.BorderSizePixel = 0;
    TextLabel.AnchorPoint = Vector2.new(1, 0);
    TextLabel.Position = UDim2.new(0.985, 0, p8, 0);
    TextLabel.Size = UDim2.new(0.4, 0, 0.062, 0);
    TextLabel.Font = p5 and p5.Font or Enum.Font.GothamBold;
    TextLabel.Text = p6;
    TextLabel.TextColor3 = p7;
    TextLabel.TextScaled = true;
    TextLabel.ZIndex = (p5 and p5.ZIndex or 1) + 1;
    local UICorner = Instance.new("UICorner");
    UICorner.CornerRadius = UDim.new(0, 4);
    UICorner.Parent = TextLabel;
    TextLabel.Parent = p4;

    return TextLabel;
end;

local function showLoreConfirm(p9, u10) -- Line: 108
    -- upvalues: script_Parent (copy), MainFrame (copy)
    local LoreConfirm = script_Parent:FindFirstChild("LoreConfirm");

    if LoreConfirm then
        LoreConfirm:Destroy();
    end;

    local Title = MainFrame:FindFirstChild("Title");
    local Frame = Instance.new("Frame");
    Frame.Name = "LoreConfirm";
    Frame.BackgroundColor3 = Color3.new(0, 0, 0);
    Frame.BackgroundTransparency = 0.35;
    Frame.BorderSizePixel = 0;
    Frame.Size = UDim2.new(1, 0, 1, 0);
    Frame.ZIndex = 50;
    Frame.Parent = script_Parent;
    local Frame2 = Instance.new("Frame");
    Frame2.AnchorPoint = Vector2.new(0.5, 0.5);
    Frame2.Position = UDim2.new(0.5, 0, 0.5, 0);
    Frame2.Size = UDim2.new(0.34, 0, 0.3, 0);
    Frame2.BackgroundColor3 = Color3.fromRGB(16, 16, 20);
    Frame2.BorderSizePixel = 0;
    Frame2.ZIndex = 51;
    Frame2.Parent = Frame;
    local UICorner = Instance.new("UICorner");
    UICorner.CornerRadius = UDim.new(0, 8);
    UICorner.Parent = Frame2;
    local UIStroke = Instance.new("UIStroke");
    UIStroke.Color = Color3.fromRGB(212, 175, 55);
    UIStroke.Thickness = 1.5;
    UIStroke.Transparency = 0.2;
    UIStroke.Parent = Frame2;
    local TextLabel = Instance.new("TextLabel");
    TextLabel.BackgroundTransparency = 1;
    TextLabel.Position = UDim2.new(0.05, 0, 0.06, 0);
    TextLabel.Size = UDim2.new(0.9, 0, 0.16, 0);
    TextLabel.Font = Title and Title.Font or Enum.Font.GothamBold;
    TextLabel.Text = "SET LORE SLOT " .. string.format("%02d", p9);
    TextLabel.TextColor3 = Color3.fromRGB(212, 175, 55);
    TextLabel.TextScaled = true;
    TextLabel.ZIndex = 52;
    TextLabel.Parent = Frame2;
    local TextLabel2 = Instance.new("TextLabel");
    TextLabel2.BackgroundTransparency = 1;
    TextLabel2.Position = UDim2.new(0.06, 0, 0.26, 0);
    TextLabel2.Size = UDim2.new(0.88, 0, 0.38, 0);
    TextLabel2.Font = Enum.Font.Gotham;
    TextLabel2.Text = "Are you sure you want to select this slot as your Lore Slot?\nLore Slots CANNOT be changed after being selected.";
    TextLabel2.TextColor3 = Color3.fromRGB(225, 225, 230);
    TextLabel2.TextWrapped = true;
    TextLabel2.TextScaled = true;
    TextLabel2.ZIndex = 52;
    TextLabel2.Parent = Frame2;

    local function makeButton(p11, p12, p13, p14) -- Line: 163
        -- upvalues: Title (copy), Frame2 (copy)
        local TextButton = Instance.new("TextButton");
        TextButton.AnchorPoint = Vector2.new(0.5, 1);
        TextButton.Position = UDim2.new(p12, 0, 0.92, 0);
        TextButton.Size = UDim2.new(0.38, 0, 0.17, 0);
        TextButton.BackgroundColor3 = p13;
        TextButton.BorderSizePixel = 0;
        TextButton.Font = Title and Title.Font or Enum.Font.GothamBold;
        TextButton.Text = p11;
        TextButton.TextColor3 = p14;
        TextButton.TextScaled = true;
        TextButton.ZIndex = 52;
        local UICorner2 = Instance.new("UICorner");
        UICorner2.CornerRadius = UDim.new(0, 6);
        UICorner2.Parent = TextButton;
        TextButton.Parent = Frame2;

        return TextButton;
    end;

    local v15 = makeButton("YES", 0.29, Color3.fromRGB(212, 175, 55), Color3.fromRGB(16, 16, 20));
    local v16 = makeButton("NO", 0.71, Color3.fromRGB(38, 38, 44), Color3.fromRGB(225, 225, 230));
    v15.MouseButton1Up:Connect(function() -- Line: 185
        -- upvalues: Frame (copy), u10 (copy)
        Frame:Destroy();
        u10();
    end);
    v16.MouseButton1Up:Connect(function() -- Line: 191
        -- upvalues: Frame (copy)
        Frame:Destroy();
    end);
end;

local function Setup(p17) -- Line: 196
    -- upvalues: clearExistingSlots (copy), MainFrame (copy), CardHolder (copy), GlobalFunctions (copy), SoundManager (copy), LocalPlayer (copy), lockedSlotStandIn (copy), SlotTemplate (copy), Players (copy), ClothesHandler (copy), makeBadge (copy), MarketplaceService (copy), Random_Animation (copy), AnimationManager (copy), TweenService (copy), showLoreConfirm (copy), SlotRemote (copy)
    local u18 = p17.LoreMode == true;
    local v19 = tonumber(p17.LoreSlot) or 0;
    local v20 = (v19 < 1 or v19 > 4) and 0 or v19;
    local v21 = p17.LoreSlotDead == true;
    clearExistingSlots();
    local Title = MainFrame:FindFirstChild("Title");

    if Title then
        Title.Text = u18 and "SELECT YOUR LORE SLOT" or "SELECT A CHARACTER";
    end;

    MainFrame.Visible = true;
    CardHolder.Visible = true;
    MainFrame.Size = UDim2.new(1.5, 0, 1.5, 0);
    local v22 = {
        Duration = 0.3,
        Instance = MainFrame
    };
    local v23 = {
        Size = UDim2.new(1, 0, 1, 0)
    };
    GlobalFunctions.Tween(v22, v23);
    SoundManager.AddSound("Slot UI Open", {
        Parent = LocalPlayer
    }, "Client");

    for i = 1, 4 do
        local u24 = p17.CharacterSlots[i];
        local u25;

        if i == 4 then
            u25 = u24 == nil;
        else
            u25 = false;
        end;

        local u26, u27, v28, v29, v30, v31, v32, v33, u34, u35, v36, v37, v38, v39, v40, v41, v42, v43, v44, v45, u46, u47, u48, u49, u50;

        if u24 == nil then
            if i == 4 then
                u24 = lockedSlotStandIn();
                u26 = SlotTemplate:Clone();
                u26.Parent = CardHolder;
                u26.Visible = true;
                u26.Name = "Slot" .. i;
                u26.LayoutOrder = i;
                u27 = u26:FindFirstChild("LockedFrame");
                v28 = u26:FindFirstChild("ViewportFrame");
                v29 = Instance.new("WorldModel");
                v29.Parent = v28;
                v30 = Instance.new("Camera");
                v30.Parent = v28;
                v31 = nil;

                if LocalPlayer.UserId > 0 then
                    v32, v33 = pcall(Players.CreateHumanoidModelFromUserId, Players, LocalPlayer.UserId);

                    if not v32 then
                        v33 = v31;
                    end;
                else
                    v33 = v31;
                end;

                u34 = v33 or Players:CreateHumanoidModelFromDescription(Instance.new("HumanoidDescription"), Enum.HumanoidRigType.R15);
                u35 = i;

                for i2, descendant in ipairs(u34:GetDescendants()) do
                    if descendant:IsA("BaseScript") then
                        descendant:Destroy();
                    end;
                end;

                u34.Parent = v29;
                v36, v37 = GlobalFunctions.GetRootAndHumanoid(u34);
                v38 = Instance.new("HumanoidDescription");
                v38.Head = 0;
                v38.Torso = 0;
                v38.LeftArm = 0;
                v38.RightArm = 0;
                v38.LeftLeg = 0;
                v38.RightLeg = 0;
                v38.Shirt = 0;
                v38.Pants = 0;
                v38.GraphicTShirt = 0;
                v38.Face = 7074764;
                v39 = {};

                for i2, descendant in ipairs(u34:GetDescendants()) do
                    if descendant:IsA("Accessory") and descendant.AccessoryType == Enum.AccessoryType.Hair then
                        table.insert(v39, descendant:Clone());
                    end;
                end;

                v37:ApplyDescription(v38);

                for i2, v in ipairs(v39) do
                    v37:AddAccessory(v);
                end;

                task.spawn(function() -- Line: 327
                    -- upvalues: u25 (copy), ClothesHandler (ref), LocalPlayer (ref), u34 (ref), u24 (ref)
                    if u25 then
                        return;
                    end;

                    ClothesHandler.GiveClothes(LocalPlayer, u34, u24);
                end);
                v40 = u26:FindFirstChild("Name Label");
                v41 = u26:FindFirstChild("Planet Label");
                v42 = u26:FindFirstChild("Race Label");
                v43 = u26:FindFirstChild("Rank Label");
                v44 = u26:FindFirstChild("Slot Label");
                v40.Text = u24.CharacterData.Name == "" and "???" or (u24.CharacterData.Name or "???");
                v41.Text = "PLANET: " .. string.upper(u24.CharacterData.SpawnPlanet or "Earth");
                v42.Text = u24.CharacterData.Race.Race or "Human";
                v43.Text = "RANK " .. (u24.CharacterData.Rank or "E");
                v44.Text = "SLOT " .. string.format("%02d", u35);

                if v20 == u35 then
                    makeBadge(u26, v44, "LORE SLOT", Color3.fromRGB(212, 175, 55), 0.015);

                    if v21 then
                        makeBadge(u26, v44, "DEAD", Color3.fromRGB(235, 70, 70), 0.085);
                    else
                        makeBadge(u26, v44, "ALIVE", Color3.fromRGB(90, 220, 120), 0.085);
                    end;
                end;

                if u35 == 3 then
                    task.spawn(function() -- Line: 358
                        -- upvalues: LocalPlayer (ref), MarketplaceService (ref), u27 (copy)
                        local u51 = LocalPlayer;
                        local u52 = 1427963949;
                        local success, result = pcall(function() -- Line: 57
                            -- upvalues: MarketplaceService (ref), u51 (copy), u52 (copy)
                            return MarketplaceService:UserOwnsGamePassAsync(u51.UserId, u52);
                        end);

                        if not success then
                            warn("Error checking gamepass ownership for", u51.Name);
                            result = false;
                        end;

                        if result == false and u27.Parent then
                            u27.Visible = true;
                        end;
                    end);
                elseif u25 then
                    u27.Visible = true;
                end;

                v45 = Random_Animation();
                AnimationManager.PlayAnimation(u34, v45, {
                    Looped = true
                });
                v30.CFrame = v36.CFrame * CFrame.new(0, 1, -9.5);
                v30.CFrame = CFrame.lookAt(v30.CFrame.Position, v36.Position);
                v28.CurrentCamera = v30;
                u46 = u26:FindFirstChildOfClass("UIStroke");
                u47 = u26.Size;
                u48 = UDim2.new(u47.X.Scale, 0, u47.Y.Scale * 1.04, 0);

                if u46 then
                    u49 = u46.Color;
                else
                    u49 = u46;
                end;

                u50 = TweenInfo.new(0.1, Enum.EasingStyle.Quad, Enum.EasingDirection.Out);
                u26.MouseEnter:Connect(function() -- Line: 382
                    -- upvalues: u27 (copy), SoundManager (ref), LocalPlayer (ref), TweenService (ref), u26 (copy), u50 (copy), u48 (copy), u46 (copy)
                    if u27.Visible == true then
                        return;
                    end;

                    SoundManager.AddSound("Slot Hover", {
                        Parent = LocalPlayer
                    }, "Client");
                    TweenService:Create(u26, u50, {
                        Size = u48
                    }):Play();

                    if u46 then
                        TweenService:Create(u46, u50, {
                            Transparency = 0,
                            Color = Color3.new(1, 1, 1)
                        }):Play();
                    end;
                end);
                u26.MouseLeave:Connect(function() -- Line: 391
                    -- upvalues: u27 (copy), TweenService (ref), u26 (copy), u50 (copy), u47 (copy), u46 (copy), u49 (copy)
                    if u27.Visible == true then
                        return;
                    end;

                    TweenService:Create(u26, u50, {
                        Size = u47
                    }):Play();

                    if u46 then
                        TweenService:Create(u46, u50, {
                            Transparency = 0.4,
                            Color = u49
                        }):Play();
                    end;
                end);
                u26.MouseButton1Up:Connect(function() -- Line: 399
                    -- upvalues: u27 (copy), MarketplaceService (ref), LocalPlayer (ref), u35 (copy), u18 (copy), showLoreConfirm (ref), SlotRemote (ref), CardHolder (ref), MainFrame (ref)
                    if u27.Visible == true then
                        MarketplaceService:PromptGamePassPurchase(LocalPlayer, u35 == 4 and 1966662627 or 1427963949);

                        return;
                    end;

                    if u18 then
                        showLoreConfirm(u35, function() -- Line: 407
                            -- upvalues: SlotRemote (ref), u35 (ref), CardHolder (ref), MainFrame (ref)
                            SlotRemote:FireServer({
                                LoreConfirm = true,
                                ChosenSlot = u35
                            });
                            CardHolder.Visible = false;
                            task.delay(0.5, function() -- Line: 413
                                -- upvalues: MainFrame (ref)
                                MainFrame.Visible = false;
                            end);
                        end);

                        return;
                    end;

                    SlotRemote:FireServer({
                        ChosenSlot = u35
                    });
                    CardHolder.Visible = false;
                    task.delay(0.5, function() -- Line: 426
                        -- upvalues: MainFrame (ref)
                        MainFrame.Visible = false;
                    end);
                end);
            end;

            u35 = i;
        else
            u26 = SlotTemplate:Clone();
            u26.Parent = CardHolder;
            u26.Visible = true;
            u26.Name = "Slot" .. i;
            u26.LayoutOrder = i;
            u27 = u26:FindFirstChild("LockedFrame");
            v28 = u26:FindFirstChild("ViewportFrame");
            v29 = Instance.new("WorldModel");
            v29.Parent = v28;
            v30 = Instance.new("Camera");
            v30.Parent = v28;
            v31 = nil;

            if LocalPlayer.UserId > 0 then
                v32, v33 = pcall(Players.CreateHumanoidModelFromUserId, Players, LocalPlayer.UserId);

                if not v32 then
                    v33 = v31;
                end;
            else
                v33 = v31;
            end;

            u34 = v33 or Players:CreateHumanoidModelFromDescription(Instance.new("HumanoidDescription"), Enum.HumanoidRigType.R15);
            u35 = i;

            for i2, descendant in ipairs(u34:GetDescendants()) do
                if descendant:IsA("BaseScript") then
                    descendant:Destroy();
                end;
            end;

            u34.Parent = v29;
            v36, v37 = GlobalFunctions.GetRootAndHumanoid(u34);
            v38 = Instance.new("HumanoidDescription");
            v38.Head = 0;
            v38.Torso = 0;
            v38.LeftArm = 0;
            v38.RightArm = 0;
            v38.LeftLeg = 0;
            v38.RightLeg = 0;
            v38.Shirt = 0;
            v38.Pants = 0;
            v38.GraphicTShirt = 0;
            v38.Face = 7074764;
            v39 = {};

            for i2, descendant in ipairs(u34:GetDescendants()) do
                if descendant:IsA("Accessory") and descendant.AccessoryType == Enum.AccessoryType.Hair then
                    table.insert(v39, descendant:Clone());
                end;
            end;

            v37:ApplyDescription(v38);

            for i2, v in ipairs(v39) do
                v37:AddAccessory(v);
            end;

            task.spawn(function() -- Line: 327
                -- upvalues: u25 (copy), ClothesHandler (ref), LocalPlayer (ref), u34 (ref), u24 (ref)
                if u25 then
                    return;
                end;

                ClothesHandler.GiveClothes(LocalPlayer, u34, u24);
            end);
            v40 = u26:FindFirstChild("Name Label");
            v41 = u26:FindFirstChild("Planet Label");
            v42 = u26:FindFirstChild("Race Label");
            v43 = u26:FindFirstChild("Rank Label");
            v44 = u26:FindFirstChild("Slot Label");
            v40.Text = u24.CharacterData.Name == "" and "???" or (u24.CharacterData.Name or "???");
            v41.Text = "PLANET: " .. string.upper(u24.CharacterData.SpawnPlanet or "Earth");
            v42.Text = u24.CharacterData.Race.Race or "Human";
            v43.Text = "RANK " .. (u24.CharacterData.Rank or "E");
            v44.Text = "SLOT " .. string.format("%02d", u35);

            if v20 == u35 then
                makeBadge(u26, v44, "LORE SLOT", Color3.fromRGB(212, 175, 55), 0.015);

                if v21 then
                    makeBadge(u26, v44, "DEAD", Color3.fromRGB(235, 70, 70), 0.085);
                else
                    makeBadge(u26, v44, "ALIVE", Color3.fromRGB(90, 220, 120), 0.085);
                end;
            end;

            if u35 == 3 then
                task.spawn(function() -- Line: 358
                    -- upvalues: LocalPlayer (ref), MarketplaceService (ref), u27 (copy)
                    local u51 = LocalPlayer;
                    local u52 = 1427963949;
                    local success, result = pcall(function() -- Line: 57
                        -- upvalues: MarketplaceService (ref), u51 (copy), u52 (copy)
                        return MarketplaceService:UserOwnsGamePassAsync(u51.UserId, u52);
                    end);

                    if not success then
                        warn("Error checking gamepass ownership for", u51.Name);
                        result = false;
                    end;

                    if result == false and u27.Parent then
                        u27.Visible = true;
                    end;
                end);
            elseif u25 then
                u27.Visible = true;
            end;

            v45 = Random_Animation();
            AnimationManager.PlayAnimation(u34, v45, {
                Looped = true
            });
            v30.CFrame = v36.CFrame * CFrame.new(0, 1, -9.5);
            v30.CFrame = CFrame.lookAt(v30.CFrame.Position, v36.Position);
            v28.CurrentCamera = v30;
            u46 = u26:FindFirstChildOfClass("UIStroke");
            u47 = u26.Size;
            u48 = UDim2.new(u47.X.Scale, 0, u47.Y.Scale * 1.04, 0);

            if u46 then
                u49 = u46.Color;
            else
                u49 = u46;
            end;

            u50 = TweenInfo.new(0.1, Enum.EasingStyle.Quad, Enum.EasingDirection.Out);
            u26.MouseEnter:Connect(function() -- Line: 382
                -- upvalues: u27 (copy), SoundManager (ref), LocalPlayer (ref), TweenService (ref), u26 (copy), u50 (copy), u48 (copy), u46 (copy)
                if u27.Visible == true then
                    return;
                end;

                SoundManager.AddSound("Slot Hover", {
                    Parent = LocalPlayer
                }, "Client");
                TweenService:Create(u26, u50, {
                    Size = u48
                }):Play();

                if u46 then
                    TweenService:Create(u46, u50, {
                        Transparency = 0,
                        Color = Color3.new(1, 1, 1)
                    }):Play();
                end;
            end);
            u26.MouseLeave:Connect(function() -- Line: 391
                -- upvalues: u27 (copy), TweenService (ref), u26 (copy), u50 (copy), u47 (copy), u46 (copy), u49 (copy)
                if u27.Visible == true then
                    return;
                end;

                TweenService:Create(u26, u50, {
                    Size = u47
                }):Play();

                if u46 then
                    TweenService:Create(u46, u50, {
                        Transparency = 0.4,
                        Color = u49
                    }):Play();
                end;
            end);
            u26.MouseButton1Up:Connect(function() -- Line: 399
                -- upvalues: u27 (copy), MarketplaceService (ref), LocalPlayer (ref), u35 (copy), u18 (copy), showLoreConfirm (ref), SlotRemote (ref), CardHolder (ref), MainFrame (ref)
                if u27.Visible == true then
                    MarketplaceService:PromptGamePassPurchase(LocalPlayer, u35 == 4 and 1966662627 or 1427963949);

                    return;
                end;

                if u18 then
                    showLoreConfirm(u35, function() -- Line: 407
                        -- upvalues: SlotRemote (ref), u35 (ref), CardHolder (ref), MainFrame (ref)
                        SlotRemote:FireServer({
                            LoreConfirm = true,
                            ChosenSlot = u35
                        });
                        CardHolder.Visible = false;
                        task.delay(0.5, function() -- Line: 413
                            -- upvalues: MainFrame (ref)
                            MainFrame.Visible = false;
                        end);
                    end);

                    return;
                end;

                SlotRemote:FireServer({
                    ChosenSlot = u35
                });
                CardHolder.Visible = false;
                task.delay(0.5, function() -- Line: 426
                    -- upvalues: MainFrame (ref)
                    MainFrame.Visible = false;
                end);
            end);
        end;
    end;
end;

SlotRemote.OnClientEvent:Connect(function(p53) -- Line: 433
    -- upvalues: Setup (copy)
    Setup(p53);
end);
MarketplaceService.PromptGamePassPurchaseFinished:Connect(function(p54, p55, p56) -- Line: 437
    -- upvalues: LocalPlayer (copy), CardHolder (copy), MarketRemote (copy)
    if p54 ~= LocalPlayer or not p56 then
        return;
    end;

    if p55 ~= 1427963949 then
        if p55 == 1966662627 then
            MarketRemote:FireServer("Fourth Slot");
        end;

        return;
    end;

    local Slot3 = CardHolder:FindFirstChild("Slot3");

    if Slot3 then
        Slot3.LockedFrame.Visible = false;
    end;

    MarketRemote:FireServer("Third Slot");
end);