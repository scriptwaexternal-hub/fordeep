-- Decompiled with Potassium's decompiler.

local Players = game:GetService("Players");
local Modules = game:GetService("ReplicatedStorage"):WaitForChild("Modules");
local CooldownHandler = require(Modules.Utility.CooldownHandler);
local LocalPlayer = Players.LocalPlayer;

return {
    Cooldown = function(p1) -- Line: 21
        -- upvalues: CooldownHandler (copy), LocalPlayer (copy)
        CooldownHandler.Fire(LocalPlayer, p1.Attack_Type, p1.Attack_Name, p1.Race_Type);
    end
};