-- Decompiled with Potassium's decompiler.

local u1 = {};
u1.__index = u1;

function u1.new(p2: table, p3: function) -- Line: 31
    -- upvalues: u1 (copy)
    return setmetatable({
        Connected = true,
        _next = nil,
        _prev = nil,
        _signal = p2,
        _callback = p3
    }, u1);
end;

function u1.Disconnect(p4) -- Line: 41
    if not p4.Connected then
        return;
    end;

    p4.Connected = false;
    local _next = p4._next;
    local _prev = p4._prev;

    if _next then
        _next._prev = _prev;
    end;

    if _prev then
        _prev._next = _next;
    elseif p4._signal then
        p4._signal._head = _next;
    end;

    p4._callback = nil;
    p4._signal = nil;
    p4._prev = nil;
end;

local u5 = {};
u5.__index = u5;

function u5.new() -- Line: 65
    -- upvalues: u5 (copy)
    return setmetatable({}, u5);
end;

function u5.Connect(p6: table, p7: function) -- Line: 69
    -- upvalues: u1 (copy)
    local v8 = u1.new(p6, p7);

    if p6._head then
        v8._next = p6._head;
        p6._head._prev = v8;
    end;

    p6._head = v8;

    return v8;
end;

function u5.Once(p9: table, u10: function) -- Line: 79
    local u11 = nil;
    u11 = p9:Connect(function(...) -- Line: 81
        -- upvalues: u11 (ref), u10 (copy)
        if u11.Connected then
            u11:Disconnect();
        end;

        u10(...);
    end);

    return u11;
end;

function u5.Fire(p12, ...) -- Line: 90
    local _head = p12._head;

    while _head do
        local _next = _head._next;

        if _head.Connected then
            task.spawn(_head._callback, ...);
            _head = _next;
        else
            _head.Connected = nil;
            _head._next = nil;
            _head = _next;
        end;
    end;
end;

function u5.Wait(p13) -- Line: 104
    local coroutine_running_ret = coroutine.running();
    local u14 = nil;
    u14 = p13:Connect(function(...) -- Line: 107
        -- upvalues: u14 (ref), coroutine_running_ret (copy)
        u14:Disconnect();
        u14._thread = nil;

        if coroutine.status(coroutine_running_ret) == "suspended" then
            task.spawn(coroutine_running_ret, ...);
        end;
    end);
    u14._thread = coroutine_running_ret;

    return coroutine.yield();
end;

function u5.Destroy(p15) -- Line: 118
    local _head = p15._head;

    while _head do
        local _next = _head._next;

        if _head.Connected then
            if typeof(_head._thread) == "thread" and coroutine.status(_head._thread) == "suspended" then
                task.cancel(_head._thread);
            end;

            table.clear(_head);
            _head = _next;
        else
            _head = _next;
        end;
    end;

    table.clear(p15);
end;

return u5;