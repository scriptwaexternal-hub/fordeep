-- Decompiled with Potassium's decompiler.

local ReplicatedStorage = game:GetService("ReplicatedStorage");
local StateDefinitions = require(ReplicatedStorage.Modules.Metadata.StateData.StateDefinitions);
local u1 = {};
local u2 = {};
local u3 = {};
local u4 = {};

local function ensureCharacterEntry(p5) -- Line: 32
    -- upvalues: u2 (copy), u3 (copy), u4 (copy)
    if not u2[p5] then
        u2[p5] = {
            name = "Idle",
            priority = 0
        };
        u3[p5] = {
            Idle = true
        };
        u4[p5] = {};
    end;
end;

local function recomputeActiveState(p6) -- Line: 40
    -- upvalues: u3 (copy), StateDefinitions (copy), u2 (copy)
    local v7 = {
        name = "Idle",
        priority = -1
    };

    for i in pairs(u3[p6]) do
        local v8 = StateDefinitions[i];

        if v8 and v8.priority > v7.priority then
            v7 = {
                name = i,
                priority = v8.priority
            };
        end;
    end;

    u2[p6] = v7;
end;

local function cancelTimer(p9, p10) -- Line: 51
    -- upvalues: u4 (copy)
    if u4[p9] and u4[p9][p10] then
        pcall(task.cancel, u4[p9][p10]);
        u4[p9][p10] = nil;
    end;
end;

function u1.SetState(u11, u12, u13) -- Line: 74
    -- upvalues: ensureCharacterEntry (copy), StateDefinitions (copy), u2 (copy), u3 (copy), u4 (copy), u1 (copy), recomputeActiveState (copy)
    ensureCharacterEntry(u11);
    local v14 = StateDefinitions[u12];

    if not v14 then
        warn("StateManager.SetState: Unknown state \'" .. tostring(u12) .. "\'");

        return false;
    end;

    local v15 = u2[u11];
    local v16 = StateDefinitions[v15.name];

    if v16 and v15.name ~= "Idle" then
        local v17 = v14.priority > v15.priority;

        if v16.interruptedBy then
            if v16.interruptedBy[1] == "*" then
                v17 = true;
            else
                for _, v in ipairs(v16.interruptedBy) do
                    if v == u12 then
                        v17 = true;
                        break;
                    end;
                end;
            end;
        end;

        if not v17 then
            return false;
        end;
    end;

    u3[u11][u12] = true;

    if v14.onEnter then
        task.spawn(v14.onEnter, u11, u13);
    end;

    if v14.duration then
        if u4[u11] and u4[u11][u12] then
            pcall(task.cancel, u4[u11][u12]);
            u4[u11][u12] = nil;
        end;

        u4[u11][u12] = task.delay(v14.duration, function() -- Line: 125
            -- upvalues: u1 (ref), u11 (copy), u12 (copy), u13 (copy)
            u1.ClearState(u11, u12, u13);
        end);
    end;

    recomputeActiveState(u11);

    return true;
end;

function u1.ClearState(p18, p19, p20) -- Line: 140
    -- upvalues: ensureCharacterEntry (copy), u3 (copy), StateDefinitions (copy), u4 (copy), recomputeActiveState (copy)
    ensureCharacterEntry(p18);

    if not u3[p18][p19] then
        return;
    end;

    local v21 = StateDefinitions[p19];

    if v21 and v21.onExit then
        task.spawn(v21.onExit, p18, p20);
    end;

    if u4[p18] and u4[p18][p19] then
        pcall(task.cancel, u4[p18][p19]);
        u4[p18][p19] = nil;
    end;

    u3[p18][p19] = nil;

    if not next(u3[p18]) then
        u3[p18].Idle = true;
    end;

    recomputeActiveState(p18);
end;

function u1.ForceSetState(p22, p23, p24) -- Line: 167
    -- upvalues: ensureCharacterEntry (copy), u3 (copy), u4 (copy), StateDefinitions (copy), recomputeActiveState (copy)
    ensureCharacterEntry(p22);

    for i in pairs(u3[p22]) do
        if u4[p22] and u4[p22][i] then
            pcall(task.cancel, u4[p22][i]);
            u4[p22][i] = nil;
        end;

        local v25 = StateDefinitions[i];

        if v25 and v25.onExit then
            task.spawn(v25.onExit, p22, p24);
        end;
    end;

    u3[p22] = {
        [p23] = true,
        Idle = true
    };
    local v26 = StateDefinitions[p23];

    if v26 and v26.onEnter then
        task.spawn(v26.onEnter, p22, p24);
    end;

    recomputeActiveState(p22);
end;

function u1.GetState(p27) -- Line: 194
    -- upvalues: ensureCharacterEntry (copy), u2 (copy)
    ensureCharacterEntry(p27);

    return u2[p27].name;
end;

function u1.GetAllStates(p28) -- Line: 205
    -- upvalues: ensureCharacterEntry (copy), u3 (copy)
    ensureCharacterEntry(p28);

    return u3[p28];
end;

function u1.IsInState(p29, p30) -- Line: 216
    -- upvalues: ensureCharacterEntry (copy), u3 (copy)
    ensureCharacterEntry(p29);

    return u3[p29][p30] == true;
end;

function u1.IsInCategory(p31, p32) -- Line: 229
    -- upvalues: ensureCharacterEntry (copy), StateDefinitions (copy), u2 (copy)
    ensureCharacterEntry(p31);
    local v33 = StateDefinitions[u2[p31].name];

    if v33 then
        v33 = v33.category == p32;
    end;

    return v33;
end;

function u1.CanPerformAction(p34, p35, p36) -- Line: 252
    -- upvalues: ensureCharacterEntry (copy), u3 (copy), StateDefinitions (copy)
    ensureCharacterEntry(p34);

    for i in pairs(u3[p34]) do
        local v37 = StateDefinitions[i];

        if v37 then
            if v37.blockedActions then
                for _, v in ipairs(v37.blockedActions) do
                    if v == p35 or p36 and v == p36 then
                        return false;
                    end;
                end;
            end;

            local allowedActions = v37.allowedActions;

            if not allowedActions then
                return false;
            end;

            if allowedActions[1] ~= "*" then
                local v38 = false;

                for _, v in ipairs(allowedActions) do
                    if v == p35 or p36 and v == p36 then
                        v38 = true;
                        break;
                    end;
                end;

                if not v38 then
                    return false;
                end;
            end;
        end;
    end;

    return true;
end;

function u1.GetPriority(p39) -- Line: 304
    -- upvalues: ensureCharacterEntry (copy), u2 (copy)
    ensureCharacterEntry(p39);

    return u2[p39].priority;
end;

function u1.CleanupCharacter(p40) -- Line: 314
    -- upvalues: u4 (copy), u2 (copy), u3 (copy)
    if u4[p40] then
        for i in pairs(u4[p40]) do
            if u4[p40] and u4[p40][i] then
                pcall(task.cancel, u4[p40][i]);
                u4[p40][i] = nil;
            end;
        end;
    end;

    u2[p40] = nil;
    u3[p40] = nil;
    u4[p40] = nil;
end;

function u1.SyncState(p41, p42) -- Line: 333
    -- upvalues: ensureCharacterEntry (copy), StateDefinitions (copy), u3 (copy), recomputeActiveState (copy)
    ensureCharacterEntry(p41);
    local v43 = StateDefinitions[p42];

    if not v43 then
        return;
    end;

    u3[p41][p42] = true;

    if v43.onEnter then
        task.spawn(v43.onEnter, p41);
    end;

    recomputeActiveState(p41);
end;

function u1.UnsyncState(p44, p45) -- Line: 355
    -- upvalues: u1 (copy)
    u1.ClearState(p44, p45);
end;

return u1;