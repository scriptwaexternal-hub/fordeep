-- Decompiled with Potassium's decompiler.

local ReplicatedStorage = game:GetService("ReplicatedStorage");
local Players = game:GetService("Players");
local Modules = ReplicatedStorage:WaitForChild("Modules");
local Remotes = ReplicatedStorage:WaitForChild("Remotes");
local Metadata = Modules.Metadata;
local Shared = Modules.Shared;
local TopbarPlus = require(Shared.TopbarPlus);
TopbarPlus.highlightKey = false;
local ControlData = require(Metadata.ControlData.ControlData);
local TutorialData = require(Metadata.CharacterData.TutorialData);
local ChangelogData = require(Metadata.MiscData.ChangelogData);
local TopbarRemote = Remotes.TopbarRemote;
local StatRetrieveRemote = ReplicatedStorage.Remotes.StatRetrieveRemote;
local FactionRemote = Remotes.FactionRemote;
local LocalPlayer = Players.LocalPlayer;
local u1 = {
    PLATE_T = 0.02,
    ROW_T = 0.94,
    PLATE = Color3.fromRGB(28, 28, 30),
    ROW = Color3.fromRGB(255, 255, 255),
    TEXT = Color3.fromRGB(255, 255, 255),
    SUB = Color3.fromRGB(216, 213, 205),
    DIM = Color3.fromRGB(150, 150, 150),
    ACCENT = Color3.fromRGB(88, 214, 106),
    FONT = Enum.Font.Bangers,
    FONT_BOLD = Enum.Font.Arcade
};

local function corner(p2, p3) -- Line: 93
    local UICorner = Instance.new("UICorner");
    UICorner.CornerRadius = UDim.new(0, p3 or 12);
    UICorner.Parent = p2;

    return UICorner;
end;

local function stroke(p4, p5, p6, p7) -- Line: 100
    local UIStroke = Instance.new("UIStroke");
    UIStroke.Color = p5 or Color3.fromRGB(0, 0, 0);
    UIStroke.Thickness = p6 or 2;
    UIStroke.Transparency = p7 or 0;
    UIStroke.ApplyStrokeMode = Enum.ApplyStrokeMode.Contextual;
    UIStroke.Parent = p4;

    return UIStroke;
end;

local function pad(p8, p9) -- Line: 110
    local UIPadding = Instance.new("UIPadding");
    UIPadding.PaddingTop = UDim.new(0, p9);
    UIPadding.PaddingBottom = UDim.new(0, p9);
    UIPadding.PaddingLeft = UDim.new(0, p9);
    UIPadding.PaddingRight = UDim.new(0, p9);
    UIPadding.Parent = p8;

    return UIPadding;
end;

local function label(p10, p11, p12, p13, p14, p15) -- Line: 120
    -- upvalues: u1 (copy)
    local TextLabel = Instance.new("TextLabel");
    TextLabel.BackgroundTransparency = 1;
    TextLabel.Font = p13 or u1.FONT;
    TextLabel.Text = p11 or "";
    TextLabel.TextSize = p12 or 14;
    TextLabel.TextColor3 = p14 or u1.TEXT;
    TextLabel.TextXAlignment = p15 or Enum.TextXAlignment.Left;
    TextLabel.TextYAlignment = Enum.TextYAlignment.Top;
    TextLabel.TextWrapped = true;
    TextLabel.RichText = false;
    TextLabel.Parent = p10;
    local Color3_fromRGB_ret = Color3.fromRGB(0, 0, 0);
    local UIStroke = Instance.new("UIStroke");
    UIStroke.Color = Color3_fromRGB_ret or Color3.fromRGB(0, 0, 0);
    UIStroke.Thickness = 2;
    UIStroke.Transparency = 0;
    UIStroke.ApplyStrokeMode = Enum.ApplyStrokeMode.Contextual;
    UIStroke.Parent = TextLabel;

    return TextLabel;
end;

local function panel(p16, p17, p18, p19) -- Line: 144
    -- upvalues: LocalPlayer (copy), u1 (copy), label (copy)
    local v20 = LocalPlayer.PlayerGui:FindFirstChild(p16);

    if v20 then
        v20:Destroy();

        return nil;
    end;

    local ScreenGui = Instance.new("ScreenGui");
    ScreenGui.Name = p16;
    ScreenGui.ResetOnSpawn = false;
    ScreenGui.IgnoreGuiInset = true;
    ScreenGui.DisplayOrder = 20;
    ScreenGui.ZIndexBehavior = Enum.ZIndexBehavior.Sibling;
    ScreenGui.Parent = LocalPlayer.PlayerGui;
    local TextButton = Instance.new("TextButton");
    TextButton.Size = UDim2.fromScale(1, 1);
    TextButton.BackgroundColor3 = Color3.fromRGB(0, 0, 0);
    TextButton.BackgroundTransparency = 0.45;
    TextButton.BorderSizePixel = 0;
    TextButton.Text = "";
    TextButton.AutoButtonColor = false;
    TextButton.Parent = ScreenGui;
    local Frame = Instance.new("Frame");
    Frame.Name = "Card";
    Frame.AnchorPoint = Vector2.new(0.5, 0.5);
    Frame.Position = UDim2.fromScale(0.5, 0.5);
    Frame.Size = UDim2.fromOffset(p18, p19);
    Frame.BackgroundColor3 = u1.PLATE;
    Frame.BackgroundTransparency = u1.PLATE_T;
    Frame.BorderSizePixel = 0;
    Frame.Parent = ScreenGui;
    local UICorner = Instance.new("UICorner");
    UICorner.CornerRadius = UDim.new(0, 14);
    UICorner.Parent = Frame;
    local Color3_fromRGB_ret = Color3.fromRGB(255, 255, 255);
    local UIStroke = Instance.new("UIStroke");
    UIStroke.Color = Color3_fromRGB_ret or Color3.fromRGB(0, 0, 0);
    UIStroke.Thickness = 1;
    UIStroke.Transparency = 0.88;
    UIStroke.ApplyStrokeMode = Enum.ApplyStrokeMode.Contextual;
    UIStroke.Parent = Frame;
    local UISizeConstraint = Instance.new("UISizeConstraint");
    UISizeConstraint.MaxSize = Vector2.new(p18, p19);
    UISizeConstraint.Parent = Frame;
    local Frame2 = Instance.new("Frame");
    Frame2.Name = "Header";
    Frame2.Size = UDim2.new(1, 0, 0, 52);
    Frame2.BackgroundTransparency = 1;
    Frame2.Parent = Frame;
    local Frame3 = Instance.new("Frame");
    Frame3.Size = UDim2.fromOffset(3, 18);
    Frame3.Position = UDim2.fromOffset(20, 19);
    Frame3.BackgroundColor3 = u1.ACCENT;
    Frame3.BorderSizePixel = 0;
    Frame3.Parent = Frame2;
    local UICorner2 = Instance.new("UICorner");
    UICorner2.CornerRadius = UDim.new(0, 2);
    UICorner2.Parent = Frame3;
    local v21 = label(Frame2, "[ " .. string.upper(p17 or "") .. " ]", 17, u1.FONT_BOLD, u1.ACCENT);
    v21.Position = UDim2.fromOffset(33, 17);
    v21.Size = UDim2.new(1, -100, 0, 22);
    v21.TextYAlignment = Enum.TextYAlignment.Center;
    local TextButton2 = Instance.new("TextButton");
    TextButton2.Name = "Close";
    TextButton2.AnchorPoint = Vector2.new(1, 0);
    TextButton2.Position = UDim2.new(1, -14, 0, 14);
    TextButton2.Size = UDim2.fromOffset(26, 26);
    TextButton2.BackgroundTransparency = 1;
    TextButton2.Font = u1.FONT_BOLD;
    TextButton2.Text = "X";
    TextButton2.TextSize = 16;
    TextButton2.TextColor3 = u1.DIM;
    TextButton2.AutoButtonColor = false;
    TextButton2.Parent = Frame2;
    TextButton2.MouseEnter:Connect(function() -- Line: 215
        -- upvalues: TextButton2 (copy), u1 (ref)
        TextButton2.TextColor3 = u1.TEXT;
    end);
    TextButton2.MouseLeave:Connect(function() -- Line: 216
        -- upvalues: TextButton2 (copy), u1 (ref)
        TextButton2.TextColor3 = u1.DIM;
    end);
    local Frame4 = Instance.new("Frame");
    Frame4.Size = UDim2.new(1, -40, 0, 1);
    Frame4.Position = UDim2.fromOffset(20, 51);
    Frame4.BackgroundColor3 = Color3.fromRGB(255, 255, 255);
    Frame4.BackgroundTransparency = 0.88;
    Frame4.BorderSizePixel = 0;
    Frame4.Parent = Frame2;
    local Frame5 = Instance.new("Frame");
    Frame5.Name = "Content";
    Frame5.Position = UDim2.fromOffset(0, 52);
    Frame5.Size = UDim2.new(1, 0, 1, -52);
    Frame5.BackgroundTransparency = 1;
    Frame5.Parent = Frame;

    local function dismiss() -- Line: 233
        -- upvalues: ScreenGui (copy)
        ScreenGui:Destroy();
    end;

    TextButton2.MouseButton1Click:Connect(dismiss);
    TextButton.MouseButton1Click:Connect(dismiss);

    return ScreenGui, Frame5, dismiss;
end;

local GamepadGlyphs = require(Shared.GamepadGlyphs);

local function isGamepadKey(p22) -- Line: 255
    -- upvalues: GamepadGlyphs (copy)
    return GamepadGlyphs.IsGamepadKey(p22);
end;

local function isKeybinding(p23) -- Line: 267
    if type(p23) ~= "table" then
        return false;
    end;

    if #p23 == 0 then
        return false;
    end;

    for _, v in ipairs(p23) do
        if type(v) ~= "string" then
            return false;
        end;
    end;

    return true;
end;

local u24 = {
    DeCharge = "Charge"
};
local u25 = {
    Carry = "Grip",
    ["Ki Sense"] = "Loot"
};
local u26 = {
    {
        Title = "Combat",
        Source = { "Combat" },
        Order = { "Light", "Heavy", "Block", "Evade", "Dash", "Ki Blast", "Charge", "DeCharge", "Transform", "DeTransform", "Follow Up", "Ki Sense", "Carry", "Grip", "Loot", "Run" },
        Extra = { {
                Action = "Ragdoll Cancel",
                Literal = "Q - B / ○"
            } }
    },
    {
        Title = "Movement & world",
        Source = { "CoreControls" },
        Order = { "Flight/Climb", "Dive", "Meditate", "Shift Lock", "Cinematic Mode" }
    },
    {
        Title = "Interface",
        Source = { "Menu_UI", "UI", "CoreControls" },
        Order = { "Menu", "Inventory", "Skill Tree", "Transformations", "Emotes" },
        Only = {
            Menu = true,
            Inventory = true,
            ["Skill Tree"] = true,
            Transformations = true,
            Emotes = true
        }
    },
    {
        Title = "Great Ape form",
        Source = { "Great Ape" },
        Order = { "Light", "Heavy", "Beam", "Grab", "Push" }
    },
    {
        Title = "Controller utility layer",
        Source = {},
        Extra = { {
                Action = "Open layer",
                Pad = "ButtonL3",
                Prefix = "hold "
            }, {
                Action = "Sprint",
                Pad = "ButtonL3",
                Prefix = "tap "
            }, {
                Action = "Inventory",
                Pad = "ButtonY",
                Prefix = "+ "
            }, {
                Action = "Skill Tree",
                Pad = "ButtonX",
                Prefix = "+ "
            }, {
                Action = "Transformations",
                Pad = "ButtonB",
                Prefix = "+ "
            }, {
                Action = "Emotes",
                Pad = "ButtonA",
                Prefix = "+ "
            }, {
                Action = "Meditate",
                Pad = "ButtonL1",
                Prefix = "+ "
            }, {
                Action = "Zone Map",
                Pad = "ButtonR1",
                Prefix = "+ "
            }, {
                Action = "Hotbar prev",
                Pad = "ButtonL2",
                Prefix = "+ "
            }, {
                Action = "Hotbar next",
                Pad = "ButtonR2",
                Prefix = "+ "
            }, {
                Action = "Cinematic Mode",
                Pad = "DPadUp",
                Prefix = "+ "
            }, {
                Action = "Shift Lock",
                Pad = "DPadLeft",
                Prefix = "+ "
            }, {
                Action = "Menu",
                Pad = "DPadRight",
                Prefix = "+ "
            } }
    },
    {
        Title = "Controller hotbar",
        Source = {},
        Extra = { {
                Action = "Hold",
                Pad = "ButtonL1",
                Prefix = "hold "
            }, {
                Action = "Slot 1",
                Pad = "ButtonX",
                Prefix = "+ "
            }, {
                Action = "Slot 2",
                Pad = "ButtonY",
                Prefix = "+ "
            }, {
                Action = "Slot 3",
                Pad = "ButtonB",
                Prefix = "+ "
            }, {
                Action = "Slot 4",
                Pad = "ButtonR2",
                Prefix = "+ "
            }, {
                Action = "Cycle",
                Pad = "DPadRight",
                Prefix = "+ "
            } }
    }
};

local function collectSection(p27) -- Line: 368
    -- upvalues: ControlData (copy)
    local v28 = {};
    local v29 = {};

    for _, v in ipairs(p27.Source) do
        local v30 = ControlData.Controls[v];

        if type(v30) == "table" then
            for i, v2 in pairs(v30) do
                if not p27.Only or p27.Only[i] then
                    local v31, v32, v33;

                    if type(v2) == "table" and #v2 ~= 0 then
                        v31 = i;
                        v32 = v2;
                        v33 = true;

                        for _, v3 in ipairs(v2) do
                            if type(v3) ~= "string" then
                                v33 = false;
                                break;
                            end;
                        end;
                    else
                        v31 = i;
                        v32 = v2;
                        v33 = false;
                    end;

                    if v33 and not v29[v31] then
                        v29[v31] = true;
                        v28[#v28 + 1] = {
                            Action = v31,
                            Keys = v32
                        };
                    end;
                end;
            end;
        end;
    end;

    local u34 = {};

    for i, v in ipairs(p27.Order or {}) do
        u34[v] = i;
    end;

    table.sort(v28, function(p35, p36) -- Line: 385
        -- upvalues: u34 (copy)
        local v37 = u34[p35.Action];
        local v38 = u34[p36.Action];

        if v37 and v38 then
            return v37 < v38;
        end;

        if v37 then
            return true;
        end;

        if v38 then
            return false;
        end;

        return p35.Action < p36.Action;
    end);

    for _, v in ipairs(p27.Extra or {}) do
        v28[#v28 + 1] = v;
    end;

    return v28;
end;

local function keysMarkup(p39, p40) -- Line: 404
    -- upvalues: GamepadGlyphs (copy), u24 (copy), ControlData (copy), u25 (copy)
    local v41 = {};
    local v42 = {};

    for _, v in ipairs(p39) do
        local v43 = GamepadGlyphs.IsGamepadKey(v) and v41 and v41 or v42;
        v43[#v43 + 1] = GamepadGlyphs.Label(v);
    end;

    if #v41 == 0 and (p40 and u24[p40]) then
        local v44 = ControlData.Controls.Combat[u24[p40]];
        local v45;

        if type(v44) == "table" then
            v45 = v44[2];
        else
            v45 = false;
        end;

        if v45 then
            v41[#v41 + 1] = "2× " .. GamepadGlyphs.Label(v45);
        end;
    end;

    if #v41 == 0 and (p40 and u25[p40]) then
        local v46 = ControlData.Controls.Combat[u25[p40]];
        local v47;

        if type(v46) == "table" then
            v47 = v46[2];
        else
            v47 = false;
        end;

        if v47 then
            v41[#v41 + 1] = "hold " .. GamepadGlyphs.Label(v47);
        end;
    end;

    local v48 = {};

    if #v42 > 0 then
        v48[#v48 + 1] = table.concat(v42, " / ");
    end;

    if #v41 > 0 then
        v48[#v48 + 1] = ("<font color=\"#8E8C86\">%s%s</font>"):format(#v42 > 0 and "- " or "", table.concat(v41, " / "));
    end;

    return table.concat(v48, " ");
end;

local function rowMarkup(p49) -- Line: 439
    -- upvalues: GamepadGlyphs (copy), keysMarkup (copy)
    if p49.Literal then
        return ("<font color=\"#8E8C86\">%s</font>"):format(p49.Literal);
    end;

    if p49.Pad then
        return ("<font color=\"#8E8C86\">%s%s</font>"):format(p49.Prefix or "", GamepadGlyphs.Label(p49.Pad));
    end;

    return keysMarkup(p49.Keys, p49.Action);
end;

local function buildControlsPanel() -- Line: 450
    -- upvalues: panel (copy), pad (copy), u26 (copy), collectSection (copy), label (copy), u1 (copy), GamepadGlyphs (copy), keysMarkup (copy)
    local v50, v51 = panel("TopbarControls", "Controls", 460, 470);

    if not v50 then
        return;
    end;

    local ScrollingFrame = Instance.new("ScrollingFrame");
    ScrollingFrame.Size = UDim2.new(1, 0, 1, 0);
    ScrollingFrame.BackgroundTransparency = 1;
    ScrollingFrame.BorderSizePixel = 0;
    ScrollingFrame.ScrollBarThickness = 3;
    ScrollingFrame.ScrollBarImageColor3 = Color3.fromRGB(255, 255, 255);
    ScrollingFrame.ScrollBarImageTransparency = 0.7;
    ScrollingFrame.CanvasSize = UDim2.new();
    ScrollingFrame.AutomaticCanvasSize = Enum.AutomaticSize.Y;
    ScrollingFrame.Parent = v51;
    pad(ScrollingFrame, 14);
    local UIListLayout = Instance.new("UIListLayout");
    UIListLayout.FillDirection = Enum.FillDirection.Vertical;
    UIListLayout.SortOrder = Enum.SortOrder.LayoutOrder;
    UIListLayout.Padding = UDim.new(0, 2);
    UIListLayout.Parent = ScrollingFrame;
    local u52 = 0;

    local function nextOrder() -- Line: 473
        -- upvalues: u52 (ref)
        u52 = u52 + 1;

        return u52;
    end;

    for _, v in ipairs(u26) do
        local v53 = collectSection(v);

        if #v53 > 0 then
            local v54 = label(ScrollingFrame, string.upper(v.Title), 11, u1.FONT_BOLD, u1.ACCENT);
            v54.Size = UDim2.new(1, -8, 0, 26);
            u52 = u52 + 1;
            v54.LayoutOrder = u52;
            v54.TextYAlignment = Enum.TextYAlignment.Bottom;

            for _, v2 in ipairs(v53) do
                local Frame = Instance.new("Frame");
                Frame.Size = UDim2.new(1, -8, 0, 28);
                Frame.BackgroundColor3 = u1.ROW;
                Frame.BackgroundTransparency = u1.ROW_T;
                Frame.BorderSizePixel = 0;
                u52 = u52 + 1;
                Frame.LayoutOrder = u52;
                Frame.Parent = ScrollingFrame;
                local UICorner = Instance.new("UICorner");
                UICorner.CornerRadius = UDim.new(0, 6);
                UICorner.Parent = Frame;
                local v55 = label(Frame, v2.Action, 13, u1.FONT, u1.TEXT);
                v55.Position = UDim2.fromOffset(10, 0);
                v55.Size = UDim2.new(0.5, -10, 1, 0);
                v55.TextYAlignment = Enum.TextYAlignment.Center;
                local v56 = label(Frame, "", 13, u1.FONT_BOLD, u1.TEXT, Enum.TextXAlignment.Right);
                v56.RichText = true;
                local v57;

                if v2.Literal then
                    v57 = ("<font color=\"#8E8C86\">%s</font>"):format(v2.Literal);
                elseif v2.Pad then
                    v57 = ("<font color=\"#8E8C86\">%s%s</font>"):format(v2.Prefix or "", GamepadGlyphs.Label(v2.Pad));
                else
                    v57 = keysMarkup(v2.Keys, v2.Action);
                end;

                v56.Text = v57;
                v56.Position = UDim2.new(0.5, 0, 0, 0);
                v56.Size = UDim2.new(0.5, -10, 1, 0);
                v56.TextYAlignment = Enum.TextYAlignment.Center;
                v56.TextWrapped = false;
                v56.TextTruncate = Enum.TextTruncate.AtEnd;
            end;
        end;
    end;

    local v58 = label(ScrollingFrame, "Rebind any of these in Menu > Settings.", 11, u1.FONT, u1.DIM);
    v58.Size = UDim2.new(1, -8, 0, 30);
    u52 = u52 + 1;
    v58.LayoutOrder = u52;
    v58.TextYAlignment = Enum.TextYAlignment.Center;
end;

local function buildChangelogPanel() -- Line: 523
    -- upvalues: ChangelogData (copy), panel (copy), pad (copy), label (copy), u1 (copy)
    local v59 = ChangelogData[1];

    if not v59 then
        return;
    end;

    local v60, v61 = panel("TopbarChangelog", "Changes", 470, 500);

    if not v60 then
        return;
    end;

    local ScrollingFrame = Instance.new("ScrollingFrame");
    ScrollingFrame.Size = UDim2.new(1, 0, 1, 0);
    ScrollingFrame.BackgroundTransparency = 1;
    ScrollingFrame.BorderSizePixel = 0;
    ScrollingFrame.ScrollBarThickness = 3;
    ScrollingFrame.ScrollBarImageColor3 = Color3.fromRGB(255, 255, 255);
    ScrollingFrame.ScrollBarImageTransparency = 0.7;
    ScrollingFrame.CanvasSize = UDim2.new();
    ScrollingFrame.AutomaticCanvasSize = Enum.AutomaticSize.Y;
    ScrollingFrame.Parent = v61;
    pad(ScrollingFrame, 16);
    local UIListLayout = Instance.new("UIListLayout");
    UIListLayout.FillDirection = Enum.FillDirection.Vertical;
    UIListLayout.SortOrder = Enum.SortOrder.LayoutOrder;
    UIListLayout.Padding = UDim.new(0, 4);
    UIListLayout.Parent = ScrollingFrame;
    local u62 = 0;

    local function nextRow() -- Line: 548
        -- upvalues: u62 (ref)
        u62 = u62 + 1;

        return u62;
    end;

    local function line(p63, p64, p65, p66, p67) -- Line: 549
        -- upvalues: label (ref), ScrollingFrame (copy), u62 (ref)
        local v68 = label(ScrollingFrame, p63, p64, p65, p66);
        v68.Size = UDim2.new(1, -8, 0, 0);
        v68.AutomaticSize = Enum.AutomaticSize.Y;
        u62 = u62 + 1;
        v68.LayoutOrder = u62;

        if p67 then
            local UIPadding = Instance.new("UIPadding");
            UIPadding.PaddingTop = UDim.new(0, p67);
            UIPadding.Parent = v68;
        end;

        return v68;
    end;

    local v69 = label(ScrollingFrame, v59.Title or "", 20, u1.FONT_BOLD, u1.TEXT);
    v69.Size = UDim2.new(1, -8, 0, 0);
    v69.AutomaticSize = Enum.AutomaticSize.Y;
    u62 = u62 + 1;
    v69.LayoutOrder = u62;
    local v70 = label(ScrollingFrame, v59.Date or "", 12, Enum.Font.Gotham, u1.DIM);
    v70.Size = UDim2.new(1, -8, 0, 0);
    v70.AutomaticSize = Enum.AutomaticSize.Y;
    u62 = u62 + 1;
    v70.LayoutOrder = u62;

    for _, v in ipairs(v59.Sections or {}) do
        local v71 = v[2];
        line(string.upper(v[1]), 13, u1.FONT_BOLD, u1.ACCENT, 12);

        for _, v2 in ipairs(v71 or {}) do
            local v72 = label(ScrollingFrame, "- " .. v2, 14, Enum.Font.Gotham, u1.SUB);
            v72.Size = UDim2.new(1, -8, 0, 0);
            v72.AutomaticSize = Enum.AutomaticSize.Y;
            u62 = u62 + 1;
            v72.LayoutOrder = u62;
            v72.TextStrokeTransparency = 1;
            v72.LineHeight = 1.15;
            local v73 = v72:FindFirstChildOfClass("UIStroke");

            if v73 then
                v73.Thickness = 1;
                v73.Transparency = 0.6;
            end;
        end;
    end;
end;

local function confirmDialog(p74, p75, p76, u77) -- Line: 590
    -- upvalues: panel (copy), label (copy), u1 (copy)
    local v78, u79, u80 = panel("TopbarConfirm", p74, 380, 210);

    if not v78 then
        return;
    end;

    local Color3_fromRGB_ret = Color3.fromRGB(44, 44, 45);
    local Color3_fromRGB_ret2 = Color3.fromRGB(28, 28, 30);
    local Color3_fromRGB_ret3 = Color3.fromRGB(255, 255, 255);
    local Color3_fromRGB_ret4 = Color3.fromRGB(216, 213, 205);
    local Color3_fromRGB_ret5 = Color3.fromRGB(0, 0, 0);
    local Arcade = Enum.Font.Arcade;

    local function stroked(p81) -- Line: 609
        -- upvalues: Color3_fromRGB_ret5 (copy)
        p81.TextStrokeColor3 = Color3_fromRGB_ret5;
        p81.TextStrokeTransparency = 0.5;

        return p81;
    end;

    local Card = v78:FindFirstChild("Card");

    if Card then
        Card.BackgroundColor3 = Color3_fromRGB_ret;
        Card.BackgroundTransparency = 0;

        for _, descendant in ipairs(Card:GetDescendants()) do
            if descendant:IsA("UICorner") then
                descendant:Destroy();
            end;
        end;

        local v82 = Card:FindFirstChildOfClass("UIStroke");

        if v82 then
            v82:Destroy();
        end;

        local Header = Card:FindFirstChild("Header");

        if Header then
            for _, child in ipairs(Header:GetChildren()) do
                if child:IsA("TextLabel") then
                    child.Font = Arcade;
                    child.TextSize = 22;
                    child.TextColor3 = Color3_fromRGB_ret3;
                    child.Text = string.upper(child.Text);
                    child.TextStrokeColor3 = Color3_fromRGB_ret5;
                    child.TextStrokeTransparency = 0.5;
                elseif child:IsA("TextButton") and child.Name == "Close" then
                    child.Font = Enum.Font.Bangers;
                    child.TextSize = 24;
                    child.TextColor3 = Color3.fromRGB(220, 40, 40);
                    child.TextStrokeColor3 = Color3_fromRGB_ret5;
                    child.TextStrokeTransparency = 0.5;
                end;
            end;
        end;

        local ImageLabel = Instance.new("ImageLabel");
        ImageLabel.Name = "Portrait";
        ImageLabel.AnchorPoint = Vector2.new(1, 0.5);
        ImageLabel.Position = UDim2.new(-0.015, 0, 0.5, 0);
        ImageLabel.Size = UDim2.new(0.35, 0, 0.72, 0);
        ImageLabel.BackgroundTransparency = 1;
        ImageLabel.Image = "rbxassetid://85725203749860";
        ImageLabel.ScaleType = Enum.ScaleType.Fit;
        ImageLabel.Parent = Card;
        local UIAspectRatioConstraint = Instance.new("UIAspectRatioConstraint");
        UIAspectRatioConstraint.AspectRatio = 1;
        UIAspectRatioConstraint.Parent = ImageLabel;
        local TextLabel = Instance.new("TextLabel");
        TextLabel.Name = "NameLabel";
        TextLabel.Position = UDim2.new(0, 18, 0, -27);
        TextLabel.Size = UDim2.new(0, 240, 0, 26);
        TextLabel.BackgroundTransparency = 1;
        TextLabel.Font = Arcade;
        TextLabel.TextSize = 23;
        TextLabel.TextColor3 = Color3_fromRGB_ret3;
        TextLabel.TextXAlignment = Enum.TextXAlignment.Left;
        TextLabel.Text = "KAMI";
        TextLabel.TextStrokeColor3 = Color3_fromRGB_ret5;
        TextLabel.TextStrokeTransparency = 0.5;
        TextLabel.Parent = Card;
    end;

    local v83 = label(u79, "[ " .. p75 .. " ]", 14, u1.FONT, u1.SUB);
    v83.Position = UDim2.fromOffset(22, 10);
    v83.Size = UDim2.new(1, -44, 0, 60);
    v83.TextYAlignment = Enum.TextYAlignment.Top;
    v83.Font = Enum.Font.Bangers;
    v83.TextSize = 18;
    v83.TextColor3 = Color3_fromRGB_ret4;
    v83.TextStrokeColor3 = Color3_fromRGB_ret5;
    v83.TextStrokeTransparency = 0.5;

    local function choice(p84, p85, p86, u87) -- Line: 682
        -- upvalues: Color3_fromRGB_ret2 (copy), Arcade (copy), Color3_fromRGB_ret3 (copy), u79 (copy), Color3_fromRGB_ret5 (copy)
        local TextButton = Instance.new("TextButton");
        TextButton.AnchorPoint = Vector2.new(p86, 1);
        TextButton.Position = UDim2.new(p85, p86 == 0 and 22 or -22, 1, -22);
        TextButton.Size = UDim2.fromOffset(150, 34);
        TextButton.BackgroundColor3 = u87 and Color3.fromRGB(200, 60, 45) or Color3_fromRGB_ret2;
        TextButton.BackgroundTransparency = 0;
        TextButton.Font = Arcade;
        TextButton.Text = string.upper(p84);
        TextButton.TextSize = 19;
        TextButton.TextColor3 = Color3_fromRGB_ret3;
        TextButton.AutoButtonColor = false;
        TextButton.BorderSizePixel = 0;
        TextButton.Parent = u79;
        TextButton.TextStrokeColor3 = Color3_fromRGB_ret5;
        TextButton.TextStrokeTransparency = 0.5;
        local UIStroke = Instance.new("UIStroke");
        UIStroke.Color = Color3_fromRGB_ret5;
        UIStroke.Thickness = 2;
        UIStroke.Parent = TextButton;
        TextButton.MouseEnter:Connect(function() -- Line: 699
            -- upvalues: TextButton (copy), u87 (copy)
            TextButton.BackgroundColor3 = u87 and Color3.fromRGB(230, 80, 60) or Color3.fromRGB(48, 48, 52);
        end);
        TextButton.MouseLeave:Connect(function() -- Line: 702
            -- upvalues: TextButton (copy), u87 (copy), Color3_fromRGB_ret2 (ref)
            TextButton.BackgroundColor3 = u87 and Color3.fromRGB(200, 60, 45) or Color3_fromRGB_ret2;
        end);

        return TextButton;
    end;

    local v88 = choice("Cancel", 0, 0, false);
    local v89 = choice(p76, 1, 1, true);
    v88.MouseButton1Click:Connect(u80);
    v89.MouseButton1Click:Connect(function() -- Line: 714
        -- upvalues: u80 (copy), u77 (copy)
        u80();
        u77();
    end);
end;

local u90 = TopbarPlus.new():setImage(12122755689):setLabel("Menu", "Viewing"):setCaption("Menu");
u90.selected:Connect(function() -- Line: 724
    -- upvalues: u90 (copy), TopbarRemote (copy), confirmDialog (copy)
    u90:deselect();

    if game.PlaceId == 14170021060 or game:GetService("RunService"):IsStudio() then
        TopbarRemote:FireServer("Menu");

        return;
    end;

    confirmDialog("Leave to menu?", "You\'ll be taken out of this world and back to the character menu. Your progress is saved.", "Leave", function() -- Line: 737
        -- upvalues: TopbarRemote (ref)
        TopbarRemote:FireServer("Menu");
    end);
end);
local u91 = TopbarPlus.new():setImage(12905962634):setLabel("Controls", "Viewing"):setCaption("Controls");
u91.selected:Connect(function() -- Line: 745
    -- upvalues: buildControlsPanel (copy), u91 (copy)
    buildControlsPanel();
    u91:deselect();
end);
local u92 = TopbarPlus.new():setImage(12905962634):setLabel("Changes", "Viewing"):setCaption("What\'s new");
u92.selected:Connect(function() -- Line: 754
    -- upvalues: buildChangelogPanel (copy), u92 (copy)
    buildChangelogPanel();
    u92:deselect();
end);
TopbarPlus.new():setImage(136549712031956):setLabel("Faction Menu", "Viewing"):setCaption("Faction Menu").selected:Connect(function() -- Line: 764
    -- upvalues: LocalPlayer (copy), StatRetrieveRemote (copy), FactionRemote (copy)
    local FactionGuiV2 = LocalPlayer.PlayerGui:FindFirstChild("FactionGuiV2");

    if FactionGuiV2 then
        FactionGuiV2:Destroy();

        return;
    end;

    if StatRetrieveRemote:InvokeServer("Faction") == "None" then
        FactionRemote:InvokeServer("Show Faction List");

        return;
    end;

    FactionRemote:InvokeServer("View Faction");
end);

local function buildTutorialPanel() -- Line: 795
    -- upvalues: panel (copy), TutorialData (copy), pad (copy), u1 (copy), label (copy)
    local v93, v94 = panel("TopbarHowToPlay", "How to play", 560, 500);

    if not v93 then
        return;
    end;

    local u95 = 1;
    local u96 = #TutorialData;
    local ScrollingFrame = Instance.new("ScrollingFrame");
    ScrollingFrame.Size = UDim2.new(1, 0, 1, -52);
    ScrollingFrame.BackgroundTransparency = 1;
    ScrollingFrame.BorderSizePixel = 0;
    ScrollingFrame.ScrollBarThickness = 3;
    ScrollingFrame.ScrollBarImageColor3 = Color3.fromRGB(255, 255, 255);
    ScrollingFrame.ScrollBarImageTransparency = 0.7;
    ScrollingFrame.CanvasSize = UDim2.new();
    ScrollingFrame.AutomaticCanvasSize = Enum.AutomaticSize.Y;
    ScrollingFrame.Parent = v94;
    pad(ScrollingFrame, 18);
    local UIListLayout = Instance.new("UIListLayout");
    UIListLayout.FillDirection = Enum.FillDirection.Vertical;
    UIListLayout.SortOrder = Enum.SortOrder.LayoutOrder;
    UIListLayout.Padding = UDim.new(0, 12);
    UIListLayout.Parent = ScrollingFrame;
    local Frame = Instance.new("Frame");
    Frame.AnchorPoint = Vector2.new(0, 1);
    Frame.Position = UDim2.new(0, 0, 1, 0);
    Frame.Size = UDim2.new(1, 0, 0, 52);
    Frame.BackgroundTransparency = 1;
    Frame.Parent = v94;
    local Frame2 = Instance.new("Frame");
    Frame2.Size = UDim2.new(1, -40, 0, 1);
    Frame2.Position = UDim2.fromOffset(20, 0);
    Frame2.BackgroundColor3 = Color3.fromRGB(255, 255, 255);
    Frame2.BackgroundTransparency = 0.88;
    Frame2.BorderSizePixel = 0;
    Frame2.Parent = Frame;

    local function navButton(p97, p98, p99, p100) -- Line: 835
        -- upvalues: u1 (ref), Frame (copy)
        local TextButton = Instance.new("TextButton");
        TextButton.AnchorPoint = Vector2.new(p100, 0.5);
        TextButton.Position = UDim2.new(p98, p99, 0.5, 1);
        TextButton.Size = UDim2.fromOffset(96, 30);
        TextButton.BackgroundColor3 = Color3.fromRGB(255, 255, 255);
        TextButton.BackgroundTransparency = 0.92;
        TextButton.Font = u1.FONT_BOLD;
        TextButton.Text = p97;
        TextButton.TextSize = 13;
        TextButton.TextColor3 = u1.TEXT;
        TextButton.AutoButtonColor = false;
        TextButton.BorderSizePixel = 0;
        TextButton.Parent = Frame;
        local UICorner = Instance.new("UICorner");
        UICorner.CornerRadius = UDim.new(0, 8);
        UICorner.Parent = TextButton;
        TextButton.MouseEnter:Connect(function() -- Line: 850
            -- upvalues: TextButton (copy)
            TextButton.BackgroundTransparency = 0.85;
        end);
        TextButton.MouseLeave:Connect(function() -- Line: 851
            -- upvalues: TextButton (copy)
            TextButton.BackgroundTransparency = 0.92;
        end);

        return TextButton;
    end;

    local u101 = navButton("←  Back", 0, 20, 0);
    local u102 = navButton("Next  →", 1, -20, 1);
    local u103 = label(Frame, "", 12, u1.FONT, u1.DIM, Enum.TextXAlignment.Center);
    u103.AnchorPoint = Vector2.new(0.5, 0.5);
    u103.Position = UDim2.new(0.5, 0, 0.5, 1);
    u103.Size = UDim2.fromOffset(120, 20);
    u103.TextYAlignment = Enum.TextYAlignment.Center;

    local function renderPage() -- Line: 863
        -- upvalues: ScrollingFrame (copy), TutorialData (ref), u95 (ref), label (ref), u1 (ref), u103 (copy), u96 (copy), u101 (copy), u102 (copy)
        for _, child in ipairs(ScrollingFrame:GetChildren()) do
            if not (child:IsA("UIListLayout") or child:IsA("UIPadding")) then
                child:Destroy();
            end;
        end;

        local v104 = TutorialData[u95];

        if not v104 then
            return;
        end;

        local v105 = 0;

        if v104.Image then
            local ImageLabel = Instance.new("ImageLabel");
            ImageLabel.Size = UDim2.new(1, -6, 0, 210);
            ImageLabel.BackgroundColor3 = Color3.fromRGB(0, 0, 0);
            ImageLabel.BackgroundTransparency = 0.55;
            ImageLabel.BorderSizePixel = 0;
            ImageLabel.Image = v104.Image;
            ImageLabel.ScaleType = Enum.ScaleType.Fit;
            ImageLabel.LayoutOrder = v105;
            ImageLabel.Parent = ScrollingFrame;
            local UICorner = Instance.new("UICorner");
            UICorner.CornerRadius = UDim.new(0, 10);
            UICorner.Parent = ImageLabel;
            v105 = v105 + 1;
        end;

        local v106 = label(ScrollingFrame, v104.Title or "", 16, u1.FONT_BOLD, u1.TEXT);
        v106.Size = UDim2.new(1, -6, 0, 22);
        v106.LayoutOrder = v105;
        v106.TextYAlignment = Enum.TextYAlignment.Center;
        local v107 = label(ScrollingFrame, v104.Body or "", 14, u1.FONT, u1.SUB);
        v107.Size = UDim2.new(1, -6, 0, 0);
        v107.AutomaticSize = Enum.AutomaticSize.Y;
        v107.LayoutOrder = v105 + 1;
        v107.LineHeight = 1.35;
        u103.Text = ("%d / %d"):format(u95, u96);
        u101.TextTransparency = u95 > 1 and 0 or 0.6;
        u102.TextTransparency = u95 < u96 and 0 or 0.6;
        ScrollingFrame.CanvasPosition = Vector2.new(0, 0);
    end;

    u101.MouseButton1Click:Connect(function() -- Line: 907
        -- upvalues: u95 (ref), renderPage (copy)
        if u95 > 1 then
            u95 = u95 - 1;
            renderPage();
        end;
    end);
    u102.MouseButton1Click:Connect(function() -- Line: 910
        -- upvalues: u95 (ref), u96 (copy), renderPage (copy)
        if u95 < u96 then
            u95 = u95 + 1;
            renderPage();
        end;
    end);
    renderPage();
end;

local u108 = TopbarPlus.new():setImage(123779112028227):setLabel("How To Play", "Viewing"):setCaption("How to play");
u108.selected:Connect(function() -- Line: 921
    -- upvalues: buildTutorialPanel (copy), u108 (copy)
    buildTutorialPanel();
    u108:deselect();
end);