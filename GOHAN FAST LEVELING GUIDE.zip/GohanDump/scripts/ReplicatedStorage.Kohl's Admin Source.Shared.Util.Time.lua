-- Decompiled with Potassium's decompiler.

local u1 = {
    UNITS = table.freeze({ { 0.001, "millisecond" }, { 1, "second" }, { 60, "minute" }, { 3600, "hour", "hr" }, { 86400, "day" }, { 604800, "week", "wk" }, { 2592000, "month" }, { 31557600, "year", "yr" } })
};
u1.__index = u1;

function u1.fromUnit(p2: string) -- Line: 15
    -- upvalues: u1 (copy)
    local string_lower_ret = string.lower(p2);

    if string_lower_ret == "m" then
        return 60;
    end;

    if string_lower_ret == "mss" then
        return 0.001;
    end;

    if #string_lower_ret > 1 and string.find(string_lower_ret, "s$") then
        string_lower_ret = string.sub(string_lower_ret, 1, -2);
    end;

    for _, v in u1.UNITS do
        local v3 = v;

        for i = 2, #v do
            if string.find(v3[i], string_lower_ret) == 1 then
                return v3[1];
            end;

            local _ = i;
        end;
    end;
end;

function u1.clock(p4: number) -- Line: 36
    local math_floor_ret = math.floor(p4 / 3600);
    local math_floor_ret2 = math.floor(p4 % 3600 / 60);
    local math_floor_ret3 = math.floor(p4 % 60);

    if math_floor_ret > 0 then
        return string.format("%02d:%02d:%02d", math_floor_ret, math_floor_ret2, math_floor_ret3);
    end;

    if math_floor_ret2 > 0 then
        return string.format("%02d:%02d", math_floor_ret2, math_floor_ret3);
    end;

    return string.format("%02d", math_floor_ret3);
end;

function u1.readable(p5: number) -- Line: 50
    -- upvalues: u1 (copy)
    local v6 = {};

    for i = #u1.UNITS, 2, -1 do
        local v7, v8 = unpack(u1.UNITS[i]);
        local math_floor_ret = math.floor(p5 / v7);
        local v9;

        if math_floor_ret > 0 then
            p5 = p5 % v7;
            table.insert(v6, string.format("%s %s%s", math_floor_ret, v8, math_floor_ret > 1 and "s" or ""));
            v9 = i;
        else
            v9 = i;
        end;
    end;

    return table.concat(v6, ", ");
end;

return u1;