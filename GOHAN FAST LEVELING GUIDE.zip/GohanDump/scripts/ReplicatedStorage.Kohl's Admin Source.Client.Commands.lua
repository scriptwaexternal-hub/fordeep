-- Decompiled with Potassium's decompiler.

local UI = require(script.Parent:WaitForChild("UI"));
local v1 = {};
v1.__index = v1;

local function _argsString(p2) -- Line: 8
    if not p2.args or #p2.args == 0 then
        return "";
    end;

    local v3 = {};

    for _, v in p2.args do
        table.insert(v3, v.type);
    end;

    return " <" .. table.concat(v3, "> <") .. ">";
end;

function v1.new(u4) -- Line: 19
    -- upvalues: UI (copy)
    local escapeRichText = u4.Util.String.escapeRichText;

    local function createItem(p5, p6) -- Line: 22
        -- upvalues: UI (ref)
        local u7 = {
            command = UI.state(p6)
        };

        local function v8() -- Line: 27
            -- upvalues: u7 (copy), UI (ref)
            if u7.command().LocalPlayerAuthorized then
                return UI.Theme.PrimaryText();
            end;

            return UI.Theme.PrimaryText():Lerp(UI.Theme.Primary(), 0.5);
        end;

        local u9 = UI.new("Tooltip")({
            Text = "Loading..."
        });
        local v10 = { u9 };
        u7._instance = UI.new("TextLabel")({
            AutoLocalize = false,
            BackgroundTransparency = 1,
            Size = p5.ItemSize,
            RichText = true,
            FontFace = UI.Theme.Font,
            TextColor3 = v8,
            TextSize = UI.Theme.FontSize,
            TextStrokeColor3 = UI.Theme.Primary,
            TextStrokeTransparency = UI.Theme.TextStrokeTransparency,
            TextTruncate = Enum.TextTruncate.SplitWord,
            TextXAlignment = Enum.TextXAlignment.Left,
            TextYAlignment = Enum.TextYAlignment.Top,
            UI.new("TextLabel")({
                AutoLocalize = false,
                BackgroundTransparency = 1,
                Name = "Description",
                RichText = true,
                FontFace = UI.Theme.Font,
                TextColor3 = v8,
                TextSize = UI.Theme.FontSize,
                TextStrokeColor3 = UI.Theme.Primary,
                TextStrokeTransparency = UI.Theme.TextStrokeTransparency,
                TextTruncate = Enum.TextTruncate.SplitWord,
                TextXAlignment = Enum.TextXAlignment.Left,
                TextYAlignment = Enum.TextYAlignment.Top,

                Size = function() -- Line: 66, Name: Size
                    -- upvalues: UI (ref)
                    local v11 = UI.Theme.FontSize();

                    return UDim2.new(1, -v11, 0, v11);
                end,

                Position = function() -- Line: 70, Name: Position
                    -- upvalues: UI (ref)
                    local v12 = UI.Theme.FontSize();

                    return UDim2.new(0, v12, 0, v12);
                end
            }),
            u9,
            [UI.Clean] = v10
        });
        table.insert(v10, u9.Visible:Connect(function() -- Line: 82
            -- upvalues: u9 (copy), u7 (copy)
            if u9.Visible._value then
                u9.Text(u7.command._value.tipText);
            end;
        end));

        return u7;
    end;

    local u13 = {
        gamepass = nil,
        role = nil
    };
    local u14 = {};

    local function updatePurchaseData(p15) -- Line: 103
        -- upvalues: u14 (copy), u4 (copy)
        table.clear(u14);
        local v16 = nil;

        for i, v in p15 do
            local v17, v18;

            if v.RestrictedToRole then
                v17 = i;
                v18 = v;
            else
                v17 = i;
                v18 = v;

                for _, v2 in u4.Data.rolesList do
                    if u4.Auth.roleCanUseCommand(v2._key, v18) then
                        v18.RestrictedToRole = v2;
                        break;
                    end;
                end;
            end;

            if not v18.LocalPlayerAuthorized then
                local RestrictedToRole = v18.RestrictedToRole;

                if v16 and RestrictedToRole == v16 then
                    u14[v16].lastIndex = v17;
                end;

                if not v16 and (RestrictedToRole and (RestrictedToRole._key == "vip" or RestrictedToRole.gamepasses)) then
                    u14[RestrictedToRole] = {
                        firstIndex = v17 - 1,
                        lastIndex = v17
                    };
                    v16 = RestrictedToRole;
                end;
            end;
        end;
    end;

    local u19 = UI.new("Button")({
        Label = "Loading...",
        LayoutOrder = 9,
        Icon = "rbxasset://textures/ui/common/robux.png",
        IconProperties = {
            ImageColor3 = UI.Theme.PrimaryText
        },
        IconRightAlign = true,
        Padding = UI.Theme.PaddingDouble,
        TextSize = UI.Theme.FontSizeLarge,
        TextXAlignment = Enum.TextXAlignment.Left,

        Size = function() -- Line: 145, Name: Size
            -- upvalues: UI (ref)
            return UDim2.new(1, 0, 0, UI.Theme.FontSizeLarge() + UI.Theme.PaddingDouble().Offset);
        end,

        Visible = false,
        UI.new("TextLabel")({
            Name = "Price",
            LayoutOrder = 8,
            AutoLocalize = false,
            BackgroundTransparency = 1,
            TextWrapped = true,
            Text = "<b>?</b>",
            RichText = true,
            AutomaticSize = Enum.AutomaticSize.XY,
            FontFace = UI.Theme.FontMono,
            TextSize = UI.Theme.FontSizeLarge,
            TextColor3 = UI.Theme.PrimaryText,
            TextStrokeColor3 = UI.Theme.Primary,
            TextStrokeTransparency = UI.Theme.TextStrokeTransparency,

            Size = function() -- Line: 162, Name: Size
                -- upvalues: UI (ref)
                return UDim2.new(0, UI.Theme.FontSizeLarge(), 1, 0);
            end
        }),

        Activated = function() -- Line: 169, Name: Activated
            -- upvalues: u13 (copy), u4 (copy)
            if u13.role == "vip" and u4.Data.settings.vip then
                u4.PromptPurchaseVIP();

                return;
            end;

            if u13.gamepass then
                u4.Service.Marketplace:PromptGamePassPurchase(u4.LocalPlayer, u13.gamepass);
            end;
        end
    });

    local function updatePurchasePrice() -- Line: 178
        -- upvalues: u13 (copy), u4 (copy), u19 (copy)
        local success, result = pcall(function() -- Line: 179
            -- upvalues: u13 (ref), u4 (ref)
            local v20;

            if u13.role == "vip" and u4.Data.settings.vip then
                v20 = Enum.InfoType.Asset;
            else
                v20 = Enum.InfoType.GamePass;
            end;

            return u4.Service.Marketplace:GetProductInfoAsync(u13.gamepass, v20).PriceInRobux;
        end);
        u19._content.Price.Text = `<b>{success and result and result or "?"}</b>`;
    end;

    u19._content.Price.Text = "<b>799</b>";

    local function sortCommandsList(p21, p22) -- Line: 190
        -- upvalues: u4 (copy)
        local v23 = (1 / 0);
        local v24 = (1 / 0);

        for i, v in u4.Data.rolesList do
            if i < v23 then
                if u4.Auth.roleCanUseCommand(v._key, p21) then
                    v23 = i;
                end;
            end;

            if i < v24 and u4.Auth.roleCanUseCommand(v._key, p22) then
                v24 = i;
            end;
        end;

        if v23 == v24 then
            return p21.name < p22.name;
        end;

        return v23 < v24;
    end;

    local u25 = UI.state(u4.Registry.commandsList);
    local v29 = u4.Util.Function.debounce(0.2, function() -- Line: 208, Name: updateCommandsList
        -- upvalues: u4 (copy), sortCommandsList (copy), u25 (copy), updatePurchaseData (copy)
        local v26;

        if u4.client.settings.onlyShowUsableCommands._value then
            v26 = {};

            for _, v in u4.Registry.commandsList do
                local v27 = v;
                local v28 = nil;

                for i, v2 in u4.Data.roles do
                    if (v2.assets and next(v2.assets) or (v2.gamepasses and next(v2.gamepasses) or (v2.subscriptions and next(v2.subscriptions) or i == "vip" and u4.Data.settings.vip))) and u4.Auth.roleCanUseCommand(i, v27) then
                        table.insert(v26, v27);
                        v28 = true;
                        break;
                    end;
                end;

                if not v28 and u4.Auth.hasCommand(u4.LocalPlayer.UserId, v27) then
                    table.insert(v26, v27);
                end;
            end;
        else
            v26 = u4.Registry.commandsList;
        end;

        table.sort(v26, sortCommandsList);
        u25(v26);
        updatePurchaseData(v26);
    end);
    u4.client.settings.onlyShowUsableCommands:Connect(v29);
    u4.Hook.authChanged:Connect(v29);
    v29();
    local v33 = {
        Name = "Commands",
        List = u25,
        Enabled = false,
        FilterInput = true,
        Visible = false,

        ItemSize = function() -- Line: 251, Name: ItemSize
            -- upvalues: UI (ref)
            return UDim2.new(1, 0, 0, UI.Theme.FontSize * 2 + UI.Theme.Padding().Offset);
        end,

        CreateItem = createItem,

        RenderItem = function(p30, p31, p32) -- Line: 92, Name: renderItem
            if p32.renderText then
                local _instance = p31._instance;
                _instance.Text = p32.renderText;
                _instance.Description.Text = p32.renderDesc;
                p31.command(p32);
            end;
        end,

        u19
    };
    local u34 = UI.new("ScrollerFast")(v33);

    local function updatePurchaseButton() -- Line: 259
        -- upvalues: UI (ref), u34 (copy), u14 (copy), u4 (copy), u13 (copy), u19 (copy), updatePurchasePrice (copy)
        local v35 = UI.Theme.FontSize._value * 2;
        local Y = u34._scroller.AbsoluteWindowSize.Y;
        local Y2 = u34._scroller.CanvasPosition.Y;
        local v36 = Y2 + Y / 2;
        local v37 = Y2 + Y;
        local v38 = nil;

        for i, v in u14 do
            if v.firstIndex * v35 < v37 and v36 < v.lastIndex * v35 then
                v38 = i;
            end;
        end;

        if not (v38 and (v38._key == "vip" and u4.Data.settings.vip or v38.gamepasses)) then
            u19._instance.Visible = false;

            return;
        end;

        u13.role = v38._key;
        u13.gamepass = v38._key == "vip" and u4.Data.settings.vip and 110019084552349 or v38.gamepasses[1];

        if not u13.gamepass then
            return;
        end;

        u19.Label((`<b>Unlock <font color="{v38.color}">{v38.name or v38._key}</font> Commands</b>`));
        u19._instance.Visible = true;
        task.spawn(updatePurchasePrice);
    end;

    u4.Hook.authChanged:Connect(updatePurchaseButton);
    UI.Theme.FontSize:Connect(updatePurchaseButton);
    u34._scroller:GetPropertyChangedSignal("CanvasPosition"):Connect(updatePurchaseButton);

    local function updateRenderParameters(p39) -- Line: 296
        -- upvalues: u4 (copy), UI (ref), escapeRichText (copy)
        if not p39.aliasText then
            p39.aliasText = (not p39.aliases or #p39.aliases == 0) and "" or table.concat(p39.aliases, ", ");
            p39.argNames = table.create(#p39.args);
            p39.argTooltip = table.create(#p39.args);

            if #p39.args > 0 then
                table.insert(p39.argTooltip, "");
            end;

            for _, v in p39.args do
                local v40;

                if v.optional then
                    v40 = v.name .. "?";
                else
                    v40 = v.name;
                end;

                table.insert(p39.argNames, v40);
                local argTooltip = p39.argTooltip;
                local v41 = `\n<b><sc>{v.name}</sc> <font transparency="0.66"><i>&lt;{v.type}{v.optional and "?" or ""}&gt;</i></font></b>\n{v.description or "No description."}`;
                table.insert(argTooltip, v41);

                if v.ignoreSelf then
                    table.insert(p39.argTooltip, "\t<font transparency=\"0.5\"><b>ignoreSelf:</b> true</font>");
                end;

                if v.lowerRank then
                    table.insert(p39.argTooltip, "\t<font transparency=\"0.5\"><b>lowerRank:</b> true</font>");
                end;

                if v.shouldRequest and u4.Data.settings.commandRequests ~= false then
                    table.insert(p39.argTooltip, "\t<font transparency=\"0.5\"><b>shouldRequest:</b> true</font>");
                end;
            end;

            p39.argNames = table.concat(p39.argNames, " ");
            p39.argTooltip = table.concat(p39.argTooltip, "\n");
            local v42 = {};

            for i, _ in u4.Data.roles do
                if u4.Auth.roleCanUseCommand(i, p39) then
                    table.insert(v42, i);
                end;
            end;

            table.sort(v42, function(p43, p44) -- Line: 338
                -- upvalues: u4 (ref)
                return u4.Data.roles[p43]._rank < u4.Data.roles[p44]._rank;
            end);
            local v45;

            if #v42 > 0 then
                v45 = u4.Data.roles[v42[1]].color;
            else
                v45 = UI.Theme.Primary._value:ToHex();
            end;

            local v46 = `<font color="{v45}">●</font> `;
            p39.roleCircle = v46;

            for i, v in v42 do
                local v47 = u4.Data.roles[v];
                v42[i] = `<font color="{v47.color}">●</font> {string.gsub(v47.name, " ", " ")}`;
            end;

            p39.roleText = table.concat(v42, ", ");
            local v48 = p39.credit or "Kohl @Scripth";
            local v49 = p39.description or "No description.";

            if type(v48) == "table" then
                v48 = table.concat(v48, ", ");
            end;

            p39.creditText = v48;
            p39.tipText = `<b>Restricted to:</b> {p39.roleText}{p39.argTooltip}\n\n<font transparency="0.5"><b>Credit:</b> {p39.creditText}</font>`;
            p39.rawTextNoAlias = `{u4.getCommandPrefix()}{p39.name} {p39.argNames}`;
            p39.rawText = `{p39.rawTextNoAlias} {p39.aliasText}`;
            p39.richText = `{v46}<b>{escapeRichText(p39.rawTextNoAlias)}</b> <font transparency="0.66">{escapeRichText(p39.aliasText)}</font>`;
            p39.richDesc = `<font transparency="0.33">{v49}</font>`;
            p39.filterTest = string.lower((`{p39.rawText} {v49}`));
            p39.filterText = string.lower(p39.rawText);
            p39.filterDesc = string.lower(v49);
        end;

        local v50;

        if p39.LocalPlayerAuthorized then
            v50 = UI.Theme.PrimaryText._value;
        else
            v50 = UI.Theme.PrimaryText._value:Lerp(UI.Theme.Primary._value, 0.5);
        end;

        p39.colorAuth = v50;
    end;

    local function filterTest(p51, p52) -- Line: 382
        -- upvalues: u34 (copy), updateRenderParameters (copy), escapeRichText (copy)
        local string_lower_ret = string.lower(u34._input._input.Text);
        p51._filter = string_lower_ret;
        local string_find_ret = string.find(p51._filter, "^%s*$");
        local v53 = {};

        if string.find(string_lower_ret, "role=", 1, true) ~= 1 then
            for _, v in p52 do
                updateRenderParameters(v);

                if string_find_ret then
                    v.renderText = v.richText;
                    v.renderDesc = v.richDesc;
                    table.insert(v53, v);
                elseif string.find(v.filterTest, string_lower_ret, 1, true) then
                    local string_find_ret2 = string.find(v.filterText, p51._filter, 1, true);
                    local v54;

                    if string_find_ret2 then
                        v54 = v.roleCircle .. string.format("<font transparency=\"0.5\">%s</font><b>%s</b><font transparency=\"0.5\">%s</font>", escapeRichText((string.sub(v.rawText, 1, string_find_ret2 - 1))), escapeRichText((string.sub(v.rawText, string_find_ret2, string_find_ret2 + #p51._filter - 1))), escapeRichText((string.sub(v.rawText, string_find_ret2 + #p51._filter))));
                    else
                        v54 = `{v.roleCircle}<font transparency="0.5">{v.rawText}</font>`;
                    end;

                    v.renderText = v54;
                    local v55 = v.description or "No description.";
                    local string_find_ret3 = string.find(v.filterDesc, p51._filter, 1, true);
                    local v56;

                    if string_find_ret3 then
                        v56 = string.format("<font transparency=\"0.5\">%s</font><b>%s</b><font transparency=\"0.5\">%s</font>", escapeRichText((string.sub(v55, 1, string_find_ret3 - 1))), escapeRichText((string.sub(v55, string_find_ret3, string_find_ret3 + #p51._filter - 1))), escapeRichText((string.sub(v55, string_find_ret3 + #p51._filter))));
                    else
                        v56 = `<font transparency="0.5">{v55}</font>`;
                    end;

                    v.renderDesc = v56;
                    table.insert(v53, v);
                end;
            end;

            return v53;
        end;

        local string_sub_ret = string.sub(string_lower_ret, 6);

        for _, v in p52 do
            updateRenderParameters(v);

            if string.find(string.lower(v.roleText), string_sub_ret, 1, true) then
                v.renderText = v.richText;
                v.renderDesc = v.richDesc;
                table.insert(v53, v);
            end;
        end;

        return v53;
    end;

    task.defer(function() -- Line: 442
        -- upvalues: u34 (copy), filterTest (copy)
        u34:filter(filterTest);
    end);

    return u34;
end;

return v1;