-- Decompiled with Potassium's decompiler.

local Players = game:GetService("Players");
local ReplicatedStorage = game:GetService("ReplicatedStorage");
local Remotes = ReplicatedStorage:WaitForChild("Remotes");
local SkillData = require(ReplicatedStorage.Modules.Metadata.SkillData.SkillData);
local LocalPlayer = Players.LocalPlayer;
local Gui = ReplicatedStorage.Assets.Gui;
local SkillRemote = Remotes.SkillRemote;
local u1 = false;
local u2 = false;
local u3 = {};

local function clearConnections() -- Line: 33
    -- upvalues: u3 (copy)
    for _, v in pairs(u3) do
        v:Disconnect();
    end;

    table.clear(u3);
end;

local function updateButton(p4, p5, p6, p7) -- Line: 40
    -- upvalues: u2 (ref), u1 (ref)
    p4.Text = tostring(p5);

    if p5 then
        p4.BackgroundColor3 = Color3.fromRGB(61, 204, 73);
        p4.TextColor3 = Color3.fromRGB(255, 255, 255);

        if p7 then
            p6.BackgroundColor3 = Color3.fromRGB(132, 132, 132);
            p6.TextColor3 = Color3.fromRGB(255, 255, 255);
            p6.Text = tostring(false);

            if p6.Name == "Porunga" then
                u2 = false;

                return;
            end;

            u1 = false;
        end;
    else
        p4.BackgroundColor3 = Color3.fromRGB(132, 132, 132);
        p4.TextColor3 = Color3.fromRGB(255, 255, 255);
    end;
end;

return {
    OnEquipped = function(p8, p9) -- Line: 68, Name: OnEquipped
        -- upvalues: u1 (ref), u2 (ref), u3 (copy), LocalPlayer (copy), Gui (copy), updateButton (copy)
        u1 = false;
        u2 = false;

        for _, v in pairs(u3) do
            v:Disconnect();
        end;

        table.clear(u3);
        local PopupGui = LocalPlayer.PlayerGui.PopupGui;
        local v10 = Gui.Skills.RaceSkills.Namekian["Dragonball Creation"].DragonCreationFrame:Clone();
        v10.Parent = PopupGui;
        local Shenron = v10.Shenron;
        local Porunga = v10.Porunga;
        table.insert(u3, Shenron.MouseButton1Up:Connect(function() -- Line: 80
            -- upvalues: u1 (ref), updateButton (ref), Shenron (copy), Porunga (copy), u2 (ref)
            u1 = not u1;
            updateButton(Shenron, u1, Porunga, u2);
        end));
        table.insert(u3, Porunga.MouseButton1Up:Connect(function() -- Line: 85
            -- upvalues: u2 (ref), updateButton (ref), Porunga (copy), Shenron (copy), u1 (ref)
            u2 = not u2;
            updateButton(Porunga, u2, Shenron, u1);
        end));
    end,

    OnUnequipped = function(p11, p12) -- Line: 91, Name: OnUnequipped
        -- upvalues: u3 (copy), LocalPlayer (copy)
        for _, v in pairs(u3) do
            v:Disconnect();
        end;

        table.clear(u3);

        for _, child in pairs(LocalPlayer.PlayerGui.PopupGui:GetChildren()) do
            if child.Name == "DragonCreationFrame" then
                child:Destroy();
            end;
        end;
    end,

    OnActivated = function(p13, p14) -- Line: 106, Name: OnActivated
        -- upvalues: SkillData (copy), SkillRemote (copy), u1 (ref), u2 (ref)
        local Race = SkillData.GetRace("Namekian", "Dragonball Creation");

        if Race then
            Race = Race.KiCost;
        end;

        return true, SkillRemote:InvokeServer({
            Module = "SkillHandler",
            SkillModule = "Dragonball Creation",
            Action = "QuickFire",
            Attack_Name = "Dragonball Creation",
            Attack_Type = "Race Skills",
            Race_Type = "Namekian",
            Cancelable = true,
            KiCost = Race,
            CreationSettings = {
                Shenron = u1,
                Porunga = u2
            }
        });
    end
};