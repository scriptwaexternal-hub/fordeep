-- Decompiled with Potassium's decompiler.

local TweenService = game:GetService("TweenService");
local TextService = game:GetService("TextService");
local LocalPlayer = game:GetService("Players").LocalPlayer;
local u1 = nil;
local u2 = nil;
local u3 = nil;
local u4 = {};
local u5 = false;

local function ensureGui() -- Line: 33
    -- upvalues: u1 (ref), LocalPlayer (copy), u2 (ref), u3 (ref)
    if u1 and u1.Parent then
        return;
    end;

    u1 = Instance.new("ScreenGui");
    u1.Name = "EventTickerGui";
    u1.ResetOnSpawn = false;
    u1.DisplayOrder = 50;
    u1.Parent = LocalPlayer:WaitForChild("PlayerGui");
    u2 = Instance.new("Frame");
    u2.Name = "Strip";
    u2.Position = UDim2.new(0, 0, 0.16, 0);
    u2.Size = UDim2.new(1, 0, 0, 46);
    u2.BackgroundColor3 = Color3.new(0, 0, 0);
    u2.BackgroundTransparency = 1;
    u2.BorderSizePixel = 0;
    u2.ClipsDescendants = true;
    u2.Visible = false;
    u2.Parent = u1;
    u3 = Instance.new("TextLabel");
    u3.Name = "Text";
    u3.BackgroundTransparency = 1;
    u3.Font = Enum.Font.Bangers;
    u3.TextSize = 30;
    u3.TextColor3 = Color3.fromRGB(255, 170, 40);
    u3.TextStrokeColor3 = Color3.new(0, 0, 0);
    u3.TextStrokeTransparency = 0;
    u3.TextXAlignment = Enum.TextXAlignment.Left;
    u3.Size = UDim2.new(0, 100, 1, 0);
    u3.Parent = u2;
end;

local function playNext() -- Line: 66
    -- upvalues: u4 (copy), u5 (ref), ensureGui (copy), u2 (ref), TextService (copy), u3 (ref), TweenService (copy), playNext (copy)
    local table_remove_ret = table.remove(u4, 1);

    if not table_remove_ret then
        u5 = false;

        return;
    end;

    u5 = true;
    ensureGui();
    local X = u2.AbsoluteSize.X;

    if X <= 0 then
        local workspace_CurrentCamera = workspace.CurrentCamera;
        X = workspace_CurrentCamera and workspace_CurrentCamera.ViewportSize.X or 800;
    end;

    local v6 = TextService:GetTextSize(table_remove_ret, 30, u3.Font, Vector2.new(100000, 46)).X + 12;
    u3.Text = table_remove_ret;
    u3.Size = UDim2.new(0, v6, 1, 0);
    u3.Position = UDim2.new(0, X, 0, 0);
    u2.Visible = true;
    TweenService:Create(u2, TweenInfo.new(0.35), {
        BackgroundTransparency = 0.45
    }):Play();
    local v7 = TweenService:Create(u3, TweenInfo.new((X + v6) / 240, Enum.EasingStyle.Linear), {
        Position = UDim2.new(0, -v6, 0, 0)
    });
    v7.Completed:Once(function() -- Line: 97
        -- upvalues: TweenService (ref), u2 (ref), playNext (ref)
        local v8 = TweenService:Create(u2, TweenInfo.new(0.35), {
            BackgroundTransparency = 1
        });
        v8.Completed:Once(function() -- Line: 99
            -- upvalues: u2 (ref), playNext (ref)
            u2.Visible = false;
            task.defer(playNext);
        end);
        v8:Play();
    end);
    v7:Play();
end;

return {
    Show = function(p9) -- Line: 110, Name: Show
        -- upvalues: u4 (copy), u5 (ref), playNext (copy)
        local v10 = tostring(p9 and p9.Text or "");

        if v10 == "" then
            return;
        end;

        table.insert(u4, v10);

        if not u5 then
            u5 = true;
            task.spawn(playNext);
        end;
    end
};