-- Decompiled with Potassium's decompiler.

local Players = game:GetService("Players");
local generateValidate = require(script.Parent.Parent:WaitForChild("generateValidate"));

local function othersParse(p1, p2) -- Line: 5
    -- upvalues: Players (copy)
    local v3 = {};
    local v4 = {};

    for _, v in Players:GetPlayers() do
        if v ~= p2.command.fromPlayer then
            local v5, v6 = p2._K.Auth.targetUserArgument(p2, v.UserId, v);

            if v5 then
                table.insert(v3, v5);
            elseif not table.find(v4, v6) then
                table.insert(v4, v6);
            end;
        end;
    end;

    if #v3 > 0 then
        return v3;
    end;

    if #Players:GetPlayers() == 1 then
        return nil, "No other players online";
    end;

    return nil, table.concat(v4, "\n") or "No targetable player found";
end;

local u7 = {
    listable = true,
    transform = string.lower,
    validate = generateValidate(othersParse),
    parse = othersParse
};

return function(p8) -- Line: 37
    -- upvalues: u7 (copy)
    p8.Registry.registerType("otherPlayers", u7);
end;