-- Decompiled with Potassium's decompiler.

local Debris = game:GetService("Debris");
local ReplicatedStorage = game:GetService("ReplicatedStorage");
local UserInputService = game:GetService("UserInputService");
local Players = game:GetService("Players");
local Modules = ReplicatedStorage:WaitForChild("Modules");
local Remotes = ReplicatedStorage:WaitForChild("Remotes");
local Metadata = Modules.Metadata;
local Shared = Modules.Shared;
local _ = Modules.Utility;
local _ = ReplicatedStorage.Assets;
require(Metadata.CharacterData.SkillTreeData);
local ControlData = require(Metadata.ControlData.ControlData);
require(Shared.SoundManager);
local GlobalFunctions = require(Modules.GlobalFunctions);
local Platform = require(Shared.Platform);

local function graphicsQuality() -- Line: 25
    local GraphicsQuality = Player.PlayerScripts:FindFirstChild("GraphicsQuality", true);

    return GraphicsQuality and require(GraphicsQuality) or nil;
end;

local LocalPlayer = Players.LocalPlayer;
local u1 = script:FindFirstAncestor("MenuGui")["Menu Frame"];
local Buttons = u1.Buttons;
local Sliders = u1.Sliders;
local _ = u1.Labels;
local SettingsRemote = Remotes.SettingsRemote;
local StatRetrieveRemote = ReplicatedStorage.Remotes.StatRetrieveRemote;
local u2 = false;
local u3 = {};
local _ = {
    Music = function() -- Line: 60
    end,

    Monetization = function() -- Line: 63
    end,

    Settings = function() -- Line: 67
    end
};

function Destroy_Connections()
    -- upvalues: u3 (copy)
    for _, v in pairs(u3) do
        v:Disconnect();
    end;
end;

function Open_Menu()
    -- upvalues: u2 (ref), u1 (copy), GlobalFunctions (copy), Buttons (copy), StatRetrieveRemote (copy), Platform (copy), SettingsRemote (copy), ControlData (copy), LocalPlayer (copy), Sliders (copy), ReplicatedStorage (copy), UserInputService (copy), u3 (copy)
    u2 = true;
    u1.Position = UDim2.new(0.5, 0, 0.5, 0);
    u1.Size = UDim2.new(0.55, 0, 0.579, 0);
    local UIScale = u1:FindFirstChild("UIScale");

    if UIScale then
        UIScale.Scale = 0.7;
    end;

    u1.Visible = true;

    if UIScale then
        GlobalFunctions.Tween({
            Duration = 0.35,
            Instance = UIScale,
            Style = Enum.EasingStyle.Back,
            Direction = Enum.EasingDirection.Out
        }, {
            Scale = 1
        });
    end;

    local BlurEffect = Instance.new("BlurEffect", game.Lighting);
    BlurEffect.Size = 0;
    BlurEffect.Name = "UIBlur";
    GlobalFunctions.Tween({
        Duration = 1,
        Instance = BlurEffect
    }, {
        Size = 24
    });

    local function SetupButtons() -- Line: 101
        -- upvalues: Buttons (ref), StatRetrieveRemote (ref), Platform (ref), SettingsRemote (ref), ControlData (ref)
        for _, child in pairs(Buttons:GetChildren()) do
            local Name = child.Name;
            local On = child:FindFirstChild("On", true);
            local Off = child:FindFirstChild("Off", true);

            if On and Off then
                local v4 = StatRetrieveRemote:InvokeServer(Name);

                if Name == "LowGraphics" and StatRetrieveRemote:InvokeServer("GraphicsChosen") ~= true then
                    v4 = Platform.IsTouch();
                end;

                if v4 == true then
                    On.OnImage.Visible = true;
                else
                    Off.OnImage.Visible = true;
                end;

                On.MouseButton1Up:Connect(function() -- Line: 128
                    -- upvalues: SettingsRemote (ref), Name (copy), ControlData (ref), On (copy), Off (copy)
                    SettingsRemote:FireServer({
                        NewValue = true,
                        Action = Name
                    });

                    if Name == "ToggleRun" then
                        ControlData.Controls.Run.ToggleMode = true;
                    end;

                    if Name == "LowGraphics" then
                        local GraphicsQuality = Player.PlayerScripts:FindFirstChild("GraphicsQuality", true);
                        local v5 = GraphicsQuality and require(GraphicsQuality) or nil;

                        if v5 then
                            v5.Set(true);
                        end;
                    end;

                    On.OnImage.Visible = true;
                    Off.OnImage.Visible = false;
                end);
                Off.MouseButton1Up:Connect(function() -- Line: 142
                    -- upvalues: SettingsRemote (ref), Name (copy), ControlData (ref), Off (copy), On (copy)
                    SettingsRemote:FireServer({
                        NewValue = false,
                        Action = Name
                    });

                    if Name == "ToggleRun" then
                        ControlData.Controls.Run.ToggleMode = false;
                    end;

                    if Name == "LowGraphics" then
                        local GraphicsQuality = Player.PlayerScripts:FindFirstChild("GraphicsQuality", true);
                        local v6 = GraphicsQuality and require(GraphicsQuality) or nil;

                        if v6 then
                            v6.Set(false);
                        end;
                    end;

                    Off.OnImage.Visible = true;
                    On.OnImage.Visible = false;
                end);
            end;
        end;
    end;

    local function SetupSliders() -- Line: 159
        -- upvalues: LocalPlayer (ref), Sliders (ref), StatRetrieveRemote (ref), SettingsRemote (ref)
        local MusicManager = LocalPlayer.PlayerScripts:FindFirstChild("MusicManager", true);

        for _, child in pairs(Sliders:GetChildren()) do
            local Name = child.Name;
            local u7 = child[Name .. " Slider"];
            local Slider = u7.Slider;
            local UIDragDetector = Slider.UIDragDetector;
            local v8 = StatRetrieveRemote:InvokeServer(Name);
            local Fill = u7:FindFirstChild("Fill");
            local Percent = child:FindFirstChild("Percent");

            local function paint(p9) -- Line: 171
                -- upvalues: Fill (copy), Percent (copy)
                if Fill then
                    Fill.Size = UDim2.fromScale(p9 / 100, 1);
                end;

                if Percent then
                    Percent.Text = tostring(p9) .. "%";
                end;
            end;

            local v10 = tonumber(v8) or 0;
            local math_round_ret = math.round(v10);
            local math_clamp_ret = math.clamp(math_round_ret, 0, 100);

            if Fill then
                Fill.Size = UDim2.fromScale(math_clamp_ret / 100, 1);
            end;

            if Percent then
                Percent.Text = tostring(math_clamp_ret) .. "%";
            end;

            Slider.Position = UDim2.new(v8 / 100, 0, 0.5, 0);
            UIDragDetector.DragContinue:Connect(function() -- Line: 180
                -- upvalues: Slider (copy), u7 (copy), Fill (copy), Percent (copy)
                local v11 = (Slider.AbsolutePosition.X + Slider.AbsoluteSize.X / 2 - u7.AbsolutePosition.X) / math.max(1, u7.AbsoluteSize.X) * 100;
                local math_round_ret2 = math.round(v11);
                local math_clamp_ret2 = math.clamp(math_round_ret2, 0, 100);

                if Fill then
                    Fill.Size = UDim2.fromScale(math_clamp_ret2 / 100, 1);
                end;

                if Percent then
                    Percent.Text = tostring(math_clamp_ret2) .. "%";
                end;
            end);
            UIDragDetector.DragEnd:Connect(function() -- Line: 185
                -- upvalues: Slider (copy), u7 (copy), Fill (copy), Percent (copy), SettingsRemote (ref), Name (copy), MusicManager (copy)
                local v12 = (Slider.AbsolutePosition.X + Slider.AbsoluteSize.X / 2 - u7.AbsolutePosition.X) / math.max(1, u7.AbsoluteSize.X) * 100;
                local math_round_ret2 = math.round(v12);
                local math_clamp_ret2 = math.clamp(math_round_ret2, 0, 100);
                Slider.Position = UDim2.new(math_clamp_ret2 / 100, 0, 0.5, 0);

                if Fill then
                    Fill.Size = UDim2.fromScale(math_clamp_ret2 / 100, 1);
                end;

                if Percent then
                    Percent.Text = tostring(math_clamp_ret2) .. "%";
                end;

                SettingsRemote:FireServer({
                    Action = Name,
                    Volume = math_clamp_ret2
                });

                if MusicManager then
                    MusicManager.Volume.Value = math_clamp_ret2;
                end;
            end);
        end;
    end;

    local GamepadGlyphs = require(ReplicatedStorage.Modules.Shared.GamepadGlyphs);
    local u13 = { { "Combat", "Dash" }, { "Combat", "Evade" }, { "Combat", "Block" }, { "Combat", "Charge" }, { "Combat", "Ki Blast" }, { "Combat", "Run" }, { "Combat", "Transform" }, { "Combat", "DeTransform" }, { "Combat", "Follow Up" }, { "Combat", "Ki Sense" }, { "Combat", "Carry" }, { "Combat", "Grip" }, { "Combat", "Loot" }, { "CoreControls", "Meditate" }, { "CoreControls", "Inventory" }, { "CoreControls", "Emotes" }, { "CoreControls", "Shift Lock" }, { "UI", "Skill Tree" }, { "UI", "Transformations" }, { "Menu_UI", "Menu" } };
    local u14 = {
        DeCharge = "ButtonL2"
    };
    local u15 = {
        ButtonA = true,
        ButtonB = true,
        ButtonX = true,
        ButtonY = true,
        ButtonL1 = true,
        ButtonR1 = true,
        ButtonL2 = true,
        ButtonR2 = true,
        ButtonL3 = true,
        ButtonR3 = true,
        DPadUp = true,
        DPadDown = true,
        DPadLeft = true,
        DPadRight = true,
        Thumbstick1 = true,
        Thumbstick2 = true
    };
    local u16 = nil;

    local function SetupKeybinds() -- Line: 250
        -- upvalues: u1 (ref), u16 (ref), UserInputService (ref), Platform (ref), u15 (copy), LocalPlayer (ref), GamepadGlyphs (copy), SettingsRemote (ref), u3 (ref), u13 (copy), ControlData (ref), u14 (copy), SetupKeybinds (copy)
        local Keybinds = u1:FindFirstChild("Keybinds");

        if not Keybinds then
            return;
        end;

        for _, child in ipairs(Keybinds:GetChildren()) do
            if child:IsA("Frame") then
                child:Destroy();
            end;
        end;

        local function capture(u17, u18, u19, u20, u21) -- Line: 316
            -- upvalues: u16 (ref), UserInputService (ref), Platform (ref), u15 (ref), LocalPlayer (ref), GamepadGlyphs (ref), SettingsRemote (ref), u3 (ref)
            if u16 then
                return;
            end;

            u16 = true;
            local Text = u17.Text;
            u17.Text = u20 == 1 and "press key…" or "press button…";
            local u22 = nil;
            u22 = UserInputService.InputBegan:Connect(function(p23, p24) -- Line: 322
                -- upvalues: Platform (ref), u20 (copy), u22 (ref), u16 (ref), u17 (copy), Text (copy), u15 (ref), u21 (copy), u18 (copy), u19 (copy), LocalPlayer (ref), GamepadGlyphs (ref), SettingsRemote (ref)
                if p24 then
                    return;
                end;

                local v25 = Platform.IsGamepadInput(p23.UserInputType);

                if u20 == 1 and p23.UserInputType ~= Enum.UserInputType.Keyboard then
                    return;
                end;

                if u20 == 2 and not v25 then
                    return;
                end;

                local Name = p23.KeyCode.Name;

                if p23.KeyCode == Enum.KeyCode.Escape or u20 == 2 and Name == "ButtonB" then
                    u22:Disconnect();
                    u16 = nil;
                    u17.Text = Text;

                    return;
                end;

                if u20 == 2 and not u15[Name] then
                    return;
                end;

                u22:Disconnect();
                u16 = nil;
                u21[u20] = Name;

                if u20 == 1 and (u18 == "CoreControls" and u19 == "Shift Lock") then
                    LocalPlayer:SetAttribute("ShiftLockKey", Name);
                end;

                u17.Text = GamepadGlyphs.Label(Name);
                SettingsRemote:FireServer({
                    Action = "Keybind",
                    BindCategory = u18,
                    BindAction = u19,
                    NewKey = Name,
                    IsGamepad = u20 == 2
                });
            end);
            table.insert(u3, u22);
        end;

        local function makeRow(p26, p27) -- Line: 257
            -- upvalues: Keybinds (copy)
            local Frame = Instance.new("Frame");
            Frame.Size = UDim2.new(1, 0, 0, 24);
            Frame.BackgroundTransparency = 1;
            Frame.LayoutOrder = p26;
            Frame.Parent = Keybinds;
            local TextLabel = Instance.new("TextLabel");
            TextLabel.Size = UDim2.new(0.44, 0, 1, 0);
            TextLabel.BackgroundTransparency = 1;
            TextLabel.Text = p27;
            TextLabel.TextColor3 = Color3.fromRGB(216, 213, 205);
            TextLabel.TextSize = 14;
            TextLabel.Font = Enum.Font.Bangers;
            TextLabel.TextStrokeColor3 = Color3.fromRGB(0, 0, 0);
            TextLabel.TextStrokeTransparency = 0.5;
            TextLabel.TextTruncate = Enum.TextTruncate.AtEnd;
            TextLabel.TextXAlignment = Enum.TextXAlignment.Left;
            TextLabel.Parent = Frame;

            return Frame;
        end;

        local function makeKeyButton(p28, p29, p30, p31, u32) -- Line: 280
            local TextButton = Instance.new("TextButton");
            TextButton.AnchorPoint = Vector2.new(1, 0);
            TextButton.Position = UDim2.new(p29 == 1 and 0.74 or 1, 0, 0, 0);
            TextButton.Size = UDim2.new(0.27, -3, 1, 0);
            TextButton.BackgroundColor3 = p31 and Color3.fromRGB(44, 44, 45) or Color3.fromRGB(28, 28, 30);
            TextButton.Text = p30;
            TextButton.TextColor3 = p31 and Color3.fromRGB(255, 255, 255) or Color3.fromRGB(150, 150, 150);
            TextButton.TextSize = 11;
            TextButton.Font = Enum.Font.Arcade;
            TextButton.TextStrokeColor3 = Color3.fromRGB(0, 0, 0);
            TextButton.TextStrokeTransparency = 0.5;
            TextButton.TextTruncate = Enum.TextTruncate.AtEnd;
            TextButton.BorderSizePixel = 0;
            TextButton.AutoButtonColor = p31;
            TextButton.Parent = p28;
            local UIStroke = Instance.new("UIStroke");
            UIStroke.Color = Color3.fromRGB(0, 0, 0);
            UIStroke.Thickness = 1.5;
            UIStroke.ApplyStrokeMode = Enum.ApplyStrokeMode.Border;
            UIStroke.Parent = TextButton;

            if p31 then
                TextButton.MouseButton1Up:Connect(function() -- Line: 303
                    -- upvalues: u32 (copy), TextButton (copy)
                    u32(TextButton);
                end);
            end;

            return TextButton;
        end;

        for i, v in ipairs(u13) do
            local u33 = v[1];
            local u34 = v[2];
            local u35 = ControlData.Controls[u33] and ControlData.Controls[u33][u34];

            if type(u35) == "table" then
                local v36 = makeRow(i, u34);
                makeKeyButton(v36, 1, GamepadGlyphs.Label((tostring(u35[1]))), true, function(u37) -- Line: 362
                    -- upvalues: u33 (copy), u34 (copy), u35 (copy), u16 (ref), UserInputService (ref), Platform (ref), u15 (ref), LocalPlayer (ref), GamepadGlyphs (ref), SettingsRemote (ref), u3 (ref)
                    local u38 = u33;
                    local u39 = u34;
                    local u40 = u35;

                    if u16 then
                        return;
                    end;

                    u16 = true;
                    local Text = u37.Text;
                    u37.Text = "press key…";
                    local u41 = nil;
                    local u42 = 1;
                    u41 = UserInputService.InputBegan:Connect(function(p43, p44) -- Line: 322
                        -- upvalues: Platform (ref), u42 (copy), u41 (ref), u16 (ref), u37 (copy), Text (copy), u15 (ref), u40 (copy), u38 (copy), u39 (copy), LocalPlayer (ref), GamepadGlyphs (ref), SettingsRemote (ref)
                        if p44 then
                            return;
                        end;

                        local v45 = Platform.IsGamepadInput(p43.UserInputType);

                        if u42 == 1 and p43.UserInputType ~= Enum.UserInputType.Keyboard then
                            return;
                        end;

                        if u42 == 2 and not v45 then
                            return;
                        end;

                        local Name = p43.KeyCode.Name;

                        if p43.KeyCode == Enum.KeyCode.Escape or u42 == 2 and Name == "ButtonB" then
                            u41:Disconnect();
                            u16 = nil;
                            u37.Text = Text;

                            return;
                        end;

                        if u42 == 2 and not u15[Name] then
                            return;
                        end;

                        u41:Disconnect();
                        u16 = nil;
                        u40[u42] = Name;

                        if u42 == 1 and (u38 == "CoreControls" and u39 == "Shift Lock") then
                            LocalPlayer:SetAttribute("ShiftLockKey", Name);
                        end;

                        u37.Text = GamepadGlyphs.Label(Name);
                        SettingsRemote:FireServer({
                            Action = "Keybind",
                            BindCategory = u38,
                            BindAction = u39,
                            NewKey = Name,
                            IsGamepad = u42 == 2
                        });
                    end);
                    table.insert(u3, u41);
                end);
                local v46 = u35[2];

                if v46 then
                    makeKeyButton(v36, 2, GamepadGlyphs.Label(v46), true, function(u47) -- Line: 370
                        -- upvalues: u33 (copy), u34 (copy), u35 (copy), u16 (ref), UserInputService (ref), Platform (ref), u15 (ref), LocalPlayer (ref), GamepadGlyphs (ref), SettingsRemote (ref), u3 (ref)
                        local u48 = u33;
                        local u49 = u34;
                        local u50 = u35;

                        if u16 then
                            return;
                        end;

                        u16 = true;
                        local Text = u47.Text;
                        u47.Text = "press button…";
                        local u51 = nil;
                        local u52 = 2;
                        u51 = UserInputService.InputBegan:Connect(function(p53, p54) -- Line: 322
                            -- upvalues: Platform (ref), u52 (copy), u51 (ref), u16 (ref), u47 (copy), Text (copy), u15 (ref), u50 (copy), u48 (copy), u49 (copy), LocalPlayer (ref), GamepadGlyphs (ref), SettingsRemote (ref)
                            if p54 then
                                return;
                            end;

                            local v55 = Platform.IsGamepadInput(p53.UserInputType);

                            if u52 == 1 and p53.UserInputType ~= Enum.UserInputType.Keyboard then
                                return;
                            end;

                            if u52 == 2 and not v55 then
                                return;
                            end;

                            local Name = p53.KeyCode.Name;

                            if p53.KeyCode == Enum.KeyCode.Escape or u52 == 2 and Name == "ButtonB" then
                                u51:Disconnect();
                                u16 = nil;
                                u47.Text = Text;

                                return;
                            end;

                            if u52 == 2 and not u15[Name] then
                                return;
                            end;

                            u51:Disconnect();
                            u16 = nil;
                            u50[u52] = Name;

                            if u52 == 1 and (u48 == "CoreControls" and u49 == "Shift Lock") then
                                LocalPlayer:SetAttribute("ShiftLockKey", Name);
                            end;

                            u47.Text = GamepadGlyphs.Label(Name);
                            SettingsRemote:FireServer({
                                Action = "Keybind",
                                BindCategory = u48,
                                BindAction = u49,
                                NewKey = Name,
                                IsGamepad = u52 == 2
                            });
                        end);
                        table.insert(u3, u51);
                    end);
                elseif u14[u34] then
                    makeKeyButton(v36, 2, "2× " .. GamepadGlyphs.Label(u14[u34]), false, nil);
                else
                    makeKeyButton(v36, 2, GamepadGlyphs.PadBinding(u33, u34) or "—", false, nil);
                end;
            end;
        end;

        makeKeyButton(makeRow(#u13 + 1, "Reset all binds"), 2, "RESET", true, function() -- Line: 386
            -- upvalues: ControlData (ref), u13 (ref), LocalPlayer (ref), SettingsRemote (ref), SetupKeybinds (ref)
            local Defaults = ControlData.Defaults;

            if Defaults then
                for _, v in ipairs(u13) do
                    local v56 = v[1];
                    local v57 = v[2];
                    local v58 = ControlData.Controls[v56] and ControlData.Controls[v56][v57];
                    local v59 = Defaults[v56] and Defaults[v56][v57];

                    if v58 and v59 then
                        for i = 1, math.max(#v58, #v59) do
                            v58[i] = v59[i];
                            local _ = i;
                        end;

                        if v56 == "CoreControls" and (v57 == "Shift Lock" and v59[1]) then
                            LocalPlayer:SetAttribute("ShiftLockKey", v59[1]);
                        end;
                    end;
                end;
            end;

            SettingsRemote:FireServer({
                Action = "ResetKeybinds"
            });
            SetupKeybinds();
        end);
    end;

    SetupSliders();
    SetupButtons();
    SetupKeybinds();
end;

function Close_Menu()
    -- upvalues: u2 (ref), GlobalFunctions (copy), Debris (copy), u1 (copy)
    u2 = false;

    for _, child in pairs(game.Lighting:GetChildren()) do
        if child:IsA("BlurEffect") then
            GlobalFunctions.Tween({
                Duration = 1,
                Instance = child
            }, {
                Size = 0
            });
            Debris:AddItem(child, 1);
        end;
    end;

    local UIScale = u1:FindFirstChild("UIScale");

    if UIScale then
        GlobalFunctions.Tween({
            Duration = 0.18,
            Instance = UIScale,
            Style = Enum.EasingStyle.Quad,
            Direction = Enum.EasingDirection.In
        }, {
            Scale = 0.75
        });
    end;

    task.delay(UIScale and 0.18 or 0.5, function() -- Line: 436
        -- upvalues: u1 (ref), UIScale (copy)
        u1.Visible = false;

        if UIScale then
            UIScale.Scale = 1;
        end;
    end);
end;

return {
    Menu = function(p60) -- Line: 443
        -- upvalues: u2 (ref)
        if u2 == false then
            Open_Menu();

            return;
        end;

        Close_Menu();
    end
};