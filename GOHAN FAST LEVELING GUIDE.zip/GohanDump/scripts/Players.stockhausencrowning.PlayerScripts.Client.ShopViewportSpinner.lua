-- Decompiled with Potassium's decompiler.

local Players = game:GetService("Players");
local RunService = game:GetService("RunService");
local PlayerGui = Players.LocalPlayer:WaitForChild("PlayerGui");
local u1 = {};

local function register(u2) -- Line: 34
    -- upvalues: u1 (copy), register (copy)
    if u1[u2] then
        return;
    end;

    local Attribute = u2:GetAttribute("SpinZoom");

    if type(Attribute) == "number" then
        u1[u2] = {
            Angle = 0,
            Pivot = nil,
            Zoom = Attribute,
            Screen = u2:FindFirstAncestorWhichIsA("ScreenGui")
        };

        return;
    end;

    local u3 = nil;
    u3 = u2:GetAttributeChangedSignal("SpinZoom"):Connect(function() -- Line: 43
        -- upvalues: u2 (copy), u3 (ref), register (ref)
        if type(u2:GetAttribute("SpinZoom")) == "number" then
            u3:Disconnect();
            register(u2);
        end;
    end);
end;

local function getSubject(p4) -- Line: 25
    for _, child in ipairs(p4:GetChildren()) do
        if child:IsA("Model") or child:IsA("BasePart") then
            return child;
        end;
    end;

    return nil;
end;

for _, descendant in ipairs(PlayerGui:GetDescendants()) do
    if descendant:IsA("ViewportFrame") then
        register(descendant);
    end;
end;

PlayerGui.DescendantAdded:Connect(function(p5) -- Line: 64
    -- upvalues: register (copy)
    if p5:IsA("ViewportFrame") then
        register(p5);
    end;
end);
PlayerGui.DescendantRemoving:Connect(function(p6) -- Line: 68
    -- upvalues: u1 (copy)
    if u1[p6] then
        u1[p6] = nil;
    end;
end);
RunService.Heartbeat:Connect(function(p7) -- Line: 72
    -- upvalues: u1 (copy), getSubject (copy)
    for i, v in pairs(u1) do
        if i.Parent then
            if i.Visible and (not v.Screen or v.Screen.Enabled) then
                local Parent = i.Parent;
                local v8 = i;
                local v9 = v;
                local v10 = false;

                while Parent and Parent ~= v9.Screen do
                    if Parent:IsA("GuiObject") and not Parent.Visible then
                        v10 = true;
                        break;
                    end;

                    Parent = Parent.Parent;
                end;

                if not v10 then
                    local CurrentCamera = v8.CurrentCamera;

                    if not CurrentCamera then
                        CurrentCamera = v8:FindFirstChildOfClass("Camera") or Instance.new("Camera");
                        CurrentCamera.Parent = v8;
                        v8.CurrentCamera = CurrentCamera;
                    end;

                    local v11;

                    if v9.Pivot then
                        v9.Angle = (v9.Angle + 60 * p7) % 360;
                        v11 = v9.Pivot * CFrame.Angles(0, math.rad(v9.Angle), 0) * CFrame.new(0, 0, -v9.Zoom);
                        CurrentCamera.CFrame = CFrame.lookAt(v11.Position, v9.Pivot.Position);
                    else
                        local v12 = getSubject(v8);

                        if v12 then
                            v9.Pivot = v12:IsA("Model") and v12:GetPivot() or v12.CFrame;
                            v9.Angle = (v9.Angle + 60 * p7) % 360;
                            v11 = v9.Pivot * CFrame.Angles(0, math.rad(v9.Angle), 0) * CFrame.new(0, 0, -v9.Zoom);
                            CurrentCamera.CFrame = CFrame.lookAt(v11.Position, v9.Pivot.Position);
                        end;
                    end;
                end;
            end;
        else
            u1[i] = nil;
        end;
    end;
end);