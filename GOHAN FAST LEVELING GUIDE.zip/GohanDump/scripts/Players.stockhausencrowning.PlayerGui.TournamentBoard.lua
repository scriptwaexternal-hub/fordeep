-- Decompiled with Potassium's decompiler.

local Players = game:GetService("Players");
local ReplicatedStorage = game:GetService("ReplicatedStorage");
local PlayerGui = Players.LocalPlayer:WaitForChild("PlayerGui");
local Remotes = ReplicatedStorage:WaitForChild("Remotes");
local ServerRemote = Remotes:WaitForChild("ServerRemote");
local TournamentRemote = Remotes:WaitForChild("TournamentRemote");
local GetTournamentStatus = Remotes:WaitForChild("GetTournamentStatus");
local Color3_fromRGB_ret = Color3.fromRGB(38, 41, 47);
local Color3_fromRGB_ret2 = Color3.fromRGB(28, 30, 35);
local Color3_fromRGB_ret3 = Color3.fromRGB(70, 76, 86);
local Color3_fromRGB_ret4 = Color3.fromRGB(235, 238, 242);
local Color3_fromRGB_ret5 = Color3.fromRGB(160, 168, 178);
local Color3_fromRGB_ret6 = Color3.fromRGB(120, 255, 140);
local Color3_fromRGB_ret7 = Color3.fromRGB(90, 200, 255);
local Color3_fromRGB_ret8 = Color3.fromRGB(255, 120, 120);
local ScreenGui = Instance.new("ScreenGui");
ScreenGui.Name = "TournamentBoard";
ScreenGui.ResetOnSpawn = false;
ScreenGui.Enabled = false;
ScreenGui.IgnoreGuiInset = true;
ScreenGui.DisplayOrder = 40;
ScreenGui.Parent = PlayerGui;
local Frame = Instance.new("Frame");
Frame.Name = "Board";
Frame.Size = UDim2.fromOffset(430, 430);
Frame.Position = UDim2.new(0.5, -215, 0.5, -215);
Frame.BackgroundColor3 = Color3_fromRGB_ret;
Frame.BorderSizePixel = 3;
Frame.BorderColor3 = Color3_fromRGB_ret3;
Frame.Parent = ScreenGui;
local TextLabel = Instance.new("TextLabel");
TextLabel.Size = UDim2.new(1, 0, 0, 58);
TextLabel.BackgroundColor3 = Color3_fromRGB_ret2;
TextLabel.BorderSizePixel = 0;
TextLabel.Font = Enum.Font.Bangers;
TextLabel.Text = "WORLD MARTIAL ARTS TOURNAMENT";
TextLabel.TextColor3 = Color3_fromRGB_ret7;
TextLabel.TextSize = 30;
TextLabel.TextWrapped = true;
TextLabel.Parent = Frame;
local TextButton = Instance.new("TextButton");
TextButton.Size = UDim2.fromOffset(34, 34);
TextButton.Position = UDim2.new(1, -40, 0, 6);
TextButton.BackgroundColor3 = Color3_fromRGB_ret;
TextButton.BorderSizePixel = 2;
TextButton.BorderColor3 = Color3_fromRGB_ret3;
TextButton.Font = Enum.Font.Bangers;
TextButton.Text = "X";
TextButton.TextSize = 24;
TextButton.TextColor3 = Color3_fromRGB_ret8;
TextButton.Parent = Frame;
local u1 = {};

for i, v in ipairs({ "Next Tournament", "Registration", "Entry Fee", "Minimum Players", "Registered" }) do
    local v2 = 70 + (i - 1) * 40;
    local TextLabel2 = Instance.new("TextLabel");
    TextLabel2.Size = UDim2.new(0.5, -20, 0, 32);
    TextLabel2.Position = UDim2.new(0, 16, 0, v2);
    TextLabel2.BackgroundTransparency = 1;
    TextLabel2.Font = Enum.Font.Arcade;
    TextLabel2.Text = v;
    TextLabel2.TextSize = 17;
    TextLabel2.TextColor3 = Color3_fromRGB_ret5;
    TextLabel2.TextXAlignment = Enum.TextXAlignment.Left;
    TextLabel2.Parent = Frame;
    local TextLabel3 = Instance.new("TextLabel");
    TextLabel3.Size = UDim2.new(0.5, -20, 0, 32);
    TextLabel3.Position = UDim2.new(0.5, 4, 0, v2);
    TextLabel3.BackgroundTransparency = 1;
    TextLabel3.Font = Enum.Font.Arcade;
    TextLabel3.Text = "-";
    TextLabel3.TextSize = 17;
    TextLabel3.TextColor3 = Color3_fromRGB_ret4;
    TextLabel3.TextXAlignment = Enum.TextXAlignment.Right;
    TextLabel3.Parent = Frame;
    u1[v] = TextLabel3;
end;

local TextLabel2 = Instance.new("TextLabel");
TextLabel2.Size = UDim2.new(1, -32, 0, 46);
TextLabel2.Position = UDim2.new(0, 16, 0, 274);
TextLabel2.BackgroundTransparency = 1;
TextLabel2.Font = Enum.Font.Arcade;
TextLabel2.Text = "";
TextLabel2.TextSize = 15;
TextLabel2.TextWrapped = true;
TextLabel2.TextColor3 = Color3_fromRGB_ret7;
TextLabel2.Parent = Frame;
local TextButton2 = Instance.new("TextButton");
TextButton2.Size = UDim2.new(1, -32, 0, 60);
TextButton2.Position = UDim2.new(0, 16, 1, -100);
TextButton2.BackgroundColor3 = Color3_fromRGB_ret2;
TextButton2.BorderSizePixel = 3;
TextButton2.BorderColor3 = Color3_fromRGB_ret6;
TextButton2.Font = Enum.Font.Bangers;
TextButton2.Text = "ENTER TOURNAMENT";
TextButton2.TextSize = 26;
TextButton2.TextColor3 = Color3_fromRGB_ret6;
TextButton2.Parent = Frame;
local TextLabel3 = Instance.new("TextLabel");
TextLabel3.Size = UDim2.new(1, -32, 0, 26);
TextLabel3.Position = UDim2.new(0, 16, 1, -34);
TextLabel3.BackgroundTransparency = 1;
TextLabel3.Font = Enum.Font.Arcade;
TextLabel3.Text = "";
TextLabel3.TextSize = 14;
TextLabel3.TextColor3 = Color3_fromRGB_ret5;
TextLabel3.Parent = Frame;

local function refresh() -- Line: 127
    -- upvalues: GetTournamentStatus (copy), u1 (copy), TextButton2 (copy), TextLabel2 (copy), Color3_fromRGB_ret6 (copy), Color3_fromRGB_ret8 (copy), Color3_fromRGB_ret7 (copy), Color3_fromRGB_ret5 (copy), Color3_fromRGB_ret3 (copy)
    local success, result = pcall(function() -- Line: 128
        -- upvalues: GetTournamentStatus (ref)
        return GetTournamentStatus:InvokeServer();
    end);

    if not success or type(result) ~= "table" then
        return;
    end;

    if not result.Available then
        u1["Next Tournament"].Text = "Not on this world";
        u1.Registration.Text = "-";
        u1["Entry Fee"].Text = "-";
        u1["Minimum Players"].Text = "-";
        u1.Registered.Text = "-";
        TextButton2.Visible = false;
        TextLabel2.Text = "The tournament is held on Earth.";

        return;
    end;

    u1["Next Tournament"].Text = result.NextTimeText;
    u1.Registration.Text = result.RegistrationOpen and "OPEN" or "CLOSED";
    u1.Registration.TextColor3 = result.RegistrationOpen and Color3_fromRGB_ret6 or Color3_fromRGB_ret8;
    u1["Entry Fee"].Text = string.format("%s Zeni", (tostring(result.Fee)));
    u1["Minimum Players"].Text = tostring(result.MinPlayers);
    u1.Registered.Text = tostring(result.RegisteredCount);

    if result.CurrentMatchText == "" then
        if result.State == "CANCELLED" then
            TextLabel2.Text = "The last tournament was cancelled.";
        elseif result.State == "COMPLETED" then
            TextLabel2.Text = "The last tournament has concluded.";
        elseif result.RegistrationOpen then
            local math_floor_ret = math.floor(result.SecondsToStart / 60);
            TextLabel2.Text = string.format("The bell rings in %d minute%s!", math_floor_ret, math_floor_ret == 1 and "" or "s");
        else
            TextLabel2.Text = "";
        end;
    else
        TextLabel2.Text = "NOW: " .. result.CurrentMatchText;
    end;

    TextButton2.Visible = true;

    if result.IsRegistered then
        TextButton2.Text = "YOU ARE REGISTERED FOR THE NEXT WMAT";
        TextButton2.TextColor3 = Color3_fromRGB_ret7;
        TextButton2.BorderColor3 = Color3_fromRGB_ret7;
        TextButton2.Active = false;

        return;
    end;

    if result.RegistrationOpen then
        TextButton2.Text = string.format("ENTER TOURNAMENT -- %s ZENI", (tostring(result.Fee)));
        TextButton2.TextColor3 = Color3_fromRGB_ret6;
        TextButton2.BorderColor3 = Color3_fromRGB_ret6;
        TextButton2.Active = true;

        return;
    end;

    TextButton2.Text = "REGISTRATION CLOSED";
    TextButton2.TextColor3 = Color3_fromRGB_ret5;
    TextButton2.BorderColor3 = Color3_fromRGB_ret3;
    TextButton2.Active = false;
end;

TextButton2.Activated:Connect(function() -- Line: 183
    -- upvalues: TextButton2 (copy), ServerRemote (copy), refresh (copy)
    if not TextButton2.Active then
        return;
    end;

    ServerRemote:FireServer(nil, {
        Module = "TournamentManager",
        Action = "Register"
    });
    task.delay(0.6, refresh);
end);
TextButton.Activated:Connect(function() -- Line: 192
    -- upvalues: ScreenGui (copy)
    ScreenGui.Enabled = false;
end);
PlayerGui:GetAttributeChangedSignal("OpenTournamentBoard"):Connect(function() -- Line: 196
    -- upvalues: ScreenGui (copy), refresh (copy)
    ScreenGui.Enabled = true;
    refresh();
end);
TournamentRemote.OnClientEvent:Connect(function(p3) -- Line: 201
    -- upvalues: ScreenGui (copy), refresh (copy)
    if p3 == "Refresh" and ScreenGui.Enabled then
        refresh();
    end;
end);
task.spawn(function() -- Line: 206
    -- upvalues: ScreenGui (copy), refresh (copy)
    while true do
        repeat
            task.wait(3);
        until ScreenGui.Enabled;

        pcall(refresh);
    end;
end);