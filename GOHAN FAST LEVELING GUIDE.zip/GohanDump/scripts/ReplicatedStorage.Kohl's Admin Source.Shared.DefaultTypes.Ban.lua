-- Decompiled with Potassium's decompiler.

local u1 = nil;

local function parseBan(p2) -- Line: 3
    -- upvalues: u1 (ref)
    local string_lower_ret = string.lower(p2);

    for i, v in u1.Data.bans do
        local v3 = v[1];

        if v3 and string.find(string.lower(v3), string_lower_ret, 1, true) == 1 or string.find(string.lower(i), string_lower_ret, 1, true) == 1 then
            return i;
        end;
    end;

    if tonumber(p2) then
        return tonumber(p2);
    end;

    return nil, "Invalid ban.";
end;

local u9 = {
    validate = parseBan,
    parse = parseBan,
    prefixes = {
        ["^%*$"] = "allBans",
        ["^all$"] = "allBans"
    },

    suggestions = function(p4) -- Line: 29, Name: suggestions
        -- upvalues: u1 (ref)
        local v5 = { { { "*", "all" }, "*  [all] (Everyone)" } };

        for i, v in u1.Data.bans do
            local v6 = v[1];

            if v6 then
                local v7 = {
                    { v6, i },
                    (`{v6} [{i}]`)
                };
                table.insert(v5, v7);
            else
                local v8 = { i, (`UNKNOWN [{i}]`) };
                table.insert(v5, v8);
            end;
        end;

        return v5;
    end
};
local u10 = {
    listable = true
};

local function parseAll(p11, p12) -- Line: 47
    -- upvalues: u1 (ref)
    local v13 = {};
    local v14 = {};

    for i, _ in u1.Data.bans do
        local v15, v16 = p12._K.Auth.targetUserArgument(p12, tonumber(i), i);

        if v15 then
            table.insert(v13, i);
        elseif not table.find(v14, v16) then
            table.insert(v14, i);
        end;
    end;

    if #v13 > 0 then
        return v13;
    end;

    return nil, #v14 > 0 and table.concat(v14, "\n") or "No targetable user found";
end;

local u21 = {
    listable = true,
    transform = string.lower,

    validate = function(p17, p18) -- Line: 70, Name: validate
        -- upvalues: parseAll (copy)
        local v19, v20 = parseAll(p17, p18);

        return v19, v20 or "Invalid ban";
    end,

    suggestions = { { { "*", "all" }, "*  [all] (Everyone)" } },
    parse = parseAll
};

return function(p22) -- Line: 78
    -- upvalues: u1 (ref), u9 (copy), u10 (copy), u21 (copy)
    u1 = p22;
    u1.Registry.registerType("ban", u9);
    u1.Registry.registerType("bans", u10, u9);
    u1.Registry.registerType("allBans", u21);
end;