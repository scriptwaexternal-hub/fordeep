-- Decompiled with Potassium's decompiler.

local ReplicatedStorage = game:GetService("ReplicatedStorage");
local Modules = ReplicatedStorage:WaitForChild("Modules");
local Remotes = ReplicatedStorage:WaitForChild("Remotes");
local KamiCard = require(Modules.Shared.KamiCard);
local ServerRemote = Remotes.ServerRemote;
local Color3_fromRGB_ret = Color3.fromRGB(255, 64, 64);

return {
    Ask = function(p1) -- Line: 24, Name: Ask
        -- upvalues: KamiCard (copy), Color3_fromRGB_ret (copy), ServerRemote (copy)
        local v2 = p1 or {};
        local v3 = v2.Duration or 30;
        local u4 = KamiCard.new({
            Name = "FusionConsentCard",
            Width = 540,
            Height = 216,
            DisplayOrder = 90,
            Portrait = false
        });
        u4:Render({
            Counter = "FUSION",
            Title = "GIVE UP BODY AND SOUL?",
            Detail = "WARNING: IF YOU ACCEPT, THIS CHARACTER IS RESET. ALL PROGRESSION IS PERMANENTLY LOST.",
            Footnote = "Walk away or wait to refuse.",
            Button = "GIVE UP BODY & SOUL",
            Objective = (v2.Initiator or "A Namekian") .. " offers fusion"
        });
        u4.Detail.TextColor3 = Color3_fromRGB_ret;
        u4.Detail.Size = UDim2.new(1, -36, 0, 58);
        u4.Footnote.Position = UDim2.new(0, 18, 0, 134);
        u4.Footnote.Size = UDim2.new(1, -36, 0, 22);
        u4.Button.Size = UDim2.fromOffset(310, 34);
        u4.Button.BackgroundColor3 = Color3.fromRGB(170, 36, 36);
        local TextButton = Instance.new("TextButton");
        TextButton.Name = "Refuse";
        TextButton.AnchorPoint = Vector2.new(1, 1);
        TextButton.Position = UDim2.new(1, -338, 1, -14);
        TextButton.Size = UDim2.fromOffset(120, 34);
        TextButton.BackgroundColor3 = Color3.fromRGB(28, 28, 30);
        TextButton.BorderSizePixel = 0;
        TextButton.TextColor3 = Color3.new(1, 1, 1);
        TextButton.Font = Enum.Font.Arcade;
        TextButton.TextSize = 18;
        TextButton.Text = "REFUSE";
        TextButton.AutoButtonColor = true;
        TextButton.Parent = u4.Card;
        local UIStroke = Instance.new("UIStroke");
        UIStroke.Color = Color3.new(0, 0, 0);
        UIStroke.Thickness = 1.5;
        UIStroke.Parent = TextButton;
        u4:SlideIn();
        local u5 = false;

        local function reply(p6) -- Line: 79
            -- upvalues: u5 (ref), ServerRemote (ref), u4 (copy)
            if u5 then
                return;
            end;

            u5 = true;
            ServerRemote:FireServer(nil, {
                Module = "FusionManager",
                Action = "Respond",
                Accept = p6
            });
            u4:Dismiss();
        end;

        u4.Button.MouseButton1Click:Connect(function() -- Line: 90
            -- upvalues: u5 (ref), ServerRemote (ref), u4 (copy)
            if u5 then
                return;
            end;

            u5 = true;
            ServerRemote:FireServer(nil, {
                Module = "FusionManager",
                Action = "Respond",
                Accept = true
            });
            u4:Dismiss();
        end);
        TextButton.MouseButton1Click:Connect(function() -- Line: 93
            -- upvalues: u5 (ref), ServerRemote (ref), u4 (copy)
            if u5 then
                return;
            end;

            u5 = true;
            ServerRemote:FireServer(nil, {
                Module = "FusionManager",
                Action = "Respond",
                Accept = false
            });
            u4:Dismiss();
        end);
        task.delay(v3, function() -- Line: 96
            -- upvalues: u5 (ref), ServerRemote (ref), u4 (copy)
            if u5 then
                return;
            end;

            u5 = true;
            ServerRemote:FireServer(nil, {
                Module = "FusionManager",
                Action = "Respond",
                Accept = false
            });
            u4:Dismiss();
        end);
    end
};