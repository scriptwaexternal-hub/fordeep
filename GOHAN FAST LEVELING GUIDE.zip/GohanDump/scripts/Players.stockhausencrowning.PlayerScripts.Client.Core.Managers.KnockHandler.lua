-- Decompiled with Potassium's decompiler.

local Players = game:GetService("Players");
game:GetService("Debris");
local ReplicatedStorage = game:GetService("ReplicatedStorage");
game:GetService("RunService");
local _ = ReplicatedStorage.Assets;
local Modules = ReplicatedStorage:WaitForChild("Modules");
local Remotes = ReplicatedStorage:WaitForChild("Remotes");
local _ = Modules.Metadata;
local Shared = Modules.Shared;
local _ = Modules.Utility;
require(Shared.SoundManager);
require(Modules.GlobalFunctions);
local KamiCard = require(Shared.KamiCard);
local UserInputService = game:GetService("UserInputService");
local ServerRemote = Remotes.ServerRemote;
local workspace_CurrentCamera = workspace.CurrentCamera;
local LocalPlayer = Players.LocalPlayer;
local u1 = { "UpperTorso", "Torso", "HumanoidRootPart", "Head" };

local function stableSubject(p2) -- Line: 40
    -- upvalues: u1 (copy)
    for _, v in ipairs(u1) do
        local v3 = p2:FindFirstChild(v);

        if v3 and v3:IsA("BasePart") then
            return v3;
        end;
    end;

    return nil;
end;

local function isKnocked(p4) -- Line: 48
    local v5;

    if p4:FindFirstChild("Knocked") == nil then
        v5 = false;
    else
        v5 = p4:FindFirstChild("Dead") == nil;
    end;

    return v5;
end;

local function canTech(p6, p7) -- Line: 63
    if p6:FindFirstChild("K.O") then
        return false;
    end;

    if p6:GetAttribute("State_KO") then
        return false;
    end;

    if p7 < 0.35 then
        return false;
    end;

    if (p6:GetAttribute("RagdollCancelCDUntil") or 0) > workspace:GetServerTimeNow() then
        return false;
    end;

    if (p6:GetAttribute("FormCollapseUntil") or 0) > workspace:GetServerTimeNow() then
        return false;
    end;

    return (p6:GetAttribute("NoTechUntil") or 0) <= workspace:GetServerTimeNow();
end;

local function techKeys() -- Line: 79
    -- upvalues: UserInputService (copy)
    return UserInputService.TouchEnabled and not UserInputService.KeyboardEnabled and { "TAP" } or { "Q", "B" };
end;

return {
    Execute = function() -- Line: 86
        -- upvalues: LocalPlayer (copy), stableSubject (copy), workspace_CurrentCamera (copy), UserInputService (copy), ServerRemote (copy), KamiCard (copy), techKeys (copy), canTech (copy)
        local v8 = LocalPlayer.Character or LocalPlayer.CharacterAdded:Wait();

        if not v8 then
            return;
        end;

        local v9 = stableSubject(v8);

        if not v9 then
            return;
        end;

        workspace_CurrentCamera.CameraSubject = v9;
        local v12 = UserInputService.InputBegan:Connect(function(p10, p11) -- Line: 106
            -- upvalues: ServerRemote (ref)
            if p11 then
                return;
            end;

            if p10.KeyCode == Enum.KeyCode.Q or (p10.KeyCode == Enum.KeyCode.ButtonB or p10.UserInputType == Enum.UserInputType.Touch) then
                ServerRemote:FireServer("Ragdoll Cancel");
            end;
        end);
        local u13 = nil;

        local function showCard() -- Line: 123
            -- upvalues: u13 (ref), KamiCard (ref), techKeys (ref)
            if u13 then
                return;
            end;

            u13 = KamiCard.new({
                Name = "RagdollEscapeCard",
                Width = 200,
                Height = 88,
                DisplayOrder = 80,
                Portrait = false
            });
            u13:Render({
                Speaker = "",
                Title = "TECH UP",
                Objective = "",
                Detail = "",
                Counter = "",
                Button = false,
                Keys = techKeys()
            });
            u13.Title.Size = UDim2.new(1, -36, 0, 28);
            u13:SlideIn();
        end;

        local function hideCard() -- Line: 157
            -- upvalues: u13 (ref)
            if not u13 then
                return;
            end;

            u13:Dismiss();
            u13 = nil;
        end;

        local os_clock_ret = os.clock();

        while v8.Parent ~= nil do
            local v14;

            if v8:FindFirstChild("Knocked") == nil then
                v14 = false;
            else
                v14 = v8:FindFirstChild("Dead") == nil;
            end;

            if not v14 then
                break;
            end;

            if workspace_CurrentCamera.CameraSubject ~= v9 then
                if not (v9.Parent and v9:IsDescendantOf(v8)) then
                    break;
                end;

                workspace_CurrentCamera.CameraSubject = v9;
            end;

            if canTech(v8, os.clock() - os_clock_ret) then
                showCard();
            elseif u13 then
                u13:Dismiss();
                u13 = nil;
            end;

            task.wait(0.1);
        end;

        if u13 then
            u13:Dismiss();
            u13 = nil;
        end;

        v12:Disconnect();
        local Character = LocalPlayer.Character;

        if Character then
            Character = Character:FindFirstChildOfClass("Humanoid");
        end;

        if Character then
            workspace_CurrentCamera.CameraSubject = Character;
        end;
    end
};