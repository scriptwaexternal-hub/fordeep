-- Decompiled with Potassium's decompiler.

local Debris = game:GetService("Debris");
local ReplicatedStorage = game:GetService("ReplicatedStorage");
local RunService = game:GetService("RunService");
local Modules = ReplicatedStorage:WaitForChild("Modules");
local SoundManager = require(Modules.Shared.SoundManager);
local GlobalFunctions = require(Modules.GlobalFunctions);
local Bezier = require(Modules.Shared.Bezier);
local Visuals = workspace.World.Visuals;
local Effects = ReplicatedStorage.Assets.Effects;
local Color3_fromRGB_ret = Color3.fromRGB(255, 100, 100);

return {
    Blast = function(p1) -- Line: 31
        -- upvalues: GlobalFunctions (copy), Effects (copy), Visuals (copy), Debris (copy), SoundManager (copy), Bezier (copy), RunService (copy)
        local Character = p1.Character;

        if not Character then
            return;
        end;

        local RootAndHumanoid = GlobalFunctions.GetRootAndHumanoid(Character);

        if not RootAndHumanoid then
            return;
        end;

        if not p1.Location then
            return;
        end;

        local v2 = Character:FindFirstChild(p1.Arm and "Right Arm" or "Left Arm") or RootAndHumanoid;
        local v3 = Effects.Skills["Ki Blast"]:Clone();
        v3.Name = Character.Name .. ":Grenade";
        v3.CFrame = v2.CFrame * CFrame.new(0, -2, 0);
        v3.Anchored = true;
        v3.Parent = Visuals;
        Debris:AddItem(v3, 10);
        SoundManager.AddSound("Ki Blast", {
            Parent = v3
        }, "Client");
        local Position = v2.Position;
        local v4 = RootAndHumanoid.CFrame * CFrame.new(math.random(-40, 40), math.random(20, 40), math.random(-70, -20)).Position;
        local v5 = Bezier.new(Bezier.quadBezier, 10, Position, v4, p1.Location.Position);

        for i = 0, 1, 0.02 do
            if not v3.Parent then
                return;
            end;

            v3.CFrame = CFrame.new(v5:calcFixed(i));
            RunService.RenderStepped:Wait();
            local _ = i;
        end;
    end,

    Engage = function(p6) -- Line: 62
        -- upvalues: Visuals (copy), GlobalFunctions (copy), Color3_fromRGB_ret (copy), Debris (copy)
        local Character = p6.Character;

        if not Character then
            return;
        end;

        local v7 = Character.Name .. ":Grenade";

        for _, child in ipairs(Visuals:GetChildren()) do
            if child.Name == v7 then
                GlobalFunctions.Tween({
                    Duration = 0.1,
                    Instance = child
                }, {
                    Transparency = 0,
                    Color = Color3_fromRGB_ret
                });
                Debris:AddItem(child, 1);
            end;
        end;
    end
};