-- Decompiled with Potassium's decompiler.

local Players = game:GetService("Players");
local ReplicatedStorage = game:GetService("ReplicatedStorage");
game:GetService("ServerStorage");
game:GetService("ServerScriptService");
game:GetService("RunService");
local Debris = game:GetService("Debris");
local Modules = ReplicatedStorage:WaitForChild("Modules");
ReplicatedStorage:WaitForChild("Remotes");
local Metadata = Modules.Metadata;
local Shared = Modules.Shared;
local Utility = Modules.Utility;
local Assets = ReplicatedStorage.Assets;
local AnimationManager = require(Shared.AnimationManager);
local CharacterData = Metadata.CharacterData;
local SkinColorHandler = require(CharacterData.SkinColorHandler);
local HairHandler = require(CharacterData.HairHandler);
local ShopData = require(Metadata.ShopData.ShopData);
require(Metadata.RaceData.Arcosian.ArmorColorData);
local BaldData = require(Metadata.RaceData.BaldData);
local u1 = require(CharacterData["Bio-Android Body Handler"]);
local ArcosianArmorHandler = require(Metadata:FindFirstChild("ArcosianArmorHandler", true));
local Create = require(Utility.Create);
local FaceHandler = require(CharacterData.FaceHandler);
local PupilColorHandler = require(CharacterData.PupilColorHandler);
local HeightHandler = require(CharacterData.HeightHandler);
local SoundManager = require(Shared.SoundManager);
local GlobalFunctions = require(Modules.GlobalFunctions);
local Clothing = Assets.Clothing;
local RaceParts = Assets.RaceParts;
local Particles = Assets.Effects.Particles;
local u2 = {
    Attachment_Table = { "HatAttachment", "FaceFrontAttachment", "BodyBackAttachment", "NeckAttachment", "FaceCenterAttachment" },
    Removal_Table = { "Shirt", "Pants", "Body Colors", "face", "FakeHead", "Tail", "Cellgame", "Android Button" },
    Banned_From_Clothes = { "Arcosian", "Bio-Android" }
};

function u2.CanWearClothes(p3) -- Line: 86
    -- upvalues: u2 (copy)
    return table.find(u2.Banned_From_Clothes, p3) == nil;
end;

u2.CosmeticAttribute = "Cosmetic";
u2.CosmeticModelName = "Cosmetics";

function u2.NormalizeCosmetic(p4) -- Line: 108
    if not p4 then
        return p4;
    end;

    local function apply(p5) -- Line: 111
        if not p5:IsA("BasePart") then
            return;
        end;

        p5.Massless = true;
        p5.CanCollide = false;
        p5.CanTouch = false;
        p5.CanQuery = false;
        p5:SetAttribute("Cosmetic", true);
    end;

    if p4:IsA("BasePart") then
        p4.Massless = true;
        p4.CanCollide = false;
        p4.CanTouch = false;
        p4.CanQuery = false;
        p4:SetAttribute("Cosmetic", true);
    end;

    for _, descendant in ipairs(p4:GetDescendants()) do
        if descendant:IsA("BasePart") then
            descendant.Massless = true;
            descendant.CanCollide = false;
            descendant.CanTouch = false;
            descendant.CanQuery = false;
            descendant:SetAttribute("Cosmetic", true);
        end;
    end;

    return p4;
end;

function u2.GetCosmeticsModel(p6) -- Line: 132
    if not p6 then
        return nil;
    end;

    local Cosmetics = p6:FindFirstChild("Cosmetics");

    if Cosmetics and Cosmetics:IsA("Model") then
        return Cosmetics;
    end;

    local Model = Instance.new("Model");
    Model.Name = "Cosmetics";
    Model.Parent = p6;

    return Model;
end;

function u2.AttachCosmetic(p7, p8) -- Line: 143
    -- upvalues: u2 (copy)
    u2.NormalizeCosmetic(p8);
    local CosmeticsModel = u2.GetCosmeticsModel(p7);

    if CosmeticsModel then
        p8.Parent = CosmeticsModel;
    end;

    return p8;
end;

local u9 = {
    Clothing = true,
    ["Hat Clothing"] = true,
    ["Back Clothing"] = true
};

function u2.GetClothingModels(p10) -- Line: 163
    -- upvalues: u9 (copy)
    local v11 = {};

    if not p10 then
        return v11;
    end;

    for _, descendant in ipairs(p10:GetDescendants()) do
        if descendant:IsA("Model") and u9[descendant.Name] then
            table.insert(v11, descendant);
        end;
    end;

    return v11;
end;

function Remove_Spawn_Clothes(p12)
    -- upvalues: u2 (copy)
    local Cosmetics = p12:FindFirstChild("Cosmetics");

    if Cosmetics then
        Cosmetics:Destroy();
    end;

    for _, descendant in pairs(p12:GetDescendants()) do
        local v13 = descendant;

        for _, v in pairs(u2.Removal_Table) do
            if v13.Name == v then
                v13:Destroy();
            end;
        end;
    end;

    for _, descendant in pairs(p12:GetDescendants()) do
        if descendant:IsA("Accessory") then
            if descendant.AccessoryType ~= Enum.AccessoryType.Hair then
                descendant:Destroy();
            end;
        elseif descendant.Name == "Clothing" and descendant:IsA("Model") then
            descendant:Destroy();
        end;
    end;
end;

function Remove_Arm(p14)
    local v15 = p14:FindFirstChild("Left Arm");

    if not v15 then
        return;
    end;

    v15.Transparency = 1;

    for _, child in pairs(v15:GetChildren()) do
        if child:IsA("Model") then
            child:Destroy();
        end;
    end;
end;

function Restore_Arm(p16)
    local v17 = p16:FindFirstChild("Left Arm");

    if v17 then
        v17.Transparency = 0;
    end;
end;

function Restore_Tail(u18)
    -- upvalues: RaceParts (copy), u2 (copy), AnimationManager (copy)
    (function() -- Line: 223, Name: Saiyan_Tail
        -- upvalues: RaceParts (ref), u2 (ref), u18 (copy), AnimationManager (ref)
        local v19 = RaceParts.Saiyan.MonkeyTail:Clone();
        u2.AttachCosmetic(u18, v19);
        local Motor6D = Instance.new("Motor6D");
        Motor6D.Part0 = u18.Torso;
        Motor6D.Part1 = v19;
        Motor6D.C0 = Motor6D.C0 * CFrame.new(0, -0.7, 2.7);
        Motor6D.Name = "Tail";
        Motor6D.Parent = u18.Torso;
        AnimationManager.PlayAnimation(u18, "Saiyan Tail Wag", {
            Looped = true
        });
        task.delay(1.5, function() -- Line: 237
            -- upvalues: u18 (ref), AnimationManager (ref)
            if not u18.Parent then
                return;
            end;

            local Torso = u18:FindFirstChild("Torso");

            if not (Torso and Torso:FindFirstChild("Tail")) then
                return;
            end;

            local v20 = u18:FindFirstChildOfClass("Humanoid");

            if not v20 or v20.Health <= 0 then
                return;
            end;

            AnimationManager.ReloadAnimation(u18, "Saiyan Tail Wag", {
                Looped = true
            });
        end);
    end)();
end;

function Give_Default_Race_Clothing(p21, p22)
    -- upvalues: Players (copy), Clothing (copy)
    local Race = p22.CharacterData.Race.Race;
    local PlayerFromCharacter = Players:GetPlayerFromCharacter(p21);

    if not PlayerFromCharacter or PlayerFromCharacter.UserId ~= 90585941 then
        local Children = Clothing["Race Clothes"][Race]["Starter Clothes"]["Outfit 1"]:GetChildren();

        for _, v in pairs(Children) do
            v:Clone().Parent = p21;
        end;

        return;
    end;

    local Shirt = Instance.new("Shirt");
    Shirt.Parent = p21;
    Shirt.ShirtTemplate = "rbxassetid://12691260200";
    local Pants = Instance.new("Pants");
    Pants.Parent = p21;
    Pants.PantsTemplate = "rbxassetid://12691261978";
end;

function Give_OutFit(p23, p24)
    -- upvalues: u2 (copy), Players (copy), Clothing (copy), ShopData (copy)
    if table.find(u2.Banned_From_Clothes, p24.CharacterData.Race.Race) then
        return "None";
    end;

    local Outfit = p24.Accessories.Outfit;
    local PlayerFromCharacter = Players:GetPlayerFromCharacter(p23);

    if PlayerFromCharacter then
        PlayerFromCharacter = PlayerFromCharacter:GetAttribute("LoreOutfit");
    end;

    if PlayerFromCharacter then
        if PlayerFromCharacter == "" then
            PlayerFromCharacter = Outfit;
        end;
    else
        PlayerFromCharacter = Outfit;
    end;

    local v25 = Clothing:FindFirstChild(PlayerFromCharacter, true);

    if not v25 then
        return;
    end;

    for _, child in pairs(v25:GetChildren()) do
        local v26 = child;

        for _, child2 in pairs(p23:GetChildren()) do
            if child2:IsA("BasePart") and v26.Name == child2.Name then
                local v27 = v26:Clone();
                v27.Name = "Clothing";
                local v28 = ShopData and ShopData.Clothing and ShopData.Clothing[PlayerFromCharacter];

                if v28 and v28.Stretchy then
                    v27:SetAttribute("Stretch", true);
                end;

                u2.AttachCosmetic(p23, v27);
                local v29 = child2;

                for _, child3 in pairs(v27:GetChildren()) do
                    local v30 = child3:FindFirstChildOfClass("Attachment");

                    if child3 and v30 then
                        local Weld = Instance.new("Weld");
                        Weld.Parent = v27;
                        Weld.Part0 = child3;
                        Weld.Part1 = v29;
                        Weld.C0 = v30.CFrame;
                    end;
                end;
            end;
        end;
    end;
end;

function Give_Skin_Color(p31, p32)
    -- upvalues: SkinColorHandler (copy)
    SkinColorHandler.Give(p31, p32);
end;

function Give_Race_Parts(u33, u34)
    -- upvalues: Players (copy), RaceParts (copy), u2 (copy), AnimationManager (copy), ArcosianArmorHandler (copy), u1 (copy), GlobalFunctions (copy)
    local Race = u33.CharacterData.Race.Race;
    local HairType = u33.CharacterData.HairType;
    local SkinColor = u33.CharacterData.SkinColor;
    local SecondarySkinColor = u33.CharacterData.SecondarySkinColor;
    local Tail = u33.Accessories.Tail;
    Players:GetPlayerFromCharacter(u34);
    local v46 = ({
        Namekian = function() -- Line: 334
            -- upvalues: RaceParts (ref), HairType (copy), u2 (ref), u34 (copy), SkinColor (copy)
            (function() -- Line: 335, Name: Namek_Head
                -- upvalues: RaceParts (ref), HairType (ref), u2 (ref), u34 (ref), SkinColor (ref)
                for _, child in pairs(RaceParts.Namekian.Heads:GetChildren()) do
                    if child.Name == "NamekHead" .. HairType then
                        local v35 = child:Clone();
                        u2.AttachCosmetic(u34, v35);
                        v35.Handle.Color = Color3.fromRGB(SkinColor.Red, SkinColor.Green, SkinColor.Blue);
                        v35.Name = "FakeHead";

                        for _, child2 in pairs(v35:GetChildren()) do
                            if child2:IsA("Part") or child2:IsA("MeshPart") then
                                child2.Color = Color3.fromRGB(SkinColor.Red, SkinColor.Green, SkinColor.Blue);
                            end;
                        end;

                        local Weld = Instance.new("Weld");
                        Weld.Parent = v35;
                        Weld.Part0 = v35;
                        Weld.Part1 = u34.Head;

                        return;
                    end;
                end;
            end)();
        end,

        Arcosian = function() -- Line: 363
            -- upvalues: RaceParts (ref), u2 (ref), u34 (copy), AnimationManager (ref), SkinColor (copy), SecondarySkinColor (copy), ArcosianArmorHandler (ref), u33 (copy)
            (function() -- Line: 365, Name: Arcosian_Tail
                -- upvalues: RaceParts (ref), u2 (ref), u34 (ref), AnimationManager (ref), SkinColor (ref), SecondarySkinColor (ref)
                local v36 = RaceParts.Arcosian.Form1.Form1Tail:Clone();
                v36.Name = "Arcosian Tail";
                u2.AttachCosmetic(u34, v36);
                local Motor6D = Instance.new("Motor6D");
                Motor6D.Parent = u34.Torso;
                Motor6D.Part0 = u34.Torso;
                Motor6D.Part1 = v36.Tail;
                Motor6D.C0 = Motor6D.C0 * CFrame.new(0, -0.7, 3.5);
                Motor6D.Name = "Tail";
                AnimationManager.PlayAnimation(u34, "Arcosian Tail Wag", {
                    Looped = true
                });
                task.delay(1.5, function() -- Line: 381
                    -- upvalues: u34 (ref), AnimationManager (ref)
                    if not u34.Parent then
                        return;
                    end;

                    local Torso = u34:FindFirstChild("Torso");

                    if not (Torso and Torso:FindFirstChild("Tail")) then
                        return;
                    end;

                    local v37 = u34:FindFirstChildOfClass("Humanoid");

                    if not v37 or v37.Health <= 0 then
                        return;
                    end;

                    AnimationManager.ReloadAnimation(u34, "Arcosian Tail Wag", {
                        Looped = true
                    });
                end);
                v36.Tail.Color = Color3.fromRGB(SkinColor.Red, SkinColor.Green, SkinColor.Blue);
                v36.Tail_End.Color = Color3.fromRGB(SecondarySkinColor.Red, SecondarySkinColor.Green, SecondarySkinColor.Blue);
            end)();
            ArcosianArmorHandler.Fire(u34, "Armor1", u33);
        end,

        Majin = function() -- Line: 398
            -- upvalues: RaceParts (ref), HairType (copy), u2 (ref), u34 (copy), SkinColor (copy)
            (function() -- Line: 399, Name: Majin_Head
                -- upvalues: RaceParts (ref), HairType (ref), u2 (ref), u34 (ref), SkinColor (ref)
                for _, child in pairs(RaceParts.Majin.Heads:GetChildren()) do
                    if child.Name == "Head" .. HairType then
                        local v38 = child:Clone();
                        u2.AttachCosmetic(u34, v38);
                        v38.Color = Color3.fromRGB(SkinColor.Red, SkinColor.Green, SkinColor.Blue);
                        v38.Name = "Buu Parts";

                        for _, child2 in pairs(v38:GetChildren()) do
                            if child2:IsA("MeshPart") then
                                child2.Color = Color3.fromRGB(SkinColor.Red, SkinColor.Green, SkinColor.Blue);
                            end;
                        end;

                        local Weld = Instance.new("Weld");
                        Weld.Parent = v38;
                        Weld.Part0 = v38;
                        Weld.Part1 = u34.Head;

                        return;
                    end;
                end;
            end)();
        end,

        Saiyan = function() -- Line: 426
            -- upvalues: RaceParts (ref), u2 (ref), u34 (copy), AnimationManager (ref), Tail (copy)
            local function Saiyan_Tail() -- Line: 427
                -- upvalues: RaceParts (ref), u2 (ref), u34 (ref), AnimationManager (ref)
                local v39 = RaceParts.Saiyan.MonkeyTail:Clone();
                u2.AttachCosmetic(u34, v39);
                local Motor6D = Instance.new("Motor6D");
                Motor6D.Part0 = u34.Torso;
                Motor6D.Part1 = v39;
                Motor6D.C0 = Motor6D.C0 * CFrame.new(0, -0.7, 2.7);
                Motor6D.Name = "Tail";
                Motor6D.Parent = u34.Torso;
                AnimationManager.PlayAnimation(u34, "Saiyan Tail Wag", {
                    Looped = true
                });
                task.delay(1.5, function() -- Line: 459
                    -- upvalues: u34 (ref), AnimationManager (ref)
                    if not u34.Parent then
                        return;
                    end;

                    local Torso = u34:FindFirstChild("Torso");

                    if not (Torso and Torso:FindFirstChild("Tail")) then
                        return;
                    end;

                    local v40 = u34:FindFirstChildOfClass("Humanoid");

                    if not v40 or v40.Health <= 0 then
                        return;
                    end;

                    AnimationManager.ReloadAnimation(u34, "Saiyan Tail Wag", {
                        Looped = true
                    });
                end);
            end;

            if not Tail then
                return;
            end;

            Saiyan_Tail();
        end,

        ["Bio-Android"] = function() -- Line: 475
            -- upvalues: u34 (copy), u33 (copy), u1 (ref), RaceParts (ref), u2 (ref), AnimationManager (ref)
            local function Give_Body() -- Line: 476
                -- upvalues: u34 (ref), u33 (ref), u1 (ref)
                u34:FindFirstChild("Torso");
                task.delay(1, function() -- Line: 482
                    -- upvalues: u33 (ref), u1 (ref), u34 (ref)
                    u1.GiveBody(u34, u33, {
                        Form = u33.StatData.Transformations["Bio-Android"]["Perfect Form"].Unlocked and "Perfect Form" or (u33.StatData.Transformations["Bio-Android"]["Semi Perfect"].Unlocked and "Semi Perfect Form" or "Imperfect Form")
                    });
                end);
            end;

            local function Bio_Tail() -- Line: 494
                -- upvalues: RaceParts (ref), u2 (ref), u34 (ref), AnimationManager (ref)
                local v41 = RaceParts["Bio-Android"].Cellgame:Clone();
                v41.Name = "Bio Tail";
                u2.AttachCosmetic(u34, v41);

                if u34:FindFirstChild("Torso") then
                    local Motor6D = Instance.new("Motor6D");
                    Motor6D.Parent = u34.Torso;
                    Motor6D.Part0 = u34.Torso;
                    Motor6D.Part1 = v41;
                    Motor6D.C0 = Motor6D.C0 * (CFrame.Angles(0, 1.5707963267948966, 0) * CFrame.new(-3.5, -0.7, 0));
                    Motor6D.Name = "Cellgame";
                    AnimationManager.PlayAnimation(u34, "Bio Tail Wag", {
                        Looped = true
                    });
                end;
            end;

            u34:FindFirstChild("Torso");
            task.delay(1, function() -- Line: 482
                -- upvalues: u33 (ref), u1 (ref), u34 (ref)
                u1.GiveBody(u34, u33, {
                    Form = u33.StatData.Transformations["Bio-Android"]["Perfect Form"].Unlocked and "Perfect Form" or (u33.StatData.Transformations["Bio-Android"]["Semi Perfect"].Unlocked and "Semi Perfect Form" or "Imperfect Form")
                });
            end);
            Bio_Tail();
        end,

        Android = function() -- Line: 516
            -- upvalues: u34 (copy), RaceParts (ref), u2 (ref)
            (function() -- Line: 517, Name: Give_Button
                -- upvalues: u34 (ref), RaceParts (ref), u2 (ref)
                local v42 = { u34:FindFirstChild("Left Arm"), (u34:FindFirstChild("Right Arm")) };

                for _, v in pairs(v42) do
                    if v.Transparency ~= 1 then
                        local v43 = RaceParts.Android["Android Button"]:Clone();
                        v43.CFrame = v.CFrame * CFrame.new(0, -1.03, 0);
                        v43.CFrame = v43.CFrame * CFrame.Angles(0, 0, -1.5707963267948966);
                        u2.AttachCosmetic(u34, v43);
                        local WeldConstraint = Instance.new("WeldConstraint");
                        WeldConstraint.Part0 = v;
                        WeldConstraint.Part1 = v43;
                        WeldConstraint.Parent = v43;
                    end;
                end;
            end)();
        end,

        Demon = function() -- Line: 544
            -- upvalues: u34 (copy), RaceParts (ref), SkinColor (copy), u2 (ref)
            (function() -- Line: 548, Name: Give_Ears
                -- upvalues: u34 (ref), RaceParts (ref), SkinColor (ref), u2 (ref)
                local Head = u34:FindFirstChild("Head");

                if not Head then
                    return;
                end;

                local DemonEars = RaceParts.Demon:FindFirstChild("DemonEars");

                if not DemonEars then
                    warn("ClothesHandler: RaceParts.Demon.DemonEars missing -- skipping demon ears");

                    return;
                end;

                local v44 = DemonEars:Clone();
                v44.Name = "Demon Ears";
                v44.Color = Color3.fromRGB(SkinColor.Red, SkinColor.Green, SkinColor.Blue);
                u2.AttachCosmetic(u34, v44);
                local Weld = Instance.new("Weld");
                Weld.Part0 = Head;
                Weld.Part1 = v44;
                Weld.C0 = CFrame.new(0, 0.15, 0.05) * CFrame.Angles(0, -1.5707963267948966, 0);
                Weld.Parent = v44;
            end)();
        end,

        Alien = function() -- Line: 577
        end,

        Angel = function() -- Line: 578
            -- upvalues: GlobalFunctions (ref), u34 (copy), RaceParts (ref), u2 (ref)
            local _, _ = GlobalFunctions.GetRootAndHumanoid(u34);
            (function() -- Line: 580, Name: Give_Halo
                -- upvalues: u34 (ref), RaceParts (ref), u2 (ref)
                local Head = u34:FindFirstChild("Head");

                if Head then
                    local v45 = RaceParts.Angel.Halo:Clone();
                    u2.AttachCosmetic(u34, v45);
                    local Attachment = v45.Attachment;
                    local Weld = Instance.new("Weld");
                    Weld.Parent = v45;
                    Weld.Part0 = v45;
                    Weld.Part1 = Head;
                    Weld.C0 = Attachment.CFrame;
                end;
            end)();
        end
    })[Race];

    if v46 then
        local success, result = pcall(v46);

        if not success then
            if u34 then
                u34 = u34.Name;
            end;

            warn(("ClothesHandler: race parts failed for %s (race=%s) -- %s"):format(tostring(u34), tostring(Race), (tostring(result))));
        end;
    end;
end;

function Give_Fake_Head(p47)
    -- upvalues: u2 (copy)
    if not p47:FindFirstChild("Head") then
        return;
    end;

    local v48 = p47.Head:Clone();
    v48.Transparency = 1;
    v48.Name = "FakeHead";
    local Humanoid = p47:FindFirstChild("Humanoid");

    for _, child in pairs(v48:GetChildren()) do
        if child.Name ~= "Mesh" then
            child:Destroy();
        end;
    end;

    local Weld = Instance.new("Weld", v48);
    Weld.Part0 = p47.Head;
    Weld.Part1 = v48;
    u2.NormalizeCosmetic(v48);

    if not Humanoid then
        return;
    end;

    v48.Parent = Humanoid;
end;

function Give_Height(p49, p50)
    -- upvalues: HeightHandler (copy)
    HeightHandler.GiveHeight(p49, p50);
end;

function RemoveHair(p51)
    -- upvalues: HairHandler (copy)
    for _, descendant in pairs(p51:GetDescendants()) do
        if HairHandler.IsHair(descendant) then
            descendant:Destroy();
        end;
    end;
end;

function RipClothingMesh(p52)
    -- upvalues: Particles (copy), SoundManager (copy), Debris (copy)
    local Color = p52.Color;
    local v53 = Particles["Cloth PFX"]:Clone();
    v53.Parent = p52;
    v53.Color = ColorSequence.new({ ColorSequenceKeypoint.new(0, Color), ColorSequenceKeypoint.new(0.5, Color), ColorSequenceKeypoint.new(1, Color) });
    v53:Emit(5);
    SoundManager.AddSound("Cloth Rip", {
        Parent = p52
    }, "Client");
    p52.Transparency = 1;
    Debris:AddItem(p52, 1);
end;

function removeBundles(p54, p55)
    local u56 = p54:FindFirstChildOfClass("Humanoid");

    if not u56 then
        error("Character has no humanoid.");
    end;

    local AppliedDescription = u56:GetAppliedDescription();
    AppliedDescription.Head = 0;
    AppliedDescription.LeftArm = 0;
    AppliedDescription.RightArm = 0;
    AppliedDescription.LeftLeg = 0;
    AppliedDescription.RightLeg = 0;
    AppliedDescription.Torso = 0;

    if (p55 and p55.CharacterData and p55.CharacterData.Gender) ~= "Female" then
        return;
    end;

    AppliedDescription.Torso = 48474356;
    local success, result = pcall(function() -- Line: 720
        -- upvalues: u56 (copy), AppliedDescription (copy)
        u56:ApplyDescription(AppliedDescription);
    end);

    if not success then
        warn(("ClothesHandler: female torso failed for %s -- %s"):format(p54.Name, (tostring(result))));
    end;
end;

function u2.ReapplyOutfit(p57: userdata, p58: any, p59: any) -- Line: 734
    -- upvalues: u2 (copy)
    for _, v in pairs(u2.GetClothingModels(p58)) do
        if v.Name == "Clothing" then
            v:Destroy();
        end;
    end;

    Give_OutFit(p58, p59);
end;

function u2.GiveClothes(p60: userdata, p61: any, p62: any) -- Line: 741
    -- upvalues: BaldData (copy), HairHandler (copy), u2 (copy), FaceHandler (copy), PupilColorHandler (copy), Create (copy)
    local Race = p62.CharacterData.Race.Race;
    local Arm = p62.Accessories.Arm;
    local v63 = tostring(Race or "");
    local v64;

    if p60 then
        v64 = p60:FindFirstChild("PlayerStats");
    else
        v64 = p60;
    end;

    if v64 then
        v64 = v64:FindFirstChild("Race", true);
    end;

    if v64 and v64:IsA("StringValue") then
        v64.Value = v63;
    end;

    if p61 then
        p61:SetAttribute("Race", v63);
    end;

    removeBundles(p61, p62);
    Remove_Spawn_Clothes(p61);
    Give_OutFit(p61, p62);
    Give_Skin_Color(p62, p61);
    Give_Fake_Head(p61);
    Give_Default_Race_Clothing(p61, p62);
    Give_Race_Parts(p62, p61);

    if BaldData[Race] then
        RemoveHair(p61);
    elseif HairHandler.UsesCustomHair(Race) then
        local success, result = pcall(HairHandler.ApplyBaseHair, p61, p62);

        if not success then
            warn(("ClothesHandler: custom hair failed for %s -- %s"):format(p61.Name, (tostring(result))));
            HairHandler.GiveHairColor(p61, p62);
        end;
    else
        HairHandler.GiveHairColor(p61, p62);
    end;

    if Arm == false then
        u2.RipArm(p61);
    end;

    FaceHandler.Give(p62, p61);
    PupilColorHandler.Give(p62, p61);
    u2.ApplyHairHide(p61, p62);

    for _, child in ipairs(p61:GetChildren()) do
        if child:IsA("Accessory") then
            for _, descendant in ipairs(child:GetDescendants()) do
                if descendant:IsA("BasePart") then
                    descendant.Anchored = false;
                    descendant.CanCollide = false;
                    descendant.CanQuery = false;
                    descendant.CanTouch = false;
                    descendant.Massless = true;
                end;
            end;
        end;
    end;

    Create.new(p60, "Loaded", 5);
end;

function u2.ApplyHairHide(p65, p66) -- Line: 812
    -- upvalues: Clothing (copy), HairHandler (copy)
    local v67 = p66 and p66.Accessories and p66.Accessories.Outfit;

    if v67 then
        if v67 == "" or v67 == "None" then
            v67 = false;
        else
            v67 = Clothing:FindFirstChild(v67, true);
        end;
    end;

    if v67 then
        v67 = v67:GetAttribute("HideHair") == true;
    end;

    p65:SetAttribute("HairHidden", v67 or nil);

    if v67 then
        pcall(HairHandler.HairTransparency, p65);

        return;
    end;

    pcall(HairHandler.HairTransparency, p65, "Off");
end;

function u2.SetBaseFit(p68: userdata, p69: any) -- Line: 826
    -- upvalues: u2 (copy), Clothing (copy)
    local Race = p69.CharacterData.Race.Race;

    if table.find(u2.Banned_From_Clothes, Race) then
        return "None";
    end;

    local v70 = Clothing["Race Clothes"][Race]["3D Clothes"];
    local v71 = #v70:GetChildren();

    return v70[Race .. " " .. math.random(1, v71)].Name;
end;

function u2.RipClothes(p72: userdata, p73: any, p74: any) -- Line: 839
    -- upvalues: u2 (copy)
    if p72 then
        p74.Accessories.Outfit = "None";
        p74.Accessories.Hat = "None";
        p74.Accessories.Back = "None";
    end;

    for _, v in pairs(u2.GetClothingModels(p73)) do
        u2.RipClothingModel(p73, v, nil, true);
    end;
end;

local u75 = {
    Clothing = "Outfit",
    ["Hat Clothing"] = "Hat",
    ["Back Clothing"] = "Back"
};

function u2.RipClothingModel(p76, p77, p78, p79) -- Line: 855
    -- upvalues: GlobalFunctions (copy), u75 (copy), Debris (copy), Particles (copy), SoundManager (copy)
    if not (p77 and p77.Parent) then
        return false;
    end;

    if p77:GetAttribute("Stretch") and not p79 then
        return false;
    end;

    local RootAndHumanoid = GlobalFunctions.GetRootAndHumanoid(p76);

    if p78 and (p78.Accessories and u75[p77.Name]) then
        p78.Accessories[u75[p77.Name]] = "None";
    end;

    Debris:AddItem(p77, 0.7);

    for _, child in pairs(p77:GetChildren()) do
        if child:IsA("MeshPart") then
            local Color = child.Color;
            local v80 = Particles["Cloth PFX"]:Clone();
            v80.Parent = child;
            v80.Color = ColorSequence.new({ ColorSequenceKeypoint.new(0, Color), ColorSequenceKeypoint.new(0.5, Color), ColorSequenceKeypoint.new(1, Color) });
            v80:Emit(5);

            if RootAndHumanoid then
                SoundManager.AddSound("Cloth Rip", {
                    Parent = RootAndHumanoid
                }, "Client");
            end;

            child.Transparency = 1;
            Debris:AddItem(child, 1);
        end;
    end;

    return true;
end;

function u2.RipHat(p81: userdata, p82: any, p83: any) -- Line: 882
    -- upvalues: GlobalFunctions (copy), u2 (copy), Debris (copy)
    if p81 then
        p83.Accessories.Hat = "None";
    end;

    local _, _ = GlobalFunctions.GetRootAndHumanoid(p82);
    p82:FindFirstChild("Head", true);

    for _, v in pairs(u2.GetClothingModels(p82)) do
        if v.Name == "Hat Clothing" then
            Debris:AddItem(v, 1);

            if v and v:IsA("Model") then
                for _, child in pairs(v:GetChildren()) do
                    if child:IsA("MeshPart") then
                        RipClothingMesh(child);
                    end;
                end;
            end;
        end;
    end;
end;

function u2.RipBack(p84: userdata, p85: any, p86: any) -- Line: 905
    -- upvalues: GlobalFunctions (copy), Debris (copy)
    if p84 then
        p86.Accessories.Back = "None";
    end;

    local _, _ = GlobalFunctions.GetRootAndHumanoid(p85);

    for _, child in pairs(p85.Torso:GetChildren()) do
        if child.Name == "Back Clothing" then
            Debris:AddItem(child, 1);

            if child and child:IsA("Model") then
                for _, child2 in pairs(child:GetChildren()) do
                    if child2:IsA("MeshPart") then
                        RipClothingMesh(child2);
                    end;
                end;
            end;
        end;
    end;
end;

function u2.ReplaceClothes(p87: userdata, u88: userdata, p89: any, p90: any) -- Line: 925
    -- upvalues: u2 (copy), Debris (copy), Clothing (copy), HairHandler (copy)
    local Clothes = p90.Clothes;
    local Hat = p90.Hat;
    local Back = p90.Back;

    if table.find(u2.Banned_From_Clothes, p89 and (p89.CharacterData.Race.Race or "Human") or "Human") then
        return "None";
    end;

    local function AddClothesToModel(p91, p92) -- Line: 936
        -- upvalues: u88 (copy), u2 (ref), Debris (ref)
        if not p91 then
            return;
        end;

        local v93 = p91:Clone();
        v93:ScaleTo((u88:GetScale()));

        for _, child in pairs(v93:GetChildren()) do
            local v94 = child;

            for _, descendant in pairs(u88:GetDescendants()) do
                if descendant:IsA("BasePart") and v94.Name == descendant.Name then
                    local v95 = v94:Clone();
                    v95.Name = p92 or "Clothing";
                    u2.AttachCosmetic(u88, v95);
                    local v96 = descendant;

                    for _, child2 in pairs(v95:GetChildren()) do
                        local v97 = child2:FindFirstChildOfClass("Attachment");

                        if child2 and v97 then
                            local Weld = Instance.new("Weld");
                            Weld.Parent = v95;
                            Weld.Part0 = child2;
                            Weld.Part1 = v96;
                            Weld.C0 = v97.CFrame;
                        end;
                    end;
                end;
            end;
        end;

        Debris:AddItem(v93, 1);
    end;

    local v98 = p89 and p89.Accessories and p89.Accessories.Hat;
    local v99 = p89 and p89.Accessories and p89.Accessories.Back;
    local v100 = Clothing:FindFirstChild(Clothes, true);

    if v100 then
        u2.RipClothes(p87, u88, p89);
        AddClothesToModel(v100);

        if p87 then
            p89.Accessories.Outfit = Clothes;

            if not Hat then
                p89.Accessories.Hat = v98;
            end;

            if not Back then
                p89.Accessories.Back = v99;
            end;
        end;

        u2.ApplyHairHide(u88, p89);
    elseif Clothes == "None" then
        u2.RipClothes(p87, u88, p89);
        u88:SetAttribute("HairHidden", nil);
        pcall(HairHandler.HairTransparency, u88, "Off");

        if p87 then
            p89.Accessories.Outfit = "";

            if not Hat then
                p89.Accessories.Hat = v98;
            end;

            if not Back then
                p89.Accessories.Back = v99;
            end;
        end;
    end;

    if Hat then
        u2.RipHat(p87, u88, p89);
        AddClothesToModel(Clothing:FindFirstChild(Hat, true), "Hat Clothing");

        if p87 then
            p89.Accessories.Hat = Hat or "";
        end;
    end;

    if Back then
        u2.RipBack(p87, u88, p89);
        AddClothesToModel(Clothing:FindFirstChild(Back, true), "Back Clothing");

        if p87 then
            p89.Accessories.Back = Back or "";
        end;
    end;

    if p89 then
        p89 = p89.Accessories.Arm;
    end;

    if p89 == false then
        u2.RipArm(u88);
    end;
end;

function u2.RipArm(p101) -- Line: 1033
    Remove_Arm(p101);
end;

function u2.RestoreArm(p102) -- Line: 1037
    local v103 = p102.Character or p102.CharacterAdded:Wait();
    Restore_Arm(v103);
end;

function u2.RestoreTail(p104, p105) -- Line: 1042
    local v106 = p104.Character or p104.CharacterAdded:Wait();
    Restore_Tail(v106);
end;

function u2.TransparentClothes(p107, p108) -- Line: 1047
    -- upvalues: GlobalFunctions (copy)
    if p108 == "Off" then
        for _, descendant in pairs(p107:GetDescendants()) do
            if (descendant.Name == "Clothing" or (descendant.Name == "Hat Clothing" or descendant.Name == "Back Clothing")) and descendant:IsA("Model") then
                for _, descendant2 in pairs(descendant:GetDescendants()) do
                    if descendant2:IsA("BasePart") or descendant2:IsA("MeshPart") then
                        GlobalFunctions.Tween({
                            Duration = 1,
                            Instance = descendant2
                        }, {
                            Transparency = 0
                        });
                    end;
                end;
            end;
        end;

        return;
    end;

    for _, descendant in pairs(p107:GetDescendants()) do
        if (descendant.Name == "Clothing" or (descendant.Name == "Hat Clothing" or descendant.Name == "Back Clothing")) and descendant:IsA("Model") then
            for _, descendant2 in pairs(descendant:GetDescendants()) do
                if descendant2:IsA("BasePart") or descendant2:IsA("MeshPart") then
                    GlobalFunctions.Tween({
                        Duration = 1,
                        Instance = descendant2
                    }, {
                        Transparency = 1
                    });
                end;
            end;
        end;
    end;
end;

return u2;