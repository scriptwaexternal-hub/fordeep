-- Decompiled with Potassium's decompiler.

local UserService = game:GetService("UserService");
local RunService = game:GetService("RunService");
local Function = require(script.Parent:WaitForChild("Function"));
local Signal = require(script.Parent:WaitForChild("Signal"));
local SafePlayerAdded = require(script.Parent:WaitForChild("SafePlayerAdded"));
local u1 = {};
local u2 = nil;

if RunService:IsServer() then
    u2 = Instance.new("RemoteFunction", script);
elseif RunService:IsClient() then
    u2 = script:WaitForChild("RemoteFunction");
end;

local u3 = {};
local u4 = {};
local u5 = nil;
u5 = Function.debounce(0.2, function() -- Line: 28
    -- upvalues: u3 (copy), u4 (copy), UserService (copy), u1 (copy), u5 (ref)
    for i in u3 do
        if #u4 == 200 then
            break;
        end;

        table.insert(u4, i);
    end;

    local success, result = pcall(UserService.GetUserInfosByUserIdsAsync, UserService, u4);
    local v6 = 0;

    while not success and v6 < 5 do
        v6 = v6 + 1;
        task.wait(2 ^ v6);
        success, result = pcall(UserService.GetUserInfosByUserIdsAsync, UserService, u4);
    end;

    if not (success and result) then
        warn((`getUserInfo failed: {result}`));
        task.delay(5, u5);

        return;
    end;

    for _, v in result do
        u1[v.Id] = v;
        local v7 = u3[v.Id];

        if v7 then
            v7:Fire(v);
            v7:Destroy();
        end;

        u3[v.Id] = nil;
    end;

    for _, v in u4 do
        if not u1[v] then
            local v8 = {
                Username = "Deleted",
                DisplayName = "Deleted",
                Deleted = true,
                Id = v
            };
            u1[v] = v8;
            local v9 = u3[v];

            if v9 then
                v9:Fire(v8);
                v9:Destroy();
            end;
        end;

        u3[v] = nil;
    end;

    table.clear(u4);

    if next(u3) then
        task.defer(u5);
    end;
end);

local function getUserInfo(p10: number, p11: boolean?) -- Line: 79
    -- upvalues: u1 (copy), RunService (copy), u2 (ref), u3 (copy), Signal (copy), u5 (ref)
    local v12 = tonumber(p10);

    if not v12 then
        return {
            Username = "Unknown",
            DisplayName = "Unknown",
            HasVerifiedBadge = false,
            Id = v12
        };
    end;

    if p11 or u1[v12] then
        return u1[v12];
    end;

    if RunService:IsClient() then
        local v13 = u2:InvokeServer(v12);

        if not v13 then
            return {
                Username = "Unknown",
                DisplayName = "Unknown",
                HasVerifiedBadge = false,
                Id = v12
            };
        end;

        u1[v12] = v13;

        return v13;
    end;

    local v14 = u3[v12];

    if v14 then
        return v14:Wait();
    end;

    local v15 = Signal.new();
    u3[v12] = v15;
    task.defer(u5);

    return v15:Wait();
end;

if RunService:IsServer() then
    function u2.OnServerInvoke(p16, p17) -- Line: 112
        -- upvalues: getUserInfo (copy)
        return getUserInfo(p17);
    end;
end;

SafePlayerAdded(function(p18) -- Line: 117
    -- upvalues: u1 (copy)
    u1[p18.UserId] = {
        Id = p18.UserId,
        Username = p18.Name,
        DisplayName = p18.DisplayName,
        HasVerifiedBadge = p18.HasVerifiedBadge
    };
end);

return getUserInfo;