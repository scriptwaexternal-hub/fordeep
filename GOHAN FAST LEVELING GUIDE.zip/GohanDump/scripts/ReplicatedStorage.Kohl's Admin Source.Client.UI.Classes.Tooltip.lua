-- Decompiled with Potassium's decompiler.

local Parent = require(script.Parent.Parent);
local BaseClass = require(script.Parent:WaitForChild("BaseClass"));
local u1 = Parent.state(Parent.LayerTop, "AbsoluteSize");
local u2 = Parent.state(Vector2.zero);
local u3 = Parent.state(Vector2.zero);
local u4 = Parent.state(Vector2.zero);
local u5 = nil;

local function init() -- Line: 10
    -- upvalues: u5 (ref), Parent (copy), u4 (copy), u1 (copy), u2 (copy), u3 (copy)
    u5 = Parent.new("TextLabel")({
        Parent = Parent.LayerTop,
        AutoLocalize = false,
        AutomaticSize = Enum.AutomaticSize.XY,
        Name = "Tooltip",
        ZIndex = 900000000,
        BackgroundColor3 = Parent.Theme.Primary,
        FontFace = Parent.Theme.Font,
        TextSize = Parent.Theme.FontSize,
        TextColor3 = Parent.Theme.PrimaryText,
        TextStrokeColor3 = Parent.Theme.Primary,
        TextStrokeTransparency = Parent.Theme.TextStrokeTransparency,
        TextXAlignment = Enum.TextXAlignment.Left,
        TextWrapped = true,
        RichText = true,
        Visible = false,

        Position = function() -- Line: 28, Name: Position
            -- upvalues: u4 (ref), u1 (ref), u2 (ref), u3 (ref), Parent (ref)
            local v6 = u4();
            local v7 = u1();
            local v8 = u2();
            local v9 = u3();
            local Offset = Parent.Theme.Padding().Offset;
            local v10 = v8.Y + v9.Y + Offset + Parent.TopbarInset().Height;
            local math_max_ret = math.max(0, v7.X - v6.X);
            local math_max_ret2 = math.max(0, v7.Y - v6.Y);
            local v11 = 0;

            if math_max_ret2 < v10 then
                v10 = v8.Y - v6.Y - Offset + Parent.TopbarInset().Height;

                if v10 < 0 then
                    v11 = v9.X + Offset;

                    if math_max_ret < v8.X + v9.X + Offset then
                        v11 = -(v6.X + Offset);
                    end;
                end;
            end;

            return UDim2.fromOffset(math.clamp(v8.X + v11, 0, math_max_ret), (math.clamp(v10, 0, math_max_ret2)));
        end,

        Parent.new("UICorner")({
            CornerRadius = Parent.Theme.CornerRadius
        }),
        Parent.new("UIPadding")({
            PaddingLeft = Parent.Theme.Padding,
            PaddingRight = Parent.Theme.Padding,
            PaddingTop = Parent.Theme.Padding,
            PaddingBottom = Parent.Theme.Padding
        }),
        Parent.new("UISizeConstraint")({
            MinSize = Vector2.new(8, 8),
            MaxSize = Vector2.new(256, (1 / 0))
        }),
        Parent.new("Stroke")({})
    });
    u4:_bindToProperty(u5, "AbsoluteSize");
end;

local u12 = { "Enabled", "Hovering", "Parent", "_instance" };

local function updateTooltip(p13: boolean, p14: userdata?, p15: table?) -- Line: 71
    -- upvalues: u5 (ref), u12 (copy), Parent (copy), u2 (copy), u3 (copy)
    u5.Visible = p13;

    if not (p13 and (p15 and (typeof(p14) == "Instance" and p14:IsA("GuiObject")))) then
        if u2._bindConnection then
            u2._bindConnection:Disconnect();
        end;

        if u3._bindConnection then
            u3._bindConnection:Disconnect();
        end;

        return;
    end;

    local table_clone_ret = table.clone(p15);

    for _, v in u12 do
        table_clone_ret[v] = nil;
    end;

    Parent.edit(u5, table_clone_ret);
    u2(p14.AbsolutePosition, true);
    u3(p14.AbsoluteSize, true);
    u2:_bindToProperty(p14, "AbsolutePosition");
    u3:_bindToProperty(p14, "AbsoluteSize");
end;

local u16 = {
    Enabled = true,
    Hovering = false,
    Visible = false,
    Text = "Example tooltip text.",
    FontFace = Parent.Theme.Font
};
local u17 = {
    Cache = {}
};
u17.__index = u17;
setmetatable(u17, BaseClass);

function u17.new(p18) -- Line: 107
    -- upvalues: u5 (ref), init (copy), u16 (copy), Parent (copy), u17 (copy), updateTooltip (copy), u2 (copy), u3 (copy)
    if not u5 then
        init();
    end;

    local table_clone_ret = table.clone(u16);
    Parent.makeStatefulDefaults(table_clone_ret, p18);

    if p18 then
        local Parent2 = p18.Parent;
        table.clear(p18);
        p18.Parent = Parent2;
    end;

    local u19 = nil;
    local u20 = {};
    local Hovering = table_clone_ret.Hovering;
    local u21 = nil;

    local function hover(p22) -- Line: 127
        -- upvalues: table_clone_ret (copy), u21 (ref), Hovering (copy)
        if not (p22 and table_clone_ret.Enabled._value) then
            table_clone_ret.Visible(false);

            return;
        end;

        local u23 = tick();
        u21 = u23;
        task.delay(0.4, function() -- Line: 131
            -- upvalues: u21 (ref), u23 (copy), Hovering (ref), table_clone_ret (ref)
            if u21 == u23 and Hovering._value then
                table_clone_ret.Visible(true);
            end;
        end);
    end;

    local function hoverEnter() -- Line: 141
        -- upvalues: Parent (ref), Hovering (copy)
        Parent.activateState(Hovering, "hover");
    end;

    local function hoverLeave() -- Line: 144
        -- upvalues: Parent (ref), Hovering (copy)
        Parent.deactivateState(Hovering, "hover");
    end;

    local function inputChanged(p24, p25) -- Line: 148
        -- upvalues: Parent (ref), u19 (ref), Hovering (copy)
        if p25 then
            return;
        end;

        if p24.UserInputType == Enum.UserInputType.MouseMovement or p24.UserInputType == Enum.UserInputType.Touch then
            if Parent.sinkInput(p24.Position.X, p24.Position.Y, u19) then
                Parent.deactivateState(Hovering, "hover");

                return;
            end;

            Parent.activateState(Hovering, "hover");
        end;
    end;

    local function inputEnded(p26) -- Line: 164
        -- upvalues: Parent (ref), Hovering (copy)
        if p26.UserInputType == Enum.UserInputType.MouseMovement or p26.UserInputType == Enum.UserInputType.Touch then
            Parent.deactivateState(Hovering, "hover");
        end;
    end;

    local function updateAdornee(p27: userdata) -- Line: 173
        -- upvalues: u19 (ref), u20 (copy), u17 (ref), table_clone_ret (copy), inputChanged (copy), inputEnded (copy), hoverEnter (copy), hoverLeave (copy)
        if u19 then
            for _, v in u20 do
                v:Disconnect();
            end;
        end;

        u17.Cache[p27] = table_clone_ret;
        table.insert(u20, p27.InputChanged:Connect(inputChanged));
        table.insert(u20, p27.InputEnded:Connect(inputEnded));
        table.insert(u20, p27.SelectionGained:Connect(hoverEnter));
        table.insert(u20, p27.SelectionLost:Connect(hoverLeave));
        u19 = p27;
    end;

    table_clone_ret._instance = Parent.new("Folder")({
        Name = "TooltipReference",
        [Parent.Clean] = {
            hoverState = Hovering,
            hoverDisconnect = Hovering:Connect(hover),
            table_clone_ret.Visible:Connect(function(p28) -- Line: 193
                -- upvalues: updateTooltip (ref), u19 (ref), table_clone_ret (copy), u5 (ref), u2 (ref), u3 (ref)
                if p28 then
                    updateTooltip(true, u19, table_clone_ret);

                    return;
                end;

                u5.Visible = false;

                if u2._bindConnection then
                    u2._bindConnection:Disconnect();
                end;

                if u3._bindConnection then
                    u3._bindConnection:Disconnect();
                end;
            end),
            Parent.UserInputService.TouchMoved:Connect(function() -- Line: 200
                -- upvalues: Hovering (copy)
                Hovering(false);
            end)
        },
        [Parent.Event] = {
            Parent = function() -- Line: 206, Name: Parent
                -- upvalues: table_clone_ret (copy), Parent (ref), updateAdornee (copy)
                local Parent2 = table_clone_ret._instance.Parent;

                if Parent2 and Parent2 ~= Parent.LayerTop then
                    updateAdornee(Parent2);
                end;
            end
        }
    });

    return setmetatable(table_clone_ret, u17);
end;

return u17;