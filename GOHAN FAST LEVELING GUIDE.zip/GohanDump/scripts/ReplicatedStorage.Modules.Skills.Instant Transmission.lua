-- Decompiled with Potassium's decompiler.

local Players = game:GetService("Players");
local ReplicatedStorage = game:GetService("ReplicatedStorage");
local LocalPlayer = Players.LocalPlayer;
local SkillRemote = ReplicatedStorage:WaitForChild("Remotes"):WaitForChild("SkillRemote");
local PlanetData = require(ReplicatedStorage:WaitForChild("Modules").Metadata.PlanetData.PlanetData);
local Color3_fromRGB_ret = Color3.fromRGB(16, 18, 24);
local Color3_fromRGB_ret2 = Color3.fromRGB(255, 255, 255);
local Color3_fromRGB_ret3 = Color3.fromRGB(255, 255, 255);
local Color3_fromRGB_ret4 = Color3.fromRGB(158, 166, 182);
local Color3_fromRGB_ret5 = Color3.fromRGB(255, 176, 46);
local Color3_fromRGB_ret6 = Color3.fromRGB(178, 132, 255);
local Color3_fromRGB_ret7 = Color3.fromRGB(92, 190, 255);
local Color3_fromRGB_ret8 = Color3.fromRGB(140, 235, 190);
local Color3_fromRGB_ret9 = Color3.fromRGB(255, 58, 61);
local Font_new_ret = Font.new("rbxasset://fonts/families/PermanentMarker.json", Enum.FontWeight.Regular);
local Font_new_ret2 = Font.new("rbxasset://fonts/families/AccanthisADFStd.json", Enum.FontWeight.Bold);
local Font_new_ret3 = Font.new("rbxasset://fonts/families/AccanthisADFStd.json", Enum.FontWeight.Regular);
local u1 = {
    Future = true,
    ["Time Chamber"] = true
};
local u2 = {
    Otherworld = true,
    HFIL = true
};
local u3 = {};
local u4 = nil;
local u5 = {};
local u6 = { "Locations", "Players", "Planets", "Realms" };
local u7 = 1;
local u8 = nil;
local u9 = nil;
local u10 = nil;
local u11 = nil;
local u12 = nil;
local u13 = {};
local u14 = nil;

local function track(p15) -- Line: 104
    -- upvalues: u13 (copy)
    table.insert(u13, p15);

    return p15;
end;

local function disconnectAll() -- Line: 109
    -- upvalues: u13 (copy)
    for _, v in ipairs(u13) do
        v:Disconnect();
    end;

    table.clear(u13);
end;

local function characterNameOf(p16) -- Line: 122
    local Character = p16.Character;

    if not Character then
        return nil;
    end;

    local Attribute = Character:GetAttribute("CharacterName");

    if type(Attribute) == "string" and Attribute ~= "" then
        return Attribute;
    end;

    local v17 = Character:FindFirstChildOfClass("Humanoid");

    if v17 then
        v17 = v17.DisplayName;
    end;

    if not v17 or v17 == "" then
        return nil;
    end;

    local v18 = v17:split("\n")[1];
    local v19 = (v18:match("^(.-)%s*%-?%s*\"") or v18):match("^%s*(.-)%s*$");

    if v19 == "" or not v19 then
        v19 = nil;
    end;

    return v19;
end;

local function sendDestination(u20) -- Line: 146
    -- upvalues: LocalPlayer (copy), u14 (ref), SkillRemote (copy), u3 (copy)
    if type(u20) ~= "string" or u20 == "" then
        return;
    end;

    local Character = LocalPlayer.Character;

    if Character then
        Character = Character:FindFirstChild("Using Move") ~= nil;
    end;

    if not Character and (u14 and u14.Parent) then
        pcall(u14.Activate, u14);
    end;

    task.spawn(function() -- Line: 157
        -- upvalues: SkillRemote (ref), u20 (copy)
        pcall(function() -- Line: 158
            -- upvalues: SkillRemote (ref), u20 (ref)
            SkillRemote:InvokeServer({
                Action = "Destination",
                Destination = u20
            });
        end);
    end);
    u3.Close();
end;

local function corner(p21, p22) -- Line: 168
    local UICorner = Instance.new("UICorner");
    UICorner.CornerRadius = UDim.new(0, p22);
    UICorner.Parent = p21;

    return UICorner;
end;

local function padding(p23, p24) -- Line: 175
    local UIPadding = Instance.new("UIPadding");
    UIPadding.PaddingTop = UDim.new(0, p24);
    UIPadding.PaddingBottom = UDim.new(0, p24);
    UIPadding.PaddingLeft = UDim.new(0, p24);
    UIPadding.PaddingRight = UDim.new(0, p24);
    UIPadding.Parent = p23;

    return UIPadding;
end;

local function buildList(p25, p26) -- Line: 187
    -- upvalues: padding (copy)
    local ScrollingFrame = Instance.new("ScrollingFrame");
    ScrollingFrame.Name = "List";
    ScrollingFrame.Position = UDim2.new(0, 0, 0, 28);
    ScrollingFrame.Size = UDim2.new(1, 0, 1, -28);
    ScrollingFrame.BackgroundTransparency = 1;
    ScrollingFrame.BorderSizePixel = 0;
    ScrollingFrame.CanvasSize = UDim2.new();
    ScrollingFrame.AutomaticCanvasSize = Enum.AutomaticSize.Y;
    ScrollingFrame.ScrollingDirection = Enum.ScrollingDirection.Y;
    ScrollingFrame.ScrollBarThickness = 3;
    ScrollingFrame.ScrollBarImageColor3 = p26;
    ScrollingFrame.ScrollBarImageTransparency = 0.4;
    ScrollingFrame.Visible = false;
    ScrollingFrame.Parent = p25;
    padding(ScrollingFrame, 6);
    local UIListLayout = Instance.new("UIListLayout");
    UIListLayout.FillDirection = Enum.FillDirection.Vertical;
    UIListLayout.SortOrder = Enum.SortOrder.LayoutOrder;
    UIListLayout.HorizontalAlignment = Enum.HorizontalAlignment.Center;
    UIListLayout.Padding = UDim.new(0, 4);
    UIListLayout.Parent = ScrollingFrame;

    return ScrollingFrame;
end;

local function buildEmptyRow(p27, p28) -- Line: 214
    -- upvalues: Font_new_ret3 (copy), Color3_fromRGB_ret4 (copy)
    local TextLabel = Instance.new("TextLabel");
    TextLabel.Name = "Empty";
    TextLabel.Size = UDim2.new(1, 0, 0, 30);
    TextLabel.BackgroundTransparency = 1;
    TextLabel.FontFace = Font_new_ret3;
    TextLabel.Text = p28;
    TextLabel.TextSize = 12;
    TextLabel.TextColor3 = Color3_fromRGB_ret4;
    TextLabel.TextWrapped = true;
    TextLabel.Parent = p27;
end;

local function buildRow(p29, p30, p31, p32, u33) -- Line: 232
    -- upvalues: Color3_fromRGB_ret2 (copy), sendDestination (copy)
    local TextButton = Instance.new("TextButton");
    TextButton.Size = UDim2.new(1, 0, 0, p30);
    TextButton.LayoutOrder = p31;
    TextButton.BackgroundColor3 = Color3_fromRGB_ret2;
    TextButton.BackgroundTransparency = 0.93;
    TextButton.BorderSizePixel = 0;
    TextButton.AutoButtonColor = false;
    TextButton.Text = "";
    TextButton.Parent = p29;
    local UICorner = Instance.new("UICorner");
    UICorner.CornerRadius = UDim.new(0, 5);
    UICorner.Parent = TextButton;
    TextButton.MouseEnter:Connect(function() -- Line: 244
        -- upvalues: TextButton (copy)
        TextButton.BackgroundTransparency = 0.82;
    end);
    TextButton.MouseLeave:Connect(function() -- Line: 245
        -- upvalues: TextButton (copy)
        TextButton.BackgroundTransparency = 0.93;
    end);
    TextButton.MouseButton1Click:Connect(function() -- Line: 246
        -- upvalues: sendDestination (ref), u33 (copy)
        sendDestination(u33);
    end);
    local Frame = Instance.new("Frame");
    Frame.AnchorPoint = Vector2.new(0, 0.5);
    Frame.Position = UDim2.new(0, 6, 0.5, 0);
    Frame.Size = UDim2.new(0, 3, 0, (math.floor(p30 * 0.5)));
    Frame.BackgroundColor3 = p32;
    Frame.BackgroundTransparency = 0.25;
    Frame.BorderSizePixel = 0;
    Frame.Parent = TextButton;
    local UICorner2 = Instance.new("UICorner");
    UICorner2.CornerRadius = UDim.new(0, 2);
    UICorner2.Parent = Frame;

    return TextButton;
end;

local function clearList(p34) -- Line: 261
    for _, child in ipairs(p34:GetChildren()) do
        if not (child:IsA("UIListLayout") or child:IsA("UIPadding")) then
            child:Destroy();
        end;
    end;
end;

local function simpleLabel(p35, p36) -- Line: 269
    -- upvalues: Font_new_ret2 (copy), Color3_fromRGB_ret3 (copy)
    local TextLabel = Instance.new("TextLabel");
    TextLabel.BackgroundTransparency = 1;
    TextLabel.Position = UDim2.new(0, 15, 0, 0);
    TextLabel.Size = UDim2.new(1, -20, 1, 0);
    TextLabel.FontFace = Font_new_ret2;
    TextLabel.Text = p36;
    TextLabel.TextSize = 13;
    TextLabel.TextColor3 = Color3_fromRGB_ret3;
    TextLabel.TextXAlignment = Enum.TextXAlignment.Left;
    TextLabel.TextTruncate = Enum.TextTruncate.AtEnd;
    TextLabel.Parent = p35;
end;

local function refreshLocations() -- Line: 283
    -- upvalues: u5 (ref), clearList (copy), Font_new_ret3 (copy), Color3_fromRGB_ret4 (copy), buildRow (copy), Color3_fromRGB_ret5 (copy), simpleLabel (copy), u3 (copy)
    local Locations = u5.Locations;

    if not (Locations and (Locations.List and Locations.List.Parent)) then
        return;
    end;

    clearList(Locations.List);
    local v37 = workspace.World:FindFirstChild("TP Locations", true);
    local v38 = {};

    if v37 then
        for _, descendant in ipairs(v37:GetDescendants()) do
            if descendant:IsA("BasePart") then
                table.insert(v38, descendant.Name);
            end;
        end;
    end;

    table.sort(v38);
    Locations.Count = #v38;

    if #v38 == 0 then
        local List = Locations.List;
        local TextLabel = Instance.new("TextLabel");
        TextLabel.Name = "Empty";
        TextLabel.Size = UDim2.new(1, 0, 0, 30);
        TextLabel.BackgroundTransparency = 1;
        TextLabel.FontFace = Font_new_ret3;
        TextLabel.Text = "No teleport points on this map.";
        TextLabel.TextSize = 12;
        TextLabel.TextColor3 = Color3_fromRGB_ret4;
        TextLabel.TextWrapped = true;
        TextLabel.Parent = List;
    else
        for i, v in ipairs(v38) do
            simpleLabel(buildRow(Locations.List, 26, i, Color3_fromRGB_ret5, v), v);
        end;
    end;

    u3._syncHeader();
end;

local function refreshPlanetPage(p39, p40, p41, p42) -- Line: 321
    -- upvalues: u5 (ref), clearList (copy), PlanetData (copy), u1 (copy), u2 (copy), Font_new_ret3 (copy), Color3_fromRGB_ret4 (copy), buildRow (copy), simpleLabel (copy), u3 (copy)
    local v43 = u5[p39];

    if not (v43 and (v43.List and v43.List.Parent)) then
        return;
    end;

    clearList(v43.List);
    local v44 = {};

    for i in pairs(PlanetData) do
        if not u1[i] and u2[i] == true == p40 then
            table.insert(v44, i);
        end;
    end;

    table.sort(v44);
    v43.Count = #v44;

    if #v44 == 0 then
        local List = v43.List;
        local TextLabel = Instance.new("TextLabel");
        TextLabel.Name = "Empty";
        TextLabel.Size = UDim2.new(1, 0, 0, 30);
        TextLabel.BackgroundTransparency = 1;
        TextLabel.FontFace = Font_new_ret3;
        TextLabel.Text = p42;
        TextLabel.TextSize = 12;
        TextLabel.TextColor3 = Color3_fromRGB_ret4;
        TextLabel.TextWrapped = true;
        TextLabel.Parent = List;
    else
        for i, v in ipairs(v44) do
            simpleLabel(buildRow(v43.List, 26, i, p41, v), v);
        end;
    end;

    u3._syncHeader();
end;

local function refreshPlanets() -- Line: 349
    -- upvalues: refreshPlanetPage (copy), Color3_fromRGB_ret6 (copy)
    refreshPlanetPage("Planets", false, Color3_fromRGB_ret6, "No planets available from here.");
end;

local function refreshRealms() -- Line: 353
    -- upvalues: refreshPlanetPage (copy), Color3_fromRGB_ret8 (copy)
    refreshPlanetPage("Realms", true, Color3_fromRGB_ret8, "No realms available from here.");
end;

local function refreshPlayers() -- Line: 357
    -- upvalues: u5 (ref), clearList (copy), Players (copy), LocalPlayer (copy), characterNameOf (copy), Font_new_ret3 (copy), Color3_fromRGB_ret4 (copy), buildRow (copy), Color3_fromRGB_ret7 (copy), Font_new_ret2 (copy), Color3_fromRGB_ret3 (copy), u3 (copy)
    local Players2 = u5.Players;

    if not (Players2 and (Players2.List and Players2.List.Parent)) then
        return;
    end;

    clearList(Players2.List);
    local v45 = {};

    for _, v in ipairs(Players:GetPlayers()) do
        if v ~= LocalPlayer then
            local v46 = characterNameOf(v);

            if v46 then
                table.insert(v45, {
                    Name = v46,
                    User = v.Name
                });
            end;
        end;
    end;

    table.sort(v45, function(p47, p48) -- Line: 371
        return p47.Name:lower() < p48.Name:lower();
    end);
    Players2.Count = #v45;

    if #v45 == 0 then
        local List = Players2.List;
        local TextLabel = Instance.new("TextLabel");
        TextLabel.Name = "Empty";
        TextLabel.Size = UDim2.new(1, 0, 0, 30);
        TextLabel.BackgroundTransparency = 1;
        TextLabel.FontFace = Font_new_ret3;
        TextLabel.Text = "Nobody else is here.";
        TextLabel.TextSize = 12;
        TextLabel.TextColor3 = Color3_fromRGB_ret4;
        TextLabel.TextWrapped = true;
        TextLabel.Parent = List;
    else
        for i, v in ipairs(v45) do
            local v49 = buildRow(Players2.List, 38, i, Color3_fromRGB_ret7, v.User);
            local TextLabel = Instance.new("TextLabel");
            TextLabel.BackgroundTransparency = 1;
            TextLabel.Position = UDim2.new(0, 15, 0, 3);
            TextLabel.Size = UDim2.new(1, -20, 0, 18);
            TextLabel.FontFace = Font_new_ret2;
            TextLabel.Text = v.Name;
            TextLabel.TextSize = 13;
            TextLabel.TextColor3 = Color3_fromRGB_ret3;
            TextLabel.TextXAlignment = Enum.TextXAlignment.Left;
            TextLabel.TextTruncate = Enum.TextTruncate.AtEnd;
            TextLabel.Parent = v49;
            local TextLabel2 = Instance.new("TextLabel");
            TextLabel2.BackgroundTransparency = 1;
            TextLabel2.Position = UDim2.new(0, 15, 0, 19);
            TextLabel2.Size = UDim2.new(1, -20, 0, 14);
            TextLabel2.FontFace = Font_new_ret3;
            TextLabel2.Text = "@" .. v.User;
            TextLabel2.TextSize = 11;
            TextLabel2.TextColor3 = Color3_fromRGB_ret4;
            TextLabel2.TextXAlignment = Enum.TextXAlignment.Left;
            TextLabel2.TextTruncate = Enum.TextTruncate.AtEnd;
            TextLabel2.Parent = v49;
        end;
    end;

    u3._syncHeader();
end;

local function watchPlayer(p50) -- Line: 410
    -- upvalues: refreshPlayers (copy), u13 (copy)
    local function watchCharacter(p51) -- Line: 411
        -- upvalues: refreshPlayers (ref), u13 (ref)
        local v52 = p51:GetAttributeChangedSignal("CharacterName"):Connect(refreshPlayers);
        table.insert(u13, v52);
        refreshPlayers();
    end;

    if p50.Character then
        local v53 = p50.Character:GetAttributeChangedSignal("CharacterName"):Connect(refreshPlayers);
        table.insert(u13, v53);
        refreshPlayers();
    end;

    local v54 = p50.CharacterAdded:Connect(watchCharacter);
    table.insert(u13, v54);
end;

local u55 = {
    Locations = Color3_fromRGB_ret5,
    Players = Color3_fromRGB_ret7,
    Planets = Color3_fromRGB_ret6,
    Realms = Color3_fromRGB_ret8
};

function u3._syncHeader() -- Line: 429
    -- upvalues: u6 (copy), u7 (ref), u5 (ref), u8 (ref), u9 (ref), u55 (copy), u10 (ref), u11 (ref), u12 (ref)
    local v56 = u6[u7];
    local v57 = u5[v56];

    if not (v57 and (u8 and u9)) then
        return;
    end;

    local v58 = u55[v56];
    u8.Text = v56;
    u8.TextColor3 = v58;
    u9.Text = tostring(v57.Count or 0);
    u9.TextColor3 = v58;

    if u10 then
        u10.Color = v58;
    end;

    if u11 then
        u11.BackgroundColor3 = v58;
    end;

    if u12 then
        u12.BackgroundColor3 = v58;
    end;
end;

local function showPage(p59) -- Line: 444
    -- upvalues: u7 (ref), u6 (copy), u5 (ref), u3 (copy)
    u7 = (p59 - 1) % #u6 + 1;

    for i, v in pairs(u5) do
        v.List.Visible = i == u6[u7];
    end;

    u3._syncHeader();
end;

function u3.Close() -- Line: 453
    -- upvalues: u13 (copy), u4 (ref), u5 (ref), u8 (ref), u9 (ref), u10 (ref), u11 (ref), u12 (ref), u7 (ref)
    for _, v in ipairs(u13) do
        v:Disconnect();
    end;

    table.clear(u13);

    if u4 then
        u4:Destroy();
    end;

    u4 = nil;
    u5 = {};
    u8 = nil;
    u9 = nil;
    u10 = nil;
    u11 = nil;
    u12 = nil;
    u7 = 1;
end;

function u3.OnEquipped(p60, p61) -- Line: 468
    -- upvalues: u14 (ref), u3 (copy), LocalPlayer (copy), u4 (ref), Color3_fromRGB_ret (copy), u10 (ref), u12 (ref), u11 (ref), u8 (ref), Font_new_ret (copy), u9 (ref), Font_new_ret2 (copy), u6 (copy), u5 (ref), buildList (copy), u55 (copy), Color3_fromRGB_ret4 (copy), Color3_fromRGB_ret3 (copy), u13 (copy), showPage (copy), u7 (ref), Font_new_ret3 (copy), Color3_fromRGB_ret9 (copy), refreshLocations (copy), refreshPlayers (copy), refreshPlanetPage (copy), Color3_fromRGB_ret6 (copy), Color3_fromRGB_ret8 (copy), Players (copy)
    u14 = p61;
    u3.Close();
    local PopupGui = LocalPlayer:WaitForChild("PlayerGui"):WaitForChild("PopupGui");

    for _, child in ipairs(PopupGui:GetChildren()) do
        if child.Name == "InstantTransmissionPicker" or child.Name == "LocationList" then
            child:Destroy();
        end;
    end;

    local Frame = Instance.new("Frame");
    Frame.Name = "InstantTransmissionPicker";
    Frame.AnchorPoint = Vector2.new(1, 0.5);
    Frame.Position = UDim2.new(1, -24, 0.5, 0);
    Frame.Size = UDim2.new(0, 226, 0, 254);
    Frame.BackgroundTransparency = 1;
    Frame.Parent = PopupGui;
    u4 = Frame;
    Instance.new("UIDragDetector").Parent = Frame;
    local Frame2 = Instance.new("Frame");
    Frame2.Name = "Panel";
    Frame2.Size = UDim2.new(0, 190, 0, 236);
    Frame2.BackgroundColor3 = Color3_fromRGB_ret;
    Frame2.BackgroundTransparency = 0;
    Frame2.BorderSizePixel = 0;
    Frame2.ClipsDescendants = true;
    Frame2.Parent = Frame;
    local UICorner = Instance.new("UICorner");
    UICorner.CornerRadius = UDim.new(0, 9);
    UICorner.Parent = Frame2;
    u10 = Instance.new("UIStroke");
    u10.Thickness = 1;
    u10.Transparency = 0.62;
    u10.Parent = Frame2;
    u12 = Instance.new("Frame");
    u12.Name = "Header";
    u12.Size = UDim2.new(1, 0, 0, 28);
    u12.BackgroundTransparency = 0.88;
    u12.BorderSizePixel = 0;
    u12.Parent = Frame2;
    local UIGradient = Instance.new("UIGradient");
    UIGradient.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(1, 1) });
    UIGradient.Parent = u12;
    u11 = Instance.new("Frame");
    u11.Name = "Underline";
    u11.Position = UDim2.new(0, 0, 0, 26);
    u11.Size = UDim2.new(1, 0, 0, 2);
    u11.BorderSizePixel = 0;
    u11.Parent = Frame2;
    u8 = Instance.new("TextLabel");
    u8.Name = "Title";
    u8.BackgroundTransparency = 1;
    u8.Position = UDim2.new(0, 9, 0, 0);
    u8.Size = UDim2.new(1, -44, 0, 26);
    u8.FontFace = Font_new_ret;
    u8.Text = "Locations";
    u8.TextSize = 14;
    u8.TextXAlignment = Enum.TextXAlignment.Left;
    u8.Parent = Frame2;
    u9 = Instance.new("TextLabel");
    u9.Name = "Count";
    u9.BackgroundTransparency = 1;
    u9.AnchorPoint = Vector2.new(1, 0);
    u9.Position = UDim2.new(1, -9, 0, 0);
    u9.Size = UDim2.new(0, 30, 0, 26);
    u9.FontFace = Font_new_ret2;
    u9.Text = "0";
    u9.TextSize = 12;
    u9.TextTransparency = 0.25;
    u9.TextXAlignment = Enum.TextXAlignment.Right;
    u9.Parent = Frame2;

    for _, v in ipairs(u6) do
        u5[v] = {
            Count = 0,
            List = buildList(Frame2, u55[v])
        };
    end;

    local TextButton = Instance.new("TextButton");
    TextButton.Name = "Cycle";
    TextButton.AnchorPoint = Vector2.new(0, 0.5);
    TextButton.Position = UDim2.new(0, 196, 0.5, 0);
    TextButton.Size = UDim2.new(0, 30, 0, 30);
    TextButton.BackgroundColor3 = Color3_fromRGB_ret;
    TextButton.BorderSizePixel = 0;
    TextButton.AutoButtonColor = true;
    TextButton.Text = "";
    TextButton.ZIndex = 5;
    TextButton.Parent = Frame;
    local UICorner2 = Instance.new("UICorner");
    UICorner2.CornerRadius = UDim.new(0, 8);
    UICorner2.Parent = TextButton;
    local UIStroke = Instance.new("UIStroke");
    UIStroke.Color = Color3_fromRGB_ret4;
    UIStroke.Thickness = 1;
    UIStroke.Transparency = 0.6;
    UIStroke.Parent = TextButton;
    local Frame3 = Instance.new("Frame");
    Frame3.Name = "Ring";
    Frame3.AnchorPoint = Vector2.new(0.5, 0.5);
    Frame3.Position = UDim2.new(0.5, 0, 0.5, 0);
    Frame3.Size = UDim2.new(0, 16, 0, 16);
    Frame3.BackgroundTransparency = 1;
    Frame3.ZIndex = 6;
    Frame3.Parent = TextButton;
    local UICorner3 = Instance.new("UICorner");
    UICorner3.CornerRadius = UDim.new(0, 16);
    UICorner3.Parent = Frame3;
    local UIStroke2 = Instance.new("UIStroke");
    UIStroke2.Color = Color3_fromRGB_ret3;
    UIStroke2.Thickness = 2;
    UIStroke2.Parent = Frame3;
    local Frame4 = Instance.new("Frame");
    Frame4.Name = "Notch";
    Frame4.AnchorPoint = Vector2.new(0.5, 0.5);
    Frame4.Position = UDim2.new(1, 0, 0.18, 0);
    Frame4.Size = UDim2.new(0, 7, 0, 7);
    Frame4.BackgroundColor3 = Color3_fromRGB_ret;
    Frame4.BorderSizePixel = 0;
    Frame4.ZIndex = 7;
    Frame4.Parent = Frame3;
    local Frame5 = Instance.new("Frame");
    Frame5.Name = "Head";
    Frame5.AnchorPoint = Vector2.new(0.5, 0.5);
    Frame5.Position = UDim2.new(1, 0, 0.16, 0);
    Frame5.Size = UDim2.new(0, 6, 0, 6);
    Frame5.Rotation = 45;
    Frame5.BackgroundColor3 = Color3_fromRGB_ret3;
    Frame5.BorderSizePixel = 0;
    Frame5.ZIndex = 8;
    Frame5.Parent = Frame3;
    local v62 = TextButton.MouseButton1Down:Connect(function() -- Line: 645
        -- upvalues: Frame3 (copy)
        Frame3.Rotation = Frame3.Rotation + 90;
    end);
    table.insert(u13, v62);
    local v63 = TextButton.MouseButton1Click:Connect(function() -- Line: 649
        -- upvalues: showPage (ref), u7 (ref)
        showPage(u7 + 1);
    end);
    table.insert(u13, v63);
    local TextLabel = Instance.new("TextLabel");
    TextLabel.Name = "Hint";
    TextLabel.AnchorPoint = Vector2.new(0, 1);
    TextLabel.Position = UDim2.new(0, 0, 1, 0);
    TextLabel.Size = UDim2.new(0, 190, 0, 14);
    TextLabel.BackgroundTransparency = 1;
    TextLabel.FontFace = Font_new_ret3;
    TextLabel.Text = "Click to warp, or say a name in chat";
    TextLabel.TextSize = 11;
    TextLabel.TextColor3 = Color3_fromRGB_ret4;
    TextLabel.Parent = Frame;
    local TextButton2 = Instance.new("TextButton");
    TextButton2.Name = "Exit";
    TextButton2.AnchorPoint = Vector2.new(1, 0);
    TextButton2.Position = UDim2.new(0, 195, 0, -5);
    TextButton2.Size = UDim2.new(0, 20, 0, 20);
    TextButton2.BackgroundColor3 = Color3_fromRGB_ret9;
    TextButton2.BorderSizePixel = 0;
    TextButton2.AutoButtonColor = true;
    TextButton2.FontFace = Font_new_ret;
    TextButton2.Text = "X";
    TextButton2.TextSize = 12;
    TextButton2.TextColor3 = Color3_fromRGB_ret3;
    TextButton2.ZIndex = 6;
    TextButton2.Parent = Frame;
    local UICorner4 = Instance.new("UICorner");
    UICorner4.CornerRadius = UDim.new(0, 10);
    UICorner4.Parent = TextButton2;
    local v64 = TextButton2.MouseButton1Click:Connect(function() -- Line: 685
        -- upvalues: u3 (ref)
        u3.Close();
    end);
    table.insert(u13, v64);
    refreshLocations();
    refreshPlayers();
    refreshPlanetPage("Planets", false, Color3_fromRGB_ret6, "No planets available from here.");
    refreshPlanetPage("Realms", true, Color3_fromRGB_ret8, "No realms available from here.");
    u7 = 0 % #u6 + 1;

    for i, v in pairs(u5) do
        v.List.Visible = i == u6[u7];
    end;

    u3._syncHeader();
    local v65 = workspace.World:FindFirstChild("TP Locations", true);

    if v65 then
        local v66 = v65.ChildAdded:Connect(refreshLocations);
        table.insert(u13, v66);
        local v67 = v65.ChildRemoved:Connect(refreshLocations);
        table.insert(u13, v67);
    end;

    for _, v in ipairs(Players:GetPlayers()) do
        if v ~= LocalPlayer then
            local function v70(p68) -- Line: 411
                -- upvalues: refreshPlayers (ref), u13 (ref)
                local v69 = p68:GetAttributeChangedSignal("CharacterName"):Connect(refreshPlayers);
                table.insert(u13, v69);
                refreshPlayers();
            end;

            if v.Character then
                local v71 = v.Character:GetAttributeChangedSignal("CharacterName"):Connect(refreshPlayers);
                table.insert(u13, v71);
                refreshPlayers();
            end;

            local v72 = v.CharacterAdded:Connect(v70);
            table.insert(u13, v72);
        end;
    end;

    local v79 = Players.PlayerAdded:Connect(function(p73) -- Line: 708
        -- upvalues: refreshPlayers (ref), u13 (ref)
        local function v76(p74) -- Line: 411
            -- upvalues: refreshPlayers (ref), u13 (ref)
            local v75 = p74:GetAttributeChangedSignal("CharacterName"):Connect(refreshPlayers);
            table.insert(u13, v75);
            refreshPlayers();
        end;

        if p73.Character then
            local v77 = p73.Character:GetAttributeChangedSignal("CharacterName"):Connect(refreshPlayers);
            table.insert(u13, v77);
            refreshPlayers();
        end;

        local v78 = p73.CharacterAdded:Connect(v76);
        table.insert(u13, v78);
        refreshPlayers();
    end);
    table.insert(u13, v79);
    local v80 = Players.PlayerRemoving:Connect(function() -- Line: 712
        -- upvalues: refreshPlayers (ref)
        task.defer(refreshPlayers);
    end);
    table.insert(u13, v80);
end;

function u3.OnUnequipped(p81, p82) -- Line: 718
    -- upvalues: u14 (ref), u3 (copy)
    u14 = nil;
    u3.Close();
end;

return u3;