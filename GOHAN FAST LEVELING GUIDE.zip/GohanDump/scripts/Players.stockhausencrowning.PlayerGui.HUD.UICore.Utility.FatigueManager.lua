-- Decompiled with Potassium's decompiler.

local Players = game:GetService("Players");
local Assets = game:GetService("ReplicatedStorage").Assets;
local LocalPlayer = Players.LocalPlayer;

local function getFatigueGui(p1) -- Line: 18
    -- upvalues: Assets (copy)
    local FatigueGui = p1:FindFirstChild("FatigueGui");

    if not FatigueGui then
        FatigueGui = Assets.Gui.Stamina.FatigueGui:Clone();
        FatigueGui.Enabled = false;
        FatigueGui.Adornee = p1:FindFirstChild("HumanoidRootPart");
        FatigueGui.Parent = p1;
    end;

    if not FatigueGui.Adornee then
        FatigueGui.Adornee = p1:FindFirstChild("HumanoidRootPart");
    end;

    return FatigueGui;
end;

return {
    Update = function(p2) -- Line: 34, Name: Update
        -- upvalues: LocalPlayer (copy), getFatigueGui (copy)
        local Character = LocalPlayer.Character;

        if not Character then
            return;
        end;

        local v3 = getFatigueGui(Character);
        v3.Meter.Bar:TweenSize(UDim2.new(p2 / 100, 0, 1, 0), "Out", "Sine", 0.1, true);
        v3.Enabled = p2 > 0;
    end
};