-- Decompiled with Potassium's decompiler.

local Players = game:GetService("Players");
local UserInputService = game:GetService("UserInputService");
local ContextActionService = game:GetService("ContextActionService");
local ReplicatedStorage = game:GetService("ReplicatedStorage");
local LocalPlayer = Players.LocalPlayer;
local PlayerGui = LocalPlayer:WaitForChild("PlayerGui");
local ServerRemote = ReplicatedStorage:WaitForChild("Remotes"):WaitForChild("ServerRemote");
local Modules = ReplicatedStorage:WaitForChild("Modules");
local Platform = require(Modules.Shared.Platform);
local GamepadGlyphs = require(Modules.Shared.GamepadGlyphs);
local ControlData = require(Modules.Metadata.ControlData.ControlData);
local u1 = { "HUD" };
local Color3_fromRGB_ret = Color3.fromRGB(44, 44, 45);
local Color3_fromRGB_ret2 = Color3.fromRGB(28, 28, 30);
local Color3_fromRGB_ret3 = Color3.fromRGB(255, 255, 255);
local Color3_fromRGB_ret4 = Color3.fromRGB(216, 213, 205);
local Color3_fromRGB_ret5 = Color3.fromRGB(0, 0, 0);
local Color3_fromRGB_ret6 = Color3.fromRGB(88, 214, 106);
local Arcade = Enum.Font.Arcade;
local Bangers = Enum.Font.Bangers;

local function kamiStroke(p2, p3) -- Line: 39
    -- upvalues: Color3_fromRGB_ret5 (copy)
    local UIStroke = Instance.new("UIStroke");
    local Border = Enum.ApplyStrokeMode.Border;
    UIStroke.Color = Color3_fromRGB_ret5;
    UIStroke.Thickness = p3 or 2;
    UIStroke.ApplyStrokeMode = Border;
    UIStroke.Parent = p2;
end;

local function kamiText(p4) -- Line: 44
    -- upvalues: Color3_fromRGB_ret5 (copy)
    p4.TextStrokeColor3 = Color3_fromRGB_ret5;
    p4.TextStrokeTransparency = 0.5;
end;

local u5 = {};
local u6 = 0;
local u7 = {};
local u8 = false;
local u9 = nil;
local u10 = nil;
local u11 = nil;

local function hintText() -- Line: 68
    -- upvalues: Platform (copy), ControlData (copy), GamepadGlyphs (copy)
    if Platform.IsTouch() then
        return "TAP TO DROP";
    end;

    if not Platform.PreferGamepadGlyphs() then
        return "RIGHT CLICK TO DROP";
    end;

    local _, v12 = GamepadGlyphs.Describe(ControlData.Controls.Combat.Heavy);

    return ("PRESS  %s  TO DROP"):format(v12 or "Y");
end;

local function build() -- Line: 78
    -- upvalues: u9 (ref), PlayerGui (copy), Color3_fromRGB_ret (copy), Color3_fromRGB_ret5 (copy), Arcade (copy), Color3_fromRGB_ret6 (copy), u10 (ref), Bangers (copy), Color3_fromRGB_ret3 (copy), u11 (ref), Color3_fromRGB_ret2 (copy), Color3_fromRGB_ret4 (copy), Platform (copy), ControlData (copy), GamepadGlyphs (copy)
    u9 = Instance.new("ScreenGui");
    u9.Name = "CarryGui";
    u9.ResetOnSpawn = false;
    u9.IgnoreGuiInset = true;
    u9.DisplayOrder = 50;
    u9.Enabled = false;
    u9.Parent = PlayerGui;
    local Frame = Instance.new("Frame");
    Frame.Name = "Panel";
    Frame.AnchorPoint = Vector2.new(0.5, 1);
    Frame.Position = UDim2.new(0.5, 0, 1, -36);
    Frame.Size = UDim2.new(0, 330, 0, 96);
    Frame.BackgroundColor3 = Color3_fromRGB_ret;
    Frame.BorderSizePixel = 0;
    Frame.Parent = u9;
    local UIStroke = Instance.new("UIStroke");
    local Border = Enum.ApplyStrokeMode.Border;
    UIStroke.Color = Color3_fromRGB_ret5;
    UIStroke.Thickness = 2;
    UIStroke.ApplyStrokeMode = Border;
    UIStroke.Parent = Frame;
    local ImageLabel = Instance.new("ImageLabel");
    ImageLabel.Name = "Ball";
    ImageLabel.AnchorPoint = Vector2.new(0.5, 0.5);
    ImageLabel.Position = UDim2.new(0, 0, 0.5, -6);
    ImageLabel.Size = UDim2.fromOffset(52, 52);
    ImageLabel.BackgroundTransparency = 1;
    ImageLabel.Image = "rbxassetid://10639165493";
    ImageLabel.ZIndex = 3;
    ImageLabel.Parent = Frame;
    local TextLabel = Instance.new("TextLabel");
    TextLabel.Size = UDim2.new(1, -52, 0, 18);
    TextLabel.Position = UDim2.new(0, 40, 0, 10);
    TextLabel.BackgroundTransparency = 1;
    TextLabel.Text = "CARRYING";
    TextLabel.Font = Arcade;
    TextLabel.TextSize = 13;
    TextLabel.TextColor3 = Color3_fromRGB_ret6;
    TextLabel.TextXAlignment = Enum.TextXAlignment.Left;
    TextLabel.Parent = Frame;
    TextLabel.TextStrokeColor3 = Color3_fromRGB_ret5;
    TextLabel.TextStrokeTransparency = 0.5;
    u10 = Instance.new("TextLabel");
    u10.Size = UDim2.new(1, -52, 0, 22);
    u10.Position = UDim2.new(0, 40, 0, 28);
    u10.BackgroundTransparency = 1;
    u10.Text = "OBJECT";
    u10.Font = Bangers;
    u10.TextSize = 20;
    u10.TextColor3 = Color3_fromRGB_ret3;
    u10.TextXAlignment = Enum.TextXAlignment.Left;
    u10.TextTruncate = Enum.TextTruncate.AtEnd;
    u10.Parent = Frame;
    local v13 = u10;
    v13.TextStrokeColor3 = Color3_fromRGB_ret5;
    v13.TextStrokeTransparency = 0.5;
    u11 = Instance.new("TextButton");
    u11.Name = "DropButton";
    u11.Size = UDim2.new(1, -52, 0, 28);
    u11.Position = UDim2.new(0, 40, 1, -38);
    u11.BackgroundColor3 = Color3_fromRGB_ret2;
    u11.BorderSizePixel = 0;
    u11.AutoButtonColor = true;
    u11.Font = Arcade;
    u11.TextSize = 13;
    u11.TextColor3 = Color3_fromRGB_ret4;
    local v14;

    if Platform.IsTouch() then
        v14 = "TAP TO DROP";
    elseif Platform.PreferGamepadGlyphs() then
        local _, v15 = GamepadGlyphs.Describe(ControlData.Controls.Combat.Heavy);
        v14 = ("PRESS  %s  TO DROP"):format(v15 or "Y");
    else
        v14 = "RIGHT CLICK TO DROP";
    end;

    u11.Text = v14;
    u11.Parent = Frame;
    local UIStroke2 = Instance.new("UIStroke");
    local Border2 = Enum.ApplyStrokeMode.Border;
    UIStroke2.Color = Color3_fromRGB_ret5;
    UIStroke2.Thickness = 1.5;
    UIStroke2.ApplyStrokeMode = Border2;
    UIStroke2.Parent = u11;
    local v16 = u11;
    v16.TextStrokeColor3 = Color3_fromRGB_ret5;
    v16.TextStrokeTransparency = 0.5;
end;

local u17 = false;

local function requestDrop() -- Line: 157
    -- upvalues: u8 (ref), u17 (ref), u11 (ref), ServerRemote (copy), Platform (copy), ControlData (copy), GamepadGlyphs (copy)
    if not u8 then
        return;
    end;

    if u17 then
        return;
    end;

    u17 = true;
    u11.AutoButtonColor = false;
    u11.Text = "DROPPING...";
    ServerRemote:FireServer("Drop", {
        Module = "CarryableHandler",
        Action = "Drop"
    });
    task.delay(1.5, function() -- Line: 173
        -- upvalues: u17 (ref), u8 (ref), u11 (ref), Platform (ref), ControlData (ref), GamepadGlyphs (ref)
        if not u17 then
            return;
        end;

        u17 = false;

        if u8 and u11 then
            u11.AutoButtonColor = true;
            local v18;

            if Platform.IsTouch() then
                v18 = "TAP TO DROP";
            elseif Platform.PreferGamepadGlyphs() then
                local _, v19 = GamepadGlyphs.Describe(ControlData.Controls.Combat.Heavy);
                v18 = ("PRESS  %s  TO DROP"):format(v19 or "Y");
            else
                v18 = "RIGHT CLICK TO DROP";
            end;

            u11.Text = v18;
        end;
    end);
end;

local function setCarrying(p20, p21) -- Line: 183
    -- upvalues: u8 (ref), u6 (ref), u1 (copy), PlayerGui (copy), u5 (copy), u10 (ref), u11 (ref), Platform (copy), ControlData (copy), GamepadGlyphs (copy), u17 (ref), u9 (ref), ContextActionService (copy), requestDrop (copy)
    if u8 == p20 and not p20 then
        return;
    end;

    u6 = u6 + 1;
    local v22 = u8;
    u8 = p20;

    if not p20 then
        ContextActionService:UnbindAction("CarryDrop");
        u17 = false;

        if u9 then
            u9.Enabled = false;
        end;

        for _, v in ipairs(u1) do
            local v23 = PlayerGui:FindFirstChild(v);

            if v23 and v23:IsA("ScreenGui") then
                local v24 = u5[v];
                v23.Enabled = v24 == nil and true or v24;
            end;
        end;

        table.clear(u5);

        return;
    end;

    if not v22 then
        for _, v in ipairs(u1) do
            local v25 = PlayerGui:FindFirstChild(v);

            if v25 and v25:IsA("ScreenGui") then
                u5[v] = v25.Enabled;
            end;
        end;
    end;

    for _, v in ipairs(u1) do
        local v26 = PlayerGui:FindFirstChild(v);

        if v26 and v26:IsA("ScreenGui") then
            v26.Enabled = false;
        end;
    end;

    u10.Text = string.upper(p21 or "OBJECT");
    local v27;

    if Platform.IsTouch() then
        v27 = "TAP TO DROP";
    elseif Platform.PreferGamepadGlyphs() then
        local _, v28 = GamepadGlyphs.Describe(ControlData.Controls.Combat.Heavy);
        v27 = ("PRESS  %s  TO DROP"):format(v28 or "Y");
    else
        v27 = "RIGHT CLICK TO DROP";
    end;

    u11.Text = v27;
    u11.AutoButtonColor = true;
    u17 = false;
    u9.Enabled = true;
    ContextActionService:BindActionAtPriority("CarryDrop", function(p29, p30) -- Line: 218
        -- upvalues: requestDrop (ref)
        if p30 == Enum.UserInputState.Begin then
            requestDrop();
        end;

        return Enum.ContextActionResult.Sink;
    end, false, 3000, Enum.UserInputType.MouseButton2, Enum.KeyCode.ButtonY);
end;

local function resolveName(p31) -- Line: 242
    if p31.Value then
        return p31.Value.Name;
    end;

    local os_clock_ret = os.clock();

    while not (p31.Value or (not p31.Parent or os.clock() - os_clock_ret >= 2)) do
        task.wait();
    end;

    return p31.Value and p31.Value.Name or nil;
end;

local function watch(u32) -- Line: 251
    -- upvalues: u7 (copy), setCarrying (copy), u6 (ref), resolveName (copy), u8 (ref), u9 (ref), ContextActionService (copy), u1 (copy), PlayerGui (copy)
    for _, v in ipairs(u7) do
        if v.Connected then
            v:Disconnect();
        end;
    end;

    table.clear(u7);
    setCarrying(false);

    local function isLive(p33) -- Line: 262
        -- upvalues: u32 (copy)
        local v34;

        if p33 == nil or (p33.Parent ~= u32 or p33.Value == nil) then
            v34 = false;
        else
            v34 = p33.Value:IsDescendantOf(workspace);
        end;

        return v34;
    end;

    local function showFor(u35) -- Line: 273
        -- upvalues: u6 (ref), resolveName (ref), u32 (copy), setCarrying (ref)
        local u36 = u6;
        task.spawn(function() -- Line: 275
            -- upvalues: resolveName (ref), u35 (copy), u36 (copy), u6 (ref), u32 (ref), setCarrying (ref)
            local v37 = resolveName(u35);

            if u36 ~= u6 then
                return;
            end;

            local v38 = u35;
            local v39;

            if v38 == nil or (v38.Parent ~= u32 or v38.Value == nil) then
                v39 = false;
            else
                v39 = v38.Value:IsDescendantOf(workspace);
            end;

            if not v39 then
                return;
            end;

            setCarrying(true, v37);
        end);
    end;

    local CarriedObject = u32:FindFirstChild("CarriedObject");

    if CarriedObject and CarriedObject:IsA("ObjectValue") then
        local u40 = u6;
        task.spawn(function() -- Line: 275
            -- upvalues: resolveName (ref), CarriedObject (copy), u40 (copy), u6 (ref), u32 (copy), setCarrying (ref)
            local v41 = resolveName(CarriedObject);

            if u40 ~= u6 then
                return;
            end;

            local v42 = CarriedObject;
            local v43;

            if v42 == nil or (v42.Parent ~= u32 or v42.Value == nil) then
                v43 = false;
            else
                v43 = v42.Value:IsDescendantOf(workspace);
            end;

            if not v43 then
                return;
            end;

            setCarrying(true, v41);
        end);
    end;

    table.insert(u7, u32.ChildAdded:Connect(function(u44) -- Line: 286
        -- upvalues: u6 (ref), resolveName (ref), u32 (copy), setCarrying (ref)
        if u44.Name == "CarriedObject" and u44:IsA("ObjectValue") then
            local u45 = u6;
            task.spawn(function() -- Line: 275
                -- upvalues: resolveName (ref), u44 (copy), u45 (copy), u6 (ref), u32 (ref), setCarrying (ref)
                local v46 = resolveName(u44);

                if u45 ~= u6 then
                    return;
                end;

                local v47 = u44;
                local v48;

                if v47 == nil or (v47.Parent ~= u32 or v47.Value == nil) then
                    v48 = false;
                else
                    v48 = v47.Value:IsDescendantOf(workspace);
                end;

                if not v48 then
                    return;
                end;

                setCarrying(true, v46);
            end);
        end;
    end));
    table.insert(u7, u32.ChildRemoved:Connect(function(p49) -- Line: 292
        -- upvalues: setCarrying (ref)
        if p49.Name == "CarriedObject" then
            setCarrying(false);
        end;
    end));
    task.spawn(function() -- Line: 305
        -- upvalues: u32 (copy), u8 (ref), setCarrying (ref), u9 (ref), ContextActionService (ref), u1 (ref), PlayerGui (ref)
        while u32.Parent do
            task.wait(0.4);
            local CarriedObject2 = u32:FindFirstChild("CarriedObject");
            local v50;

            if CarriedObject2 == nil or (CarriedObject2.Parent ~= u32 or CarriedObject2.Value == nil) then
                v50 = false;
            else
                v50 = CarriedObject2.Value:IsDescendantOf(workspace);
            end;

            if u8 and not v50 then
                setCarrying(false);
            elseif not u8 and (u9 and u9.Enabled) then
                u9.Enabled = false;
                ContextActionService:UnbindAction("CarryDrop");

                for _, v in ipairs(u1) do
                    local v51 = PlayerGui:FindFirstChild(v);

                    if v51 and (v51:IsA("ScreenGui") and not v51.Enabled) then
                        v51.Enabled = true;
                    end;
                end;
            end;
        end;
    end);
end;

build();
u11.Activated:Connect(requestDrop);
UserInputService.InputBegan:Connect(function(p52) -- Line: 355
    -- upvalues: u8 (ref), requestDrop (copy)
    if not u8 then
        return;
    end;

    if p52.UserInputType == Enum.UserInputType.MouseButton2 then
        requestDrop();
    end;
end);
UserInputService.LastInputTypeChanged:Connect(function() -- Line: 362
    -- upvalues: u8 (ref), u11 (ref), Platform (copy), ControlData (copy), GamepadGlyphs (copy)
    if u8 and u11 then
        local v53;

        if Platform.IsTouch() then
            v53 = "TAP TO DROP";
        elseif Platform.PreferGamepadGlyphs() then
            local _, v54 = GamepadGlyphs.Describe(ControlData.Controls.Combat.Heavy);
            v53 = ("PRESS  %s  TO DROP"):format(v54 or "Y");
        else
            v53 = "RIGHT CLICK TO DROP";
        end;

        u11.Text = v53;
    end;
end);

if LocalPlayer.Character then
    watch(LocalPlayer.Character);
end;

LocalPlayer.CharacterAdded:Connect(watch);