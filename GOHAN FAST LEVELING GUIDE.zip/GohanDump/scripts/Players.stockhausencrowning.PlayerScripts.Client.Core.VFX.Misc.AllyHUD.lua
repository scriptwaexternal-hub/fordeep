-- Decompiled with Potassium's decompiler.

local Players = game:GetService("Players");
local CollectionService = game:GetService("CollectionService");
local TweenService = game:GetService("TweenService");
local LocalPlayer = Players.LocalPlayer;
local Color3_fromRGB_ret = Color3.fromRGB(44, 44, 45);
local Color3_fromRGB_ret2 = Color3.fromRGB(28, 28, 30);
local Color3_new_ret = Color3.new(0, 0, 0);
local Color3_new_ret2 = Color3.new(1, 1, 1);
local Color3_fromRGB_ret3 = Color3.fromRGB(90, 200, 120);
local Color3_fromRGB_ret4 = Color3.fromRGB(226, 62, 48);
local Color3_fromRGB_ret5 = Color3.fromRGB(90, 200, 255);
local Color3_fromRGB_ret6 = Color3.fromRGB(255, 120, 120);
local u1 = {};
local ScreenGui = Instance.new("ScreenGui");
ScreenGui.Name = "AllyHUDGui";
ScreenGui.ResetOnSpawn = false;
ScreenGui.DisplayOrder = 60;
ScreenGui.Parent = LocalPlayer:WaitForChild("PlayerGui");
local Frame = Instance.new("Frame");
Frame.Name = "AllyList";
Frame.AnchorPoint = Vector2.new(1, 1);
Frame.Position = UDim2.new(1, -12, 1, -150);
Frame.Size = UDim2.new(0, 240, 0, 300);
Frame.BackgroundTransparency = 1;
Frame.Parent = ScreenGui;
local UIListLayout = Instance.new("UIListLayout");
UIListLayout.Padding = UDim.new(0, 6);
UIListLayout.VerticalAlignment = Enum.VerticalAlignment.Bottom;
UIListLayout.HorizontalAlignment = Enum.HorizontalAlignment.Right;
UIListLayout.SortOrder = Enum.SortOrder.LayoutOrder;
UIListLayout.Parent = Frame;

local function outline(p2) -- Line: 25
    -- upvalues: Color3_new_ret (copy)
    local UIStroke = Instance.new("UIStroke");
    UIStroke.Color = Color3_new_ret;
    UIStroke.Thickness = 1.5;
    UIStroke.Parent = p2;
end;

local function label(p3, p4, p5, p6, p7, p8, p9) -- Line: 26
    -- upvalues: Color3_new_ret (copy)
    local TextLabel = Instance.new("TextLabel");
    TextLabel.BackgroundTransparency = 1;
    TextLabel.Position = p4;
    TextLabel.Size = p5;
    TextLabel.Font = p6;
    TextLabel.TextSize = p7;
    TextLabel.TextColor3 = p8;
    TextLabel.Text = p9;
    TextLabel.TextXAlignment = Enum.TextXAlignment.Left;
    TextLabel.TextTruncate = Enum.TextTruncate.AtEnd;
    TextLabel.TextStrokeColor3 = Color3_new_ret;
    TextLabel.TextStrokeTransparency = 0.5;
    TextLabel.Parent = p3;

    return TextLabel;
end;

local function buildPortrait(p10, p11) -- Line: 32
    local WorldModel = Instance.new("WorldModel");
    WorldModel.Parent = p10;
    local Head = p11:FindFirstChild("Head", true);
    local v12 = p11:FindFirstChild("Torso") or p11:FindFirstChild("UpperTorso");

    if not v12 then
        return;
    end;

    local function put(u13) -- Line: 37
        -- upvalues: WorldModel (copy)
        local success, result = pcall(function() -- Line: 38
            -- upvalues: u13 (copy)
            return u13:Clone();
        end);

        if success and result then
            for _, child in ipairs(result:GetChildren()) do
                if child:IsA("JointInstance") or (child:IsA("LuaSourceContainer") or child:IsA("BillboardGui")) then
                    child:Destroy();
                end;
            end;

            result.Anchored = true;
            result.Parent = WorldModel;
        end;
    end;

    if Head then
        put(Head);
    end;

    put(v12);

    for _, child in ipairs(p11:GetChildren()) do
        if child:IsA("Accessory") then
            local v14 = child:FindFirstChildWhichIsA("BasePart");

            if v14 then
                put(v14);
            end;
        end;
    end;

    local v15 = Head and Head.Position or v12.Position + Vector3.new(0, 1.6, 0);
    local Camera = Instance.new("Camera");
    Camera.FieldOfView = 40;
    Camera.CFrame = CFrame.lookAt(v15 + v12.CFrame.LookVector * 3.4 + Vector3.new(0, 0.2, 0), v15);
    Camera.Parent = p10;
    p10.CurrentCamera = Camera;
end;

local function addCard(u16) -- Line: 53
    -- upvalues: u1 (copy), Color3_fromRGB_ret (copy), Frame (copy), Color3_new_ret (copy), Color3_fromRGB_ret2 (copy), Color3_new_ret2 (copy), buildPortrait (copy), Color3_fromRGB_ret5 (copy), Color3_fromRGB_ret3 (copy), TweenService (copy), Color3_fromRGB_ret4 (copy), Color3_fromRGB_ret6 (copy)
    if u1[u16] then
        return;
    end;

    local u17 = u16:FindFirstChildOfClass("Humanoid");

    if not u17 then
        return;
    end;

    local Frame2 = Instance.new("Frame");
    Frame2.Name = "AllyCard";
    Frame2.Size = UDim2.new(0, 240, 0, 54);
    Frame2.BackgroundColor3 = Color3_fromRGB_ret;
    Frame2.BorderSizePixel = 0;
    Frame2.LayoutOrder = os.clock() % 100000;
    Frame2.Parent = Frame;
    local UIStroke = Instance.new("UIStroke");
    UIStroke.Color = Color3_new_ret;
    UIStroke.Thickness = 1.5;
    UIStroke.Parent = Frame2;
    local ViewportFrame = Instance.new("ViewportFrame");
    ViewportFrame.Name = "Portrait";
    ViewportFrame.Size = UDim2.new(0, 42, 0, 42);
    ViewportFrame.Position = UDim2.new(0, 6, 0, 6);
    ViewportFrame.BackgroundColor3 = Color3_fromRGB_ret2;
    ViewportFrame.BorderSizePixel = 0;
    ViewportFrame.Ambient = Color3.fromRGB(180, 180, 180);
    ViewportFrame.LightColor = Color3_new_ret2;
    ViewportFrame.LightDirection = Vector3.new(-1, -1, -1);
    ViewportFrame.Parent = Frame2;
    local UIStroke2 = Instance.new("UIStroke");
    UIStroke2.Color = Color3_new_ret;
    UIStroke2.Thickness = 1.5;
    UIStroke2.Parent = ViewportFrame;
    task.defer(buildPortrait, ViewportFrame, u16);
    local UDim2_new_ret = UDim2.new(0, 56, 0, 6);
    local UDim2_new_ret2 = UDim2.new(1, -110, 0, 15);
    local Arcade = Enum.Font.Arcade;
    local v18 = u16:GetAttribute("AllyLabel") or string.upper(u16.Name);
    local TextLabel = Instance.new("TextLabel");
    TextLabel.BackgroundTransparency = 1;
    TextLabel.Position = UDim2_new_ret;
    TextLabel.Size = UDim2_new_ret2;
    TextLabel.Font = Arcade;
    TextLabel.TextSize = 13;
    TextLabel.TextColor3 = Color3_new_ret2;
    TextLabel.Text = v18;
    TextLabel.TextXAlignment = Enum.TextXAlignment.Left;
    TextLabel.TextTruncate = Enum.TextTruncate.AtEnd;
    TextLabel.TextStrokeColor3 = Color3_new_ret;
    TextLabel.TextStrokeTransparency = 0.5;
    TextLabel.Parent = Frame2;
    local TextLabel2 = Instance.new("TextLabel");
    TextLabel2.Size = UDim2.new(0, 40, 0, 15);
    TextLabel2.Position = UDim2.new(1, -46, 0, 6);
    TextLabel2.BackgroundColor3 = Color3_fromRGB_ret5;
    TextLabel2.BorderSizePixel = 0;
    TextLabel2.Font = Enum.Font.Arcade;
    TextLabel2.TextSize = 10;
    TextLabel2.TextColor3 = Color3_new_ret2;
    TextLabel2.TextStrokeColor3 = Color3_new_ret;
    TextLabel2.TextStrokeTransparency = 0.5;
    TextLabel2.Text = "ALLY";
    TextLabel2.Parent = Frame2;
    local UIStroke3 = Instance.new("UIStroke");
    UIStroke3.Color = Color3_new_ret;
    UIStroke3.Thickness = 1.5;
    UIStroke3.Parent = TextLabel2;
    local Frame3 = Instance.new("Frame");
    Frame3.Position = UDim2.new(0, 56, 0, 26);
    Frame3.Size = UDim2.new(1, -62, 0, 11);
    Frame3.BackgroundColor3 = Color3_fromRGB_ret2;
    Frame3.BorderSizePixel = 0;
    Frame3.Parent = Frame2;
    local UIStroke4 = Instance.new("UIStroke");
    UIStroke4.Color = Color3_new_ret;
    UIStroke4.Thickness = 1.5;
    UIStroke4.Parent = Frame3;
    local Frame4 = Instance.new("Frame");
    Frame4.Size = UDim2.new(1, 0, 1, 0);
    Frame4.BackgroundColor3 = Color3_fromRGB_ret3;
    Frame4.BorderSizePixel = 0;
    Frame4.Parent = Frame3;
    local UDim2_new_ret3 = UDim2.new(0, 56, 0, 40);
    local UDim2_new_ret4 = UDim2.new(1, -62, 0, 11);
    local Arcade2 = Enum.Font.Arcade;
    local v19 = u16:GetAttribute("Status") or "";
    local TextLabel3 = Instance.new("TextLabel");
    TextLabel3.BackgroundTransparency = 1;
    TextLabel3.Position = UDim2_new_ret3;
    TextLabel3.Size = UDim2_new_ret4;
    TextLabel3.Font = Arcade2;
    TextLabel3.TextSize = 9;
    TextLabel3.TextColor3 = Color3_fromRGB_ret5;
    TextLabel3.Text = v19;
    TextLabel3.TextXAlignment = Enum.TextXAlignment.Left;
    TextLabel3.TextTruncate = Enum.TextTruncate.AtEnd;
    TextLabel3.TextStrokeColor3 = Color3_new_ret;
    TextLabel3.TextStrokeTransparency = 0.5;
    TextLabel3.Parent = Frame2;

    local function refresh() -- Line: 67
        -- upvalues: u17 (copy), TweenService (ref), Frame4 (copy), Color3_fromRGB_ret4 (ref), Color3_fromRGB_ret3 (ref), u16 (copy), TextLabel3 (copy), Color3_fromRGB_ret6 (ref), Color3_fromRGB_ret5 (ref)
        local v20 = u17.Health / math.max(1, u17.MaxHealth);
        local math_clamp_ret = math.clamp(v20, 0, 1);
        TweenService:Create(Frame4, TweenInfo.new(0.15), {
            Size = UDim2.new(math_clamp_ret, 0, 1, 0)
        }):Play();
        Frame4.BackgroundColor3 = math_clamp_ret <= 0.3 and Color3_fromRGB_ret4 or Color3_fromRGB_ret3;
        local v21 = u16:GetAttribute("Status") or "";
        TextLabel3.Text = v21;
        TextLabel3.TextColor3 = v21 == "DOWN" and Color3_fromRGB_ret6 or Color3_fromRGB_ret5;
    end;

    u1[u16] = {
        frame = Frame2,
        conns = { u17.HealthChanged:Connect(refresh), u16:GetAttributeChangedSignal("Status"):Connect(refresh) }
    };
    refresh();
end;

local function removeCard(p22) -- Line: 83
    -- upvalues: u1 (copy)
    local v23 = u1[p22];

    if not v23 then
        return;
    end;

    for _, v in ipairs(v23.conns) do
        v:Disconnect();
    end;

    v23.frame:Destroy();
    u1[p22] = nil;
end;

local function consider(u24) -- Line: 91
    -- upvalues: LocalPlayer (copy), addCard (copy), removeCard (copy)
    if not u24:IsA("Model") then
        return;
    end;

    local os_clock_ret = os.clock();

    while u24.Parent and (os.clock() - os_clock_ret < 5 and (u24:GetAttribute("AllyFor") == nil or not u24:FindFirstChildOfClass("Humanoid"))) do
        task.wait(0.1);
    end;

    if not u24.Parent then
        return;
    end;

    if u24:GetAttribute("AllyFor") ~= LocalPlayer.UserId then
        return;
    end;

    addCard(u24);
    u24.AncestryChanged:Connect(function(p25, p26) -- Line: 100
        -- upvalues: removeCard (ref), u24 (copy)
        if not p26 then
            removeCard(u24);
        end;
    end);
end;

local v27 = {};

for _, v in ipairs(CollectionService:GetTagged("PlayerAlly")) do
    consider(v);
end;

CollectionService:GetInstanceAddedSignal("PlayerAlly"):Connect(function(p28) -- Line: 104
    -- upvalues: consider (copy)
    task.spawn(consider, p28);
end);
CollectionService:GetInstanceRemovedSignal("PlayerAlly"):Connect(removeCard);

return v27;