-- Decompiled with Potassium's decompiler.

local Players = game:GetService("Players");
local UserInputService = game:GetService("UserInputService");
local ReplicatedStorage = game:GetService("ReplicatedStorage");
local LocalPlayer = Players.LocalPlayer;
local ServerRemote = ReplicatedStorage:WaitForChild("Remotes"):WaitForChild("ServerRemote");
local Font_new_ret = Font.new("rbxasset://fonts/families/PressStart2P.json");

local function clear() -- Line: 18
    -- upvalues: LocalPlayer (copy)
    local ApeAscendPrompt = LocalPlayer.PlayerGui:FindFirstChild("ApeAscendPrompt");

    if ApeAscendPrompt then
        ApeAscendPrompt:Destroy();
    end;
end;

return {
    Fire = function(p1) -- Line: 25
        -- upvalues: LocalPlayer (copy), Font_new_ret (copy), ServerRemote (copy), UserInputService (copy)
        local ApeAscendPrompt = LocalPlayer.PlayerGui:FindFirstChild("ApeAscendPrompt");

        if ApeAscendPrompt then
            ApeAscendPrompt:Destroy();
        end;

        local v2;

        if p1 then
            v2 = p1.Time;
        else
            v2 = p1;
        end;

        local v3 = tonumber(v2) or 5;
        local u4 = p1 and (p1.Action or "Ascend") or "Ascend";
        local v5 = p1 and p1.Title or "Ascend?";
        local ScreenGui = Instance.new("ScreenGui");
        ScreenGui.Name = "ApeAscendPrompt";
        ScreenGui.ResetOnSpawn = false;
        ScreenGui.IgnoreGuiInset = true;
        ScreenGui.DisplayOrder = 50;
        local Frame = Instance.new("Frame");
        Frame.Name = "Root";
        Frame.AnchorPoint = Vector2.new(0.5, 0.5);
        Frame.Position = UDim2.new(0.5, 0, 0.62, 0);
        Frame.Size = UDim2.new(0, 220, 0, 130);
        Frame.BackgroundTransparency = 1;
        Frame.Parent = ScreenGui;
        local TextLabel = Instance.new("TextLabel");
        TextLabel.Name = "Title";
        TextLabel.AnchorPoint = Vector2.new(0.5, 0);
        TextLabel.Position = UDim2.new(0.5, 0, 0, 0);
        TextLabel.Size = UDim2.new(1, 0, 0, 22);
        TextLabel.BackgroundTransparency = 1;
        TextLabel.Text = v5;
        TextLabel.FontFace = Font_new_ret;
        TextLabel.TextSize = 18;
        TextLabel.TextColor3 = Color3.fromRGB(255, 205, 120);
        TextLabel.Parent = Frame;
        local UIStroke = Instance.new("UIStroke");
        UIStroke.Color = Color3.fromRGB(16, 16, 18);
        UIStroke.Thickness = 2;
        UIStroke.Parent = TextLabel;
        local TextButton = Instance.new("TextButton");
        TextButton.Name = "KeyPrompt";
        TextButton.AnchorPoint = Vector2.new(0.5, 0);
        TextButton.Position = UDim2.new(0.5, 0, 0, 34);
        TextButton.Size = UDim2.new(0, 54, 0, 54);
        TextButton.BackgroundColor3 = Color3.fromRGB(16, 16, 18);
        TextButton.BackgroundTransparency = 0.08;
        TextButton.AutoButtonColor = false;
        TextButton.Text = "X";
        TextButton.FontFace = Font_new_ret;
        TextButton.TextSize = 30;
        TextButton.TextColor3 = Color3.fromRGB(245, 245, 245);
        TextButton.Parent = Frame;
        local UICorner = Instance.new("UICorner");
        UICorner.CornerRadius = UDim.new(0, 10);
        UICorner.Parent = TextButton;
        local UIStroke2 = Instance.new("UIStroke");
        UIStroke2.Color = Color3.fromRGB(245, 245, 245);
        UIStroke2.Thickness = 1;
        UIStroke2.Parent = TextButton;
        local Frame2 = Instance.new("Frame");
        Frame2.Name = "Track";
        Frame2.AnchorPoint = Vector2.new(0.5, 0);
        Frame2.Position = UDim2.new(0.5, 0, 0, 100);
        Frame2.Size = UDim2.new(0, 160, 0, 8);
        Frame2.BackgroundColor3 = Color3.fromRGB(61, 61, 61);
        Frame2.BorderSizePixel = 0;
        Frame2.Parent = Frame;
        local Frame3 = Instance.new("Frame");
        Frame3.Name = "Bar";
        Frame3.AnchorPoint = Vector2.new(0.5, 0.5);
        Frame3.Position = UDim2.new(0.5, 0, 0.5, 0);
        Frame3.Size = UDim2.new(1, 0, 1, 0);
        Frame3.BackgroundColor3 = Color3.fromRGB(213, 0, 0);
        Frame3.BorderSizePixel = 0;
        Frame3.Parent = Frame2;
        ScreenGui.Parent = LocalPlayer.PlayerGui;
        Frame3:TweenSize(UDim2.new(0, 0, 1, 0), Enum.EasingDirection.Out, Enum.EasingStyle.Linear, v3, true);
        local u6 = false;
        local u7 = nil;

        local function finish(p8) -- Line: 98
            -- upvalues: u6 (ref), u7 (ref), ServerRemote (ref), u4 (copy), ScreenGui (copy)
            if u6 then
                return;
            end;

            u6 = true;

            if u7 then
                u7:Disconnect();
            end;

            if p8 then
                ServerRemote:FireServer(nil, {
                    Module = "Ape Transformation",
                    Action = u4
                });
            end;

            if ScreenGui.Parent then
                ScreenGui:Destroy();
            end;
        end;

        u7 = UserInputService.InputBegan:Connect(function(p9, p10) -- Line: 109
            -- upvalues: UserInputService (ref), finish (copy)
            if p9.KeyCode ~= Enum.KeyCode.X then
                return;
            end;

            if UserInputService:GetFocusedTextBox() then
                return;
            end;

            finish(true);
        end);
        TextButton.Activated:Connect(function() -- Line: 114
            -- upvalues: finish (copy)
            finish(true);
        end);
        task.delay(v3, function() -- Line: 115
            -- upvalues: u6 (ref), u7 (ref), ScreenGui (copy)
            if u6 then
                return;
            end;

            u6 = true;

            if u7 then
                u7:Disconnect();
            end;

            if ScreenGui.Parent then
                ScreenGui:Destroy();
            end;
        end);
    end,

    Clear = function() -- Line: 118
        -- upvalues: LocalPlayer (copy)
        local ApeAscendPrompt = LocalPlayer.PlayerGui:FindFirstChild("ApeAscendPrompt");

        if ApeAscendPrompt then
            ApeAscendPrompt:Destroy();
        end;
    end
};