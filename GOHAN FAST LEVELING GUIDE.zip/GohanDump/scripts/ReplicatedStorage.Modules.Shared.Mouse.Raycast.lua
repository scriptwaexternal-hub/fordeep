-- Decompiled with Potassium's decompiler.

local Workspace = game:GetService("Workspace");
local u1 = {
    Continue = 1,
    Finished = 2,
    Fail = 3
};
local u36 = {
    CallBackResult = u1,

    FindPartOnRay = function(p2, p3, p4, p5) -- Line: 13, Name: FindPartOnRay
        -- upvalues: Workspace (copy)
        return Workspace:FindPartOnRay(p2, p3, p4, p5);
    end,

    FindPartOnRayWithIgnoreList = function(p6, p7, p8, p9) -- Line: 17, Name: FindPartOnRayWithIgnoreList
        -- upvalues: Workspace (copy)
        return Workspace:FindPartOnRayWithIgnoreList(p6, p7, p8, p9);
    end,

    FindPartOnRayWithWhiteList = function(p10, p11, p12, p13) -- Line: 21, Name: FindPartOnRayWithWhiteList
        -- upvalues: Workspace (copy)
        return Workspace:FindPartOnRayWithWhitelist(p10, p11, p12, p13);
    end,

    FindPartOnRayWithCallbackWithIgnoreList = function(p14, p15, p16, p17, p18) -- Line: 27, Name: FindPartOnRayWithCallbackWithIgnoreList
        -- upvalues: Workspace (copy), u1 (copy)
        local Magnitude = p14.Direction.Magnitude;
        local Unit = p14.Direction.Unit;
        local Origin = p14.Origin;
        local v19 = 0;

        while true do
            Ray.new(Origin, Unit * (Magnitude - v19));
            local v20, v21, v22, v23 = Workspace:FindPartOnRayWithIgnoreList(p14, p15, p16, p17, true);
            local v24 = p18(v20, v21, v22, v23);

            if v24 == u1.Continue then
                v19 = (p14.Origin - v21).Magnitude;
            else
                if v24 == u1.Finished then
                    return v20, v21, v22, v23;
                end;

                if v24 == u1.Fail or v24 == nil then
                    break;
                end;

                v21 = Origin;
            end;

            if Magnitude - 0.1 <= v19 then
                break;
            end;

            Origin = v21;
        end;
    end,

    FindPartOnRayWithCallbackWithWhiteList = function(p25, p26, p27, p28, p29) -- Line: 54, Name: FindPartOnRayWithCallbackWithWhiteList
        -- upvalues: Workspace (copy), u1 (copy)
        local Magnitude = p25.Direction.Magnitude;
        local Unit = p25.Direction.Unit;
        local Origin = p25.Origin;
        local v30 = 0;

        while true do
            Ray.new(Origin, Unit * (Magnitude - v30));
            local v31, v32, v33, v34 = Workspace:FindPartOnRayWithWhiteList(p25, p26, p27, p28, true);
            local v35 = p29(v31, v32, v33, v34);

            if v35 == u1.Continue then
                v30 = (p25.Origin - v32).Magnitude;
            else
                if v35 == u1.Finished then
                    return v31, v32, v33, v34;
                end;

                if v35 == u1.Fail or v35 == nil then
                    break;
                end;

                v32 = Origin;
            end;

            if Magnitude - 0.1 <= v30 then
                break;
            end;

            Origin = v32;
        end;
    end
};

function u36.FindPartOnRayWithCallback(p37, p38, p39, p40, p41) -- Line: 81
    -- upvalues: u36 (copy)
    return u36.FindPartOnRayWithCallbackWithIgnoreList(p37, { p38 }, p39, p40, p41);
end;

return u36;