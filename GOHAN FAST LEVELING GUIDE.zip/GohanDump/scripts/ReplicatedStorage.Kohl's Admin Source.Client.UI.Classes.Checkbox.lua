-- Decompiled with Potassium's decompiler.

local Parent = require(script.Parent.Parent);
local BaseClass = require(script.Parent:WaitForChild("BaseClass"));
local u1 = {
    Value = false
};
local u2 = {};
u2.__index = u2;
setmetatable(u2, BaseClass);
local u3 = Parent.compute(function() -- Line: 15
    -- upvalues: Parent (copy)
    return UDim2.fromOffset(Parent.Theme.FontSizeLarger(), Parent.Theme.FontSizeLarger());
end);

function u2.new(p4) -- Line: 19
    -- upvalues: u1 (copy), Parent (copy), u3 (copy), u2 (copy)
    local table_clone_ret = table.clone(u1);
    Parent.makeStatefulDefaults(table_clone_ret, p4);
    table_clone_ret._instance = Parent.new("TextButton")({
        AutoLocalize = false,
        Name = "Checkbox",
        Active = true,
        AnchorPoint = Vector2.new(1, 0.5),
        BackgroundColor3 = Parent.Theme.Secondary,
        BackgroundTransparency = Parent.Theme.TransparencyHeavy,
        Position = UDim2.new(1, 0, 0.5, 0),
        Text = "",
        TextTransparency = 1,
        Size = u3,
        Parent.new("UICorner")({
            CornerRadius = Parent.Theme.CornerPadded
        }),
        Parent.new("Stroke")({}),
        Parent.new("UIPadding")({
            PaddingTop = Parent.Theme.PaddingHalf,
            PaddingRight = Parent.Theme.PaddingHalf,
            PaddingBottom = Parent.Theme.PaddingHalf,
            PaddingLeft = Parent.Theme.PaddingHalf
        }),
        Parent.new("Frame")({
            Name = "Checkmark",
            BackgroundTransparency = 1,
            ClipsDescendants = true,
            Size = Parent.tween(function() -- Line: 52
                -- upvalues: table_clone_ret (copy)
                return UDim2.new(table_clone_ret.Value() and 1 or 0, 0, 1, 0);
            end, Parent.Theme.TweenOut),
            Parent.new("ImageLabel")({
                BackgroundTransparency = 1,
                AnchorPoint = Vector2.new(0, 0.5),
                Position = UDim2.new(0, 0, 0.5, 0),
                Size = UDim2.fromScale(1, 1),
                SizeConstraint = Enum.SizeConstraint.RelativeYY,
                Image = Parent.Theme.Image.Check,
                ImageColor3 = Parent.Theme.Secondary
            })
        }),

        Activated = function() -- Line: 67, Name: Activated
            -- upvalues: Parent (ref), table_clone_ret (copy)
            local v5 = not Parent.raw(table_clone_ret.Value);
            table_clone_ret.Value(v5);

            if v5 then
                Parent.Sound.Hover03:Play();

                return;
            end;

            Parent.Sound.Hover01:Play();
        end
    });

    return setmetatable(table_clone_ret, u2);
end;

return u2;