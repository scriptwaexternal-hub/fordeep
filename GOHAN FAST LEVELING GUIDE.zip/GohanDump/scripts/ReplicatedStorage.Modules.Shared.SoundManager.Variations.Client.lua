-- Decompiled with Potassium's decompiler.

local Debris = game:GetService("Debris");
game:GetService("TweenService");
local ReplicatedStorage = game:GetService("ReplicatedStorage");
game:GetService("RunService");
local Modules = ReplicatedStorage:WaitForChild("Modules");
ReplicatedStorage:WaitForChild("Remotes");
local _ = ReplicatedStorage.Assets;
local _ = Modules.Metadata;
local _ = Modules.Shared;
local _ = Modules.Utility;
local GlobalFunctions = require(Modules.GlobalFunctions);

return function(p1, p2, p3, p4) -- Line: 22
    -- upvalues: GlobalFunctions (copy), Debris (copy)
    if p1[p2] then
        local u5 = p1[p2]:Clone();

        if u5.TimeLength > 0 and u5.TimePosition >= u5.TimeLength then
            u5.TimePosition = 0;
        end;

        if p3 then
            for i, v in next, p3 do
                u5[i] = v;
            end;
        end;

        u5.RollOffMaxDistance = 250;
        u5:Play();

        local function fallbackDestroy(u6) -- Line: 52
            -- upvalues: u5 (copy)
            task.spawn(function() -- Line: 53
                -- upvalues: u5 (ref), u6 (copy)
                local TimeLength = u5.TimeLength;

                if TimeLength <= 0 then
                    local os_clock_ret = os.clock();

                    while u5.Parent and (u5.TimeLength <= 0 and os.clock() - os_clock_ret < 8) do
                        task.wait(0.5);
                    end;

                    TimeLength = u5.TimeLength;
                end;

                local v7 = TimeLength > 0 and TimeLength / math.max(u5.PlaybackSpeed, 0.1) or 0;
                task.wait(v7 + (u6 or 1));

                if u5.Parent then
                    u5:Destroy();
                end;
            end);
        end;

        if p3.Looped then
            if p3.Looped then
                if not p4 and p4.Duration then
                    return;
                end;

                Debris:AddItem(u5, p4.Duration);
            end;

            return u5;
        end;

        if p4 and p4.Duration then
            local u8 = {
                Instance = u5,
                Duration = 0.3
            };
            local u9 = {
                Volume = 0
            };
            task.delay(p4.Duration - 0.3, function() -- Line: 84
                -- upvalues: GlobalFunctions (ref), u8 (copy), u9 (copy)
                GlobalFunctions.Tween(u8, u9);
            end);
            Debris:AddItem(u5, p4.Duration);

            return u5;
        end;

        local u10 = nil;
        u10 = u5.Ended:Connect(function() -- Line: 68
            -- upvalues: u5 (copy), u10 (ref)
            u5:Destroy();
            u10:Disconnect();
            u10 = nil;
        end);
        local u11 = 1;
        task.spawn(function() -- Line: 53
            -- upvalues: u5 (copy), u11 (copy)
            local TimeLength = u5.TimeLength;

            if TimeLength <= 0 then
                local os_clock_ret = os.clock();

                while u5.Parent and (u5.TimeLength <= 0 and os.clock() - os_clock_ret < 8) do
                    task.wait(0.5);
                end;

                TimeLength = u5.TimeLength;
            end;

            local v12 = TimeLength > 0 and TimeLength / math.max(u5.PlaybackSpeed, 0.1) or 0;
            task.wait(v12 + (u11 or 1));

            if u5.Parent then
                u5:Destroy();
            end;
        end);

        return u5;
    end;

    warn(p2 .. " not found");
end;