-- Decompiled with Potassium's decompiler.

local ReplicatedStorage = game:GetService("ReplicatedStorage");
game:GetService("UserInputService");
game:GetService("Debris");
local Players = game:GetService("Players");
local Modules = ReplicatedStorage:WaitForChild("Modules");
local Remotes = ReplicatedStorage:WaitForChild("Remotes");
local _ = ReplicatedStorage.Assets;
local _ = Modules.Metadata;
local Shared = Modules.Shared;
local Utility = Modules.Utility;
local Gui = ReplicatedStorage.Assets.Gui;
require(Utility.Create);
local CinemaManager = require(Shared.CinemaManager);
local GlobalFunctions = require(Modules.GlobalFunctions);
local SoundManager = require(Shared.SoundManager);
local NumberFormat = require(Utility.NumberFormat);
local ServerRemote = Remotes.ServerRemote;
local LocalPlayer = Players.LocalPlayer;
local _ = workspace.World.Live;
local Scouter = Gui.Tech.Scouter;
local Spaceship = Gui.Tech.Spaceship;
local u1 = {};

function Clean_Connections()
    -- upvalues: u1 (copy)
    for _, v in pairs(u1) do
        v:Disconnect();
    end;
end;

return {
    ScouterRemove = function(p2) -- Line: 79
        local Victim = p2.Victim;

        if not Victim or Victim.Parent == nil then
            return;
        end;

        local HumanoidRootPart = Victim:FindFirstChild("HumanoidRootPart");

        if HumanoidRootPart then
            HumanoidRootPart = HumanoidRootPart:FindFirstChild("ScouterGui");
        end;

        if HumanoidRootPart then
            HumanoidRootPart:Destroy();
        end;
    end,

    ScouterAdd = function(p3) -- Line: 87
        -- upvalues: GlobalFunctions (copy), Players (copy), Scouter (copy), NumberFormat (copy), SoundManager (copy)
        local Character = p3.Character;
        local Victim = p3.Victim;
        local Range = p3.Range;
        local Color = p3.Color;
        local MaxCapacity = p3.MaxCapacity;
        local v4 = p3.FirstScan ~= false;
        local HumanoidRootPart = Victim:FindFirstChild("HumanoidRootPart");

        if HumanoidRootPart and HumanoidRootPart:FindFirstChild("ScouterGui") then
            return;
        end;

        local Color3_fromRGB_ret = Color3.fromRGB(255, 133, 62);
        local Color3_fromRGB_ret2 = Color3.fromRGB(255, 94, 65);
        local Color3_fromRGB_ret3 = Color3.fromRGB(255, 19, 11);
        local Color3_fromRGB_ret4 = Color3.fromRGB(255, 225, 150);
        local RootAndHumanoid = GlobalFunctions.GetRootAndHumanoid(Character);
        local RootAndHumanoid2 = GlobalFunctions.GetRootAndHumanoid(Victim);
        local PlayerFromCharacter = Players:GetPlayerFromCharacter(Victim);
        local u5 = Scouter.ScouterGui:Clone();
        u5.Parent = RootAndHumanoid2;
        local u6 = {};

        for _, child in ipairs(u5:GetChildren()) do
            if child:IsA("ImageButton") then
                u6[#u6 + 1] = {
                    Prop = "ImageColor3",
                    Item = child
                };
            elseif child:IsA("TextLabel") then
                u6[#u6 + 1] = {
                    Prop = "TextColor3",
                    Item = child
                };
            end;
        end;

        local function Change_Gui_To_Color(p7) -- Line: 132
            -- upvalues: u6 (copy), GlobalFunctions (ref)
            for _, v in ipairs(u6) do
                GlobalFunctions.Tween({
                    Instance = v.Item
                }, {
                    [v.Prop] = p7
                });
            end;
        end;

        local u8 = {
            [0] = Color3_fromRGB_ret4,
            [1] = Color3_fromRGB_ret,
            [2] = Color3_fromRGB_ret2,
            [3] = Color3_fromRGB_ret3
        };

        local function bandFor(p9) -- Line: 148
            -- upvalues: MaxCapacity (copy)
            return 0.9 * MaxCapacity <= p9 and 3 or (0.8 * MaxCapacity <= p9 and 2 or (0.6 * MaxCapacity <= p9 and 1 or 0));
        end;

        local u10 = nil;
        local u11 = nil;
        local PLText = u5:FindFirstChild("PLText");
        local u12 = 0;
        local u13 = false;
        local u14 = 0;

        local function writeText(p15) -- Line: 187
            -- upvalues: PLText (copy), NumberFormat (ref), u11 (ref)
            if not PLText or PLText.Parent == nil then
                return;
            end;

            local v16 = NumberFormat.Comma(p15);

            if v16 ~= u11 then
                u11 = v16;
                PLText.Text = v16;
            end;
        end;

        local function beginScramble() -- Line: 196
            -- upvalues: u12 (ref), u13 (ref), u14 (ref), u11 (ref), PLText (copy), NumberFormat (ref)
            u12 = u12 + 1;
            local u17 = u12;
            u13 = true;
            task.spawn(function() -- Line: 200
                -- upvalues: u14 (ref), u11 (ref), PLText (ref), NumberFormat (ref), u17 (copy), u12 (ref), u13 (ref)
                local math_floor_ret = math.floor(u14 or 0);
                local math_max_ret = math.max(math_floor_ret, 0);
                local u18 = tostring(math_max_ret);
                local u19 = #u18;
                local table_create_ret = table.create(u19);

                local function render(p20) -- Line: 209
                    -- upvalues: u19 (copy), table_create_ret (copy), u18 (copy), u11 (ref), math_max_ret (copy), PLText (ref), NumberFormat (ref)
                    for i = 1, u19 do
                        table_create_ret[i] = i <= p20 and u18:sub(i, i) or tostring(math.random(1, 9));
                        local _ = i;
                    end;

                    u11 = nil;
                    local v21 = tonumber(table.concat(table_create_ret)) or math_max_ret;

                    if PLText then
                        if PLText.Parent == nil then
                            return;
                        end;

                        local v22 = NumberFormat.Comma(v21);

                        if v22 ~= u11 then
                            u11 = v22;
                            PLText.Text = v22;
                        end;
                    end;
                end;

                for i = 0, u19 - 1 do
                    local v23 = 0.3 + math.random() * 0.8999999999999999;
                    local os_clock_ret = os.clock();
                    local v24 = i;

                    repeat
                        if u17 ~= u12 then
                            return;
                        end;

                        if not PLText or PLText.Parent == nil then
                            u13 = false;

                            return;
                        end;

                        render(v24);
                        task.wait(0.04);
                    until v23 <= os.clock() - os_clock_ret;
                end;

                if u17 ~= u12 then
                    return;
                end;

                u13 = false;
                u11 = nil;
                local v25 = u14;

                if PLText then
                    if PLText.Parent == nil then
                        return;
                    end;

                    local v26 = NumberFormat.Comma(v25);

                    if v26 ~= u11 then
                        u11 = v26;
                        PLText.Text = v26;
                    end;
                end;
            end);
        end;

        local function Change_Gui_Val(p27) -- Line: 240
            -- upvalues: u14 (ref), MaxCapacity (copy), u10 (ref), Change_Gui_To_Color (copy), u8 (copy), RootAndHumanoid2 (copy), SoundManager (ref), u13 (ref), PLText (copy), NumberFormat (ref), u11 (ref)
            local v28 = tonumber(p27) or 0;
            u14 = v28;
            local v29 = 0.9 * MaxCapacity <= v28 and 3 or (0.8 * MaxCapacity <= v28 and 2 or (0.6 * MaxCapacity <= v28 and 1 or 0));

            if v29 ~= u10 then
                u10 = v29;
                Change_Gui_To_Color(u8[v29]);

                if v29 == 3 and not RootAndHumanoid2:FindFirstChild("Scouter Alert") then
                    SoundManager.AddSound("Scouter Alert", {
                        Parent = RootAndHumanoid2
                    }, "Client");
                end;
            end;

            if u13 then
                return;
            end;

            if PLText then
                if PLText.Parent == nil then
                    return;
                end;

                local v30 = NumberFormat.Comma(v28);

                if v30 ~= u11 then
                    u11 = v30;
                    PLText.Text = v30;
                end;
            end;
        end;

        local u31 = Scouter.ScouterHighlight:Clone();
        u31.Parent = Victim;
        u31.FillColor = Color;
        local u32 = nil;

        local function teardown() -- Line: 267
            -- upvalues: u12 (ref), u13 (ref), u32 (ref), u5 (copy), u31 (copy)
            u12 = u12 + 1;
            u13 = false;

            if u32 then
                u32:Disconnect();
                u32 = nil;
            end;

            if u5 then
                u5:Destroy();
            end;

            if u31 then
                u31:Destroy();
            end;
        end;

        local v33;

        if PlayerFromCharacter then
            v33 = PlayerFromCharacter:FindFirstChild("PlayerStats");
            local v34;

            if v33 then
                v34 = v33:FindFirstChild("Race", true);
            else
                v34 = v33;
            end;

            if (v34 and v34.Value ~= "" and v34.Value or Victim:GetAttribute("Race")) == "Android" then
                u12 = u12 + 1;
                u13 = false;

                if u32 then
                    u32:Disconnect();
                    u32 = nil;
                end;

                if u5 then
                    u5:Destroy();
                end;

                if u31 then
                    u31:Destroy();
                end;

                return;
            end;

            if v33 then
                v33 = v33.StatData.CoreStats.PowerLevel;
            end;
        else
            v33 = Victim:FindFirstChild("PlayerStats");

            if v33 then
                v33 = v33:FindFirstChild("PowerLevel", true);
            end;
        end;

        if v33 then
            u32 = v33.Changed:Connect(Change_Gui_Val);
            Change_Gui_Val(v33.Value);
        else
            Change_Gui_Val(0);
        end;

        if v4 then
            u12 = u12 + 1;
            local u35 = u12;
            u13 = true;
            task.spawn(function() -- Line: 200
                -- upvalues: u14 (ref), u11 (ref), PLText (copy), NumberFormat (ref), u35 (copy), u12 (ref), u13 (ref)
                local math_floor_ret = math.floor(u14 or 0);
                local math_max_ret = math.max(math_floor_ret, 0);
                local u36 = tostring(math_max_ret);
                local u37 = #u36;
                local table_create_ret = table.create(u37);

                local function v41(p38) -- Line: 209
                    -- upvalues: u37 (copy), table_create_ret (copy), u36 (copy), u11 (ref), math_max_ret (copy), PLText (ref), NumberFormat (ref)
                    for i = 1, u37 do
                        table_create_ret[i] = i <= p38 and u36:sub(i, i) or tostring(math.random(1, 9));
                        local _ = i;
                    end;

                    u11 = nil;
                    local v39 = tonumber(table.concat(table_create_ret)) or math_max_ret;

                    if PLText then
                        if PLText.Parent == nil then
                            return;
                        end;

                        local v40 = NumberFormat.Comma(v39);

                        if v40 ~= u11 then
                            u11 = v40;
                            PLText.Text = v40;
                        end;
                    end;
                end;

                for i = 0, u37 - 1 do
                    local v42 = 0.3 + math.random() * 0.8999999999999999;
                    local os_clock_ret = os.clock();
                    local v43 = i;

                    repeat
                        if u35 ~= u12 then
                            return;
                        end;

                        if not PLText or PLText.Parent == nil then
                            u13 = false;

                            return;
                        end;

                        v41(v43);
                        task.wait(0.04);
                    until v42 <= os.clock() - os_clock_ret;
                end;

                if u35 ~= u12 then
                    return;
                end;

                u13 = false;
                u11 = nil;
                local v44 = u14;

                if PLText then
                    if PLText.Parent == nil then
                        return;
                    end;

                    local v45 = NumberFormat.Comma(v44);

                    if v45 ~= u11 then
                        u11 = v45;
                        PLText.Text = v45;
                    end;
                end;
            end);
        end;

        SoundManager.AddSound("Scouter Measure", {
            Parent = RootAndHumanoid2
        }, "Client");
        task.spawn(function() -- Line: 319
            -- upvalues: u5 (copy), Character (copy), RootAndHumanoid (copy), RootAndHumanoid2 (copy), Range (copy), u12 (ref), u13 (ref), u32 (ref), u31 (copy)
            while u5.Parent ~= nil and (Character:FindFirstChild("Scouter_On") and (RootAndHumanoid.Parent ~= nil and (RootAndHumanoid2.Parent ~= nil and Range > (RootAndHumanoid.Position - RootAndHumanoid2.Position).Magnitude))) do
                task.wait(0.2);
            end;

            u12 = u12 + 1;
            u13 = false;

            if u32 then
                u32:Disconnect();
                u32 = nil;
            end;

            if u5 then
                u5:Destroy();
            end;

            if u31 then
                u31:Destroy();
            end;
        end);
    end,

    ["Scouter On"] = function(p46) -- Line: 330
        -- upvalues: CinemaManager (copy), LocalPlayer (copy)
        CinemaManager.ColorFrame(LocalPlayer, {
            Action = "On",
            Color = p46.Color
        });
    end,

    ["Scouter Off"] = function(p47) -- Line: 341
        -- upvalues: CinemaManager (copy), LocalPlayer (copy)
        CinemaManager.ColorFrame(LocalPlayer, {
            Action = "Off",
            Color = p47.Color
        });
    end,

    ["Setup Ship"] = function(p48) -- Line: 357
        -- upvalues: Spaceship (copy), u1 (copy), ServerRemote (copy)
        local _ = p48.Character;
        local Spaceship2 = p48.Spaceship;
        local RealOwner = p48.RealOwner;
        local _ = Spaceship.SpacePod;
        local Fuel = p48.Fuel;
        local StartFuel = p48.StartFuel;
        local u49 = nil;
        local _ = {
            ["Fuel Gui"] = function(p50) -- Line: 369
                -- upvalues: StartFuel (copy), Fuel (copy), u1 (ref)
                local FuelMeter = p50.FuelFrame.FuelMeter;
                FuelMeter:TweenSize(UDim2.new(Fuel.Value / StartFuel, 0, 1, 0), "Out", "Sine", 0.1, true);
                u1[#u1 + 1] = Fuel.Changed:Connect(function(p51) -- Line: 377
                    -- upvalues: StartFuel (ref), FuelMeter (copy)
                    FuelMeter:TweenSize(UDim2.new(p51 / StartFuel, 0, 1, 0), "Out", "Sine", 0.1, true);
                end);
            end,

            ["Planet Gui"] = function(p52) -- Line: 384
                -- upvalues: u1 (ref), u49 (ref)
                local TextBox = p52.MainFrame.TextBox;
                u1[#u1 + 1] = TextBox:GetPropertyChangedSignal("Text"):Connect(function(p53) -- Line: 388
                    -- upvalues: u49 (ref), TextBox (copy)
                    u49 = TextBox.Text;
                end);
            end,

            ["Ship Buttons"] = function(p54) -- Line: 393
                -- upvalues: u1 (ref), ServerRemote (ref), Spaceship2 (copy), u49 (ref), RealOwner (copy)
                local MainFrame = p54.MainFrame;
                local Refuel = MainFrame.Refuel;
                u1[#u1 + 1] = MainFrame.Start.MouseButton1Up:Connect(function() -- Line: 398
                    -- upvalues: ServerRemote (ref), Spaceship2 (ref), u49 (ref), RealOwner (ref)
                    ServerRemote:FireServer(nil, {
                        Module = "TechManager",
                        Action = "Start Spaceship",
                        ActionType = "On",
                        Spaceship = Spaceship2,
                        Planet = u49,
                        RealOwner = RealOwner
                    });
                end);
                u1[#u1 + 1] = Refuel.MouseButton1Up:Connect(function() -- Line: 410
                    -- upvalues: ServerRemote (ref), Spaceship2 (ref), u49 (ref), RealOwner (ref)
                    ServerRemote:FireServer(nil, {
                        Module = "TechManager",
                        Action = "Refuel Spaceship",
                        ActionType = "On",
                        Spaceship = Spaceship2,
                        Planet = u49,
                        RealOwner = RealOwner
                    });
                end);
            end
        };
    end,

    ["Leave Ship"] = function(p55) -- Line: 439
        -- upvalues: LocalPlayer (copy)
        local _ = p55.Character;
        local _ = p55.Spaceship;

        for _, child in pairs(LocalPlayer.PlayerGui.PopupGui:GetChildren()) do
            if child:IsA("BillboardGui") then
                child:Destroy();
            end;
        end;

        Clean_Connections();
    end
};