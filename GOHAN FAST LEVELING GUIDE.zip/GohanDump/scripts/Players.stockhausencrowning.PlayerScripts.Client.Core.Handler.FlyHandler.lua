-- Decompiled with Potassium's decompiler.

local ReplicatedStorage = game:GetService("ReplicatedStorage");
local RunService = game:GetService("RunService");
local UserInputService = game:GetService("UserInputService");
local Players = game:GetService("Players");
local Modules = ReplicatedStorage:WaitForChild("Modules");
local Shared = Modules.Shared;
local Utility = Modules.Utility;
local GlobalFunctions = require(Modules.GlobalFunctions);
local AnimationManager = require(Shared.AnimationManager);
local SoundManager = require(Shared.SoundManager);
local Create = require(Utility.Create);
local StateManager = require(ReplicatedStorage.Modules.Metadata.ControlData.StateManager);
local ControlData = require(ReplicatedStorage.Modules.Metadata.ControlData.ControlData);
local Platform = require(Shared.Platform);
local u1 = Platform.IsTouch();

local function usingAnalogStick() -- Line: 85
    -- upvalues: u1 (copy), Platform (copy)
    return u1 or Platform.PreferGamepadGlyphs();
end;

local ServerRemote = ReplicatedStorage.Remotes.ServerRemote;
local TouchActionRemote = ReplicatedStorage.Remotes:WaitForChild("TouchActionRemote");
local LocalPlayer = Players.LocalPlayer;
local workspace_CurrentCamera = workspace.CurrentCamera;
local PlayerStats = LocalPlayer:FindFirstChild("PlayerStats");
local TempStats = PlayerStats:FindFirstChild("TempStats", true);
local AgilityBoost = PlayerStats:FindFirstChild("AgilityBoost", true);
local KiControl = PlayerStats:FindFirstChild("KiControl", true);
local TempKiControl = TempStats:FindFirstChild("TempKiControl");
local SpeedMultiplier = PlayerStats:FindFirstChild("SpeedMultiplier", true);
local u2 = {
    W = "FlyFoward",
    A = "FlyLeft",
    S = "FlyBackward",
    D = "FlyRight"
};
local u3 = {
    W = 1,
    A = 2,
    S = 3,
    D = 4,
    LeftControl = 5,
    Space = 6
};
local u4 = nil;

local function getFlyVelocity(p5) -- Line: 159
    local FlyAttachment = p5:FindFirstChild("FlyAttachment");

    if not FlyAttachment then
        FlyAttachment = Instance.new("Attachment");
        FlyAttachment.Name = "FlyAttachment";
        FlyAttachment.Parent = p5;
    end;

    local v6 = FlyAttachment:FindFirstChildOfClass("LinearVelocity");

    if not v6 then
        v6 = Instance.new("LinearVelocity");
        v6.Name = "FlyVelocity";
        v6.Attachment0 = FlyAttachment;
        v6.Parent = FlyAttachment;
    end;

    v6.MaxForce = math.max(FlyAttachment.Parent.AssemblyMass, 1) * 12000;
    v6.Enabled = true;

    return v6;
end;

local function getFaceOrientation(p7) -- Line: 182
    local FlyAttachment = p7:FindFirstChild("FlyAttachment");

    if not FlyAttachment then
        FlyAttachment = Instance.new("Attachment");
        FlyAttachment.Name = "FlyAttachment";
        FlyAttachment.Parent = p7;
    end;

    local v8 = FlyAttachment:FindFirstChildOfClass("AlignOrientation");

    if not v8 then
        v8 = Instance.new("AlignOrientation");
        v8.Attachment0 = FlyAttachment;
        v8.Mode = Enum.OrientationAlignmentMode.OneAttachment;
        v8.RigidityEnabled = false;
        v8.Responsiveness = 25;
        v8.MaxTorque = (1 / 0);
        v8.Parent = FlyAttachment;
    end;

    return v8;
end;

local function stopSession(p9) -- Line: 204
    -- upvalues: AnimationManager (copy), u2 (copy), GlobalFunctions (copy), u4 (ref)
    if not (p9 and p9.active) then
        return;
    end;

    p9.active = false;

    for _, v in ipairs(p9.connections) do
        if v.Connected then
            v:Disconnect();
        end;
    end;

    for i, v in pairs(p9.playing) do
        if v then
            AnimationManager.StopAnimation(p9.character, u2[i]);
        end;
    end;

    if p9.linearVelocity and p9.linearVelocity.Parent then
        p9.linearVelocity.VectorVelocity = Vector3.new(0, 0, 0);
        p9.linearVelocity.Enabled = false;
    end;

    if p9.alignOrientation and p9.alignOrientation.Parent then
        p9.alignOrientation:Destroy();
    end;

    local _, v10 = GlobalFunctions.GetRootAndHumanoid(p9.character);

    if v10 and v10.Parent then
        v10.AutoRotate = true;
    end;

    if u4 == p9 then
        u4 = nil;
    end;
end;

local function sweepIgnoreList(p11) -- Line: 246
    local v12 = { p11.character };
    local World = workspace:FindFirstChild("World");

    if World then
        local Visuals = World:FindFirstChild("Visuals");
        local Live = World:FindFirstChild("Live");

        if Visuals then
            table.insert(v12, Visuals);
        end;

        if Live then
            table.insert(v12, Live);
        end;
    end;

    return v12;
end;

local function computeDirectionVectors(p13) -- Line: 258
    -- upvalues: workspace_CurrentCamera (copy)
    return {
        workspace_CurrentCamera.CFrame.LookVector.Unit * p13,
        workspace_CurrentCamera.CFrame.RightVector.Unit * -p13,
        workspace_CurrentCamera.CFrame.LookVector.Unit * -p13,
        workspace_CurrentCamera.CFrame.RightVector.Unit * p13,
        Vector3.new(0, -20, 0),
        Vector3.new(0, 20, 0)
    };
end;

local function updateFlightAnimations(p14) -- Line: 272
    -- upvalues: u3 (copy), u2 (copy), AnimationManager (copy)
    for i, v in pairs(u3) do
        local v15 = u2[i];

        if v15 then
            local v16 = p14.directions[v] ~= 0;

            if v16 and not p14.playing[i] then
                p14.playing[i] = true;
                AnimationManager.PlayAnimation(p14.character, v15, {
                    Looped = true
                });
            elseif not v16 and p14.playing[i] then
                p14.playing[i] = false;
                AnimationManager.StopAnimation(p14.character, v15);
            end;
        end;
    end;
end;

local function bindHeartbeat(u17) -- Line: 288
    -- upvalues: RunService (copy), StateManager (copy), stopSession (copy), u1 (copy), Platform (copy), workspace_CurrentCamera (copy), computeDirectionVectors (copy), GlobalFunctions (copy), sweepIgnoreList (copy), ServerRemote (copy), SoundManager (copy), updateFlightAnimations (copy)
    local v27 = RunService.Heartbeat:Connect(function(p18) -- Line: 290
        -- upvalues: u17 (copy), StateManager (ref), stopSession (ref), u1 (ref), Platform (ref), workspace_CurrentCamera (ref), computeDirectionVectors (ref), GlobalFunctions (ref), sweepIgnoreList (ref), ServerRemote (ref), SoundManager (ref), updateFlightAnimations (ref)
        if not (u17.active and (u17.character.Parent and StateManager.IsInState(u17.character, "Flying"))) then
            stopSession(u17);

            return;
        end;

        local root = u17.root;
        local directions = u17.directions;

        if u1 or Platform.PreferGamepadGlyphs() then
            local v19 = u17.character:FindFirstChildOfClass("Humanoid");
            local v20 = v19 and v19.MoveDirection or Vector3.new(0, 0, 0);
            local v21 = 0;
            local v22 = 0;

            if v20.Magnitude > 0.05 then
                local Vector3_new_ret = Vector3.new(workspace_CurrentCamera.CFrame.LookVector.X, 0, workspace_CurrentCamera.CFrame.LookVector.Z);
                local Vector3_new_ret2 = Vector3.new(workspace_CurrentCamera.CFrame.RightVector.X, 0, workspace_CurrentCamera.CFrame.RightVector.Z);

                if Vector3_new_ret.Magnitude > 0.01 then
                    v21 = v20:Dot(Vector3_new_ret.Unit);
                end;

                if Vector3_new_ret2.Magnitude > 0.01 then
                    v22 = v20:Dot(Vector3_new_ret2.Unit);
                end;
            end;

            directions[1] = v21 > 0.25 and v21 and v21 or 0;
            directions[3] = v21 < -0.25 and -v21 or 0;
            directions[4] = v22 > 0.25 and v22 and v22 or 0;
            directions[2] = v22 < -0.25 and -v22 or 0;
        end;

        local math_min_ret = math.min(u17.speed, 250);

        if u17.currentSpeed < math_min_ret then
            u17.currentSpeed = math.min(u17.currentSpeed + (u17.boosting and 150 or 22) * p18, math_min_ret);
        elseif math_min_ret < u17.currentSpeed then
            u17.currentSpeed = math.max(u17.currentSpeed - 140 * p18, math_min_ret);
        end;

        local v23 = computeDirectionVectors(u17.currentSpeed);
        local v24 = Vector3.new(0, 0, 0) + v23[1] * directions[1] + v23[2] * directions[2] + v23[3] * directions[3] + v23[4] * directions[4] + v23[5] * directions[5] + v23[6] * directions[6];
        local Magnitude = v24.Magnitude;

        if Magnitude > 0.01 then
            local v25 = GlobalFunctions.CastRay(root.Position, v24.Unit * (Magnitude * p18 + 2.5), sweepIgnoreList(u17), true);

            if v25 then
                local v26 = math.max((v25.Position - root.Position).Magnitude - 2.5, 0) / math.max(p18, 0.004166666666666667);

                if v26 < Magnitude then
                    v24 = v24.Unit * v26;
                    u17.currentSpeed = math.min(u17.currentSpeed, v26);
                end;
            end;
        end;

        u17.linearVelocity.VectorVelocity = v24;
        local LookVector = workspace_CurrentCamera.CFrame.LookVector;

        if LookVector.Magnitude > 0.01 then
            u17.alignOrientation.CFrame = CFrame.lookAt(Vector3.new(0, 0, 0), LookVector.Unit);
        end;

        if directions[5] == 0 or not GlobalFunctions.CastRay(root.Position, Vector3.new(0, -3.5, 0), { u17.character }) then
            updateFlightAnimations(u17);

            return;
        end;

        ServerRemote:FireServer("Flight", {
            Action = "Terminate"
        });
        SoundManager.AddSound("Land", {
            Parent = root
        }, "Client");
        stopSession(u17);
    end);
    table.insert(u17.connections, v27);
end;

local function bindLandTap(u28) -- Line: 421
    -- upvalues: UserInputService (copy), Platform (copy), ServerRemote (copy)
    local v31 = UserInputService.InputBegan:Connect(function(p29, p30) -- Line: 423
        -- upvalues: u28 (copy), Platform (ref), ServerRemote (ref)
        if not u28.active then
            return;
        end;

        local Name = p29.KeyCode.Name;

        if Name ~= "Space" and Name ~= "ButtonA" then
            return;
        end;

        if Platform.InputBlocked(p29, p30) then
            return;
        end;

        if u28.spaceTapped then
            ServerRemote:FireServer("Flight", {
                Action = "Terminate"
            });

            return;
        end;

        u28.spaceTapped = true;
        task.delay(0.25, function() -- Line: 449
            -- upvalues: u28 (ref)
            u28.spaceTapped = false;
        end);
    end);
    table.insert(u28.connections, v31);
end;

local function boostKeyCode() -- Line: 467
    -- upvalues: ControlData (copy)
    local v32 = ControlData.Controls.CoreControls["Fast Fly"];

    if typeof(v32) == "table" then
        v32 = v32[1] or v32;
    end;

    return v32 and Enum.KeyCode[v32] or nil;
end;

local function boostSustained(p33) -- Line: 473
    -- upvalues: StateManager (copy), ControlData (copy), UserInputService (copy)
    if not p33.active then
        return false;
    end;

    if not StateManager.IsInState(p33.character, "Flying") then
        return false;
    end;

    if p33.touchBoost then
        return true;
    end;

    local v34 = ControlData.Controls.CoreControls["Fast Fly"];

    if typeof(v34) == "table" then
        v34 = v34[1] or v34;
    end;

    local v35 = v34 and Enum.KeyCode[v34] or nil;
    local v36;

    if v35 == nil then
        v36 = false;
    else
        v36 = UserInputService:IsKeyDown(v35) and UserInputService:IsKeyDown(Enum.KeyCode.W);
    end;

    return v36;
end;

local function startBoost(u37) -- Line: 483
    -- upvalues: StateManager (copy), AnimationManager (copy), Create (copy), ServerRemote (copy), boostSustained (copy), AgilityBoost (copy), KiControl (copy), TempKiControl (copy), SpeedMultiplier (copy)
    if not u37.active then
        return;
    end;

    if not StateManager.IsInState(u37.character, "Flying") then
        return;
    end;

    if u37.character:FindFirstChild("Boosting") then
        return;
    end;

    local v38 = AnimationManager.PlayAnimation(u37.character, "Fly Charge");
    Create.new(u37.character, "Boosting", 1);

    if not v38 then
        return;
    end;

    local u40 = v38:GetMarkerReachedSignal("Boost"):Once(function() -- Line: 493
        -- upvalues: ServerRemote (ref), u37 (copy), boostSustained (ref), AgilityBoost (ref), KiControl (ref), TempKiControl (ref), SpeedMultiplier (ref)
        ServerRemote:FireServer("Flight", {
            Action = "Boost Execute"
        });
        u37.boosting = true;
        local v39 = 2;

        while boostSustained(u37) do
            u37.speed = math.clamp((100 + AgilityBoost.Value + (KiControl.Value + TempKiControl.Value) / 3) * SpeedMultiplier.Value * v39, u37.speed, 250);
            v39 = math.max(v39 - 0.1, 1);
            task.wait(0.15);
        end;

        ServerRemote:FireServer("Flight", {
            Action = "Boost Terminate"
        });
        u37.boosting = false;
        u37.touchBoost = false;
        u37.speed = 40;
    end);
    task.delay(3, function() -- Line: 515
        -- upvalues: u40 (ref)
        if u40 and u40.Connected then
            u40:Disconnect();
        end;
    end);
end;

local function bindBoost(u41) -- Line: 520
    -- upvalues: UserInputService (copy), ControlData (copy), startBoost (copy), TouchActionRemote (copy)
    local v46 = UserInputService.InputBegan:Connect(function(p42, p43) -- Line: 521
        -- upvalues: u41 (copy), ControlData (ref), UserInputService (ref), startBoost (ref)
        if p43 or not u41.active then
            return;
        end;

        local v44 = ControlData.Controls.CoreControls["Fast Fly"];

        if typeof(v44) == "table" then
            v44 = v44[1] or v44;
        end;

        local v45 = v44 and Enum.KeyCode[v44] or nil;

        if not v45 or p42.KeyCode ~= v45 then
            return;
        end;

        if not UserInputService:IsKeyDown(Enum.KeyCode.W) then
            return;
        end;

        startBoost(u41);
    end);
    local v49 = TouchActionRemote.Event:Connect(function(p47, p48) -- Line: 530
        -- upvalues: u41 (copy), startBoost (ref)
        if p47 ~= "CoreControls" or p48 ~= "Fast Fly" then
            return;
        end;

        if not u41.active then
            return;
        end;

        if u41.touchBoost or u41.boosting then
            u41.touchBoost = false;

            return;
        end;

        u41.touchBoost = true;
        startBoost(u41);
    end);
    u41.touchConn = v49;
    table.insert(u41.connections, v46);
    table.insert(u41.connections, v49);
end;

local function ensureSession(p50) -- Line: 545
    -- upvalues: u4 (ref), stopSession (copy), GlobalFunctions (copy), getFlyVelocity (copy), getFaceOrientation (copy), RunService (copy), StateManager (copy), u1 (copy), Platform (copy), workspace_CurrentCamera (copy), computeDirectionVectors (copy), sweepIgnoreList (copy), ServerRemote (copy), SoundManager (copy), updateFlightAnimations (copy), UserInputService (copy), bindBoost (copy)
    if u4 and (u4.active and u4.character == p50) then
        return u4;
    end;

    if u4 then
        stopSession(u4);
    end;

    local RootAndHumanoid = GlobalFunctions.GetRootAndHumanoid(p50);

    if not RootAndHumanoid then
        return nil;
    end;

    local _, v51 = GlobalFunctions.GetRootAndHumanoid(p50);

    if v51 then
        v51.AutoRotate = false;
    end;

    local u52 = {
        active = true,
        speed = 40,
        currentSpeed = 15,
        boosting = false,
        spaceTapped = false,
        character = p50,
        root = RootAndHumanoid,
        linearVelocity = getFlyVelocity(RootAndHumanoid),
        alignOrientation = getFaceOrientation(RootAndHumanoid),
        directions = { 0, 0, 0, 0, 0, 0 },
        playing = {},
        connections = {}
    };
    u4 = u52;
    local v62 = RunService.Heartbeat:Connect(function(p53) -- Line: 290
        -- upvalues: u52 (copy), StateManager (ref), stopSession (ref), u1 (ref), Platform (ref), workspace_CurrentCamera (ref), computeDirectionVectors (ref), GlobalFunctions (ref), sweepIgnoreList (ref), ServerRemote (ref), SoundManager (ref), updateFlightAnimations (ref)
        if not (u52.active and (u52.character.Parent and StateManager.IsInState(u52.character, "Flying"))) then
            stopSession(u52);

            return;
        end;

        local root = u52.root;
        local directions = u52.directions;

        if u1 or Platform.PreferGamepadGlyphs() then
            local v54 = u52.character:FindFirstChildOfClass("Humanoid");
            local v55 = v54 and v54.MoveDirection or Vector3.new(0, 0, 0);
            local v56 = 0;
            local v57 = 0;

            if v55.Magnitude > 0.05 then
                local Vector3_new_ret = Vector3.new(workspace_CurrentCamera.CFrame.LookVector.X, 0, workspace_CurrentCamera.CFrame.LookVector.Z);
                local Vector3_new_ret2 = Vector3.new(workspace_CurrentCamera.CFrame.RightVector.X, 0, workspace_CurrentCamera.CFrame.RightVector.Z);

                if Vector3_new_ret.Magnitude > 0.01 then
                    v56 = v55:Dot(Vector3_new_ret.Unit);
                end;

                if Vector3_new_ret2.Magnitude > 0.01 then
                    v57 = v55:Dot(Vector3_new_ret2.Unit);
                end;
            end;

            directions[1] = v56 > 0.25 and v56 and v56 or 0;
            directions[3] = v56 < -0.25 and -v56 or 0;
            directions[4] = v57 > 0.25 and v57 and v57 or 0;
            directions[2] = v57 < -0.25 and -v57 or 0;
        end;

        local math_min_ret = math.min(u52.speed, 250);

        if u52.currentSpeed < math_min_ret then
            u52.currentSpeed = math.min(u52.currentSpeed + (u52.boosting and 150 or 22) * p53, math_min_ret);
        elseif math_min_ret < u52.currentSpeed then
            u52.currentSpeed = math.max(u52.currentSpeed - 140 * p53, math_min_ret);
        end;

        local v58 = computeDirectionVectors(u52.currentSpeed);
        local v59 = Vector3.new(0, 0, 0) + v58[1] * directions[1] + v58[2] * directions[2] + v58[3] * directions[3] + v58[4] * directions[4] + v58[5] * directions[5] + v58[6] * directions[6];
        local Magnitude = v59.Magnitude;

        if Magnitude > 0.01 then
            local v60 = GlobalFunctions.CastRay(root.Position, v59.Unit * (Magnitude * p53 + 2.5), sweepIgnoreList(u52), true);

            if v60 then
                local v61 = math.max((v60.Position - root.Position).Magnitude - 2.5, 0) / math.max(p53, 0.004166666666666667);

                if v61 < Magnitude then
                    v59 = v59.Unit * v61;
                    u52.currentSpeed = math.min(u52.currentSpeed, v61);
                end;
            end;
        end;

        u52.linearVelocity.VectorVelocity = v59;
        local LookVector = workspace_CurrentCamera.CFrame.LookVector;

        if LookVector.Magnitude > 0.01 then
            u52.alignOrientation.CFrame = CFrame.lookAt(Vector3.new(0, 0, 0), LookVector.Unit);
        end;

        if directions[5] == 0 or not GlobalFunctions.CastRay(root.Position, Vector3.new(0, -3.5, 0), { u52.character }) then
            updateFlightAnimations(u52);

            return;
        end;

        ServerRemote:FireServer("Flight", {
            Action = "Terminate"
        });
        SoundManager.AddSound("Land", {
            Parent = root
        }, "Client");
        stopSession(u52);
    end);
    table.insert(u52.connections, v62);
    local v65 = UserInputService.InputBegan:Connect(function(p63, p64) -- Line: 423
        -- upvalues: u52 (copy), Platform (ref), ServerRemote (ref)
        if not u52.active then
            return;
        end;

        local Name = p63.KeyCode.Name;

        if Name ~= "Space" and Name ~= "ButtonA" then
            return;
        end;

        if Platform.InputBlocked(p63, p64) then
            return;
        end;

        if u52.spaceTapped then
            ServerRemote:FireServer("Flight", {
                Action = "Terminate"
            });

            return;
        end;

        u52.spaceTapped = true;
        task.delay(0.25, function() -- Line: 449
            -- upvalues: u52 (ref)
            u52.spaceTapped = false;
        end);
    end);
    table.insert(u52.connections, v65);
    bindBoost(u52);

    return u52;
end;

return {
    Move = {
        Execute = function(p66, p67) -- Line: 589
            -- upvalues: LocalPlayer (copy), ensureSession (copy), u3 (copy)
            local v68 = ensureSession(LocalPlayer.Character or LocalPlayer.CharacterAdded:Wait());

            if not v68 then
                return;
            end;

            local v69 = u3[p67];

            if v69 then
                v68.directions[v69] = 1;
            end;
        end,

        Terminate = function(p70, p71) -- Line: 600
            -- upvalues: u4 (ref), u3 (copy)
            if not (u4 and u4.active) then
                return;
            end;

            local v72 = u3[p71];

            if v72 then
                u4.directions[v72] = 0;
            end;
        end
    }
};