-- Decompiled with Potassium's decompiler.

local Players = game:GetService("Players");
game:GetService("Debris");
local ReplicatedStorage = game:GetService("ReplicatedStorage");
game:GetService("TweenService");
game:GetService("RunService");
game:GetService("UserInputService");
local _ = ReplicatedStorage.Assets;
local Modules = ReplicatedStorage:WaitForChild("Modules");
ReplicatedStorage:WaitForChild("Remotes");
local Metadata = Modules.Metadata;
local _ = Modules.Utility;
local CinemaManager = require(Modules.Shared.CinemaManager);
local ControlData = require(Metadata.ControlData.ControlData);
local LocalPlayer = Players.LocalPlayer;
local CoreControls = ControlData.Controls.CoreControls;

return {
    Flash = function(p1) -- Line: 32
        -- upvalues: CinemaManager (copy), LocalPlayer (copy)
        CinemaManager.Flash(LocalPlayer, p1.Duration or 1, p1.Delay or 0);
    end,

    Transition = function() -- Line: 38
        -- upvalues: CinemaManager (copy), LocalPlayer (copy)
        CinemaManager.Transition(LocalPlayer);
    end,

    Announce = function(p2) -- Line: 45
        -- upvalues: CinemaManager (copy), LocalPlayer (copy)
        CinemaManager.Annouce(LocalPlayer, p2.Annoucer, p2.Message, p2);
    end,

    ForceCinema = function(p3) -- Line: 61
        -- upvalues: CoreControls (copy), CinemaManager (copy), LocalPlayer (copy)
        local v4 = p3.Mode == "On";

        if v4 == (CoreControls.CinemaOn == true) then
            return;
        end;

        CoreControls.CinemaOn = v4;

        if v4 then
            CinemaManager.FadeIn(LocalPlayer, nil, {
                Strict = true
            });

            return;
        end;

        CinemaManager.FadeOut(LocalPlayer);
    end
};