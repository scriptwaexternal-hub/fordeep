-- Decompiled with Potassium's decompiler.

local Players = game:GetService("Players");
local ReplicatedStorage = game:GetService("ReplicatedStorage");
local TweenService = game:GetService("TweenService");
local GuiService = game:GetService("GuiService");
game:GetService("UserInputService");
local SpaceshipConfig = require(ReplicatedStorage.Modules.Metadata.MiscData.TechData.SpaceshipConfig);
local SpaceshipFlight = require(script.Parent.Parent.Parent.Handler.SpaceshipFlight);
local SpaceshipRemote = ReplicatedStorage.Remotes:WaitForChild("SpaceshipRemote");
local ServerRemote = ReplicatedStorage.Remotes:WaitForChild("ServerRemote");
local LocalPlayer = Players.LocalPlayer;
local PlayerGui = LocalPlayer:WaitForChild("PlayerGui");
local u1 = { "HUD", "MissionGui", "LoreThoughtsGui" };
local Color3_fromRGB_ret = Color3.fromRGB(255, 138, 30);
local Color3_fromRGB_ret2 = Color3.fromRGB(255, 198, 40);
local Color3_fromRGB_ret3 = Color3.fromRGB(178, 34, 34);
local Color3_fromRGB_ret4 = Color3.fromRGB(16, 12, 10);
local Color3_fromRGB_ret5 = Color3.fromRGB(28, 22, 18);
local Color3_fromRGB_ret6 = Color3.fromRGB(255, 244, 224);
local Color3_fromRGB_ret7 = Color3.fromRGB(168, 148, 128);
local Color3_fromRGB_ret8 = Color3.fromRGB(90, 200, 120);
local Color3_fromRGB_ret9 = Color3.fromRGB(226, 62, 48);
local Color3_fromRGB_ret10 = Color3.fromRGB(226, 100, 40);
Color3.fromRGB(44, 44, 45);
local Arcade = Enum.Font.Arcade;
local Bangers = Enum.Font.Bangers;
local u2 = {};
local u3 = nil;
local u4 = nil;
local u5 = {};
local u6 = {};
local u7 = nil;
local u8 = 0;

local function ink(p9, p10) -- Line: 72
    -- upvalues: Color3_fromRGB_ret4 (copy)
    local UIStroke = Instance.new("UIStroke");
    UIStroke.Color = Color3_fromRGB_ret4;
    UIStroke.Thickness = p10 or 1.5;
    UIStroke.ApplyStrokeMode = Enum.ApplyStrokeMode.Border;
    UIStroke.Parent = p9;

    return UIStroke;
end;

local function bevel(p11, p12) -- Line: 82
    return nil;
end;

local function slantGradient(p13, p14, p15) -- Line: 85
    return nil;
end;

local function stroked(p16) -- Line: 88
    -- upvalues: Color3_fromRGB_ret4 (copy)
    p16.TextStrokeColor3 = Color3_fromRGB_ret4;
    p16.TextStrokeTransparency = 0.5;

    return p16;
end;

local function makeButton(p17, p18, p19, p20) -- Line: 94
    -- upvalues: Color3_fromRGB_ret (copy), Arcade (copy), Color3_fromRGB_ret4 (copy)
    local TextButton = Instance.new("TextButton");
    TextButton.Name = p18;
    TextButton.Size = UDim2.new(1, 0, 0, 34);
    TextButton.BackgroundColor3 = Color3_fromRGB_ret;
    TextButton.BorderSizePixel = 0;
    TextButton.AutoButtonColor = true;
    TextButton.Font = Arcade;
    TextButton.TextSize = 15;
    TextButton.TextColor3 = Color3_fromRGB_ret4;
    TextButton.Text = p19;
    TextButton.LayoutOrder = p20;
    TextButton.Selectable = true;
    TextButton.Parent = p17;
    local UIStroke = Instance.new("UIStroke");
    UIStroke.Color = Color3_fromRGB_ret4;
    UIStroke.Thickness = 1.5;
    UIStroke.ApplyStrokeMode = Enum.ApplyStrokeMode.Border;
    UIStroke.Parent = TextButton;

    return TextButton;
end;

local function makeBar(p21, p22, p23, p24) -- Line: 112
    -- upvalues: Arcade (copy), Color3_fromRGB_ret2 (copy), Color3_fromRGB_ret4 (copy), Bangers (copy), Color3_fromRGB_ret6 (copy)
    local Frame = Instance.new("Frame");
    Frame.BackgroundTransparency = 1;
    Frame.Size = UDim2.new(1, -26, 0, 32);
    Frame.Position = UDim2.new(0, 13, 0, p23);
    Frame.Parent = p21;
    local TextLabel = Instance.new("TextLabel");
    TextLabel.BackgroundTransparency = 1;
    TextLabel.Size = UDim2.new(0.5, 0, 0, 14);
    TextLabel.Font = Arcade;
    TextLabel.TextSize = 13;
    TextLabel.TextColor3 = Color3_fromRGB_ret2;
    TextLabel.TextXAlignment = Enum.TextXAlignment.Left;
    TextLabel.Text = p22;
    TextLabel.TextStrokeColor3 = Color3_fromRGB_ret4;
    TextLabel.TextStrokeTransparency = 0.5;
    TextLabel.Parent = Frame;
    local TextLabel2 = Instance.new("TextLabel");
    TextLabel2.Name = "Value";
    TextLabel2.BackgroundTransparency = 1;
    TextLabel2.Size = UDim2.new(0.5, 0, 0, 14);
    TextLabel2.Position = UDim2.new(0.5, 0, 0, 0);
    TextLabel2.Font = Bangers;
    TextLabel2.TextSize = 15;
    TextLabel2.TextColor3 = Color3_fromRGB_ret6;
    TextLabel2.TextXAlignment = Enum.TextXAlignment.Right;
    TextLabel2.Text = "--";
    TextLabel2.TextStrokeColor3 = Color3_fromRGB_ret4;
    TextLabel2.TextStrokeTransparency = 0.5;
    TextLabel2.Parent = Frame;
    local Frame2 = Instance.new("Frame");
    Frame2.BackgroundColor3 = Color3_fromRGB_ret4;
    Frame2.BorderSizePixel = 0;
    Frame2.Size = UDim2.new(1, 0, 0, 10);
    Frame2.Position = UDim2.new(0, 0, 0, 17);
    Frame2.Parent = Frame;
    local UIStroke = Instance.new("UIStroke");
    UIStroke.Color = Color3_fromRGB_ret4;
    UIStroke.Thickness = 1.5;
    UIStroke.ApplyStrokeMode = Enum.ApplyStrokeMode.Border;
    UIStroke.Parent = Frame2;
    local Frame3 = Instance.new("Frame");
    Frame3.Name = "Fill";
    Frame3.BackgroundColor3 = p24;
    Frame3.BorderSizePixel = 0;
    Frame3.Size = UDim2.new(1, 0, 1, 0);
    Frame3.Parent = Frame2;

    return {
        Value = TextLabel2,
        Fill = Frame3
    };
end;

local function build() -- Line: 159
    -- upvalues: u3 (ref), PlayerGui (copy), Color3_fromRGB_ret5 (copy), Color3_fromRGB_ret4 (copy), Color3_fromRGB_ret (copy), Color3_fromRGB_ret2 (copy), Arcade (copy), makeBar (copy), Color3_fromRGB_ret8 (copy), Color3_fromRGB_ret2 (copy), Bangers (copy), Color3_fromRGB_ret7 (copy), makeButton (copy), Color3_fromRGB_ret3 (copy), Color3_fromRGB_ret6 (copy), SpaceshipConfig (copy), u4 (ref), GuiService (copy), SpaceshipRemote (copy), u6 (ref), ServerRemote (copy), u2 (copy)
    u3 = Instance.new("ScreenGui");
    u3.Name = "SpaceshipHUD";
    u3.ResetOnSpawn = false;
    u3.IgnoreGuiInset = true;
    u3.ZIndexBehavior = Enum.ZIndexBehavior.Sibling;
    u3.DisplayOrder = 20;
    u3.Enabled = false;
    u3.Parent = PlayerGui;
    local Frame = Instance.new("Frame");
    Frame.AnchorPoint = Vector2.new(0, 1);
    Frame.Position = UDim2.new(0, 20, 1, -20);
    Frame.Size = UDim2.new(0, 250, 0, 126);
    Frame.BackgroundColor3 = Color3_fromRGB_ret5;
    Frame.BorderSizePixel = 0;
    Frame.Parent = u3;
    local UIStroke = Instance.new("UIStroke");
    UIStroke.Color = Color3_fromRGB_ret4;
    UIStroke.Thickness = 3;
    UIStroke.ApplyStrokeMode = Enum.ApplyStrokeMode.Border;
    UIStroke.Parent = Frame;
    local Frame2 = Instance.new("Frame");
    Frame2.Size = UDim2.new(1, 0, 0, 22);
    Frame2.BackgroundColor3 = Color3_fromRGB_ret;
    Frame2.BorderSizePixel = 0;
    Frame2.Parent = Frame;
    local TextLabel = Instance.new("TextLabel");
    TextLabel.BackgroundTransparency = 1;
    TextLabel.Size = UDim2.new(1, -16, 1, 0);
    TextLabel.Position = UDim2.new(0, 8, 0, 0);
    TextLabel.Font = Arcade;
    TextLabel.TextSize = 15;
    TextLabel.TextColor3 = Color3_fromRGB_ret4;
    TextLabel.TextXAlignment = Enum.TextXAlignment.Left;
    TextLabel.Text = "SPACE POD";
    TextLabel.TextStrokeColor3 = Color3_fromRGB_ret4;
    TextLabel.TextStrokeTransparency = 0.5;
    TextLabel.Parent = Frame2;
    TextLabel.TextStrokeTransparency = 0.8;
    local TextLabel2 = Instance.new("TextLabel");
    TextLabel2.Name = "Mode";
    TextLabel2.BackgroundTransparency = 1;
    TextLabel2.Size = UDim2.new(1, -16, 1, 0);
    TextLabel2.Position = UDim2.new(0, -8, 0, 0);
    TextLabel2.Font = Arcade;
    TextLabel2.TextSize = 12;
    TextLabel2.TextColor3 = Color3_fromRGB_ret4;
    TextLabel2.TextXAlignment = Enum.TextXAlignment.Right;
    TextLabel2.Text = "LANDED";
    TextLabel2.Parent = Frame2;
    local v25 = makeBar(Frame, "HULL", 30, Color3_fromRGB_ret8);
    local v26 = makeBar(Frame, "FUEL", 66, Color3_fromRGB_ret2);
    local TextLabel3 = Instance.new("TextLabel");
    TextLabel3.Name = "Readout";
    TextLabel3.BackgroundTransparency = 1;
    TextLabel3.Position = UDim2.new(0, 13, 0, 102);
    TextLabel3.Size = UDim2.new(1, -26, 0, 14);
    TextLabel3.Font = Bangers;
    TextLabel3.TextSize = 14;
    TextLabel3.TextColor3 = Color3_fromRGB_ret7;
    TextLabel3.TextXAlignment = Enum.TextXAlignment.Left;
    TextLabel3.Text = "SPD 0   ALT 0";
    TextLabel3.TextStrokeColor3 = Color3_fromRGB_ret4;
    TextLabel3.TextStrokeTransparency = 0.5;
    TextLabel3.Parent = Frame;
    local Frame3 = Instance.new("Frame");
    Frame3.Name = "Actions";
    Frame3.AnchorPoint = Vector2.new(1, 1);
    Frame3.Position = UDim2.new(1, -20, 1, -20);
    Frame3.Size = UDim2.new(0, 132, 0, 240);
    Frame3.BackgroundTransparency = 1;
    Frame3.Parent = u3;
    local UIListLayout = Instance.new("UIListLayout");
    UIListLayout.SortOrder = Enum.SortOrder.LayoutOrder;
    UIListLayout.VerticalAlignment = Enum.VerticalAlignment.Bottom;
    UIListLayout.Padding = UDim.new(0, 6);
    UIListLayout.Parent = Frame3;
    local v27 = makeButton(Frame3, "Orbit", "ENTER ORBIT", 1);
    local v28 = makeButton(Frame3, "Launch", "LAUNCH", 2);
    local v29 = makeButton(Frame3, "Land", "LAND", 3);
    local v30 = makeButton(Frame3, "Refuel", "REFUEL", 4);
    local v31 = makeButton(Frame3, "Repair", "REPAIR", 5);
    local v32 = makeButton(Frame3, "Eject", "EJECT", 6);
    v32.BackgroundColor3 = Color3_fromRGB_ret3;
    v32.TextColor3 = Color3_fromRGB_ret6;
    v28.Visible = false;
    local TextLabel4 = Instance.new("TextLabel");
    TextLabel4.Name = "Status";
    TextLabel4.AnchorPoint = Vector2.new(0.5, 0);
    TextLabel4.Position = UDim2.new(0.5, 0, 0, 74);
    TextLabel4.Size = UDim2.new(0, 460, 0, 26);
    TextLabel4.BackgroundTransparency = 1;
    TextLabel4.Font = Arcade;
    TextLabel4.TextSize = 18;
    TextLabel4.TextColor3 = Color3_fromRGB_ret2;
    TextLabel4.Text = "";
    TextLabel4.TextStrokeColor3 = Color3_fromRGB_ret4;
    TextLabel4.TextStrokeTransparency = 0.5;
    TextLabel4.Parent = u3;
    TextLabel4.TextStrokeTransparency = 0.25;
    local Frame4 = Instance.new("Frame");
    Frame4.Name = "Flash";
    Frame4.Size = UDim2.new(1, 0, 1, 0);
    Frame4.BackgroundColor3 = Color3.fromRGB(255, 40, 40);
    Frame4.BackgroundTransparency = 1;
    Frame4.BorderSizePixel = 0;
    Frame4.ZIndex = 0;
    Frame4.Parent = u3;
    local Frame5 = Instance.new("Frame");
    Frame5.Name = "OrbitPanel";
    Frame5.AnchorPoint = Vector2.new(0.5, 0.5);
    Frame5.Position = UDim2.new(0.5, 0, 0.5, 0);
    Frame5.Size = UDim2.new(0, 380, 0, 190);
    Frame5.BackgroundColor3 = Color3_fromRGB_ret5;
    Frame5.BorderSizePixel = 0;
    Frame5.Visible = false;
    Frame5.Parent = u3;
    local UIStroke2 = Instance.new("UIStroke");
    UIStroke2.Color = Color3_fromRGB_ret4;
    UIStroke2.Thickness = 3;
    UIStroke2.ApplyStrokeMode = Enum.ApplyStrokeMode.Border;
    UIStroke2.Parent = Frame5;
    local Frame6 = Instance.new("Frame");
    Frame6.Size = UDim2.new(1, 0, 0, 30);
    Frame6.BackgroundColor3 = Color3_fromRGB_ret;
    Frame6.BorderSizePixel = 0;
    Frame6.Parent = Frame5;
    local TextLabel5 = Instance.new("TextLabel");
    TextLabel5.BackgroundTransparency = 1;
    TextLabel5.Size = UDim2.new(1, 0, 1, 0);
    TextLabel5.Font = Arcade;
    TextLabel5.TextSize = 17;
    TextLabel5.TextColor3 = Color3_fromRGB_ret4;
    TextLabel5.Text = "SELECT DESTINATION";
    TextLabel5.TextStrokeColor3 = Color3_fromRGB_ret4;
    TextLabel5.TextStrokeTransparency = 0.5;
    TextLabel5.Parent = Frame6;
    TextLabel5.TextStrokeTransparency = 0.8;
    local Frame7 = Instance.new("Frame");
    Frame7.Name = "List";
    Frame7.BackgroundTransparency = 1;
    Frame7.Position = UDim2.new(0, 14, 0, 42);
    Frame7.Size = UDim2.new(1, -28, 1, -88);
    Frame7.Parent = Frame5;
    local UIListLayout2 = Instance.new("UIListLayout");
    UIListLayout2.Padding = UDim.new(0, 6);
    UIListLayout2.SortOrder = Enum.SortOrder.LayoutOrder;
    UIListLayout2.Parent = Frame7;
    local TextLabel6 = Instance.new("TextLabel");
    TextLabel6.Name = "Cost";
    TextLabel6.BackgroundTransparency = 1;
    TextLabel6.AnchorPoint = Vector2.new(0.5, 1);
    TextLabel6.Position = UDim2.new(0.5, 0, 1, -20);
    TextLabel6.Size = UDim2.new(1, -28, 0, 14);
    TextLabel6.Font = Bangers;
    TextLabel6.TextSize = 14;
    TextLabel6.TextColor3 = Color3_fromRGB_ret7;
    TextLabel6.Text = ("JUMP COST: %d FUEL"):format(SpaceshipConfig.ORBIT_FUEL_COST);
    TextLabel6.TextStrokeColor3 = Color3_fromRGB_ret4;
    TextLabel6.TextStrokeTransparency = 0.5;
    TextLabel6.Parent = Frame5;
    local TextButton = Instance.new("TextButton");
    TextButton.Name = "Close";
    TextButton.AnchorPoint = Vector2.new(0.5, 1);
    TextButton.Position = UDim2.new(0.5, 0, 1, -4);
    TextButton.Size = UDim2.new(0, 90, 0, 16);
    TextButton.BackgroundTransparency = 1;
    TextButton.Font = Arcade;
    TextButton.TextSize = 13;
    TextButton.TextColor3 = Color3_fromRGB_ret7;
    TextButton.Text = "CLOSE";
    TextButton.Selectable = true;
    TextButton.TextStrokeColor3 = Color3_fromRGB_ret4;
    TextButton.TextStrokeTransparency = 0.5;
    TextButton.Parent = Frame5;
    u4 = {
        Panel = Frame,
        Mode = TextLabel2,
        Health = v25,
        Fuel = v26,
        Readout = TextLabel3,
        Status = TextLabel4,
        Flash = Frame4,
        Orbit = Frame5,
        OrbitList = Frame7,
        Close = TextButton,
        Actions = Frame3,
        BtnOrbit = v27,
        BtnLaunch = v28,
        BtnLand = v29,
        BtnEject = v32,
        BtnRefuel = v30,
        BtnRepair = v31
    };
    GuiService:AddSelectionParent("SpaceshipActions", Frame3);
    GuiService:AddSelectionParent("SpaceshipPlanets", Frame5);
    v27.Activated:Connect(function() -- Line: 363
        -- upvalues: SpaceshipRemote (ref), u6 (ref)
        SpaceshipRemote:FireServer("Autopilot", {
            Enable = not u6.Autopilot
        });
    end);
    v29.Activated:Connect(function() -- Line: 366
        -- upvalues: SpaceshipRemote (ref)
        SpaceshipRemote:FireServer("Land", {});
    end);
    v32.Activated:Connect(function() -- Line: 369
        -- upvalues: SpaceshipRemote (ref)
        SpaceshipRemote:FireServer("Exit", {});
    end);
    v30.Activated:Connect(function() -- Line: 372
        -- upvalues: ServerRemote (ref)
        ServerRemote:FireServer(nil, {
            Module = "TechManager",
            Action = "Refuel Spaceship"
        });
    end);
    v31.Activated:Connect(function() -- Line: 375
        -- upvalues: ServerRemote (ref)
        ServerRemote:FireServer(nil, {
            Module = "TechManager",
            Action = "Repair Spaceship"
        });
    end);
    v28.Activated:Connect(function() -- Line: 378
        -- upvalues: u2 (ref)
        u2.SetOrbitPanel(true);
    end);
    TextButton.Activated:Connect(function() -- Line: 381
        -- upvalues: u2 (ref)
        u2.SetOrbitPanel(false);
    end);
end;

local u33 = {};

local function buildPlanetButtons() -- Line: 392
    -- upvalues: u33 (copy), ReplicatedStorage (copy), Color3_fromRGB_ret (copy), Arcade (copy), Color3_fromRGB_ret4 (copy), u4 (ref), SpaceshipRemote (copy), u2 (copy)
    for _, v in ipairs(u33) do
        v:Destroy();
    end;

    table.clear(u33);
    local SpaceshipData = require(ReplicatedStorage.Modules.Metadata.MiscData.TechData.SpaceshipData);

    for i, v in ipairs(SpaceshipData.Planets) do
        local TextButton = Instance.new("TextButton");
        TextButton.Name = v;
        TextButton.Size = UDim2.new(1, 0, 0, 30);
        TextButton.BackgroundColor3 = Color3_fromRGB_ret;
        TextButton.BorderSizePixel = 0;
        TextButton.Font = Arcade;
        TextButton.TextSize = 16;
        TextButton.TextColor3 = Color3_fromRGB_ret4;
        TextButton.Text = string.upper(v);
        TextButton.AutoButtonColor = true;
        TextButton.LayoutOrder = i;
        TextButton.Selectable = true;
        TextButton.Parent = u4.OrbitList;
        local UIStroke = Instance.new("UIStroke");
        UIStroke.Color = Color3_fromRGB_ret4;
        UIStroke.Thickness = 1.5;
        UIStroke.ApplyStrokeMode = Enum.ApplyStrokeMode.Border;
        UIStroke.Parent = TextButton;
        TextButton.Activated:Connect(function() -- Line: 413
            -- upvalues: SpaceshipRemote (ref), v (copy), u2 (ref)
            SpaceshipRemote:FireServer("Travel", {
                Planet = v
            });
            u2.SetOrbitPanel(false);
        end);
        u33[#u33 + 1] = TextButton;
    end;
end;

function u2.SetOrbitPanel(p34) -- Line: 421
    -- upvalues: u4 (ref), u33 (copy), GuiService (copy)
    if not u4 then
        return;
    end;

    u4.Orbit.Visible = p34 and true or false;

    if p34 then
        if u33[1] then
            GuiService.SelectedObject = u33[1];
        end;
    elseif GuiService.SelectedObject and GuiService.SelectedObject:IsDescendantOf(u4.Orbit) then
        GuiService.SelectedObject = nil;
    end;
end;

local function setInterfaceHidden(p35) -- Line: 451
    -- upvalues: u5 (copy), u1 (copy), PlayerGui (copy)
    if p35 then
        table.clear(u5);

        for _, v in ipairs(u1) do
            local v36 = PlayerGui:FindFirstChild(v);

            if v36 and v36:IsA("ScreenGui") then
                u5[v] = v36.Enabled;
                v36.Enabled = false;
            end;
        end;

        return;
    end;

    for _, v in ipairs(u1) do
        local v37 = PlayerGui:FindFirstChild(v);

        if v37 and v37:IsA("ScreenGui") then
            local v38 = u5[v];
            v37.Enabled = v38 == nil and true or v38;
        end;
    end;

    table.clear(u5);
end;

local function ensure() -- Line: 477
    -- upvalues: u3 (ref), build (copy)
    if not (u3 and u3.Parent) then
        build();
    end;
end;

function u2.Mount(p39) -- Line: 481
    -- upvalues: u3 (ref), build (copy), buildPlanetButtons (copy), u6 (ref), u4 (ref), u2 (copy), u7 (ref), u8 (ref), setInterfaceHidden (copy), SpaceshipFlight (copy)
    if not (u3 and u3.Parent) then
        build();
    end;

    buildPlanetButtons();
    u6 = {};
    u4.Status.Text = "";
    u2.SetOrbitPanel(false);
    u4.Flash.BackgroundTransparency = 1;
    u3.Enabled = true;
    u7 = p39.Ship;
    u8 = os.clock();
    setInterfaceHidden(true);
    u2.Update(p39);
    SpaceshipFlight.Start(p39.Ship);
end;

function u2.Dismount(p40) -- Line: 496
    -- upvalues: SpaceshipFlight (copy), setInterfaceHidden (copy), u7 (ref), u3 (ref), u2 (copy), GuiService (copy)
    SpaceshipFlight.Stop();
    setInterfaceHidden(false);
    u7 = nil;

    if u3 then
        u3.Enabled = false;
        u2.SetOrbitPanel(false);
    end;

    if GuiService.SelectedObject then
        GuiService.SelectedObject = nil;
    end;
end;

local function forceDismountIfStuck(p41) -- Line: 520
    -- upvalues: u3 (ref), u2 (copy)
    if not (u3 and u3.Enabled) then
        return;
    end;

    warn("[SpaceshipHUD] force dismount: " .. p41);
    u2.Dismount({});
end;

task.spawn(function() -- Line: 526
    -- upvalues: u3 (ref), u7 (ref), u2 (copy), u8 (ref)
    while true do
        repeat
            task.wait(1);
        until u3 and u3.Enabled;

        if u7 and not u7.Parent then
            if u3 and u3.Enabled then
                warn("[SpaceshipHUD] force dismount: ship no longer exists");
                u2.Dismount({});
            end;
        elseif os.clock() - u8 > 5 then
            local v42 = ("no server update for %.0fs"):format(os.clock() - u8);

            if u3 and u3.Enabled then
                warn("[SpaceshipHUD] force dismount: " .. v42);
                u2.Dismount({});
            end;
        end;
    end;
end);
LocalPlayer.CharacterAdded:Connect(function() -- Line: 542
    -- upvalues: u3 (ref), u2 (copy)
    task.defer(function() -- Line: 543
        -- upvalues: u3 (ref), u2 (ref)
        task.wait(0.5);

        if u3 then
            if not u3.Enabled then
                return;
            end;

            warn("[SpaceshipHUD] force dismount: character respawned");
            u2.Dismount({});
        end;
    end);
end);
local u43 = 0;

function u2.Update(p44) -- Line: 551
    -- upvalues: u3 (ref), build (copy), u8 (ref), u7 (ref), u6 (ref), SpaceshipConfig (copy), TweenService (copy), u4 (ref), Color3_fromRGB_ret9 (copy), Color3_fromRGB_ret8 (copy), Color3_fromRGB_ret10 (copy), Color3_fromRGB_ret2 (copy), u2 (copy), Color3_fromRGB_ret2 (copy), u43 (ref)
    if not (u3 and u3.Parent) then
        build();
    end;

    u8 = os.clock();

    if p44.Ship then
        u7 = p44.Ship;
    end;

    if not u3.Enabled then
        return;
    end;

    for i, v in pairs(p44) do
        u6[i] = v;
    end;

    local v45 = p44.MaxHealth or SpaceshipConfig.MAX_HEALTH;
    local v46 = p44.Health or (u6.Health or v45);
    local v47 = p44.MaxFuel or SpaceshipConfig.MAX_FUEL;
    local v48 = p44.Fuel or (u6.Fuel or 0);
    local v49 = v46 / math.max(1, v45);
    local math_clamp_ret = math.clamp(v49, 0, 1);
    local v50 = v48 / math.max(1, v47);
    local math_clamp_ret2 = math.clamp(v50, 0, 1);
    TweenService:Create(u4.Health.Fill, TweenInfo.new(0.18), {
        Size = UDim2.new(math_clamp_ret, 0, 1, 0)
    }):Play();
    TweenService:Create(u4.Fuel.Fill, TweenInfo.new(0.18), {
        Size = UDim2.new(math_clamp_ret2, 0, 1, 0)
    }):Play();
    u4.Health.Fill.BackgroundColor3 = math_clamp_ret <= 0.3 and Color3_fromRGB_ret9 or Color3_fromRGB_ret8;
    u4.Fuel.Fill.BackgroundColor3 = v48 <= SpaceshipConfig.FUEL_LOW_WARN and Color3_fromRGB_ret10 or Color3_fromRGB_ret2;
    u4.Health.Value.Text = string.format("%d / %d", math.floor(v46), (math.floor(v45)));
    u4.Fuel.Value.Text = string.format("%d%%", (math.floor(math_clamp_ret2 * 100 + 0.5)));

    if p44.Speed or p44.Altitude then
        u4.Readout.Text = string.format("SPD %d   ALT %d", math.floor(u6.Speed or 0), (math.floor(u6.Altitude or 0)));
    end;

    local v51 = u6.Stationed == true;
    local v52 = u6.InOrbit == true;
    u4.Mode.Text = v51 and "LANDED" or (u6.Landing and "LANDING" or (v52 and "ORBIT" or (u6.Autopilot and "AUTOPILOT" or "FLYING")));
    u4.BtnLaunch.Visible = v52;
    u4.BtnLand.Visible = not v51;
    u4.BtnOrbit.Text = u6.Autopilot and "CANCEL AUTO" or "ENTER ORBIT";
    u4.BtnOrbit.Visible = not v52;

    if not v52 then
        u2.SetOrbitPanel(false);
    end;

    if v48 <= 0 then
        u4.Status.TextColor3 = Color3_fromRGB_ret10;
        u4.Status.Text = "OUT OF FUEL - REFUEL WITH AN ENERGY CELL";
    elseif v52 then
        u4.Status.TextColor3 = Color3_fromRGB_ret2;
        u4.Status.Text = "IN ORBIT - LAUNCH TO TRAVEL";
    elseif u6.NearOrbit then
        u4.Status.TextColor3 = Color3_fromRGB_ret2;
        u4.Status.Text = "APPROACHING ORBIT";
    else
        u4.Status.Text = "";
    end;

    if p44.DamageTaken and os.clock() - u43 > 0.12 then
        u43 = os.clock();
        u4.Flash.BackgroundTransparency = 0.72;
        TweenService:Create(u4.Flash, TweenInfo.new(SpaceshipConfig.DAMAGE_SHAKE_TIME), {
            BackgroundTransparency = 1
        }):Play();
    end;
end;

return u2;