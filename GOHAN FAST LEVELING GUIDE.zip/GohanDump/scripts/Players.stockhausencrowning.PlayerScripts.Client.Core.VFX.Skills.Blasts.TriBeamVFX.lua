-- Decompiled with Potassium's decompiler.

local Debris = game:GetService("Debris");
local ReplicatedStorage = game:GetService("ReplicatedStorage");
local GlobalFunctions = require(ReplicatedStorage:WaitForChild("Modules").GlobalFunctions);
local Visuals = workspace.World.Visuals;
local Particles = ReplicatedStorage.Assets.Effects.Particles;

return {
    Execute = function(p1) -- Line: 20
        -- upvalues: GlobalFunctions (copy), Particles (copy), Visuals (copy), Debris (copy)
        local Character = p1.Character;

        if not Character then
            return;
        end;

        local RootAndHumanoid = GlobalFunctions.GetRootAndHumanoid(Character);

        if not RootAndHumanoid then
            return;
        end;

        local v2 = Particles.Kikoho:Clone();
        v2.CFrame = RootAndHumanoid.CFrame * CFrame.new(0, 2, -1);
        v2.Anchored = true;
        v2.Parent = Visuals;
        Debris:AddItem(v2, 5);

        for _, child in ipairs(v2.Emit:GetChildren()) do
            child:Emit(30);
        end;
    end
};