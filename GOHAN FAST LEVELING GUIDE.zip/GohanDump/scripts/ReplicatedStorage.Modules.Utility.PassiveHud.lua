-- Decompiled with Potassium's decompiler.

local Players = game:GetService("Players");
local ReplicatedStorage = game:GetService("ReplicatedStorage");
local TweenService = game:GetService("TweenService");
local Metadata = ReplicatedStorage:WaitForChild("Modules").Metadata;
local BuffData = require(Metadata.MiscData.BuffData.BuffData);
local PassiveData = require(Metadata.PassiveData.PassiveData);
local Font_new_ret = Font.new("rbxasset://fonts/families/Sarpanch.json", Enum.FontWeight.Bold, Enum.FontStyle.Italic);
local Font_new_ret2 = Font.new("rbxasset://fonts/families/Sarpanch.json", Enum.FontWeight.Regular, Enum.FontStyle.Italic);
local u1 = {
    Race = {
        Order = 1,
        Tag = "RACE PASSIVE",
        Color = Color3.fromRGB(255, 72, 72)
    },
    RaceTrait = {
        Order = 2,
        Tag = "TRAIT PASSIVE",
        Color = Color3.fromRGB(255, 183, 66)
    },
    Misc = {
        Order = 3,
        Tag = "PASSIVE",
        Color = Color3.fromRGB(102, 184, 255)
    },
    Buff = {
        Order = 4,
        Tag = "TEMPORARY BUFF",
        Color = Color3.fromRGB(96, 224, 140)
    }
};
local Misc = u1.Misc;
local TweenInfo_new_ret = TweenInfo.new(0.12, Enum.EasingStyle.Quad, Enum.EasingDirection.Out);
local TweenInfo_new_ret2 = TweenInfo.new(0.14, Enum.EasingStyle.Quad, Enum.EasingDirection.Out);
local u3 = {
    ["Zenkai Boost"] = function(p2) -- Line: 72
        local Attribute = p2:GetAttribute("ZenkaiStacks");

        if Attribute == nil then
            return nil;
        end;

        return ("Zenkai stacks: %d/%d  (+%d per stat)"):format(Attribute, p2:GetAttribute("ZenkaiStackCap") or 20, Attribute * (p2:GetAttribute("ZenkaiPerStack") or 0));
    end
};
local u4 = {
    buffFrame = nil,
    popupGui = nil,
    tooltip = nil,
    hovered = nil,
    icons = {},
    descs = {},
    buffs = {}
};

local function formatLeft(p5) -- Line: 96
    local math_floor_ret = math.floor(p5);
    local math_max_ret = math.max(0, math_floor_ret);

    if math_max_ret >= 3600 then
        return ("%dh %02dm"):format(math_max_ret // 3600, math_max_ret % 3600 // 60);
    end;

    if math_max_ret >= 60 then
        return ("%dm %02ds"):format(math_max_ret // 60, math_max_ret % 60);
    end;

    return math_max_ret .. "s";
end;

local function categoryOf(p6) -- Line: 103
    -- upvalues: u1 (copy), Misc (copy)
    return u1[p6] or Misc;
end;

local function initialsOf(p7) -- Line: 112
    local v8 = {};

    for i in tostring(p7):gmatch("%a+") do
        v8[#v8 + 1] = i:sub(1, 1):upper();

        if #v8 == 3 then
            break;
        end;
    end;

    if #v8 > 1 then
        return table.concat(v8);
    end;

    return tostring(p7):gsub("%A", ""):sub(1, 3):upper();
end;

local function getGui() -- Line: 125
    -- upvalues: Players (copy)
    local LocalPlayer = Players.LocalPlayer;

    if not LocalPlayer then
        return nil, nil;
    end;

    local PlayerGui = LocalPlayer:WaitForChild("PlayerGui");
    local HUD = PlayerGui:WaitForChild("HUD");

    return PlayerGui:WaitForChild("PopupGui"), HUD:WaitForChild("MainFrame"):WaitForChild("HUDisplay"):WaitForChild("BuffFrame");
end;

local function viewportSize() -- Line: 139
    -- upvalues: u4 (copy)
    local popupGui = u4.popupGui;

    if popupGui then
        popupGui = popupGui.AbsoluteSize;
    end;

    if popupGui and popupGui.Y > 1 then
        return popupGui;
    end;

    local workspace_CurrentCamera = workspace.CurrentCamera;

    return workspace_CurrentCamera and workspace_CurrentCamera.ViewportSize or Vector2.new(1280, 720);
end;

local function hideTooltip() -- Line: 150
    -- upvalues: u4 (copy)
    u4.hovered = nil;

    if u4.tooltip then
        u4.tooltip:Destroy();
        u4.tooltip = nil;
    end;

    local popupGui = u4.popupGui;

    if popupGui and popupGui.Parent then
        for _, child in ipairs(popupGui:GetChildren()) do
            if child.Name == "BuffDesc" then
                child:Destroy();
            end;
        end;
    end;
end;

local function reposition(p9, p10) -- Line: 172
    if not (p9.Parent and p10.Parent) then
        return;
    end;

    local AbsoluteSize = p9.Parent.AbsoluteSize;
    local AbsoluteSize2 = p9.AbsoluteSize;
    local AbsolutePosition = p10.AbsolutePosition;
    local AbsoluteSize3 = p10.AbsoluteSize;
    local v11 = AbsolutePosition.X + AbsoluteSize3.X * 0.5 - AbsoluteSize2.X * 0.5;
    local v12 = AbsolutePosition.Y + AbsoluteSize3.Y + 10;

    if v12 + AbsoluteSize2.Y > AbsoluteSize.Y - 10 then
        v12 = AbsolutePosition.Y - AbsoluteSize2.Y - 10;
    end;

    local UDim2_fromOffset = UDim2.fromOffset;
    local math_max_ret = math.max(10, AbsoluteSize.X - AbsoluteSize2.X - 10);
    local math_clamp_ret = math.clamp(v11, 10, math_max_ret);
    local math_max_ret2 = math.max(10, AbsoluteSize.Y - AbsoluteSize2.Y - 10);
    p9.Position = UDim2_fromOffset(math_clamp_ret, (math.clamp(v12, 10, math_max_ret2)));
end;

local function prepareFade(p13) -- Line: 196
    -- upvalues: TweenService (copy), TweenInfo_new_ret2 (copy)
    local u14 = {};

    local function stage(p15, p16, p17) -- Line: 199
        -- upvalues: u14 (copy), TweenService (ref), TweenInfo_new_ret2 (ref)
        local v18 = p15[p16];
        p15[p16] = p17;
        u14[#u14 + 1] = TweenService:Create(p15, TweenInfo_new_ret2, {
            [p16] = v18
        });
    end;

    local BackgroundTransparency = p13.BackgroundTransparency;
    p13.BackgroundTransparency = 1;
    u14[#u14 + 1] = TweenService:Create(p13, TweenInfo_new_ret2, {
        BackgroundTransparency = BackgroundTransparency
    });

    for _, descendant in ipairs(p13:GetDescendants()) do
        if descendant:IsA("TextLabel") then
            local TextTransparency = descendant.TextTransparency;
            descendant.TextTransparency = 1;
            u14[#u14 + 1] = TweenService:Create(descendant, TweenInfo_new_ret2, {
                TextTransparency = TextTransparency
            });
            local TextStrokeTransparency = descendant.TextStrokeTransparency;
            descendant.TextStrokeTransparency = 1;
            u14[#u14 + 1] = TweenService:Create(descendant, TweenInfo_new_ret2, {
                TextStrokeTransparency = TextStrokeTransparency
            });
        elseif descendant:IsA("UIStroke") then
            local Transparency = descendant.Transparency;
            descendant.Transparency = 1;
            u14[#u14 + 1] = TweenService:Create(descendant, TweenInfo_new_ret2, {
                Transparency = Transparency
            });
        elseif descendant:IsA("UIScale") then
            local Scale = descendant.Scale;
            descendant.Scale = 0.94;
            u14[#u14 + 1] = TweenService:Create(descendant, TweenInfo_new_ret2, {
                Scale = Scale
            });
        elseif descendant:IsA("Frame") then
            local BackgroundTransparency2 = descendant.BackgroundTransparency;
            descendant.BackgroundTransparency = 1;
            u14[#u14 + 1] = TweenService:Create(descendant, TweenInfo_new_ret2, {
                BackgroundTransparency = BackgroundTransparency2
            });
        end;
    end;

    return function() -- Line: 219
        -- upvalues: u14 (copy)
        for _, v in ipairs(u14) do
            v:Play();
        end;
    end;
end;

local function buildTooltip(p19, p20) -- Line: 224
    -- upvalues: u1 (copy), Misc (copy), u4 (copy), Font_new_ret2 (copy), Font_new_ret (copy), PassiveData (copy), BuffData (copy), u3 (copy), Players (copy)
    local v21 = u1[p20] or Misc;
    local popupGui = u4.popupGui;

    if popupGui then
        popupGui = popupGui.AbsoluteSize;
    end;

    if not popupGui or popupGui.Y <= 1 then
        local workspace_CurrentCamera = workspace.CurrentCamera;
        popupGui = workspace_CurrentCamera and workspace_CurrentCamera.ViewportSize or Vector2.new(1280, 720);
    end;

    local math_clamp_ret = math.clamp(popupGui.X * 0.2, 220, 360);
    local math_clamp_ret2 = math.clamp(popupGui.Y / 52, 13, 20);
    local Frame = Instance.new("Frame");
    Frame.Name = "BuffDesc";
    Frame.BackgroundColor3 = Color3.fromRGB(9, 9, 12);
    Frame.BackgroundTransparency = 0.12;
    Frame.BorderSizePixel = 0;
    Frame.Size = UDim2.fromOffset(math_clamp_ret, 0);
    Frame.AutomaticSize = Enum.AutomaticSize.Y;
    Frame.ZIndex = 20;
    local UICorner = Instance.new("UICorner");
    UICorner.CornerRadius = UDim.new(0, 8);
    UICorner.Parent = Frame;
    local UIStroke = Instance.new("UIStroke");
    UIStroke.Color = v21.Color;
    UIStroke.Thickness = 1.5;
    UIStroke.Transparency = 0.3;
    UIStroke.ApplyStrokeMode = Enum.ApplyStrokeMode.Border;
    UIStroke.Parent = Frame;
    local UIGradient = Instance.new("UIGradient");
    UIGradient.Rotation = 90;
    UIGradient.Color = ColorSequence.new({ ColorSequenceKeypoint.new(0, Color3.fromRGB(255, 255, 255)), ColorSequenceKeypoint.new(1, Color3.fromRGB(150, 150, 160)) });
    UIGradient.Parent = Frame;
    Instance.new("UIScale").Parent = Frame;
    local Frame2 = Instance.new("Frame");
    Frame2.Name = "Accent";
    Frame2.BackgroundColor3 = v21.Color;
    Frame2.BorderSizePixel = 0;
    Frame2.Position = UDim2.fromScale(0, 0);
    Frame2.Size = UDim2.new(0, 3, 1, 0);
    Frame2.ZIndex = 21;
    Frame2.Parent = Frame;
    local Frame3 = Instance.new("Frame");
    Frame3.Name = "Content";
    Frame3.BackgroundTransparency = 1;
    Frame3.BorderSizePixel = 0;
    Frame3.Position = UDim2.fromOffset(3, 0);
    Frame3.Size = UDim2.new(1, -3, 0, 0);
    Frame3.AutomaticSize = Enum.AutomaticSize.Y;
    Frame3.ZIndex = 21;
    Frame3.Parent = Frame;
    local UIPadding = Instance.new("UIPadding");
    UIPadding.PaddingTop = UDim.new(0, 8);
    UIPadding.PaddingBottom = UDim.new(0, 9);
    UIPadding.PaddingLeft = UDim.new(0, 11);
    UIPadding.PaddingRight = UDim.new(0, 11);
    UIPadding.Parent = Frame3;
    local UIListLayout = Instance.new("UIListLayout");
    UIListLayout.FillDirection = Enum.FillDirection.Vertical;
    UIListLayout.SortOrder = Enum.SortOrder.LayoutOrder;
    UIListLayout.Padding = UDim.new(0, 3);
    UIListLayout.Parent = Frame3;

    local function label(p22, p23, p24, p25, p26, p27) -- Line: 296
        -- upvalues: Frame3 (copy)
        local TextLabel = Instance.new("TextLabel");
        TextLabel.Name = p22;
        TextLabel.LayoutOrder = p23;
        TextLabel.BackgroundTransparency = 1;
        TextLabel.BorderSizePixel = 0;
        TextLabel.Size = UDim2.new(1, 0, 0, 0);
        TextLabel.AutomaticSize = Enum.AutomaticSize.Y;
        TextLabel.FontFace = p25;
        TextLabel.TextSize = p26;
        TextLabel.TextColor3 = p27;
        TextLabel.TextStrokeTransparency = 0.6;
        TextLabel.TextWrapped = true;
        TextLabel.TextXAlignment = Enum.TextXAlignment.Left;
        TextLabel.TextYAlignment = Enum.TextYAlignment.Top;
        TextLabel.Text = p24;
        TextLabel.ZIndex = 22;
        TextLabel.Parent = Frame3;

        return TextLabel;
    end;

    label("Tag", 1, v21.Tag, Font_new_ret2, math.max(math_clamp_ret2 - 3, 10), v21.Color);
    label("NameLabel", 2, p19, Font_new_ret, math_clamp_ret2 + 4, Color3.fromRGB(255, 255, 255));
    local Frame4 = Instance.new("Frame");
    Frame4.Name = "Divider";
    Frame4.LayoutOrder = 3;
    Frame4.BackgroundColor3 = v21.Color;
    Frame4.BackgroundTransparency = 0.55;
    Frame4.BorderSizePixel = 0;
    Frame4.Size = UDim2.new(1, 0, 0, 1);
    Frame4.ZIndex = 22;
    Frame4.Parent = Frame3;
    local v28 = PassiveData and PassiveData.Passives and PassiveData.Passives[p19];
    label("Desc", 4, u4.descs[p19] or BuffData[p19] or (v28 and v28.Description or "No description yet."), Font_new_ret2, math_clamp_ret2, Color3.fromRGB(214, 214, 222));
    local v29 = u3[p19];
    local LocalPlayer = Players.LocalPlayer;

    if v29 and LocalPlayer then
        local success, result = pcall(v29, LocalPlayer);

        if success and result then
            label("Live", 5, result, Font_new_ret, math_clamp_ret2, v21.Color);
        end;
    end;

    local v30 = u4.buffs[p19];

    if v30 and v30.ExpiresAt then
        local v31 = v30.ExpiresAt - os.clock();
        local math_floor_ret = math.floor(v31);
        local math_max_ret = math.max(0, math_floor_ret);
        local v32;

        if math_max_ret >= 3600 then
            v32 = ("%dh %02dm"):format(math_max_ret // 3600, math_max_ret % 3600 // 60);
        elseif math_max_ret >= 60 then
            v32 = ("%dm %02ds"):format(math_max_ret // 60, math_max_ret % 60);
        else
            v32 = math_max_ret .. "s";
        end;

        label("Timer", 6, "Time left: " .. v32, Font_new_ret, math_clamp_ret2, v21.Color);
    end;

    return Frame;
end;

local function showTooltip(u33, p34, p35) -- Line: 357
    -- upvalues: hideTooltip (copy), u4 (copy), buildTooltip (copy), prepareFade (copy), reposition (copy)
    hideTooltip();
    local popupGui = u4.popupGui;

    if not (popupGui and popupGui.Parent) then
        return;
    end;

    local u36 = buildTooltip(p34, p35);
    local v37 = prepareFade(u36);
    u36.Parent = popupGui;
    u4.tooltip = u36;
    u4.hovered = p34;
    reposition(u36, u33);
    u36:GetPropertyChangedSignal("AbsoluteSize"):Connect(function() -- Line: 373
        -- upvalues: u4 (ref), u36 (copy), reposition (ref), u33 (copy)
        if u4.tooltip == u36 then
            reposition(u36, u33);
        end;
    end);
    v37();
end;

local function buildIcon(u38, u39) -- Line: 387
    -- upvalues: u1 (copy), Misc (copy), Font_new_ret (copy), initialsOf (copy), TweenService (copy), TweenInfo_new_ret (copy), showTooltip (copy), u4 (copy), hideTooltip (copy)
    local u40 = u1[u39] or Misc;
    local Frame = Instance.new("Frame");
    Frame.Name = u38;
    Frame.BackgroundTransparency = 1;
    Frame.BorderSizePixel = 0;
    Frame.Size = UDim2.fromScale(1, 1);
    local ImageButton = Instance.new("ImageButton");
    ImageButton.Name = "Icon";
    ImageButton.AnchorPoint = Vector2.new(0.5, 0.5);
    ImageButton.Position = UDim2.fromScale(0.5, 0.5);
    ImageButton.Size = UDim2.fromScale(1, 1);
    ImageButton.BackgroundTransparency = 1;
    ImageButton.BorderSizePixel = 0;
    ImageButton.AutoButtonColor = false;
    ImageButton.Image = "rbxassetid://18715463865";
    ImageButton.ImageColor3 = u40.Color;
    ImageButton.ScaleType = Enum.ScaleType.Fit;
    ImageButton.ZIndex = 2;
    ImageButton.Parent = Frame;
    local UIAspectRatioConstraint = Instance.new("UIAspectRatioConstraint");
    UIAspectRatioConstraint.AspectRatio = 1;
    UIAspectRatioConstraint.Parent = ImageButton;
    local UIScale = Instance.new("UIScale");
    UIScale.Parent = ImageButton;
    local TextLabel = Instance.new("TextLabel");
    TextLabel.Name = "Initials";
    TextLabel.AnchorPoint = Vector2.new(0.5, 0.5);
    TextLabel.Position = UDim2.fromScale(0.5, 0.5);
    TextLabel.Size = UDim2.fromScale(0.5, 0.4);
    TextLabel.BackgroundTransparency = 1;
    TextLabel.BorderSizePixel = 0;
    TextLabel.FontFace = Font_new_ret;
    TextLabel.TextScaled = true;
    TextLabel.TextColor3 = Color3.fromRGB(255, 255, 255);
    TextLabel.TextStrokeTransparency = 0.55;
    TextLabel.Text = initialsOf(u38);
    TextLabel.ZIndex = 3;
    TextLabel.Parent = ImageButton;
    local u41 = u40.Color:Lerp(Color3.new(1, 1, 1), 0.35);
    ImageButton.MouseEnter:Connect(function() -- Line: 435
        -- upvalues: ImageButton (copy), TextLabel (copy), TweenService (ref), UIScale (copy), TweenInfo_new_ret (ref), u41 (copy), showTooltip (ref), u38 (copy), u39 (copy)
        ImageButton.ZIndex = 6;
        TextLabel.ZIndex = 7;
        TweenService:Create(UIScale, TweenInfo_new_ret, {
            Scale = 1.14
        }):Play();
        TweenService:Create(ImageButton, TweenInfo_new_ret, {
            ImageColor3 = u41
        }):Play();
        showTooltip(ImageButton, u38, u39);
    end);
    ImageButton.MouseLeave:Connect(function() -- Line: 443
        -- upvalues: ImageButton (copy), TextLabel (copy), TweenService (ref), UIScale (copy), TweenInfo_new_ret (ref), u40 (copy), u4 (ref), u38 (copy), hideTooltip (ref)
        ImageButton.ZIndex = 2;
        TextLabel.ZIndex = 3;
        TweenService:Create(UIScale, TweenInfo_new_ret, {
            Scale = 1
        }):Play();
        TweenService:Create(ImageButton, TweenInfo_new_ret, {
            ImageColor3 = u40.Color
        }):Play();

        if u4.hovered == u38 then
            hideTooltip();
        end;
    end);

    return Frame;
end;

local function adopt(p42, p43) -- Line: 462
    -- upvalues: u4 (copy), hideTooltip (copy)
    if u4.buffFrame == p43 then
        return;
    end;

    u4.popupGui = p42;
    hideTooltip();
    u4.buffFrame = p43;
    table.clear(u4.icons);

    for _, child in ipairs(p43:GetChildren()) do
        if child:IsA("GuiObject") then
            child:Destroy();
        end;
    end;
end;

local function addIcon(p44, p45, p46) -- Line: 475
    -- upvalues: u4 (copy), buildIcon (copy)
    local v47 = u4.icons[p45];

    if v47 and v47.Parent == p44 then
        if v47:GetAttribute("Category") == p46 then
            return v47;
        end;

        v47:Destroy();
    end;

    local v48 = buildIcon(p45, p46);
    v48:SetAttribute("Category", p46);
    v48.Parent = p44;
    u4.icons[p45] = v48;

    return v48;
end;

local u51 = {
    SetCount = function(p49, p50) -- Line: 503, Name: SetCount
        -- upvalues: Font_new_ret (copy)
        if p49 then
            p49 = p49:FindFirstChild("Icon");
        end;

        if not p49 then
            return;
        end;

        local Count = p49:FindFirstChild("Count");

        if not p50 or p50 <= 0 then
            if Count then
                Count:Destroy();
            end;

            return;
        end;

        if not Count then
            Count = Instance.new("TextLabel");
            Count.Name = "Count";
            Count.AnchorPoint = Vector2.new(1, 1);
            Count.Position = UDim2.fromScale(1.08, 1.08);
            Count.Size = UDim2.fromScale(0.5, 0.42);
            Count.BackgroundColor3 = Color3.fromRGB(16, 16, 18);
            Count.BorderSizePixel = 0;
            Count.FontFace = Font_new_ret;
            Count.TextScaled = true;
            Count.TextColor3 = Color3.fromRGB(255, 255, 255);
            Count.ZIndex = 5;
            local UICorner = Instance.new("UICorner");
            UICorner.CornerRadius = UDim.new(1, 0);
            UICorner.Parent = Count;
            local UIStroke = Instance.new("UIStroke");
            UIStroke.Color = Color3.fromRGB(255, 160, 205);
            UIStroke.Thickness = 1.5;
            UIStroke.Parent = Count;
            Count.Parent = p49;
        end;

        Count.Text = tostring(p50);
    end
};

function u51.Render(p52) -- Line: 530
    -- upvalues: getGui (copy), adopt (copy), u4 (copy), addIcon (copy), u51 (copy), hideTooltip (copy)
    local v53, v54 = getGui();

    if not v54 then
        return;
    end;

    adopt(v53, v54);
    local v55 = {};

    for i, v in ipairs(p52) do
        if v.Name then
            u4.descs[v.Name] = v.Desc;
            local v56 = addIcon(v54, v.Name, v.Category);
            v56.LayoutOrder = i;
            u51.SetCount(v56, v.Count);
            v55[v.Name] = true;
        end;
    end;

    local v57 = #p52;

    for i, v in pairs(u4.buffs) do
        if not v55[i] then
            u4.descs[i] = v.Desc;
            v57 = v57 + 1;
            addIcon(v54, i, "Buff").LayoutOrder = v57;
            v55[i] = true;
        end;
    end;

    for i, v in pairs(u4.icons) do
        if not v55[i] then
            v:Destroy();
            u4.icons[i] = nil;

            if u4.hovered == i then
                hideTooltip();
            end;
        end;
    end;

    for _, child in ipairs(v54:GetChildren()) do
        if child:IsA("GuiObject") and u4.icons[child.Name] ~= child then
            child:Destroy();
        end;
    end;
end;

function u51.Add(p58, p59, p60) -- Line: 579
    -- upvalues: getGui (copy), adopt (copy), u4 (copy), addIcon (copy)
    if not p58 then
        return nil;
    end;

    local v61, v62 = getGui();

    if not v62 then
        return nil;
    end;

    adopt(v61, v62);
    u4.descs[p58] = p60;

    return addIcon(v62, p58, p59 or "Misc");
end;

function u51.Remove(p63) -- Line: 590
    -- upvalues: getGui (copy), adopt (copy), u4 (copy), hideTooltip (copy)
    if not p63 then
        return;
    end;

    local v64, v65 = getGui();

    if not v65 then
        return;
    end;

    adopt(v64, v65);
    u4.icons[p63] = nil;
    u4.descs[p63] = nil;

    for _, child in ipairs(v65:GetChildren()) do
        if child:IsA("GuiObject") and child.Name == p63 then
            child:Destroy();
        end;
    end;

    if u4.hovered == p63 then
        hideTooltip();
    end;
end;

function u51.Clear() -- Line: 611
    -- upvalues: getGui (copy), adopt (copy), u4 (copy), hideTooltip (copy)
    local v66, v67 = getGui();

    if not v67 then
        return;
    end;

    adopt(v66, v67);

    for _, child in ipairs(v67:GetChildren()) do
        if child:IsA("GuiObject") then
            child:Destroy();
        end;
    end;

    table.clear(u4.icons);
    table.clear(u4.descs);
    hideTooltip();
end;

function u51.AddBuff(u68, p69, p70) -- Line: 629
    -- upvalues: u4 (copy), getGui (copy), adopt (copy), addIcon (copy), u51 (copy)
    if not u68 then
        return;
    end;

    local u71 = {};
    local buffs = u4.buffs;
    local v72 = {
        Desc = p69
    };
    local v73;

    if tonumber(p70) and tonumber(p70) > 0 then
        v73 = os.clock() + p70 or nil;
    else
        v73 = nil;
    end;

    v72.ExpiresAt = v73;
    v72.Token = u71;
    buffs[u68] = v72;
    local v74, v75 = getGui();

    if v75 then
        adopt(v74, v75);
        u4.descs[u68] = p69;
        addIcon(v75, u68, "Buff").LayoutOrder = 1000;
    end;

    if tonumber(p70) and p70 > 0 then
        task.delay(p70, function() -- Line: 645
            -- upvalues: u4 (ref), u68 (copy), u71 (copy), u51 (ref)
            local v76 = u4.buffs[u68];

            if v76 and v76.Token == u71 then
                u51.RemoveBuff(u68);
            end;
        end);
    end;
end;

function u51.RemoveBuff(p77) -- Line: 652
    -- upvalues: u4 (copy), u51 (copy)
    if not p77 then
        return;
    end;

    u4.buffs[p77] = nil;
    u51.Remove(p77);
end;

u51.Categories = u1;

return u51;