-- Decompiled with Potassium's decompiler.

local ReplicatedStorage = game:GetService("ReplicatedStorage");
local UserInputService = game:GetService("UserInputService");
local GuiService = game:GetService("GuiService");
game:GetService("TextService");
local Modules = ReplicatedStorage:WaitForChild("Modules");
local _ = Modules.Metadata;
local Shared = Modules.Shared;
local _ = Modules.Utility;
local LocalPlayer = game.Players.LocalPlayer;
local u1 = LocalPlayer.Character or LocalPlayer.CharacterAdded:Wait();
local HumanoidRootPart = u1:WaitForChild("HumanoidRootPart");
LocalPlayer.CharacterAdded:Connect(function(p2) -- Line: 46
    -- upvalues: u1 (ref), HumanoidRootPart (ref)
    u1 = p2;
    HumanoidRootPart = p2:WaitForChild("HumanoidRootPart");
end);
local script_Parent = script.Parent;
local PromptFrame = script_Parent:FindFirstChild("PromptFrame", true);
local DialogueRemote = ReplicatedStorage.Remotes.DialogueRemote;
local DialogueBindable = ReplicatedStorage.Remotes.DialogueBindable;
local CinemaManager = require(ReplicatedStorage.Modules.Shared.CinemaManager);
local SoundManager = require(Shared.SoundManager);
local DialogueContext = require(Shared.DialogueContext);
local Platform = require(Shared.Platform);
local TrainerStyleData = require(ReplicatedStorage.Modules.Metadata.TrainerData.TrainerStyleData);

local function setStyleTag(p3) -- Line: 63
    -- upvalues: script_Parent (copy), TrainerStyleData (copy)
    local StyleTag = script_Parent:FindFirstChild("StyleTag", true);

    if not StyleTag then
        return;
    end;

    local v4, v5, v6 = TrainerStyleData.Get(p3);
    StyleTag.Visible = v4 ~= nil;

    if v4 then
        StyleTag.Label.Text = v4;
        StyleTag.Accent.BackgroundColor3 = v5;
        StyleTag.BackgroundColor3 = v6 and v5 and v5 or Color3.fromRGB(247, 232, 210);
        StyleTag.Label.TextColor3 = v6 and Color3.new(1, 1, 1) or Color3.fromRGB(46, 34, 26);
    end;
end;

local u7 = nil;
local u8 = false;
local u9 = false;
local u10 = PromptFrame:Clone();
u10.Name = "PromptMeasure";
u10:ClearAllChildren();
u10.TextScaled = false;
u10.TextSize = 16;
u10.TextTransparency = 1;
u10.TextStrokeTransparency = 1;
u10.BackgroundTransparency = 1;
u10.Active = false;
u10.Selectable = false;
u10.ZIndex = 0;
u10.MaxVisibleGraphemes = -1;
u10.Position = UDim2.fromScale(0, 0);
u10.Parent = PromptFrame.Parent;

local function promptAvailable() -- Line: 101
    -- upvalues: PromptFrame (copy)
    local Parent = PromptFrame.Parent;

    if Parent then
        Parent = Parent:FindFirstChildOfClass("UIScale");
    end;

    local v11 = Parent and (Parent.Scale > 0 and Parent.Scale) or 1;
    local v12 = PromptFrame:FindFirstChildOfClass("UIPadding");
    local v13 = v12 and v12.PaddingTop.Offset + v12.PaddingBottom.Offset or 0;
    local v14 = PromptFrame.AbsoluteSize / v11;

    return math.max(v14.X - (v12 and (v12.PaddingLeft.Offset + v12.PaddingRight.Offset or 0) or 0), 40), math.max(v14.Y - v13 - 10, 20), 16 / v11;
end;

local function fitsPage(p15, p16, p17, p18) -- Line: 115
    -- upvalues: u10 (copy)
    u10.Size = UDim2.fromOffset(p16, p17);
    u10.TextSize = p18 or 16;
    u10.Text = p15;

    return u10.TextFits;
end;

local function paginate(p19) -- Line: 122
    -- upvalues: promptAvailable (copy), PromptFrame (copy), u10 (copy)
    local v20, v21, v22 = promptAvailable();

    if PromptFrame.AbsoluteSize.X <= 0 then
        return { p19 };
    end;

    u10.Size = UDim2.fromOffset(v20, v21);
    u10.TextSize = v22 or 16;
    u10.Text = p19;

    if u10.TextFits then
        return { p19 };
    end;

    local v23 = {};

    for i in p19:gmatch("[^%.%!%?]+[%.%!%?]*%s*") do
        v23[#v23 + 1] = i;
    end;

    if #v23 <= 1 then
        v23 = {};

        for i in p19:gmatch("%S+%s*") do
            v23[#v23 + 1] = i;
        end;
    end;

    local v24 = "";
    local v25 = {};

    for _, v in ipairs(v23) do
        local v26 = v24 .. v;

        if v24 == "" then
            v24 = v26;
        else
            u10.Size = UDim2.fromOffset(v20, v21);
            u10.TextSize = v22 or 16;
            u10.Text = v26 .. "  ▼";

            if u10.TextFits then
                v24 = v26;
            else
                v25[#v25 + 1] = v24;
                v24 = v;
            end;
        end;
    end;

    if v24 ~= "" then
        v25[#v25 + 1] = v24;
    end;

    for i, v in ipairs(v25) do
        v25[i] = v:gsub("%s+$", "");
    end;

    return v25;
end;

local u27 = nil;

local function Speaker() -- Line: 160
    -- upvalues: u7 (ref)
    return u7 and u7.Speaker or "<unknown NPC>";
end;

local RunService = game:GetService("RunService");
local TrainerRemote = ReplicatedStorage.Remotes.TrainerRemote;
local workspace_CurrentCamera = workspace.CurrentCamera;
local u28 = 0;
local u29 = nil;
local u30 = nil;

local function StopDialogueCamera() -- Line: 175
    -- upvalues: u28 (ref), u29 (ref), workspace_CurrentCamera (copy), HumanoidRootPart (ref), RunService (copy), u1 (ref)
    u28 = u28 + 1;

    if u29 then
        u29:Disconnect();
        u29 = nil;
    end;

    if workspace_CurrentCamera.CameraType ~= Enum.CameraType.Scriptable then
        return;
    end;

    local u31 = u28;
    task.spawn(function() -- Line: 181
        -- upvalues: u28 (ref), u31 (copy), HumanoidRootPart (ref), workspace_CurrentCamera (ref), RunService (ref), u1 (ref)
        local os_clock_ret = os.clock();

        while os.clock() - os_clock_ret < 0.25 do
            if u28 ~= u31 then
                return;
            end;

            local v32 = HumanoidRootPart;

            if v32 and v32.Parent then
                local CFrame_lookAt_ret = CFrame.lookAt(v32.Position - v32.CFrame.LookVector * 10 + Vector3.new(0, 4, 0), v32.Position + Vector3.new(0, 2, 0));
                workspace_CurrentCamera.CFrame = workspace_CurrentCamera.CFrame:Lerp(CFrame_lookAt_ret, 0.2);
            end;

            RunService.RenderStepped:Wait();
        end;

        if u28 ~= u31 then
            return;
        end;

        workspace_CurrentCamera.CameraType = Enum.CameraType.Custom;
        local v33 = u1 and u1:FindFirstChildOfClass("Humanoid");

        if v33 then
            workspace_CurrentCamera.CameraSubject = v33;
        end;
    end);
end;

local function StartDialogueCamera(p34) -- Line: 201
    -- upvalues: u28 (ref), u29 (ref), u1 (ref), workspace_CurrentCamera (copy), RunService (copy), script_Parent (copy)
    local NPC = p34.NPC;

    if typeof(NPC) ~= "Instance" or not NPC.Parent then
        return;
    end;

    local u35 = NPC:FindFirstChild("Head") or NPC:FindFirstChild("HumanoidRootPart");

    if u35 and not u35:IsA("BasePart") then
        u35 = u35:FindFirstChildWhichIsA("BasePart") or NPC:FindFirstChild("HumanoidRootPart");
    end;

    if not (u35 and u35:IsA("BasePart")) then
        return;
    end;

    u28 = u28 + 1;
    local u36 = u28;

    if u29 then
        u29:Disconnect();
        u29 = nil;
    end;

    local Magnitude = u35.Size.Magnitude;
    local math_max_ret = math.max(5, Magnitude * 1.6);
    local RaycastParams_new_ret = RaycastParams.new();
    RaycastParams_new_ret.FilterType = Enum.RaycastFilterType.Exclude;
    local v37 = { NPC };

    if u1 then
        table.insert(v37, u1);
    end;

    local World = workspace:FindFirstChild("World");

    if World then
        World = World:FindFirstChild("Visuals");
    end;

    if World then
        table.insert(v37, World);
    end;

    RaycastParams_new_ret.FilterDescendantsInstances = v37;
    local CFrame2 = u35.CFrame;
    local Vector3_new_ret = Vector3.new(0, Magnitude * 0.15, 0);
    local v38 = { CFrame2.LookVector * math_max_ret + CFrame2.RightVector * (math_max_ret * 0.35) + Vector3_new_ret, CFrame2.LookVector * math_max_ret - CFrame2.RightVector * (math_max_ret * 0.35) + Vector3_new_ret, CFrame2.LookVector * math_max_ret + Vector3_new_ret };
    local v39 = nil;

    for _, v in ipairs(v38) do
        if not workspace:Raycast(CFrame2.Position, v, RaycastParams_new_ret) then
            v39 = v;
            break;
        end;
    end;

    if not v39 then
        local v40 = v38[3];
        local v41 = workspace:Raycast(CFrame2.Position, v40, RaycastParams_new_ret);

        if v41 then
            math_max_ret = math.max((v41.Position - CFrame2.Position).Magnitude - 1, 5) or math_max_ret;
        end;

        v39 = v40.Unit * math_max_ret;
    end;

    local u42 = CFrame2:VectorToObjectSpace(v39);
    workspace_CurrentCamera.CameraType = Enum.CameraType.Scriptable;
    u29 = RunService.RenderStepped:Connect(function(p43) -- Line: 255
        -- upvalues: u28 (ref), u36 (copy), NPC (copy), u35 (ref), script_Parent (ref), u42 (copy), workspace_CurrentCamera (ref)
        if u28 ~= u36 then
            return;
        end;

        if not NPC.Parent then
            task.defer(Close);

            return;
        end;

        if not (u35.Parent and script_Parent.Enabled) then
            return;
        end;

        local CFrame3 = u35.CFrame;
        local Position = CFrame3.Position;
        local CFrame_lookAt_ret = CFrame.lookAt(Position + CFrame3:VectorToWorldSpace(u42), Position);
        workspace_CurrentCamera.CameraType = Enum.CameraType.Scriptable;
        workspace_CurrentCamera.CFrame = workspace_CurrentCamera.CFrame:Lerp(CFrame_lookAt_ret, 1 - math.exp(-p43 * 5));
    end);
end;

local Color3_fromRGB_ret = Color3.fromRGB(28, 28, 30);
local Color3_fromRGB_ret2 = Color3.fromRGB(255, 152, 48);
local Color3_fromRGB_ret3 = Color3.fromRGB(120, 235, 120);
local Color3_fromRGB_ret4 = Color3.fromRGB(255, 255, 255);
local Color3_fromRGB_ret5 = Color3.fromRGB(200, 200, 200);
local u44 = nil;

local function destroyTrainerPanel() -- Line: 280
    -- upvalues: u44 (ref)
    if u44 then
        u44:Destroy();
        u44 = nil;
    end;
end;

local function panelLabel(p45, p46, p47, p48, p49, p50) -- Line: 284
    local TextLabel = Instance.new("TextLabel");
    TextLabel.BackgroundTransparency = 1;
    TextLabel.Size = UDim2.new(1, 0, 0, p47 + 6);
    TextLabel.Font = p48;
    TextLabel.TextSize = p47;
    TextLabel.TextColor3 = p49;
    TextLabel.TextXAlignment = Enum.TextXAlignment.Left;
    TextLabel.TextTruncate = Enum.TextTruncate.AtEnd;
    TextLabel.RichText = true;
    TextLabel.Text = p46;
    TextLabel.LayoutOrder = p50;
    TextLabel.Parent = p45;

    return TextLabel;
end;

local function buildTrainerPanel(p51) -- Line: 300
    -- upvalues: u44 (ref), Color3_fromRGB_ret (copy), panelLabel (copy), Color3_fromRGB_ret2 (copy), Color3_fromRGB_ret3 (copy), Color3_fromRGB_ret4 (copy), Color3_fromRGB_ret5 (copy), script_Parent (copy)
    if u44 then
        u44:Destroy();
        u44 = nil;
    end;

    local Frame = Instance.new("Frame");
    Frame.Name = "TrainerPanel";
    Frame.AnchorPoint = Vector2.new(0, 0);
    Frame.Position = UDim2.new(0, 14, 0.16, 0);
    Frame.Size = UDim2.new(0, 168, 0, 0);
    Frame.AutomaticSize = Enum.AutomaticSize.Y;
    Frame.BackgroundColor3 = Color3_fromRGB_ret;
    Frame.BorderSizePixel = 0;
    local UIStroke = Instance.new("UIStroke");
    UIStroke.Color = Color3.new(0, 0, 0);
    UIStroke.Thickness = 3;
    UIStroke.Parent = Frame;
    local UIPadding = Instance.new("UIPadding");
    UIPadding.PaddingTop = UDim.new(0, 6);
    UIPadding.PaddingBottom = UDim.new(0, 8);
    UIPadding.PaddingLeft = UDim.new(0, 8);
    UIPadding.PaddingRight = UDim.new(0, 8);
    UIPadding.Parent = Frame;
    local UIListLayout = Instance.new("UIListLayout");
    UIListLayout.SortOrder = Enum.SortOrder.LayoutOrder;
    UIListLayout.Padding = UDim.new(0, 1);
    UIListLayout.Parent = Frame;
    panelLabel(Frame, "NEXT TECHNIQUE", 15, Enum.Font.Bangers, Color3_fromRGB_ret2, 1);

    if p51.AllUnlocked then
        panelLabel(Frame, "All techniques learned!", 10, Enum.Font.Arcade, Color3_fromRGB_ret3, 2);
    else
        panelLabel(Frame, tostring(p51.Skill), 11, Enum.Font.Arcade, Color3_fromRGB_ret4, 2);
        panelLabel(Frame, "REQUIREMENTS", 13, Enum.Font.Bangers, Color3_fromRGB_ret2, 3);

        for i, v in ipairs(p51.Requirements or {}) do
            local v52 = tostring(v.Label):gsub("(%l)(%u)", "%1 %2");
            panelLabel(Frame, ("%s %s %d/%d"):format(v.Met and "<font color=\"#78EB78\">O</font>" or "<font color=\"#EB6E6E\">X</font>", v52, v.Current, v.Required), 10, Enum.Font.Arcade, v.Met and Color3_fromRGB_ret4 or Color3_fromRGB_ret5, 2 + i);
        end;
    end;

    Frame.Parent = script_Parent;
    u44 = Frame;
end;

local function StartTrainerPanel(u53) -- Line: 352
    -- upvalues: script_Parent (copy), u7 (ref), TrainerRemote (copy), buildTrainerPanel (copy), u44 (ref)
    local Speaker2 = u53.Speaker;

    if type(Speaker2) ~= "string" then
        return;
    end;

    task.spawn(function() -- Line: 355
        -- upvalues: script_Parent (ref), u7 (ref), u53 (copy), TrainerRemote (ref), Speaker2 (copy), buildTrainerPanel (ref), u44 (ref)
        while script_Parent.Enabled and u7 == u53 do
            local success, result = pcall(function() -- Line: 357
                -- upvalues: TrainerRemote (ref), Speaker2 (ref)
                return TrainerRemote:InvokeServer(Speaker2, "NextSkillInfo");
            end);

            if not script_Parent.Enabled or u7 ~= u53 then
                break;
            end;

            if success and type(result) == "table" then
                buildTrainerPanel(result);
            elseif u44 then
                u44:Destroy();
                u44 = nil;
            end;

            task.wait(2);
        end;
    end);
end;

function GetRootNode(p54)
    for _, child in pairs(p54:GetChildren()) do
        if child:GetAttribute("Type") == "DialogueRoot" then
            return child;
        end;
    end;
end;

function GetNodeFromValue(p55)
    return p55:FindFirstAncestorWhichIsA("Configuration");
end;

function GetOutputNodes(p56)
    local v57 = {};

    for _, descendant in pairs(p56:GetDescendants()) do
        if descendant.Parent.Name == "Outputs" and descendant.Value ~= nil then
            local v58 = GetNodeFromValue(descendant.Value);

            if not table.find(v57, v58) then
                table.insert(v57, v58);
            end;
        end;
    end;

    return v57;
end;

function GetInputNodes(p59)
    local v60 = {};

    for _, descendant in pairs(p59:GetDescendants()) do
        if descendant.Parent.Name == "Inputs" and descendant.Value ~= nil then
            local v61 = GetNodeFromValue(descendant.Value);

            if not table.find(v60, v61) then
                table.insert(v60, v61);
            end;
        end;
    end;

    return v60;
end;

function GetInputs(p62)
    local v63 = {};

    for _, descendant in pairs(p62:GetDescendants()) do
        if descendant.Parent.Name == "Inputs" and descendant.Value ~= nil then
            table.insert(v63, descendant);
        end;
    end;

    return v63;
end;

function ClearResponses()
    -- upvalues: script_Parent (copy)
    for _, child in pairs(script_Parent:FindFirstChild("ResponseFrame", true):GetChildren()) do
        if child:IsA("TextButton") and child.Visible then
            child:Destroy();
        end;
    end;
end;

function FindNodeType(p64, p65)
    for _, v in pairs(p64) do
        if v:GetAttribute("Type") == p65 then
            return v;
        end;
    end;
end;

function FindInput(p66, p67)
    for _, v in pairs(p66) do
        if v.Value.Name == p67 then
            return v.Value;
        end;
    end;
end;

function FireEvents(p68)
    for _, child in pairs(p68:GetChildren()) do
        if child:IsA("RemoteEvent") then
            child:FireServer(p68);
        elseif child:IsA("BindableEvent") then
            child:Fire(p68);
        end;
    end;
end;

function RunCommands(p69)
    -- upvalues: LocalPlayer (copy)
    for _, v in pairs(GetInputNodes(p69)) do
        if v:GetAttribute("Type") ~= "Condition" and (v:FindFirstChildWhichIsA("ModuleScript") and #GetInputs(v) <= 0) then
            local success, result = pcall(require, v:FindFirstChildWhichIsA("ModuleScript"));

            if success and (result and result.Run) then
                local success2, result2 = pcall(result.Run, LocalPlayer);

                if not success2 then
                    warn("[Dialogue] command failed at", v:GetFullName(), result2);
                end;
            elseif not success then
                warn("[Dialogue] command module failed to load at", v:GetFullName(), result);
            end;
        end;
    end;
end;

local u70 = {};

function CheckForCondition(p71)
    -- upvalues: u70 (copy), LocalPlayer (copy), u7 (ref)
    for _, v in pairs(GetInputNodes(p71)) do
        if v:GetAttribute("Type") == "Condition" and (v:FindFirstChildWhichIsA("ModuleScript") and #GetInputs(v) <= 0) then
            local success, result = pcall(require, v:FindFirstChildWhichIsA("ModuleScript"));

            if success and (result and result.Run) then
                local v72 = u70[v];
                local v73;

                if v72 == nil then
                    local v74;
                    v74, v73 = pcall(result.Run, LocalPlayer);

                    if v74 then
                        u70[v] = v73;
                    else
                        warn(("[Dialogue] %s: condition failed at %s — %s"):format(u7 and u7.Speaker or "<unknown NPC>", v:GetFullName(), (tostring(v73))));
                        v73 = v72;
                    end;
                else
                    v73 = v72;
                end;

                if v73 ~= p71:GetAttribute("Priority") then
                    return true;
                end;
            elseif not success then
                warn(("[Dialogue] %s: condition module failed to load at %s — %s"):format(u7 and u7.Speaker or "<unknown NPC>", v:GetFullName(), (tostring(result))));
            end;
        end;
    end;
end;

function ToggleLock(p75)
    for _, v in pairs(GetInputs(p75)) do
        if v.Value.Name == "Toggle" then
            v.Value.Value = not v.Value.Value;
        end;
    end;
end;

function IsLocked(p76)
    local v77 = FindNodeType(GetInputNodes(p76), "Lock");

    if not v77 or v77.Toggle.Value ~= true then
        return false;
    end;

    local v78 = false;

    for _, v in pairs(GetInputs(p76)) do
        if v.Value.Name == "MainPathway" and v.Value.Parent == v77 then
            v78 = true;
        end;
    end;

    return v78;
end;

function RunInternalCommands(p79)
    -- upvalues: LocalPlayer (copy)
    if p79:FindFirstChildWhichIsA("ModuleScript") then
        local success, result = pcall(require, p79:FindFirstChildWhichIsA("ModuleScript"));

        if success and (result and result.Run) then
            local success2, result2 = pcall(result.Run, LocalPlayer);

            if not success2 then
                warn("[Dialogue] internal command failed at", p79:GetFullName(), result2);
            end;
        else
            if success then
                warn("[Dialogue] module at " .. p79:GetFullName() .. " has no .Run function");

                return;
            end;

            warn("[Dialogue] module failed to load at", p79:GetFullName(), result);
        end;
    end;
end;

function CommonNodeFunctions(p80)
    RunCommands(p80);
    ToggleLock(p80);
    FireEvents(p80);
    RunInternalCommands(p80);
end;

function LoadNode(u81)
    -- upvalues: script_Parent (copy), u70 (copy), SoundManager (copy), LocalPlayer (copy), u7 (ref), paginate (copy), PromptFrame (copy), u8 (ref), u9 (ref)
    local Attribute = u81:GetAttribute("Type");

    if IsLocked(u81) or not script_Parent.Enabled then
        return false;
    end;

    if CheckForCondition(u81) then
        return false;
    end;

    if Attribute ~= "Response" then
        if Attribute ~= "Prompt" then
            if not u81:FindFirstChildWhichIsA("ModuleScript") then
                return false;
            end;

            CommonNodeFunctions(u81);
            FireEvents(u81);
            LoadNodes(GetOutputNodes(u81));
            table.clear(u70);

            return true;
        end;

        CommonNodeFunctions(u81);
        script_Parent:FindFirstChild("Speaker", true).Text = u7.Speaker or "?";
        local u82 = paginate(u81.Text.Value);
        PromptFrame.Text = u82[1];
        PromptFrame.MaxVisibleGraphemes = 0;
        u8 = false;
        u9 = u81.Skippable.Value;
        task.spawn(function() -- Line: 651
            -- upvalues: u82 (copy), PromptFrame (ref), u8 (ref), script_Parent (ref), u9 (ref), u81 (copy), u70 (ref)
            for i, v in ipairs(u82) do
                local v83 = i == #u82;
                PromptFrame.Text = v .. (v83 and "" or "  ▼");
                PromptFrame.MaxVisibleGraphemes = 0;
                u8 = false;

                for i2 = 1, #PromptFrame.Text do
                    if (not script_Parent.Enabled or u8) and u9 then
                        break;
                    end;

                    local v84 = PromptFrame;
                    v84.MaxVisibleGraphemes = v84.MaxVisibleGraphemes + 1;
                    task.wait(0.01);
                    local _ = i2;
                end;

                PromptFrame.MaxVisibleGraphemes = -1;

                if not script_Parent.Enabled then
                    return;
                end;

                if not v83 then
                    u8 = false;
                    local os_clock_ret = os.clock();

                    while script_Parent.Enabled and (not u8 and os.clock() - os_clock_ret < 7) do
                        task.wait(0.05);
                    end;

                    if not script_Parent.Enabled then
                        return;
                    end;
                end;
            end;

            if not (u8 and u9) and script_Parent.Enabled ~= false then
                task.wait(2);
            end;

            u8 = false;
            LoadNodes(GetOutputNodes(u81));
            table.clear(u70);
        end);

        return true;
    end;

    local u85 = script_Parent:FindFirstChild("SampleResponse", true):Clone();
    u85.Parent = script_Parent:FindFirstChild("ResponseFrame", true);
    u85.Visible = true;
    u85.Selectable = true;
    u85.Text = u81.Text.Value;
    u85.Name = "Response";
    u85.LayoutOrder = u81:GetAttribute("Priority");
    u85.Size = UDim2.new(1, 0, 0, u85.TextBounds.Y + 18);
    local BackgroundColor3 = u85.BackgroundColor3;
    local Color3_fromRGB_ret6 = Color3.fromRGB(255, 247, 228);
    u85.MouseEnter:Connect(function() -- Line: 619
        -- upvalues: u85 (copy), Color3_fromRGB_ret6 (copy)
        u85.BackgroundColor3 = Color3_fromRGB_ret6;
    end);
    u85.MouseLeave:Connect(function() -- Line: 622
        -- upvalues: u85 (copy), BackgroundColor3 (copy)
        u85.BackgroundColor3 = BackgroundColor3;
    end);
    u85.Activated:Once(function() -- Line: 626
        -- upvalues: u81 (copy), u70 (ref), SoundManager (ref), LocalPlayer (ref)
        CommonNodeFunctions(u81);
        LoadNodes(GetOutputNodes(u81));
        table.clear(u70);
        SoundManager.AddSound("Click", {
            Parent = LocalPlayer
        }, "Client");
    end);

    return true;
end;

function Close()
    -- upvalues: script_Parent (copy), StopDialogueCamera (copy), u44 (ref), u30 (ref), CinemaManager (copy), LocalPlayer (copy), GuiService (copy), u7 (ref), u27 (ref), u70 (copy), DialogueContext (copy), PromptFrame (copy)
    if not script_Parent.Enabled then
        return;
    end;

    StopDialogueCamera();

    if u44 then
        u44:Destroy();
        u44 = nil;
    end;

    if u30 then
        u30:Disconnect();
        u30 = nil;
    end;

    CinemaManager.FadeOut(LocalPlayer);
    script_Parent.Enabled = false;
    local SelectedObject = GuiService.SelectedObject;

    if SelectedObject and SelectedObject:IsDescendantOf(script_Parent) then
        GuiService.SelectedObject = nil;
    end;

    if u7 and u7.Speaker == "Majin Buu" then
        pcall(function() -- Line: 731
            game:GetService("ReplicatedStorage").Remotes.ServerRemote:FireServer(nil, {
                Module = "BuuEncounterManager",
                Action = "Leave"
            });
        end);
    end;

    u7 = nil;
    u27 = nil;
    table.clear(u70);
    DialogueContext.Finish();
    PromptFrame.Text = "";
end;

function LoadNodes(p86)
    -- upvalues: script_Parent (copy), u7 (ref), LocalPlayer (copy), Platform (copy), GuiService (copy)
    if not script_Parent.Enabled then
        return;
    end;

    if #p86 <= 0 then
        Close();

        return;
    end;

    ClearResponses();
    local v87 = 0;

    for _, v in pairs(p86) do
        if LoadNode(v) then
            v87 = v87 + 1;
        end;
    end;

    if v87 ~= 0 then
        if Platform.PreferGamepadGlyphs() then
            task.defer(function() -- Line: 799
                -- upvalues: script_Parent (ref), GuiService (ref)
                if not script_Parent.Enabled then
                    return;
                end;

                local ResponseFrame = script_Parent:FindFirstChild("ResponseFrame", true);
                local v88 = nil;
                local v89 = nil;

                for _, child in ipairs(ResponseFrame:GetChildren()) do
                    if child:IsA("TextButton") and (child.Visible and (not v88 or child.LayoutOrder < v89)) then
                        v89 = child.LayoutOrder;
                        v88 = child;
                    end;
                end;

                if v88 then
                    GuiService.SelectedObject = v88;
                end;
            end);
        end;

        return;
    end;

    local v90 = {};

    for _, v in pairs(p86) do
        table.insert(v90, v.Name);
    end;

    warn(("[Dialogue] %s: every branch was skipped for %s — closing rather than freezing. Candidates: %s. Usual cause: a condition module errored or returned nil (profile not loaded)."):format(u7 and u7.Speaker or "<unknown NPC>", LocalPlayer.Name, table.concat(v90, ", ")));
    Close();
end;

function OnEvent(u91, p92)
    -- upvalues: script_Parent (copy), u27 (ref), u7 (ref), CinemaManager (copy), LocalPlayer (copy), setStyleTag (copy), DialogueContext (copy), u70 (copy), StartDialogueCamera (copy), TrainerRemote (copy), buildTrainerPanel (copy), u44 (ref), u30 (ref), u1 (ref)
    if script_Parent.Enabled then
        if not u27 or os.clock() - u27 <= 180 then
            return;
        end;

        local v93 = warn;
        local v94 = os.clock() - u27;
        local math_floor_ret = math.floor(v94);
        local v95;

        if p92 then
            v95 = p92.Speaker;
        else
            v95 = p92;
        end;

        v93(("[Dialogue] forcing closed a dialogue stuck open %ds (%s) before opening %s"):format(math_floor_ret, u7 and u7.Speaker or "<unknown NPC>", (tostring(v95))));
        Close();
    end;

    CinemaManager.FadeIn(LocalPlayer);
    local u96 = GetRootNode(u91);
    script_Parent.Enabled = true;
    u27 = os.clock();
    u7 = p92 or {};
    pcall(setStyleTag, u7.Speaker);
    local success, result = pcall(function() -- Line: 852
        -- upvalues: DialogueContext (ref), u7 (ref), u70 (ref), u91 (copy), u96 (copy)
        DialogueContext.Begin(u7.Speaker);
        table.clear(u70);

        for _, child in pairs(u91:GetChildren()) do
            if child:GetAttribute("Type") == "Condition" then
                child:SetAttribute("ReturnedValue", nil);
            end;
        end;

        LoadNodes(GetOutputNodes(u96));
    end);

    if success then
        local success2, result2 = pcall(function() -- Line: 881
            -- upvalues: StartDialogueCamera (ref), u7 (ref), script_Parent (ref), TrainerRemote (ref), buildTrainerPanel (ref), u44 (ref), u30 (ref), u1 (ref)
            StartDialogueCamera(u7);
            local u97 = u7;
            local Speaker2 = u97.Speaker;

            if type(Speaker2) == "string" then
                task.spawn(function() -- Line: 355
                    -- upvalues: script_Parent (ref), u7 (ref), u97 (copy), TrainerRemote (ref), Speaker2 (copy), buildTrainerPanel (ref), u44 (ref)
                    while script_Parent.Enabled and u7 == u97 do
                        local success2, result2 = pcall(function() -- Line: 357
                            -- upvalues: TrainerRemote (ref), Speaker2 (ref)
                            return TrainerRemote:InvokeServer(Speaker2, "NextSkillInfo");
                        end);

                        if not script_Parent.Enabled or u7 ~= u97 then
                            break;
                        end;

                        if success2 and type(result2) == "table" then
                            buildTrainerPanel(result2);
                        elseif u44 then
                            u44:Destroy();
                            u44 = nil;
                        end;

                        task.wait(2);
                    end;
                end);
            end;

            if u30 then
                u30:Disconnect();
            end;

            local v98 = u1 and u1:FindFirstChildOfClass("Humanoid");

            if v98 then
                u30 = v98.Died:Connect(function() -- Line: 887
                    -- upvalues: script_Parent (ref)
                    if script_Parent.Enabled then
                        Close();
                    end;
                end);
            end;
        end);

        if not success2 then
            warn(("[Dialogue] %s: camera/panel setup failed — %s"):format(u7 and u7.Speaker or "<unknown NPC>", (tostring(result2))));
        end;

        if u7.Range and u7.Position then
            WatchRange(u7);
        end;

        return;
    end;

    warn(("[Dialogue] %s errored for %s -- closing so the next NPC still works: %s"):format(u7 and u7.Speaker or "<unknown NPC>", LocalPlayer.Name, (tostring(result))));
    pcall(Close);
    script_Parent.Enabled = false;
    u7 = nil;
    u27 = nil;
end;

DialogueRemote.OnClientEvent:Connect(OnEvent);
DialogueBindable.Event:Connect(OnEvent);
PromptFrame.Activated:Connect(function() -- Line: 904
    -- upvalues: u8 (ref)
    u8 = true;
end);
UserInputService.InputBegan:Connect(function(p99) -- Line: 911
    -- upvalues: script_Parent (copy), GuiService (copy), u8 (ref)
    if not script_Parent.Enabled then
        return;
    end;

    if p99.KeyCode ~= Enum.KeyCode.ButtonA then
        return;
    end;

    if GuiService.SelectedObject ~= nil then
        return;
    end;

    u8 = true;
end);

function WatchRange(u100)
    -- upvalues: script_Parent (copy), u7 (ref), HumanoidRootPart (ref)
    task.spawn(function() -- Line: 932
        -- upvalues: script_Parent (ref), u7 (ref), u100 (copy), HumanoidRootPart (ref)
        while script_Parent.Enabled and u7 == u100 do
            if (HumanoidRootPart.Position - u100.Position).Magnitude > u100.Range then
                Close();

                return;
            end;

            task.wait(1);
        end;
    end);
end;

script.Destroying:Connect(function() -- Line: 945
    -- upvalues: u29 (ref), u30 (ref), workspace_CurrentCamera (copy)
    if u29 then
        u29:Disconnect();
    end;

    if u30 then
        u30:Disconnect();
    end;

    if workspace_CurrentCamera.CameraType == Enum.CameraType.Scriptable then
        workspace_CurrentCamera.CameraType = Enum.CameraType.Custom;
    end;
end);