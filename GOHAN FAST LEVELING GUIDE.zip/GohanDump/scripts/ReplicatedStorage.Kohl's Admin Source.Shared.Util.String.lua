-- Decompiled with Potassium's decompiler.

local Players = game:GetService("Players");
local TextChatService = game:GetService("TextChatService");
local TextService = game:GetService("TextService");
local u33 = {
    escapePattern = function(p1: string) -- Line: 12, Name: escapePattern
        return string.gsub(p1, "([%%%.%(%)%[%]%+%-%*%?%^%$])", "%%%1");
    end,

    escapeRichText = function(p2: string) -- Line: 17, Name: escapeRichText
        local string_gsub_ret = string.gsub(p2, "&", "&amp;");
        local string_gsub_ret2 = string.gsub(string_gsub_ret, "<", "&lt;");
        local string_gsub_ret3 = string.gsub(string_gsub_ret2, ">", "&gt;");
        local string_gsub_ret4 = string.gsub(string_gsub_ret3, "\"", "&quot;");

        return string.gsub(string_gsub_ret4, "\'", "&apos;");
    end,

    unescapeRichText = function(p3: string) -- Line: 27, Name: unescapeRichText
        local string_gsub_ret = string.gsub(p3, "&apos;", "\'");
        local string_gsub_ret2 = string.gsub(string_gsub_ret, "&quot;", "\"");
        local string_gsub_ret3 = string.gsub(string_gsub_ret2, "&gt;", ">");
        local string_gsub_ret4 = string.gsub(string_gsub_ret3, "&lt;", "<");

        return string.gsub(string_gsub_ret4, "&amp;", "&");
    end,

    levenshteinDistance = function(p4: string, p5: string) -- Line: 37, Name: levenshteinDistance
        local v6 = #p4;
        local v7 = #p5;

        if v6 < v7 then
            local v8 = p5;
            p5 = p4;
            p4 = v8;
            v8 = v6;
            v6 = v7;
            v7 = v8;
        end;

        if v7 == 0 then
            return v6;
        end;

        local table_create_ret = table.create(v7 + 1);

        for i = 0, v7 do
            table_create_ret[i] = i;
            local _ = i;
        end;

        for i = 1, v6 do
            local v9 = table_create_ret[0];
            table_create_ret[0] = i;
            local v10 = i;

            for i2 = 1, v7 do
                local v11 = table_create_ret[i2];
                local v12 = table_create_ret[i2 - 1] + 1;
                local v13 = string.sub(p4, v10, v10) == string.sub(p5, i2, i2) and 0 or 1;
                table_create_ret[i2] = math.min(v11 + 1, v12, v9 + v13);
                v9 = v11;
                local _ = i2;
            end;
        end;

        return table_create_ret[v7];
    end,

    splitOutsideQuotes = function(p14: string, p15: string?) -- Line: 70, Name: splitOutsideQuotes
        if not p14 then
            return {};
        end;

        local v16 = { "" };
        local v17 = (p15 == nil or p15 == "") and "," or p15;
        local v18 = nil;
        local v19 = { v16 };

        for i, v in utf8.graphemes(p14) do
            local string_sub_ret = string.sub(p14, i, v);

            if v18 then
                table.insert(v16, string_sub_ret);

                if string_sub_ret == v18 then
                    v18 = nil;
                end;
            elseif string_sub_ret == "`" or string_sub_ret == "\"" then
                table.insert(v16, string_sub_ret);
                v18 = string_sub_ret;
            elseif string_sub_ret == v17 then
                v16 = { "" };
                table.insert(v19, v16);
            else
                table.insert(v16, string_sub_ret);
            end;
        end;

        for i, v in v19 do
            v19[i] = table.concat(v);
        end;

        return v19;
    end,

    stripQuotes = function(p20: string) -- Line: 109, Name: stripQuotes
        if string.find(p20, "[`\"]") ~= 1 then
            return p20;
        end;

        local v21;

        if string.find(p20, "[`\"]", #p20) == #p20 then
            v21 = #p20 - 1;
        else
            v21 = #p20;
        end;

        return string.sub(p20, 2, v21);
    end,

    trimStart = function(p22: string) -- Line: 118, Name: trimStart
        return string.find(p22, "^%s*$") and "" or (string.match(p22, "^%s*(.*)") or "");
    end,

    trimEnd = function(p23: string) -- Line: 123, Name: trimEnd
        return string.find(p23, "^%s*$") and "" or (string.match(p23, "(.-)%s*$") or "");
    end,

    trim = function(p24: string) -- Line: 128, Name: trim
        return string.find(p24, "^%s*$") and "" or (string.match(p24, "^%s*(.*%S)") or "");
    end,

    filterResult = function(u25: string, u26: number, u27: any) -- Line: 133, Name: filterResult
        -- upvalues: TextService (copy)
        return pcall(function() -- Line: 138
            -- upvalues: TextService (ref), u25 (copy), u26 (copy), u27 (copy)
            return TextService:FilterStringAsync(u25, u26, u27 or Enum.TextFilterContext.PublicChat);
        end);
    end,

    filterResultForBroadcast = function(u28: any, p29: number) -- Line: 144, Name: filterResultForBroadcast
        if type(u28) == "string" then
            return u28;
        end;

        local _, result = pcall(function() -- Line: 148
            -- upvalues: u28 (copy)
            return u28:GetNonChatStringForBroadcastAsync();
        end);

        return result;
    end,

    filterResultForUser = function(u30: any, u31: number, u32: number) -- Line: 155, Name: filterResultForUser
        -- upvalues: Players (copy), TextChatService (copy)
        if type(u30) == "string" then
            return u30;
        end;

        local _, result = pcall(function() -- Line: 159
            -- upvalues: Players (ref), u31 (copy), TextChatService (ref), u32 (copy), u30 (copy)
            if Players:GetPlayerByUserId(u31) then
                return not TextChatService:CanUsersChatAsync(u31, u32) and "User cannot chat" or u30:GetNonChatStringForUserAsync(u32);
            end;

            return not TextChatService:CanUserChatAsync(u31) and "User cannot chat" or u30:GetNonChatStringForBroadcastAsync();
        end);

        return result;
    end
};

function u33.filterForBroadcast(p34: string, p35: number, p36: any) -- Line: 178
    -- upvalues: u33 (copy)
    local _, v37 = u33.filterResult(p34, p35, p36);

    return u33.filterResultForBroadcast(v37, p35);
end;

function u33.filterForUser(p38: string, p39: number, p40: number, p41: any) -- Line: 184
    -- upvalues: u33 (copy)
    if p39 == p40 then
        return p38;
    end;

    local _, v42 = u33.filterResult(p38, p39);

    return u33.filterResultForUser(v42, p39, p40);
end;

function u33.toFlag(p43: string) -- Line: 198
    if not p43 or #p43 < 2 then
        return "";
    end;

    local string_upper = string.upper;
    local string_sub_ret = string.sub(p43, 1, 1);
    local v44 = string.byte(string_upper(string_sub_ret)) - 65 + 127462;
    local string_upper2 = string.upper;
    local string_sub_ret2 = string.sub(p43, 2, 2);
    local v45 = string.byte(string_upper2(string_sub_ret2)) - 65 + 127462;

    return utf8.char(v44) .. utf8.char(v45);
end;

return u33;