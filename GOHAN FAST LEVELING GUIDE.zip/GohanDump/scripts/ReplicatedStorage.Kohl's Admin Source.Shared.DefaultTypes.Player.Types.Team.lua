-- Decompiled with Potassium's decompiler.

local Teams = game:GetService("Teams");
local generateValidate = require(script.Parent.Parent:WaitForChild("generateValidate"));

return function(p1) -- Line: 5
    -- upvalues: Teams (copy), generateValidate (copy)
    local function teamParse(p2, p3) -- Line: 6
        -- upvalues: Teams (ref)
        local v4 = {};
        local v5 = {};
        local v6 = false;

        for _, v in Teams:GetTeams() do
            if string.find(string.lower(v.Name), p2, 1, true) == 1 then
                v6 = true;

                for _, v2 in v:GetPlayers() do
                    local v7, v8 = p3._K.Auth.targetUserArgument(p3, v2.UserId, v2);

                    if v7 then
                        table.insert(v4, v7);
                    elseif not table.find(v5, v8) then
                        table.insert(v5, v8);
                    end;
                end;

                break;
            end;
        end;

        if not v6 then
            return false, "Invalid team";
        end;

        if #v4 <= 0 then
            v4 = false;
        end;

        return v4, #v5 > 0 and table.concat(v5, "\n") or "No targetable player found";
    end;

    local v14 = {
        listable = true,
        transform = string.lower,
        validate = generateValidate(teamParse),
        parse = teamParse,

        suggestions = function(p9, p10) -- Line: 35, Name: suggestions
            -- upvalues: Teams (ref)
            local v11 = next;
            local Teams2, v12 = Teams:GetTeams();
            local v13 = {};

            for _, v in v11, Teams2, v12 do
                table.insert(v13, "%" .. v.Name);
            end;

            return v13;
        end
    };
    p1.Registry.registerType("teamPlayers", v14);
end;