-- Decompiled with Potassium's decompiler.

local Players = game:GetService("Players");
local Debris = game:GetService("Debris");
local ReplicatedStorage = game:GetService("ReplicatedStorage");
game:GetService("RunService");
game:GetService("CollectionService");
local Modules = ReplicatedStorage:WaitForChild("Modules");
ReplicatedStorage:WaitForChild("Remotes");
local Assets = ReplicatedStorage.Assets;
local _ = Modules.Metadata;
local Shared = Modules.Shared;
local _ = Modules.Utility;
require(Shared.SoundManager);
local GlobalFunctions = require(Modules.GlobalFunctions);
local SoundManager = require(Shared.SoundManager);
local _ = workspace.World.Visuals;
local _ = Players.LocalPlayer;
local _ = Assets.Sounds;
local Particles = Assets.Effects.Particles;

return {
    Fire = function(p1) -- Line: 36
        -- upvalues: GlobalFunctions (copy), SoundManager (copy), Particles (copy)
        local Character = p1.Character;
        local v2 = p1.CurrentRate or 100;
        local UI_Time = p1.UI_Time;
        local RootAndHumanoid = GlobalFunctions.GetRootAndHumanoid(Character);
        SoundManager.AddSound("UI SFX", {
            Parent = RootAndHumanoid
        }, "Client", {
            Duration = UI_Time
        });
        SoundManager.AddSound("Ultra Instinct Awaken", {
            Parent = RootAndHumanoid
        }, "Client", {
            Duration = 1
        });
        local v3 = Particles["UI Aura"];

        for _, child in pairs(Character:GetChildren()) do
            if child:IsA("Part") then
                local v4 = child;

                for _, child2 in pairs(v3:GetChildren()) do
                    if child2:IsA("ParticleEmitter") then
                        local v5 = child2:Clone();
                        v5.Name = "UI_Aura";
                        v5.Rate = v2;
                        v5.Parent = v4;
                    end;
                end;
            end;
        end;
    end,

    ["Give Bar"] = function(p6) -- Line: 64
        -- upvalues: Assets (copy)
        local Character = p6.Character;
        local UI_Time = p6.UI_Time;
        local u7 = Assets.Gui.Transformation.Misc["UI Bar"]:Clone();
        u7.Parent = Character;
        u7.Bar.Meter:TweenSize(UDim2.new(0, 0, 1, 0), "Out", "Sine", UI_Time, true);
        task.delay(UI_Time, function() -- Line: 78
            -- upvalues: u7 (copy)
            u7:Destroy();
        end);
    end,

    Disable = function(p8) -- Line: 84
        -- upvalues: Debris (copy)
        for _, descendant in pairs(p8.Character:GetDescendants()) do
            if descendant.Name == "UI_Aura" or descendant.Name == "UI Bar" then
                descendant.Enabled = false;
                Debris:AddItem(descendant, 5);
            end;
        end;
    end
};