-- Decompiled with Potassium's decompiler.

local UI = require(script.Parent:WaitForChild("UI"));
local v1 = {};
v1.__index = v1;

function v1.new(u2) -- Line: 6
    -- upvalues: UI (copy)
    local escapeRichText = u2.Util.String.escapeRichText;

    local function v4() -- Line: 9
        -- upvalues: UI (ref)
        local v3 = UI.Theme.FontSize();
        local Offset = UI.Theme.Padding().Offset;

        return UDim2.fromOffset(0, v3 + Offset);
    end;

    local u5 = UI.state({
        Id = "vip",
        Name = "VIP"
    });
    local u6 = UI.state({ {
            Id = "vip",
            Name = "VIP"
        } });
    local u7 = UI.state();
    local u8 = nil;

    local function resetRoleTargetInput() -- Line: 19
        -- upvalues: u7 (copy), u8 (ref)
        u7(nil);
        u8.Value("");
    end;

    u8 = UI.new("Input")({
        AutomaticSize = Enum.AutomaticSize.X,
        FontFace = UI.Theme.FontMono,
        FontSize = UI.Theme.FontSize,
        MaxChars = 20,
        Placeholder = "UserId or Username",
        Size = v4,
        Value = "",
        UI.new("UIFlexItem")({
            FlexMode = Enum.UIFlexMode.Shrink
        }),
        [UI.Hook] = {
            Value = function(p9) -- Line: 38, Name: Value
                -- upvalues: u2 (copy), resetRoleTargetInput (copy), u5 (copy), u6 (copy), u7 (copy)
                local v10;

                if tonumber(p9) then
                    v10 = tonumber(p9);
                else
                    local success, result = pcall(u2.Service.Players.GetUserIdFromNameAsync, u2.Service.Players, p9);
                    v10 = success and result;
                end;

                local v11 = {
                    _K = u2,
                    definition = u2.Registry.commands.role.args[1],
                    command = {
                        from = u2.LocalPlayer.UserId,
                        fromRank = u2.Auth.getRank(u2.LocalPlayer.UserId),
                        fromRole = {},
                        rank = u2.Auth.hasCommand(u2.LocalPlayer.UserId, "role") or 0
                    }
                };
                u2.Data.targetLimits[u2.LocalPlayer.UserId] = 0;

                if v10 and not u2.Auth.targetUserArgument(v11, v10, v10) then
                    task.defer(resetRoleTargetInput);
                    v10 = nil;
                end;

                local v12 = u2.Data.members[tostring(v10)] or {};
                local v13 = {};

                for i, v in u2.Data.rolesList do
                    if i ~= 0 and (u2.client.rank._value > i or u2.creatorId == u2.LocalPlayer.UserId) then
                        local v14;

                        if u2.Auth.hasPermission(u2.LocalPlayer.UserId, "saveRoles") then
                            v14 = table.find(v12.persist or {}, v._key);
                        else
                            v14 = table.find(v12.roles or {}, v._key);
                        end;

                        if not v14 then
                            table.insert(v13, {
                                Id = v._key,
                                Name = v.name
                            });
                        end;
                    end;
                end;

                if v13 then
                    u5(v13[1]);
                    u6(v13);
                else
                    u5("");
                    u6({});
                end;

                u7(v10);
            end
        }
    });
    local u15 = nil;
    u15 = UI.new("Dialog")({
        Parent = UI.LayerTop,
        BackgroundTransparency = 0,
        Draggable = true,
        Title = "Add Role",
        Visible = false,
        ExitButton = true,
        Modal = true,

        Close = function() -- Line: 99, Name: Close
            -- upvalues: u15 (ref)
            u15.Visible(false);
        end,

        UI.new("UIPadding")({
            PaddingTop = UI.Theme.Padding,
            PaddingBottom = UI.Theme.Padding,
            PaddingLeft = UI.Theme.Padding,
            PaddingRight = UI.Theme.Padding
        }),
        UI.new("ListItem")({
            Text = "User",
            UI.new("ImageLabel")({
                BackgroundTransparency = UI.Theme.TransparencyHeavy,
                BackgroundColor3 = UI.Theme.PrimaryText,
                Size = v4,

                Image = function() -- Line: 116, Name: Image
                    -- upvalues: u7 (copy)
                    return `rbxthumb://type=AvatarHeadShot&id={u7()}&w=48&h=48`;
                end,

                UI.new("UIAspectRatioConstraint")({
                    AspectType = Enum.AspectType.ScaleWithParentSize,
                    DominantAxis = Enum.DominantAxis.Height
                }),
                UI.new("UICorner")({
                    CornerRadius = UI.Theme.CornerPadded
                })
            }),
            u8
        }),
        UI.new("ListItem")({
            Text = "Role",
            UI.new("Select")({
                Value = u5,
                Choices = u6
            }),

            Visible = function() -- Line: 136, Name: Visible
                -- upvalues: u7 (copy), u6 (copy)
                local v16 = u7() and #u6() > 0;

                return v16;
            end
        }),
        UI.new("Button")({
            Label = "Confirm",

            Activated = function() -- Line: 143, Name: Activated
                -- upvalues: u7 (copy), u2 (copy), u5 (copy), u15 (ref), u8 (ref)
                if u7._value then
                    local LocalPlayerAuthorized = u2.Registry.commands.role.LocalPlayerAuthorized;
                    local v17 = `{u2.getCommandPrefix()}{LocalPlayerAuthorized and "" or "temp"}role {u7()} {u5().Id}`;
                    u2.Process.runCommands(u2, u2.LocalPlayer.UserId, v17);
                    u15.Visible(false);
                    u7(nil);
                    u8.Value("");
                end;
            end
        })
    });
    local v18 = UI.new("Button")({
        LayoutOrder = 3,
        ActiveSound = false,
        Icon = UI.Theme.Image.Add,
        IconProperties = {
            ImageColor3 = UI.Theme.PrimaryText
        },
        Size = UDim2.new(1, 0, 1, 0),
        SizeConstraint = Enum.SizeConstraint.RelativeYY,
        UI.new("UIPadding")({
            PaddingTop = UI.Theme.Padding,
            PaddingBottom = UI.Theme.Padding,
            PaddingLeft = UI.Theme.Padding,
            PaddingRight = UI.Theme.Padding
        }),

        Visible = function() -- Line: 173, Name: Visible
            -- upvalues: u2 (copy)
            u2.client.rank();

            return u2.Registry.commands.role.LocalPlayerAuthorized or u2.Registry.commands.temprole.LocalPlayerAuthorized;
        end,

        Activated = function() -- Line: 179, Name: Activated
            -- upvalues: u15 (ref), u7 (copy), u8 (ref), UI (ref)
            if not u15.Visible._value then
                u7(nil);
                u8.Value("");
                UI.Sound.Hover03:Play();
            end;

            u15.Visible(not u15.Visible._value);
        end
    });
    UI.new("Tooltip")({
        Text = "New Member",
        Parent = v18,
        Hovering = v18._hovering
    });
    UI.edit(v18._instance.UICorner, {
        CornerRadius = UI.Theme.CornerPadded
    });
    local u23 = UI.compute(function() -- Line: 191
        -- upvalues: u2 (copy), UI (ref)
        u2.client.rank();
        local v19 = UI.Theme.Font();
        local v20 = UI.Theme.FontSize();
        local Offset = UI.Theme.Padding().Offset;
        local GetTextBoundsParams = Instance.new("GetTextBoundsParams");
        GetTextBoundsParams.Font = v19;
        GetTextBoundsParams.Size = v20;
        GetTextBoundsParams.Width = (1 / 0);
        GetTextBoundsParams.RichText = true;
        local v21 = v20;

        for _, v in u2.Data.roles do
            GetTextBoundsParams.Text = v.name;
            local X = UI.retryGetTextBoundsAsync(GetTextBoundsParams).X;
            v20 = math.max(v20, X);
        end;

        local v22 = not u2.Auth.hasPermission(u2.LocalPlayer.UserId, "saveRoles") and 0 or v21 + Offset;

        return UDim2.fromOffset(v20 + Offset * 3 + v21 + v22, (math.round(v21 + Offset)));
    end);
    local u24 = UI.new("Menu")({
        RightAlign = true,
        AutomaticSize = Enum.AutomaticSize.XY,
        Size = UDim2.new()
    });
    u24._content.AutomaticSize = Enum.AutomaticSize.X;
    local u25 = UI.state();

    local function hoverClick(p26) -- Line: 222
        -- upvalues: UI (ref)
        if p26 then
            UI.Sound.Hover02:Play();
        end;
    end;

    for i, v in u2.Data.roles do
        if v._rank and v._rank ~= 0 then
            UI.new("Button")({
                Parent = u24,
                LayoutOrder = math.min(1000000000, v._rank),
                BackgroundTransparency = 1,
                Label = v.name,
                Icon = UI.Theme.Image.Circle,
                IconProperties = {
                    Visible = true,
                    ImageColor3 = Color3.fromHex(v.color),
                    Size = UDim2.fromScale(0.5, 0.5),
                    SizeConstraint = Enum.SizeConstraint.RelativeYY
                },
                Padding = UDim.new(),
                Size = u23,
                TextXAlignment = Enum.TextXAlignment.Left,

                Visible = function() -- Line: 247, Name: Visible
                    -- upvalues: u25 (copy), u2 (copy), i (copy), v (copy)
                    local v27 = u25() or {};
                    local v28 = u2.Registry.commands.role.LocalPlayerAuthorized or u2.Registry.commands.temprole.LocalPlayerAuthorized;
                    local v29;

                    if u2.Auth.hasPermission(u2.LocalPlayer.UserId, "saveRoles") then
                        v29 = table.find(v27.persist or {}, i);
                    else
                        v29 = table.find(v27.roles or {}, i);
                    end;

                    if u2.client.rank() > v._rank or u2.creatorId == u2.LocalPlayer.UserId then
                        if v28 then
                            v28 = not v29;
                        end;
                    else
                        v28 = false;
                    end;

                    return v28;
                end,

                UI.new("ImageLabel")({
                    LayoutOrder = 9,
                    BackgroundTransparency = 1,
                    Image = UI.Theme.Image.Cloud_Save,
                    ScaleType = Enum.ScaleType.Fit,

                    Size = function() -- Line: 264, Name: Size
                        -- upvalues: UI (ref)
                        return UDim2.new(1, UI.Theme.Padding().Offset, 1, 0);
                    end,

                    SizeConstraint = Enum.SizeConstraint.RelativeYY,

                    Visible = function() -- Line: 268, Name: Visible
                        -- upvalues: u2 (copy)
                        u2.client.rank();

                        return u2.Auth.hasPermission(u2.LocalPlayer.UserId, "saveRoles");
                    end
                }),

                Activated = function() -- Line: 274, Name: Activated
                    -- upvalues: UI (ref), u24 (copy), u2 (copy), v (copy), u25 (copy), i (copy)
                    UI.deactivateState(u24.Visible, "floating");

                    if u2.client.rank._value > v._rank or u2.creatorId == u2.LocalPlayer.UserId then
                        local LocalPlayerAuthorized = u2.Registry.commands.role.LocalPlayerAuthorized;
                        local v30 = `{u2.getCommandPrefix()}{LocalPlayerAuthorized and "" or "temp"}role {u25().userId} {i}`;
                        u2.Process.runCommands(u2, u2.LocalPlayer.UserId, v30);
                    end;
                end
            })._hovering:Connect(hoverClick);
        end;
    end;

    local function roleRemoveCornerRadius() -- Line: 286
        -- upvalues: UI (ref)
        local v31 = UI.Theme.Padding();
        local v32 = UI.Theme.CornerRadius();

        return UDim.new(v32.Scale, v32.Offset - v31.Offset * 0.75);
    end;

    local function roleChip(u33: string, u34: any, u35: any) -- Line: 292
        -- upvalues: u2 (copy), UI (ref), roleRemoveCornerRadius (copy)
        local u36 = u2.Data.roles[u33];
        local Color3_fromHex_ret = Color3.fromHex(u36.color);
        local u39 = UI.compute(function() -- Line: 296
            -- upvalues: u35 (copy), u2 (ref)
            local v37 = 0;

            for _, v in u35.roles() do
                v37 = math.max(v37, u2.Data.roles[v]._rank);
            end;

            local v38;

            if v37 < u2.client.rank() or u2.creatorId == u2.LocalPlayer.UserId then
                v38 = u2.Registry.commands.unrole.LocalPlayerAuthorized;
            else
                v38 = false;
            end;

            return v38;
        end);
        local v42 = UI.new("Button")({
            BackgroundTransparency = 1,
            Text = "",
            Size = UDim2.new(1, 0, 1, 0),
            SizeConstraint = Enum.SizeConstraint.RelativeYY,
            Icon = UI.Theme.Image.Close_Bold,
            IconProperties = {
                ImageColor3 = UI.Theme.PrimaryText,
                Size = UDim2.fromScale(0.5, 0.5)
            },
            Visible = u39,

            Activated = function() -- Line: 317, Name: Activated
                -- upvalues: u2 (ref), u36 (copy), u34 (copy), u33 (copy)
                if (u2.client.rank() > u36._rank or u2.creatorId == u2.LocalPlayer.UserId) and u2.Registry.commands.unrole.LocalPlayerAuthorized then
                    local v40 = u34.name or u34.userId;

                    if string.find(v40, "%s") then
                        v40 = `"{v40}"`;
                    end;

                    local v41 = `{u2.getCommandPrefix()}unrole {v40} {u33}`;
                    u2.Process.runCommands(u2, u2.LocalPlayer.UserId, v41);
                end;
            end
        });
        UI.new("Tooltip")({
            Text = "Remove Role",
            Parent = v42,
            Hovering = v42._hovering
        });
        v42._instance.UIStroke:Destroy();
        UI.edit(v42._instance.UICorner, {
            CornerRadius = roleRemoveCornerRadius
        });

        return UI.new("Frame")({
            AutomaticSize = Enum.AutomaticSize.X,
            BackgroundColor3 = Color3_fromHex_ret,
            BackgroundTransparency = 0.75,
            Size = UDim2.new(0, 0, 1, 0),
            UI.new("UICorner")({
                CornerRadius = UI.Theme.CornerPadded
            }),
            UI.new("UIPadding")({
                PaddingLeft = function() -- Line: 347, Name: PaddingLeft
                    -- upvalues: u39 (copy), UI (ref)
                    if u39() then
                        return UI.Theme.PaddingHalf();
                    end;

                    return UI.Theme.Padding();
                end,

                PaddingRight = UI.Theme.Padding,
                PaddingTop = UI.Theme.PaddingHalf,
                PaddingBottom = UI.Theme.PaddingHalf
            }),
            UI.new("UIListLayout")({
                VerticalAlignment = Enum.VerticalAlignment.Center,
                FillDirection = Enum.FillDirection.Horizontal,
                SortOrder = Enum.SortOrder.LayoutOrder,
                Padding = UI.Theme.PaddingHalf
            }),
            v42,
            UI.new("TextLabel")({
                AutoLocalize = false,
                BackgroundTransparency = 1,
                AutomaticSize = Enum.AutomaticSize.X,
                Size = UDim2.new(0, 0, 1, 0),
                FontFace = UI.Theme.Font,
                Text = u36.name,

                TextSize = function() -- Line: 371, Name: TextSize
                    -- upvalues: UI (ref)
                    return UI.Theme.FontSize() - UI.Theme.PaddingHalf().Offset;
                end,

                TextColor3 = UI.Theme.PrimaryText,
                TextStrokeColor3 = UI.Theme.Primary,
                TextStrokeTransparency = UI.Theme.TextStrokeTransparency
            }),
            UI.new("ImageLabel")({
                LayoutOrder = 9,
                BackgroundTransparency = 1,
                Image = UI.Theme.Image.Cloud_Done,
                ScaleType = Enum.ScaleType.Fit,
                Size = UDim2.fromScale(1, 1),
                SizeConstraint = Enum.SizeConstraint.RelativeYY,

                Visible = function() -- Line: 386, Name: Visible
                    -- upvalues: u34 (copy), u33 (copy)
                    return table.find(u34.persist or {}, u33);
                end
            })
        });
    end;

    local function createItem(p43, p44) -- Line: 393
        -- upvalues: UI (ref), u2 (copy), u25 (copy), u24 (copy), u23 (copy), roleChip (copy)
        local u45 = {
            roles = UI.state({}),
            target = UI.state()
        };
        local u46 = nil;
        u46 = UI.new("Button")({
            ActiveSound = false,
            Icon = UI.Theme.Image.Add,
            IconProperties = {
                ImageColor3 = UI.Theme.PrimaryText,
                Size = UDim2.fromScale(0.5, 0.5)
            },
            Size = UDim2.new(1, 0, 1, 0),
            SizeConstraint = Enum.SizeConstraint.RelativeYY,

            Visible = function() -- Line: 409, Name: Visible
                -- upvalues: u2 (ref)
                u2.client.rank();

                return u2.Registry.commands.role.LocalPlayerAuthorized or u2.Registry.commands.temprole.LocalPlayerAuthorized;
            end,

            Activated = function() -- Line: 415, Name: Activated
                -- upvalues: u25 (ref), u45 (copy), u24 (ref), u23 (ref), u46 (ref), UI (ref)
                u25(u45.target(), true);
                local v47 = 0;

                for _, child in u24._content:GetChildren() do
                    if child:IsA("TextButton") and child.Visible then
                        v47 = v47 + 1;
                    end;
                end;

                u24._instance.Size = UDim2.fromOffset(0, math.min(v47, 7.5) * u23().Y.Offset);
                u24.Adornee(u46._instance, true);
                UI.toggleState(u24.Visible, "floating");

                if UI.raw(u24.Visible) then
                    UI.Sound.Hover03:Play();

                    return;
                end;

                UI.Sound.Hover01:Play();
            end
        });
        UI.new("Tooltip")({
            Text = "Add Role",
            Parent = u46,
            Hovering = u46._hovering
        });
        UI.edit(u46._instance.UICorner, {
            CornerRadius = UI.Theme.CornerPadded
        });
        u45._instance = UI.new("Frame")({
            BackgroundTransparency = 1,
            Size = p43.ItemSize,
            UI.new("UIPadding")({
                PaddingBottom = UI.Theme.Padding
            }),
            UI.new("UIListLayout")({
                VerticalAlignment = Enum.VerticalAlignment.Center,
                FillDirection = Enum.FillDirection.Horizontal,
                SortOrder = Enum.SortOrder.LayoutOrder,
                Padding = UI.Theme.Padding
            }),
            UI.new("ImageLabel")({
                BackgroundTransparency = UI.Theme.TransparencyHeavy,
                BackgroundColor3 = UI.Theme.PrimaryText,
                Size = UDim2.new(1, 0, 1, 0),
                SizeConstraint = Enum.SizeConstraint.RelativeYY,
                UI.new("UICorner")({
                    CornerRadius = UI.Theme.CornerPadded
                }),
                UI.new("Stroke")({})
            }),
            UI.new("TextLabel")({
                AutoLocalize = false,
                BackgroundTransparency = 1,
                RichText = true,
                AutomaticSize = Enum.AutomaticSize.X,
                Size = UDim2.new(0, 0, 1, 0),
                FontFace = UI.Theme.Font,
                TextSize = UI.Theme.FontSize,
                TextColor3 = UI.Theme.PrimaryText,
                TextStrokeColor3 = UI.Theme.Primary,
                TextStrokeTransparency = UI.Theme.TextStrokeTransparency,
                TextTruncate = Enum.TextTruncate.SplitWord,
                TextXAlignment = Enum.TextXAlignment.Left
            }),
            UI.new("ScrollingFrame")({
                AutomaticSize = Enum.AutomaticSize.X,
                AutomaticCanvasSize = Enum.AutomaticSize.X,
                BackgroundTransparency = 1,
                BorderSizePixel = 0,
                CanvasSize = UDim2.new(),
                Size = UDim2.new(0, 0, 1, 0),
                ScrollBarThickness = 0,
                UI.new("UIFlexItem")({
                    FlexMode = Enum.UIFlexMode.Shrink
                }),
                UI.new("UIListLayout")({
                    VerticalAlignment = Enum.VerticalAlignment.Center,
                    FillDirection = Enum.FillDirection.Horizontal,
                    SortOrder = Enum.SortOrder.LayoutOrder,
                    Padding = UI.Theme.Padding
                }),

                function() -- Line: 494
                    -- upvalues: u45 (copy), roleChip (ref)
                    local v48 = u45.target();
                    local v49 = {};

                    for _, v in u45.roles() do
                        table.insert(v49, roleChip(v, v48, u45));
                    end;

                    return v49;
                end
            }),
            u46
        });

        return u45;
    end;

    local function isDifferent(p50: table?, p51: table?) -- Line: 509
        if not p50 ~= not p51 then
            return true;
        end;

        if p50 and p51 then
            if #p50 ~= #p51 then
                return true;
            end;

            for i, v in p50 do
                if p51[i] ~= v then
                    return true;
                end;
            end;
        end;

        return false;
    end;

    local u57 = UI.new("ScrollerFast")({
        Name = "Members",
        Enabled = false,
        DictList = true,
        FilterInput = true,
        Visible = false,
        List = u2.client.members,
        CreateItem = createItem,

        RenderItem = function(p52, p53, p54) -- Line: 526, Name: renderItem
            -- upvalues: u2 (copy)
            local v55 = u2.Data.members[p54];

            if v55 and v55.renderText then
                local _instance = p53._instance;
                _instance.TextLabel.Text = v55.renderText;
                _instance.ImageLabel.Image = `rbxthumb://type=AvatarHeadShot&id={v55.userId}&w=48&h=48`;
                p53.target(v55);
                local _value = p53.roles._value;
                local roles = v55.roles;
                local v56;

                if not _value == not roles then
                    if _value and roles then
                        if #_value == #roles then
                            v56 = false;

                            for i, v in _value do
                                if roles[i] ~= v then
                                    v56 = true;
                                    break;
                                end;
                            end;
                        else
                            v56 = true;
                        end;
                    end;
                else
                    v56 = true;
                end;

                if v56 then
                    p53.roles(v55.roles);
                end;
            end;
        end
    });
    u57._input._instance = UI.new("Frame")({
        Parent = u57,
        Name = "FilterInput",
        BackgroundTransparency = 1,

        Size = function() -- Line: 555, Name: Size
            -- upvalues: UI (ref)
            return UDim2.new(0, 0, 0, UI.Theme.FontSize() + UI.Theme.PaddingDouble().Offset);
        end,

        UI.new("UIListLayout")({
            FillDirection = Enum.FillDirection.Horizontal,
            Padding = UI.Theme.PaddingWithStroke,
            SortOrder = Enum.SortOrder.LayoutOrder
        }),
        UI.edit(u57._input, { UI.new("UIFlexItem")({
                FlexMode = Enum.UIFlexMode.Fill
            }) }),
        v18
    });

    local function updateCache(p58) -- Line: 568
        -- upvalues: u2 (copy)
        p58.nameCache = p58.name;
        local v59;

        if p58.roles then
            v59 = table.clone(p58.roles);
        else
            v59 = nil;
        end;

        p58.rolesCache = v59;
        local v60;

        if p58.persist then
            v60 = table.clone(p58.persist);
        else
            v60 = nil;
        end;

        p58.persistCache = v60;

        if p58.roles then
            local v61 = {};

            for _, v in p58.roles do
                local v62 = u2.Data.roles[v];

                if v62 then
                    table.insert(v61, v62.name);
                end;
            end;

            p58.roleString = table.concat(v61, " | ") or "";
        else
            p58.roleString = "";
        end;

        p58.richText = `<b>{p58.name or "UNKNOWN"}</b> [{p58.userId}]`;
        p58.rawText = `{p58.name or "UNKNOWN"} [{p58.userId}]`;
        p58.filterText = string.lower((`{p58.rawText} {p58.roleString}`));
    end;

    task.defer(u57.filter, u57, function(p63, p64) -- Line: 592, Name: filterTest
        -- upvalues: u57 (copy), u2 (copy), updateCache (copy), escapeRichText (copy)
        local string_lower_ret = string.lower(u57._input._input.Text);
        p63._filter = string_lower_ret;
        local string_find_ret = string.find(p63._filter, "^%s*$");
        local v65 = {};

        for _, v in p64 do
            local v66 = u2.Data.members[v];

            if v66 then
                local v67, v68;

                if v66.name ~= v66.nameCache then
                    v67 = v;
                    v66.userId = v67;
                    updateCache(v66);

                    if string_find_ret then
                        v66.renderText = v66.richText;
                        table.insert(v65, v67);
                    else
                        v68 = string.find(v66.filterText, string_lower_ret, 1, true);

                        if v68 then
                            v66.renderText = `<font transparency="0.5">{escapeRichText((string.sub(v66.rawText, 1, v68 - 1)))}</font><b>{escapeRichText((string.sub(v66.rawText, v68, v68 + #string_lower_ret - 1)))}</b><font transparency="0.5">{escapeRichText((string.sub(v66.rawText, v68 + #string_lower_ret)))}</font>`;
                            table.insert(v65, v67);
                        end;
                    end;
                end;

                local roles = v66.roles;
                local rolesCache = v66.rolesCache;
                local v69;

                if not roles == not rolesCache then
                    if roles and rolesCache then
                        if #roles == #rolesCache then
                            v67 = v;
                            v69 = false;

                            for i, v2 in roles do
                                if rolesCache[i] ~= v2 then
                                    v69 = true;
                                    break;
                                end;
                            end;
                        else
                            v67 = v;
                            v69 = true;
                        end;
                    else
                        v67 = v;
                    end;
                else
                    v67 = v;
                    v69 = true;
                end;

                if v69 then
                    v66.userId = v67;
                    updateCache(v66);

                    if string_find_ret then
                        v66.renderText = v66.richText;
                        table.insert(v65, v67);
                    else
                        v68 = string.find(v66.filterText, string_lower_ret, 1, true);

                        if v68 then
                            v66.renderText = `<font transparency="0.5">{escapeRichText((string.sub(v66.rawText, 1, v68 - 1)))}</font><b>{escapeRichText((string.sub(v66.rawText, v68, v68 + #string_lower_ret - 1)))}</b><font transparency="0.5">{escapeRichText((string.sub(v66.rawText, v68 + #string_lower_ret)))}</font>`;
                            table.insert(v65, v67);
                        end;
                    end;
                end;

                local persist = v66.persist;
                local persistCache = v66.persistCache;
                local v70;

                if not persist == not persistCache then
                    if persist and persistCache then
                        if #persist == #persistCache then
                            v70 = false;

                            for i, v2 in persist do
                                if persistCache[i] ~= v2 then
                                    v70 = true;
                                    break;
                                end;
                            end;
                        else
                            v70 = true;
                        end;
                    end;
                else
                    v70 = true;
                end;

                if v70 then
                    v66.userId = v67;
                    updateCache(v66);

                    if string_find_ret then
                        v66.renderText = v66.richText;
                        table.insert(v65, v67);
                    else
                        v68 = string.find(v66.filterText, string_lower_ret, 1, true);

                        if v68 then
                            v66.renderText = `<font transparency="0.5">{escapeRichText((string.sub(v66.rawText, 1, v68 - 1)))}</font><b>{escapeRichText((string.sub(v66.rawText, v68, v68 + #string_lower_ret - 1)))}</b><font transparency="0.5">{escapeRichText((string.sub(v66.rawText, v68 + #string_lower_ret)))}</font>`;
                            table.insert(v65, v67);
                        end;
                    end;
                end;

                if string_find_ret then
                    v66.renderText = v66.richText;
                    table.insert(v65, v67);
                else
                    v68 = string.find(v66.filterText, string_lower_ret, 1, true);

                    if v68 then
                        v66.renderText = `<font transparency="0.5">{escapeRichText((string.sub(v66.rawText, 1, v68 - 1)))}</font><b>{escapeRichText((string.sub(v66.rawText, v68, v68 + #string_lower_ret - 1)))}</b><font transparency="0.5">{escapeRichText((string.sub(v66.rawText, v68 + #string_lower_ret)))}</font>`;
                        table.insert(v65, v67);
                    end;
                end;
            end;
        end;

        return v65;
    end);

    return u57;
end;

return v1;