-- Decompiled with Potassium's decompiler.

game:GetService("Players");
local Debris = game:GetService("Debris");
local ReplicatedStorage = game:GetService("ReplicatedStorage");
local RunService = game:GetService("RunService");
game:GetService("UserInputService");
local CollectionService = game:GetService("CollectionService");
local Assets = ReplicatedStorage.Assets;
local Modules = ReplicatedStorage:WaitForChild("Modules");
local Remotes = ReplicatedStorage:WaitForChild("Remotes");
local _ = Modules.Metadata;
local Shared = Modules.Shared;
local Utility = Modules.Utility;
local _ = Assets.Gui;
require(Utility.Create);
require(Shared.SoundManager);
require(Modules.GlobalFunctions);
local VfxHandler = require(Modules.Effects.VfxHandler);
require(Shared.CamManager);
require(Shared.CinemaManager);
local HitboxHandler = require(Utility.HitboxHandler);
local FindCharacters = require(Shared.FindCharacters);
local ReplicationModule = require(Utility.ReplicationModule);
local UtilityHandler = require(Utility.UtilityHandler);
local FastCastRedux = require(Shared.FastCastRedux);
local _ = Remotes.ClashRemote;
local ExplosionRemote = Remotes.ExplosionRemote;
local BindDamageRemote = ReplicatedStorage.Remotes.BindDamageRemote;
local workspace_World = workspace.World;
local Visuals = workspace_World.Visuals;
local _ = Assets.Effects.Meshes;
local Zones = workspace_World.Map.Zones;
local _ = Assets.Sounds;
local Effects = Assets.Effects;
local _ = Effects.Meshes;
local _ = Effects.Particles;
local u1 = FastCastRedux.new();
FastCastRedux.VisualizeCasts = false;

local function bezierRandoms(p2, p3) -- Line: 75
    local math_abs_ret = math.abs(p2.X * 73856093 + p2.Y * 19349663 + p2.Z * 83492791 + p3.X * 15485863 + p3.Y * 49979687 + p3.Z * 32452843);
    local Random_new_ret = Random.new((math.floor(math_abs_ret % 2147483648)));

    return Random_new_ret:NextNumber() < 0.5 and 1 or -1, Random_new_ret:NextNumber(0.7, 1);
end;

FastCastRedux.newBehavior();
local RaycastParams_new_ret = RaycastParams.new();
RaycastParams_new_ret.FilterType = Enum.RaycastFilterType.Exclude;
RaycastParams_new_ret.RespectCanCollide = true;

local function getVoxelIgnores() -- Line: 102
    -- upvalues: CollectionService (copy)
    local Tagged = CollectionService:GetTagged("Debris");
    local VoxelCache = workspace:FindFirstChild("VoxelCache");

    if VoxelCache then
        table.insert(Tagged, VoxelCache);
    end;

    local VoxelDebris = workspace:FindFirstChild("VoxelDebris");

    if VoxelDebris then
        table.insert(Tagged, VoxelDebris);
    end;

    return Tagged;
end;

local function onCanPierce(p4, p5, p6) -- Line: 132
    -- upvalues: RunService (copy), VfxHandler (copy)
    local UserData = p4.UserData;

    if UserData and UserData.Is_Weapon then
        return false;
    end;

    local Instance = p5.Instance;

    if Instance and (Instance:IsA("BasePart") and Instance.Transparency >= 0.95) then
        return true;
    end;

    if UserData and (UserData.CutsBreakables and (UserData.Voxelize ~= false and Instance)) then
        local v7 = Instance:FindFirstAncestorOfClass("Model");

        if Instance:GetAttribute("Breakable") ~= nil or v7 and v7:GetAttribute("Breakable") == true then
            if RunService:IsServer() then
                local u8 = p6 and (p6.Magnitude > 0.01 and p6.Unit) or nil;
                local u9 = typeof(UserData.CutSize) == "number" and (UserData.CutSize or 8) or 8;
                local Position = p5.Position;
                task.spawn(function() -- Line: 155
                    -- upvalues: VfxHandler (ref), Position (copy), u9 (copy), u8 (copy)
                    VfxHandler["Voxel Destruction"].BeamCarve({
                        Location = CFrame.new(Position)
                    }, Vector3.new(1, 1, 1) * u9, nil, u8);
                end);
            end;

            return true;
        end;
    end;

    return false;
end;

function CleanUp(p10)
    for _, v in pairs(p10) do
        if v then
            v:Disconnect();
        end;
    end;
end;

u1.LengthChanged:Connect(function(p11: any, p12: any, p13: any, p14: any, p15: any, p16: userdata) -- Line: 402
    -- upvalues: HitboxHandler (copy), FindCharacters (copy), UtilityHandler (copy), BindDamageRemote (copy), ReplicationModule (copy)
    local UserData = p11.UserData;
    local v17 = UserData.Character or UserData.Weapon;
    local ProjectileSize = UserData.ProjectileSize;
    local v18 = UserData.HitModule or nil;
    local v19 = UserData.HitFunction or nil;
    local _ = UserData.Is_Weapon or nil;
    local _ = UserData.IgnoreInstances or nil;
    local v20 = p12 + p13 * p14;

    if p16 then
        p16.Position = v20;

        if UserData.LookAtGoal then
            p16.CFrame = CFrame.new(p12, v20) * CFrame.Angles(0, 3.141592653589793, 0);
        end;
    end;

    if v18 and v19 then
        local v21 = {
            Size = ProjectileSize,
            Location = p16 and p16.CFrame or CFrame.new(v20)
        };
        local _, v22 = HitboxHandler.New(v21);
        local v23 = FindCharacters.Find(v17, v22);

        if UtilityHandler:Length(v23) > 0 then
            for _, v in pairs(v23) do
                v:FindFirstChild("HumanoidRootPart");

                if v:FindFirstChild("Humanoid").Health <= 0 then
                    return;
                end;

                local _, _ = BindDamageRemote:Fire(v17, v, UserData, "Skill");

                if type(UserData.OnServerHit) == "function" then
                    pcall(UserData.OnServerHit, v);
                end;

                ReplicationModule.FireMultipleClientRange(v, "ClientRemote", 150, {
                    Character = v17,
                    Victim = v,
                    Module = v18,
                    Function = v19
                });
            end;
        end;
    end;
end);
u1.RayHit:Connect(function(p24: any, u25, p26: any, p27: any) -- Line: 461
    -- upvalues: ReplicationModule (copy), VfxHandler (copy), ExplosionRemote (copy)
    local UserData = p24.UserData;
    local Character = UserData.Character;
    local v28 = UserData.Module or nil;
    local v29 = UserData.Function or nil;
    local _ = UserData.HitModule or nil;
    local _ = UserData.HitFunction or nil;
    local v30 = UserData.NoExplosion or nil;
    local ProjectileSize = UserData.ProjectileSize;
    local _ = UserData.IgnoreInstances or nil;
    local v31 = UserData.Is_Weapon or nil;
    local v32 = {
        CFrame = CFrame.new(u25.Position),
        Size = ProjectileSize
    };

    if p27 then
        p27:Destroy();
    end;

    if not (v28 and v29) then
        return;
    end;

    if v30 then
        return;
    end;

    ReplicationModule.FireMultipleClient(Character, "ClientRemote", {
        Character = Character,
        Module = v28,
        Function = v29,
        Location = CFrame.new(u25.Position),
        Instance = u25.Instance,
        Size = UserData.Size,
        Color = UserData.Color or Color3.fromRGB(255, 255, 255),
        BulletData = v32
    });
    UserData.ExplosionPoint = u25.Position;
    UserData.ExplosionSize = UserData.Size;

    if not v31 and UserData.Voxelize ~= false then
        local u33 = typeof(UserData.Size) == "number" and (UserData.Size or 8) or 8;
        local u34 = p26 and (p26.Magnitude > 0.01 and p26.Unit) or nil;
        task.spawn(function() -- Line: 525
            -- upvalues: VfxHandler (ref), u25 (copy), u33 (copy), u34 (copy)
            VfxHandler["Voxel Destruction"].Carve({
                Location = CFrame.new(u25.Position)
            }, Vector3.new(1, 1, 1) * u33, 15, u34, nil, {
                MaxBiteRadius = 32
            });
        end);
    end;

    ExplosionRemote:Fire(UserData);
end);

return {
    Fire = function(u35) -- Line: 183
        -- upvalues: FastCastRedux (copy), onCanPierce (copy), Effects (copy), Visuals (copy), Zones (copy), CollectionService (copy), bezierRandoms (copy), u1 (copy), Debris (copy)
        local Origin = u35.Origin;
        local Goal = u35.Goal;
        local _ = u35.Acceleration or nil;
        local v36 = u35.Duration or 1;
        local u37 = u35.Speed or 100;
        local _ = u35.Sound or nil;
        local v38 = u35.HasHandle or nil;
        local Character = u35.Character;
        local IgnoreInstances = u35.IgnoreInstances;
        local v39 = FastCastRedux.newBehavior();
        local RaycastParams_new_ret2 = RaycastParams.new();
        RaycastParams_new_ret2.FilterType = Enum.RaycastFilterType.Exclude;
        RaycastParams_new_ret2.RespectCanCollide = true;
        v39.CanPierceFunction = onCanPierce;
        local u40 = u35.SentProjectile and Effects:FindFirstChild(u35.SentProjectile, true) or u35.Projectile and Visuals:FindFirstChild(u35.Projectile);

        if u40 then
            local _ = u35.Projectile;

            if v38 then
                v39.CosmeticBulletTemplate = u40.Handle;
            else
                v39.CosmeticBulletTemplate = u40;
            end;

            local Trail = u40:FindFirstChild("Trail");

            if Trail then
                local v41 = u35.Color or Color3.fromRGB(255, 255, 255);
                Trail.Color = ColorSequence.new({ ColorSequenceKeypoint.new(0, v41), ColorSequenceKeypoint.new(1, v41) });
            end;

            if u40.Name == "Ki Ball" then
                local v42 = u35.Color or Color3.fromRGB(255, 255, 255);

                for _, child in pairs(u40.Main:GetChildren()) do
                    child.Enabled = true;
                    child.Color = ColorSequence.new({ ColorSequenceKeypoint.new(0, v42), ColorSequenceKeypoint.new(1, v42) });
                end;

                for _, child in pairs(u40["Ki Trail"]:GetChildren()) do
                    child.Enabled = true;
                    child.Color = ColorSequence.new({ ColorSequenceKeypoint.new(0, v42), ColorSequenceKeypoint.new(1, v42) });
                end;
            end;

            if not v38 then
                local CosmeticBulletTemplate = v39.CosmeticBulletTemplate;

                if CosmeticBulletTemplate then
                    local Attribute = CosmeticBulletTemplate:GetAttribute("AuthoredSize");

                    if Attribute == nil then
                        Attribute = CosmeticBulletTemplate.Size;
                        CosmeticBulletTemplate:SetAttribute("AuthoredSize", Attribute);
                    end;

                    CosmeticBulletTemplate.Size = u35.ProjectileSize or Attribute;
                    local Attribute2 = CosmeticBulletTemplate:GetAttribute("AuthoredColor");

                    if Attribute2 == nil then
                        Attribute2 = CosmeticBulletTemplate.Color;
                        CosmeticBulletTemplate:SetAttribute("AuthoredColor", Attribute2);
                    end;

                    CosmeticBulletTemplate.Color = u35.Color or Attribute2;
                end;
            end;
        end;

        local v43 = IgnoreInstances and { IgnoreInstances, Visuals } or (Character and { Visuals, Character, Zones } or { Visuals });
        local v44 = ipairs;
        local Tagged = CollectionService:GetTagged("Debris");
        local VoxelCache = workspace:FindFirstChild("VoxelCache");

        if VoxelCache then
            table.insert(Tagged, VoxelCache);
        end;

        local VoxelDebris = workspace:FindFirstChild("VoxelDebris");

        if VoxelDebris then
            table.insert(Tagged, VoxelDebris);
        end;

        for _, v in v44(Tagged) do
            table.insert(v43, v);
        end;

        RaycastParams_new_ret2.FilterDescendantsInstances = v43;
        v39.RaycastParams = RaycastParams_new_ret2;
        v39.CosmeticBulletContainer = Visuals;
        local v45 = Goal - Origin;
        local Magnitude = v45.Magnitude;
        local v46 = u35.Bezier and not u35.Is_Weapon;

        if v46 and Magnitude > 300 then
            Goal = Origin + v45.Unit * 300;
            v45 = Goal - Origin;
            Magnitude = 300;
        end;

        local u47;

        if v46 and Magnitude >= 15 then
            local math_max_ret = math.max(Magnitude / u37, 0.1);
            local Unit = v45.Unit;
            local v48, v49 = bezierRandoms(Origin, Goal);
            local v50 = Unit:Cross(Vector3.new(0, 1, 0));

            if v50.Magnitude < 0.01 then
                v50 = Unit:Cross(Vector3.new(1, 0, 0));
            end;

            local v51 = v50.Unit * v48;
            local v52 = Vector3.new(0, 1, 0) - Unit * (Vector3.new(0, 1, 0)):Dot(Unit);
            local v53 = v51 + (v52.Magnitude > 0.01 and v52.Unit or Vector3.new(0, 0, 0)) * 0.35;

            if v53.Magnitude > 0.01 then
                v51 = v53.Unit or v51;
            end;

            local v54 = math.min(Magnitude * 0.015, 5) * v49;
            local v55 = u35.ControlPoint or (Origin + Goal) / 2 + v51 * v54;
            local v56 = (v55 - Origin) * (2 / math_max_ret);
            v39.Acceleration = (Origin - v55 * 2 + Goal) * (2 / (math_max_ret * math_max_ret));
            u47 = u1:Fire(Origin, v56.Unit, v56, v39);
            local u57 = u47;
            task.delay(math_max_ret, function() -- Line: 341
                -- upvalues: u57 (copy), u37 (copy)
                if not u57.UserData then
                    return;
                end;

                pcall(function() -- Line: 343
                    -- upvalues: u57 (ref), u37 (ref)
                    local Velocity = u57:GetVelocity();

                    if Velocity.Magnitude > 0.01 then
                        u57:SetVelocity(Velocity.Unit * u37);
                    end;

                    u57:SetAcceleration(Vector3.new(0, 0, 0));
                end);
            end);
        else
            u47 = u1:Fire(Origin, v45.Unit, u37, v39);
        end;

        u47.UserData = u35;

        if u35.Projectile then
            local v58 = u47.RayInfo and u47.RayInfo.CosmeticBulletObject;

            if v58 then
                v58:SetAttribute("Staged", nil);
            end;

            if u40 then
                u40:Destroy();
            end;
        end;

        task.delay(v36, function() -- Line: 363
            -- upvalues: u47 (ref), Debris (ref), u35 (copy), u40 (copy)
            if u47.UserData then
                Debris:AddItem(u47.RayInfo.CosmeticBulletObject, 0.1);

                if u35.Projectile and u40 then
                    u40:Destroy();
                end;

                u47:Terminate(u47);
            end;
        end);
    end,

    RollControlPoint = function(p59, p60) -- Line: 387, Name: RollControlPoint
        local v61 = p60 - p59;
        local Magnitude = v61.Magnitude;

        if Magnitude < 15 then
            return nil;
        end;

        local Unit = v61.Unit;
        local v62 = Unit:Cross(Vector3.new(0, 1, 0));

        if v62.Magnitude < 0.01 then
            v62 = Unit:Cross(Vector3.new(1, 0, 0));
        end;

        local v63 = v62.Unit * (math.random(0, 1) == 0 and -1 or 1);
        local v64 = Vector3.new(0, 1, 0) - Unit * (Vector3.new(0, 1, 0)):Dot(Unit);
        local v65 = v63 + (v64.Magnitude > 0.01 and v64.Unit or Vector3.new(0, 0, 0)) * 0.35;

        if v65.Magnitude > 0.01 then
            v63 = v65.Unit or v63;
        end;

        local v66 = math.min(Magnitude * 0.015, 5) * (0.7 + math.random() * 0.3);

        return (p59 + p60) / 2 + v63 * v66;
    end
};