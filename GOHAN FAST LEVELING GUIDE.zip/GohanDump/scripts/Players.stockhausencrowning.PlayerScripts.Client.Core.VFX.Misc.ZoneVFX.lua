-- Decompiled with Potassium's decompiler.

local Players = game:GetService("Players");
local Debris = game:GetService("Debris");
local ReplicatedStorage = game:GetService("ReplicatedStorage");
game:GetService("RunService");
game:GetService("CollectionService");
local Modules = ReplicatedStorage:WaitForChild("Modules");
local Remotes = ReplicatedStorage:WaitForChild("Remotes");
local Assets = ReplicatedStorage.Assets;
local Metadata = Modules.Metadata;
local Shared = Modules.Shared;
local Utility = Modules.Utility;
require(Shared.SoundManager);
local GlobalFunctions = require(Modules.GlobalFunctions);
local CinemaManager = require(Shared.CinemaManager);
local Zone = require(Shared.Zone);
local ZoneData = require(Metadata.ZoneData.ZoneData);
local GameMessage = require(Utility.GameMessage);
local ServerRemote = Remotes.ServerRemote;
local workspace_World = workspace.World;
local Map = workspace_World.Map;
local CurrentPlanet = Map.CurrentPlanet;
local Visuals = workspace_World.Visuals;
local LocalPlayer = Players.LocalPlayer;
local Zones = Map.Zones;
local u1 = Map["Zone Locations"];
local Meshes = Assets.Effects.Meshes;
local workspace_CurrentCamera = workspace.CurrentCamera;

function Exp_Handler(p2, p3)
    -- upvalues: ServerRemote (copy)
    ServerRemote:FireServer(nil, {
        Module = "ZoneTransitionHandler",
        Action = "ExpBoost",
        ZoneName = p3,
        NewAction = p2
    });
end;

function Gravity_Handler(p4, p5)
    -- upvalues: ServerRemote (copy)
    ServerRemote:FireServer(nil, {
        Module = "ZoneTransitionHandler",
        Action = "Gravity",
        ZoneName = p5,
        NewAction = p4
    });
end;

local function ResolveCFrame(p6) -- Line: 107
    if typeof(p6) == "CFrame" then
        return p6;
    end;

    if typeof(p6) == "Instance" and p6:IsA("BasePart") then
        return p6.CFrame;
    end;

    return nil;
end;

function Transport_To_Location(p7)
    -- upvalues: LocalPlayer (copy), GameMessage (copy), GlobalFunctions (copy), workspace_CurrentCamera (copy), Meshes (copy), Visuals (copy), Debris (copy), ServerRemote (copy), CinemaManager (copy)
    local Character = LocalPlayer.Character;

    if not Character then
        return;
    end;

    if Character:FindFirstChild("Flying") then
        GameMessage.SendMessage(LocalPlayer, "Can\'t transistion while flying");

        return;
    end;

    local RootAndHumanoid = GlobalFunctions.GetRootAndHumanoid(Character);
    local u8;

    if typeof(p7) == "CFrame" then
        u8 = p7;
    elseif typeof(p7) == "Instance" and p7:IsA("BasePart") then
        u8 = p7.CFrame;
    else
        u8 = nil;
    end;

    if not u8 then
        warn("[ZoneVFX] Transport: unusable destination (" .. typeof(p7) .. ")");

        return;
    end;

    (function() -- Line: 128, Name: DomainSphere
        -- upvalues: workspace_CurrentCamera (ref), RootAndHumanoid (copy), Meshes (ref), Visuals (ref), Debris (ref), ServerRemote (ref), GlobalFunctions (ref), CinemaManager (ref), LocalPlayer (ref), u8 (copy)
        workspace_CurrentCamera.CameraType = Enum.CameraType.Scriptable;
        workspace_CurrentCamera.CFrame = RootAndHumanoid.CFrame * CFrame.new(0, 5, -5);
        local u9 = Meshes.Domain:Clone();
        u9.Parent = Visuals;
        u9.CFrame = RootAndHumanoid.CFrame;
        u9.Size = Vector3.new(100, 100, 100);
        Debris:AddItem(u9, 10);
        u9.PFX.Enabled = true;
        ServerRemote:FireServer(nil, {
            Module = "ZoneTransitionHandler",
            Action = "Transistion"
        });
        GlobalFunctions.Tween({
            Instance = u9.PFX,
            Duration = 1
        }, {
            ShapePartial = 1
        }).Completed:Once(function() -- Line: 161
            -- upvalues: CinemaManager (ref), LocalPlayer (ref), workspace_CurrentCamera (ref), u9 (copy), RootAndHumanoid (ref), u8 (ref)
            CinemaManager.Transition(LocalPlayer);
            task.wait(1);
            workspace_CurrentCamera.CameraType = Enum.CameraType.Custom;
            u9.PFX.Enabled = false;
            u9.PFX.EmissionDirection = Enum.NormalId.Front;
            RootAndHumanoid.CFrame = u8;
        end);
    end)();
    local v10 = GlobalFunctions.CastRay(RootAndHumanoid.Position, Vector3.new(0, -10, 0));

    if v10 then
        local u11 = Meshes["Domain Ground"]:Clone();
        u11.Parent = Visuals;
        u11.CFrame = CFrame.new(v10.Position);
        u11.PFX.Enabled = true;
        u11.Size = Vector3.new(100, 0.1, 100);
        Debris:AddItem(u11, 5);
        GlobalFunctions.Tween({
            Instance = u11.PFX
        }, {
            ShapePartial = 1
        }).Completed:Once(function() -- Line: 198
            -- upvalues: u11 (copy)
            task.wait(1);
            u11.PFX.EmissionDirection = Enum.NormalId.Front;
            u11.PFX.Enabled = false;
        end);
        task.delay(3, function() -- Line: 204
            -- upvalues: u11 (copy)
            u11.PFX.Enabled = false;
        end);
    end;
end;

function Find_Location(p12)
    -- upvalues: u1 (copy)
    for _, child in pairs(u1:GetChildren()) do
        if child.Name == p12 then
            return child;
        end;
    end;

    return nil;
end;

return {
    Fire = function() -- Line: 46
        -- upvalues: Zones (copy), Zone (copy), CinemaManager (copy), LocalPlayer (copy), ZoneData (copy), CurrentPlanet (copy)
        for _, child in pairs(Zones:GetChildren()) do
            local v13 = Zone.new(child);
            v13.localPlayerEntered:Connect(function() -- Line: 49
                -- upvalues: child (copy), CinemaManager (ref), LocalPlayer (ref), ZoneData (ref)
                local Name = child.Name;
                CinemaManager.ChangeZone(LocalPlayer, {
                    ZoneName = Name
                });

                if ZoneData[Name] and ZoneData[Name].has_Location == true then
                    local v14 = Find_Location(Name);

                    if v14 ~= nil then
                        Transport_To_Location(v14);
                    end;
                end;

                if ZoneData[Name] and ZoneData[Name]["Exp Boost"] then
                    Exp_Handler("Enter", Name);
                end;

                if ZoneData[Name] and ZoneData[Name].Gravity then
                    Gravity_Handler("Enter", Name);
                end;
            end);
            v13.localPlayerExited:Connect(function() -- Line: 67
                -- upvalues: child (copy), CinemaManager (ref), LocalPlayer (ref), CurrentPlanet (ref), ZoneData (ref)
                local Name = child.Name;
                CinemaManager.ChangeZone(LocalPlayer, {
                    ZoneName = CurrentPlanet.Planet.Value
                });

                if ZoneData[Name] and ZoneData[Name]["Exp Boost"] then
                    Exp_Handler("Exit", Name);
                end;

                if ZoneData[Name] and ZoneData[Name].Gravity then
                    Gravity_Handler("Exit", Name);
                end;
            end);
        end;
    end,

    Transport = function(p15) -- Line: 80
        Transport_To_Location(p15.Location);
    end
};