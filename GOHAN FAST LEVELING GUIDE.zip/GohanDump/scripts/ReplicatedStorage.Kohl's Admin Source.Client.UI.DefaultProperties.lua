-- Decompiled with Potassium's decompiler.

return function(p1) -- Line: 1
    return {
        ImageButton = {
            HoverHapticEffect = p1.Haptic.Hover,
            PressHapticEffect = p1.Haptic.Click
        },
        TextButton = {
            HoverHapticEffect = p1.Haptic.Hover,
            PressHapticEffect = p1.Haptic.Click
        }
    };
end;