-- Decompiled with Potassium's decompiler.

local Players = game:GetService("Players");
local Debris = game:GetService("Debris");
local ReplicatedStorage = game:GetService("ReplicatedStorage");
game:GetService("RunService");
game:GetService("CollectionService");
local Modules = ReplicatedStorage:WaitForChild("Modules");
ReplicatedStorage:WaitForChild("Remotes");
local Assets = ReplicatedStorage.Assets;
local _ = Modules.Metadata;
local Shared = Modules.Shared;
local _ = Modules.Utility;
local SoundManager = require(Shared.SoundManager);
local GlobalFunctions = require(Modules.GlobalFunctions);
require(Shared.CinemaManager);
local _ = workspace.World.Visuals;
local _ = Players.LocalPlayer;
local _ = Assets.Sounds;
local _ = Assets.Effects.Particles;

local function Highlight_Character(p1, p2) -- Line: 35
    -- upvalues: Debris (copy), GlobalFunctions (copy)
    local v3 = p2 or Color3.fromRGB(150, 255, 150);
    local Highlight = Instance.new("Highlight");
    Highlight.Parent = p1;
    Highlight.FillTransparency = 0;
    Highlight.FillColor = v3;
    Debris:AddItem(Highlight, 1);
    GlobalFunctions.Tween({
        Duration = 1,
        Instance = Highlight
    }, {
        FillTransparency = 1,
        OutlineTransparency = 1
    });
end;

return {
    Heal = function(p4) -- Line: 49
        -- upvalues: GlobalFunctions (copy), SoundManager (copy), Highlight_Character (copy)
        local Character = p4.Character;
        local RootAndHumanoid = GlobalFunctions.GetRootAndHumanoid(Character);
        SoundManager.AddSound("Heal SFX", {
            Parent = RootAndHumanoid
        }, "Client");
        Highlight_Character(Character);
    end,

    ["Super Heal"] = function(p5) -- Line: 57
        -- upvalues: GlobalFunctions (copy), SoundManager (copy), Highlight_Character (copy)
        local Character = p5.Character;
        local RootAndHumanoid = GlobalFunctions.GetRootAndHumanoid(Character);
        local Color3_fromRGB_ret = Color3.fromRGB(200, 200, 150);
        SoundManager.AddSound("Heal SFX", {
            Parent = RootAndHumanoid
        }, "Client");
        Highlight_Character(Character, Color3_fromRGB_ret);
    end
};