-- Decompiled with Potassium's decompiler.

local RunService = game:GetService("RunService");
local Parent = script.Parent.Parent.Parent;
local Theme = require(Parent.Client:WaitForChild("UI"):WaitForChild("Theme"));
local Z = require(Parent:WaitForChild("Z"));
Z.TRIM_STRINGS = true;
local v1 = {
    log = Z.schema({
        Z.str16,
        Z.byte,
        Z.f64,
        Z.some(Z.uint),
        Z.some(Z.str8)
    })
};
v1.logs = Z.schema({ v1.log });
v1.logRemote = Z.schema({
    Z.str16,
    Z.byte,
    Z.f64,
    Z.some(Z.uint),
    Z.some(Z.str8),
    Z.some(Z.bool)
});
v1.logsRemote = Z.schema({ v1.logRemote });
v1.logV0 = Z.schema({
    level = Z.byte,
    from = Z.some(Z.uint),
    name = Z.some(Z.str8),
    text = Z.str16,
    time = Z.f64
});
v1.logsV0 = Z.schema({ v1.logV0 });
local u2 = {
    SEPARATE_DATASTORE = nil,
    canSave = nil,
    saveError = nil,
    initialize = nil,
    sizeBans = 0,
    sizeMain = 0,
    sizeLogs = 0,
    gameClosing = false,
    roles = nil,
    settingsModuleData = nil
};
local v3 = RunService:IsServer();

if v3 then
    if game.PrivateServerId == "" then
        v3 = false;
    else
        v3 = game.PrivateServerOwnerId ~= 0;
    end;
end;

u2.IS_PRIVATE_SERVER = v3;
u2.REMOVE = table.freeze({});
u2.Schema = v1;
u2.Sync = {
    bans = {},
    members = {},
    settings = {},
    logs = {}
};
u2.Migrate = {};
u2.creatorId = game.CreatorId;
u2.async = {
    asset = {},
    gamepass = {},
    group = {},
    subscription = {}
};
u2.bans = {};
u2.members = {};
u2.logs = {};
u2.reservedServers = {};
u2.servers = {};
u2.rolesList = {};
u2.logsHidden = {};
u2.playerPrefix = {};
u2.targetLimits = {};
u2.defaultSettings = {};
u2.savedSettings = {};
u2.settings = {
    announcement = false,
    useSavedSettings = true,
    splitKey = " ",
    commandBarRank = 0,
    dashboardRank = 0,
    commandsButtonRank = 0,
    dashboardButtonRank = 1,
    joinNotificationRank = 1,
    welcomeBadgeId = 0,
    addToCharts = true,
    vip = true,
    chatCommands = true,
    chatCommandsNotification = true,
    commandRequests = true,
    onlyShowUsableCommands = true,
    getKohlsAdminPopup = true,
    wrongPrefixWarning = true,
    saveLogs = true,
    saveChatLogs = false,
    saveLogsForAllRoles = false,
    theme = "Default",
    changeThemeAuthority = "Client",
    prefix = { ";", ":" }
};

function u2.filterRemove(p4: table) -- Line: 130
    -- upvalues: u2 (copy)
    for i, v in p4 do
        if v == u2.REMOVE then
            p4[i] = nil;
        elseif type(v) == "table" then
            u2.filterRemove(v);
        end;
    end;

    return p4;
end;

function u2.mergeRemove(p5: table, p6: table) -- Line: 141
    -- upvalues: u2 (copy)
    for i, v in p6 do
        local v7;

        if v == u2.REMOVE then
            v7 = nil;
        else
            v7 = v;
        end;

        p5[i] = v7;
    end;

    return p5;
end;

u2.Store = require(script.Parent:WaitForChild("Store"));

if game:GetService("RunService"):IsClient() then
    u2.Store = nil;
end;

for i, v in Theme do
    if i ~= "Themes" and v._value ~= nil then
        u2.settings["theme" .. i] = v._value;
    end;
end;

return u2;