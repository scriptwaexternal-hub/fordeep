-- Decompiled with Potassium's decompiler.

return function(p1) -- Line: 3
    if game.PlaceId == 18274376677 and p1.IsServer then
        table.insert(p1.Data.loaderSettings.freeAdmin, "admin");
    end;
end;