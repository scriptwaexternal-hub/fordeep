-- Decompiled with Potassium's decompiler.

local Parent = require(script.Parent.Parent);
local BaseClass = require(script.Parent:WaitForChild("BaseClass"));
local u1 = {
    Snap = 0,
    SnapSound = true,
    Value = 1,
    Vertical = false
};
local u2 = {};
u2.__index = u2;
setmetatable(u2, BaseClass);

function u2.new(p3) -- Line: 17
    -- upvalues: u1 (copy), Parent (copy), u2 (copy)
    local table_clone_ret = table.clone(u1);
    Parent.makeStatefulDefaults(table_clone_ret, p3);
    local v4 = {};
    local u5 = nil;
    local u6 = Parent.state(false);
    table_clone_ret._dragging = u6;
    local u9 = Parent.compute(function() -- Line: 27
        -- upvalues: table_clone_ret (copy)
        local v7 = table_clone_ret.Snap();
        local v8 = table_clone_ret.Value();

        if v7 > 1 then
            return math.max(0, v8 - 1) / (v7 - 1);
        end;

        return v8;
    end);
    table.insert(v4, u9);

    local function update(p10) -- Line: 35
        -- upvalues: u5 (ref), table_clone_ret (copy), Parent (ref)
        if not u5 then
            return;
        end;

        local v11;

        if table_clone_ret.Vertical._value then
            v11 = math.clamp((p10.Position.Y - table_clone_ret._instance.AbsolutePosition.Y - 12) / (table_clone_ret._instance.AbsoluteSize.Y - 24), 0, 1);
        else
            v11 = math.clamp((p10.Position.X - table_clone_ret._instance.AbsolutePosition.X - 12) / (table_clone_ret._instance.AbsoluteSize.X - 24), 0, 1);
        end;

        local _value = table_clone_ret.Snap._value;

        if _value > 1 then
            v11 = math.round(1 + v11 * (_value - 1));

            if table_clone_ret.SnapSound._value and table_clone_ret.Value._value ~= v11 then
                Parent.Sound.Hover02:Play();
            end;
        end;

        table_clone_ret.Value(v11, true);
    end;

    local function inputBegan(u12) -- Line: 56
        -- upvalues: Parent (ref), u5 (ref), u6 (copy), update (copy)
        if u12.UserInputType == Enum.UserInputType.MouseButton1 or u12.UserInputType == Enum.UserInputType.Touch then
            Parent.Sound.Hover03:Play();
            u5 = u12;
            u6(true);
            local u13 = nil;
            u13 = u12:GetPropertyChangedSignal("UserInputState"):Connect(function() -- Line: 65
                -- upvalues: u12 (copy), u13 (ref), u5 (ref), Parent (ref), u6 (ref)
                if u12.UserInputState == Enum.UserInputState.End then
                    u13:Disconnect();

                    if u5 == u12 then
                        Parent.Sound.Hover01:Play();
                        u5 = nil;
                        u6(false);
                    end;
                end;
            end);
            update(u12);
        end;
    end;

    table.insert(v4, Parent.UserInputService.InputChanged:Connect(update));
    table_clone_ret._slider = Parent.new("Frame")({
        Name = "Slider",
        AnchorPoint = Vector2.new(0.5, 0.5),
        BackgroundColor3 = Parent.Theme.SecondaryText,

        Position = function() -- Line: 85, Name: Position
            -- upvalues: table_clone_ret (copy), u9 (copy)
            if table_clone_ret.Vertical() then
                return UDim2.new(0.5, 0, u9(), 0);
            end;

            return UDim2.new(u9(), 0, 0.5, 0);
        end,

        Size = Parent.tween(function() -- Line: 88
            -- upvalues: Parent (ref), u6 (copy)
            local v14 = Parent.Theme.FontSize();
            local v15 = v14 / 2;

            if u6() then
                return UDim2.new(0, v14, 0, v14);
            end;

            return UDim2.new(0, v15, 0, v15);
        end, Parent.Theme.TweenOut),
        Parent.new("UICorner")({
            CornerRadius = Parent.Theme.CornerPadded
        }),
        InputBegan = inputBegan
    });
    local v16 = Parent.compute(function() -- Line: 101
        -- upvalues: Parent (ref)
        return UDim.new(0, Parent.Theme.FontSizeSmaller() + Parent.Theme.PaddingHalf().Offset);
    end);
    table.insert(v4, v16);
    table_clone_ret._instance = Parent.new("Frame")({
        Name = "Slider",
        Active = true,
        BackgroundColor3 = Parent.Theme.Secondary,
        BackgroundTransparency = Parent.Theme.TransparencyHeavy,

        Size = function() -- Line: 112, Name: Size
            -- upvalues: Parent (ref), table_clone_ret (copy)
            local v17 = Parent.Theme.FontSize() + Parent.Theme.Padding().Offset;

            if table_clone_ret.Vertical() then
                return UDim2.new(0, v17, 1, 0);
            end;

            return UDim2.new(1, 0, 0, v17);
        end,

        Parent.new("UICorner")({
            CornerRadius = Parent.Theme.CornerPadded
        }),
        Parent.new("Stroke")({}),
        Parent.new("Frame")({
            BackgroundTransparency = 1,
            Size = UDim2.new(1, 0, 1, 0),
            ZIndex = 2,
            Parent.new("UIPadding")({
                PaddingTop = v16,
                PaddingBottom = v16,
                PaddingLeft = v16,
                PaddingRight = v16
            }),
            table_clone_ret._slider
        }),
        Parent.new("Frame")({
            Name = "Filled",
            BackgroundColor3 = Parent.Theme.Secondary,
            BorderSizePixel = 0,

            Size = function() -- Line: 140, Name: Size
                -- upvalues: u9 (copy), Parent (ref), table_clone_ret (copy)
                local v18 = u9();
                local v19 = (Parent.Theme.FontSize() + Parent.Theme.Padding().Offset) * (1 - v18);

                if table_clone_ret.Vertical() then
                    return UDim2.new(1, 0, v18, v19);
                end;

                return UDim2.new(v18, v19, 1, 0);
            end,

            Parent.new("UICorner")({
                CornerRadius = Parent.Theme.CornerPadded
            })
        }),
        InputBegan = inputBegan,
        [Parent.Clean] = v4
    });

    return setmetatable(table_clone_ret, u2);
end;

return u2;