-- Decompiled with Potassium's decompiler.

local u1 = {
    Wishes = {
        {
            Id = "Zeni",
            Tier = 3,
            Text = "Wish for a fortune of Zeni"
        },
        {
            Id = "Karma",
            Tier = 3,
            Text = "Wish for your karma to be cleansed"
        },
        {
            Id = "Revive",
            Tier = 3,
            Text = "Wish to revive a player"
        },
        {
            Id = "Increase Height",
            Tier = 3,
            Text = "Wish to become taller"
        },
        {
            Id = "Decrease Height",
            Tier = 3,
            Text = "Wish to become shorter"
        },
        {
            Id = "Tail",
            Tier = 3,
            Text = "Wish to restore your tail"
        },
        {
            Id = "New Arm",
            Tier = 3,
            Text = "Wish for a new arm"
        },
        {
            Id = "Wipe",
            Tier = 3,
            Text = "Wish to erase your existence",
            Confirm = true
        },
        {
            Id = "Smart",
            Tier = 3,
            Text = "Wish to be smart"
        },
        {
            Id = "Summon All",
            Tier = 2,
            Text = "Wish to bring everyone to you"
        },
        {
            Id = "Style Reset",
            Tier = 2,
            Text = "Wish to forget your fighting style"
        },
        {
            Id = "Mortality",
            Tier = 2,
            Text = "Wish to be mortal"
        },
        {
            Id = "Stat Reset",
            Tier = 2,
            Text = "Wish for your stats to be reset"
        },
        {
            Id = "Intelligent",
            Tier = 2,
            Text = "Wish to be intelligent"
        },
        {
            Id = "Race",
            Tier = 1,
            Text = "Wish for a race change"
        },
        {
            Id = "Trait",
            Tier = 1,
            Text = "Wish for a trait change"
        },
        {
            Id = "Immortality",
            Tier = 1,
            Text = "Wish to be immortal"
        },
        {
            Id = "Increase Potential",
            Tier = 1,
            Text = "Wish to unlock your potential"
        },
        {
            Id = "Group Revive",
            Tier = 1,
            Text = "Wish to revive all the dead"
        },
        {
            Id = "Genius",
            Tier = 1,
            Text = "Wish to be a genius"
        },
        {
            Id = "Punisher Drive",
            Tier = 1,
            Dragon = "Porunga",
            Text = "Wish for the power of the Punisher Drive"
        },
        {
            Id = "Race Rerolls",
            Tier = 1,
            Dragon = "Porunga",
            Text = "Wish for 3 race rerolls"
        },
        {
            Id = "Trait Rerolls",
            Tier = 1,
            Dragon = "Porunga",
            Text = "Wish for 3 trait rerolls"
        }
    },
    ZeniByQuality = { 20000, 10000, 5000 },
    ReviveByQuality = { 4, 2, 2 },
    PorungaZeni = 30000
};

function u1.GetAvailable(p2, p3) -- Line: 71
    -- upvalues: u1 (copy)
    local v4 = tonumber(p2) or 3;
    local v5 = {};

    for i = 3, 1, -1 do
        local v6 = i;

        for _, v in ipairs(u1.Wishes) do
            if v.Tier == v6 and (v4 <= v6 and (v.Dragon == nil or v.Dragon == p3)) then
                table.insert(v5, v);
            end;
        end;
    end;

    return v5;
end;

function u1.GetAllowed(p7, p8, p9) -- Line: 87
    -- upvalues: u1 (copy)
    local v10 = tonumber(p8) or 3;

    for _, v in ipairs(u1.Wishes) do
        if v.Id == p7 then
            if v.Dragon ~= nil and v.Dragon ~= p9 then
                return nil, "dragon";
            end;

            if v10 <= v.Tier then
                return v;
            end;

            return nil, "tier";
        end;
    end;

    return nil, "unknown";
end;

return u1;