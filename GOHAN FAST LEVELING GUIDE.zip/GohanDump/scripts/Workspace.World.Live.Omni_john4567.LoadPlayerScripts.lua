-- Decompiled with Potassium's decompiler.

local Players = game:GetService("Players");
local ReplicatedStorage = game:GetService("ReplicatedStorage");
game:GetService("RunService");
game:GetService("Debris");
local Modules = ReplicatedStorage:WaitForChild("Modules");
local Remotes = ReplicatedStorage:WaitForChild("Remotes");
local _ = Modules.Metadata;
local _ = Modules.Shared;
local _ = Modules.Utility;
local _ = ReplicatedStorage.Assets;
local ScriptLoaderRemote = Remotes.ScriptLoaderRemote;
local LocalPlayer = Players.LocalPlayer;
local Humanoid = LocalPlayer.Character:FindFirstChild("Humanoid");
Humanoid:SetStateEnabled(Enum.HumanoidStateType.FallingDown, false);
Humanoid:SetStateEnabled(Enum.HumanoidStateType.GettingUp, true);
Humanoid:SetStateEnabled(Enum.HumanoidStateType.Ragdoll, false);

function ReplicatePlayerScripts()
    -- upvalues: LocalPlayer (copy)
    local PlayerScripts = LocalPlayer:WaitForChild("PlayerScripts");
    local RbxCharacterSounds = game.StarterPlayer.StarterPlayerScripts:FindFirstChild("RbxCharacterSounds");

    if RbxCharacterSounds then
        RbxCharacterSounds:Destroy();
    end;

    for _, child in pairs(game.StarterPlayer.StarterPlayerScripts:GetChildren()) do
        if child.Name ~= "PlayerScriptsLoader" and not PlayerScripts:FindFirstChild(child.Name) then
            child:Clone().Parent = PlayerScripts;
        end;
    end;
end;

ScriptLoaderRemote.OnClientEvent:Connect(ReplicatePlayerScripts);