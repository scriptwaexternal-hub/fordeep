-- Decompiled with Potassium's decompiler.

local Debris = game:GetService("Debris");
local ReplicatedStorage = game:GetService("ReplicatedStorage");
local Modules = ReplicatedStorage:WaitForChild("Modules");
local SoundManager = require(Modules.Shared.SoundManager);
local GlobalFunctions = require(Modules.GlobalFunctions);
local Visuals = workspace.World.Visuals;
local Meshes = ReplicatedStorage.Assets.Effects.Meshes;
local Color3_fromRGB_ret = Color3.fromRGB(66, 255, 79);

return {
    Start = function(p1) -- Line: 27
        -- upvalues: Meshes (copy), Color3_fromRGB_ret (copy), Visuals (copy), Debris (copy), SoundManager (copy), GlobalFunctions (copy)
        local Character = p1.Character;

        if not Character then
            return;
        end;

        local v2 = Character:FindFirstChild("Right Arm") or Character:FindFirstChild("HumanoidRootPart");

        if not v2 then
            return;
        end;

        local Beam = Meshes.Skills.Blasts["Eraser Cannon"].Beam;
        local u3 = Beam:Clone();
        u3.Name = "EraserCannon" .. Character.Name;
        u3.CFrame = v2.CFrame * CFrame.new(0, -2, -0.2);
        u3.Anchored = false;
        u3.Size = Vector3.new(0, 0, 0);
        u3.Transparency = 1;
        u3.Material = Enum.Material.Neon;
        u3.Color = Color3_fromRGB_ret;
        u3.Parent = Visuals;
        local u4 = Beam:Clone();
        u4.Name = "Effect";
        u4.CFrame = u3.CFrame;
        u4.Size = Vector3.new(100, 100, 100);
        u4.Transparency = 1;
        u4.Anchored = true;
        u4.Parent = Visuals;
        Debris:AddItem(u4, 5);
        local WeldConstraint = Instance.new("WeldConstraint");
        WeldConstraint.Part0 = u3;
        WeldConstraint.Part1 = v2;
        WeldConstraint.Parent = u3;
        SoundManager.AddSound("Beam Charge", {
            Parent = u3
        }, "Client");
        GlobalFunctions.Tween({
            Duration = 1,
            Instance = u4
        }, {
            Size = Vector3.new(0, 0, 0),
            Transparency = 0
        }).Completed:Once(function() -- Line: 66
            -- upvalues: GlobalFunctions (ref), u3 (copy), u4 (copy)
            GlobalFunctions.Tween({
                Duration = 0.5,
                Instance = u3
            }, {
                Size = Vector3.new(2, 2, 2),
                Transparency = 0
            });
            GlobalFunctions.TransparencyTween({
                Instance = u4
            });
        end);
        task.spawn(function() -- Line: 73
            -- upvalues: Character (copy), u3 (copy), WeldConstraint (copy), Debris (ref)
            while Character:FindFirstChild("Charging Beam") do
                if Character:FindFirstChild("Stun") then
                    u3:Destroy();

                    return;
                end;

                task.wait();
            end;

            WeldConstraint:Destroy();
            u3.Anchored = true;
            Debris:AddItem(u3, 10);
        end);
    end
};