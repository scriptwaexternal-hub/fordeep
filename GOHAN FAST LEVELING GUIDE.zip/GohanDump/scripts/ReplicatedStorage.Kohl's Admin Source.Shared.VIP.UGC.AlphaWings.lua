-- Decompiled with Potassium's decompiler.

local CollectionService = game:GetService("CollectionService");
local InsertService = game:GetService("InsertService");
local RunService = game:GetService("RunService");
local Parent = script.Parent.Parent.Parent.Parent;
local Flux = require(Parent:WaitForChild("Flux"));
local Util = require(Parent.Shared:WaitForChild("Util"));
local Oklab = Flux.Color.Oklab;
local Accessory = Instance.new("Accessory");
Accessory.AccessoryType = Enum.AccessoryType.Back;
Accessory.Name = "_KAlphaWings";
Accessory:AddTag("_KAlphaWings");
local Part = Instance.new("Part", Accessory);
Part.Name = "Handle";
Part.Transparency = 1;
Part.CanCollide = false;
Part.CanQuery = false;
Part.CanTouch = false;
Part.Massless = true;
Part.Locked = true;
local Attachment = Instance.new("Attachment", Part);
Attachment.CFrame = CFrame.new(0, -0.5, 0);
Attachment.Name = "BodyBackAttachment";
task.spawn(function() -- Line: 30
    -- upvalues: Util (copy), InsertService (copy), Accessory (copy), Part (copy)
    local v1, v2 = Util.Retry(function() -- Line: 31
        -- upvalues: InsertService (ref)
        return InsertService:CreateMeshPartAsync("rbxassetid://135389107063517", Enum.CollisionFidelity.Box, Enum.RenderFidelity.Precise);
    end);

    if not v1 then
        warn(v2);

        return;
    end;

    v2:AddTag("_KAlphaWings");
    v2.Parent = Accessory;
    v2.Name = "Wings";
    v2.Color = Color3.fromRGB(170, 170, 170);
    v2.CastShadow = false;
    v2.CanCollide = false;
    v2.CanQuery = false;
    v2.CanTouch = false;
    v2.Massless = true;
    v2.Locked = true;
    v2.Material = Enum.Material.Neon;
    v2:SetAttribute("OriginalSize", v2.Size);
    local Weld = Instance.new("Weld", v2);
    Weld.Part0 = Part;
    Weld.Part1 = v2;

    for _, child in require(script:WaitForChild("Bones")):GetChildren() do
        child:SetAttribute("OriginalCFrame", child.CFrame);
        child.Parent = v2;
    end;

    script:WaitForChild("Animate"):Clone().Parent = v2;
end);

if RunService:IsClient() then
    local u3 = {};
    RunService.Heartbeat:Connect(function() -- Line: 71
        -- upvalues: u3 (copy), Oklab (copy)
        if next(u3) then
            local toRGB = Oklab.toRGB;
            local fromHCL = Oklab.fromHCL;
            local v4 = time() / 10 % 1;
            local v5 = toRGB(fromHCL((Vector3.new(v4, 0.4, 1))));

            for i in u3 do
                if i and (i.Parent and i:FindFirstChild("Handle")) then
                    i.Wings.Color = v5;
                else
                    u3[i] = nil;
                end;
            end;
        end;
    end);
    CollectionService:GetInstanceAddedSignal("_KAlphaWingsRainbow"):Connect(function(p6) -- Line: 84
        -- upvalues: u3 (copy)
        u3[p6] = true;
    end);
    CollectionService:GetInstanceRemovedSignal("_KAlphaWingsRainbow"):Connect(function(p7) -- Line: 87
        -- upvalues: u3 (copy)
        u3[p7] = nil;
    end);

    for _, v in CollectionService:GetTagged("_KAlphaWingsRainbow") do
        u3[v] = true;
    end;
end;

local u8 = {
    dark = Color3.new(),
    gold = Color3.fromRGB(170, 125, 0)
};

return {
    MatchId = "rbxassetid://89119211625300",
    Name = Accessory.Name,

    Method = function(p9: userdata, p10: userdata) -- Line: 103, Name: Method
        -- upvalues: u8 (copy), Accessory (copy)
        local v11 = nil;

        if p10 then
            if typeof(p10) == "Instance" then
                local Handle = p10:FindFirstChild("Handle");

                if Handle:IsA("MeshPart") then
                    if string.find(Handle.TextureID, "74391200400192") then
                        v11 = u8.dark;
                    elseif string.find(Handle.TextureID, "115319077247149") then
                        v11 = u8.gold;
                    end;
                end;

                p10:Destroy();
            elseif typeof(p10) == "string" then
                for i, v in u8 do
                    if string.find(string.lower(p10), i, 1, true) then
                        v11 = v;
                        break;
                    end;
                end;
            end;
        end;

        local v12 = p9:FindFirstChild(Accessory.Name);

        if v12 then
            v12:Destroy();
        end;

        local v13 = Accessory:Clone();

        if v13:FindFirstChild("Wings") then
            if v11 then
                v13:SetAttribute("_KWingsColor", v11);
                v13.Wings.Color = v11;
            end;

            v13.Wings.Animate.Enabled = true;
        end;

        v13.Parent = p9;

        return v13;
    end
};