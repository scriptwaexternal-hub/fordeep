-- Decompiled with Potassium's decompiler.

local Players = game:GetService("Players");
game:GetService("Debris");
local ReplicatedStorage = game:GetService("ReplicatedStorage");
game:GetService("RunService");
game:GetService("CollectionService");
game:GetService("UserInputService");
local Modules = ReplicatedStorage:WaitForChild("Modules");
ReplicatedStorage:WaitForChild("Remotes");
local Assets = ReplicatedStorage.Assets;
local _ = Modules.Metadata;
local _ = Modules.Utility;
local LocalPlayer = Players.LocalPlayer;
require(Modules.Shared.SoundManager);
local GlobalFunctions = require(Modules.GlobalFunctions);
local _ = workspace.World.Visuals;
local LSSJ = Assets.Gui.Transformation.LSSJ;
local _ = Assets.Sounds;
local _ = Assets.Effects.Particles;
local u1 = {};
local u2 = {};

function AddHighlight(p3)
    -- upvalues: LSSJ (copy)
    LSSJ["Enraged Highlight"]:Clone().Parent = p3;
end;

function RemoveHighlight(p4)
    -- upvalues: GlobalFunctions (copy)
    GlobalFunctions.RemoveValue(p4, "Enraged Highlight");
end;

function u2.Fire(p5) -- Line: 55
    -- upvalues: LocalPlayer (copy)
    require(LocalPlayer.PlayerScripts.PlayerModule):GetControls():Disable();
    AddHighlight(LocalPlayer.Character);
end;

function u2.Off(p6) -- Line: 67
    -- upvalues: LocalPlayer (copy)
    require(LocalPlayer.PlayerScripts.PlayerModule):GetControls():Enable();
    RemoveHighlight(LocalPlayer.Character);
end;

function u2.AddGui(p7) -- Line: 80
    -- upvalues: Players (copy), u2 (copy), LSSJ (copy), u1 (copy)
    local Character = p7.Character;
    local v8 = p7.GuiName or "EnragedGui";
    local v9 = Players:GetPlayerFromCharacter(Character):FindFirstChild("PlayerStats"):FindFirstChild(p7.ValueName or "Rage", true);

    if not v9 then
        return;
    end;

    u2.GuiRemove({
        Character = Character,
        GuiName = v8
    });
    local u10 = v9.Value / 100;
    local u11 = LSSJ.EnragedGui:Clone();
    u11.Name = v8;

    if typeof(p7.Color) == "Color3" then
        u11.Meter.Bar.BackgroundColor3 = p7.Color;
    end;

    u11.Parent = Character;
    u11.Meter.Bar:TweenSize(UDim2.new(u10, 0, 1, 0), "Out", "Sine", 0.1, true);
    local u12 = nil;
    u12 = v9.Changed:Connect(function(p13) -- Line: 101
        -- upvalues: u11 (copy), u12 (ref), u10 (ref)
        if u11.Parent == nil then
            u12:Disconnect();

            return;
        end;

        u10 = p13 / 100;
        u11.Meter.Bar:TweenSize(UDim2.new(u10, 0, 1, 0), "Out", "Sine", 0.1, true);
    end);
    u1[v8] = u1[v8] or {};
    table.insert(u1[v8], u12);
end;

function u2.GuiRemove(p14) -- Line: 111
    -- upvalues: u1 (copy), GlobalFunctions (copy)
    local Character = p14.Character;
    local v15 = p14.GuiName or "EnragedGui";

    for _, v in pairs(u1[v15] or {}) do
        v:Disconnect();
    end;

    u1[v15] = nil;

    if Character then
        GlobalFunctions.RemoveValue(Character, v15);
    end;
end;

function u2.AddHighlight(p16) -- Line: 123
    -- upvalues: LSSJ (copy)
    local Character = p16.Character;

    if not Character then
        return;
    end;

    local v17 = tonumber(p16.FillTransparency);
    local v18 = tonumber(p16.Duration);

    if not (v17 or v18) then
        AddHighlight(Character);

        return;
    end;

    local v19 = Character:FindFirstChild("Enraged Highlight");

    if v19 then
        v19:Destroy();
    end;

    local u20 = LSSJ["Enraged Highlight"]:Clone();

    if v17 then
        u20.FillTransparency = v17;
    end;

    u20.Parent = Character;

    if v18 then
        task.delay(v18, function() -- Line: 136
            -- upvalues: u20 (copy)
            if u20.Parent then
                game:GetService("TweenService"):Create(u20, TweenInfo.new(0.4), {
                    FillTransparency = 1,
                    OutlineTransparency = 1
                }):Play();
                task.delay(0.4, function() -- Line: 140
                    -- upvalues: u20 (ref)
                    if u20.Parent then
                        u20:Destroy();
                    end;
                end);
            end;
        end);
    end;
end;

function u2.RemoveHighlight(p21) -- Line: 149
    RemoveHighlight(p21.Character);
end;

return u2;