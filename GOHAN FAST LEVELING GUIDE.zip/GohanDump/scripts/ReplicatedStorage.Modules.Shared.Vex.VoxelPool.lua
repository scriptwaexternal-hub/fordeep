-- Decompiled with Potassium's decompiler.

local v1 = {};
local u2 = {};
local u3 = 0;

local function getContainer() -- Line: 22
    local VoxelDebris = workspace:FindFirstChild("VoxelDebris");

    if not VoxelDebris then
        VoxelDebris = Instance.new("Folder");
        VoxelDebris.Name = "VoxelDebris";
        VoxelDebris.Parent = workspace;
    end;

    return VoxelDebris;
end;

local function createKey(p4, p5, p6) -- Line: 35
    return string.format("%.1f_%.1f_%.1f_%s_%d_%d_%d", p4.X, p4.Y, p4.Z, tostring(p5), math.floor(p6.R * 255), math.floor(p6.G * 255), (math.floor(p6.B * 255)));
end;

function v1.get(p7, p8, p9, p10) -- Line: 46
    -- upvalues: u2 (ref), u3 (ref)
    local string_format_ret = string.format("%.1f_%.1f_%.1f_%s_%d_%d_%d", p7.X, p7.Y, p7.Z, tostring(p8), math.floor(p9.R * 255), math.floor(p9.G * 255), (math.floor(p9.B * 255)));

    if u2[string_format_ret] and #u2[string_format_ret] > 0 then
        local table_remove_ret = table.remove(u2[string_format_ret]);
        table_remove_ret.Anchored = false;
        table_remove_ret.CanCollide = true;
        table_remove_ret.Transparency = 0;
        local VoxelDebris = workspace:FindFirstChild("VoxelDebris");

        if not VoxelDebris then
            VoxelDebris = Instance.new("Folder");
            VoxelDebris.Name = "VoxelDebris";
            VoxelDebris.Parent = workspace;
        end;

        table_remove_ret.Parent = VoxelDebris;
        u3 = u3 + 1;

        return table_remove_ret;
    end;

    local Part = Instance.new("Part");
    Part.Size = p7;
    Part.Material = p8;
    Part.Color = p9;
    Part.TopSurface = Enum.SurfaceType.Smooth;
    Part.BottomSurface = Enum.SurfaceType.Smooth;
    Part.Anchored = false;
    Part.CanCollide = true;
    local VoxelDebris = workspace:FindFirstChild("VoxelDebris");

    if not VoxelDebris then
        VoxelDebris = Instance.new("Folder");
        VoxelDebris.Name = "VoxelDebris";
        VoxelDebris.Parent = workspace;
    end;

    Part.Parent = VoxelDebris;

    if p10 then
        Part.CollisionGroup = p10;
    end;

    u3 = u3 + 1;

    return Part;
end;

function v1.release(p11) -- Line: 80
    -- upvalues: u2 (ref), u3 (ref)
    if not (p11 and p11:IsA("BasePart")) then
        return;
    end;

    local Size = p11.Size;
    local Color = p11.Color;
    local string_format_ret = string.format("%.1f_%.1f_%.1f_%s_%d_%d_%d", Size.X, Size.Y, Size.Z, tostring(p11.Material), math.floor(Color.R * 255), math.floor(Color.G * 255), (math.floor(Color.B * 255)));

    if not u2[string_format_ret] then
        u2[string_format_ret] = {};
    end;

    if #u2[string_format_ret] >= 1000 then
        p11:Destroy();
        u3 = math.max(0, u3 - 1);

        return;
    end;

    for _, child in ipairs(p11:GetChildren()) do
        if child:IsA("WeldConstraint") or child:IsA("Weld") then
            child:Destroy();
        end;
    end;

    p11.Parent = nil;
    p11.CFrame = CFrame.new(0, -10000, 0);
    p11.Anchored = true;
    p11.CanCollide = false;
    p11.Velocity = Vector3.new(0, 0, 0);
    p11.RotVelocity = Vector3.new(0, 0, 0);
    table.insert(u2[string_format_ret], p11);
    u3 = math.max(0, u3 - 1);
end;

function v1.clear() -- Line: 115
    -- upvalues: u2 (ref), u3 (ref)
    for _, v in pairs(u2) do
        for _, v2 in ipairs(v) do
            if v2 and v2:IsA("Instance") then
                v2:Destroy();
            end;
        end;
    end;

    u2 = {};
    u3 = 0;
end;

function v1.getStats() -- Line: 129
    -- upvalues: u2 (ref), u3 (ref)
    local v12 = 0;

    for _, v in pairs(u2) do
        v12 = v12 + #v;
    end;

    return {
        active = u3,
        pooled = v12,
        total = u3 + v12
    };
end;

return v1;