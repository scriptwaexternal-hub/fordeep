-- Decompiled with Potassium's decompiler.

local Players = game:GetService("Players");
local Debris = game:GetService("Debris");
local ReplicatedStorage = game:GetService("ReplicatedStorage");
local RunService = game:GetService("RunService");
local ContextActionService = game:GetService("ContextActionService");
local TweenService = game:GetService("TweenService");
local UserInputService = game:GetService("UserInputService");
local Assets = ReplicatedStorage.Assets;
local Modules = ReplicatedStorage:WaitForChild("Modules");
local Remotes = ReplicatedStorage:WaitForChild("Remotes");
local TouchActionRemote = Remotes:WaitForChild("TouchActionRemote");
local Shared = Modules.Shared;
local SoundManager = require(Shared.SoundManager);
local GlobalFunctions = require(Modules.GlobalFunctions);
local CinemaManager = require(Shared.CinemaManager);
local ClashRemote = Remotes.ClashRemote;
local LocalPlayer = Players.LocalPlayer;
local workspace_CurrentCamera = workspace.CurrentCamera;
local Visuals = workspace.World.Visuals;
local Particles = Assets.Effects.Particles;
local u1 = { "W", "A", "S", "D" };
local u2 = { 0, 140, -140, 70, -70, 180 };
local u3 = {
    Enum.KeyCode.W,
    Enum.KeyCode.A,
    Enum.KeyCode.S,
    Enum.KeyCode.D,
    Enum.KeyCode.X,
    Enum.KeyCode.F,
    Enum.KeyCode.Space,
    Enum.KeyCode.ButtonY,
    Enum.KeyCode.ButtonX,
    Enum.KeyCode.ButtonA,
    Enum.KeyCode.ButtonB
};
local u4 = {
    ButtonY = "W",
    ButtonX = "A",
    ButtonA = "S",
    ButtonB = "D"
};
local u5 = {
    W = "Y",
    A = "X",
    S = "A",
    D = "B"
};

local function gamepadActive() -- Line: 97
    -- upvalues: UserInputService (copy)
    return UserInputService:GetLastInputType().Name:find("Gamepad") ~= nil;
end;

local Color3_fromRGB_ret = Color3.fromRGB(245, 245, 245);
local Color3_fromRGB_ret2 = Color3.fromRGB(255, 90, 90);
local Color3_fromRGB_ret3 = Color3.fromRGB(80, 220, 120);
local TweenInfo_new_ret = TweenInfo.new(0.15, Enum.EasingStyle.Quad, Enum.EasingDirection.Out);
local u6 = UserInputService.TouchEnabled and not UserInputService.KeyboardEnabled;
local u7 = nil;
local u8 = nil;
local u9 = false;

local function getHUD() -- Line: 133
    -- upvalues: LocalPlayer (copy)
    local ClashGui = LocalPlayer.PlayerGui:FindFirstChild("ClashGui");

    if ClashGui then
        ClashGui = ClashGui:FindFirstChild("ClashHUD");
    end;

    return ClashGui;
end;

local function stopCamera() -- Line: 138
    -- upvalues: u7 (ref), workspace_CurrentCamera (copy), LocalPlayer (copy)
    if u7 then
        if u7.camConn then
            u7.camConn:Disconnect();
            u7.camConn = nil;
        end;

        if u7.camThread then
            pcall(task.cancel, u7.camThread);
            u7.camThread = nil;
        end;

        if u7.camTween then
            pcall(function() -- Line: 149
                -- upvalues: u7 (ref)
                u7.camTween:Cancel();
            end);
            u7.camTween = nil;
        end;
    end;

    workspace_CurrentCamera.CameraType = Enum.CameraType.Custom;
    local Character = LocalPlayer.Character;

    if Character then
        Character = Character:FindFirstChildOfClass("Humanoid");
    end;

    if Character then
        workspace_CurrentCamera.CameraSubject = Character;
    end;
end;

local function punchCut(p10) -- Line: 172
    -- upvalues: u7 (ref), workspace_CurrentCamera (copy), LocalPlayer (copy), u2 (copy), TweenService (copy)
    if not u7 then
        return;
    end;

    workspace_CurrentCamera.CameraType = Enum.CameraType.Scriptable;
    local v11 = LocalPlayer.Character and LocalPlayer.Character:FindFirstChild("HumanoidRootPart");
    local opponent = u7.opponent;

    if opponent then
        opponent = opponent:FindFirstChild("HumanoidRootPart");
    end;

    local v12 = v11 and (opponent and opponent.Position - v11.Position) or Vector3.new(1, 0, 0);
    local Vector3_new_ret = Vector3.new(v12.X, 0, v12.Z);
    local v13 = Vector3_new_ret.Magnitude > 0.05 and Vector3_new_ret.Unit or Vector3.new(1, 0, 0);
    local v14 = math.atan2(v13.Z, v13.X) + 1.5707963267948966;
    u7.cutIndex = (u7.cutIndex or 0) + 1;
    local v15 = u2[(u7.cutIndex - 1) % #u2 + 1] + math.random(-15, 15);
    local v16 = v14 + math.rad(v15);
    local math_random_ret = math.random(16, 30);
    local math_random_ret2 = math.random(2, 12);
    local v17 = math.cos(v16) * math_random_ret;
    local v18 = math.sin(v16) * math_random_ret;
    local v19 = p10 + Vector3.new(v17, math_random_ret2, v18);

    if u7.camTween then
        pcall(function() -- Line: 193
            -- upvalues: u7 (ref)
            u7.camTween:Cancel();
        end);
    end;

    u7.camTween = TweenService:Create(workspace_CurrentCamera, TweenInfo.new(0.12, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
        CFrame = CFrame.lookAt(v19, p10 + Vector3.new(0, 2, 0))
    });
    u7.camTween:Play();
end;

local function endSession() -- Line: 200
    -- upvalues: u7 (ref), stopCamera (copy), u8 (ref), ContextActionService (copy), LocalPlayer (copy)
    if not u7 then
        return;
    end;

    stopCamera();
    u8();
    pcall(ContextActionService.UnbindAction, ContextActionService, "ClashInputSink");
    local ClashGui = LocalPlayer.PlayerGui:FindFirstChild("ClashGui");

    if ClashGui then
        ClashGui = ClashGui:FindFirstChild("ClashHUD");
    end;

    if ClashGui then
        ClashGui.KeyPrompt.Visible = false;
        ClashGui.Visible = false;
    end;

    u7 = nil;
end;

local function updateBar(p20, p21, p22) -- Line: 213
    -- upvalues: LocalPlayer (copy), TweenService (copy), TweenInfo_new_ret (copy)
    local ClashGui = LocalPlayer.PlayerGui:FindFirstChild("ClashGui");

    if ClashGui then
        ClashGui = ClashGui:FindFirstChild("ClashHUD");
    end;

    if not ClashGui then
        return;
    end;

    local v23 = p20 + p21;
    local v24 = v23 > 0 and p20 / v23 or 0.5;
    local TugBar = ClashGui.TugBar;
    TweenService:Create(TugBar.PlayerFill, TweenInfo_new_ret, {
        Size = UDim2.fromScale(v24, 1)
    }):Play();
    TweenService:Create(TugBar.EnemyFill, TweenInfo_new_ret, {
        Size = UDim2.fromScale(1 - v24, 1)
    }):Play();
    TweenService:Create(TugBar.Divider, TweenInfo_new_ret, {
        Position = UDim2.fromScale(v24, 0.5)
    }):Play();
    local math_round_ret = math.round(v24 * 100);
    ClashGui.PlayerTag.Text = string.format("%s  %d%%", LocalPlayer.Name, math_round_ret);
    ClashGui.EnemyTag.Text = string.format("%d%%  %s", 100 - math_round_ret, p22 or "Enemy");
end;

local function setCapFeedback(p25, p26) -- Line: 233
    -- upvalues: Color3_fromRGB_ret (copy)
    local KeyPrompt = p25.KeyPrompt;
    KeyPrompt.Letter.TextColor3 = p26;
    local v27 = KeyPrompt:FindFirstChildOfClass("UIStroke");

    if v27 then
        if p26 == Color3_fromRGB_ret then
            v27.Color = Color3_fromRGB_ret;
            v27.Transparency = 0.55;

            return;
        end;

        v27.Color = p26;
        v27.Transparency = 0;
    end;
end;

local function rollLetter() -- Line: 250
    -- upvalues: LocalPlayer (copy), u7 (ref), u1 (copy), UserInputService (copy), u5 (copy), Color3_fromRGB_ret (copy)
    local ClashGui = LocalPlayer.PlayerGui:FindFirstChild("ClashGui");

    if ClashGui then
        ClashGui = ClashGui:FindFirstChild("ClashHUD");
    end;

    if not (ClashGui and u7) then
        return;
    end;

    local v28;

    repeat
        v28 = u1[math.random(1, #u1)];
    until v28 ~= u7.letter;

    u7.letter = v28;
    local Letter = ClashGui.KeyPrompt.Letter;

    if UserInputService:GetLastInputType().Name:find("Gamepad") ~= nil then
        v28 = u5[v28] or v28;
    end;

    Letter.Text = v28;
    local v29 = Color3_fromRGB_ret;
    local KeyPrompt = ClashGui.KeyPrompt;
    KeyPrompt.Letter.TextColor3 = v29;
    local v30 = KeyPrompt:FindFirstChildOfClass("UIStroke");

    if v30 then
        if v29 == Color3_fromRGB_ret then
            v30.Color = Color3_fromRGB_ret;
            v30.Transparency = 0.55;

            return;
        end;

        v30.Color = v29;
        v30.Transparency = 0;
    end;
end;

local function handleKeyPress(p31) -- Line: 265
    -- upvalues: u7 (ref), LocalPlayer (copy), ClashRemote (copy), Color3_fromRGB_ret3 (copy), Color3_fromRGB_ret (copy), SoundManager (copy), workspace_CurrentCamera (copy), rollLetter (copy), u1 (copy), Color3_fromRGB_ret2 (copy)
    if not (u7 and (u7.roundActive and u7.canGuess)) then
        return;
    end;

    local ClashGui = LocalPlayer.PlayerGui:FindFirstChild("ClashGui");

    if ClashGui then
        ClashGui = ClashGui:FindFirstChild("ClashHUD");
    end;

    if not ClashGui then
        return;
    end;

    if p31 ~= u7.letter then
        if table.find(u1, p31) then
            u7.canGuess = false;
            local v32 = Color3_fromRGB_ret2;
            local KeyPrompt = ClashGui.KeyPrompt;
            KeyPrompt.Letter.TextColor3 = v32;
            local v33 = KeyPrompt:FindFirstChildOfClass("UIStroke");

            if v33 then
                if v32 == Color3_fromRGB_ret then
                    v33.Color = Color3_fromRGB_ret;
                    v33.Transparency = 0.55;
                else
                    v33.Color = v32;
                    v33.Transparency = 0;
                end;
            end;

            task.delay(0.2, function() -- Line: 285
                -- upvalues: u7 (ref), ClashGui (copy), Color3_fromRGB_ret (ref)
                if u7 then
                    local v34 = Color3_fromRGB_ret;
                    local KeyPrompt2 = ClashGui.KeyPrompt;
                    KeyPrompt2.Letter.TextColor3 = v34;
                    local v35 = KeyPrompt2:FindFirstChildOfClass("UIStroke");

                    if v35 then
                        if v34 == Color3_fromRGB_ret then
                            v35.Color = Color3_fromRGB_ret;
                            v35.Transparency = 0.55;
                        else
                            v35.Color = v34;
                            v35.Transparency = 0;
                        end;
                    end;

                    u7.canGuess = true;
                end;
            end);
        end;

        return;
    end;

    u7.canGuess = false;
    ClashRemote:FireServer();
    local v36 = Color3_fromRGB_ret3;
    local KeyPrompt = ClashGui.KeyPrompt;
    KeyPrompt.Letter.TextColor3 = v36;
    local v37 = KeyPrompt:FindFirstChildOfClass("UIStroke");

    if v37 then
        if v36 == Color3_fromRGB_ret then
            v37.Color = Color3_fromRGB_ret;
            v37.Transparency = 0.55;
        else
            v37.Color = v36;
            v37.Transparency = 0;
        end;
    end;

    SoundManager.AddSound("Osu Hit", {
        Parent = workspace_CurrentCamera
    }, "Client");
    task.delay(0.1, function() -- Line: 275
        -- upvalues: u7 (ref), rollLetter (ref)
        if u7 and u7.roundActive then
            rollLetter();
            u7.canGuess = true;
        end;
    end);
end;

local function bindMobilePad() -- Line: 299
    -- upvalues: u6 (copy), u7 (ref), LocalPlayer (copy), u9 (ref), TouchActionRemote (copy), handleKeyPress (copy)
    if not (u6 and u7) then
        return;
    end;

    local ClashGui = LocalPlayer.PlayerGui:FindFirstChild("ClashGui");

    if ClashGui then
        ClashGui = ClashGui:FindFirstChild("ClashHUD");
    end;

    if ClashGui then
        ClashGui = ClashGui:FindFirstChild("MobilePad");
    end;

    if not ClashGui then
        warn("[ClashVFX] ClashHUD.MobilePad missing -- mobile cannot clash");

        return;
    end;

    if not u9 then
        u9 = true;
        TouchActionRemote:Fire("TouchPad", "EventFocus", true);
    end;

    u7.padConns = {};

    for _, child in ipairs(ClashGui:GetChildren()) do
        if child:IsA("TextButton") then
            local Name = child.Name;
            table.insert(u7.padConns, child.Activated:Connect(function() -- Line: 319
                -- upvalues: handleKeyPress (ref), Name (copy)
                handleKeyPress(Name);
            end));
        end;
    end;

    ClashGui.Visible = true;
end;

u8 = function() -- Line: 327, Name: unbindMobilePad
    -- upvalues: u7 (ref), LocalPlayer (copy), u9 (ref), TouchActionRemote (copy)
    if u7 and u7.padConns then
        for _, v in ipairs(u7.padConns) do
            pcall(function() -- Line: 330
                -- upvalues: v (copy)
                v:Disconnect();
            end);
        end;

        u7.padConns = nil;
    end;

    local ClashGui = LocalPlayer.PlayerGui:FindFirstChild("ClashGui");

    if ClashGui then
        ClashGui = ClashGui:FindFirstChild("ClashHUD");
    end;

    if ClashGui then
        ClashGui = ClashGui:FindFirstChild("MobilePad");
    end;

    if ClashGui then
        ClashGui.Visible = false;
    end;

    if u9 then
        u9 = false;
        TouchActionRemote:Fire("TouchPad", "EventFocus", false);
    end;
end;

return {
    ["Start Clash"] = function(p38) -- Line: 347
        -- upvalues: u7 (ref), stopCamera (copy), u8 (ref), ContextActionService (copy), LocalPlayer (copy), CinemaManager (copy), handleKeyPress (copy), u4 (copy), u3 (copy), updateBar (copy), bindMobilePad (copy)
        if u7 then
            stopCamera();
            u8();
            pcall(ContextActionService.UnbindAction, ContextActionService, "ClashInputSink");
            local ClashGui = LocalPlayer.PlayerGui:FindFirstChild("ClashGui");

            if ClashGui then
                ClashGui = ClashGui:FindFirstChild("ClashHUD");
            end;

            if ClashGui then
                ClashGui.KeyPrompt.Visible = false;
                ClashGui.Visible = false;
            end;

            u7 = nil;
        end;

        u7 = {
            opponentName = p38.Opponent and (p38.Opponent.Name or "Enemy") or "Enemy",
            opponent = p38.Opponent
        };
        CinemaManager.FadeIn(LocalPlayer, 0.3);
        ContextActionService:BindActionAtPriority("ClashInputSink", function(p39, p40, p41) -- Line: 357
            -- upvalues: handleKeyPress (ref), u4 (ref)
            if p40 == Enum.UserInputState.Begin then
                handleKeyPress(u4[p41.KeyCode.Name] or p41.KeyCode.Name);
            end;

            return Enum.ContextActionResult.Sink;
        end, false, Enum.ContextActionPriority.High.Value + 500, table.unpack(u3));
        local ClashGui = LocalPlayer.PlayerGui:FindFirstChild("ClashGui");

        if ClashGui then
            ClashGui = ClashGui:FindFirstChild("ClashHUD");
        end;

        if ClashGui then
            ClashGui.Parent.Enabled = true;
            ClashGui.KeyPrompt.Visible = false;
            updateBar(0, 0, u7.opponentName);
            ClashGui.Visible = true;
        end;

        bindMobilePad();
    end,

    Round = function(p42) -- Line: 377
        -- upvalues: u7 (ref), LocalPlayer (copy), rollLetter (copy)
        if not u7 then
            return;
        end;

        local v43 = p42.Duration or 3;
        local ClashGui = LocalPlayer.PlayerGui:FindFirstChild("ClashGui");

        if ClashGui then
            ClashGui = ClashGui:FindFirstChild("ClashHUD");
        end;

        if not ClashGui then
            return;
        end;

        u7.letter = nil;
        rollLetter();
        ClashGui.KeyPrompt.Visible = true;
        u7.roundActive = true;
        u7.canGuess = true;
        task.delay(v43, function() -- Line: 389
            -- upvalues: u7 (ref), LocalPlayer (ref)
            if u7 then
                u7.roundActive = false;
            end;

            local ClashGui2 = LocalPlayer.PlayerGui:FindFirstChild("ClashGui");

            if ClashGui2 then
                ClashGui2 = ClashGui2:FindFirstChild("ClashHUD");
            end;

            if ClashGui2 then
                ClashGui2.KeyPrompt.Visible = false;
            end;
        end);
    end,

    Points = function(p44) -- Line: 398
        -- upvalues: u7 (ref), LocalPlayer (copy), updateBar (copy)
        if not u7 then
            return;
        end;

        if LocalPlayer.Character == p44.CharacterA then
            updateBar(p44.PointsA or 0, p44.PointsB or 0, u7.opponentName);

            return;
        end;

        updateBar(p44.PointsB or 0, p44.PointsA or 0, u7.opponentName);
    end,

    Camera = function(p45) -- Line: 408
        -- upvalues: u7 (ref), stopCamera (copy), workspace_CurrentCamera (copy), u2 (copy), punchCut (copy)
        if not u7 then
            return;
        end;

        local Location = p45.Location;

        if not Location then
            return;
        end;

        stopCamera();
        workspace_CurrentCamera.CameraType = Enum.CameraType.Scriptable;
        u7.clashCenter = Location.Position;
        u7.cutIndex = math.random(0, #u2 - 1);
        punchCut(Location.Position);
    end,

    ["Winner Cam"] = function(p46) -- Line: 423
        -- upvalues: u7 (ref), stopCamera (copy), workspace_CurrentCamera (copy), RunService (copy)
        local Winner = p46.Winner;
        local Loser = p46.Loser;
        local u47 = p46.Duration or 2;

        if Winner then
            Winner = Winner:FindFirstChild("HumanoidRootPart");
        end;

        if Loser then
            Loser = Loser:FindFirstChild("HumanoidRootPart");
        end;

        if not (Winner and Loser) then
            return;
        end;

        if u7 then
            stopCamera();
        end;

        workspace_CurrentCamera.CameraType = Enum.CameraType.Scriptable;
        local v48 = (Winner.Position - Loser.Position):Cross(Vector3.new(0, 1, 0));
        local u49 = v48.Magnitude > 0.01 and v48.Unit or Vector3.new(0, 0, 1);
        local os_clock_ret = os.clock();
        local u50 = nil;
        u50 = RunService.RenderStepped:Connect(function() -- Line: 442
            -- upvalues: Winner (copy), Loser (copy), u50 (ref), os_clock_ret (copy), u47 (copy), workspace_CurrentCamera (ref), u49 (ref)
            if not (Winner.Parent and Loser.Parent) then
                u50:Disconnect();

                return;
            end;

            local v51 = (os.clock() - os_clock_ret) / u47;
            local math_clamp_ret = math.clamp(v51, 0, 1);
            local v52 = 1 - (1 - math_clamp_ret) ^ 3;
            local v53 = (Winner.Position + Loser.Position) / 2;
            workspace_CurrentCamera.CFrame = CFrame.lookAt(v53 + u49 * (v52 * -8 + 16) + Vector3.new(0, 3 - v52 * 1.5, 0), v53);

            if math_clamp_ret >= 1 then
                u50:Disconnect();
            end;
        end);

        if u7 then
            u7.camConn = u50;
        end;
    end,

    Effect = function(p54) -- Line: 461
        -- upvalues: SoundManager (copy), u7 (ref), punchCut (copy), Particles (copy), Visuals (copy), Debris (copy), GlobalFunctions (copy)
        local Center = p54.Center;

        if not (Center and Center.Parent) then
            return;
        end;

        local v55 = (p54.Clash_Wait or 3) / 4;

        for i = 1, 4 do
            if not Center.Parent then
                break;
            end;

            SoundManager.AddSound("Heavy_Punch", {
                Parent = Center,
                PlaybackSpeed = math.random(8, 15) / 10
            }, "Client");

            if u7 and u7.clashCenter then
                punchCut(Center.Position);
            end;

            local math_random_ret = math.random(-5, 5);
            local math_random_ret2 = math.random(-5, 5);
            local math_random_ret3 = math.random(-5, 5);
            local v56 = Particles.Clash_Part:Clone();
            v56.CFrame = Center.CFrame * CFrame.new(math_random_ret, math_random_ret2, math_random_ret3);
            v56.Parent = Visuals;
            Debris:AddItem(v56, 5);
            local v57 = Particles.Clash_PFX:Clone();
            v57.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(0.2, 30), NumberSequenceKeypoint.new(1, 30) });
            v57.Parent = v56;
            v57:Emit(1);
            GlobalFunctions.Tween({
                Duration = 1.5,
                Instance = v56,
                EasingStyle = Enum.EasingStyle.Exponential
            }, {
                Size = Vector3.new(100, 100, 100),
                Transparency = 1,
                CFrame = v56.CFrame * CFrame.Angles(math.rad(math_random_ret), math.rad(math_random_ret2), (math.rad(math_random_ret3)))
            });
            task.wait(v55);
            local _ = i;
        end;
    end,

    ["Win Effect"] = function(p58) -- Line: 515
        -- upvalues: SoundManager (copy), Particles (copy), Visuals (copy), Debris (copy)
        local Victim = p58.Victim;

        if not (p58.Character and Victim) then
            return;
        end;

        local HumanoidRootPart = Victim:FindFirstChild("HumanoidRootPart");

        if not HumanoidRootPart then
            return;
        end;

        SoundManager.AddSound("Punch", {
            Parent = HumanoidRootPart,
            PlaybackSpeed = math.random(90, 150) / 100
        }, "Client");
        local v59 = Particles.HitEffect:Clone();
        v59.CFrame = HumanoidRootPart.CFrame;
        v59.Parent = Visuals;
        v59.Attachment.Hit1:Emit(100);
        v59.Attachment.Hit2:Emit(1);
        Debris:AddItem(v59, 3);
    end,

    Reset = function(p60) -- Line: 533
        -- upvalues: u7 (ref), stopCamera (copy), u8 (ref), ContextActionService (copy), LocalPlayer (copy), CinemaManager (copy)
        if u7 then
            stopCamera();
            u8();
            pcall(ContextActionService.UnbindAction, ContextActionService, "ClashInputSink");
            local ClashGui = LocalPlayer.PlayerGui:FindFirstChild("ClashGui");

            if ClashGui then
                ClashGui = ClashGui:FindFirstChild("ClashHUD");
            end;

            if ClashGui then
                ClashGui.KeyPrompt.Visible = false;
                ClashGui.Visible = false;
            end;

            u7 = nil;
        end;

        CinemaManager.FadeOut(LocalPlayer);
    end
};