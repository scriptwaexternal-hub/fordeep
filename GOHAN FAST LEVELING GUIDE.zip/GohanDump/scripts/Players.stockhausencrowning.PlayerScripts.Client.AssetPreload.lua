-- Decompiled with Potassium's decompiler.

game:GetService("ReplicatedFirst"):RemoveDefaultLoadingScreen();
game.StarterGui:SetCoreGuiEnabled(Enum.CoreGuiType.PlayerList, false);
game.StarterGui:SetCoreGuiEnabled(Enum.CoreGuiType.Health, false);
local ContentProvider = game:GetService("ContentProvider");
local StarterGui = game:GetService("StarterGui");
local ReplicatedStorage = game:GetService("ReplicatedStorage");
ContentProvider:PreloadAsync({});

for _, descendant in pairs(game:GetDescendants()) do
    pcall(function() -- Line: 17
        -- upvalues: ContentProvider (copy), descendant (copy)
        ContentProvider:PreloadAsync(descendant);
    end);
end;

local Players = game:GetService("Players");
local BindableEvent = Instance.new("BindableEvent");
local ResetEvent = ReplicatedStorage:FindFirstChild("ResetEvent", true);

local function inCombat(p1) -- Line: 40
    if p1 and p1.Parent then
        return p1:GetAttribute("State_InCombat") ~= nil and true or p1:FindFirstChild("InCombat") ~= nil;
    end;

    return false;
end;

BindableEvent.Event:Connect(function() -- Line: 54
    -- upvalues: Players (copy), ResetEvent (copy)
    local Character = Players.LocalPlayer.Character;

    if not Character then
        return;
    end;

    if Character:FindFirstChild("Reset Gui") then
        return;
    end;

    local v2 = Character:FindFirstChildOfClass("Humanoid");
    local u3 = script["Reset Gui"]:Clone();
    u3.Name = "Reset Gui";
    u3.Parent = Character;
    u3.Desc.Text = 10;
    local u4 = false;
    local u5 = {};

    local function teardown() -- Line: 72
        -- upvalues: u5 (copy), u3 (copy)
        for _, v in ipairs(u5) do
            if v.Connected then
                v:Disconnect();
            end;
        end;

        table.clear(u5);

        if u3 and u3.Parent then
            u3:Destroy();
        end;
    end;

    local function cancel() -- Line: 80
        -- upvalues: u4 (ref), teardown (copy)
        if u4 then
            return;
        end;

        u4 = true;
        teardown();
    end;

    local function combatCancels() -- Line: 90
        -- upvalues: Character (copy)
        local v6 = Character;
        local v7;

        if v6 and v6.Parent then
            v7 = v6:GetAttribute("State_InCombat") ~= nil and true or v6:FindFirstChild("InCombat") ~= nil;
        else
            v7 = false;
        end;

        if v7 then
            v7 = not Character:GetAttribute("FailsafeEligible");
        end;

        return v7;
    end;

    local v8;

    if Character and Character.Parent then
        v8 = Character:GetAttribute("State_InCombat") ~= nil and true or Character:FindFirstChild("InCombat") ~= nil;
    else
        v8 = false;
    end;

    if v8 then
        v8 = not Character:GetAttribute("FailsafeEligible");
    end;

    if v8 then
        teardown();

        return;
    end;

    if v2 then
        local Health = v2.Health;
        table.insert(u5, v2.HealthChanged:Connect(function(p9) -- Line: 101
            -- upvalues: Health (ref), u4 (ref), teardown (copy)
            if p9 < Health and not u4 then
                u4 = true;
                teardown();
            end;

            Health = p9;
        end));
        table.insert(u5, v2.Died:Connect(cancel));
    end;

    local AttributeChangedSignal = Character:GetAttributeChangedSignal("State_InCombat");
    table.insert(u5, AttributeChangedSignal:Connect(function() -- Line: 109
        -- upvalues: Character (copy), u4 (ref), teardown (copy)
        local v10 = Character;
        local v11;

        if v10 and v10.Parent then
            v11 = v10:GetAttribute("State_InCombat") ~= nil and true or v10:FindFirstChild("InCombat") ~= nil;
        else
            v11 = false;
        end;

        if v11 then
            v11 = not Character:GetAttribute("FailsafeEligible");
        end;

        if v11 then
            if u4 then
                return;
            end;

            u4 = true;
            teardown();
        end;
    end));
    table.insert(u5, Character.ChildAdded:Connect(function(p12) -- Line: 114
        -- upvalues: Character (copy), u4 (ref), teardown (copy)
        if p12.Name == "InCombat" then
            local v13 = Character;
            local v14;

            if v13 and v13.Parent then
                v14 = v13:GetAttribute("State_InCombat") ~= nil and true or v13:FindFirstChild("InCombat") ~= nil;
            else
                v14 = false;
            end;

            if v14 then
                v14 = not Character:GetAttribute("FailsafeEligible");
            end;

            if v14 then
                if u4 then
                    return;
                end;

                u4 = true;
                teardown();
            end;
        end;
    end));
    table.insert(u5, Character.AncestryChanged:Connect(function() -- Line: 118
        -- upvalues: Character (copy), u4 (ref), teardown (copy)
        if not Character:IsDescendantOf(game) then
            if u4 then
                return;
            end;

            u4 = true;
            teardown();
        end;
    end));
    local v15 = tick();

    while not u4 and tick() - v15 < 10 do
        local Desc = u3.Desc;
        local v16 = tick() - v15;
        local v17 = 10 - math.round(v16);
        Desc.Text = math.max(0, v17);
        task.wait(0.1);
    end;

    if u4 then
        return;
    end;

    teardown();
    ResetEvent:FireServer();
end);
local v18;

repeat
    v18 = pcall(function() -- Line: 136
        -- upvalues: StarterGui (copy), BindableEvent (copy)
        StarterGui:SetCore("ResetButtonCallback", BindableEvent);
    end);
    task.wait(1);
until v18;