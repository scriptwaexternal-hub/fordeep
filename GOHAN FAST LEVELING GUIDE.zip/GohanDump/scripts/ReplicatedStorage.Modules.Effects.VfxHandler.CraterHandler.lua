-- Decompiled with Potassium's decompiler.

local TweenService = game:GetService("TweenService");
local ReplicatedStorage = game:GetService("ReplicatedStorage");
local Debris = game:GetService("Debris");
local Modules = ReplicatedStorage:WaitForChild("Modules");
local Shared = Modules.Shared;
local Effects = ReplicatedStorage.Assets.Effects;
local Meshes = Effects.Meshes;
local Particles = Effects.Particles;
local GlobalFunctions = require(Modules.GlobalFunctions);
local SoundManager = require(Shared.SoundManager);
local workspace_World = workspace.World;
local Visuals = workspace_World.Visuals;

local function resolveImpactScale(p1) -- Line: 84
    local v2 = tonumber(p1);

    return (not v2 or v2 ~= v2) and 1 or math.clamp(v2, 0.5, 1.35);
end;

local u3 = {
    RING_COUNT = 6,
    SLABS_INNER = 22,
    SLABS_OUTER = 12,
    RING_STAGGER_MAX = 0.35,
    INNER_RADIUS_MIN = 0.5,
    INNER_RADIUS_MAX = 2,
    LENGTH_MIN = 1.2,
    LENGTH_MAX = 4,
    THICKNESS_MIN = 0.5,
    THICKNESS_MAX = 1.8,
    WIDTH_FILL = 0.95,
    WIDTH_VARIANCE = 0.25,
    BOWL_DEPTH = 3,
    BOWL_EXPONENT = 1.35,
    SHEAR_HEIGHT = 0.6,
    SHEAR_TILT = 20,
    SHEAR_YAW = 10,
    SHEAR_ROLL = 14,
    RISE_MIN = 0.6,
    RISE_MAX = 1.3,
    SLAB_DURATION = 15,
    SLAB_FADE_LEAD = 2.5,
    RING_DELAY = 0.06,
    PIT_RUBBLE_ENABLED = true,
    PIT_RUBBLE_COUNT = 10,
    PIT_RUBBLE_MIN = 0.4,
    PIT_RUBBLE_MAX = 1,
    CRACK_ENABLED = true,
    CRACK_SIZE_MULT = 2.4,
    CRACK_DURATION = 15,
    CRACK_FADE_LEAD = 3,
    CRACK_Y_OFFSET = 0.08,

    RAY_BLACKLIST = function() -- Line: 160, Name: RAY_BLACKLIST
        -- upvalues: workspace_World (copy)
        return { workspace_World.Visuals, workspace_World.Live, workspace_World.Map["Landing Sites"] };
    end
};
local u4 = {
    COUNT = 14,
    BASE_SIZE = 1.8,
    DURATION = 8,
    SPAWN_SPREAD = 2,
    OUT_VEL_MIN = 12,
    OUT_VEL_MAX = 30,
    UP_VEL_MIN = 18,
    UP_VEL_MAX = 40,
    LV_DURATION = 0.35,
    FADE_LEAD = 1.5
};
local u5 = {
    RING_BASE_SIZE = 180,
    RING_SCALE = 70,
    RING_DURATION = 2,
    BURST_BASE_SIZE = 25,
    BURST_SCALE = 10,
    BURST_DURATION = 0.7,
    DUST_PUFFS = 3,
    DUST_SPREAD = 5,
    DUST_SIZE_MIN = 15,
    DUST_SIZE_MAX = 26,
    DUST_EMIT_MIN = 8,
    DUST_EMIT_MAX = 15,
    DUST_STAGGER = 0.12
};
local u6 = {
    RING_COUNT = 3,
    SLABS_PER_RING = 14,
    RING_STAGGER_MAX = 0.25,
    INNER_RADIUS = 2.5,
    LENGTH_MIN = 1.6,
    LENGTH_MAX = 4,
    THICKNESS_MIN = 0.4,
    THICKNESS_MAX = 0.9,
    WIDTH_FILL = 0.94,
    WIDTH_VARIANCE = 0.1,
    BOWL_DEPTH = 1.6,
    BOWL_EXPONENT = 1.3,
    SHEAR_HEIGHT = 0.25,
    SHEAR_TILT = 6,
    SHEAR_YAW = 3,
    SHEAR_ROLL = 5,
    RISE_MIN = 0.4,
    RISE_MAX = 0.9,
    SLAB_DURATION = 12,
    SLAB_FADE_LEAD = 2,
    RING_DELAY = 0.07
};
local u7 = {
    SIDE_OFFSET = 3.2,
    SIDE_VARIANCE = 0.8,
    SEGMENT_SPACING = 3.5,
    LENGTH_MIN = 1.4,
    LENGTH_MAX = 2.6,
    WIDTH_MIN = 0.9,
    WIDTH_MAX = 1.8,
    THICKNESS_MIN = 0.5,
    THICKNESS_MAX = 1,
    CANT_MIN = 15,
    CANT_MAX = 40,
    SHEAR_TILT = 12,
    SHEAR_YAW = 14,
    SHEAR_HEIGHT = 0.3,
    RISE_MIN = 0.5,
    RISE_MAX = 1,
    SLAB_DURATION = 6,
    SLAB_FADE_LEAD = 1.5,
    MIN_SPEED = 16,
    START_GRACE = 0.35,
    MAX_DURATION = 4,
    MAX_SEGMENT_PAIRS = 40,
    STEEP_NORMAL_Y = 0.3,
    PROBE_DOWN = 25,
    AIRBORNE_HEIGHT = 7,
    AIRBORNE_FORGIVE = 0.3,
    DUST_EVERY = 3,
    DUST_SIZE_MIN = 3.5,
    DUST_SIZE_MAX = 6,
    DUST_EMIT_MIN = 2,
    DUST_EMIT_MAX = 3
};

local function rand(p8, p9) -- Line: 304
    return p8 + math.random() * (p9 - p8);
end;

local function lerp(p10, p11, p12) -- Line: 308
    return p10 + (p11 - p10) * p12;
end;

local function castDown(p13, p14) -- Line: 312
    -- upvalues: GlobalFunctions (copy)
    return GlobalFunctions.CastRay(p13 + Vector3.new(0, 6, 0), Vector3.new(0, -14, 0), p14, true);
end;

local function scheduleFade(u15, p16, u17) -- Line: 323
    -- upvalues: Debris (copy), GlobalFunctions (copy)
    Debris:AddItem(u15, p16);
    task.delay(p16 - u17, function() -- Line: 325
        -- upvalues: u15 (copy), GlobalFunctions (ref), u17 (copy)
        if not u15.Parent then
            return;
        end;

        local v18 = u15.Size.Y + math.max(u15.Size.X, u15.Size.Z) * 0.5;
        GlobalFunctions.Tween({
            Instance = u15,
            Duration = u17,
            EasingStyle = Enum.EasingStyle.Quad,
            EasingDirection = Enum.EasingDirection.In
        }, {
            Transparency = 1,
            CFrame = u15.CFrame - Vector3.new(0, v18, 0)
        });
    end);
end;

local Slate = Enum.Material.Slate;
local Color3_fromRGB_ret = Color3.fromRGB(92, 74, 58);

local function spawnLayeredSlab(p19, p20, p21, p22, p23, p24) -- Line: 359
    -- upvalues: Slate (copy), Color3_fromRGB_ret (copy), Visuals (copy), Debris (copy), GlobalFunctions (copy)
    local Y = p21.Y;
    local math_max_ret = math.max(Y * 0.25, 0.1);
    local v25 = Y - math_max_ret;
    local Part = Instance.new("Part");
    Part.Material = Slate;
    Part.Color = Color3_fromRGB_ret;
    Part.Size = Vector3.new(p21.X, v25, p21.Z);
    Part.Anchored = true;
    Part.CanCollide = false;
    Part.CastShadow = true;
    Part.CFrame = p20 * CFrame.new(0, -math_max_ret * 0.5, 0);
    Part.Parent = Visuals;
    local Part2 = Instance.new("Part");
    Part2.Material = p22;
    Part2.Color = p23;
    Part2.Size = Vector3.new(p21.X, math_max_ret, p21.Z);
    Part2.Anchored = true;
    Part2.CanCollide = false;
    Part2.CastShadow = true;
    Part2.CFrame = p20 * CFrame.new(0, v25 * 0.5, 0);
    Part2.Parent = Visuals;
    local SLAB_DURATION = p19.SLAB_DURATION;
    local SLAB_FADE_LEAD = p19.SLAB_FADE_LEAD;
    Debris:AddItem(Part, SLAB_DURATION);
    task.delay(SLAB_DURATION - SLAB_FADE_LEAD, function() -- Line: 325
        -- upvalues: Part (copy), GlobalFunctions (ref), SLAB_FADE_LEAD (copy)
        if not Part.Parent then
            return;
        end;

        local v26 = Part.Size.Y + math.max(Part.Size.X, Part.Size.Z) * 0.5;
        GlobalFunctions.Tween({
            Instance = Part,
            Duration = SLAB_FADE_LEAD,
            EasingStyle = Enum.EasingStyle.Quad,
            EasingDirection = Enum.EasingDirection.In
        }, {
            Transparency = 1,
            CFrame = Part.CFrame - Vector3.new(0, v26, 0)
        });
    end);
    local SLAB_DURATION2 = p19.SLAB_DURATION;
    local SLAB_FADE_LEAD2 = p19.SLAB_FADE_LEAD;
    Debris:AddItem(Part2, SLAB_DURATION2);
    task.delay(SLAB_DURATION2 - SLAB_FADE_LEAD2, function() -- Line: 325
        -- upvalues: Part2 (copy), GlobalFunctions (ref), SLAB_FADE_LEAD2 (copy)
        if not Part2.Parent then
            return;
        end;

        local v27 = Part2.Size.Y + math.max(Part2.Size.X, Part2.Size.Z) * 0.5;
        GlobalFunctions.Tween({
            Instance = Part2,
            Duration = SLAB_FADE_LEAD2,
            EasingStyle = Enum.EasingStyle.Quad,
            EasingDirection = Enum.EasingDirection.In
        }, {
            Transparency = 1,
            CFrame = Part2.CFrame - Vector3.new(0, v27, 0)
        });
    end);
    local v28 = 0.15 + math.random() * 0.13000000000000003;

    for _, v in ipairs({ Part, Part2 }) do
        GlobalFunctions.Tween({
            Instance = v,
            Duration = v28,
            EasingStyle = Enum.EasingStyle.Quad,
            EasingDirection = Enum.EasingDirection.Out
        }, {
            CFrame = v.CFrame + p24
        });
    end;
end;

local function bowlDepth(p29, p30, p31, p32) -- Line: 399
    if p32 <= p30 then
        return 0;
    end;

    if p30 <= p31 then
        return p29.BOWL_DEPTH;
    end;

    return p29.BOWL_DEPTH * (1 - (p30 - p31) / (p32 - p31)) ^ p29.BOWL_EXPONENT;
end;

local function SpawnBowlSlab(p33, p34, p35, p36, p37, p38, p39, p40, p41, p42, p43, p44) -- Line: 420
    -- upvalues: GlobalFunctions (copy), spawnLayeredSlab (copy)
    local v45 = p36 + p37;
    local v46 = p36 + p37 * 0.5;
    local math_sin_ret = math.sin(p35);
    local math_cos_ret = math.cos(p35);
    local Vector3_new_ret = Vector3.new(p34.Position.X + math_sin_ret * v46, p34.Position.Y, p34.Position.Z + math_cos_ret * v46);
    local v47 = GlobalFunctions.CastRay(Vector3_new_ret + Vector3.new(0, 6, 0), Vector3.new(0, -14, 0), p44, true);

    if not v47 then
        return;
    end;

    local Y = v47.Position.Y;
    local v48 = p42 or v47.Material;

    if v48 == Enum.Material.Plastic then
        v48 = Enum.Material.SmoothPlastic;
    end;

    local v49 = p43 or v47.Instance.Color;
    local v50;

    if p41 <= p36 then
        v50 = 0;
    elseif p36 <= p40 then
        v50 = p33.BOWL_DEPTH;
    else
        v50 = p33.BOWL_DEPTH * (1 - (p36 - p40) / (p41 - p40)) ^ p33.BOWL_EXPONENT;
    end;

    local v51;

    if p41 <= v45 then
        v51 = 0;
    elseif v45 <= p40 then
        v51 = p33.BOWL_DEPTH;
    else
        v51 = p33.BOWL_DEPTH * (1 - (v45 - p40) / (p41 - p40)) ^ p33.BOWL_EXPONENT;
    end;

    local math_atan2_ret = math.atan2(v50 - v51, p37);
    local v52 = -p33.SHEAR_HEIGHT;
    local SHEAR_HEIGHT = p33.SHEAR_HEIGHT;
    local v53 = v52 + math.random() * (SHEAR_HEIGHT - v52);
    local v54 = Y - (v50 + v51) * 0.5 + p38 * 0.25 + v53;
    local v55 = -p33.SHEAR_TILT;
    local SHEAR_TILT = p33.SHEAR_TILT;
    local v56 = v55 + math.random() * (SHEAR_TILT - v55);
    local v57 = math_atan2_ret + math.rad(v56);
    local v58 = -p33.SHEAR_YAW;
    local SHEAR_YAW = p33.SHEAR_YAW;
    local v59 = v58 + math.random() * (SHEAR_YAW - v58);
    local math_rad_ret = math.rad(v59);
    local v60 = -p33.SHEAR_ROLL;
    local SHEAR_ROLL = p33.SHEAR_ROLL;
    local v61 = v60 + math.random() * (SHEAR_ROLL - v60);
    local math_rad_ret2 = math.rad(v61);
    local RISE_MIN = p33.RISE_MIN;
    local RISE_MAX = p33.RISE_MAX;
    local v62 = RISE_MIN + math.random() * (RISE_MAX - RISE_MIN);
    spawnLayeredSlab(p33, CFrame.new(Vector3.new(Vector3_new_ret.X, v54 - v62, Vector3_new_ret.Z), (Vector3.new(Vector3_new_ret.X + math_sin_ret, v54 - v62, Vector3_new_ret.Z + math_cos_ret))) * CFrame.Angles(v57, math_rad_ret, math_rad_ret2), Vector3.new(p39, p38, p37), v48, v49, (Vector3.new(0, v62, 0)));
end;

local function SpawnPitRubble(p63, p64, p65, p66, p67, p68) -- Line: 481
    -- upvalues: GlobalFunctions (copy), Visuals (copy), Slate (copy), Color3_fromRGB_ret (copy), Debris (copy)
    if not p63.PIT_RUBBLE_ENABLED then
        return;
    end;

    local v69 = GlobalFunctions.CastRay(p64.Position + Vector3.new(0, 6, 0), Vector3.new(0, -14, 0), p68, true);

    if not v69 then
        return;
    end;

    local v70 = v69.Position.Y - p63.BOWL_DEPTH * p65;

    for i = 1, p63.PIT_RUBBLE_COUNT do
        local v71 = 0 + math.random() * 6.283185307179586;
        local v72 = p63.INNER_RADIUS_MAX * p65 * 0.85;
        local v73 = 0 + math.random() * (v72 - 0);
        local PIT_RUBBLE_MIN = p63.PIT_RUBBLE_MIN;
        local PIT_RUBBLE_MAX = p63.PIT_RUBBLE_MAX;
        local v74 = (PIT_RUBBLE_MIN + math.random() * (PIT_RUBBLE_MAX - PIT_RUBBLE_MIN)) * p65;
        local v75 = p64.Position.X + math.cos(v71) * v73;
        local v76 = p64.Position.Z + math.sin(v71) * v73;
        local Vector3_new_ret = Vector3.new(v75, p64.Position.Y, v76);
        local v77;

        if GlobalFunctions.CastRay(Vector3_new_ret + Vector3.new(0, 6, 0), Vector3.new(0, -14, 0), p68, true) then
            local Part = Instance.new("Part");
            Part.Parent = Visuals;
            Part.Material = Slate;
            Part.Color = Color3_fromRGB_ret;
            local v78 = v74 * (0.7 + math.random() * 0.6000000000000001);
            local v79 = v74 * (0.5 + math.random() * 0.5);
            local v80 = v74 * (0.7 + math.random() * 0.6000000000000001);
            Part.Size = Vector3.new(v78, v79, v80);
            Part.Anchored = true;
            Part.CanCollide = false;
            local CFrame_new_ret = CFrame.new(v75, v70 + v74 * 0.3, v76);
            local CFrame_Angles = CFrame.Angles;
            local v81 = 0 + math.random() * 360;
            local math_rad_ret = math.rad(v81);
            local v82 = 0 + math.random() * 360;
            local math_rad_ret2 = math.rad(v82);
            local v83 = 0 + math.random() * 360;
            Part.CFrame = CFrame_new_ret * CFrame_Angles(math_rad_ret, math_rad_ret2, (math.rad(v83)));
            local SLAB_DURATION = p63.SLAB_DURATION;
            local SLAB_FADE_LEAD = p63.SLAB_FADE_LEAD;
            Debris:AddItem(Part, SLAB_DURATION);
            task.delay(SLAB_DURATION - SLAB_FADE_LEAD, function() -- Line: 325
                -- upvalues: Part (copy), GlobalFunctions (ref), SLAB_FADE_LEAD (copy)
                if not Part.Parent then
                    return;
                end;

                local v84 = Part.Size.Y + math.max(Part.Size.X, Part.Size.Z) * 0.5;
                GlobalFunctions.Tween({
                    Instance = Part,
                    Duration = SLAB_FADE_LEAD,
                    EasingStyle = Enum.EasingStyle.Quad,
                    EasingDirection = Enum.EasingDirection.In
                }, {
                    Transparency = 1,
                    CFrame = Part.CFrame - Vector3.new(0, v84, 0)
                });
            end);
            v77 = i;
        else
            v77 = i;
        end;
    end;
end;

local function SpawnGroundCrack(u85, p86, p87, p88) -- Line: 526
    -- upvalues: Meshes (copy), GlobalFunctions (copy), Visuals (copy), Debris (copy)
    if not u85.CRACK_ENABLED then
        return;
    end;

    local success, result = pcall(function() -- Line: 528
        -- upvalues: Meshes (ref)
        return Meshes["Ground Crack"];
    end);

    if not (success and result) then
        return;
    end;

    local v89 = GlobalFunctions.CastRay(p86.Position + Vector3.new(0, 6, 0), Vector3.new(0, -14, 0), p88, true);
    local v90 = v89 and v89.Position.Y or p86.Position.Y;
    local u91 = result:Clone();
    u91.Parent = Visuals;
    local v92 = u85.INNER_RADIUS_MAX * u85.CRACK_SIZE_MULT * p87;
    u91.Size = Vector3.new(v92, 0.1, v92);
    u91.CFrame = CFrame.new(p86.Position.X, v90 - u85.BOWL_DEPTH * p87 + u85.CRACK_Y_OFFSET, p86.Position.Z) * CFrame.Angles(0, 0 + math.random() * 6.283185307179586, 0);
    u91.Anchored = true;
    u91.CanCollide = false;
    Debris:AddItem(u91, u85.CRACK_DURATION);
    task.delay(u85.CRACK_DURATION - u85.CRACK_FADE_LEAD, function() -- Line: 550
        -- upvalues: u91 (copy), GlobalFunctions (ref), u85 (copy)
        if not u91.Parent then
            return;
        end;

        local v93 = u91:FindFirstChildOfClass("Decal");

        if v93 then
            GlobalFunctions.Tween({
                Instance = v93,
                Duration = u85.CRACK_FADE_LEAD
            }, {
                Transparency = 1
            });
        end;

        GlobalFunctions.Tween({
            Instance = u91,
            Duration = u85.CRACK_FADE_LEAD,
            EasingStyle = Enum.EasingStyle.Quad,
            EasingDirection = Enum.EasingDirection.In
        }, {
            Transparency = 1,
            CFrame = u91.CFrame - Vector3.new(0, 1, 0)
        });
    end);
end;

local function SpawnDebris(p94, p95, p96, p97) -- Line: 570
    -- upvalues: u4 (copy), workspace_World (copy), GlobalFunctions (copy), Meshes (copy), Visuals (copy), Debris (copy)
    local v98 = u4;
    local v99 = p95 or 1;
    local v100 = GlobalFunctions.CastRay(p94.Position + Vector3.new(0, 6, 0), Vector3.new(0, -14, 0), { workspace_World.Visuals, workspace_World.Live }, true);
    local v101 = p96 or (v100 and v100.Material or Enum.Material.SmoothPlastic);

    if v101 == Enum.Material.Plastic then
        v101 = Enum.Material.SmoothPlastic;
    end;

    local v102 = p97 or (v100 and v100.Instance.Color or Color3.fromRGB(110, 105, 100));

    for i = 1, v98.COUNT do
        local math_random_ret = math.random();
        local v103;

        if math_random_ret < 0.15 then
            local v104 = v98.BASE_SIZE * 0.7;
            local BASE_SIZE = v98.BASE_SIZE;
            v103 = (v104 + math.random() * (BASE_SIZE - v104)) * v99;
        elseif math_random_ret < 0.5 then
            local v105 = v98.BASE_SIZE * 0.3;
            local v106 = v98.BASE_SIZE * 0.6;
            v103 = (v105 + math.random() * (v106 - v105)) * v99;
        else
            local v107 = v98.BASE_SIZE * 0.25;
            v103 = (0.15 + math.random() * (v107 - 0.15)) * v99;
        end;

        local u108 = Meshes["Rock Debris"]:Clone();
        u108.Parent = Visuals;
        u108.Material = v101;
        u108.Color = v102;
        u108.Size = Vector3.new(1, 1, 1) * v103;
        u108.CanCollide = false;
        local v109 = 0 + math.random() * 6.283185307179586;
        local v110 = v98.SPAWN_SPREAD * v99;
        local v111 = 0 + math.random() * (v110 - 0);
        local v112 = p94 * CFrame.new(math.cos(v109) * v111, 1, math.sin(v109) * v111);
        local CFrame_Angles = CFrame.Angles;
        local v113 = 0 + math.random() * 360;
        local math_rad_ret = math.rad(v113);
        local v114 = 0 + math.random() * 360;
        local math_rad_ret2 = math.rad(v114);
        local v115 = 0 + math.random() * 360;
        u108.CFrame = v112 * CFrame_Angles(math_rad_ret, math_rad_ret2, (math.rad(v115)));
        local DURATION = v98.DURATION;
        local FADE_LEAD = v98.FADE_LEAD;
        Debris:AddItem(u108, DURATION);
        task.delay(DURATION - FADE_LEAD, function() -- Line: 325
            -- upvalues: u108 (copy), GlobalFunctions (ref), FADE_LEAD (copy)
            if not u108.Parent then
                return;
            end;

            local v116 = u108.Size.Y + math.max(u108.Size.X, u108.Size.Z) * 0.5;
            GlobalFunctions.Tween({
                Instance = u108,
                Duration = FADE_LEAD,
                EasingStyle = Enum.EasingStyle.Quad,
                EasingDirection = Enum.EasingDirection.In
            }, {
                Transparency = 1,
                CFrame = u108.CFrame - Vector3.new(0, v116, 0)
            });
        end);
        task.delay(0.3, function() -- Line: 605
            -- upvalues: u108 (copy)
            if u108.Parent then
                u108.CanCollide = true;
            end;
        end);
        local Attachment = Instance.new("Attachment");
        Attachment.Parent = u108;
        local LinearVelocity = Instance.new("LinearVelocity");
        LinearVelocity.Parent = Attachment;
        LinearVelocity.Attachment0 = Attachment;
        LinearVelocity.MaxForce = 10000;
        LinearVelocity.Visible = false;
        local math_cos_ret = math.cos(v109);
        local math_sin_ret = math.sin(v109);
        local Vector3_new_ret = Vector3.new(math_cos_ret, 0, math_sin_ret);
        local OUT_VEL_MIN = v98.OUT_VEL_MIN;
        local OUT_VEL_MAX = v98.OUT_VEL_MAX;
        local v117 = Vector3_new_ret * (OUT_VEL_MIN + math.random() * (OUT_VEL_MAX - OUT_VEL_MIN)) * v99;
        local UP_VEL_MIN = v98.UP_VEL_MIN;
        local UP_VEL_MAX = v98.UP_VEL_MAX;
        local v118 = (UP_VEL_MIN + math.random() * (UP_VEL_MAX - UP_VEL_MIN)) * v99;
        LinearVelocity.VectorVelocity = v117 + Vector3.new(0, v118, 0);
        task.delay(v98.LV_DURATION, function() -- Line: 621
            -- upvalues: LinearVelocity (copy)
            if LinearVelocity.Parent then
                LinearVelocity:Destroy();
            end;
        end);
        local _ = i;
    end;
end;

local function SpawnRing(p119, p120) -- Line: 631
    -- upvalues: u5 (copy), Meshes (copy), Visuals (copy), Debris (copy), GlobalFunctions (copy)
    local v121 = u5;
    local v122 = Meshes.Crater.Ring:Clone();
    v122.Parent = Visuals;
    v122.CFrame = p119;
    Debris:AddItem(v122, v121.RING_DURATION);
    GlobalFunctions.Tween({
        Instance = v122,
        Duration = v121.RING_DURATION,
        EasingStyle = Enum.EasingStyle.Exponential,
        EasingDirection = Enum.EasingDirection.Out
    }, {
        Transparency = 1,
        Size = Vector3.new(1, 0.05, 1) * (v121.RING_BASE_SIZE + v121.RING_SCALE * (p120 or 1))
    });
end;

local function SpawnBurst(p123, p124) -- Line: 647
    -- upvalues: u5 (copy), Meshes (copy), Visuals (copy), Debris (copy), TweenService (copy)
    local v125 = u5;
    local v126 = Meshes.Crater.Block_Burst:Clone();
    v126.Parent = Visuals;
    v126.CFrame = p123;
    Debris:AddItem(v126, 2);
    TweenService:Create(v126, TweenInfo.new(v125.BURST_DURATION, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out), {
        Transparency = 1,
        Size = Vector3.new(1, 1, 1) * (v125.BURST_BASE_SIZE + v125.BURST_SCALE * (p124 or 1))
    }):Play();
end;

local function SpawnDust(p127, p128) -- Line: 661
    -- upvalues: u5 (copy), workspace_World (copy), GlobalFunctions (copy), Meshes (copy), Visuals (copy), Debris (copy)
    local v129 = u5;
    local v130 = p128 or 1;
    local v131 = GlobalFunctions.CastRay(p127.Position + Vector3.new(0, 6, 0), Vector3.new(0, -14, 0), { workspace_World.Visuals, workspace_World.Live }, true);

    if not v131 then
        return;
    end;

    local Color = v131.Instance.Color;

    for i = 1, v129.DUST_PUFFS do
        local v132 = 0 + math.random() * 6.283185307179586;
        local v133 = v129.DUST_SPREAD * v130;
        local v134 = 0 + math.random() * (v133 - 0);
        local v135 = p127 * CFrame.new(math.cos(v132) * v134, 0, math.sin(v132) * v134);
        local v136 = Meshes.Crater.Dust:Clone();
        v136.Parent = Visuals;
        v136.CFrame = v135;
        Debris:AddItem(v136, 10);
        local DUST_SIZE_MIN = v129.DUST_SIZE_MIN;
        local DUST_SIZE_MAX = v129.DUST_SIZE_MAX;
        local v137 = (DUST_SIZE_MIN + math.random() * (DUST_SIZE_MAX - DUST_SIZE_MIN)) * v130;
        v136.Effect.Color = ColorSequence.new({ ColorSequenceKeypoint.new(0, Color), ColorSequenceKeypoint.new(0.5, Color), ColorSequenceKeypoint.new(1, Color) });
        v136.Effect.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, v137), NumberSequenceKeypoint.new(0.5, v137 * 0.35), NumberSequenceKeypoint.new(1, 0) });
        local Effect = v136.Effect;
        local DUST_EMIT_MIN = v129.DUST_EMIT_MIN;
        local DUST_EMIT_MAX = v129.DUST_EMIT_MAX;
        local v138 = DUST_EMIT_MIN + math.random() * (DUST_EMIT_MAX - DUST_EMIT_MIN);
        Effect:Emit((math.floor(v138)));
        local _ = i;
    end;
end;

local function MakeCrater(u139, p140) -- Line: 702
    -- upvalues: u3 (copy), Particles (copy), Visuals (copy), Debris (copy), SoundManager (copy), SpawnRing (copy), SpawnBurst (copy), SpawnDust (copy), SpawnDebris (copy), SpawnPitRubble (copy), SpawnBowlSlab (copy)
    local v141 = p140 or {};
    local v142 = tonumber(v141.ImpactScale);
    local u143 = (not v142 or v142 ~= v142) and 1 or math.clamp(v142, 0.5, 1.35);
    local v144 = tonumber(v141.RingAmount) or u3.RING_COUNT;
    local math_floor_ret = math.floor(v144);
    local math_clamp_ret = math.clamp(math_floor_ret, 1, u3.RING_COUNT);
    local SurfaceMaterial = v141.SurfaceMaterial;
    local SurfaceColor = v141.SurfaceColor;
    local u145 = u3.RAY_BLACKLIST();
    local v146 = Particles.DownslamVFX:Clone();
    v146.Parent = Visuals;
    v146.CFrame = u139;
    Debris:AddItem(v146, 3);
    SoundManager.AddSound("KnockbackCrash", {
        Parent = v146
    }, "Client");

    for _, descendant in ipairs(v146:GetDescendants()) do
        if descendant:IsA("ParticleEmitter") then
            descendant:Emit((math.floor(8 * u143)));
        end;
    end;

    task.spawn(SpawnRing, u139, u143);
    task.spawn(SpawnBurst, u139, u143);
    task.spawn(SpawnDust, u139, u143);
    task.spawn(SpawnDebris, u139, u143, SurfaceMaterial, SurfaceColor);
    task.spawn(SpawnPitRubble, u3, u139, u143, SurfaceMaterial, SurfaceColor, u145);
    task.spawn(function() -- Line: 737
        -- upvalues: u3 (ref), u143 (copy), math_clamp_ret (copy), SpawnBowlSlab (ref), u139 (copy), SurfaceMaterial (copy), SurfaceColor (copy), u145 (copy)
        local INNER_RADIUS_MIN = u3.INNER_RADIUS_MIN;
        local INNER_RADIUS_MAX = u3.INNER_RADIUS_MAX;
        local v147 = (INNER_RADIUS_MIN + math.random() * (INNER_RADIUS_MAX - INNER_RADIUS_MIN)) * u143;
        local v148 = v147;
        local v149 = {};

        for i = 1, math_clamp_ret do
            local v150 = (i - 1) / math.max(math_clamp_ret - 1, 1);
            local LENGTH_MIN = u3.LENGTH_MIN;
            local v151 = (LENGTH_MIN + (u3.LENGTH_MAX - LENGTH_MIN) * v150) * u143;
            local THICKNESS_MIN = u3.THICKNESS_MIN;
            local SLABS_INNER = u3.SLABS_INNER;
            v149[i] = {
                rInner = v147,
                length = v151,
                thickness = THICKNESS_MIN + (u3.THICKNESS_MAX - THICKNESS_MIN) * v150,
                count = math.floor(SLABS_INNER + (u3.SLABS_OUTER - SLABS_INNER) * v150)
            };
            v147 = v147 + v151;
            local _ = i;
        end;

        for i = 1, math_clamp_ret do
            local v152;

            if math_clamp_ret - 2 < i then
                local v153 = v149[i];
                local v154 = 6.283185307179586 / v153.count;
                local v155 = v154 * u3.RING_STAGGER_MAX;
                local v156 = 0 + math.random() * (v155 - 0);
                v152 = i;

                for i2 = 1, v153.count do
                    local v157 = 6.283185307179586 * (v153.rInner + v153.length * 0.5) / v153.count;
                    local v158 = -u3.WIDTH_VARIANCE;
                    local WIDTH_VARIANCE = u3.WIDTH_VARIANCE;
                    local v159 = 1 + (v158 + math.random() * (WIDTH_VARIANCE - v158));
                    local math_max_ret = math.max(v157 * u3.WIDTH_FILL * v159, 0.8);
                    task.spawn(SpawnBowlSlab, u3, u139, (i2 - 1) * v154 + v156, v153.rInner, v153.length, v153.thickness, math_max_ret, v148, v147, SurfaceMaterial, SurfaceColor, u145);
                    local _ = i2;
                end;

                task.wait(u3.RING_DELAY);
            else
                v152 = i;
            end;
        end;
    end);
end;

local function MakeWallCrater(u160, p161) -- Line: 800
    -- upvalues: u6 (copy), Visuals (copy), Debris (copy), SoundManager (copy), SpawnRing (copy), SpawnBurst (copy), GlobalFunctions (copy), workspace_World (copy), spawnLayeredSlab (copy)
    local v162 = p161 or {};
    local v163 = tonumber((v162.Data or {}).ImpactScale);
    local u164 = (not v163 or v163 ~= v163) and 1 or math.clamp(v163, 0.5, 1.35);
    local SurfaceMaterial = v162.SurfaceMaterial;
    local SurfaceColor = v162.SurfaceColor;
    local RayData = v162.RayData;

    if not (RayData and RayData.Normal) then
        warn("CraterHandler.WallCrater: missing RayData.Normal");

        return;
    end;

    local Unit = RayData.Normal.Unit;
    local u165 = u6;
    local Part = Instance.new("Part");
    Part.Parent = Visuals;
    Part.Transparency = 1;
    Part.Size = Vector3.new(1, 1, 1);
    Part.CFrame = u160;
    Part.Anchored = true;
    Part.CanCollide = false;
    Debris:AddItem(Part, 3);
    SoundManager.AddSound("Rock Explosion", {
        Parent = Part
    }, "Client");
    task.spawn(SpawnRing, u160, u164);
    task.spawn(SpawnBurst, u160, u164);
    task.spawn(function() -- Line: 829
        -- upvalues: Unit (copy), u165 (copy), u164 (copy), u160 (copy), GlobalFunctions (ref), workspace_World (ref), SurfaceMaterial (copy), SurfaceColor (copy), spawnLayeredSlab (ref)
        local v166 = Unit:Cross(Vector3.new(0, 1, 0));

        if v166.Magnitude < 0.001 then
            v166 = Unit:Cross(Vector3.new(1, 0, 0));
        end;

        local Unit2 = v166.Unit;
        local Unit3 = Unit2:Cross(Unit).Unit;
        local v167 = u165.INNER_RADIUS * u164;
        local v168 = v167;
        local v169 = {};

        for i = 1, u165.RING_COUNT do
            local v170 = (i - 1) / math.max(u165.RING_COUNT - 1, 1);
            local LENGTH_MIN = u165.LENGTH_MIN;
            local v171 = (LENGTH_MIN + (u165.LENGTH_MAX - LENGTH_MIN) * v170) * u164;
            local THICKNESS_MIN = u165.THICKNESS_MIN;
            v169[i] = {
                rInner = v167,
                length = v171,
                thickness = THICKNESS_MIN + (u165.THICKNESS_MAX - THICKNESS_MIN) * v170
            };
            v167 = v167 + v171;
            local _ = i;
        end;

        local SLABS_PER_RING = u165.SLABS_PER_RING;
        local v172 = 6.283185307179586 / SLABS_PER_RING;

        for i = 1, u165.RING_COUNT do
            local v173 = v169[i];
            local v174 = v172 * u165.RING_STAGGER_MAX;
            local v175 = 0 + math.random() * (v174 - 0);
            local _ = i;

            for i2 = 1, SLABS_PER_RING do
                local v176 = (i2 - 1) * v172 + v175;
                local v177 = Unit2 * math.cos(v176) + Unit3 * math.sin(v176);
                local v178 = v173.rInner + v173.length * 0.5;
                local v179 = GlobalFunctions.CastRay(u160.Position + v177 * v178 + Unit * 5, Unit * -10, { workspace_World.Visuals, workspace_World.Live });
                local v180;

                if v179 then
                    local v181 = SurfaceMaterial or (v179.Material or Enum.Material.SmoothPlastic);

                    if v181 == Enum.Material.Plastic then
                        v181 = Enum.Material.SmoothPlastic;
                    end;

                    local v182 = SurfaceColor or (v179.Instance.Color or Color3.fromRGB(110, 105, 100));
                    local v183 = -u165.WIDTH_VARIANCE;
                    local WIDTH_VARIANCE = u165.WIDTH_VARIANCE;
                    local v184 = 1 + (v183 + math.random() * (WIDTH_VARIANCE - v183));
                    local math_max_ret = math.max(6.283185307179586 * v178 / SLABS_PER_RING * u165.WIDTH_FILL * v184, 0.6);
                    local v185 = u165;
                    local rInner = v173.rInner;
                    local v186;

                    if v167 <= rInner then
                        v186 = 0;
                    elseif rInner <= v168 then
                        v186 = v185.BOWL_DEPTH;
                    else
                        v186 = v185.BOWL_DEPTH * (1 - (rInner - v168) / (v167 - v168)) ^ v185.BOWL_EXPONENT;
                    end;

                    local v187 = u165;
                    local v188 = v173.rInner + v173.length;
                    local v189;

                    if v167 <= v188 then
                        v189 = 0;
                    elseif v188 <= v168 then
                        v189 = v187.BOWL_DEPTH;
                    else
                        v189 = v187.BOWL_DEPTH * (1 - (v188 - v168) / (v167 - v168)) ^ v187.BOWL_EXPONENT;
                    end;

                    local math_atan2_ret = math.atan2(v186 - v189, v173.length);
                    local v190 = -u165.SHEAR_TILT;
                    local SHEAR_TILT = u165.SHEAR_TILT;
                    local v191 = v190 + math.random() * (SHEAR_TILT - v190);
                    local v192 = math_atan2_ret + math.rad(v191);
                    local v193 = -u165.SHEAR_YAW;
                    local SHEAR_YAW = u165.SHEAR_YAW;
                    local v194 = v193 + math.random() * (SHEAR_YAW - v193);
                    local math_rad_ret = math.rad(v194);
                    local v195 = -u165.SHEAR_ROLL;
                    local SHEAR_ROLL = u165.SHEAR_ROLL;
                    local v196 = v195 + math.random() * (SHEAR_ROLL - v195);
                    local math_rad_ret2 = math.rad(v196);
                    local v197 = -u165.SHEAR_HEIGHT;
                    local SHEAR_HEIGHT = u165.SHEAR_HEIGHT;
                    local v198 = v197 + math.random() * (SHEAR_HEIGHT - v197);
                    local RISE_MIN = u165.RISE_MIN;
                    local RISE_MAX = u165.RISE_MAX;
                    local v199 = RISE_MIN + math.random() * (RISE_MAX - RISE_MIN);
                    local v200 = v179.Position + Unit * (-((v186 + v189) * 0.5) + v173.thickness * 0.25 + v198 - v199);
                    spawnLayeredSlab(u165, CFrame.lookAt(v200, v200 + v177, Unit) * CFrame.Angles(v192, math_rad_ret, math_rad_ret2), Vector3.new(math_max_ret, v173.thickness, v173.length), v181, v182, Unit * v199);
                    v180 = i2;
                else
                    v180 = i2;
                end;
            end;

            task.wait(u165.RING_DELAY);
        end;
    end);
end;

local function castDownTrail(p201, p202) -- Line: 924
    -- upvalues: GlobalFunctions (copy), u7 (copy)
    return GlobalFunctions.CastRay(p201 + Vector3.new(0, 6, 0), Vector3.new(0, -(6 + u7.PROBE_DOWN), 0), p202, true);
end;

local function SpawnDragSlab(p203, p204, p205, p206, p207, p208, p209) -- Line: 945
    -- upvalues: u7 (copy), GlobalFunctions (copy), spawnLayeredSlab (copy)
    local v210 = u7;
    local v211 = GlobalFunctions.CastRay(p203 + Vector3.new(0, 6, 0), Vector3.new(0, -(6 + u7.PROBE_DOWN), 0), p209, true);

    if not v211 then
        return;
    end;

    local Normal = v211.Normal;

    if Normal.Y < v210.STEEP_NORMAL_Y then
        return;
    end;

    local v212 = p207 or v211.Material;

    if v212 == Enum.Material.Plastic then
        v212 = Enum.Material.SmoothPlastic;
    end;

    local v213 = p208 or v211.Instance.Color;
    local v214 = p204 - Normal * p204:Dot(Normal);

    if v214.Magnitude < 0.05 then
        return;
    end;

    local Unit = v214.Unit;
    local LENGTH_MIN = v210.LENGTH_MIN;
    local LENGTH_MAX = v210.LENGTH_MAX;
    local v215 = (LENGTH_MIN + math.random() * (LENGTH_MAX - LENGTH_MIN)) * p206;
    local WIDTH_MIN = v210.WIDTH_MIN;
    local WIDTH_MAX = v210.WIDTH_MAX;
    local v216 = (WIDTH_MIN + math.random() * (WIDTH_MAX - WIDTH_MIN)) * p206;
    local THICKNESS_MIN = v210.THICKNESS_MIN;
    local THICKNESS_MAX = v210.THICKNESS_MAX;
    local v217 = (THICKNESS_MIN + math.random() * (THICKNESS_MAX - THICKNESS_MIN)) * p206;
    local RISE_MIN = v210.RISE_MIN;
    local RISE_MAX = v210.RISE_MAX;
    local v218 = RISE_MIN + math.random() * (RISE_MAX - RISE_MIN);
    local v219 = -v210.SHEAR_HEIGHT;
    local SHEAR_HEIGHT = v210.SHEAR_HEIGHT;
    local v220 = v219 + math.random() * (SHEAR_HEIGHT - v219);
    local v221 = v211.Position + Normal * (v217 * 0.25 + v220) - Normal * v218;
    local v222 = -v210.SHEAR_TILT;
    local SHEAR_TILT = v210.SHEAR_TILT;
    local v223 = v222 + math.random() * (SHEAR_TILT - v222);
    local math_rad_ret = math.rad(v223);
    local v224 = -v210.SHEAR_YAW;
    local SHEAR_YAW = v210.SHEAR_YAW;
    local v225 = v224 + math.random() * (SHEAR_YAW - v224);
    local math_rad_ret2 = math.rad(v225);
    local CANT_MIN = v210.CANT_MIN;
    local CANT_MAX = v210.CANT_MAX;
    local v226 = CANT_MIN + math.random() * (CANT_MAX - CANT_MIN);
    local v227 = p205 * math.rad(v226);
    spawnLayeredSlab(v210, CFrame.lookAt(v221, v221 + Unit, Normal) * CFrame.Angles(math_rad_ret, math_rad_ret2, v227), Vector3.new(v216, v217, v215), v212, v213, Normal * v218);
end;

local function SpawnDragDust(p228, p229, p230) -- Line: 993
    -- upvalues: u7 (copy), GlobalFunctions (copy), Meshes (copy), Visuals (copy), Debris (copy)
    local v231 = u7;
    local v232 = GlobalFunctions.CastRay(p228 + Vector3.new(0, 6, 0), Vector3.new(0, -(6 + u7.PROBE_DOWN), 0), p230, true);

    if not v232 then
        return;
    end;

    local v233 = Meshes.Crater.Dust:Clone();
    v233.Parent = Visuals;
    v233.CFrame = CFrame.new(v232.Position + v232.Normal * 0.5);
    Debris:AddItem(v233, 6);
    local Color = v232.Instance.Color;
    v233.Effect.Color = ColorSequence.new({ ColorSequenceKeypoint.new(0, Color), ColorSequenceKeypoint.new(0.5, Color), ColorSequenceKeypoint.new(1, Color) });
    local DUST_SIZE_MIN = v231.DUST_SIZE_MIN;
    local DUST_SIZE_MAX = v231.DUST_SIZE_MAX;
    local v234 = (DUST_SIZE_MIN + math.random() * (DUST_SIZE_MAX - DUST_SIZE_MIN)) * p229;
    v233.Effect.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, v234), NumberSequenceKeypoint.new(0.5, v234 * 0.35), NumberSequenceKeypoint.new(1, 0) });
    local Effect = v233.Effect;
    local DUST_EMIT_MIN = v231.DUST_EMIT_MIN;
    local DUST_EMIT_MAX = v231.DUST_EMIT_MAX;
    local v235 = DUST_EMIT_MIN + math.random() * (DUST_EMIT_MAX - DUST_EMIT_MIN);
    Effect:Emit((math.floor(v235)));
end;

local u236 = setmetatable({}, {
    __mode = "k"
});

local function MakeDragTrail(u237, p238) -- Line: 1036
    -- upvalues: u7 (copy), u3 (copy), u236 (copy), GlobalFunctions (copy), SpawnDragSlab (copy), SpawnDragDust (copy)
    local v239 = p238 or {};
    local u240 = u7;
    local u241;

    if u237 then
        u241 = u237:FindFirstChild("HumanoidRootPart");
    else
        u241 = u237;
    end;

    if not u241 then
        return;
    end;

    local v242 = tonumber(v239.ImpactScale);
    local u243 = (not v242 or v242 ~= v242) and 1 or math.clamp(v242, 0.5, 1.35);
    local SurfaceMaterial = v239.SurfaceMaterial;
    local SurfaceColor = v239.SurfaceColor;
    local u244 = v239.Duration or u240.MAX_DURATION;
    local u245 = u3.RAY_BLACKLIST();
    local u246 = {};
    u236[u237] = u246;
    task.spawn(function() -- Line: 1051
        -- upvalues: u241 (copy), u236 (ref), u237 (copy), u246 (copy), u244 (copy), u240 (copy), u245 (copy), GlobalFunctions (ref), u7 (ref), u243 (copy), SpawnDragSlab (ref), SurfaceMaterial (copy), SurfaceColor (copy), SpawnDragDust (ref)
        local os_clock_ret = os.clock();
        local Position = u241.Position;
        local Position2 = u241.Position;
        local v247 = 0;
        local v248 = 0;
        local v249 = 1;
        local v250 = nil;

        while true do
            local task_wait_ret = task.wait();

            if u236[u237] ~= u246 or not u241.Parent then
                break;
            end;

            local v251 = os.clock() - os_clock_ret;

            if u244 < v251 or u240.MAX_SEGMENT_PAIRS <= v247 then
                break;
            end;

            local Position3 = u241.Position;
            local v252 = (Position3 - Position2).Magnitude / math.max(task_wait_ret, 0.004166666666666667);

            if u240.START_GRACE < v251 and v252 < u240.MIN_SPEED then
                break;
            end;

            local v253 = GlobalFunctions.CastRay(Position3 + Vector3.new(0, 6, 0), Vector3.new(0, -(6 + u7.PROBE_DOWN), 0), u245, true);
            local v254;

            if v253 == nil then
                v254 = false;
            else
                v254 = Position3.Y - v253.Position.Y <= u240.AIRBORNE_HEIGHT;
            end;

            if v254 then
                v250 = nil;
                local v255 = Position3 - Position;
                local Magnitude = v255.Magnitude;

                if u240.SEGMENT_SPACING <= Magnitude then
                    local v256 = v255 / Magnitude;
                    local v257 = v256:Cross(Vector3.new(0, 1, 0));

                    if v257.Magnitude > 0.05 then
                        local Unit = v257.Unit;
                        local math_floor_ret = math.floor(Magnitude / u240.SEGMENT_SPACING);
                        local math_clamp_ret = math.clamp(math_floor_ret, 1, 4);
                        Position2 = Position3;

                        for i = 1, math_clamp_ret do
                            if u240.MAX_SEGMENT_PAIRS <= v247 then
                                break;
                            end;

                            local v258 = Position + v255 * (i / math_clamp_ret);
                            local _ = i;

                            for _, v in ipairs({ -1, 1 }) do
                                local v259 = -u240.SIDE_VARIANCE;
                                local SIDE_VARIANCE = u240.SIDE_VARIANCE;
                                local v260 = (u240.SIDE_OFFSET + (v259 + math.random() * (SIDE_VARIANCE - v259))) * u243;
                                task.spawn(SpawnDragSlab, v258 + Unit * v260 * v, v256, v, u243, SurfaceMaterial, SurfaceColor, u245);
                            end;

                            v247 = v247 + 1;
                            v248 = v248 + 1;

                            if u240.DUST_EVERY <= v248 then
                                v249 = -v249;
                                task.spawn(SpawnDragDust, v258 + Unit * u240.SIDE_OFFSET * u243 * v249, u243, u245);
                                v248 = 0;
                            end;
                        end;
                    else
                        Position2 = Position3;
                    end;
                else
                    Position2 = Position3;
                    Position3 = Position;
                end;
            else
                v250 = v250 or os.clock();

                if os.clock() - v250 > u240.AIRBORNE_FORGIVE then
                    break;
                end;

                Position2 = Position3;
            end;

            Position = Position3;
        end;

        if u236[u237] == u246 then
            u236[u237] = nil;
        end;
    end);
end;

return {
    CreateCrater = function(p261, p262) -- Line: 1160, Name: CreateCrater
        -- upvalues: MakeCrater (copy)
        MakeCrater(p261.CFrame, p262);
    end,

    CreateCraterAtPoint = function(p263, p264) -- Line: 1164, Name: CreateCraterAtPoint
        -- upvalues: MakeCrater (copy)
        MakeCrater(p263, p264);
    end,

    CreateWallCrater = function(p265, p266) -- Line: 1168, Name: CreateWallCrater
        -- upvalues: MakeWallCrater (copy)
        MakeWallCrater(p265, p266);
    end,

    CreateDragTrail = function(p267, p268) -- Line: 1180, Name: CreateDragTrail
        -- upvalues: MakeDragTrail (copy)
        MakeDragTrail(p267, p268);
    end,

    StopDragTrail = function(p269) -- Line: 1186, Name: StopDragTrail
        -- upvalues: u236 (copy)
        u236[p269] = nil;
    end
};