-- Decompiled with Potassium's decompiler.

local ReplicatedStorage = game:GetService("ReplicatedStorage");
game:GetService("UserInputService");
game:GetService("Debris");
game:GetService("Players");
local Modules = ReplicatedStorage:WaitForChild("Modules");
ReplicatedStorage:WaitForChild("Remotes");
local Assets = ReplicatedStorage.Assets;
local _ = Modules.Metadata;
local Shared = Modules.Shared;
local Utility = Modules.Utility;
require(Utility.Create);
local ReplicationModule = require(Utility.ReplicationModule);
local Invisibility = require(Modules.Effects.VfxHandler.Invisibility);
require(Modules.GlobalFunctions);
require(Shared.SoundManager);
local _ = workspace.World.Visuals;
local _ = Assets.Effects.Particles;

return {
    new = function(u1, p2) -- Line: 37, Name: new
        -- upvalues: Invisibility (copy), ReplicationModule (copy)
        local u3 = p2 or 0.7;
        coroutine.resume(coroutine.create(function() -- Line: 39
            -- upvalues: Invisibility (ref), u1 (copy), u3 (ref), ReplicationModule (ref)
            Invisibility.Invis(u1, u3);
            ReplicationModule.FireMultipleClient(u1, "ClientRemote", {
                Module = "Z_VanishVFX",
                Function = "Vanish",
                Character = u1,
                Vanish_Time = u3
            });
        end));
    end
};