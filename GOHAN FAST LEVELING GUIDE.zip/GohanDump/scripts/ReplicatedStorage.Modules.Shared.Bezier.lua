-- Decompiled with Potassium's decompiler.

local u1 = {};

function length(p2, p3, ...)
    local v4 = {};
    local v5 = 0;
    local v6 = {};

    for i = 0, p2 - 1 do
        local v7 = p3(i / p2, ...);
        local v8 = p3((i + 1) / p2, ...);
        local magnitude = (v8 - v7).magnitude;
        v4[v5] = { magnitude, v7, v8 };
        table.insert(v6, v5);
        v5 = v5 + magnitude;
        local _ = i;
    end;

    return v5, v4, v6;
end;

function u1.new(p9, p10, ...) -- Line: 15
    -- upvalues: u1 (copy)
    local v11 = setmetatable({}, {
        __index = u1
    });
    local v12, v13, v14 = length(p10, p9, ...);
    v11.func = p9;
    v11.n = p10;
    v11.points = { ... };
    v11.length = v12;
    v11.ranges = v13;
    v11.sums = v14;

    return v11;
end;

function u1.setPoints(p15, ...) -- Line: 27
    local v16, v17, v18 = length(p15.n, p15.func, ...);
    p15.points = { ... };
    p15.length = v16;
    p15.ranges = v17;
    p15.sums = v18;
end;

function u1.calc(p19, p20) -- Line: 36
    return p19.func(p20, unpack(p19.points));
end;

function u1.calcFixed(p21, p22) -- Line: 41
    local v23 = p22 * p21.length;
    local v24 = 0;

    for _, v in next, p21.sums do
        if v23 - v < 0 then
            break;
        end;

        v24 = v;
    end;

    local v25 = p21.ranges[v24];

    return v25[2] + (v25[3] - v25[2]) * ((v23 - v24) / v25[1]);
end;

function u1.quadBezier(p26, p27, p28, p29) -- Line: 52
    return (1 - p26) ^ 2 * p27 + 2 * (1 - p26) * p26 * p28 + p26 ^ 2 * p29;
end;

return u1;