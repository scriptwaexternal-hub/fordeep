-- Decompiled with Potassium's decompiler.

local Parent = require(script.Parent.Parent);
local BaseClass = require(script.Parent:WaitForChild("BaseClass"));
require(script.Parent:WaitForChild("Button"));
require(script.Parent:WaitForChild("Menu"));
local u1 = {
    Value = "Default",
    Choices = { "Default", "Choice A", "Choice B", "Choice C" },
    FontFace = Parent.Theme.Font
};

local function getName(p2) -- Line: 17
    -- upvalues: Parent (copy)
    local v3 = tostring(p2);
    local v4 = typeof(p2);

    if v4 == "EnumItem" or v4 == "Instance" then
        return p2.Name;
    end;

    if v4 == "Font" then
        return Parent.getFontName(p2);
    end;

    if v4 == "table" then
        v3 = p2.Name or p2.name;
    end;

    return v3;
end;

local u5 = {};
u5.__index = u5;
setmetatable(u5, BaseClass);

function u5.new(p6) -- Line: 36
    -- upvalues: u1 (copy), Parent (copy), u5 (copy)
    local table_clone_ret = table.clone(u1);
    Parent.makeStatefulDefaults(table_clone_ret, p6);
    local u16 = Parent.compute(function() -- Line: 40
        -- upvalues: table_clone_ret (copy), Parent (ref)
        local v7 = table_clone_ret.Choices();
        local v8 = table_clone_ret.FontFace();
        local v9 = Parent.Theme.FontSize();
        local v10;

        if table_clone_ret.Padding then
            v10 = table_clone_ret.Padding().Offset;
        else
            v10 = Parent.Theme.Padding().Offset;
        end;

        local GetTextBoundsParams = Instance.new("GetTextBoundsParams");
        GetTextBoundsParams.Size = v9;
        GetTextBoundsParams.Width = (1 / 0);
        GetTextBoundsParams.RichText = true;
        local v11 = v9;

        for _, v in v7 do
            local v12, v13, v14, v15;

            if typeof(v) == "Font" then
                v8 = v;
                GetTextBoundsParams.Font = v8;
                v12 = tostring(v);
                v13 = typeof(v);

                if v13 == "EnumItem" or v13 == "Instance" then
                    v12 = v.Name;
                elseif v13 == "Font" then
                    v12 = Parent.getFontName(v);
                elseif v13 == "table" then
                    v12 = v.Name or v.name;
                end;

                GetTextBoundsParams.Text = v12;
                v14 = Parent.retryGetTextBoundsAsync(GetTextBoundsParams).X;
                v15 = math.ceil(v14);
                v9 = math.max(v9, v15);
            else
                if typeof(v) ~= "EnumItem" then
                    GetTextBoundsParams.Font = v8;
                    v12 = tostring(v);
                    v13 = typeof(v);

                    if v13 == "EnumItem" or v13 == "Instance" then
                        v12 = v.Name;
                    elseif v13 == "Font" then
                        v12 = Parent.getFontName(v);
                    elseif v13 == "table" then
                        v12 = v.Name or v.name;
                    end;

                    GetTextBoundsParams.Text = v12;
                    v14 = Parent.retryGetTextBoundsAsync(GetTextBoundsParams).X;
                    v15 = math.ceil(v14);
                    v9 = math.max(v9, v15);
                end;

                if v.Name ~= "Unknown" then
                    if v.EnumType == Enum.Font then
                        v8 = Font.fromEnum(v);
                    end;

                    GetTextBoundsParams.Font = v8;
                    v12 = tostring(v);
                    v13 = typeof(v);

                    if v13 == "EnumItem" or v13 == "Instance" then
                        v12 = v.Name;
                    elseif v13 == "Font" then
                        v12 = Parent.getFontName(v);
                    elseif v13 == "table" then
                        v12 = v.Name or v.name;
                    end;

                    GetTextBoundsParams.Text = v12;
                    v14 = Parent.retryGetTextBoundsAsync(GetTextBoundsParams).X;
                    v15 = math.ceil(v14);
                    v9 = math.max(v9, v15);
                end;
            end;
        end;

        return UDim2.fromOffset(v9 + v10 * 2 + v11, v11 + v10);
    end);
    local v20 = Parent.new("Button")({
        Name = "Header",
        ActiveSound = false,
        IconRightAlign = true,
        BackgroundColor3 = Parent.Theme.Secondary,
        BackgroundTransparency = Parent.Theme.TransparencyHeavy,
        Icon = Parent.Theme.Image.Down,
        IconProperties = {
            ImageColor3 = Parent.Theme.PrimaryText,
            Position = UDim2.new(0.5, 0, 0.5, 1),
            Size = UDim2.fromScale(0.5, 0.5)
        },

        Label = function() -- Line: 85, Name: Label
            -- upvalues: table_clone_ret (copy), Parent (ref)
            local v17 = table_clone_ret.Value();
            local v18 = tostring(v17);
            local v19 = typeof(v17);

            if v19 == "EnumItem" or v19 == "Instance" then
                return v17.Name;
            end;

            if v19 == "Font" then
                return Parent.getFontName(v17);
            end;

            if v19 == "table" then
                v18 = v17.Name or v17.name;
            end;

            return v18;
        end,

        Size = u16,
        FontFace = table_clone_ret.FontFace,
        TextXAlignment = Enum.TextXAlignment.Left,

        Activated = function() -- Line: 92, Name: Activated
            -- upvalues: Parent (ref), table_clone_ret (copy)
            Parent.toggleState(table_clone_ret.menu.Visible, "floating");

            if Parent.raw(table_clone_ret.menu.Visible) then
                Parent.Sound.Hover03:Play();

                return;
            end;

            Parent.Sound.Hover01:Play();
        end
    });
    Parent.edit(v20._content.Label.UIPadding, {
        PaddingRight = UDim.new()
    });
    local v21 = { u16 };
    table_clone_ret._instance = Parent.new("Frame")({
        ZIndex = 100,
        Name = "Select",
        BackgroundTransparency = 1,
        Size = u16,
        v20,
        [Parent.Clean] = v21
    });
    local u22 = Parent.state(table_clone_ret._instance, "AbsoluteSize");
    table.insert(v21, u22);
    table_clone_ret.menu = Parent.new("Menu")({
        Adornee = table_clone_ret._instance,

        Size = function() -- Line: 121, Name: Size
            -- upvalues: u22 (copy), table_clone_ret (copy), u16 (copy)
            local UDim2_new = UDim2.new;
            local X = u22().X;
            local v23 = #table_clone_ret.Choices();

            return UDim2_new(0, X, 0, math.min(v23, 7.5) * u16().Y.Offset);
        end
    });
    table.insert(v21, table_clone_ret.menu);
    Parent.edit(table_clone_ret.menu._instance.UICorner, {
        CornerRadius = Parent.Theme.CornerPadded
    });
    local u24 = {};
    local u25 = nil;

    local function updateChoices() -- Line: 134
        -- upvalues: table_clone_ret (copy), Parent (ref), u16 (copy), u25 (ref), u24 (copy)
        local _value = table_clone_ret.Value._value;

        for i, v in table_clone_ret.Choices._value do
            local v26 = tostring(v);
            local v27 = typeof(v);

            if v27 == "EnumItem" or v27 == "Instance" then
                v26 = v.Name;
            elseif v27 == "Font" then
                v26 = Parent.getFontName(v);
            elseif v27 == "table" then
                v26 = v.Name or v.name;
            end;

            local v28 = nil;
            local u29;

            if typeof(v) == "Font" then
                v28 = v;
                u29 = nil;
                u29 = Parent.new("Button")({
                    ZIndex = 1000,
                    LayoutOrder = math.min(2147483647, i),
                    Parent = table_clone_ret.menu._content,
                    Name = tostring(v26),
                    Label = v26,
                    FontFace = v28,
                    TextSize = Parent.Theme.FontSize,
                    TextXAlignment = Enum.TextXAlignment.Left,
                    Size = u16,

                    Activated = function() -- Line: 162, Name: Activated
                        -- upvalues: u25 (ref), u29 (ref), table_clone_ret (ref), v (copy), Parent (ref)
                        u25 = u29._instance;
                        table_clone_ret.Value(v, true);
                        Parent.deactivateState(table_clone_ret.menu.Visible, "floating");
                    end
                });
                u29._instance:FindFirstChildOfClass("UIStroke"):Destroy();
                Parent.edit(u29._instance, {
                    BackgroundColor3 = function() -- Line: 170, Name: BackgroundColor3
                        -- upvalues: u29 (ref), table_clone_ret (ref), v (copy), Parent (ref)
                        local v30 = u29._hovering();

                        if table_clone_ret.Value() == v and not v30 then
                            return Parent.Theme.Secondary();
                        end;

                        if v30 or Parent.Theme.Transparency() > 0 then
                            return Parent.Theme.Secondary();
                        end;

                        return Parent.Theme.Primary();
                    end,

                    BackgroundTransparency = function() -- Line: 177, Name: BackgroundTransparency
                        -- upvalues: u29 (ref), Parent (ref), table_clone_ret (ref), v (copy)
                        return not (u29._hovering() or (Parent.Theme.Transparency() <= 0 or table_clone_ret.Value() == v)) and 1 or Parent.Theme.TransparencyHeavy();
                    end
                });
                table.insert(u24, u29._hovering:Connect(function(p31) -- Line: 187
                    -- upvalues: Parent (ref)
                    if p31 then
                        Parent.Sound.Hover02:Play();
                    end;
                end));

                if v == _value then
                    u25 = u29._instance;
                end;
            end;

            if typeof(v) == "EnumItem" then
                if v.Name ~= "Unknown" then
                    if v.EnumType == Enum.Font then
                        v28 = Font.fromEnum(v);
                    end;

                    u29 = nil;
                    u29 = Parent.new("Button")({
                        ZIndex = 1000,
                        LayoutOrder = math.min(2147483647, i),
                        Parent = table_clone_ret.menu._content,
                        Name = tostring(v26),
                        Label = v26,
                        FontFace = v28,
                        TextSize = Parent.Theme.FontSize,
                        TextXAlignment = Enum.TextXAlignment.Left,
                        Size = u16,

                        Activated = function() -- Line: 162, Name: Activated
                            -- upvalues: u25 (ref), u29 (ref), table_clone_ret (ref), v (copy), Parent (ref)
                            u25 = u29._instance;
                            table_clone_ret.Value(v, true);
                            Parent.deactivateState(table_clone_ret.menu.Visible, "floating");
                        end
                    });
                    u29._instance:FindFirstChildOfClass("UIStroke"):Destroy();
                    Parent.edit(u29._instance, {
                        BackgroundColor3 = function() -- Line: 170, Name: BackgroundColor3
                            -- upvalues: u29 (ref), table_clone_ret (ref), v (copy), Parent (ref)
                            local v30 = u29._hovering();

                            if table_clone_ret.Value() == v and not v30 then
                                return Parent.Theme.Secondary();
                            end;

                            if v30 or Parent.Theme.Transparency() > 0 then
                                return Parent.Theme.Secondary();
                            end;

                            return Parent.Theme.Primary();
                        end,

                        BackgroundTransparency = function() -- Line: 177, Name: BackgroundTransparency
                            -- upvalues: u29 (ref), Parent (ref), table_clone_ret (ref), v (copy)
                            return not (u29._hovering() or (Parent.Theme.Transparency() <= 0 or table_clone_ret.Value() == v)) and 1 or Parent.Theme.TransparencyHeavy();
                        end
                    });
                    table.insert(u24, u29._hovering:Connect(function(p31) -- Line: 187
                        -- upvalues: Parent (ref)
                        if p31 then
                            Parent.Sound.Hover02:Play();
                        end;
                    end));

                    if v == _value then
                        u25 = u29._instance;
                    end;
                end;
            else
                u29 = nil;
                u29 = Parent.new("Button")({
                    ZIndex = 1000,
                    LayoutOrder = math.min(2147483647, i),
                    Parent = table_clone_ret.menu._content,
                    Name = tostring(v26),
                    Label = v26,
                    FontFace = v28,
                    TextSize = Parent.Theme.FontSize,
                    TextXAlignment = Enum.TextXAlignment.Left,
                    Size = u16,

                    Activated = function() -- Line: 162, Name: Activated
                        -- upvalues: u25 (ref), u29 (ref), table_clone_ret (ref), v (copy), Parent (ref)
                        u25 = u29._instance;
                        table_clone_ret.Value(v, true);
                        Parent.deactivateState(table_clone_ret.menu.Visible, "floating");
                    end
                });
                u29._instance:FindFirstChildOfClass("UIStroke"):Destroy();
                Parent.edit(u29._instance, {
                    BackgroundColor3 = function() -- Line: 170, Name: BackgroundColor3
                        -- upvalues: u29 (ref), table_clone_ret (ref), v (copy), Parent (ref)
                        local v30 = u29._hovering();

                        if table_clone_ret.Value() == v and not v30 then
                            return Parent.Theme.Secondary();
                        end;

                        if v30 or Parent.Theme.Transparency() > 0 then
                            return Parent.Theme.Secondary();
                        end;

                        return Parent.Theme.Primary();
                    end,

                    BackgroundTransparency = function() -- Line: 177, Name: BackgroundTransparency
                        -- upvalues: u29 (ref), Parent (ref), table_clone_ret (ref), v (copy)
                        return not (u29._hovering() or (Parent.Theme.Transparency() <= 0 or table_clone_ret.Value() == v)) and 1 or Parent.Theme.TransparencyHeavy();
                    end
                });
                table.insert(u24, u29._hovering:Connect(function(p31) -- Line: 187
                    -- upvalues: Parent (ref)
                    if p31 then
                        Parent.Sound.Hover02:Play();
                    end;
                end));

                if v == _value then
                    u25 = u29._instance;
                end;
            end;
        end;
    end;

    table.insert(v21, table_clone_ret.menu.Visible:Connect(function(p32) -- Line: 202
        -- upvalues: u25 (ref), table_clone_ret (copy)
        if u25 and p32 then
            local Y = u25.AbsoluteSize.Y;
            local v33 = u25.AbsolutePosition.Y + table_clone_ret.menu._content.CanvasPosition.Y;
            local v34 = math.round(table_clone_ret.menu._content.AbsoluteSize.Y / 2 / Y) * Y;
            table_clone_ret.menu._content.CanvasPosition = Vector2.new(0, v33 - table_clone_ret.menu._content.AbsolutePosition.Y - v34);
        end;
    end));
    table.insert(v21, table_clone_ret.Choices:Connect(function(p35) -- Line: 215
        -- upvalues: table_clone_ret (copy), Parent (ref), u24 (copy), updateChoices (copy)
        for _, child in table_clone_ret.menu._content:GetChildren() do
            if not child:IsA("UIBase") then
                child:Destroy();
            end;
        end;

        Parent.cleanup(u24);
        updateChoices();
    end));
    updateChoices();

    return setmetatable(table_clone_ret, u5);
end;

return u5;