-- Decompiled with Potassium's decompiler.

local UI = require(script.Parent:WaitForChild("UI"));
local v1 = {};
v1.__index = v1;
local u2 = { { "DEBUG", "#888" }, { "INFO", "#ccc" }, { "WARN", "#ff0" }, { "ERROR", "#f00" }, { "CHAT", "#0f8" }, { "COMMAND", "#80f" }, { "JOIN", "#0f0" }, { "LEAVE", "#080" }, { "KILL", "#a00" }, { "DEATH", "#800" }, { "DAMAGE", "#a80" }, { "PURCHASE", "#0ff" }, { "GLOBAL 🌐", "#fff" } };
local u3 = {};

for _, v in u2 do
    local v4, v5 = unpack(v);
    u3[v4] = v5;
end;

function v1.new(u6) -- Line: 32
    -- upvalues: UI (copy), u3 (copy), u2 (copy)
    local function createItem(p7, p8) -- Line: 33
        -- upvalues: UI (ref)
        local u9 = UI.new("Tooltip")({
            Text = "Loading..."
        });
        local v10 = { u9 };
        local u11 = {
            _instance = UI.new("TextBox")({
                AutoLocalize = false,
                BackgroundColor3 = UI.Theme.PrimaryText,
                BackgroundTransparency = 1,
                Size = p7.ItemSize,
                TextEditable = false,
                ClearTextOnFocus = false,
                FontFace = UI.Theme.FontMono,
                Text = "",
                TextSize = UI.Theme.FontSize,
                TextColor3 = UI.Theme.Primary,
                TextTransparency = 0.5,
                TextTruncate = Enum.TextTruncate.SplitWord,
                TextXAlignment = Enum.TextXAlignment.Left,
                TextYAlignment = Enum.TextYAlignment.Center,
                u9,
                UI.new("TextLabel")({
                    AutoLocalize = false,
                    BackgroundTransparency = 1,
                    RichText = true,
                    Text = "Log failed to render.",
                    TextTransparency = 0,
                    Size = p7.ItemSize,
                    FontFace = UI.Theme.FontMono,
                    TextSize = UI.Theme.FontSize,
                    TextColor3 = UI.Theme.PrimaryText,
                    TextStrokeColor3 = UI.Theme.Primary,
                    TextStrokeTransparency = UI.Theme.TextStrokeTransparency,
                    TextTruncate = Enum.TextTruncate.SplitWord,
                    TextXAlignment = Enum.TextXAlignment.Left,
                    TextYAlignment = Enum.TextYAlignment.Center
                })
            }),
            tipText = "",
            [UI.Clean] = v10
        };
        table.insert(v10, u9.Visible:Connect(function() -- Line: 84
            -- upvalues: u9 (copy), u11 (copy)
            if u9.Visible._value then
                u9.Text(u11.tipText);
            end;
        end));

        return u11;
    end;

    local escapeRichText = u6.Util.String.escapeRichText;

    local function renderItem(p12, p13, p14) -- Line: 96
        -- upvalues: u6 (copy), escapeRichText (copy), u3 (ref)
        if not p14.filterText or #p14 < 3 then
            return;
        end;

        local _instance = p13._instance;
        local os_date_ret = os.date("%y-%m-%d", p14[3]);
        local os_date_ret2 = os.date("%X", p14[3]);
        local v15 = u6.Logger:decode(p14[2]);
        local v16 = p14[6] == false and " 🌐" or "";
        local v17 = `<font transparency="0.5">{escapeRichText(os_date_ret2)}</font>{v16} <font color="{u3[v15] or "#fff"}"><b>{v15}</b></font><b>{p14[6] and " <font color=\'#0bb\'><b>CLIENT</b></font>" or ((p14[5] or p14[6] ~= nil) and "" or " <font color=\'#b60\'><b>SERVER</b></font>")}</b>`;
        local v18 = `{not p14[5] and "" or `<font transparency='0.5'>{p14[5]}:</font> `}{escapeRichText(p14[1] or "")}`;
        p13.tipText = `<font transparency="0.5">{os_date_ret}</font> {v17}\n{v18}`;
        local v19 = `{os_date_ret2}{v16} {v15}{p14[6] and " CLIENT" or ((p14[5] or p14[6] ~= nil) and "" or " SERVER")} {not p14[5] and "" or p14[5] .. ": "}{p14[1]}`;

        if p12._noFilter then
            _instance.Text = v19;
            _instance.TextLabel.Text = `{v17} {v18}`;

            return;
        end;

        local string_find_ret, v20 = string.find(p14.filterText, p12._filter, 1, true);
        local v21 = `{os_date_ret} {v19}`;
        _instance.Text = `{os_date_ret2}{v16} {v15}{p14[6] and " CLIENT" or ((p14[5] or p14[6] ~= nil) and "" or " SERVER")} {not p14[5] and "" or p14[5] .. ": "}{p14[1]}`;
        _instance.TextLabel.Text = `<font transparency="0.5">{escapeRichText((string.sub(v21, 1, string_find_ret - 1)))}</font><b>{escapeRichText((string.sub(v21, string_find_ret, v20)))}</b><font transparency="0.5">{escapeRichText((string.sub(v21, v20 + 1)))}</font>`;
    end;

    local u22 = UI.new("ScrollerFast")({
        Name = "Logs",
        Enabled = false,
        FilterInput = true,
        ReverseOrder = true,
        Visible = false,
        List = u6.client.logs,
        CreateItem = createItem,
        RenderItem = renderItem,

        ItemSize = function() -- Line: 150, Name: ItemSize
            -- upvalues: UI (ref)
            return UDim2.new(1, 0, 0, UI.Theme.FontSize() + UI.Theme.Padding().Offset);
        end
    });
    local u23 = {};

    for _, v in u2 do
        u23[v[1]] = UI.state(v[1] ~= "DEBUG" and true or u6.DEBUG);
    end;

    u22.logTypeFilter = u23;
    task.defer(u22.filter, u22, function(p24, p25) -- Line: 162, Name: filterTest
        -- upvalues: u23 (copy), u6 (copy)
        local string_lower_ret = string.lower(p24._input._input.Text);
        p24._filter = string_lower_ret;
        local string_find_ret = string.find(string_lower_ret, "^%s*$");
        p24._noFilter = string_find_ret;
        local _value = u23["GLOBAL 🌐"]._value;
        local v26 = {};

        for _, v in p25 do
            local v27 = u6.Logger:decode(v[2]);

            if not v.filterText then
                local os_date_ret = os.date("%y-%m-%d", v[3]);
                local os_date_ret2 = os.date("%X", v[3]);
                v.filterText = string.lower((`{os_date_ret} {os_date_ret2}{v[6] == false and " 🌐" or ""} {v27}{v[6] and " CLIENT" or ((v[5] or v[6] ~= nil) and "" or " SERVER")} {not v[5] and "" or v[5] .. ": "}{v[1]}`));
            end;

            if u23[v27]._value and (v[6] ~= false or _value) then
                if string_find_ret then
                    table.insert(v26, v);
                elseif string.find(v.filterText, string_lower_ret, 1, true) then
                    table.insert(v26, v);
                end;
            end;
        end;

        return v26;
    end);
    local u28 = nil;
    local v29 = UI.new("Button")({
        LayoutOrder = 3,
        ActiveSound = false,
        Icon = UI.Theme.Image.Filter,
        IconProperties = {
            ImageColor3 = UI.Theme.PrimaryText
        },
        Size = UDim2.new(1, 0, 1, 0),
        SizeConstraint = Enum.SizeConstraint.RelativeYY,
        UI.new("UIPadding")({
            PaddingTop = UI.Theme.Padding,
            PaddingBottom = UI.Theme.Padding,
            PaddingLeft = UI.Theme.Padding,
            PaddingRight = UI.Theme.Padding
        }),

        Activated = function() -- Line: 225, Name: Activated
            -- upvalues: UI (ref), u28 (ref)
            UI.toggleState(u28.Visible, "floating");

            if UI.raw(u28.Visible) then
                UI.Sound.Hover03:Play();

                return;
            end;

            UI.Sound.Hover01:Play();
        end
    });
    UI.new("Tooltip")({
        Text = "Filter Logs",
        Parent = v29,
        Hovering = v29._hovering
    });
    UI.edit(v29._instance.UICorner, {
        CornerRadius = UI.Theme.CornerPadded
    });
    local v30 = UI.new("Frame")({
        AutomaticSize = Enum.AutomaticSize.Y,
        BackgroundTransparency = 1,
        Size = UDim2.new(1, 0, 0, 0),
        UI.new("UIListLayout")({
            Wraps = true,
            FillDirection = Enum.FillDirection.Horizontal,
            Padding = UI.Theme.Padding,
            SortOrder = Enum.SortOrder.LayoutOrder,
            VerticalAlignment = Enum.VerticalAlignment.Top
        })
    });
    u28 = UI.new("Menu")({
        Adornee = v29._instance,
        AutomaticSize = Enum.AutomaticSize.Y,
        RightAlign = true,

        Size = function() -- Line: 257, Name: Size
            -- upvalues: UI (ref)
            local Offset = UI.Theme.Padding().Offset;

            return UDim2.fromOffset(256 + Offset * 3, 0);
        end,

        UI.new("UIPadding")({
            PaddingTop = UI.Theme.Padding,
            PaddingBottom = UI.Theme.Padding,
            PaddingLeft = UI.Theme.Padding,
            PaddingRight = UI.Theme.Padding
        }),
        v30
    });
    u28._content.AutomaticSize = Enum.AutomaticSize.Y;
    UI.edit(u28._list, {
        Wraps = true,
        FillDirection = Enum.FillDirection.Horizontal,
        Padding = UI.Theme.Padding
    });
    local v31 = UI.compute(function() -- Line: 280
        -- upvalues: UI (ref)
        return UDim2.fromOffset(128, UI.Theme.FontSizeLarger());
    end);

    for i, v in u2 do
        local u32 = v[1];
        UI.new("ListItem")({
            Parent = v30,
            LayoutOrder = i,
            Text = u32,
            Size = v31,
            UI.new("Checkbox")({
                Value = u23[u32],
                [UI.Hook] = {
                    Value = function(p33) -- Line: 296, Name: Value
                        -- upvalues: u22 (copy), u23 (copy), u32 (copy)
                        u22._filterUpdate = true;
                        u23[u32](p33);
                        u22:refreshList();
                    end
                }
            })
        });
    end;

    for i, v in {
        SELECT = true,
        DESELECT = false
    } do
        UI.new("Button")({
            Parent = u28._content,
            LayoutOrder = #u2 + 1,
            Label = `<b>{i} ALL</b>`,
            Size = v31,

            Activated = function() -- Line: 313, Name: Activated
                -- upvalues: u22 (copy), u2 (ref), u23 (copy), v (copy)
                u22._filterUpdate = true;

                for _, v2 in u2 do
                    u23[v2[1]](v);
                    u22:refreshList();
                end;
            end
        });
    end;

    u22._input._instance = UI.new("Frame")({
        Parent = u22,
        Name = "FilterInput",
        BackgroundTransparency = 1,

        Size = function() -- Line: 329, Name: Size
            -- upvalues: UI (ref)
            return UDim2.new(1, 0, 0, UI.Theme.FontSize() + UI.Theme.PaddingDouble().Offset);
        end,

        UI.new("UIListLayout")({
            FillDirection = Enum.FillDirection.Horizontal,
            Padding = UI.Theme.PaddingWithStroke,
            SortOrder = Enum.SortOrder.LayoutOrder
        }),
        UI.edit(u22._input, { UI.new("UIFlexItem")({
                FlexMode = Enum.UIFlexMode.Fill
            }) }),
        v29
    });

    return u22;
end;

return v1;