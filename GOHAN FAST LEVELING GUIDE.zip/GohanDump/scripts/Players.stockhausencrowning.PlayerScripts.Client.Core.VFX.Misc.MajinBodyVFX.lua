-- Decompiled with Potassium's decompiler.

local RunService = game:GetService("RunService");
local LocalPlayer = game:GetService("Players").LocalPlayer;
local v1 = {};
local u2 = nil;

local function release() -- Line: 17
    -- upvalues: u2 (ref), LocalPlayer (copy)
    if u2 then
        u2:Disconnect();
        u2 = nil;
    end;

    local workspace_CurrentCamera = workspace.CurrentCamera;
    local Character = LocalPlayer.Character;
    workspace_CurrentCamera.CameraType = Enum.CameraType.Custom;

    if Character and Character:FindFirstChildOfClass("Humanoid") then
        workspace_CurrentCamera.CameraSubject = Character:FindFirstChildOfClass("Humanoid");
    end;
end;

function v1.Follow(p3) -- Line: 25
    -- upvalues: u2 (ref), LocalPlayer (copy), RunService (copy)
    local u4 = p3 and p3.Part;

    if not u4 then
        local v5 = workspace:FindFirstChild("World") and workspace.World:FindFirstChild("Visuals");
        local os_clock_ret = os.clock();

        while not u4 and os.clock() - os_clock_ret < 1.5 do
            if v5 then
                u4 = v5:FindFirstChild("MajinBlob");
            end;

            if not u4 then
                task.wait(0.03);
            end;
        end;
    end;

    if not u4 then
        return;
    end;

    if u2 then
        u2:Disconnect();
        u2 = nil;
    end;

    local workspace_CurrentCamera = workspace.CurrentCamera;
    local Character = LocalPlayer.Character;
    workspace_CurrentCamera.CameraType = Enum.CameraType.Custom;

    if Character and Character:FindFirstChildOfClass("Humanoid") then
        workspace_CurrentCamera.CameraSubject = Character:FindFirstChildOfClass("Humanoid");
    end;

    local workspace_CurrentCamera2 = workspace.CurrentCamera;
    workspace_CurrentCamera2.CameraType = Enum.CameraType.Scriptable;
    local u6 = -workspace_CurrentCamera2.CFrame.LookVector;
    local Position = workspace_CurrentCamera2.CFrame.Position;
    u2 = RunService.RenderStepped:Connect(function(p7) -- Line: 42
        -- upvalues: u4 (ref), u2 (ref), LocalPlayer (ref), u6 (ref), Position (ref), workspace_CurrentCamera2 (copy)
        if u4.Parent then
            local AssemblyLinearVelocity = u4.AssemblyLinearVelocity;
            local Vector3_new_ret = Vector3.new(AssemblyLinearVelocity.X, 0, AssemblyLinearVelocity.Z);

            if Vector3_new_ret.Magnitude > 1 then
                u6 = -Vector3_new_ret.Unit;
            end;

            Position = Position:Lerp(u4.Position + u6 * 9 + Vector3.new(0, 3.5, 0), 1 - math.exp(-p7 / 0.12));
            workspace_CurrentCamera2.CFrame = CFrame.lookAt(Position, u4.Position);

            return;
        end;

        if u2 then
            u2:Disconnect();
            u2 = nil;
        end;

        local workspace_CurrentCamera3 = workspace.CurrentCamera;
        local Character2 = LocalPlayer.Character;
        workspace_CurrentCamera3.CameraType = Enum.CameraType.Custom;

        if Character2 and Character2:FindFirstChildOfClass("Humanoid") then
            workspace_CurrentCamera3.CameraSubject = Character2:FindFirstChildOfClass("Humanoid");
        end;
    end);
end;

function v1.Release() -- Line: 53
    -- upvalues: u2 (ref), LocalPlayer (copy)
    if u2 then
        u2:Disconnect();
        u2 = nil;
    end;

    local workspace_CurrentCamera = workspace.CurrentCamera;
    local Character = LocalPlayer.Character;
    workspace_CurrentCamera.CameraType = Enum.CameraType.Custom;

    if Character and Character:FindFirstChildOfClass("Humanoid") then
        workspace_CurrentCamera.CameraSubject = Character:FindFirstChildOfClass("Humanoid");
    end;
end;

return v1;