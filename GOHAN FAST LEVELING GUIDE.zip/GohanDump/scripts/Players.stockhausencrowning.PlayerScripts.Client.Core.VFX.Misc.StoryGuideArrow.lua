-- Decompiled with Potassium's decompiler.

local Players = game:GetService("Players");
local ReplicatedStorage = game:GetService("ReplicatedStorage");
local RunService = game:GetService("RunService");
local LocalPlayer = Players.LocalPlayer;
local World = workspace:WaitForChild("World");
local Visuals = World:WaitForChild("Visuals");
local Color3_fromRGB_ret = Color3.fromRGB(196, 40, 28);
local Color3_fromRGB_ret2 = Color3.fromRGB(230, 180, 60);
local v1 = {};
local u2 = nil;
local u3 = nil;
local u4 = nil;
local u5 = nil;
local u6 = 0;

local function enabled() -- Line: 42
    -- upvalues: LocalPlayer (copy)
    local Character = LocalPlayer.Character;

    return not Character or Character:GetAttribute("StoryIcons") ~= false;
end;

local u7 = {
    name = nil,
    at = 0,
    positions = {}
};

local function areaPos(p8, p9) -- Line: 53
    -- upvalues: u7 (ref), World (copy)
    if u7.name ~= p8 or os.clock() - u7.at > 2 then
        u7 = {
            name = p8,
            at = os.clock(),
            positions = {}
        };
        local Map = World:FindFirstChild("Map");

        if Map then
            Map = Map:FindFirstChild("Indicators");
        end;

        if Map then
            for _, descendant in ipairs(Map:GetDescendants()) do
                if descendant.Name == p8 and descendant:FindFirstChild("Marker") then
                    local v10;

                    if descendant:IsA("BasePart") and descendant then
                        v10 = descendant;
                    else
                        v10 = descendant:IsA("Model") and (descendant.PrimaryPart or descendant:FindFirstChildWhichIsA("BasePart", true));
                    end;

                    if v10 then
                        table.insert(u7.positions, v10.Position);
                    end;
                end;
            end;
        end;
    end;

    local v11 = nil;
    local v12 = nil;

    for _, v in ipairs(u7.positions) do
        local v13 = p9 and ((v - p9).Magnitude or 0) or 0;

        if not v11 or v13 < v11 then
            v12 = v;
            v11 = v13;
        end;
    end;

    return v12;
end;

local function objectivePos(p14) -- Line: 76
    -- upvalues: u3 (ref), areaPos (copy), u2 (ref), World (copy)
    local v15 = u3 and areaPos(u3.Name, p14);

    if v15 then
        return v15;
    end;

    if not u2 then
        return nil;
    end;

    local NPC = World:FindFirstChild("NPC");

    if NPC then
        for _, descendant in ipairs(NPC:GetDescendants()) do
            if descendant:IsA("Model") and descendant.Name == u2.Name then
                local v16 = descendant:FindFirstChild("HumanoidRootPart") or (descendant.PrimaryPart or descendant:FindFirstChildWhichIsA("BasePart"));

                if v16 then
                    u2.Position = v16.Position;

                    return v16.Position;
                end;
            end;
        end;
    end;

    return u2.Position;
end;

local function busStops() -- Line: 94
    -- upvalues: World (copy)
    local Map = World:FindFirstChild("Map");

    if Map then
        Map = Map:FindFirstChild("Fast Travel");
    end;

    local v17 = {};

    if not Map then
        return v17;
    end;

    for _, child in ipairs(Map:GetChildren()) do
        local Location = child:FindFirstChild("Location");

        if Location and Location:IsA("BasePart") then
            v17[#v17 + 1] = {
                Name = child.Name,
                Position = Location.Position
            };
        end;
    end;

    return v17;
end;

local function busAim(p18, p19) -- Line: 107
    -- upvalues: busStops (copy)
    local Magnitude = (p18 - p19).Magnitude;
    local v20 = busStops();
    local v21 = nil;
    local v22 = nil;

    for _, v in ipairs(v20) do
        local Magnitude2 = (v.Position - p18).Magnitude;

        if Magnitude2 <= 250 and (not v21 or Magnitude2 < v21) then
            local Magnitude3 = (v.Position - p19).Magnitude;
            local v23 = v;

            for _, v2 in ipairs(v20) do
                if v2 ~= v23 then
                    local Magnitude4 = (v2.Position - p19).Magnitude;

                    if Magnitude4 < Magnitude - 200 and Magnitude4 < Magnitude3 then
                        v22 = v23;
                        v21 = Magnitude2;
                        break;
                    end;
                end;
            end;
        end;
    end;

    return v22;
end;

local function ensureArrow() -- Line: 129
    -- upvalues: u4 (ref), ReplicatedStorage (copy), Visuals (copy)
    if u4 and u4.Parent then
        return u4;
    end;

    local v24 = ReplicatedStorage:FindFirstChild("Assets") and ReplicatedStorage.Assets:FindFirstChild("Models") and ReplicatedStorage.Assets.Models:FindFirstChild("GuideArrow");

    if not v24 then
        return nil;
    end;

    u4 = v24:Clone();
    u4.Name = "StoryGuideArrow";
    u4.Size = v24.Size * 0.45;
    u4.Anchored = true;
    u4.CanCollide = false;
    u4.CanQuery = false;
    u4.CanTouch = false;
    u4.Parent = Visuals;

    return u4;
end;

local function hideArrow() -- Line: 141
    -- upvalues: u4 (ref)
    if u4 then
        u4.Transparency = 1;
    end;
end;

local function step(p25) -- Line: 145
    -- upvalues: LocalPlayer (copy), u2 (ref), u3 (ref), u4 (ref), objectivePos (copy), ensureArrow (copy), busAim (copy), Color3_fromRGB_ret2 (copy), Color3_fromRGB_ret (copy), u6 (ref)
    local Character = LocalPlayer.Character;
    local v26;

    if Character then
        v26 = Character:FindFirstChild("Head");
    else
        v26 = Character;
    end;

    if Character then
        Character = Character:FindFirstChild("HumanoidRootPart");
    end;

    if (u2 or u3) and (v26 and Character) then
        local Character2 = LocalPlayer.Character;

        if not Character2 or Character2:GetAttribute("StoryIcons") ~= false then
            local Position = Character.Position;
            local v27 = objectivePos(Position);

            if not v27 then
                if u4 then
                    u4.Transparency = 1;
                end;

                return;
            end;

            if (Position - v27).Magnitude <= 14 then
                if u4 then
                    u4.Transparency = 1;
                end;

                return;
            end;

            local v28 = ensureArrow();

            if not v28 then
                return;
            end;

            local v29 = busAim(Position, v27);

            if v29 then
                v27 = v29.Position or v27;
            end;

            v28.Color = v29 and Color3_fromRGB_ret2 or Color3_fromRGB_ret;
            v28.Transparency = 0.35;
            u6 = u6 + p25 * 2.5;
            local Position2 = v26.Position;
            local v30 = math.sin(u6) * 0.2 + 3.4;
            local v31 = Position2 + Vector3.new(0, v30, 0);
            local Vector3_new_ret = Vector3.new(v27.X, v31.Y, v27.Z);

            if (Vector3_new_ret - v31).Magnitude < 0.5 then
                Vector3_new_ret = v31 + Character.CFrame.LookVector;
            end;

            v28.CFrame = CFrame.lookAt(v31, Vector3_new_ret) * CFrame.Angles(0, 1.5707963267948966, 0);

            return;
        end;
    end;

    if u4 then
        u4.Transparency = 1;
    end;
end;

function v1.Set(p32, p33) -- Line: 169
    -- upvalues: u2 (ref), u5 (ref), RunService (copy), step (copy)
    if type(p32) ~= "string" then
        return;
    end;

    u2 = {
        Name = p32,
        Position = typeof(p33) == "Vector3" and p33 and p33 or nil
    };

    if not u5 then
        u5 = RunService.Heartbeat:Connect(step);
    end;
end;

function v1.Clear(p34) -- Line: 175
    -- upvalues: u2 (ref), u3 (ref), u5 (ref), u4 (ref)
    if p34 and (u2 and u2.Name ~= p34) then
        return;
    end;

    u2 = nil;

    if u3 then
        return;
    end;

    if u5 then
        u5:Disconnect();
        u5 = nil;
    end;

    if u4 then
        u4:Destroy();
        u4 = nil;
    end;
end;

function v1.SetArea(p35) -- Line: 184
    -- upvalues: u3 (ref), u5 (ref), RunService (copy), step (copy)
    if type(p35) ~= "string" then
        return;
    end;

    u3 = {
        Name = p35
    };

    if not u5 then
        u5 = RunService.Heartbeat:Connect(step);
    end;
end;

function v1.ClearArea(p36) -- Line: 190
    -- upvalues: u3 (ref), u2 (ref), u5 (ref), u4 (ref)
    if p36 and (u3 and u3.Name ~= p36) then
        return;
    end;

    u3 = nil;

    if u2 then
        return;
    end;

    if u5 then
        u5:Disconnect();
        u5 = nil;
    end;

    if u4 then
        u4:Destroy();
        u4 = nil;
    end;
end;

function v1.Current() -- Line: 198
    -- upvalues: u3 (ref), u2 (ref)
    return u3 and u3.Name or (u2 and u2.Name or nil);
end;

LocalPlayer.CharacterRemoving:Connect(function() -- Line: 202
    -- upvalues: u4 (ref)
    if u4 then
        u4.Transparency = 1;
    end;
end);

return v1;