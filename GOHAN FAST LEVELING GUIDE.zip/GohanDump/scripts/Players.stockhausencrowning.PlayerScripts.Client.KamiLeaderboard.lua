-- Decompiled with Potassium's decompiler.

local Players = game:GetService("Players");
local RunService = game:GetService("RunService");
local ReplicatedStorage = game:GetService("ReplicatedStorage");
local LocalPlayer = Players.LocalPlayer;

if game.PlaceId == 89366025586253 then
    return;
end;

local Color3_fromRGB_ret = Color3.fromRGB(44, 44, 45);
local Color3_fromRGB_ret2 = Color3.fromRGB(28, 28, 30);
local Color3_fromRGB_ret3 = Color3.fromRGB(255, 255, 255);
local Color3_fromRGB_ret4 = Color3.fromRGB(0, 0, 0);
local Color3_fromRGB_ret5 = Color3.fromRGB(255, 152, 48);
local Color3_fromRGB_ret6 = Color3.fromRGB(120, 235, 120);
local Arcade = Enum.Font.Arcade;
local Bangers = Enum.Font.Bangers;
local u1 = true;
local u2 = {};

local function stroke(p3, p4) -- Line: 40
    -- upvalues: Color3_fromRGB_ret4 (copy)
    local UIStroke = Instance.new("UIStroke");
    UIStroke.Color = Color3_fromRGB_ret4;
    UIStroke.Thickness = p4 or 2;
    UIStroke.ApplyStrokeMode = Enum.ApplyStrokeMode.Border;
    UIStroke.Parent = p3;

    return UIStroke;
end;

local ScreenGui = Instance.new("ScreenGui");
ScreenGui.Name = "KamiLeaderboardGui";
ScreenGui.ResetOnSpawn = false;
ScreenGui.DisplayOrder = 44;
ScreenGui.Parent = LocalPlayer:WaitForChild("PlayerGui");
local TextButton = Instance.new("TextButton");
TextButton.Name = "Toggle";
TextButton.AnchorPoint = Vector2.new(1, 0);
TextButton.Position = UDim2.new(1, -10, 0.075, 0);
TextButton.Size = UDim2.fromOffset(92, 28);
TextButton.BackgroundColor3 = Color3_fromRGB_ret2;
TextButton.BorderSizePixel = 0;
TextButton.AutoButtonColor = true;
TextButton.Font = Arcade;
TextButton.TextSize = 12;
TextButton.TextColor3 = Color3_fromRGB_ret6;
TextButton.Text = "CLOSE";
TextButton.Parent = ScreenGui;
local UIStroke = Instance.new("UIStroke");
UIStroke.Color = Color3_fromRGB_ret4;
UIStroke.Thickness = 2;
UIStroke.ApplyStrokeMode = Enum.ApplyStrokeMode.Border;
UIStroke.Parent = TextButton;
local Frame = Instance.new("Frame");
Frame.Name = "Panel";
Frame.AnchorPoint = Vector2.new(1, 0);
Frame.Position = UDim2.new(1, -10, 0.075, 34);
Frame.Size = UDim2.fromOffset(210, 300);
Frame.BackgroundColor3 = Color3_fromRGB_ret;
Frame.BorderSizePixel = 0;
Frame.Visible = true;
Frame.Parent = ScreenGui;
local UIStroke2 = Instance.new("UIStroke");
UIStroke2.Color = Color3_fromRGB_ret4;
UIStroke2.Thickness = 3;
UIStroke2.ApplyStrokeMode = Enum.ApplyStrokeMode.Border;
UIStroke2.Parent = Frame;
local TextLabel = Instance.new("TextLabel");
TextLabel.Name = "Header";
TextLabel.Size = UDim2.new(1, 0, 0, 20);
TextLabel.BackgroundColor3 = Color3_fromRGB_ret2;
TextLabel.BorderSizePixel = 0;
TextLabel.Font = Bangers;
TextLabel.TextSize = 15;
TextLabel.TextColor3 = Color3_fromRGB_ret5;
TextLabel.TextStrokeColor3 = Color3_fromRGB_ret4;
TextLabel.TextStrokeTransparency = 0;
TextLabel.Text = "FIGHTERS";
TextLabel.Parent = Frame;
local TextLabel2 = Instance.new("TextLabel");
TextLabel2.Name = "Count";
TextLabel2.AnchorPoint = Vector2.new(1, 0);
TextLabel2.Position = UDim2.new(1, -6, 0, 0);
TextLabel2.Size = UDim2.fromOffset(50, 20);
TextLabel2.BackgroundTransparency = 1;
TextLabel2.Font = Arcade;
TextLabel2.TextSize = 11;
TextLabel2.TextColor3 = Color3_fromRGB_ret6;
TextLabel2.TextXAlignment = Enum.TextXAlignment.Right;
TextLabel2.Text = "";
TextLabel2.Parent = Frame;
local Frame2 = Instance.new("Frame");
Frame2.Name = "Accent";
Frame2.Position = UDim2.fromOffset(0, 20);
Frame2.Size = UDim2.new(1, 0, 0, 2);
Frame2.BackgroundColor3 = Color3_fromRGB_ret6;
Frame2.BorderSizePixel = 0;
Frame2.Parent = Frame;
local ScrollingFrame = Instance.new("ScrollingFrame");
ScrollingFrame.Name = "List";
ScrollingFrame.Position = UDim2.fromOffset(0, 22);
ScrollingFrame.Size = UDim2.new(1, 0, 1, -22);
ScrollingFrame.BackgroundTransparency = 1;
ScrollingFrame.BorderSizePixel = 0;
ScrollingFrame.ScrollBarThickness = 4;
ScrollingFrame.ScrollBarImageColor3 = Color3_fromRGB_ret5;
ScrollingFrame.AutomaticCanvasSize = Enum.AutomaticSize.Y;
ScrollingFrame.CanvasSize = UDim2.new();
ScrollingFrame.Parent = Frame;
local UIPadding = Instance.new("UIPadding");
UIPadding.PaddingTop = UDim.new(0, 6);
UIPadding.PaddingLeft = UDim.new(0, 6);
UIPadding.PaddingRight = UDim.new(0, 8);
UIPadding.PaddingBottom = UDim.new(0, 6);
UIPadding.Parent = ScrollingFrame;
local UIListLayout = Instance.new("UIListLayout");
UIListLayout.Padding = UDim.new(0, 4);
UIListLayout.SortOrder = Enum.SortOrder.Name;
UIListLayout.Parent = ScrollingFrame;

local function ingameName(p5) -- Line: 141
    local Character = p5.Character;

    if Character then
        Character = Character:GetAttribute("CharacterName");
    end;

    if type(Character) == "string" and Character ~= "" then
        return Character;
    end;

    return p5.DisplayName;
end;

local function escRich(p6) -- Line: 149
    return tostring(p6):gsub("&", "&amp;"):gsub("<", "&lt;"):gsub(">", "&gt;");
end;

local function playerTitle(p7) -- Line: 155
    local Character = p7.Character;

    if Character then
        Character = Character:GetAttribute("CharacterTitle");
    end;

    if type(Character) ~= "string" or (Character == "" or not Character) then
        Character = nil;
    end;

    return Character;
end;

local ContractRemote = ReplicatedStorage:WaitForChild("Remotes"):WaitForChild("ContractRemote");
local u8 = {};

local function playerElo(p9) -- Line: 169
    local PlayerStats = p9:FindFirstChild("PlayerStats");

    if PlayerStats then
        PlayerStats = PlayerStats:FindFirstChild("Elo", true);
    end;

    return PlayerStats and PlayerStats.Value or nil;
end;

local function playerRank(p10) -- Line: 174
    -- upvalues: u8 (copy)
    for i, v in pairs(u8) do
        if i:match("^(%d+)_") == tostring(p10.UserId) then
            return v;
        end;
    end;

    return nil;
end;

local function refreshRanks() -- Line: 180
    -- upvalues: ContractRemote (copy), u8 (copy)
    local success, result = pcall(ContractRemote.InvokeServer, ContractRemote, {
        Action = "PvpLeaderboard"
    });

    if not (success and (type(result) == "table" and type(result.list) == "table")) then
        return;
    end;

    table.clear(u8);

    for _, v in ipairs(result.list) do
        if v.Key then
            u8[v.Key] = v.Rank;
        end;
    end;
end;

local function showElo(p11) -- Line: 186
    -- upvalues: u2 (copy), playerRank (copy)
    local v12 = u2[p11];

    if not (v12 and v12.elo) then
        return;
    end;

    local PlayerStats = p11:FindFirstChild("PlayerStats");

    if PlayerStats then
        PlayerStats = PlayerStats:FindFirstChild("Elo", true);
    end;

    local v13 = PlayerStats and PlayerStats.Value or nil;
    local v14 = playerRank(p11);
    v12.elo.Text = v13 and ((v14 and ("#" .. v14 .. "  " or "") or "") .. tostring(v13) or "") or "";
    v12.elo.TextColor3 = v14 and (v14 <= 3 and Color3.fromRGB(250, 204, 90)) or Color3.fromRGB(201, 198, 191);
end;

local function showName(p15) -- Line: 195
    -- upvalues: u2 (copy), Color3_fromRGB_ret6 (copy), LocalPlayer (copy), Color3_fromRGB_ret5 (copy), Color3_fromRGB_ret3 (copy)
    local v16 = u2[p15];

    if not v16 then
        return;
    end;

    if v16.flipped then
        v16.button.Text = tostring("@" .. p15.Name):gsub("&", "&amp;"):gsub("<", "&lt;"):gsub(">", "&gt;");
        v16.button.TextColor3 = Color3_fromRGB_ret6;

        return;
    end;

    local Character = p15.Character;

    if Character then
        Character = Character:GetAttribute("CharacterTitle");
    end;

    if type(Character) ~= "string" or (Character == "" or not Character) then
        Character = nil;
    end;

    if Character then
        local button = v16.button;
        local Character2 = p15.Character;

        if Character2 then
            Character2 = Character2:GetAttribute("CharacterName");
        end;

        if type(Character2) ~= "string" or Character2 == "" then
            Character2 = p15.DisplayName;
        end;

        button.Text = tostring(Character2):gsub("&", "&amp;"):gsub("<", "&lt;"):gsub(">", "&gt;") .. " <font size=\"9\" color=\"#FFB86C\">\"" .. tostring(Character):gsub("&", "&amp;"):gsub("<", "&lt;"):gsub(">", "&gt;") .. "\"</font>";
    else
        local button = v16.button;
        local Character2 = p15.Character;

        if Character2 then
            Character2 = Character2:GetAttribute("CharacterName");
        end;

        if type(Character2) ~= "string" or Character2 == "" then
            Character2 = p15.DisplayName;
        end;

        button.Text = tostring(Character2):gsub("&", "&amp;"):gsub("<", "&lt;"):gsub(">", "&gt;");
    end;

    v16.button.TextColor3 = p15 == LocalPlayer and Color3_fromRGB_ret5 or Color3_fromRGB_ret3;
end;

local function addRow(u17) -- Line: 215
    -- upvalues: u2 (copy), Color3_fromRGB_ret2 (copy), Arcade (copy), ScrollingFrame (copy), Color3_fromRGB_ret4 (copy), showName (copy)
    if u2[u17] then
        return;
    end;

    local TextButton2 = Instance.new("TextButton");
    TextButton2.Name = u17.Name;
    TextButton2.Size = UDim2.new(1, 0, 0, 24);
    TextButton2.BackgroundColor3 = Color3_fromRGB_ret2;
    TextButton2.BorderSizePixel = 0;
    TextButton2.AutoButtonColor = false;
    TextButton2.Font = Arcade;
    TextButton2.TextSize = 11;
    TextButton2.RichText = true;
    TextButton2.TextXAlignment = Enum.TextXAlignment.Left;
    TextButton2.TextTruncate = Enum.TextTruncate.AtEnd;
    TextButton2.Parent = ScrollingFrame;
    local UIStroke3 = Instance.new("UIStroke");
    UIStroke3.Color = Color3_fromRGB_ret4;
    UIStroke3.Thickness = 1;
    UIStroke3.ApplyStrokeMode = Enum.ApplyStrokeMode.Border;
    UIStroke3.Parent = TextButton2;
    local UIPadding2 = Instance.new("UIPadding");
    UIPadding2.PaddingLeft = UDim.new(0, 6);
    UIPadding2.PaddingRight = UDim.new(0, 74);
    UIPadding2.Parent = TextButton2;
    local TextLabel3 = Instance.new("TextLabel");
    TextLabel3.Name = "Elo";
    TextLabel3.BackgroundTransparency = 1;
    TextLabel3.AnchorPoint = Vector2.new(1, 0.5);
    TextLabel3.Position = UDim2.new(1, 68, 0.5, 0);
    TextLabel3.Size = UDim2.new(0, 66, 1, 0);
    TextLabel3.Font = Arcade;
    TextLabel3.TextSize = 10;
    TextLabel3.TextXAlignment = Enum.TextXAlignment.Right;
    TextLabel3.TextColor3 = Color3.fromRGB(201, 198, 191);
    TextLabel3.Text = "";
    TextLabel3.Parent = TextButton2;
    u2[u17] = {
        flipped = false,
        button = TextButton2,
        elo = TextLabel3
    };
    TextButton2.MouseEnter:Connect(function() -- Line: 254
        -- upvalues: u2 (ref), u17 (copy), showName (ref)
        local v18 = u2[u17];

        if v18 then
            v18.flipped = true;
            showName(u17);
        end;
    end);
    TextButton2.MouseLeave:Connect(function() -- Line: 258
        -- upvalues: u2 (ref), u17 (copy), showName (ref)
        local v19 = u2[u17];

        if v19 then
            v19.flipped = false;
            showName(u17);
        end;
    end);
    TextButton2.Activated:Connect(function() -- Line: 263
        -- upvalues: u2 (ref), u17 (copy), showName (ref)
        local v20 = u2[u17];

        if v20 then
            v20.flipped = not v20.flipped;
            showName(u17);
        end;
    end);
    showName(u17);
end;

local function removeRow(p21) -- Line: 271
    -- upvalues: u2 (copy)
    local v22 = u2[p21];

    if not v22 then
        return;
    end;

    u2[p21] = nil;
    v22.button:Destroy();
end;

local function refresh() -- Line: 278
    -- upvalues: Players (copy), TextLabel2 (copy), addRow (copy), showName (copy), showElo (copy)
    local Players2 = Players:GetPlayers();
    TextLabel2.Text = tostring(#Players2);

    for _, v in ipairs(Players2) do
        addRow(v);
        showName(v);
        showElo(v);
    end;
end;

task.spawn(function() -- Line: 295
    -- upvalues: u1 (ref), refreshRanks (copy)
    while true do
        repeat
            task.wait(60);
        until u1;

        pcall(refreshRanks);
    end;
end);
TextButton.Activated:Connect(function() -- Line: 302
    -- upvalues: u1 (ref), Frame (copy), TextButton (copy), Color3_fromRGB_ret6 (copy), Color3_fromRGB_ret5 (copy), refresh (copy)
    u1 = not u1;
    Frame.Visible = u1;
    TextButton.Text = u1 and "CLOSE" or "PLAYERS";
    TextButton.TextColor3 = u1 and Color3_fromRGB_ret6 or Color3_fromRGB_ret5;

    if u1 then
        refresh();
    end;
end);
Players.PlayerAdded:Connect(function(p23) -- Line: 310
    -- upvalues: addRow (copy), refresh (copy)
    addRow(p23);
    refresh();
end);
Players.PlayerRemoving:Connect(function(p24) -- Line: 314
    -- upvalues: u2 (copy), refresh (copy)
    local v25 = u2[p24];

    if v25 then
        u2[p24] = nil;
        v25.button:Destroy();
    end;

    task.defer(refresh);
end);
refresh();
local u26 = 0;
RunService.Heartbeat:Connect(function(p27) -- Line: 325
    -- upvalues: u1 (ref), u26 (ref), refresh (copy)
    if not u1 then
        return;
    end;

    u26 = u26 + p27;

    if u26 < 2 then
        return;
    end;

    u26 = 0;
    refresh();
end);