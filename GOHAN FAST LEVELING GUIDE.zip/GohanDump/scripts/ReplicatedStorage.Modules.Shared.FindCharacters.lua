-- Decompiled with Potassium's decompiler.

local ReplicatedStorage = game:GetService("ReplicatedStorage");
game:GetService("UserInputService");
game:GetService("Debris");
game:GetService("Players");
local Modules = ReplicatedStorage:WaitForChild("Modules");
ReplicatedStorage:WaitForChild("Remotes");
local _ = Modules.Metadata;
local Shared = Modules.Shared;
local _ = Modules.Utility;
require(Modules.GlobalFunctions);
require(Shared.AnimationManager);
local workspace_World = workspace.World;
local _ = workspace_World.Visuals;
local v1 = {};

local function characterOf(p2) -- Line: 35
    while p2 and p2 ~= workspace do
        if p2:IsA("Model") and p2:FindFirstChildOfClass("Humanoid") then
            return p2;
        end;

        p2 = p2.Parent;
    end;

    return nil;
end;

local function collect(p3, p4, p5) -- Line: 55
    -- upvalues: characterOf (copy), workspace_World (copy)
    local v6 = {};
    local v7 = 0;
    local v8 = {};

    for _, v in pairs(p3) do
        local v9 = characterOf(v);

        if v9 and not v6[v9] then
            v6[v9] = true;
            local HumanoidRootPart = v9:FindFirstChild("HumanoidRootPart");
            local v10 = v9:FindFirstChildOfClass("Humanoid");
            local v11;

            if p5 then
                v11 = v9.Parent == workspace_World.Live;
            else
                v11 = v9:FindFirstAncestor("Live") ~= nil;
            end;

            if HumanoidRootPart and (v10 and (v10.Health > 0 and (HumanoidRootPart ~= p4 and v11))) then
                v7 = v7 + 1;
                local Name = v9.Name;

                if v8[Name] ~= nil then
                    Name = Name .. "#" .. v7;
                end;

                v8[Name] = v9;
            end;
        end;
    end;

    return v8;
end;

function v1.FindAnything(p12) -- Line: 81
    -- upvalues: collect (copy)
    return collect(p12, nil, false);
end;

function v1.Find(p13, p14) -- Line: 85
    -- upvalues: collect (copy)
    if p13 then
        p13 = p13:FindFirstChild("HumanoidRootPart");
    end;

    return collect(p14, p13, false);
end;

function v1.FindOne(p15, p16) -- Line: 90
    -- upvalues: collect (copy)
    if p15 then
        p15 = p15:FindFirstChild("HumanoidRootPart");
    end;

    local v17 = collect(p16, p15, false);
    local _, v18 = next(v17);

    return v18;
end;

function v1.Weapon(p19) -- Line: 97
    -- upvalues: collect (copy)
    return collect(p19, nil, true);
end;

return v1;