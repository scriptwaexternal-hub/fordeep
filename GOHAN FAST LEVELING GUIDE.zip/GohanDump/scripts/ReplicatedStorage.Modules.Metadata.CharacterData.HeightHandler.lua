-- Decompiled with Potassium's decompiler.

local Metadata = game:GetService("ReplicatedStorage"):WaitForChild("Modules").Metadata;
local HeightData = require(Metadata.CharacterData.HeightData);

return {
    GiveHeight = function(p1, p2) -- Line: 16, Name: GiveHeight
        if workspace:GetAttribute("DisableHeight") == true then
            p2:ScaleTo(1);

            return;
        end;

        local Height = p1.CharacterData.Height;
        p2:ScaleTo(Height > 1.4 and 1.4 or (Height < 0.75 and 0.75 or Height));
    end,

    SetHeight = function(p3) -- Line: 34, Name: SetHeight
        -- upvalues: HeightData (copy)
        local Race = p3.CharacterData.Race.Race;

        return math.random(HeightData[Race].MinHeight * 100, HeightData[Race].MaxHeight * 100) / 100;
    end
};