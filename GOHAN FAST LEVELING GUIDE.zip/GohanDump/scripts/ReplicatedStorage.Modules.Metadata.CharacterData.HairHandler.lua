-- Decompiled with Potassium's decompiler.

local ReplicatedStorage = game:GetService("ReplicatedStorage");
game:GetService("ServerScriptService");
local Modules = ReplicatedStorage:WaitForChild("Modules");
local HairData = require(Modules.Metadata.CharacterData.HairData);
local GlobalFunctions = require(Modules.GlobalFunctions);
local u4 = {
    SetHairColor = function(p1, p2, p3) -- Line: 14, Name: SetHairColor
        return p2 == "Saiyan" and p3.CharacterData.Race.SubType ~= "Half Saiyan" and {
            Red = 0,
            Green = 0,
            Blue = 0
        } or (p2 == "Angel" and {
            Red = 255,
            Green = 255,
            Blue = 255
        } or (p2 == "Alien" and {
            Red = 255,
            Green = 140,
            Blue = 30
        } or {
            Red = math.random(1, 255),
            Green = math.random(1, 255),
            Blue = math.random(1, 255)
        }));
    end
};

function u4.SetHairType(p5, p6, p7) -- Line: 27
    -- upvalues: u4 (copy), HairData (copy)
    local v8 = u4.ListFor(p6, p7);

    if v8 then
        return math.random(1, #v8);
    end;

    return math.random(1, HairData.Hair_Types[p6] or 1);
end;

local RunService = game:GetService("RunService");

local function hairLibrary() -- Line: 45
    -- upvalues: ReplicatedStorage (copy)
    local Assets = ReplicatedStorage:FindFirstChild("Assets");

    if Assets then
        Assets = Assets:FindFirstChild("Hairs");
    end;

    return Assets;
end;

function u4.UsesCustomHair(p9) -- Line: 50
    -- upvalues: HairData (copy)
    return HairData.CustomHairRaces and HairData.CustomHairRaces[p9] == true;
end;

function u4.ListFor(p10, p11) -- Line: 55
    -- upvalues: u4 (copy), HairData (copy)
    if u4.UsesCustomHair(p10) then
        return p11 == "Female" and HairData.Female or HairData.Male;
    end;

    return nil;
end;

function u4.MaxHairType(p12, p13) -- Line: 60
    -- upvalues: u4 (copy), HairData (copy)
    local v14 = u4.ListFor(p12, p13);

    return v14 and #v14 or (HairData.Hair_Types and HairData.Hair_Types[p12] or 1);
end;

function u4.MinHairType(p15, p16) -- Line: 67
    -- upvalues: u4 (copy)
    return u4.ListFor(p15, p16) and -1 or 1;
end;

function u4.IsCustomHair(p17) -- Line: 71
    -- upvalues: u4 (copy)
    if p17 then
        p17 = p17.CharacterData;
    end;

    if not p17 then
        return false;
    end;

    if u4.ListFor(p17.Race and p17.Race.Race, p17.Gender) then
        return (tonumber(p17.HairType) or 1) == 0;
    end;

    return false;
end;

function u4.BaseHairName(p18) -- Line: 79
    -- upvalues: u4 (copy)
    if p18 then
        p18 = p18.CharacterData;
    end;

    if not p18 then
        return nil;
    end;

    local v19 = u4.ListFor(p18.Race and p18.Race.Race, p18.Gender);

    if not v19 then
        return nil;
    end;

    local v20 = tonumber(p18.HairType) or 1;

    if v20 <= 0 then
        return nil;
    end;

    return v19[math.clamp(v20, 1, #v19)];
end;

local function clientHairContainer(p21) -- Line: 113
    local Model = Instance.new("Model");
    Model.Name = p21;
    Model:SetAttribute("ClientHair", true);

    return Model;
end;

local function buildAccessory(p22, u23) -- Line: 120
    -- upvalues: RunService (copy)
    local Head = u23:FindFirstChild("Head");
    local Head2 = p22:FindFirstChild("Head");
    local Hair = p22:FindFirstChild("Hair");

    if not (Head and (Head2 and Hair)) then
        return nil;
    end;

    local u24 = 1;
    pcall(function() -- Line: 127
        -- upvalues: u24 (ref), u23 (copy)
        u24 = u23:GetScale();
    end);
    local HairAttachment = Head:FindFirstChild("HairAttachment");

    if not HairAttachment then
        HairAttachment = Instance.new("Attachment");
        HairAttachment.Name = "HairAttachment";
        HairAttachment.CFrame = CFrame.new(0, u24 * 0.6, 0);
        HairAttachment.Parent = Head;
    end;

    local function scaled(p25) -- Line: 137
        -- upvalues: u24 (ref)
        return CFrame.new(p25.Position * u24) * p25.Rotation;
    end;

    local v26 = RunService:IsClient();
    local v27;

    if v26 then
        local Name = p22.Name;
        v27 = Instance.new("Model");
        v27.Name = Name;
        v27:SetAttribute("ClientHair", true);
    else
        v27 = Instance.new("Accessory");
        v27.Name = p22.Name;
        v27.AccessoryType = Enum.AccessoryType.Hair;
    end;

    v27:SetAttribute("CustomHair", p22.Name);
    local v28 = Hair:Clone();
    v28.Name = "Handle";
    v28.Anchored = false;
    v28.CanCollide = false;
    v28.CanQuery = false;
    v28.CanTouch = false;
    v28.Massless = true;
    v28.Size = v28.Size * u24;
    local v29 = Head2.CFrame:ToObjectSpace(Hair.CFrame);
    local v30 = CFrame.new(v29.Position * u24) * v29.Rotation;
    local Attachment = Instance.new("Attachment");
    Attachment.Name = "HairAttachment";
    Attachment.CFrame = v30:Inverse() * HairAttachment.CFrame;
    Attachment.Parent = v28;
    v28.CFrame = Head.CFrame * v30;
    v28.Parent = v27;

    for _, child in ipairs(p22:GetChildren()) do
        if child:IsA("BasePart") and (child ~= Head2 and child ~= Hair) then
            local v31 = child:Clone();
            v31.Anchored = false;
            v31.CanCollide = false;
            v31.CanQuery = false;
            v31.CanTouch = false;
            v31.Massless = true;
            v31.Size = v31.Size * u24;
            local v32 = Hair.CFrame:ToObjectSpace(child.CFrame);
            local v33 = CFrame.new(v32.Position * u24) * v32.Rotation;
            v31.CFrame = v28.CFrame * v33;
            local Weld = Instance.new("Weld");
            Weld.Part0 = v28;
            Weld.Part1 = v31;
            Weld.C0 = v33;
            Weld.Parent = v31;
            v31.Parent = v28;
        end;
    end;

    local v34 = u23:FindFirstChildOfClass("Humanoid");
    local v35;

    if v34 and not v26 then
        v35 = pcall(v34.AddAccessory, v34, v27);
    else
        v35 = false;
    end;

    if not v35 or v27.Parent ~= u23 then
        v27.Parent = u23;
    end;

    if not (v28:FindFirstChildOfClass("Weld") or v28:FindFirstChildOfClass("Motor6D")) then
        v28.CFrame = Head.CFrame * v30;
        local Weld = Instance.new("Weld");
        Weld.Name = "HairWeld";
        Weld.Part0 = Head;
        Weld.Part1 = v28;
        Weld.C0 = v30;
        Weld.Parent = v28;
    end;

    return v27;
end;

local function parkAvatarHair(p36) -- Line: 221
    if p36:GetAttribute("AvatarHairParked") then
        return;
    end;

    for _, descendant in ipairs(p36:GetDescendants()) do
        if descendant:IsA("BasePart") then
            descendant.Transparency = 1;
        end;
    end;

    p36:SetAttribute("AvatarHairParked", true);
end;

local function unparkAvatarHair(p37) -- Line: 229
    for _, descendant in ipairs(p37:GetDescendants()) do
        if (descendant:IsA("Accessory") or descendant:IsA("Model")) and descendant:GetAttribute("AvatarHairParked") then
            for _, descendant2 in ipairs(descendant:GetDescendants()) do
                if descendant2:IsA("BasePart") then
                    descendant2.Transparency = 0;
                end;
            end;

            descendant:SetAttribute("AvatarHairParked", nil);
        end;
    end;
end;

local function removeAllHair(p38) -- Line: 240
    -- upvalues: RunService (copy), u4 (copy), parkAvatarHair (copy)
    local v39 = RunService:IsClient();

    for _, descendant in ipairs(p38:GetDescendants()) do
        if u4.IsHair(descendant) then
            if v39 and not descendant:GetAttribute("CustomHair") then
                parkAvatarHair(descendant);
            else
                descendant:Destroy();
            end;
        end;
    end;
end;

local InsertService = game:GetService("InsertService");
local Players = game:GetService("Players");
local u40 = setmetatable({}, {
    __mode = "k"
});

local function avatarHairIds(p41, p42) -- Line: 267
    -- upvalues: u40 (copy), Players (copy)
    local function parse(p43, p44) -- Line: 268
        for i in string.gmatch(p43 or "", "%d+") do
            p44[#p44 + 1] = tonumber(i);
        end;
    end;

    local v45 = {};

    if p42 then
        local success, result = pcall(p42.GetAppliedDescription, p42);

        if success and result then
            for i in string.gmatch(result.HairAccessory or "", "%d+") do
                v45[#v45 + 1] = tonumber(i);
            end;
        end;
    end;

    if #v45 > 0 then
        u40[p41] = v45;

        return v45;
    end;

    if u40[p41] and #u40[p41] > 0 then
        return u40[p41];
    end;

    if p41.UserId > 0 then
        local success, result = pcall(Players.GetHumanoidDescriptionFromUserId, Players, p41.UserId);

        if success and result then
            for i in string.gmatch(result.HairAccessory or "", "%d+") do
                v45[#v45 + 1] = tonumber(i);
            end;
        end;
    end;

    u40[p41] = v45;

    return v45;
end;

local function hasAvatarHair(p46) -- Line: 290
    -- upvalues: u4 (copy)
    for _, descendant in ipairs(p46:GetDescendants()) do
        if u4.IsHair(descendant) and not descendant:GetAttribute("CustomHair") then
            return true;
        end;
    end;

    return false;
end;

local function restoreAvatarHair(p47) -- Line: 297
    -- upvalues: hasAvatarHair (copy), Players (copy), RunService (copy), u40 (copy), u4 (copy), avatarHairIds (copy), InsertService (copy)
    if hasAvatarHair(p47) then
        return;
    end;

    local v48 = Players:GetPlayerFromCharacter(p47) or (RunService:IsClient() and Players.LocalPlayer or nil);
    local v49 = p47:FindFirstChildOfClass("Humanoid");

    if not (v48 and v49) then
        return;
    end;

    if not RunService:IsClient() then
        for _, v in ipairs((avatarHairIds(v48, v49))) do
            local success, result = pcall(InsertService.LoadAsset, InsertService, v);

            if success and result then
                local v50 = result:FindFirstChildWhichIsA("Accessory", true);

                if v50 then
                    v50:SetAttribute("AvatarHair", true);

                    local function harden(p51) -- Line: 367
                        for _, descendant in ipairs(p51:GetDescendants()) do
                            if descendant:IsA("BasePart") then
                                descendant.Anchored = false;
                                descendant.CanCollide = false;
                                descendant.CanQuery = false;
                                descendant.CanTouch = false;
                                descendant.Massless = true;
                            end;
                        end;
                    end;

                    harden(v50);
                    pcall(v49.AddAccessory, v49, v50);
                    harden(v50);
                end;

                result:Destroy();
            end;
        end;

        return;
    end;

    local v52 = u40[v48];

    if type(v52) ~= "table" or v52.kind ~= "instances" then
        v52 = {
            kind = "instances"
        };

        if v48.UserId > 0 then
            local success, result = pcall(Players.CreateHumanoidModelFromUserId, Players, v48.UserId);

            if success and result then
                for _, descendant in ipairs(result:GetDescendants()) do
                    if u4.IsHair(descendant) then
                        v52[#v52 + 1] = descendant:Clone();
                    end;
                end;

                result:Destroy();
            end;
        end;

        u40[v48] = v52;
    end;

    for _, v in ipairs(v52) do
        local Handle = v:FindFirstChild("Handle");

        if Handle then
            local Head = p47:FindFirstChild("Head");
            local v53;

            if Head then
                v53 = Head:FindFirstChild("HairAttachment");
            else
                v53 = Head;
            end;

            local v54 = Handle:FindFirstChild("HairAttachment") or Handle:FindFirstChild("HatAttachment");

            if Head then
                local Name = v.Name;
                local Model = Instance.new("Model");
                Model.Name = Name;
                Model:SetAttribute("ClientHair", true);
                Model:SetAttribute("AvatarHair", true);
                local v55 = Handle:Clone();

                for _, descendant in ipairs(v55:GetDescendants()) do
                    if descendant:IsA("JointInstance") or descendant:IsA("WeldConstraint") then
                        descendant:Destroy();
                    end;
                end;

                v55.Anchored = false;
                v55.CanCollide = false;
                v55.CanQuery = false;
                v55.CanTouch = false;
                v55.Massless = true;
                local v56 = v53 and (v54 and v53.CFrame * v54.CFrame:Inverse()) or CFrame.new(0, 0.6, 0);
                v55.CFrame = Head.CFrame * v56;
                local Weld = Instance.new("Weld");
                Weld.Name = "HairWeld";
                Weld.Part0 = Head;
                Weld.Part1 = v55;
                Weld.C0 = v56;
                Weld.Parent = v55;
                v55.Parent = Model;
                Model.Parent = p47;
            end;
        end;
    end;
end;

function u4.IsBald(p57) -- Line: 390
    -- upvalues: u4 (copy)
    if p57 then
        p57 = p57.CharacterData;
    end;

    if not p57 then
        return false;
    end;

    if u4.ListFor(p57.Race and p57.Race.Race, p57.Gender) then
        return (tonumber(p57.HairType) or 1) == -1;
    end;

    return false;
end;

function u4.ApplyBaseHair(p58, p59) -- Line: 397
    -- upvalues: u4 (copy), removeAllHair (copy), unparkAvatarHair (copy), restoreAvatarHair (copy), ReplicatedStorage (copy), buildAccessory (copy)
    if u4.IsBald(p59) then
        removeAllHair(p58);
        p58:SetAttribute("BaseHair", "Bald");
        p58:SetAttribute("FormHair", nil);

        return nil;
    end;

    if u4.IsCustomHair(p59) then
        for _, descendant in ipairs(p58:GetDescendants()) do
            if (descendant:IsA("Accessory") or descendant:IsA("Model")) and descendant:GetAttribute("CustomHair") then
                descendant:Destroy();
            end;
        end;

        unparkAvatarHair(p58);
        restoreAvatarHair(p58);
        p58:SetAttribute("BaseHair", "Custom");
        p58:SetAttribute("FormHair", nil);
        u4.GiveHairColor(p58, p59);

        if p58:GetAttribute("HairHidden") then
            u4.HairTransparency(p58);
        end;

        return nil;
    end;

    local v60 = u4.BaseHairName(p59);

    if not v60 then
        return nil;
    end;

    local Assets = ReplicatedStorage:FindFirstChild("Assets");

    if Assets then
        Assets = Assets:FindFirstChild("Hairs");
    end;

    local Gender = p59.CharacterData.Gender;

    if Assets then
        Assets = Assets:FindFirstChild(Gender == "Female" and "Female" or "Male");
    end;

    if Assets then
        Assets = Assets:FindFirstChild(v60);
    end;

    if not Assets then
        warn(("HairHandler: library hair %q missing for %s"):format(tostring(v60), p58.Name));

        return nil;
    end;

    removeAllHair(p58);
    local v61 = buildAccessory(Assets, p58);
    p58:SetAttribute("BaseHair", v60);
    p58:SetAttribute("FormHair", nil);
    u4.GiveHairColor(p58, p59);

    if p58:GetAttribute("HairHidden") then
        u4.HairTransparency(p58);
    end;

    return v61;
end;

function u4.FormHairFor(p62, p63) -- Line: 437
    -- upvalues: HairData (copy)
    if not (p62 and (p62 ~= "Custom" and p62 ~= "Bald")) then
        return nil;
    end;

    if p63 == "SSJ2" and HairData.SSJ2[p62] then
        return "SSJ2", HairData.SSJ2[p62];
    end;

    if HairData.SSJ[p62] then
        return "SSJ", HairData.SSJ[p62];
    end;

    return nil;
end;

function u4.ApplyFormHair(p64, p65, p66) -- Line: 449
    -- upvalues: u4 (copy), ReplicatedStorage (copy), removeAllHair (copy), buildAccessory (copy)
    local v67 = p64:GetAttribute("BaseHair") or u4.BaseHairName(p65);
    local v68, v69 = u4.FormHairFor(v67, p66);

    if not v69 then
        return false;
    end;

    if p64:GetAttribute("FormHair") == v68 .. "/" .. v69 then
        return true;
    end;

    local Assets = ReplicatedStorage:FindFirstChild("Assets");

    if Assets then
        Assets = Assets:FindFirstChild("Hairs");
    end;

    local v70 = Assets and Assets:FindFirstChild(v68) and Assets[v68]:FindFirstChild(v69);

    if not v70 then
        warn(("HairHandler: form hair %s/%s missing"):format(v68, (tostring(v69))));

        return false;
    end;

    removeAllHair(p64);
    buildAccessory(v70, p64);
    p64:SetAttribute("BaseHair", v67);
    p64:SetAttribute("FormHair", v68 .. "/" .. v69);

    if p64:GetAttribute("HairHidden") then
        u4.HairTransparency(p64);
    end;

    return true;
end;

function u4.RestoreBaseHair(p71, p72) -- Line: 472
    -- upvalues: u4 (copy)
    if not p71:GetAttribute("FormHair") then
        return false;
    end;

    u4.ApplyBaseHair(p71, p72);

    return true;
end;

function u4.SetGlow(p73, p74) -- Line: 480
end;

local u75 = { "hairband", "hair band", "hairpin", "hair pin", "hairclip", "hair clip", "hairnet", "hair net", "hairbow", "hair bow", "hairbrush" };

function u4.IsHair(p76) -- Line: 512
    -- upvalues: u75 (copy)
    if p76:IsA("Model") and p76:GetAttribute("ClientHair") then
        return true;
    end;

    if not p76:IsA("Accessory") then
        return false;
    end;

    if p76.AccessoryType == Enum.AccessoryType.Hair then
        return true;
    end;

    local Handle = p76:FindFirstChild("Handle");

    if Handle and Handle:FindFirstChild("HairAttachment") then
        return true;
    end;

    if p76.AccessoryType == Enum.AccessoryType.Hat or p76.AccessoryType == Enum.AccessoryType.Unknown then
        local string_lower_ret = string.lower(p76.Name);

        if string.find(string_lower_ret, "hair", 1, true) then
            for _, v in ipairs(u75) do
                if string.find(string_lower_ret, v, 1, true) then
                    return false;
                end;
            end;

            return true;
        end;
    end;

    return false;
end;

function u4.FindHair(p77) -- Line: 536
    -- upvalues: u4 (copy)
    local v78 = {};

    for _, descendant in pairs(p77:GetDescendants()) do
        if u4.IsHair(descendant) then
            v78[#v78 + 1] = descendant;
        end;
    end;

    return v78;
end;

function u4.TintHair(p79, p80, p81, p82) -- Line: 567
    -- upvalues: u4 (copy), GlobalFunctions (copy)
    if not (p79 and p80) then
        return 0;
    end;

    local v83 = u4.FindHair(p79);

    if #v83 == 0 then
        return 0;
    end;

    local v84 = 0;

    for _, v in pairs(v83) do
        for _, descendant in ipairs(v:GetDescendants()) do
            if descendant:IsA("BasePart") then
                local v85 = descendant:GetAttribute("GlowPiece") == true;
                local v86 = descendant:FindFirstChildOfClass("SpecialMesh");

                if v86 then
                    v86.TextureId = "";
                    v86.VertexColor = Vector3.new(1, 1, 1);
                elseif descendant:IsA("MeshPart") then
                    descendant.TextureID = "";
                end;

                if p81 and not v85 then
                    descendant.Material = p81;
                end;

                if p82 and p82 > 0 then
                    GlobalFunctions.Tween({
                        Instance = descendant,
                        Duration = p82
                    }, {
                        Color = p80
                    });
                else
                    descendant.Color = p80;
                end;

                v84 = v84 + 1;
            end;
        end;
    end;

    return #v83, v84;
end;

function u4.EnforceRaceHairColor(p87) -- Line: 620
    if p87 then
        p87 = p87.CharacterData;
    end;

    if not (p87 and p87.Race) then
        return nil;
    end;

    if p87.Race.Race ~= "Saiyan" or p87.Race.SubType == "Half Saiyan" then
        return nil;
    end;

    local HairColor = p87.HairColor;

    if not (HairColor and (HairColor.Red == 0 and (HairColor.Green == 0 and HairColor.Blue == 0))) then
        p87.HairColor = {
            Red = 0,
            Green = 0,
            Blue = 0
        };
    end;

    return p87.HairColor;
end;

function u4.GiveHairColor(p88, p89) -- Line: 633
    -- upvalues: u4 (copy)
    local v90 = u4.EnforceRaceHairColor(p89) or p89 and p89.CharacterData and p89.CharacterData.HairColor;

    if v90 then
        return u4.TintHair(p88, Color3.fromRGB(v90.Red, v90.Green, v90.Blue));
    end;
end;

function u4.HairTransparency(p91, p92) -- Line: 641
    -- upvalues: u4 (copy), GlobalFunctions (copy)
    local v93 = p92 == "Off";

    for _, v in pairs(u4.FindHair(p91)) do
        local v94 = {};

        if v:IsA("BasePart") then
            v94[#v94 + 1] = v;
        end;

        for _, descendant in ipairs(v:GetDescendants()) do
            if descendant:IsA("BasePart") then
                v94[#v94 + 1] = descendant;
            end;
        end;

        for _, v2 in ipairs(v94) do
            if v93 then
                local Attribute = v2:GetAttribute("HairT");

                if Attribute == nil then
                    GlobalFunctions.Tween({
                        Duration = 0.1,
                        Instance = v2
                    }, {
                        Transparency = 0
                    });
                else
                    GlobalFunctions.Tween({
                        Duration = 0.1,
                        Instance = v2
                    }, {
                        Transparency = Attribute
                    });
                    v2:SetAttribute("HairT", nil);
                end;
            else
                if v2:GetAttribute("HairT") == nil then
                    v2:SetAttribute("HairT", v2.Transparency);
                end;

                v2.Transparency = 1;
            end;
        end;
    end;
end;

return u4;