-- Decompiled with Potassium's decompiler.

local HungerBar = script:FindFirstAncestor("HUD").MainFrame.HUDisplay.HungerBar;
local Meter = HungerBar.Meter;
local HungerLabel = HungerBar.HungerLabel;
HungerBar.MouseEnter:Connect(function() -- Line: 16
    -- upvalues: HungerLabel (copy)
    HungerLabel.Visible = true;
end);
HungerBar.MouseLeave:Connect(function() -- Line: 19
    -- upvalues: HungerLabel (copy)
    HungerLabel.Visible = false;
end);

return {
    Update = function(p1) -- Line: 25, Name: Update
        -- upvalues: Meter (copy)
        local math_clamp_ret = math.clamp(p1 / 100, 0, 1);
        Meter:TweenSize(UDim2.new(math_clamp_ret, 0, 1, 0), "Out", "Sine", 0.1, true);
    end
};