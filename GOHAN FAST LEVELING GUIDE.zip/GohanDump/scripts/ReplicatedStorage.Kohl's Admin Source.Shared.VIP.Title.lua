-- Decompiled with Potassium's decompiler.

local CollectionService = game:GetService("CollectionService");
local RunService = game:GetService("RunService");
local Oklab = require(script.Parent.Parent.Parent:WaitForChild("Flux")).Color.Oklab;

local function sortKeypoints(p1, p2) -- Line: 10
    return p1.Time < p2.Time;
end;

local u41 = {
    definition = {
        vip = {
            gamepass = 5411126,
            color = Color3.fromHex("#fc0"),
            assetId = { 110019084552349, 115444443724463 }
        },
        patron = {
            assetId = 115403290087767,
            gamepass = 938480383,
            color = Color3.fromHex("#0ff")
        },
        elite = {
            assetId = 130880915606069,
            gamepass = 939618404,
            color = Color3.fromHex("#0bf")
        },
        epic = {
            assetId = 84349662672781,
            gamepass = 936146448,
            rotation = 0,

            getValue = function(p3: number) -- Line: 35, Name: getValue
                -- upvalues: Oklab (copy)
                local v4 = p3 / 2;
                local v5 = {};

                for i = 0, 2 do
                    local v6 = i / 2;
                    local v7 = math.abs((v4 + v6) % 2 - 1) * 1 / 7;
                    local v8 = Oklab.toRGB(Oklab.fromHCL((Vector3.new(v7 + 0.42857142857142855, 0.4, 1))));
                    table.insert(v5, ColorSequenceKeypoint.new(v6, v8));
                    local _ = i;
                end;

                return ColorSequence.new(v5);
            end,

            update = function(p9, p10) -- Line: 46, Name: update
                p9.Title.UIGradient.Color = p10;
            end
        },
        hero = {
            assetId = 129439770798699,
            gamepass = 941076536,

            getValue = function(p11: number) -- Line: 53, Name: getValue
                -- upvalues: Oklab (copy)
                local v12 = p11 / 2;
                local v13 = {};

                for i = 0, 2 do
                    local v14 = i / 2;
                    local v15 = math.abs((v12 + v14) % 2 - 1) * 1 / 7;
                    local v16 = Oklab.toRGB(Oklab.fromHCL((Vector3.new(v15 + 0.7142857142857143, 0.4, 1))));
                    table.insert(v13, ColorSequenceKeypoint.new(v14, v16));
                    local _ = i;
                end;

                return ColorSequence.new(v13);
            end,

            update = function(p17, p18) -- Line: 64, Name: update
                p17.Title.UIGradient.Color = p18;
            end
        },
        legend = {
            assetId = 132161234381156,
            gamepass = 941162509,

            getValue = function(p19: number) -- Line: 71, Name: getValue
                -- upvalues: Oklab (copy)
                local v20 = p19 / 2;
                local v21 = {};

                for i = 0, 2 do
                    local v22 = i / 2;
                    local v23 = math.abs((v20 + v22) % 2 - 1) * 1 / 7;
                    local v24 = Oklab.toRGB(Oklab.fromHCL((Vector3.new(v23, 0.4, 1))));
                    table.insert(v21, ColorSequenceKeypoint.new(v22, v24));
                    local _ = i;
                end;

                return ColorSequence.new(v21);
            end,

            update = function(p25, p26) -- Line: 82, Name: update
                p25.Title.UIGradient.Color = p26;
            end
        },
        mythic = {
            assetId = 89859349616824,
            gamepass = 941006661,

            getValue = function(p27: number) -- Line: 89, Name: getValue
                -- upvalues: Oklab (copy)
                local ColorSequence_new = ColorSequence.new;
                local toRGB = Oklab.toRGB;
                local fromHCL = Oklab.fromHCL;
                local v28 = time() / 10 % 1;

                return ColorSequence_new(toRGB(fromHCL((Vector3.new(v28, 0.4, 1)))));
            end,

            update = function(p29, p30) -- Line: 92, Name: update
                p29.Title.UIGradient.Color = p30;
            end
        },
        eternal = {
            assetId = 102980653148583,
            gamepass = 983235767,
            rotation = 0,

            getValue = function(p31: number) -- Line: 100, Name: getValue
                -- upvalues: Oklab (copy), sortKeypoints (copy)
                local v32 = p31 / 4;
                local v33 = {};
                local v34 = v32 % 1;
                local v35 = Oklab.toRGB(Oklab.fromHCL((Vector3.new(-v34, 0.4, 1))));
                table.insert(v33, ColorSequenceKeypoint.new(0, v35));
                local v36 = Oklab.toRGB(Oklab.fromHCL((Vector3.new(1 - v34, 0.4, 1))));
                table.insert(v33, ColorSequenceKeypoint.new(1, v36));

                for i = 0, 6 do
                    local v37 = i / 6;
                    local v38 = Oklab.toRGB(Oklab.fromHCL((Vector3.new(v37, 0.4, 1))));
                    table.insert(v33, ColorSequenceKeypoint.new(1 - (v37 + v32) % 1, v38));
                    local _ = i;
                end;

                table.sort(v33, sortKeypoints);

                return ColorSequence.new(v33);
            end,

            update = function(p39, p40) -- Line: 121, Name: update
                p39.Title.UIGradient.Color = p40;
            end
        }
    }
};

for _, v in u41.definition do
    v.ownerCache = {};
end;

shared._KVIPTitle = u41;
local BillboardGui = Instance.new("BillboardGui");
BillboardGui.Name = "_K_Title";
BillboardGui.MaxDistance = 256;
BillboardGui.Size = UDim2.new(4, 0, 1, 0);
BillboardGui.StudsOffset = Vector3.new(0, 3, 0);
BillboardGui.ResetOnSpawn = false;
BillboardGui.LightInfluence = 0;
local TextLabel = Instance.new("TextLabel");
TextLabel.AutoLocalize = false;
TextLabel.Name = "Title";
TextLabel.BackgroundTransparency = 1;
TextLabel.Size = UDim2.fromScale(1, 1);
TextLabel.Font = Enum.Font.FredokaOne;
TextLabel.Text = "LEGEND";
TextLabel.TextScaled = true;
TextLabel.TextColor3 = Color3.new(1, 1, 1);
TextLabel.Parent = BillboardGui;
local UIStroke = Instance.new("UIStroke");
UIStroke.Thickness = 1;
UIStroke.Parent = TextLabel;
Instance.new("UIGradient").Parent = TextLabel;

function u41.Method(p42: userdata, p43: string?, p44, p45, p46: any) -- Line: 160
    -- upvalues: u41 (copy), BillboardGui (copy)
    local _K_Title = p42:FindFirstChild("_K_Title");

    if _K_Title then
        _K_Title:Destroy();
    end;

    if p43 == nil then
        return;
    end;

    local string_lower_ret = string.lower(p43);
    local v47 = u41.definition[string_lower_ret];

    if v47 then
        p44 = p44 or v47.color;
        p45 = p45 or v47.topColor;
    end;

    local v48 = BillboardGui:Clone();
    v48.Parent = p42;
    v48.Adornee = p42:FindFirstChild("Head");
    v48:AddTag("_K" .. string_lower_ret);
    v48.Title.Text = p43;
    v48.Title.UIGradient.Color = ColorSequence.new(p45 or Color3.new(1, 1, 1), p44 or Color3.new(1, 1, 1));
    v48.Title.UIGradient.Rotation = v47 and v47.rotation or 90;

    if p46 then
        v48.Title.Font = p46;
    end;
end;

if RunService:IsClient() then
    local u49 = {};

    for i, v in u41.definition do
        if v.update then
            local v50 = "_K" .. i;
            local u51 = {
                getValue = v.getValue,
                update = v.update,
                objects = {}
            };
            u49[v50] = u51;
            CollectionService:GetInstanceAddedSignal(v50):Connect(function(p52) -- Line: 198
                -- upvalues: u51 (copy)
                u51.objects[p52] = true;
            end);
            CollectionService:GetInstanceRemovedSignal(v50):Connect(function(p53) -- Line: 201
                -- upvalues: u51 (copy)
                u51.objects[p53] = nil;
            end);
        end;
    end;

    local os_clock_ret = os.clock();
    RunService.Heartbeat:Connect(function() -- Line: 207
        -- upvalues: os_clock_ret (copy), u49 (copy)
        local v54 = os.clock() - os_clock_ret;

        for _, v in u49 do
            if next(v.objects) then
                local Value = v.getValue(v54);
                local v55 = v;

                for i in v.objects do
                    if i.AbsoluteSize.Y > 2 then
                        v55.update(i, Value);
                    end;
                end;
            end;
        end;
    end);
end;

return u41;