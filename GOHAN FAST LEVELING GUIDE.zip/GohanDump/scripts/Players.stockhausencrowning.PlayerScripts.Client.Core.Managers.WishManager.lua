-- Decompiled with Potassium's decompiler.

local Players = game:GetService("Players");
local TweenService = game:GetService("TweenService");
local ReplicatedStorage = game:GetService("ReplicatedStorage");
local Modules = ReplicatedStorage:WaitForChild("Modules");
local Remotes = ReplicatedStorage:WaitForChild("Remotes");
local Metadata = Modules.Metadata;
local Utility = Modules.Utility;
local DragonBallData = require(Metadata.DragonBallData.DragonBallData);
local RaceData = require(Metadata.RaceData.RaceData);
local SubTypeData = require(Metadata.RaceData.SubTypeData);
local GameMessage = require(Utility.GameMessage);
local ServerRemote = Remotes.ServerRemote;
local StatRetrieveRemote = Remotes.StatRetrieveRemote;
local LocalPlayer = Players.LocalPlayer;
local Color3_fromRGB_ret = Color3.fromRGB(18, 46, 26);
local Color3_fromRGB_ret2 = Color3.fromRGB(10, 30, 16);
local Color3_fromRGB_ret3 = Color3.fromRGB(30, 70, 40);
local Color3_fromRGB_ret4 = Color3.fromRGB(44, 96, 56);
local Color3_fromRGB_ret5 = Color3.fromRGB(0, 0, 0);
local Color3_fromRGB_ret6 = Color3.fromRGB(255, 133, 26);
local Color3_fromRGB_ret7 = Color3.fromRGB(255, 255, 255);
local Color3_fromRGB_ret8 = Color3.fromRGB(190, 208, 194);
local Color3_fromRGB_ret9 = Color3.fromRGB(255, 70, 55);
local Color3_fromRGB_ret10 = Color3.fromRGB(170, 255, 185);
local Bangers = Enum.Font.Bangers;
local Arcade = Enum.Font.Arcade;
local u1 = {
    [3] = Color3.fromRGB(255, 130, 115),
    [2] = Color3.fromRGB(230, 75, 60),
    [1] = Color3.fromRGB(255, 35, 30)
};

local function stroked(p2) -- Line: 69
    -- upvalues: Color3_fromRGB_ret5 (copy)
    p2.TextStrokeColor3 = Color3_fromRGB_ret5;
    p2.TextStrokeTransparency = 0.5;

    return p2;
end;

local function outline(p3, p4, p5) -- Line: 75
    -- upvalues: Color3_fromRGB_ret5 (copy)
    local UIStroke = Instance.new("UIStroke");
    UIStroke.Color = p5 or Color3_fromRGB_ret5;
    UIStroke.Thickness = p4 or 1.5;
    UIStroke.Parent = p3;

    return UIStroke;
end;

local function comma(p6) -- Line: 83
    local math_floor_ret = math.floor(p6);

    return tostring(math_floor_ret):reverse():gsub("(%d%d%d)", "%1,"):reverse():gsub("^,", "");
end;

local function makeCard(p7) -- Line: 91
    -- upvalues: LocalPlayer (copy), Color3_fromRGB_ret (copy), Color3_fromRGB_ret5 (copy), Arcade (copy), Color3_fromRGB_ret6 (copy), Bangers (copy), Color3_fromRGB_ret7 (copy), Color3_fromRGB_ret3 (copy)
    local ScreenGui = Instance.new("ScreenGui");
    ScreenGui.Name = p7.Name or "WishGui";
    ScreenGui.ResetOnSpawn = false;
    ScreenGui.DisplayOrder = 120;
    ScreenGui.IgnoreGuiInset = false;
    ScreenGui.Parent = LocalPlayer:WaitForChild("PlayerGui");
    local Frame = Instance.new("Frame");
    Frame.Name = "Card";
    Frame.AnchorPoint = Vector2.new(0.5, 0.5);
    Frame.Position = UDim2.fromScale(0.5, 0.5);
    Frame.Size = p7.Size or UDim2.fromScale(0.42, 0.72);
    Frame.BackgroundColor3 = Color3_fromRGB_ret;
    Frame.BorderSizePixel = 0;
    Frame.Parent = ScreenGui;
    local UIStroke = Instance.new("UIStroke");
    UIStroke.Color = Color3_fromRGB_ret5;
    UIStroke.Thickness = 2.5;
    UIStroke.Parent = Frame;
    local UISizeConstraint = Instance.new("UISizeConstraint");
    UISizeConstraint.MinSize = p7.MinSize or Vector2.new(330, 360);
    UISizeConstraint.MaxSize = p7.MaxSize or Vector2.new(560, 700);
    UISizeConstraint.Parent = Frame;
    local TextLabel = Instance.new("TextLabel");
    TextLabel.Name = "Title";
    TextLabel.BackgroundTransparency = 1;
    TextLabel.Position = UDim2.new(0, 14, 0, 8);
    TextLabel.Size = UDim2.new(1, -60, 0, 30);
    TextLabel.Font = Arcade;
    TextLabel.TextSize = 24;
    TextLabel.TextColor3 = Color3_fromRGB_ret6;
    TextLabel.TextXAlignment = Enum.TextXAlignment.Left;
    TextLabel.Text = p7.Title or "SHENRON";
    TextLabel.Parent = Frame;
    TextLabel.TextStrokeColor3 = Color3_fromRGB_ret5;
    TextLabel.TextStrokeTransparency = 0.5;
    local TextLabel2 = Instance.new("TextLabel");
    TextLabel2.Name = "Subtitle";
    TextLabel2.BackgroundTransparency = 1;
    TextLabel2.Position = UDim2.new(0, 14, 0, 38);
    TextLabel2.Size = UDim2.new(1, -28, 0, 22);
    TextLabel2.Font = Bangers;
    TextLabel2.TextSize = 19;
    TextLabel2.TextColor3 = Color3_fromRGB_ret7;
    TextLabel2.TextXAlignment = Enum.TextXAlignment.Left;
    TextLabel2.Text = p7.Subtitle or "";
    TextLabel2.Parent = Frame;
    TextLabel2.TextStrokeColor3 = Color3_fromRGB_ret5;
    TextLabel2.TextStrokeTransparency = 0.5;
    local TextButton = Instance.new("TextButton");
    TextButton.Name = "Close";
    TextButton.AnchorPoint = Vector2.new(1, 0);
    TextButton.Position = UDim2.new(1, -8, 0, 8);
    TextButton.Size = UDim2.new(0, 30, 0, 30);
    TextButton.BackgroundColor3 = Color3_fromRGB_ret3;
    TextButton.BorderSizePixel = 0;
    TextButton.Font = Arcade;
    TextButton.TextSize = 16;
    TextButton.TextColor3 = Color3_fromRGB_ret7;
    TextButton.Text = "X";
    TextButton.Parent = Frame;
    local UIStroke2 = Instance.new("UIStroke");
    UIStroke2.Color = Color3_fromRGB_ret5;
    UIStroke2.Thickness = 1.5;
    UIStroke2.Parent = TextButton;
    TextButton.TextStrokeColor3 = Color3_fromRGB_ret5;
    TextButton.TextStrokeTransparency = 0.5;
    TextButton.MouseButton1Up:Connect(function() -- Line: 154
        -- upvalues: ScreenGui (copy)
        ScreenGui:Destroy();
    end);

    return ScreenGui, Frame;
end;

local function makeListWell(p8, p9, p10) -- Line: 162
    -- upvalues: Color3_fromRGB_ret2 (copy), Color3_fromRGB_ret6 (copy), Color3_fromRGB_ret5 (copy)
    local ScrollingFrame = Instance.new("ScrollingFrame");
    ScrollingFrame.Name = "List";
    ScrollingFrame.Position = UDim2.new(0, 10, 0, p9);
    ScrollingFrame.Size = UDim2.new(1, -20, 1, -(p9 + (p10 or 10)));
    ScrollingFrame.BackgroundColor3 = Color3_fromRGB_ret2;
    ScrollingFrame.BorderSizePixel = 0;
    ScrollingFrame.ScrollBarThickness = 5;
    ScrollingFrame.ScrollBarImageColor3 = Color3_fromRGB_ret6;
    ScrollingFrame.CanvasSize = UDim2.new();
    ScrollingFrame.AutomaticCanvasSize = Enum.AutomaticSize.Y;
    ScrollingFrame.Parent = p8;
    local UIStroke = Instance.new("UIStroke");
    UIStroke.Color = Color3_fromRGB_ret5;
    UIStroke.Thickness = 1.5;
    UIStroke.Parent = ScrollingFrame;
    local UIListLayout = Instance.new("UIListLayout");
    UIListLayout.Padding = UDim.new(0, 6);
    UIListLayout.SortOrder = Enum.SortOrder.LayoutOrder;
    UIListLayout.Parent = ScrollingFrame;
    local UIPadding = Instance.new("UIPadding");
    UIPadding.PaddingTop = UDim.new(0, 8);
    UIPadding.PaddingBottom = UDim.new(0, 8);
    UIPadding.PaddingLeft = UDim.new(0, 8);
    UIPadding.PaddingRight = UDim.new(0, 8);
    UIPadding.Parent = ScrollingFrame;

    return ScrollingFrame;
end;

local function makeRow(p11, p12, p13) -- Line: 192
    -- upvalues: Color3_fromRGB_ret3 (copy), Bangers (copy), Color3_fromRGB_ret7 (copy), Color3_fromRGB_ret5 (copy), Color3_fromRGB_ret4 (copy), Color3_fromRGB_ret6 (copy)
    local TextButton = Instance.new("TextButton");
    TextButton.Size = UDim2.new(1, 0, 0, 44);
    TextButton.BackgroundColor3 = Color3_fromRGB_ret3;
    TextButton.BorderSizePixel = 0;
    TextButton.AutoButtonColor = false;
    TextButton.Font = Bangers;
    TextButton.TextSize = 20;
    TextButton.TextColor3 = Color3_fromRGB_ret7;
    TextButton.TextXAlignment = Enum.TextXAlignment.Left;
    TextButton.Text = "  " .. p12;
    TextButton.LayoutOrder = p13 or 0;
    TextButton.Parent = p11;
    TextButton.TextStrokeColor3 = Color3_fromRGB_ret5;
    TextButton.TextStrokeTransparency = 0.5;
    local UIStroke = Instance.new("UIStroke");
    UIStroke.Color = Color3_fromRGB_ret5;
    UIStroke.Thickness = 1.5;
    UIStroke.Parent = TextButton;
    TextButton.MouseEnter:Connect(function() -- Line: 208
        -- upvalues: TextButton (copy), Color3_fromRGB_ret4 (ref), UIStroke (copy), Color3_fromRGB_ret6 (ref)
        TextButton.BackgroundColor3 = Color3_fromRGB_ret4;
        UIStroke.Color = Color3_fromRGB_ret6;
    end);
    TextButton.MouseLeave:Connect(function() -- Line: 212
        -- upvalues: TextButton (copy), Color3_fromRGB_ret3 (ref), UIStroke (copy), Color3_fromRGB_ret5 (ref)
        TextButton.BackgroundColor3 = Color3_fromRGB_ret3;
        UIStroke.Color = Color3_fromRGB_ret5;
    end);

    return TextButton, UIStroke;
end;

local function searchPlayers(p14) -- Line: 225
    -- upvalues: Players (copy)
    local string_lower_ret = string.lower(p14);
    local v15 = {};
    local v16 = {};

    for _, v in ipairs(Players:GetPlayers()) do
        local v17 = v.Name:lower();
        local v18 = (v.DisplayName or ""):lower();

        if v17:sub(1, #string_lower_ret) == string_lower_ret or v18:sub(1, #string_lower_ret) == string_lower_ret then
            table.insert(v15, v);
        elseif v17:find(string_lower_ret, 1, true) or v18:find(string_lower_ret, 1, true) then
            table.insert(v16, v);
        end;
    end;

    for _, v in ipairs(v16) do
        table.insert(v15, v);
    end;

    return v15;
end;

local function attachPlayerAutocomplete(u19, p20) -- Line: 244
    -- upvalues: Color3_fromRGB_ret2 (copy), Color3_fromRGB_ret5 (copy), searchPlayers (copy), Color3_fromRGB_ret3 (copy), Bangers (copy), Color3_fromRGB_ret7 (copy)
    local Frame = Instance.new("Frame");
    Frame.Name = "Suggest";
    Frame.Position = UDim2.new(0, 0, 1, 2);
    Frame.Size = UDim2.new(1, -96, 0, 0);
    Frame.BackgroundColor3 = Color3_fromRGB_ret2;
    Frame.BorderSizePixel = 0;
    Frame.Visible = false;
    Frame.ZIndex = 6;
    Frame.Parent = p20;
    local UIStroke = Instance.new("UIStroke");
    UIStroke.Color = Color3_fromRGB_ret5;
    UIStroke.Thickness = 1.5;
    UIStroke.Parent = Frame;
    local UIListLayout = Instance.new("UIListLayout");
    UIListLayout.SortOrder = Enum.SortOrder.LayoutOrder;
    UIListLayout.Parent = Frame;

    local function hide() -- Line: 260
        -- upvalues: Frame (copy)
        Frame.Visible = false;
    end;

    local function render(p21) -- Line: 264
        -- upvalues: Frame (copy), searchPlayers (ref), Color3_fromRGB_ret3 (ref), Bangers (ref), Color3_fromRGB_ret7 (ref), Color3_fromRGB_ret5 (ref), u19 (copy)
        for _, child in ipairs(Frame:GetChildren()) do
            if child:IsA("TextButton") then
                child:Destroy();
            end;
        end;

        if p21 == "" then
            Frame.Visible = false;

            return;
        end;

        local v22 = searchPlayers(p21);
        local math_min_ret = math.min(#v22, 5);

        if math_min_ret == 0 then
            Frame.Visible = false;

            return;
        end;

        for i = 1, math_min_ret do
            local u23 = v22[i];
            local TextButton = Instance.new("TextButton");
            TextButton.Size = UDim2.new(1, 0, 0, 26);
            TextButton.BackgroundColor3 = Color3_fromRGB_ret3;
            TextButton.BackgroundTransparency = 1;
            TextButton.BorderSizePixel = 0;
            TextButton.AutoButtonColor = false;
            TextButton.Font = Bangers;
            TextButton.TextSize = 16;
            TextButton.TextColor3 = Color3_fromRGB_ret7;
            TextButton.TextXAlignment = Enum.TextXAlignment.Left;
            TextButton.Text = "  " .. u23.Name;
            TextButton.ZIndex = 7;
            TextButton.LayoutOrder = i;
            TextButton.Parent = Frame;
            TextButton.TextStrokeColor3 = Color3_fromRGB_ret5;
            TextButton.TextStrokeTransparency = 0.5;
            TextButton.MouseEnter:Connect(function() -- Line: 292
                -- upvalues: TextButton (copy)
                TextButton.BackgroundTransparency = 0;
            end);
            TextButton.MouseLeave:Connect(function() -- Line: 293
                -- upvalues: TextButton (copy)
                TextButton.BackgroundTransparency = 1;
            end);
            TextButton.MouseButton1Down:Connect(function() -- Line: 297
                -- upvalues: u19 (ref), u23 (copy), Frame (ref)
                u19.Text = u23.Name;
                Frame.Visible = false;
            end);
            local _ = i;
        end;

        Frame.Size = UDim2.new(1, -96, 0, math_min_ret * 26);
        Frame.Visible = true;
    end;

    u19:GetPropertyChangedSignal("Text"):Connect(function() -- Line: 307
        -- upvalues: u19 (copy), render (copy)
        if u19:IsFocused() then
            render(u19.Text);
        end;
    end);
    u19.Focused:Connect(function() -- Line: 310
        -- upvalues: render (copy), u19 (copy)
        render(u19.Text);
    end);
    u19.FocusLost:Connect(function(p24) -- Line: 313
        -- upvalues: u19 (copy), searchPlayers (ref), hide (copy)
        if p24 and u19.Text ~= "" then
            local v25 = searchPlayers(u19.Text);

            if v25[1] then
                u19.Text = v25[1].Name;
            end;
        end;

        task.delay(0.15, hide);
    end);
end;

local u26 = { "1 STAR SUMMON", "2 STAR SUMMON", "3 STAR SUMMON" };

return {
    Execute = function(p27) -- Line: 333
        -- upvalues: LocalPlayer (copy), makeCard (copy), Color3_fromRGB_ret2 (copy), Arcade (copy), u1 (copy), Color3_fromRGB_ret8 (copy), u26 (copy), Color3_fromRGB_ret5 (copy), Color3_fromRGB_ret6 (copy), TweenService (copy), makeListWell (copy), DragonBallData (copy), makeRow (copy), Color3_fromRGB_ret9 (copy), Color3_fromRGB_ret7 (copy), ServerRemote (copy)
        local v28 = tonumber(p27.WishQuality) or 3;
        local v29 = tonumber(p27.TimeLimt) or 60;
        local v30 = p27.Dragon or "Shenron";
        local v31 = v30 == "Porunga";
        local PlayerGui = LocalPlayer:FindFirstChild("PlayerGui");

        if PlayerGui then
            PlayerGui = PlayerGui:FindFirstChild("WishGui");
        end;

        if PlayerGui then
            PlayerGui:Destroy();
        end;

        local u32, v33 = makeCard({
            Name = "WishGui",
            Title = v31 and "PORUNGA" or "SHENRON",
            Subtitle = v31 and "Speak your wish in the tongue of Namek..." or "What.... is your wish....?"
        });
        local TextLabel = Instance.new("TextLabel");
        TextLabel.AnchorPoint = Vector2.new(1, 0);
        TextLabel.Position = UDim2.new(1, -46, 0, 12);
        TextLabel.Size = UDim2.new(0, 130, 0, 22);
        TextLabel.BackgroundColor3 = Color3_fromRGB_ret2;
        TextLabel.BorderSizePixel = 0;
        TextLabel.Font = Arcade;
        TextLabel.TextSize = 12;
        TextLabel.TextColor3 = u1[v28] or Color3_fromRGB_ret8;
        TextLabel.Text = v31 and "PORUNGA SUMMON" or (u26[v28] or "SUMMON");
        TextLabel.Parent = v33;
        local UIStroke = Instance.new("UIStroke");
        UIStroke.Color = Color3_fromRGB_ret5;
        UIStroke.Thickness = 1.5;
        UIStroke.Parent = TextLabel;
        TextLabel.TextStrokeColor3 = Color3_fromRGB_ret5;
        TextLabel.TextStrokeTransparency = 0.5;
        local Frame = Instance.new("Frame");
        Frame.Position = UDim2.new(0, 10, 0, 64);
        Frame.Size = UDim2.new(1, -20, 0, 5);
        Frame.BackgroundColor3 = Color3_fromRGB_ret2;
        Frame.BorderSizePixel = 0;
        Frame.Parent = v33;
        local UIStroke2 = Instance.new("UIStroke");
        UIStroke2.Color = Color3_fromRGB_ret5;
        UIStroke2.Thickness = 1;
        UIStroke2.Parent = Frame;
        local Frame2 = Instance.new("Frame");
        Frame2.Size = UDim2.fromScale(1, 1);
        Frame2.BackgroundColor3 = Color3_fromRGB_ret6;
        Frame2.BorderSizePixel = 0;
        Frame2.Parent = Frame;
        TweenService:Create(Frame2, TweenInfo.new(v29, Enum.EasingStyle.Linear), {
            Size = UDim2.fromScale(0, 1)
        }):Play();
        local v34 = makeListWell(v33, 78);
        local Available = DragonBallData.GetAvailable(v28, v30);
        local v35 = v31 and DragonBallData.PorungaZeni or (DragonBallData.ZeniByQuality[v28] or DragonBallData.ZeniByQuality[3]);

        for i, v in ipairs(Available) do
            local Text = v.Text;

            if v.Id == "Zeni" then
                local math_floor_ret = math.floor(v35);
                Text = Text .. " (" .. tostring(math_floor_ret):reverse():gsub("(%d%d%d)", "%1,"):reverse():gsub("^,", "") .. ")";
            end;

            local u36 = makeRow(v34, Text, i);
            u36.Name = v.Id;
            local TextLabel2 = Instance.new("TextLabel");
            TextLabel2.AnchorPoint = Vector2.new(1, 0.5);
            TextLabel2.Position = UDim2.new(1, -8, 0.5, 0);
            TextLabel2.Size = UDim2.new(0, 58, 0, 20);
            TextLabel2.BackgroundColor3 = Color3_fromRGB_ret2;
            TextLabel2.BorderSizePixel = 0;
            TextLabel2.Font = Arcade;
            TextLabel2.TextSize = 11;
            TextLabel2.TextColor3 = u1[v.Tier] or Color3_fromRGB_ret8;
            TextLabel2.Text = "TIER " .. v.Tier;
            TextLabel2.Parent = u36;
            local UIStroke3 = Instance.new("UIStroke");
            UIStroke3.Color = Color3_fromRGB_ret5;
            UIStroke3.Thickness = 1;
            UIStroke3.Parent = TextLabel2;
            TextLabel2.TextStrokeColor3 = Color3_fromRGB_ret5;
            TextLabel2.TextStrokeTransparency = 0.5;
            local u37 = false;
            u36.MouseButton1Up:Connect(function() -- Line: 415
                -- upvalues: v (copy), u37 (ref), u36 (copy), Color3_fromRGB_ret9 (ref), Text (ref), Color3_fromRGB_ret7 (ref), u32 (copy), ServerRemote (ref)
                if not v.Confirm or u37 then
                    u32:Destroy();
                    ServerRemote:FireServer(nil, {
                        Module = "DragonballManager",
                        Action = "GrantWishes",
                        Wish_Name = v.Id
                    });

                    return;
                end;

                u37 = true;
                u36.Text = "  Click again to confirm...";
                u36.TextColor3 = Color3_fromRGB_ret9;
                task.delay(3, function() -- Line: 421
                    -- upvalues: u36 (ref), u37 (ref), Text (ref), Color3_fromRGB_ret7 (ref)
                    if u36.Parent and u37 then
                        u37 = false;
                        u36.Text = "  " .. Text;
                        u36.TextColor3 = Color3_fromRGB_ret7;
                    end;
                end);
            end);
        end;

        task.delay(v29, function() -- Line: 440
            -- upvalues: u32 (copy)
            if u32.Parent then
                u32:Destroy();
            end;
        end);
    end,

    Revive = function(p38) -- Line: 449
        -- upvalues: DragonBallData (copy), makeCard (copy), makeListWell (copy), Color3_fromRGB_ret3 (copy), Bangers (copy), Color3_fromRGB_ret7 (copy), Color3_fromRGB_ret8 (copy), Color3_fromRGB_ret5 (copy), attachPlayerAutocomplete (copy), Color3_fromRGB_ret6 (copy), Arcade (copy), Color3_fromRGB_ret10 (copy), GameMessage (copy), LocalPlayer (copy), ServerRemote (copy)
        local v39 = tonumber(p38.WishQuality) or 3;
        local u40 = DragonBallData.ReviveByQuality[v39] or 2;
        local u41, v42 = makeCard({
            Name = "ReviveGui",
            Title = "REVIVE",
            Subtitle = "Speak their exact name. They must be online.",
            Size = UDim2.fromScale(0.36, 0.52),
            MinSize = Vector2.new(320, 300),
            MaxSize = Vector2.new(480, 480)
        });
        local v43 = makeListWell(v42, 70);

        for i = 1, u40 do
            local Frame = Instance.new("Frame");
            Frame.Size = UDim2.new(1, 0, 0, 44);
            Frame.BackgroundTransparency = 1;
            Frame.LayoutOrder = i;
            Frame.ZIndex = 2;
            Frame.Parent = v43;
            local TextBox = Instance.new("TextBox");
            TextBox.Position = UDim2.new(0, 0, 0, 0);
            TextBox.Size = UDim2.new(1, -96, 1, 0);
            TextBox.BackgroundColor3 = Color3_fromRGB_ret3;
            TextBox.BorderSizePixel = 0;
            TextBox.Font = Bangers;
            TextBox.TextSize = 19;
            TextBox.TextColor3 = Color3_fromRGB_ret7;
            TextBox.PlaceholderText = "Username...";
            TextBox.PlaceholderColor3 = Color3_fromRGB_ret8;
            TextBox.Text = "";
            TextBox.ClearTextOnFocus = false;
            TextBox.Parent = Frame;
            local UIStroke = Instance.new("UIStroke");
            UIStroke.Color = Color3_fromRGB_ret5;
            UIStroke.Thickness = 1.5;
            UIStroke.Parent = TextBox;
            TextBox.TextStrokeColor3 = Color3_fromRGB_ret5;
            TextBox.TextStrokeTransparency = 0.5;
            attachPlayerAutocomplete(TextBox, Frame);
            local TextButton = Instance.new("TextButton");
            TextButton.AnchorPoint = Vector2.new(1, 0);
            TextButton.Position = UDim2.new(1, 0, 0, 0);
            TextButton.Size = UDim2.new(0, 88, 1, 0);
            TextButton.BackgroundColor3 = Color3_fromRGB_ret6;
            TextButton.BorderSizePixel = 0;
            TextButton.AutoButtonColor = true;
            TextButton.Font = Arcade;
            TextButton.TextSize = 15;
            TextButton.TextColor3 = Color3_fromRGB_ret10;
            TextButton.Text = "REVIVE";
            TextButton.Parent = Frame;
            local UIStroke2 = Instance.new("UIStroke");
            UIStroke2.Color = Color3_fromRGB_ret5;
            UIStroke2.Thickness = 1.5;
            UIStroke2.Parent = TextButton;
            TextButton.TextStrokeColor3 = Color3_fromRGB_ret5;
            TextButton.TextStrokeTransparency = 0.5;
            TextButton.MouseButton1Up:Once(function() -- Line: 506
                -- upvalues: TextBox (copy), GameMessage (ref), LocalPlayer (ref), ServerRemote (ref), Frame (copy), u40 (ref), u41 (copy)
                local Text = TextBox.Text;

                if type(Text) ~= "string" or #Text == 0 then
                    GameMessage.SendMessage(LocalPlayer, "Speak a name for the Dragon to hear.");

                    return;
                end;

                ServerRemote:FireServer(nil, {
                    Module = "DragonballManager",
                    Action = "RevivePlayer",
                    Person_To_Revive = Text
                });
                Frame:Destroy();
                u40 = u40 - 1;

                if u40 <= 0 and u41.Parent then
                    u41:Destroy();
                end;
            end);
            local _ = i;
        end;
    end,

    ["Race/Trait"] = function(p44) -- Line: 530
        -- upvalues: makeCard (copy), Color3_fromRGB_ret6 (copy), Color3_fromRGB_ret7 (copy), Color3_fromRGB_ret5 (copy), Color3_fromRGB_ret2 (copy), RaceData (copy), makeRow (copy), Arcade (copy), SubTypeData (copy), Color3_fromRGB_ret10 (copy), GameMessage (copy), LocalPlayer (copy), StatRetrieveRemote (copy), ServerRemote (copy)
        local change_Race = p44.change_Race;
        local change_Trait = p44.change_Trait;
        local u45 = "";
        local u46 = "";
        local u47 = {};
        local u48 = {};
        local v49 = change_Race and change_Trait;
        local u50, v51 = makeCard({
            Name = "HardcodeGui",
            Subtitle = "The Dragon awaits your choice...",
            Title = change_Race and (change_Trait and "REWRITE YOUR BEING" or "CHOOSE A NEW RACE") or "CHOOSE A NEW TRAIT",
            Size = UDim2.fromScale(v49 and 0.6 or 0.42, 0.74),
            MinSize = Vector2.new(v49 and 520 or 340, 400),
            MaxSize = Vector2.new(v49 and 820 or 560, 720)
        });

        local function markSelected(p52, p53) -- Line: 550
            -- upvalues: Color3_fromRGB_ret6 (ref), Color3_fromRGB_ret7 (ref), Color3_fromRGB_ret5 (ref)
            for _, v in ipairs(p52) do
                local v54 = v.btn == p53;
                v.btn.TextColor3 = v54 and Color3_fromRGB_ret6 or Color3_fromRGB_ret7;
                v.stroke.Color = v54 and Color3_fromRGB_ret6 or Color3_fromRGB_ret5;
            end;
        end;

        local v55 = {};

        if change_Race then
            table.insert(v55, "Race");
        end;

        if change_Trait then
            table.insert(v55, "Trait");
        end;

        local v56 = v49 and 0.5 or 1;
        local v57 = {};

        for i, v in ipairs(v55) do
            local ScrollingFrame = Instance.new("ScrollingFrame");
            ScrollingFrame.Name = v .. "List";
            ScrollingFrame.Position = UDim2.new((i - 1) * v56, 10, 0, 66);
            ScrollingFrame.Size = UDim2.new(v56, -20, 1, -128);
            ScrollingFrame.BackgroundColor3 = Color3_fromRGB_ret2;
            ScrollingFrame.BorderSizePixel = 0;
            ScrollingFrame.ScrollBarThickness = 5;
            ScrollingFrame.ScrollBarImageColor3 = Color3_fromRGB_ret6;
            ScrollingFrame.CanvasSize = UDim2.new();
            ScrollingFrame.AutomaticCanvasSize = Enum.AutomaticSize.Y;
            ScrollingFrame.Parent = v51;
            local UIStroke = Instance.new("UIStroke");
            UIStroke.Color = Color3_fromRGB_ret5;
            UIStroke.Thickness = 1.5;
            UIStroke.Parent = ScrollingFrame;
            local UIListLayout = Instance.new("UIListLayout");
            UIListLayout.Padding = UDim.new(0, 6);
            UIListLayout.SortOrder = Enum.SortOrder.LayoutOrder;
            UIListLayout.Parent = ScrollingFrame;
            local UIPadding = Instance.new("UIPadding");
            UIPadding.PaddingTop = UDim.new(0, 8);
            UIPadding.PaddingBottom = UDim.new(0, 8);
            UIPadding.PaddingLeft = UDim.new(0, 8);
            UIPadding.PaddingRight = UDim.new(0, 8);
            UIPadding.Parent = ScrollingFrame;
            v57[v] = ScrollingFrame;
        end;

        if change_Race then
            local v58 = 0;

            for _, v in pairs(RaceData) do
                v58 = v58 + 1;
                local u59, v60 = makeRow(v57.Race, v[1], v58);
                u59.Size = UDim2.new(1, 0, 0, 40);
                table.insert(u47, {
                    btn = u59,
                    stroke = v60
                });
                u59.MouseButton1Up:Connect(function() -- Line: 600
                    -- upvalues: u45 (ref), v (copy), markSelected (copy), u47 (copy), u59 (copy)
                    u45 = v[1];
                    markSelected(u47, u59);
                end);
            end;
        end;

        if change_Trait then
            local v61 = 0;

            for _, v in pairs(RaceData) do
                local v62 = v61 + 1;
                local TextLabel = Instance.new("TextLabel");
                TextLabel.Size = UDim2.new(1, 0, 0, 24);
                TextLabel.BackgroundTransparency = 1;
                TextLabel.Font = Arcade;
                TextLabel.TextSize = 14;
                TextLabel.TextColor3 = Color3_fromRGB_ret6;
                TextLabel.TextXAlignment = Enum.TextXAlignment.Left;
                TextLabel.Text = string.upper(v[1]) .. " TRAITS";
                TextLabel.LayoutOrder = v62;
                TextLabel.Parent = v57.Trait;
                TextLabel.TextStrokeColor3 = Color3_fromRGB_ret5;
                TextLabel.TextStrokeTransparency = 0.5;
                local v63 = v;

                for i, v2 in pairs(SubTypeData) do
                    if string.find(i, v63[1]) then
                        for _, v3 in pairs(v2) do
                            v62 = v62 + 1;
                            local u64, v65 = makeRow(v57.Trait, v3[1], v62);
                            u64.Size = UDim2.new(1, 0, 0, 36);
                            u64.TextSize = 18;
                            table.insert(u48, {
                                btn = u64,
                                stroke = v65
                            });
                            u64.MouseButton1Up:Connect(function() -- Line: 631
                                -- upvalues: u46 (ref), u64 (copy), markSelected (copy), u48 (copy)
                                u46 = u64.Text:gsub("^%s+", "");
                                markSelected(u48, u64);
                            end);
                        end;

                        break;
                    end;
                end;

                v61 = v62 + 1;
            end;
        end;

        local TextButton = Instance.new("TextButton");
        TextButton.AnchorPoint = Vector2.new(0.5, 1);
        TextButton.Position = UDim2.new(0.5, 0, 1, -12);
        TextButton.Size = UDim2.new(0, 190, 0, 38);
        TextButton.BackgroundColor3 = Color3_fromRGB_ret6;
        TextButton.BorderSizePixel = 0;
        TextButton.Font = Arcade;
        TextButton.TextSize = 17;
        TextButton.TextColor3 = Color3_fromRGB_ret10;
        TextButton.Text = "CONFIRM";
        TextButton.Parent = v51;
        local UIStroke = Instance.new("UIStroke");
        UIStroke.Color = Color3_fromRGB_ret5;
        UIStroke.Thickness = 2;
        UIStroke.Parent = TextButton;
        TextButton.TextStrokeColor3 = Color3_fromRGB_ret5;
        TextButton.TextStrokeTransparency = 0.5;
        local u66 = nil;
        u66 = TextButton.MouseButton1Up:Connect(function() -- Line: 658
            -- upvalues: u45 (ref), change_Race (copy), GameMessage (ref), LocalPlayer (ref), u46 (ref), change_Trait (copy), StatRetrieveRemote (ref), SubTypeData (ref), ServerRemote (ref), u50 (copy), u66 (ref)
            if u45 == "" and change_Race then
                GameMessage.SendMessage(LocalPlayer, "Need to Select a Race!");

                return;
            end;

            if u46 == "" and change_Trait then
                GameMessage.SendMessage(LocalPlayer, "Need to Select a Trait!");

                return;
            end;

            if change_Trait then
                local v67 = u45 ~= "" and u45 .. "SubTypes" or StatRetrieveRemote:InvokeServer("Race") .. "SubTypes";
                local v68 = false;

                for _, v in pairs(SubTypeData[v67] or {}) do
                    if u46 == v[1] then
                        v68 = true;
                        break;
                    end;
                end;

                if not v68 then
                    GameMessage.SendMessage(LocalPlayer, "Need to Select a Trait From The Race You Picked!");

                    return;
                end;
            end;

            ServerRemote:FireServer(nil, {
                Module = "DragonballManager",
                Action = "HardcodePlayer",
                change_Race = change_Race,
                change_Trait = change_Trait,
                selected_Race = u45,
                selected_Trait = u46
            });
            u50:Destroy();
            u66:Disconnect();
        end);
    end
};