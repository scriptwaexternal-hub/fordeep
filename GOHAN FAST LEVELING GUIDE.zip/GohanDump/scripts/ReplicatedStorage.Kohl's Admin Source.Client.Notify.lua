-- Decompiled with Potassium's decompiler.

local Parent = require(script.Parent.Parent);
local UI = Parent.UI;
local u1 = {};
local u2 = {};

local function resetOffset(p3: boolean?) -- Line: 6
    -- upvalues: u1 (copy), u2 (copy), UI (copy)
    local v4 = 0;
    local v5;

    if p3 then
        v5 = u1;
    else
        v5 = u2;
    end;

    for _, v in ipairs(v5) do
        local v6, _, v7 = unpack(v);
        v7(v4, true);
        v4 = v4 + (v6.AbsoluteSize.Y + UI.Theme.Padding._value.Offset);
    end;

    return v4;
end;

local function hide(p8: any, p9: boolean?) -- Line: 16
    -- upvalues: u1 (copy), u2 (copy), UI (copy), resetOffset (copy)
    local v10;

    if p9 then
        v10 = u1;
    else
        v10 = u2;
    end;

    local v11, v12 = unpack(p8);
    local table_find_ret = table.find(v10, p8);

    if not table_find_ret then
        return;
    end;

    UI.Sound.Swipe:Play();
    table.remove(v10, table_find_ret);
    resetOffset(p9);
    v11.ZIndex = -1;
    v12(nil);
    task.delay(1 + UI.Theme.TweenOut._value.Time, v11.Destroy, v11);
end;

return function(p13) -- Line: 32
    -- upvalues: UI (copy), hide (copy), Parent (copy), u1 (copy), u2 (copy), resetOffset (copy)
    if type(p13) ~= "table" then
        return;
    end;

    if not p13.Text then
        p13.Text = "No text provided";
    end;

    local u14 = UI.state(false);
    local u15 = UI.state(0);
    local u16 = nil;
    local Activated = p13.Activated;
    local Announce = p13.Announce;
    local Close = p13.Close;
    local From = p13.From;
    local Name = p13.Name;
    local Image = p13.Image;
    local Sound = p13.Sound;
    local UserFrame = p13.UserFrame;
    p13.Activated = nil;
    p13.Announce = nil;
    p13.Close = nil;
    p13.From = nil;
    p13.Name = nil;
    p13.Image = nil;
    p13.Sound = nil;
    p13.UserFrame = nil;

    local function close() -- Line: 62
        -- upvalues: u16 (ref), Close (copy), hide (ref), Announce (copy)
        if not u16 then
            return;
        end;

        if Close then
            task.spawn(Close, u16);
        end;

        hide(u16, Announce);
    end;

    if Announce and not p13.TextSize then
        p13.TextSize = Parent.UI.Theme.FontSizeLarge;
    end;

    local u17 = nil;
    local Dialog = UI.new("Dialog");
    local merge = Parent.Util.Table.merge;
    local v18 = {
        Parent = UI.LayerTopInset,
        Close = close,
        Duration = #p13.Text * 0.0625 + 4,
        ExitButton = true,
        Size = UDim2.fromScale(0.5, 0)
    };
    local v19;

    if Announce then
        v19 = Vector2.new(0.5, 1);
    else
        v19 = Vector2.new(1, 1);
    end;

    v18.AnchorPoint = v19;
    local v20;

    if Announce then
        v20 = UI.spring(function() -- Line: 86
            -- upvalues: UI (ref), u14 (copy), u15 (copy), u17 (ref)
            local Offset = UI.Theme.Padding().Offset;
            local Height = UI.TopbarInset().Height;
            local v21;

            if u14() then
                v21 = Offset + u15() + u17._instance.AbsoluteSize.Y;
            else
                v21 = -Height - 32;
            end;

            return UDim2.new(0.5, 0, 0, v21);
        end, 16, 0.5);
    else
        v20 = UI.spring(function() -- Line: 92
            -- upvalues: UI (ref), u14 (copy), u15 (copy)
            local Offset = UI.Theme.Padding().Offset;

            return UDim2.new(1, not u14() and 288 or -Offset, 1, -(Offset + u15()));
        end, 16, 0.625);
    end;

    v18.Position = v20;
    local v22;

    if Announce then
        v22 = UI.new("UIPadding")({
            PaddingLeft = UI.Theme.Padding,
            PaddingRight = UI.Theme.Padding,
            PaddingTop = UI.Theme.Padding,
            PaddingBottom = UI.Theme.Padding
        });
    else
        v22 = nil;
    end;

    v18[1] = v22;
    u17 = Dialog(merge(v18, p13));

    if type(Activated) == "function" then
        u17._instance.Active = true;
        u17._instance.Activated:Once(function() -- Line: 108
            -- upvalues: Activated (copy), u16 (ref), Close (copy), hide (ref), Announce (copy)
            task.spawn(Activated);

            if not u16 then
                return;
            end;

            if Close then
                task.spawn(Close, u16);
            end;

            hide(u16, Announce);
        end);
    end;

    UI.new("UISizeConstraint")({
        Parent = u17._instance,
        MaxSize = Vector2.new(Announce and 512 or 256, 9000000000)
    });
    UI.Haptic.Notification:Play();

    if UserFrame or From then
        local v23;

        if UserFrame then
            v23 = Parent.client.UserFrame(unpack(UserFrame));
        else
            v23 = Parent.client.UserFrame(From, Name, Image);
        end;

        UI.edit(v23, {
            Parent = u17,
            UI.new("UIListLayout")({
                SortOrder = Enum.SortOrder.LayoutOrder,
                Padding = UDim.new(0, 4),
                FillDirection = Enum.FillDirection.Horizontal
            }),
            UI.new("Spacer")({
                LayoutOrder = 8
            }),
            u17._exitButton
        });
    end;

    local v24;

    if Announce then
        v24 = u1;
    else
        v24 = u2;
    end;

    u16 = {
        u17._instance,
        u14,
        u15,
        p13.Duration
    };
    table.insert(v24, 1, u16);
    task.defer(function() -- Line: 142
        -- upvalues: u14 (copy)
        u14(true);
    end);

    if resetOffset(Announce) > UI.LayerTopInset.AbsoluteSize.Y / (Announce and 2 or 1) then
        for i = #v24, 1, -1 do
            local _, _, _, v25 = unpack(v24[i]);

            if v25 ~= 0 then
                hide(v24[i], Announce);
                break;
            end;

            local _ = i;
        end;
    end;

    UI.Sound[Sound or (Announce and "Notification_Low" or "Notification_High")]:Play();

    return u17;
end;