-- Decompiled with Potassium's decompiler.

local InsertService = game:GetService("InsertService");
local MarketplaceService = game:GetService("MarketplaceService");
local RunService = game:GetService("RunService");
local u1 = {
    Enum.AssetType.Face.Value,
    Enum.AssetType.Shirt.Value,
    Enum.AssetType.Pants.Value,
    Enum.AssetType.TShirt.Value
};
local u2 = {
    Decal = "Texture",
    Shirt = "ShirtTemplate",
    Pants = "PantsTemplate",
    ShirtGraphic = "Graphic"
};
local u3 = {};

return function(u4: number, p5: boolean?) -- Line: 21, Name: getTexture
    -- upvalues: u3 (copy), MarketplaceService (copy), RunService (copy), u1 (copy), InsertService (copy), u2 (copy)
    local v6 = u3[u4];

    if v6 then
        return v6;
    end;

    local success, result = pcall(MarketplaceService.GetProductInfoAsync, MarketplaceService, u4);

    if success then
        local v7 = false;

        if result.AssetTypeId == Enum.AssetType.Image.Value then
            v7 = "rbxassetid://" .. u4;
        elseif RunService:IsServer() and table.find(u1, result.AssetTypeId) then
            local success2, result2 = pcall(function() -- Line: 37
                -- upvalues: InsertService (ref), u4 (copy)
                return InsertService:LoadAsset(u4);
            end);

            if success2 then
                local v8 = result2:GetChildren()[1];
                v7 = v8[u2[v8.ClassName]];
                result2:Destroy();
            end;
        end;

        if not v7 then
            local v9 = p5 and 150 or 420;
            v7 = `rbxthumb://type=Asset&id={u4}&w={v9}&h={v9}`;
        end;

        u3[u4] = v7;

        return v7;
    end;
end;