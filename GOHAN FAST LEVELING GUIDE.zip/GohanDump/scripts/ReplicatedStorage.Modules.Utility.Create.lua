-- Decompiled with Potassium's decompiler.

local Debris = game:GetService("Debris");

local function safeDestroyTime(p1, p2) -- Line: 29
    if p1 == nil then
        return 5;
    end;

    if type(p1) ~= "number" then
        error(("[Create.%s] destroyTime must be a number, got %s — did you pass a PathData table instead of a duration?"):format(p2 or "new", (type(p1))), 3);
    end;

    return p1;
end;

return {
    new = function(p3, p4, p5) -- Line: 40, Name: new
        -- upvalues: Debris (copy)
        if p5 == nil then
            p5 = 5;
        elseif type(p5) ~= "number" then
            error(("[Create.%s] destroyTime must be a number, got %s — did you pass a PathData table instead of a duration?"):format("new", (type(p5))), 3);
        end;

        local BoolValue = Instance.new("BoolValue");
        BoolValue.Name = p4;
        BoolValue.Parent = p3;
        Debris:AddItem(BoolValue, p5);

        return BoolValue;
    end,

    value = function(p6, p7, p8, p9) -- Line: 49, Name: value
        -- upvalues: Debris (copy)
        if p9 == nil then
            p9 = 5;
        elseif type(p9) ~= "number" then
            error(("[Create.%s] destroyTime must be a number, got %s — did you pass a PathData table instead of a duration?"):format("value", (type(p9))), 3);
        end;

        local NumberValue = Instance.new("NumberValue");
        NumberValue.Name = p7;
        NumberValue.Value = p8;
        NumberValue.Parent = p6;
        Debris:AddItem(NumberValue, p9);

        return NumberValue;
    end,

    string = function(p10, p11, p12, p13) -- Line: 59, Name: string
        -- upvalues: Debris (copy)
        if p13 == nil then
            p13 = 5;
        elseif type(p13) ~= "number" then
            error(("[Create.%s] destroyTime must be a number, got %s — did you pass a PathData table instead of a duration?"):format("string", (type(p13))), 3);
        end;

        local StringValue = Instance.new("StringValue");
        StringValue.Name = p11;
        StringValue.Value = p12;
        StringValue.Parent = p10;
        Debris:AddItem(StringValue, p13);

        return StringValue;
    end,

    NewNoDestroy = function(p14, p15) -- Line: 70, Name: NewNoDestroy
        local BoolValue = Instance.new("BoolValue");
        BoolValue.Name = p15;
        BoolValue.Parent = p14;

        return BoolValue;
    end
};