-- Decompiled with Potassium's decompiler.

local Players = game:GetService("Players");
local ReplicatedStorage = game:GetService("ReplicatedStorage");
local TweenService = game:GetService("TweenService");
local TextService = game:GetService("TextService");
local LocalPlayer = Players.LocalPlayer;
local QuestRemote = ReplicatedStorage:WaitForChild("Remotes"):WaitForChild("QuestRemote");
local u1 = {};
local u2 = {
    STORY = Color3.fromRGB(255, 106, 90),
    CONTRACT = Color3.fromRGB(94, 222, 130),
    CLASS = Color3.fromRGB(110, 170, 255),
    SIDE = Color3.fromRGB(64, 200, 190),
    TRAINING = Color3.fromRGB(250, 204, 90),
    FORM = Color3.fromRGB(196, 140, 252),
    RESEARCH = Color3.fromRGB(240, 130, 200),
    ["KING KAI"] = Color3.fromRGB(120, 220, 240),
    QUEST = Color3.fromRGB(200, 200, 200)
};
local Color3_fromRGB_ret = Color3.fromRGB(44, 44, 45);
local Color3_fromRGB_ret2 = Color3.fromRGB(28, 28, 30);
local Color3_fromRGB_ret3 = Color3.fromRGB(0, 0, 0);
local Color3_fromRGB_ret4 = Color3.fromRGB(255, 255, 255);
Color3.fromRGB(150, 150, 150);
Color3.fromRGB(216, 213, 205);
local Color3_fromRGB_ret5 = Color3.fromRGB(88, 214, 106);
local Color3_fromRGB_ret6 = Color3.fromRGB(240, 200, 110);
local Color3_fromRGB_ret7 = Color3.fromRGB(255, 110, 100);
local Arcade = Enum.Font.Arcade;
local Bangers = Enum.Font.Bangers;
local Color3_fromRGB_ret8 = Color3.fromRGB(220, 40, 40);
local Color3_fromRGB_ret9 = Color3.fromRGB(255, 85, 85);

local function fitLabel(p3, p4, p5) -- Line: 87
    -- upvalues: TextService (copy)
    local TextSize = TextService:GetTextSize(p5 or p3.Text, p3.TextSize, p3.Font, Vector2.new(p4, 10000));
    p3.Size = UDim2.new(p3.Size.X.Scale, p3.Size.X.Offset, 0, math.ceil(TextSize.Y) + 2);
end;

local function toHex(p6) -- Line: 93
    return string.format("#%02X%02X%02X", math.floor(p6.R * 255 + 0.5), math.floor(p6.G * 255 + 0.5), (math.floor(p6.B * 255 + 0.5)));
end;

local function escapeRich(p7) -- Line: 98
    return tostring(p7):gsub("&", "&amp;"):gsub("<", "&lt;"):gsub(">", "&gt;");
end;

local function addStroke(p8) -- Line: 103
    -- upvalues: Color3_fromRGB_ret3 (copy)
    p8.TextStrokeColor3 = Color3_fromRGB_ret3;
    p8.TextStrokeTransparency = 0.5;
end;

local function outline(p9, p10) -- Line: 108
    -- upvalues: Color3_fromRGB_ret3 (copy)
    local UIStroke = Instance.new("UIStroke");
    UIStroke.Color = Color3_fromRGB_ret3;
    UIStroke.Thickness = p10 or 1.5;
    UIStroke.ApplyStrokeMode = Enum.ApplyStrokeMode.Border;
    UIStroke.Parent = p9;

    return UIStroke;
end;

local u11 = false;
local u12 = nil;
local u13 = {};
local u14 = 1;

local function buildGui() -- Line: 126
    -- upvalues: LocalPlayer (copy), u12 (ref), Color3_fromRGB_ret2 (copy), Arcade (copy), Color3_fromRGB_ret4 (copy), Color3_fromRGB_ret3 (copy)
    local PlayerGui = LocalPlayer:WaitForChild("PlayerGui");
    local QuestTrackerGui = PlayerGui:FindFirstChild("QuestTrackerGui");

    if QuestTrackerGui then
        QuestTrackerGui:Destroy();
    end;

    local ScreenGui = Instance.new("ScreenGui");
    ScreenGui.Name = "QuestTrackerGui";
    ScreenGui.ResetOnSpawn = false;
    ScreenGui.Enabled = game.PlaceId ~= 89366025586253;
    ScreenGui.DisplayOrder = -1;
    ScreenGui.IgnoreGuiInset = false;
    ScreenGui.Parent = PlayerGui;
    u12 = Instance.new("ScrollingFrame");
    u12.Name = "Tracker";
    u12.AnchorPoint = Vector2.new(0, 0);
    u12.Position = UDim2.new(0, 12, 0.31, 0);
    u12.Size = UDim2.new(0, 200, 0.24, 0);
    u12.BackgroundTransparency = 1;
    u12.BorderSizePixel = 0;
    u12.ScrollBarThickness = 4;
    u12.ScrollBarImageTransparency = 0.4;
    u12.ScrollingDirection = Enum.ScrollingDirection.Y;
    u12.AutomaticCanvasSize = Enum.AutomaticSize.Y;
    u12.CanvasSize = UDim2.new(0, 0, 0, 0);
    u12.Parent = ScreenGui;
    local TextButton = Instance.new("TextButton");
    TextButton.Name = "TrackerToggle";
    TextButton.AnchorPoint = Vector2.new(0, 1);
    TextButton.Position = UDim2.new(0, 12, 0.31, -4);
    TextButton.Size = UDim2.fromOffset(84, 18);
    TextButton.BackgroundColor3 = Color3_fromRGB_ret2;
    TextButton.BackgroundTransparency = 0;
    TextButton.BorderSizePixel = 0;
    TextButton.Font = Arcade;
    TextButton.TextSize = 12;
    TextButton.TextColor3 = Color3_fromRGB_ret4;
    TextButton.Text = "▼ QUESTS";
    TextButton.TextStrokeColor3 = Color3_fromRGB_ret3;
    TextButton.TextStrokeTransparency = 0.5;
    TextButton.Parent = ScreenGui;
    local UIStroke = Instance.new("UIStroke");
    UIStroke.Color = Color3_fromRGB_ret3;
    UIStroke.Thickness = 1.5;
    UIStroke.ApplyStrokeMode = Enum.ApplyStrokeMode.Border;
    UIStroke.Parent = TextButton;
    TextButton.Activated:Connect(function() -- Line: 182
        -- upvalues: u12 (ref), TextButton (copy)
        u12.Visible = not u12.Visible;
        TextButton.Text = u12.Visible and "▼ QUESTS" or "▶ QUESTS";
    end);
    local UIListLayout = Instance.new("UIListLayout");
    UIListLayout.FillDirection = Enum.FillDirection.Vertical;
    UIListLayout.HorizontalAlignment = Enum.HorizontalAlignment.Left;
    UIListLayout.VerticalAlignment = Enum.VerticalAlignment.Top;
    UIListLayout.SortOrder = Enum.SortOrder.LayoutOrder;
    UIListLayout.Padding = UDim.new(0, 6);
    UIListLayout.Parent = u12;
end;

local function makeObjectiveRow(p15, p16) -- Line: 197
    -- upvalues: Bangers (copy), Color3_fromRGB_ret3 (copy)
    local TextLabel = Instance.new("TextLabel");
    TextLabel.Name = "Obj_" .. tostring(p16.Id);
    TextLabel.BackgroundTransparency = 1;
    TextLabel.Size = UDim2.new(1, 0, 0, 15);
    TextLabel.Font = Bangers;
    TextLabel.TextSize = 12;
    TextLabel.TextWrapped = true;
    TextLabel.TextXAlignment = Enum.TextXAlignment.Left;
    TextLabel.RichText = true;
    TextLabel.TextStrokeColor3 = Color3_fromRGB_ret3;
    TextLabel.TextStrokeTransparency = 0.5;
    TextLabel.Parent = p15;

    return TextLabel;
end;

local function styleObjectiveRow(p17, p18, p19) -- Line: 212
    -- upvalues: Color3_fromRGB_ret5 (copy), Color3_fromRGB_ret4 (copy), fitLabel (copy), TweenService (copy)
    local v20 = p18.Max and p18.Max > 1 and string.format(" (%d/%d)", math.min(p18.Current or 0, p18.Max), p18.Max) or (p18.Done and "" or string.format(" (%d/%d)", p18.Current or 0, p18.Max or 1));
    local v21 = (p18.Done and "[X]" or "[ ]") .. " " .. tostring(p18.Text) .. v20;

    if p18.Done then
        p17.TextColor3 = Color3_fromRGB_ret5;
        p17.TextTransparency = 0.15;
        p17.Text = "[X]" .. " " .. tostring(p18.Text):gsub("&", "&amp;"):gsub("<", "&lt;"):gsub(">", "&gt;") .. v20;
    else
        p17.TextColor3 = Color3_fromRGB_ret4;
        p17.TextTransparency = 0;
        p17.Text = "[ ]" .. " " .. tostring(p18.Text):gsub("&", "&amp;"):gsub("<", "&lt;"):gsub(">", "&gt;") .. v20;
    end;

    fitLabel(p17, 186, v21);

    if p19 and p18.Done then
        p17.TextTransparency = 0;
        TweenService:Create(p17, TweenInfo.new(0.9, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
            TextTransparency = 0.15
        }):Play();
    end;
end;

local function applyCollapse(p22) -- Line: 236
    local v23 = 0;

    for _ in pairs(p22.ObjState) do
        v23 = v23 + 1;
    end;

    for i, v in pairs(p22.ObjRows) do
        local v24 = p22.ObjState[i];

        if v23 > 3 then
            if v24 then
                v24 = v24.Done;
            end;
        else
            v24 = false;
        end;

        v.Visible = not v24;
    end;
end;

local function makeEntry(u25) -- Line: 245
    -- upvalues: u2 (copy), Color3_fromRGB_ret (copy), u14 (ref), u12 (ref), Color3_fromRGB_ret3 (copy), Arcade (copy), Color3_fromRGB_ret4 (copy), escapeRich (copy), fitLabel (copy), Bangers (copy), Color3_fromRGB_ret6 (copy), Color3_fromRGB_ret8 (copy), Color3_fromRGB_ret9 (copy), QuestRemote (copy), makeObjectiveRow (copy), styleObjectiveRow (copy), applyCollapse (copy), TweenService (copy)
    local v26 = u2[u25.Category] or u2.QUEST;
    local CanvasGroup = Instance.new("CanvasGroup");
    CanvasGroup.Name = u25.QuestName;
    CanvasGroup.BackgroundColor3 = Color3_fromRGB_ret;
    CanvasGroup.BackgroundTransparency = 0;
    CanvasGroup.BorderSizePixel = 0;
    CanvasGroup.Size = UDim2.new(1, 0, 0, 0);
    CanvasGroup.AutomaticSize = Enum.AutomaticSize.Y;
    CanvasGroup.GroupTransparency = 1;
    CanvasGroup.LayoutOrder = u25.Story and 0 or u14;
    u14 = u14 + 1;
    CanvasGroup.Parent = u12;
    local UIStroke = Instance.new("UIStroke");
    UIStroke.Color = Color3_fromRGB_ret3;
    UIStroke.Thickness = 1.5;
    UIStroke.ApplyStrokeMode = Enum.ApplyStrokeMode.Border;
    UIStroke.Parent = CanvasGroup;
    local Frame = Instance.new("Frame");
    Frame.Name = "Accent";
    Frame.BackgroundColor3 = v26;
    Frame.BorderSizePixel = 0;
    Frame.Size = UDim2.new(1, 0, 0, 4);
    Frame.Parent = CanvasGroup;
    local Frame2 = Instance.new("Frame");
    Frame2.Name = "Content";
    Frame2.BackgroundTransparency = 1;
    Frame2.Position = UDim2.new(0, 8, 0, 8);
    Frame2.Size = UDim2.new(1, -14, 0, 0);
    Frame2.AutomaticSize = Enum.AutomaticSize.Y;
    Frame2.Parent = CanvasGroup;
    local UIPadding = Instance.new("UIPadding");
    UIPadding.PaddingBottom = UDim.new(0, 6);
    UIPadding.Parent = Frame2;
    local UIListLayout = Instance.new("UIListLayout");
    UIListLayout.FillDirection = Enum.FillDirection.Vertical;
    UIListLayout.SortOrder = Enum.SortOrder.LayoutOrder;
    UIListLayout.Padding = UDim.new(0, 2);
    UIListLayout.Parent = Frame2;
    local TextLabel = Instance.new("TextLabel");
    TextLabel.Name = "Header";
    TextLabel.BackgroundTransparency = 1;
    TextLabel.Size = UDim2.new(1, -16, 0, 16);
    TextLabel.Font = Arcade;
    TextLabel.TextSize = 11;
    TextLabel.TextWrapped = true;
    TextLabel.TextXAlignment = Enum.TextXAlignment.Left;
    TextLabel.RichText = true;
    TextLabel.TextColor3 = Color3_fromRGB_ret4;
    TextLabel.LayoutOrder = 1;
    TextLabel.Text = string.format("<font color=\"%s\">[%s]</font> %s", string.format("#%02X%02X%02X", math.floor(v26.R * 255 + 0.5), math.floor(v26.G * 255 + 0.5), (math.floor(v26.B * 255 + 0.5))), tostring(u25.Category or "QUEST"):gsub("&", "&amp;"):gsub("<", "&lt;"):gsub(">", "&gt;"), escapeRich(u25.QuestName));
    TextLabel.TextStrokeColor3 = Color3_fromRGB_ret3;
    TextLabel.TextStrokeTransparency = 0.5;
    TextLabel.Parent = Frame2;
    fitLabel(TextLabel, 170, "[" .. tostring(u25.Category or "QUEST") .. "] " .. tostring(u25.QuestName));
    local TextLabel2 = Instance.new("TextLabel");
    TextLabel2.Name = "Timer";
    TextLabel2.BackgroundTransparency = 1;
    TextLabel2.Size = UDim2.new(1, 0, 0, 12);
    TextLabel2.Font = Bangers;
    TextLabel2.TextSize = 11;
    TextLabel2.TextXAlignment = Enum.TextXAlignment.Left;
    TextLabel2.TextColor3 = Color3_fromRGB_ret6;
    TextLabel2.LayoutOrder = 3;
    TextLabel2.Visible = false;
    TextLabel2.TextStrokeColor3 = Color3_fromRGB_ret3;
    TextLabel2.TextStrokeTransparency = 0.5;
    TextLabel2.Parent = Frame2;
    local Frame3 = Instance.new("Frame");
    Frame3.Name = "Objectives";
    Frame3.BackgroundTransparency = 1;
    Frame3.Size = UDim2.new(1, 0, 0, 0);
    Frame3.AutomaticSize = Enum.AutomaticSize.Y;
    Frame3.LayoutOrder = 4;
    Frame3.Parent = Frame2;
    local UIListLayout2 = Instance.new("UIListLayout");
    UIListLayout2.FillDirection = Enum.FillDirection.Vertical;
    UIListLayout2.SortOrder = Enum.SortOrder.LayoutOrder;
    UIListLayout2.Padding = UDim.new(0, 2);
    UIListLayout2.Parent = Frame3;

    if u25.Skippable then
        local TextButton = Instance.new("TextButton");
        TextButton.Name = "Quit";
        TextButton.AnchorPoint = Vector2.new(1, 0);
        TextButton.Position = UDim2.new(1, -4, 0, 6);
        TextButton.Size = UDim2.new(0, 16, 0, 16);
        TextButton.BackgroundTransparency = 1;
        TextButton.Font = Enum.Font.Bangers;
        TextButton.TextSize = 16;
        TextButton.Text = "X";
        TextButton.TextColor3 = Color3_fromRGB_ret8;
        TextButton.Parent = CanvasGroup;
        local UIStroke2 = Instance.new("UIStroke");
        UIStroke2.Color = Color3.fromRGB(0, 0, 0);
        UIStroke2.Thickness = 2;
        UIStroke2.ApplyStrokeMode = Enum.ApplyStrokeMode.Contextual;
        UIStroke2.LineJoinMode = Enum.LineJoinMode.Round;
        UIStroke2.Parent = TextButton;
        TextButton.MouseEnter:Connect(function() -- Line: 358
            -- upvalues: TextButton (ref), Color3_fromRGB_ret9 (ref)
            TextButton.TextColor3 = Color3_fromRGB_ret9;
        end);
        TextButton.MouseLeave:Connect(function() -- Line: 359
            -- upvalues: TextButton (ref), Color3_fromRGB_ret8 (ref)
            TextButton.TextColor3 = Color3_fromRGB_ret8;
        end);
        TextButton.Activated:Connect(function() -- Line: 360
            -- upvalues: QuestRemote (ref), u25 (copy)
            QuestRemote:FireServer({
                QuestName = u25.QuestName
            }, "AbandonQuest");
        end);
    end;

    local v27 = {
        Closing = false,
        Frame = CanvasGroup,
        Accent = Frame,
        Header = TextLabel,
        Category = u25.Category or "QUEST",
        TimerLabel = TextLabel2,
        ObjHolder = Frame3,
        ObjRows = {},
        ObjState = {}
    };

    for _, v in ipairs(u25.Objectives or {}) do
        local v28 = makeObjectiveRow(Frame3, v);
        v28.LayoutOrder = #v27.ObjRows + 1;
        styleObjectiveRow(v28, v, false);
        v27.ObjRows[v.Id] = v28;
        v27.ObjState[v.Id] = v;
    end;

    applyCollapse(v27);
    local UIScale = Instance.new("UIScale");
    UIScale.Scale = 0.92;
    UIScale.Parent = CanvasGroup;
    TweenService:Create(CanvasGroup, TweenInfo.new(0.35, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
        GroupTransparency = 0
    }):Play();
    TweenService:Create(UIScale, TweenInfo.new(0.35, Enum.EasingStyle.Back, Enum.EasingDirection.Out), {
        Scale = 1
    }):Play();

    return v27;
end;

local function fadeOutAndDestroy(u29, p30) -- Line: 398
    -- upvalues: TweenService (copy)
    if u29.Closing then
        return;
    end;

    u29.Closing = true;
    task.delay(p30 or 0, function() -- Line: 401
        -- upvalues: u29 (copy), TweenService (ref)
        if not u29.Frame.Parent then
            return;
        end;

        local v31 = TweenService:Create(u29.Frame, TweenInfo.new(0.4, Enum.EasingStyle.Quad, Enum.EasingDirection.In), {
            GroupTransparency = 1
        });
        v31.Completed:Once(function() -- Line: 406
            -- upvalues: u29 (ref)
            if u29.Frame then
                u29.Frame:Destroy();
            end;
        end);
        v31:Play();
    end);
end;

local u32 = nil;

local function showCompleteBanner(p33) -- Line: 420
    -- upvalues: u12 (ref), u32 (ref), Color3_fromRGB_ret3 (copy), Color3_fromRGB_ret5 (copy), Arcade (copy), Bangers (copy), Color3_fromRGB_ret4 (copy), fitLabel (copy), TweenService (copy)
    local v34 = u12 and u12.Parent;

    if not v34 then
        return;
    end;

    if u32 and u32.Parent then
        u32:Destroy();
    end;

    local CanvasGroup = Instance.new("CanvasGroup");
    CanvasGroup.Name = "QuestCompleteBanner";
    CanvasGroup.AnchorPoint = Vector2.new(0.5, 0.5);
    CanvasGroup.Position = UDim2.new(0.5, 0, 0.5, 0);
    CanvasGroup.Size = UDim2.new(0, 200, 0, 0);
    CanvasGroup.AutomaticSize = Enum.AutomaticSize.Y;
    CanvasGroup.BackgroundColor3 = Color3_fromRGB_ret3;
    CanvasGroup.BorderSizePixel = 0;
    CanvasGroup.GroupTransparency = 1;
    CanvasGroup.Parent = v34;
    local UIStroke = Instance.new("UIStroke");
    UIStroke.Color = Color3_fromRGB_ret3;
    UIStroke.Thickness = 1.5;
    UIStroke.ApplyStrokeMode = Enum.ApplyStrokeMode.Border;
    UIStroke.Parent = CanvasGroup;
    u32 = CanvasGroup;
    local Frame = Instance.new("Frame");
    Frame.BackgroundColor3 = Color3_fromRGB_ret5;
    Frame.BorderSizePixel = 0;
    Frame.Size = UDim2.new(1, 0, 0, 4);
    Frame.Parent = CanvasGroup;
    local TextLabel = Instance.new("TextLabel");
    TextLabel.BackgroundTransparency = 1;
    TextLabel.Position = UDim2.new(0, 8, 0, 8);
    TextLabel.Size = UDim2.new(1, -16, 0, 14);
    TextLabel.Font = Arcade;
    TextLabel.TextSize = 12;
    TextLabel.TextXAlignment = Enum.TextXAlignment.Center;
    TextLabel.TextColor3 = Color3_fromRGB_ret5;
    TextLabel.Text = "QUEST COMPLETE!";
    TextLabel.TextStrokeColor3 = Color3_fromRGB_ret3;
    TextLabel.TextStrokeTransparency = 0.5;
    TextLabel.Parent = CanvasGroup;
    local TextLabel2 = Instance.new("TextLabel");
    TextLabel2.BackgroundTransparency = 1;
    TextLabel2.Position = UDim2.new(0, 8, 0, 24);
    TextLabel2.Size = UDim2.new(1, -16, 0, 14);
    TextLabel2.Font = Bangers;
    TextLabel2.TextSize = 12;
    TextLabel2.TextWrapped = true;
    TextLabel2.TextXAlignment = Enum.TextXAlignment.Center;
    TextLabel2.TextColor3 = Color3_fromRGB_ret4;
    TextLabel2.Text = tostring(p33):gsub("&", "&amp;"):gsub("<", "&lt;"):gsub(">", "&gt;");
    TextLabel2.TextStrokeColor3 = Color3_fromRGB_ret3;
    TextLabel2.TextStrokeTransparency = 0.5;
    TextLabel2.Parent = CanvasGroup;
    fitLabel(TextLabel2, 184, (tostring(p33)));
    CanvasGroup.AutomaticSize = Enum.AutomaticSize.None;
    CanvasGroup.Size = UDim2.new(0, 200, 0, 24 + TextLabel2.Size.Y.Offset + 8);
    local UIPadding = Instance.new("UIPadding");
    UIPadding.PaddingBottom = UDim.new(0, 8);
    UIPadding.Parent = CanvasGroup;
    local UIScale = Instance.new("UIScale");
    UIScale.Scale = 0.85;
    UIScale.Parent = CanvasGroup;
    TweenService:Create(CanvasGroup, TweenInfo.new(0.25, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
        GroupTransparency = 0
    }):Play();
    TweenService:Create(UIScale, TweenInfo.new(0.3, Enum.EasingStyle.Back, Enum.EasingDirection.Out), {
        Scale = 1
    }):Play();
    task.delay(2.6, function() -- Line: 485
        -- upvalues: CanvasGroup (copy), TweenService (ref), u32 (ref)
        if not CanvasGroup.Parent then
            return;
        end;

        local v35 = TweenService:Create(CanvasGroup, TweenInfo.new(0.4, Enum.EasingStyle.Quad, Enum.EasingDirection.In), {
            GroupTransparency = 1
        });
        v35.Completed:Once(function() -- Line: 489
            -- upvalues: CanvasGroup (ref), u32 (ref)
            if CanvasGroup.Parent then
                CanvasGroup:Destroy();
            end;

            if u32 == CanvasGroup then
                u32 = nil;
            end;
        end);
        v35:Play();
    end);
end;

function u1.Add(p36) -- Line: 499
    -- upvalues: u11 (ref), u13 (copy), u1 (copy), makeEntry (copy)
    if not (u11 and p36.QuestName) then
        return;
    end;

    if u13[p36.QuestName] then
        u1.Update({
            QuestName = p36.QuestName,
            Objectives = p36.Objectives
        });

        return;
    end;

    u13[p36.QuestName] = makeEntry(p36);
end;

function u1.Update(p37) -- Line: 510
    -- upvalues: u11 (ref), u13 (copy), makeObjectiveRow (copy), styleObjectiveRow (copy), applyCollapse (copy)
    if not u11 then
        return;
    end;

    local v38 = u13[p37.QuestName];

    if not v38 or v38.Closing then
        return;
    end;

    for _, v in ipairs(p37.Objectives or {}) do
        local v39 = v38.ObjRows[v.Id];

        if not v39 then
            v39 = makeObjectiveRow(v38.ObjHolder, v);
            v38.ObjRows[v.Id] = v39;
        end;

        local v40 = v38.ObjState[v.Id];
        local Done = v.Done;

        if Done then
            if v40 then
                v40 = v40.Done;
            end;

            Done = not v40;
        end;

        v38.ObjState[v.Id] = v;
        styleObjectiveRow(v39, v, Done);
    end;

    applyCollapse(v38);
end;

function u1.Timer(p41) -- Line: 528
    -- upvalues: u11 (ref), u13 (copy), Color3_fromRGB_ret7 (copy), Color3_fromRGB_ret6 (copy)
    if not u11 then
        return;
    end;

    local v42 = u13[p41.QuestName];

    if not v42 or v42.Closing then
        return;
    end;

    local v43 = tonumber(p41.TimeLeft) or 0;
    v42.TimerLabel.Visible = true;
    v42.TimerLabel.Text = "Time Left: " .. v43 .. "s";
    v42.TimerLabel.TextColor3 = v43 <= 30 and Color3_fromRGB_ret7 or Color3_fromRGB_ret6;
end;

function u1.Complete(p44) -- Line: 538
    -- upvalues: u11 (ref), u13 (copy), showCompleteBanner (copy), Color3_fromRGB_ret5 (copy), fitLabel (copy), styleObjectiveRow (copy), TweenService (copy)
    if not u11 then
        return;
    end;

    local u45 = u13[p44.QuestName];

    if not u45 then
        return;
    end;

    u13[p44.QuestName] = nil;
    showCompleteBanner(p44.QuestName);
    u45.Accent.BackgroundColor3 = Color3_fromRGB_ret5;
    u45.Header.TextColor3 = Color3_fromRGB_ret5;
    u45.Header.Text = "[X]" .. " " .. u45.Header.Text;
    fitLabel(u45.Header, 170, "[X]" .. " [" .. tostring(u45.Category) .. "] " .. tostring(p44.QuestName));

    for i, v in pairs(u45.ObjRows) do
        local v46 = u45.ObjState[i];

        if v46 then
            v46.Done = true;
            v46.Current = v46.Max;
            styleObjectiveRow(v, v46, false);
        end;

        v.Visible = true;
    end;

    if u45.Closing then
        return;
    end;

    u45.Closing = true;
    task.delay(2.5, function() -- Line: 401
        -- upvalues: u45 (copy), TweenService (ref)
        if not u45.Frame.Parent then
            return;
        end;

        local v47 = TweenService:Create(u45.Frame, TweenInfo.new(0.4, Enum.EasingStyle.Quad, Enum.EasingDirection.In), {
            GroupTransparency = 1
        });
        v47.Completed:Once(function() -- Line: 406
            -- upvalues: u45 (ref)
            if u45.Frame then
                u45.Frame:Destroy();
            end;
        end);
        v47:Play();
    end);
end;

function u1.Remove(p48) -- Line: 562
    -- upvalues: u11 (ref), u13 (copy), TweenService (copy)
    if not u11 then
        return;
    end;

    local u49 = u13[p48.QuestName];

    if not u49 then
        return;
    end;

    u13[p48.QuestName] = nil;

    if u49.Closing then
        return;
    end;

    u49.Closing = true;
    task.delay(0, function() -- Line: 401
        -- upvalues: u49 (copy), TweenService (ref)
        if not u49.Frame.Parent then
            return;
        end;

        local v50 = TweenService:Create(u49.Frame, TweenInfo.new(0.4, Enum.EasingStyle.Quad, Enum.EasingDirection.In), {
            GroupTransparency = 1
        });
        v50.Completed:Once(function() -- Line: 406
            -- upvalues: u49 (ref)
            if u49.Frame then
                u49.Frame:Destroy();
            end;
        end);
        v50:Play();
    end);
end;

function u1.Clear(p51) -- Line: 570
    -- upvalues: u11 (ref), u13 (copy)
    if not u11 then
        return;
    end;

    for i, v in pairs(u13) do
        u13[i] = nil;

        if v.Frame then
            v.Frame:Destroy();
        end;
    end;
end;

task.spawn(function() -- Line: 579
    -- upvalues: buildGui (copy), u11 (ref), QuestRemote (copy)
    buildGui();
    u11 = true;
    QuestRemote:FireServer(nil, "SyncRequest");
end);

return u1;