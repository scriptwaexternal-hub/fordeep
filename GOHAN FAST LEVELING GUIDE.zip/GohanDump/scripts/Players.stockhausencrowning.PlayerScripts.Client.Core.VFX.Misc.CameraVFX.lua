-- Decompiled with Potassium's decompiler.

game:GetService("Players");
game:GetService("Debris");
local ReplicatedStorage = game:GetService("ReplicatedStorage");
game:GetService("TweenService");
game:GetService("RunService");
game:GetService("UserInputService");
local Assets = ReplicatedStorage.Assets;
local Modules = ReplicatedStorage:WaitForChild("Modules");
ReplicatedStorage:WaitForChild("Remotes");
local _ = Modules.Metadata;
local Shared = Modules.Shared;
local _ = Modules.Utility;
local _ = Assets.Gui;
require(Shared.SoundManager);
require(Modules.GlobalFunctions);
local CamManager = require(Shared.CamManager);
require(Shared.CinemaManager);
require(Shared.CamShakeHandler);

return {
    ["Zoom Out"] = function(p1) -- Line: 29
        -- upvalues: CamManager (copy)
        CamManager.ZoomOut(p1);
    end,

    Tween = function(p2) -- Line: 33
        -- upvalues: CamManager (copy)
        CamManager.Tween(p2);
    end
};