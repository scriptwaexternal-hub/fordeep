-- Decompiled with Potassium's decompiler.

local Players = game:GetService("Players");
local generateValidate = require(script:WaitForChild("generateValidate"));
local Types = script:WaitForChild("Types");
local u1 = nil;
local v2 = {
    ["^%*$"] = "allPlayers",
    ["^all$"] = "allPlayers",
    ["@"] = "rolePlayers",
    ["%%"] = "teamPlayers",
    ["~"] = "randomPlayers",
    ["%$"] = "specialPlayers",
    ["^others$"] = "otherPlayers"
};
local u3 = { { { "*", "all" }, "*  [all] (Everyone)" }, { "@", "@\t\t(Roles)" }, { "%", "%\t\t(Teams)" }, { "~", "~\t\t(Random)" }, { "$", "$\t\t(Special)" }, { "others", "others   (Everyone else)" } };
local u4 = {};

local function memoizeUser(p5: userdata) -- Line: 46
    -- upvalues: u4 (copy)
    if not u4[p5.UserId] then
        u4[p5.UserId] = {
            freeThread = nil,
            Name = p5.Name,
            DisplayName = p5.DisplayName,
            UserId = p5.UserId
        };

        return;
    end;

    local freeThread = u4[p5.UserId].freeThread;

    if typeof(freeThread) == "thread" and coroutine.status(freeThread) == "suspended" then
        task.cancel(freeThread);
    end;
end;

local function freeUser(p6: number) -- Line: 61
    -- upvalues: u4 (copy)
    if u4[p6] then
        local freeThread = u4[p6].freeThread;

        if typeof(freeThread) == "thread" and coroutine.status(freeThread) == "suspended" then
            task.cancel(freeThread);
            u4[p6].freeThread = nil;
        end;
    end;

    u4[p6] = nil;
end;

Players.PlayerAdded:Connect(function(p7) -- Line: 72
    -- upvalues: u4 (copy)
    local UserId = p7.UserId;

    if u4[UserId] then
        local freeThread = u4[UserId].freeThread;

        if typeof(freeThread) == "thread" and coroutine.status(freeThread) == "suspended" then
            task.cancel(freeThread);
            u4[UserId].freeThread = nil;
        end;
    end;

    u4[UserId] = nil;
end);
Players.PlayerRemoving:Connect(function(p8) -- Line: 75
    -- upvalues: memoizeUser (copy), u4 (copy), freeUser (copy)
    memoizeUser(p8);
    u4[p8.UserId].freeThread = task.delay(120, freeUser, p8.UserId);
end);

local function sortPlayers(p9, p10) -- Line: 80
    -- upvalues: Players (copy)
    if p9 == Players.LocalPlayer then
        return true;
    end;

    if p10 == Players.LocalPlayer then
        return false;
    end;

    return p9.Name < p10.Name;
end;

local function playerSuggestion(p11, p12) -- Line: 89
    local v13;

    if p11.Name == p11.DisplayName then
        v13 = nil;
    else
        v13 = p11.DisplayName;
    end;

    local v14;

    if p11.GetAttribute then
        v14 = p11:GetAttribute("_KDisplayName");
    else
        v14 = nil;
    end;

    if v14 == p11.Name or v14 == v13 then
        v14 = nil;
    end;

    local v15 = { p12 };
    table.insert(v15, p11.Name);
    table.insert(v15, v13);
    table.insert(v15, v14);
    local v16 = not v13 and "" or ` [{v13}]`;
    local v17 = not v14 and "" or ` [{v14}]`;
    local v18;

    if p12 then
        v18 = `{p12} [{p11.Name}]{v16}{v17}`;
    else
        v18 = `{p11.Name} {v16}{v17}`;
    end;

    return { v15, v18, p11 };
end;

local function baseSuggestions(p19: any, p20: any, p21: any, p22: boolean?) -- Line: 112
    -- upvalues: Players (copy), u4 (copy), sortPlayers (copy), playerSuggestion (copy), u1 (ref), u3 (copy)
    local Players2 = Players:GetPlayers();
    local v23 = {};

    if p22 then
        for _, v in u4 do
            table.insert(Players2, v);
        end;
    end;

    table.sort(Players2, sortPlayers);

    if not p21.ignoreSelf then
        local v24 = playerSuggestion(Players.LocalPlayer, "me");
        table.insert(v23, v24);
    end;

    local Rank = u1.Auth.getRank(p20);

    for _, v in Players2 do
        if v.UserId ~= Players.LocalPlayer.UserId and (p20 == u1.creatorId or (not p21.lowerRank or u1.Auth.getRank(v.UserId) < Rank)) then
            local v25 = playerSuggestion(v);
            table.insert(v23, v25);
        end;
    end;

    for _, v in u3 do
        table.insert(v23, v);
    end;

    return v23;
end;

local function parseIndividual(p26, p27, p28) -- Line: 145
    -- upvalues: Players (copy), u4 (copy), sortPlayers (copy)
    if p26 == "" or p26 == "me" then
        return p27._K.Auth.targetUserArgument(p27, p27.command.from, p27.command.fromPlayer);
    end;

    local Players2 = Players:GetPlayers();

    if p28 then
        for _, v in u4 do
            table.insert(Players2, v);
        end;
    end;

    table.sort(Players2, sortPlayers);
    local v29 = nil;

    for _, v in Players2 do
        local string_lower_ret = string.lower(v.Name);

        if string_lower_ret == p26 then
            return p27._K.Auth.targetUserArgument(p27, v.UserId, v);
        end;

        if not v29 and string.find(string_lower_ret, p26, 1, true) == 1 then
            v29 = v;
        end;
    end;

    for _, v in Players2 do
        local string_lower_ret = string.lower(v.DisplayName);
        local v30 = p28 and "" or string.lower(v:GetAttribute("_KDisplayName") or "");

        if string_lower_ret == p26 or v30 == p26 then
            return p27._K.Auth.targetUserArgument(p27, v.UserId, v);
        end;

        if not (v29 or string.find(string_lower_ret, p26, 1, true) ~= 1 and string.find(v30, p26, 1, true) ~= 1) then
            v29 = v;
        end;
    end;

    if v29 then
        return p27._K.Auth.targetUserArgument(p27, v29.UserId, v29);
    end;

    return nil, "Invalid player";
end;

local u31 = {
    transform = string.lower,
    validate = generateValidate(parseIndividual),
    parse = parseIndividual,
    suggestions = baseSuggestions,
    prefixes = v2
};

local function parseUser(p32, p33) -- Line: 203
    -- upvalues: parseIndividual (copy), u1 (ref)
    local v34, v35 = parseIndividual(p32, p33, true);

    if v34 then
        p32 = v34.UserId;
    end;

    local v36 = tonumber(p32);

    if not v36 or v36 <= 0 then
        local v37 = nil;

        if v35 == "Invalid player" then
            return v37, "Invalid user";
        end;

        return v37, v35;
    end;

    local targetLimits = u1.Data.targetLimits;
    local from = p33.command.from;
    targetLimits[from] = targetLimits[from] - 1;

    return p33._K.Auth.targetUserArgument(p33, v36, v36);
end;

local u47 = {
    transform = string.lower,
    validate = parseUser,
    parse = parseUser,

    postParse = function(p38) -- Line: 217, Name: postParse
        local v39 = {};

        for _, v in p38 do
            if type(v) == "table" then
                for _, v3 in v do
                    local v40;

                    if type(v3) == "table" or typeof(v3) == "Instance" and v3:IsA("Player") then
                        v40 = v3.UserId;
                    else
                        v40 = v3;
                    end;

                    table.insert(v39, v40);
                end;
            else
                local v41;

                if type(v) == "table" or typeof(v) == "Instance" and v:IsA("Player") then
                    v41 = v.UserId;
                else
                    v41 = v;
                end;

                table.insert(v39, v41);
            end;
        end;

        return v39;
    end,

    suggestions = function(p42, p43, p44) -- Line: 237, Name: suggestions
        -- upvalues: baseSuggestions (copy)
        local v45 = baseSuggestions(p42, p43, p44, true);

        if tonumber(p42) then
            local v46 = {
                p42,
                nil,
                {
                    UserId = tonumber(p42)
                }
            };
            table.insert(v45, 1, v46);
        end;

        return v45;
    end,

    prefixes = v2
};

return function(p48) -- Line: 247
    -- upvalues: u1 (ref), u31 (copy), u47 (copy), Types (copy)
    u1 = p48;
    u1.Registry.registerType("player", u31);
    u1.Registry.registerType("players", {
        listable = true,

        postParse = function(p49) -- Line: 253, Name: postParse
            local v50 = {};

            for _, v in p49 do
                if type(v) == "table" then
                    for _, v3 in v do
                        table.insert(v50, v3);
                    end;
                else
                    table.insert(v50, v);
                end;
            end;

            return v50;
        end
    }, u31);
    u1.Registry.registerType("userId", u47);
    u1.Registry.registerType("userIds", {
        listable = true
    }, u47);

    for _, child in Types:GetChildren() do
        if child:IsA("ModuleScript") then
            require(child)(u1);
        end;
    end;
end;