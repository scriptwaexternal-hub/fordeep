-- Decompiled with Potassium's decompiler.

local Parent = require(script.Parent.Parent);
local BaseClass = require(script.Parent:WaitForChild("BaseClass"));
local u1 = require(script.Clack).registerAll();
u1.enabled = Parent.raw(Parent.Theme.TypingSounds);
u1.everyTextBox = Parent.raw(Parent.Theme.TypingSoundsOnEveryTextBox);
Parent.Theme.TypingSounds:Connect(function(p2) -- Line: 7
    -- upvalues: u1 (copy), Parent (copy)
    if p2 then
        p2 = Parent.Theme.SoundEnabled._value;
    end;

    u1.enabled = p2;
end);
Parent.Theme.TypingSoundsOnEveryTextBox:Connect(function(p3) -- Line: 10
    -- upvalues: u1 (copy)
    u1.everyTextBox = p3;
end);

local function stripNewLines(p4: string) -- Line: 14
    return string.gsub(string.gsub(p4, "\n", " "), "\r", " ");
end;

local function bytePositionToWidth(p5, p6, p7, p8, p9) -- Line: 20
    -- upvalues: Parent (copy)
    if p9 == 1 then
        return 0;
    end;

    local GetTextBoundsParams = Instance.new("GetTextBoundsParams");
    GetTextBoundsParams.Font = p7;
    GetTextBoundsParams.RichText = p8;
    GetTextBoundsParams.Size = p6;
    GetTextBoundsParams.Text = string.sub(p5, 1, p9 - 1);
    GetTextBoundsParams.Width = (1 / 0);
    local X = Parent.retryGetTextBoundsAsync(GetTextBoundsParams).X;

    return math.ceil(X);
end;

local function updateSelection(p10, p11, p12, p13, p14) -- Line: 35
    -- upvalues: Parent (copy)
    if not p14 then
        local Text = p12.Text;
        local TextSize = p11.TextSize;
        local FontFace = p11.FontFace;
        local RichText = p11.RichText;
        local CursorPosition = p12.CursorPosition;

        if CursorPosition == 1 then
            p14 = 0;
        else
            local GetTextBoundsParams = Instance.new("GetTextBoundsParams");
            GetTextBoundsParams.Font = FontFace;
            GetTextBoundsParams.RichText = RichText;
            GetTextBoundsParams.Size = TextSize;
            GetTextBoundsParams.Text = string.sub(Text, 1, CursorPosition - 1);
            GetTextBoundsParams.Width = (1 / 0);
            local X = Parent.retryGetTextBoundsAsync(GetTextBoundsParams).X;
            p14 = math.ceil(X);
        end;
    end;

    local Text = p12.Text;
    local TextSize = p11.TextSize;
    local FontFace = p11.FontFace;
    local RichText = p11.RichText;
    local SelectionStart = p12.SelectionStart;
    local v15;

    if SelectionStart == 1 then
        v15 = 0;
    else
        local GetTextBoundsParams = Instance.new("GetTextBoundsParams");
        GetTextBoundsParams.Font = FontFace;
        GetTextBoundsParams.RichText = RichText;
        GetTextBoundsParams.Size = TextSize;
        GetTextBoundsParams.Text = string.sub(Text, 1, SelectionStart - 1);
        GetTextBoundsParams.Width = (1 / 0);
        local X = Parent.retryGetTextBoundsAsync(GetTextBoundsParams).X;
        v15 = math.ceil(X);
    end;

    p10.Size = UDim2.fromOffset(p14 - v15, p11.TextSize);
    p10.Position = UDim2.new(0, v15 - p13._value, 0.5, 0);
    p10.Visible = true;
end;

local function updateCursor(p16, p17, p18, p19, p20, p21) -- Line: 46
    -- upvalues: Parent (copy), updateSelection (copy)
    local Text = p18.Text;
    local TextSize = p17.TextSize;
    local FontFace = p17.FontFace;
    local RichText = p17.RichText;
    local CursorPosition = p18.CursorPosition;
    local v22;

    if CursorPosition == 1 then
        v22 = 0;
    else
        local GetTextBoundsParams = Instance.new("GetTextBoundsParams");
        GetTextBoundsParams.Font = FontFace;
        GetTextBoundsParams.RichText = RichText;
        GetTextBoundsParams.Size = TextSize;
        GetTextBoundsParams.Text = string.sub(Text, 1, CursorPosition - 1);
        GetTextBoundsParams.Width = (1 / 0);
        local X = Parent.retryGetTextBoundsAsync(GetTextBoundsParams).X;
        v22 = math.ceil(X);
    end;

    local X = p16.Parent.AbsoluteSize.X;
    local v23 = v22 - p20._value;
    local v24 = (X < p17.TextBounds.X or p20._value > 0) and v22 > 32 and 32 or 0;

    if X < v23 then
        p20((math.min(p17.TextBounds.X, p20._value + v23 - X)));
        v24 = X;
    elseif v23 < v24 then
        p20(p20._value + v23 - v24);

        if v24 == 0 or p20._value <= p17.TextSize / 2 then
            p20((math.min(0, p20._value)));
        end;
    else
        v24 = v23;
    end;

    p18.Position = UDim2.fromOffset(-p20._value, 0);
    p16.Position = UDim2.fromOffset(v24, 1);
    p16.Visible = true;

    if p18.SelectionStart ~= -1 then
        updateSelection(p21, p17, p18, p20, v22);
    end;
end;

local u25 = {
    Enum.KeyCode.LeftControl,
    Enum.KeyCode.RightControl,
    Enum.KeyCode.LeftShift,
    Enum.KeyCode.RightShift,
    Enum.KeyCode.LeftAlt,
    Enum.KeyCode.RightAlt,
    Enum.KeyCode.LeftMeta,
    Enum.KeyCode.RightMeta,
    Enum.KeyCode.LeftSuper,
    Enum.KeyCode.RightSuper
};
local u26 = {
    Cursor = "_",
    DisplayText = "",
    Placeholder = "",
    Value = "",
    ClearTextButton = false,
    Fill = false,
    Icon = "",
    IconRightAlign = false,
    HotkeyInput = false,
    MaxChars = (1 / 0),
    NumberOnly = false,
    IntegerOnly = false,
    FontFace = Parent.Theme.Font,
    FontSize = Parent.Theme.FontSize,
    TextColor3 = Parent.Theme.PrimaryText,
    TextStrokeColor3 = Parent.Theme.Primary,
    TextStrokeTransparency = Parent.Theme.TextStrokeTransparency,
    Padding = Parent.Theme.Padding,
    IconProperties = {},
    Hotkey = Parent.Nil,
    Modifiers = Parent.Nil,
    NumberRange = NumberRange.new(0, 1),
    Validate = Parent.Function
};
local u27 = {};
u27.__index = u27;
setmetatable(u27, BaseClass);

function u27.new(p28) -- Line: 122
    -- upvalues: u26 (copy), Parent (copy), u25 (copy), updateSelection (copy), updateCursor (copy), u27 (copy)
    local table_clone_ret = table.clone(u26);
    Parent.makeStatefulDefaults(table_clone_ret, p28);
    table_clone_ret.IconProperties = {};
    local v29 = {};
    local u30 = Parent.state(Parent.raw(table_clone_ret.Value));

    local function v32() -- Line: 130
        -- upvalues: table_clone_ret (copy)
        local v31 = table_clone_ret.Fill();

        return UDim2.new(v31 and 1 or 0, v31 and 0 or table_clone_ret.FontSize(), 1, 0);
    end;

    local u37 = Parent.new("TextLabel")({
        AutoLocalize = false,
        BackgroundTransparency = 1,
        RichText = true,
        AutomaticSize = Enum.AutomaticSize.X,
        Size = v32,
        TextSize = table_clone_ret.FontSize,
        TextColor3 = table_clone_ret.TextColor3,
        FontFace = table_clone_ret.FontFace,
        TextXAlignment = Enum.TextXAlignment.Left,

        Text = function() -- Line: 145, Name: Text
            -- upvalues: table_clone_ret (copy), u30 (copy)
            local v33 = table_clone_ret.DisplayText();
            local v34 = table_clone_ret.Placeholder();
            local v35 = u30();
            local v36 = table_clone_ret.MaxChars();

            if v33 == "" then
                if v35 ~= "" then
                    v34 = v35;
                end;
            else
                v34 = v33;
            end;

            local string_gsub_ret = string.gsub(string.gsub(v34, "\n", " "), "\r", " ");

            if v36 == (1 / 0) then
                return string_gsub_ret;
            end;

            return string.sub(string_gsub_ret, 1, v36);
        end,

        TextTransparency = function() -- Line: 156, Name: TextTransparency
            -- upvalues: u30 (copy), table_clone_ret (copy)
            return u30() == "" and table_clone_ret.DisplayText() == "" and 0.5 or 0;
        end
    });
    table_clone_ret._displayLabel = u37;
    table_clone_ret._input = Parent.new("TextBox")({
        AutomaticSize = Enum.AutomaticSize.X,
        AutoLocalize = false,
        ClearTextOnFocus = false,
        Size = v32,
        BackgroundTransparency = 1,
        TextTransparency = 1,
        TextSize = table_clone_ret.FontSize,
        Text = table_clone_ret.Value,
        FontFace = table_clone_ret.FontFace,
        RichText = true,
        TextXAlignment = Enum.TextXAlignment.Left,
        CursorPosition = -1,
        u37,

        FocusLost = function() -- Line: 178, Name: FocusLost
            -- upvalues: table_clone_ret (copy), Parent (ref)
            local Text = table_clone_ret._input.Text;
            local _value = table_clone_ret.NumberOnly._value;
            local _value2 = table_clone_ret.IntegerOnly._value;

            if Text == "" and (_value or _value2) then
                table_clone_ret.Value(table_clone_ret.NumberRange._value.Min);

                return;
            end;

            if (_value or _value2) and Text ~= "" then
                local v38 = tonumber(Text);

                if not v38 or _value2 and string.find(Text, "%D") then
                    table_clone_ret._input.Text = table_clone_ret.Value._value;

                    return;
                end;

                Text = math.clamp(v38, table_clone_ret.NumberRange._value.Min, table_clone_ret.NumberRange._value.Max);

                if v38 == Text then
                    Text = table_clone_ret._input.Text;
                end;

                table_clone_ret._input.Text = Text;
                local v39 = #tostring(Text);

                if v39 < table_clone_ret._input.CursorPosition - 1 then
                    table_clone_ret._input.CursorPosition = v39 + 1;
                end;
            end;

            if table_clone_ret.Hotkey and table_clone_ret.Hotkey._value then
                local StringForKeyCode = Parent.UserInputService:GetStringForKeyCode(table_clone_ret.Hotkey._value);

                if StringForKeyCode ~= string.sub(Text, -1) then
                    Text = Text .. StringForKeyCode;
                end;
            end;

            if table_clone_ret.MaxChars._value ~= (1 / 0) then
                Text = string.sub(Text, 1, table_clone_ret.MaxChars._value);
                table_clone_ret._input.CursorPosition = math.min(table_clone_ret.MaxChars._value + 1, table_clone_ret._input.CursorPosition);
                table_clone_ret._input.Text = Text;
            end;

            if not table_clone_ret.Validate or table_clone_ret.Validate._value(Text) then
                table_clone_ret.Value(Text);

                return;
            end;

            local _input = table_clone_ret._input;
            local v40;

            if table_clone_ret.MaxChars._value == (1 / 0) then
                v40 = table_clone_ret.Value._value;
            else
                v40 = string.sub(table_clone_ret.Value._value, 1, table_clone_ret.MaxChars._value);
            end;

            _input.Text = v40;
        end
    });
    table_clone_ret._input:AddTag("KeyClackSound");

    if table_clone_ret.HotkeyInput._value then
        table.insert(v29, table_clone_ret._input.Focused:Connect(function() -- Line: 231
            -- upvalues: table_clone_ret (copy)
            table_clone_ret.Value("");
        end));
        Parent.UserInputService.InputBegan:Connect(function(p41, p42) -- Line: 235
            -- upvalues: table_clone_ret (copy), u25 (ref), Parent (ref)
            if not table_clone_ret._input:IsFocused() then
                return;
            end;

            if p41.UserInputType == Enum.UserInputType.Keyboard then
                local v43 = {
                    Ctrl = p41:IsModifierKeyDown(Enum.ModifierKey.Ctrl),
                    Shift = p41:IsModifierKeyDown(Enum.ModifierKey.Shift),
                    Alt = p41:IsModifierKeyDown(Enum.ModifierKey.Alt),
                    Meta = p41:IsModifierKeyDown(Enum.ModifierKey.Meta)
                };
                local v44 = `{v43.Ctrl and "Ctrl+" or ""}{v43.Shift and "Shift+" or ""}{v43.Alt and "Alt+" or ""}{v43.Meta and "Meta+" or ""}`;

                if table.find(u25, p41.KeyCode) then
                    table_clone_ret.Value(v44);

                    return;
                end;

                table_clone_ret.Hotkey(p41.KeyCode);
                table_clone_ret.Modifiers(v43);
                table_clone_ret.Value(v44 .. Parent.UserInputService:GetStringForKeyCode(p41.KeyCode), true);
                table_clone_ret._input:ReleaseFocus(true);
            end;
        end);
    end;

    local u45 = Parent.new("Frame")({
        Name = "Selection",
        BackgroundTransparency = 0.75,
        BorderSizePixel = 0,
        Visible = false,
        AnchorPoint = Vector2.new(0, 0.5),
        Size = UDim2.new(0, 0, 0, table_clone_ret.FontSize),
        Position = UDim2.new(0, 0, 0.5, 0),
        BackgroundColor3 = Parent.Theme.Secondary
    });
    local u46 = Parent.new("TextLabel")({
        Name = "Cursor",
        AutoLocalize = false,
        BackgroundTransparency = 1,
        RichText = true,
        Visible = false,
        AutomaticSize = Enum.AutomaticSize.X,
        Size = UDim2.new(0, 0, 1, 0),
        Position = UDim2.new(0, 0, 0, 0),
        TextSize = table_clone_ret.FontSize,
        TextColor3 = Parent.Theme.PrimaryText,
        TextStrokeColor3 = Parent.Theme.Primary,
        TextStrokeTransparency = Parent.Theme.TextStrokeTransparency,
        FontFace = table_clone_ret.FontFace,
        TextXAlignment = Enum.TextXAlignment.Left,
        Text = table_clone_ret.Cursor
    });
    local u47 = 0;
    task.defer(function() -- Line: 290
        -- upvalues: u46 (copy), u47 (ref)
        while u46 and u46.Parent do
            if u46.Visible and tick() - u47 > 0.25 then
                u46.TextTransparency = u46.TextTransparency == 1 and 0 or 1;
            end;

            task.wait(0.5);
        end;
    end);

    local function v48() -- Line: 299
        -- upvalues: table_clone_ret (copy)
        if table_clone_ret.Fill() then
            return Enum.AutomaticSize.None;
        end;

        return Enum.AutomaticSize.X;
    end;

    local u49 = Parent.new("Frame")({
        Name = "InputMask",
        AutomaticSize = v48,
        ClipsDescendants = true,
        BackgroundTransparency = 1,
        Position = UDim2.new(0, 0, 0, 0),
        Size = UDim2.new(1, 0, 1, 0),
        table_clone_ret._input,
        u45
    });
    table_clone_ret._inputOffset = Parent.state(0);
    table_clone_ret._maskSize = Parent.state(u49, "AbsoluteSize");
    table_clone_ret._bounds = Parent.state(table_clone_ret._input, "TextBounds");
    local u50 = false;
    table_clone_ret._input:GetPropertyChangedSignal("Text"):Connect(function() -- Line: 320
        -- upvalues: u50 (ref), table_clone_ret (copy), u30 (copy)
        if u50 then
            return;
        end;

        u50 = true;
        local Text = table_clone_ret._input.Text;

        if table_clone_ret.MaxChars._value ~= (1 / 0) then
            Text = string.sub(Text, 1, table_clone_ret.MaxChars._value);
        end;

        table_clone_ret._input.Text = Text;
        u30(Text, true);
        u50 = false;
    end);
    Parent.edit(table_clone_ret._input, {
        Position = function() -- Line: 335, Name: Position
            -- upvalues: table_clone_ret (copy)
            local v51 = table_clone_ret._bounds().X <= table_clone_ret._maskSize().X and 0 or -table_clone_ret._inputOffset();

            return UDim2.fromOffset(v51, 0);
        end
    });
    local v52 = Parent.new("ImageLabel")({
        LayoutOrder = 1,
        BackgroundTransparency = 1,
        Size = UDim2.new(1, 0, 1, 0),
        SizeConstraint = Enum.SizeConstraint.RelativeYY,
        Image = table_clone_ret.Icon,
        ImageColor3 = Parent.Theme.Secondary,

        Visible = function() -- Line: 348, Name: Visible
            -- upvalues: table_clone_ret (copy)
            return table_clone_ret.Icon() ~= "";
        end
    });

    if p28 and p28.IconProperties then
        Parent.edit(v52, p28.IconProperties);
    end;

    table_clone_ret._instance = Parent.new("Frame")({
        Name = "Input",
        AutomaticSize = v48,
        ClipsDescendants = true,
        BackgroundColor3 = Parent.Theme.Secondary,
        BackgroundTransparency = Parent.Theme.TransparencyHeavy,

        Size = function() -- Line: 362, Name: Size
            -- upvalues: table_clone_ret (copy)
            return UDim2.new(1, 0, 0, table_clone_ret.FontSize() + table_clone_ret.Padding().Offset * 2);
        end,

        Parent.new("UICorner")({
            CornerRadius = Parent.Theme.CornerPadded
        }),
        Parent.new("Stroke")({}),
        Parent.new("UIPadding")({
            PaddingLeft = table_clone_ret.Padding,
            PaddingRight = table_clone_ret.Padding
        }),
        Parent.new("UIListLayout")({
            VerticalAlignment = Enum.VerticalAlignment.Center,
            FillDirection = Enum.FillDirection.Horizontal,
            SortOrder = Enum.SortOrder.LayoutOrder,
            Padding = table_clone_ret.Padding
        }),
        v52,
        Parent.new("Frame")({
            LayoutOrder = 2,
            AutomaticSize = Enum.AutomaticSize.X,
            Name = "InputFrame",
            BackgroundTransparency = 1,
            Size = UDim2.new(0, 0, 1, 0),
            u46,
            u49,
            Parent.new("UIFlexItem")({
                FlexMode = Enum.UIFlexMode.Fill
            })
        }),
        Parent.new("ImageButton")({
            LayoutOrder = 3,
            BackgroundTransparency = 1,
            Size = UDim2.fromScale(0.5, 0.5),
            SizeConstraint = Enum.SizeConstraint.RelativeYY,
            Image = Parent.Theme.Image.Close,
            ImageColor3 = Parent.Theme.Secondary,

            Visible = function() -- Line: 404, Name: Visible
                -- upvalues: table_clone_ret (copy), u30 (copy)
                local v53 = table_clone_ret.ClearTextButton() and u30() ~= "";

                return v53;
            end,

            Activated = function() -- Line: 408, Name: Activated
                -- upvalues: table_clone_ret (copy), u30 (copy)
                table_clone_ret._input.Text = "";
                table_clone_ret.DisplayText("", true);
                table_clone_ret.Value("", true);
                u30("", true);
            end
        }),
        [Parent.Clean] = v29
    });
    local PropertyChangedSignal = table_clone_ret._input:GetPropertyChangedSignal("SelectionStart");
    table.insert(v29, PropertyChangedSignal:Connect(function() -- Line: 421
        -- upvalues: table_clone_ret (copy), u45 (copy), updateSelection (ref), u37 (copy)
        if table_clone_ret._input.SelectionStart == -1 then
            u45.Visible = false;

            return;
        end;

        updateSelection(u45, u37, table_clone_ret._input, table_clone_ret._inputOffset);
    end));
    local PropertyChangedSignal2 = table_clone_ret._input:GetPropertyChangedSignal("CursorPosition");
    table.insert(v29, PropertyChangedSignal2:Connect(function() -- Line: 432
        -- upvalues: u47 (ref), u46 (copy), table_clone_ret (copy), updateCursor (ref), u37 (copy), u49 (copy), u45 (copy)
        u47 = tick();
        u46.TextTransparency = 0;

        if table_clone_ret._input.CursorPosition == -1 then
            u46.Visible = false;

            return;
        end;

        task.defer(updateCursor, u46, u37, table_clone_ret._input, u49, table_clone_ret._inputOffset, u45);
    end));

    return setmetatable(table_clone_ret, u27);
end;

return u27;