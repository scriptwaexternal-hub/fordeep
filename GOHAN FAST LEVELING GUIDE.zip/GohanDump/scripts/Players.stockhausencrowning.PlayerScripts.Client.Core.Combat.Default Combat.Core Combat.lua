-- Decompiled with Potassium's decompiler.

local ReplicatedStorage = game:GetService("ReplicatedStorage");
local UserInputService = game:GetService("UserInputService");
local Players = game:GetService("Players");
local RunService = game:GetService("RunService");
local Modules = ReplicatedStorage:WaitForChild("Modules");
local Metadata = Modules.Metadata;
local Shared = Modules.Shared;
local Utility = Modules.Utility;
local HitboxHandler = require(Utility.HitboxHandler);
local FindCharacters = require(Shared.FindCharacters);
local ControlData = require(Metadata.ControlData.ControlData);
local CombatPresets = require(Metadata.CombatData.CombatPresets);
local script_DashModule = require(script.DashModule);
require(Modules.GlobalFunctions);
local AnimationManager = require(Shared.AnimationManager);
local UtilityHandler = require(Utility.UtilityHandler);
local CombatClassSpeed = require(Metadata.CombatClassData.CombatClassSpeed);
local StateManager = require(ReplicatedStorage.Modules.Metadata.ControlData.StateManager);
local Platform = require(Shared.Platform);
local SoundManager = require(Shared.SoundManager);
local v1 = script:FindFirstAncestor("Core");
local CombatVFX = require(v1:FindFirstChild("CombatVFX", true));
local ServerRemote = ReplicatedStorage.Remotes.ServerRemote;
local StatRetrieveRemote = ReplicatedStorage.Remotes.StatRetrieveRemote;
local StatChangeRemote = ReplicatedStorage.Remotes.StatChangeRemote;
local LocalPlayer = Players.LocalPlayer;
local PlayerStats = LocalPlayer:WaitForChild("PlayerStats");
local SpeedMultiplier = PlayerStats:FindFirstChild("SpeedMultiplier", true);
local Hitbox = PlayerStats:FindFirstChild("Hitbox", true);
local Boosters = PlayerStats:FindFirstChild("Boosters", true);
local TempStats = PlayerStats:FindFirstChild("TempStats", true);
local AgilityBoost = Boosters:FindFirstChild("AgilityBoost");
local TempAgility = TempStats:FindFirstChild("TempAgility");
local u2 = StatRetrieveRemote:InvokeServer("CombatType");
local u3 = StatRetrieveRemote:InvokeServer("Agility", "Core") or 1;
local u4 = StatRetrieveRemote:InvokeServer("Arm");
local u5 = false;
local u6 = StatRetrieveRemote:InvokeServer("KiUnlocked") or false;
local u7 = StatRetrieveRemote:InvokeServer("GravityMastery") or 1;
local CurrentGravity = PlayerStats:FindFirstChild("CurrentGravity", true);

local function ragingSoul() -- Line: 109
    -- upvalues: LocalPlayer (copy)
    local Character = LocalPlayer.Character;
    local v8;

    if Character == nil then
        v8 = false;
    else
        v8 = Character:GetAttribute("RagingSoul") == true;
    end;

    return v8, Character;
end;

local function maxCombo() -- Line: 113
    -- upvalues: LocalPlayer (copy)
    local Character = LocalPlayer.Character;
    local v9;

    if Character == nil then
        v9 = false;
    else
        v9 = Character:GetAttribute("RagingSoul") == true;
    end;

    local v10;

    if v9 then
        v10 = tonumber(Character:GetAttribute("RagingSoulCombo"));

        if not v10 then
            return 5;
        end;
    else
        v10 = 5;
    end;

    return v10;
end;

local u11 = UtilityHandler:DeepCopy(CombatPresets);
local u12 = UtilityHandler:DeepCopy(ControlData.Controls.Dash);
local u13 = UtilityHandler:DeepCopy(ControlData.Controls.Run);
local u14 = UtilityHandler:DeepCopy(ControlData.Controls.Grip_Carry);
local u15 = UtilityHandler:DeepCopy(ControlData.Controls.Loot);
local u16 = UtilityHandler:DeepCopy(ControlData.Controls.Charge);
local u17 = UtilityHandler:DeepCopy(ControlData.Controls.KiSense);
local u18 = UtilityHandler:DeepCopy(ControlData.Controls.KiBlast);
local u19 = {
    light = true,
    heavy = true
};
local u20 = 0;
local u21 = 0;
local u22 = 0;
local u23 = 0;
local u24 = false;
local u25 = false;
local u26 = {};

local function restoreCharacterSpeed(p27) -- Line: 219
    -- upvalues: SpeedMultiplier (copy)
    if p27 then
        p27 = p27:FindFirstChildOfClass("Humanoid");
    end;

    if not p27 then
        return;
    end;

    p27.WalkSpeed = game.StarterPlayer.CharacterWalkSpeed * (SpeedMultiplier and SpeedMultiplier.Value or 1);
    p27.JumpPower = game.StarterPlayer.CharacterJumpPower;
end;

local u28 = false;
task.spawn(function() -- Line: 237
    -- upvalues: u11 (ref), u19 (copy), LocalPlayer (copy)
    local function hook(p29) -- Line: 238
        -- upvalues: u11 (ref), u19 (ref)
        p29:GetAttributeChangedSignal("ComboResetTick"):Connect(function() -- Line: 239
            -- upvalues: u11 (ref), u19 (ref)
            u11.Combo = 0;
            u11.Combo2 = 0;
            u11.Enabled = true;
            u19.light = true;
            u19.heavy = true;
        end);
    end;

    if LocalPlayer.Character then
        LocalPlayer.Character:GetAttributeChangedSignal("ComboResetTick"):Connect(function() -- Line: 239
            -- upvalues: u11 (ref), u19 (ref)
            u11.Combo = 0;
            u11.Combo2 = 0;
            u11.Enabled = true;
            u19.light = true;
            u19.heavy = true;
        end);
    end;

    LocalPlayer.CharacterAdded:Connect(hook);
end);

local function terminateRun() -- Line: 257
    -- upvalues: u28 (ref), ServerRemote (copy)
    u28 = false;
    ServerRemote:FireServer("Run", {
        Action = "Terminate"
    });
end;

local function buildHitbox(p30, p31) -- Line: 267
    -- upvalues: Hitbox (copy), u25 (ref)
    local v32 = p31 or 1;
    local HumanoidRootPart = p30:FindFirstChild("HumanoidRootPart");

    return HumanoidRootPart and {
        Size = Vector3.new(6, 7, 6) * Hitbox.Value * v32,
        Location = u25 and HumanoidRootPart.CFrame * CFrame.new(0, -5, -3.5 * v32) or HumanoidRootPart.CFrame * CFrame.new(0, 0, -3.5 * Hitbox.Value * v32)
    } or nil;
end;

local function findVictims(p33, p34) -- Line: 283
    -- upvalues: buildHitbox (copy), HitboxHandler (copy), FindCharacters (copy), UtilityHandler (copy)
    local v35 = buildHitbox(p33, p34);

    if not v35 then
        return {}, 0, nil;
    end;

    local _, v36 = HitboxHandler.New(v35);
    local v37 = FindCharacters.Find(p33, v36);

    return v37, UtilityHandler:Length(v37), v35;
end;

local function findVictimsWindowed(p38, p39, p40) -- Line: 302
    -- upvalues: findVictims (copy), RunService (copy)
    local v41 = {};
    local v42 = nil;
    local v43 = {};
    local v44 = 0;

    for i = 1, 3 do
        local v45, _, v46 = findVictims(p38, p39);
        v42 = v42 or v46;

        for _, v in pairs(v45) do
            if not v43[v] then
                v43[v] = true;
                v44 = v44 + 1;
                local Name = v.Name;

                if v41[Name] ~= nil then
                    Name = Name .. "#" .. v44;
                end;

                v41[Name] = v;

                if p40 then
                    p40(v);
                end;
            end;
        end;

        if i < 3 then
            RunService.Heartbeat:Wait();
        end;
    end;

    return v41, v44, v42;
end;

local function safePlayAnimation(p47, p48, p49) -- Line: 329
    -- upvalues: AnimationManager (copy)
    local v50 = AnimationManager.PlayAnimation(p47, p48, p49);

    if not v50 then
        warn("CoreCombat: animation not found:", p48, "(character:", p47.Name .. ")");
    end;

    return v50;
end;

local function disableJump(u51, p52) -- Line: 337
    -- upvalues: u26 (ref)
    if not (u51 and u51.Parent) then
        return;
    end;

    if u51:GetStateEnabled(Enum.HumanoidStateType.Jumping) then
        u51:SetStateEnabled(Enum.HumanoidStateType.Jumping, false);
    end;

    local os_clock_ret = os.clock();
    u26[u51] = os_clock_ret;
    task.delay(p52, function() -- Line: 344
        -- upvalues: u26 (ref), u51 (copy), os_clock_ret (copy)
        if u26[u51] == os_clock_ret then
            u51:SetStateEnabled(Enum.HumanoidStateType.Jumping, true);
            u26[u51] = nil;
        end;
    end);
end;

local function detectJump(p53) -- Line: 352
    -- upvalues: disableJump (copy), u25 (ref)
    local Humanoid = p53:WaitForChild("Humanoid");
    Humanoid.Jumping:Connect(function(p54) -- Line: 354
        -- upvalues: disableJump (ref), Humanoid (copy), u25 (ref)
        if p54 then
            disableJump(Humanoid, 1.5);
            u25 = true;
            task.delay(0.5, function() -- Line: 358
                -- upvalues: u25 (ref)
                u25 = false;
            end);
        end;
    end);
end;

local function checkMouseButtons() -- Line: 363
    -- upvalues: UserInputService (copy)
    local v55 = false;
    local v56 = false;

    for _, v in pairs(UserInputService:GetMouseButtonsPressed()) do
        v55 = v.UserInputType == Enum.UserInputType.MouseButton1 and true or v55;

        if v.UserInputType == Enum.UserInputType.MouseButton2 then
            v56 = true;
        end;
    end;

    return v55, v56;
end;

local function resetAllDebounces() -- Line: 377
    -- upvalues: u19 (copy), u11 (ref), u21 (ref), u22 (ref), u24 (ref)
    for i in pairs(u19) do
        u19[i] = true;
    end;

    u11.Enabled = true;
    u21 = 0;
    u22 = 0;
    u24 = false;
end;

local function resetControlsOnRespawn() -- Line: 391
    -- upvalues: u11 (ref), UtilityHandler (copy), CombatPresets (copy), u12 (ref), ControlData (copy), u13 (ref), u14 (ref), u15 (ref), u16 (ref), u17 (ref), u18 (ref), u19 (copy), u21 (ref), u22 (ref), u24 (ref), u25 (ref), u26 (ref)
    u11 = UtilityHandler:DeepCopy(CombatPresets);
    u12 = UtilityHandler:DeepCopy(ControlData.Controls.Dash);
    u13 = UtilityHandler:DeepCopy(ControlData.Controls.Run);
    u14 = UtilityHandler:DeepCopy(ControlData.Controls.Grip_Carry);
    u15 = UtilityHandler:DeepCopy(ControlData.Controls.Loot);
    u16 = UtilityHandler:DeepCopy(ControlData.Controls.Charge);
    u17 = UtilityHandler:DeepCopy(ControlData.Controls.KiSense);
    u18 = UtilityHandler:DeepCopy(ControlData.Controls.KiBlast);

    for i in pairs(u19) do
        u19[i] = true;
    end;

    u11.Enabled = true;
    u21 = 0;
    u22 = 0;
    u24 = false;
    u25 = false;
    u26 = {};
end;

local function calculateAnimationSpeed(p57) -- Line: 409
    -- upvalues: u3 (ref), AgilityBoost (copy), TempAgility (copy), SpeedMultiplier (copy), CurrentGravity (copy), u7 (ref)
    local v58 = (u3.BaseAgility + u3.EnhancedAgility + (AgilityBoost.Value + TempAgility.Value) / 1.5) * SpeedMultiplier.Value;
    local math_max_ret = math.max(v58, 0);
    local v59 = (not CurrentGravity or CurrentGravity.Value <= 0) and 1 or math.clamp(u7 / CurrentGravity.Value, 0.75, 1);

    return math.clamp(p57 * v59 * (math_max_ret / (math_max_ret + 400) * 0.12 + 1), 0.5, 2.5), v58;
end;

local function calculatePunchWait(p60) -- Line: 432
    -- upvalues: CombatClassSpeed (copy), u2 (ref), u11 (ref)
    local math_clamp_ret = math.clamp(p60 / 300, 0, 0.05);

    return math.clamp((CombatClassSpeed[u2] and CombatClassSpeed[u2]["Punch Wait"] or u11.Punch_Wait) - math_clamp_ret, 0.1, 2);
end;

local function resetCombo(u61, p62, p63) -- Line: 456
    -- upvalues: u11 (ref), LocalPlayer (copy), u19 (copy)
    local v64 = u11.Combo2 > 0;

    if u11.Combo >= u11.MaxCombo or v64 then
        local v65;

        if v64 then
            if u11.Combo == 3 and p63 then
                v65 = 0.5;
            else
                local Combo = u11.Combo;
                local Character = LocalPlayer.Character;
                local v66;

                if Character == nil then
                    v66 = false;
                else
                    v66 = Character:GetAttribute("RagingSoul") == true;
                end;

                if Combo == (v66 and (tonumber(Character:GetAttribute("RagingSoulCombo")) or 5) or 5) - 1 and p63 then
                    local Character2 = LocalPlayer.Character;
                    local v67;

                    if Character2 == nil then
                        v67 = false;
                    else
                        v67 = Character2:GetAttribute("RagingSoul") == true;
                    end;

                    v65 = v67 and (tonumber(Character2:GetAttribute("RagingSoulCooldown")) or u11.Cooldown) or u11.Cooldown2 / 2;
                else
                    v65 = u11.Cooldown2;
                end;
            end;
        else
            v65 = u11.Cooldown;
        end;

        u11.Enabled = false;
        u19.light = false;

        if v64 then
            u19.heavy = false;
            task.delay(v65, function() -- Line: 491
                -- upvalues: u19 (ref)
                u19.heavy = true;
            end);
        end;

        task.wait(v65);
        u11.Combo = 0;
        u11.Combo2 = 0;
        u11.Enabled = true;
        u19.light = true;
    else
        task.wait(p62);
        u19.light = true;
    end;

    task.spawn(function() -- Line: 509
        -- upvalues: u61 (copy), u11 (ref)
        local v68 = u61;
        local v69 = tick() + u11.TimeToAttack;

        while tick() < v69 do
            if u11.Combo ~= v68 or u11.Combo == 0 then
                return;
            end;

            task.wait();
        end;

        u11.Combo = 0;
    end);
end;

local v167 = {
    Run = {
        Execute = function(p70, p71) -- Line: 532
            -- upvalues: u13 (ref), ControlData (copy), u28 (ref), ServerRemote (copy)
            if not u13.Can_Run then
                return;
            end;

            if ControlData.Controls.Run.ToggleMode then
                u28 = true;
                ServerRemote:FireServer(p70, {
                    Action = "Execute"
                });

                return;
            end;

            if u13.Enabled then
                u28 = true;
                ServerRemote:FireServer(p70, {
                    Action = "Execute"
                });

                return;
            end;

            u13.Enabled = true;
            task.delay(u13.Tap_Time, function() -- Line: 545
                -- upvalues: u13 (ref)
                u13.Enabled = false;
            end);
        end,

        Terminate = function(p72, p73) -- Line: 553
            -- upvalues: u28 (ref), ServerRemote (copy)
            u28 = false;
            ServerRemote:FireServer(p72, {
                Action = "Terminate"
            });
        end
    },
    Charge = {
        Execute = function(p74, p75) -- Line: 562
            -- upvalues: LocalPlayer (copy), u6 (ref), u16 (ref), StateManager (copy), u28 (ref), ServerRemote (copy)
            local v76 = LocalPlayer.Character or LocalPlayer.CharacterAdded:Wait();

            if not (u6 and u16.Enabled) then
                return;
            end;

            if not StateManager.CanPerformAction(v76, "Charge") then
                return;
            end;

            u28 = false;
            ServerRemote:FireServer("Run", {
                Action = "Terminate"
            });
            ServerRemote:FireServer(p74, {
                Action = "Execute",
                SecondAction = "Charge"
            });
            u16.Enabled = false;
            task.delay(u16.Charge_CD, function() -- Line: 570
                -- upvalues: u16 (ref)
                u16.Enabled = true;
            end);
        end,

        Terminate = function(p77, p78) -- Line: 574
            -- upvalues: ServerRemote (copy)
            ServerRemote:FireServer(p77, {
                Action = "Terminate",
                SecondAction = "Charge"
            });
        end
    },
    DeCharge = {
        Execute = function(p79, p80) -- Line: 580
            -- upvalues: LocalPlayer (copy), u6 (ref), u16 (ref), StateManager (copy), u28 (ref), ServerRemote (copy)
            local v81 = LocalPlayer.Character or LocalPlayer.CharacterAdded:Wait();

            if not (u6 and u16.Enabled) then
                return;
            end;

            if not StateManager.CanPerformAction(v81, "DeCharge") then
                return;
            end;

            u28 = false;
            ServerRemote:FireServer("Run", {
                Action = "Terminate"
            });
            ServerRemote:FireServer("Charge", {
                Action = "Execute",
                SecondAction = "DeCharge"
            });
            u16.Enabled = false;
            task.delay(u16.Charge_CD, function() -- Line: 588
                -- upvalues: u16 (ref)
                u16.Enabled = true;
            end);
        end,

        Terminate = function(p82, p83) -- Line: 592
            -- upvalues: ServerRemote (copy)
            ServerRemote:FireServer("Charge", {
                Action = "Terminate",
                SecondAction = "DeCharge"
            });
        end
    },

    Transform = function(p84, p85) -- Line: 597
        -- upvalues: LocalPlayer (copy), u6 (ref), u16 (ref), StateManager (copy), u28 (ref), ServerRemote (copy)
        local v86 = LocalPlayer.Character or LocalPlayer.CharacterAdded:Wait();

        if not (u6 and u16.Enabled) then
            return;
        end;

        if not StateManager.CanPerformAction(v86, "Transform") then
            return;
        end;

        u28 = false;
        ServerRemote:FireServer("Run", {
            Action = "Terminate"
        });
        ServerRemote:FireServer("Charge", {
            Action = "Execute",
            SecondAction = "Charge",
            ThirdAction = "Transform"
        });
        u16.Enabled = false;
        task.delay(u16.Charge_CD, function() -- Line: 609
            -- upvalues: u16 (ref)
            u16.Enabled = true;
        end);
    end,

    DeTransform = function(p87, p88) -- Line: 614
        -- upvalues: u6 (ref), ServerRemote (copy)
        if not u6 then
            return;
        end;

        ServerRemote:FireServer("Charge", {
            Action = "Execute",
            SecondAction = "DeTransform"
        });
    end,

    Light = function(u89, p90) -- Line: 626
        -- upvalues: LocalPlayer (copy), StateManager (copy), u11 (ref), u19 (copy), u21 (ref), u20 (ref), u28 (ref), ServerRemote (copy), calculateAnimationSpeed (copy), CombatClassSpeed (copy), u2 (ref), UserInputService (copy), Platform (copy), AnimationManager (copy), u25 (ref), findVictimsWindowed (copy), CombatVFX (copy), resetCombo (copy), disableJump (copy)
        local u91 = LocalPlayer.Character or LocalPlayer.CharacterAdded:Wait();

        if not StateManager.CanPerformAction(u91, "Light") then
            return;
        end;

        if not u11.Enabled then
            return;
        end;

        if not u19.light then
            return;
        end;

        if u21 ~= 0 then
            return;
        end;

        u19.light = false;
        u20 = u20 + 1;
        local u92 = u20;
        u21 = u92;
        local v93 = u91:FindFirstChildOfClass("Humanoid");
        local Character = LocalPlayer.Character;
        local v94;

        if Character == nil then
            v94 = false;
        else
            v94 = Character:GetAttribute("RagingSoul") == true;
        end;

        local u95 = v94 and (tonumber(Character:GetAttribute("RagingSoulCombo")) or 5) or 5;
        u11.MaxCombo = u95;
        u11.Combo = math.min(u11.Combo + 1, u95);
        u28 = false;
        ServerRemote:FireServer("Run", {
            Action = "Terminate"
        });
        local v96, v97 = calculateAnimationSpeed(CombatClassSpeed[u2] and CombatClassSpeed[u2].Speed or 1.3);
        local math_clamp_ret = math.clamp(v97 / 300, 0, 0.05);
        local math_clamp_ret2 = math.clamp((CombatClassSpeed[u2] and CombatClassSpeed[u2]["Punch Wait"] or u11.Punch_Wait) - math_clamp_ret, 0.1, 2);
        local Character2 = LocalPlayer.Character;
        local v98;

        if Character2 == nil then
            v98 = false;
        else
            v98 = Character2:GetAttribute("RagingSoul") == true;
        end;

        if v98 then
            v98 = tonumber(Character2:GetAttribute("RagingSoulSpeed"));
        end;

        if v98 and v98 > 0 then
            math_clamp_ret2 = math.max(math_clamp_ret2 * (v96 / v98), 0.05);
        else
            v98 = v96;
        end;

        local u99;

        if u11.Combo == u95 then
            u99 = not StateManager.IsInState(u91, "InAir") and (UserInputService:IsKeyDown(Enum.KeyCode.Space) or Platform.IsButtonDown(Enum.KeyCode.ButtonA));
        else
            u99 = false;
        end;

        local v100;

        if u11.Combo == u95 and StateManager.IsInState(u91, "InAir") then
            v100 = "SmackDown";
        elseif u99 then
            v100 = AnimationManager.CachedAnimation[u2 .. " Uptilt"] and u2 .. " Uptilt" or "Default Uptilt";
        else
            v100 = u11.Combo == u95 and u25 and "GroundSpike" or u2 .. " Atk " .. (u11.Combo - 1) % 5 + 1;
        end;

        local u101 = AnimationManager.PlayAnimation(u91, v100, {
            AdjustSpeed = v98
        });

        if not u101 then
            warn("CoreCombat: animation not found:", v100, "(character:", u91.Name .. ")");
        end;

        if not u101 then
            u21 = 0;
            u19.light = true;
            u11.Combo = math.max(u11.Combo - 1, 0);

            return;
        end;

        local function onHit(u102) -- Line: 728
            -- upvalues: u11 (ref), u25 (ref), findVictimsWindowed (ref), u91 (copy), CombatVFX (ref), u95 (copy), u101 (copy), ServerRemote (ref), u89 (copy)
            local Combo = u11.Combo;
            local u103 = u25;
            task.spawn(function() -- Line: 743
                -- upvalues: findVictimsWindowed (ref), u91 (ref), CombatVFX (ref), Combo (copy), u95 (ref), u101 (ref), ServerRemote (ref), u89 (ref), u103 (copy), u11 (ref), u102 (copy)
                local v105, v106, v107 = findVictimsWindowed(u91, nil, function(p104) -- Line: 745
                    -- upvalues: CombatVFX (ref), u91 (ref)
                    CombatVFX.Light({
                        Character = u91,
                        Victim = p104
                    });
                end);

                if v106 == 0 and Combo == u95 then
                    u101:AdjustSpeed(0.4);
                end;

                ServerRemote:FireServer(u89, {
                    Combo = Combo,
                    Jumped = u103,
                    Victims = v105,
                    VictimCount = v106,
                    MaxCombo = u11.MaxCombo,
                    Uptilt = u102 or false,
                    RegionHitbox = v107 and {
                        Location = v107.Location,
                        Size = v107.Size
                    }
                });
            end);
        end;

        ServerRemote:FireServer("Swing", {
            SwingType = "LightSwing"
        });
        local u115 = u101:GetMarkerReachedSignal("Punch"):Once(function(p108) -- Line: 769
            -- upvalues: u21 (ref), u92 (copy), u99 (copy), u11 (ref), u25 (ref), findVictimsWindowed (ref), u91 (copy), CombatVFX (ref), u95 (copy), u101 (copy), ServerRemote (ref), u89 (copy), resetCombo (ref), math_clamp_ret2 (ref)
            if u21 == u92 then
                u21 = 0;
            end;

            local u109 = p108 == "UpTilt" and true or u99;
            local Combo = u11.Combo;
            local u110 = u25;
            task.spawn(function() -- Line: 743
                -- upvalues: findVictimsWindowed (ref), u91 (ref), CombatVFX (ref), Combo (copy), u95 (ref), u101 (ref), ServerRemote (ref), u89 (ref), u110 (copy), u11 (ref), u109 (copy)
                local v112, v113, v114 = findVictimsWindowed(u91, nil, function(p111) -- Line: 745
                    -- upvalues: CombatVFX (ref), u91 (ref)
                    CombatVFX.Light({
                        Character = u91,
                        Victim = p111
                    });
                end);

                if v113 == 0 and Combo == u95 then
                    u101:AdjustSpeed(0.4);
                end;

                ServerRemote:FireServer(u89, {
                    Combo = Combo,
                    Jumped = u110,
                    Victims = v112,
                    VictimCount = v113,
                    MaxCombo = u11.MaxCombo,
                    Uptilt = u109 or false,
                    RegionHitbox = v114 and {
                        Location = v114.Location,
                        Size = v114.Size
                    }
                });
            end);
            resetCombo(u11.Combo, math_clamp_ret2, false);
        end);
        local u122 = u101:GetMarkerReachedSignal("Second Punch"):Once(function() -- Line: 777
            -- upvalues: u11 (ref), u25 (ref), findVictimsWindowed (ref), u91 (copy), CombatVFX (ref), u95 (copy), u101 (copy), ServerRemote (ref), u89 (copy)
            local Combo = u11.Combo;
            local u116 = u25;
            local u117 = false;
            task.spawn(function() -- Line: 743
                -- upvalues: findVictimsWindowed (ref), u91 (ref), CombatVFX (ref), Combo (copy), u95 (ref), u101 (ref), ServerRemote (ref), u89 (ref), u116 (copy), u11 (ref), u117 (copy)
                local v119, v120, v121 = findVictimsWindowed(u91, nil, function(p118) -- Line: 745
                    -- upvalues: CombatVFX (ref), u91 (ref)
                    CombatVFX.Light({
                        Character = u91,
                        Victim = p118
                    });
                end);

                if v120 == 0 and Combo == u95 then
                    u101:AdjustSpeed(0.4);
                end;

                ServerRemote:FireServer(u89, {
                    Combo = Combo,
                    Jumped = u116,
                    Victims = v119,
                    VictimCount = v120,
                    MaxCombo = u11.MaxCombo,
                    Uptilt = u117 or false,
                    RegionHitbox = v121 and {
                        Location = v121.Location,
                        Size = v121.Size
                    }
                });
            end);
        end);
        u101.Stopped:Once(function() -- Line: 789
            -- upvalues: u115 (ref), u122 (ref), u21 (ref), u92 (copy), u20 (ref), u19 (ref), u11 (ref)
            local Connected = u115.Connected;

            if u115.Connected then
                u115:Disconnect();
            end;

            if u122.Connected then
                u122:Disconnect();
            end;

            if u21 == u92 then
                u21 = 0;
            end;

            if Connected and u20 == u92 then
                u19.light = true;
                u11.Enabled = true;
            end;
        end);
        disableJump(v93, 0.75);
    end,

    Heavy = function(u123, p124) -- Line: 824
        -- upvalues: LocalPlayer (copy), StateManager (copy), u11 (ref), u19 (copy), u21 (ref), u28 (ref), ServerRemote (copy), u20 (ref), calculateAnimationSpeed (copy), CombatClassSpeed (copy), u2 (ref), AnimationManager (copy), findVictimsWindowed (copy), CombatVFX (copy), resetCombo (copy), disableJump (copy)
        local u125 = LocalPlayer.Character or LocalPlayer.CharacterAdded:Wait();

        if not StateManager.CanPerformAction(u125, "Heavy") then
            return;
        end;

        if not u11.Enabled then
            return;
        end;

        if not u19.heavy then
            return;
        end;

        if u125:GetAttribute("HeavyShiftlock") == true and LocalPlayer:GetAttribute("ShiftlockEnabled") ~= true then
            return;
        end;

        if u21 ~= 0 then
            return;
        end;

        u19.heavy = false;
        local v126 = u125:FindFirstChildOfClass("Humanoid");
        local u127 = false;
        u28 = false;
        ServerRemote:FireServer("Run", {
            Action = "Terminate"
        });
        u20 = u20 + 1;
        local u128 = u20;
        u21 = u128;
        local v129 = u11;
        v129.Combo2 = v129.Combo2 + 1;
        local v130, v131 = calculateAnimationSpeed(0.7);
        local math_clamp_ret = math.clamp(v131 / 300, 0, 0.05);
        local math_clamp_ret2 = math.clamp((CombatClassSpeed[u2] and CombatClassSpeed[u2]["Punch Wait"] or u11.Punch_Wait) - math_clamp_ret, 0.1, 2);
        local v132;

        if StateManager.IsInState(u125, "InAir") then
            v132 = "SmackDown";
        elseif u11.Combo == 3 then
            v132 = u2 .. " Uptilt";
        else
            v132 = u11.Combo == 4 and "Atk 5" or u2 .. " Heavy";
        end;

        local v133 = AnimationManager.PlayAnimation(u125, v132, {
            AdjustSpeed = v130
        });

        if not v133 then
            warn("CoreCombat: animation not found:", v132, "(character:", u125.Name .. ")");
        end;

        if not v133 then
            u21 = 0;
            u19.heavy = true;
            u11.Combo2 = math.max(u11.Combo2 - 1, 0);

            return;
        end;

        ServerRemote:FireServer("Swing", {
            SwingType = "HeavySwing"
        });
        local u142 = v133:GetMarkerReachedSignal("Punch"):Once(function() -- Line: 906
            -- upvalues: u21 (ref), u128 (copy), u11 (ref), findVictimsWindowed (ref), u125 (copy), CombatVFX (ref), u127 (ref), ServerRemote (ref), u123 (copy), resetCombo (ref), math_clamp_ret2 (copy)
            if u21 == u128 then
                u21 = 0;
            end;

            local Combo = u11.Combo;
            task.spawn(function() -- Line: 913
                -- upvalues: findVictimsWindowed (ref), u125 (ref), Combo (copy), CombatVFX (ref), u127 (ref), ServerRemote (ref), u123 (ref), resetCombo (ref), math_clamp_ret2 (ref)
                local u134 = nil;
                local u135 = nil;
                local u136 = nil;
                local success, result = pcall(function() -- Line: 921
                    -- upvalues: u134 (ref), u135 (ref), u136 (ref), findVictimsWindowed (ref), u125 (ref), Combo (ref), CombatVFX (ref), u127 (ref), ServerRemote (ref), u123 (ref)
                    local v138, v139, v140 = findVictimsWindowed(u125, Combo == 3 and 1.3 or nil, function(p137) -- Line: 924
                        -- upvalues: CombatVFX (ref), u125 (ref)
                        CombatVFX.Heavy({
                            Character = u125,
                            Victim = p137
                        });
                    end);
                    u134 = v138;
                    u135 = v139;
                    u136 = v140;

                    if u135 > 0 then
                        u127 = true;
                    end;

                    local v141 = {
                        Combo = Combo,
                        Victims = u134
                    };
                    v141.RegionHitbox = u136 and {
                        Location = u136.Location,
                        Size = u136.Size
                    };
                    ServerRemote:FireServer(u123, v141);
                end);

                if not success then
                    warn("CoreCombat Heavy: victim scan failed (attack still recovers):", result);
                end;

                resetCombo(Combo, math_clamp_ret2, u127);
            end);
        end);
        v133.Stopped:Once(function() -- Line: 945
            -- upvalues: u142 (ref), u21 (ref), u128 (copy), u20 (ref), u19 (ref), u11 (ref)
            local Connected = u142.Connected;

            if u142.Connected then
                u142:Disconnect();
            end;

            if u21 == u128 then
                u21 = 0;
            end;

            if Connected and u20 == u128 then
                u19.light = true;
                u19.heavy = true;
                u11.Enabled = true;
                u11.Combo2 = math.max(u11.Combo2 - 1, 0);
            end;
        end);
        disableJump(v126, 0.75);
        task.delay(4, function() -- Line: 969
            -- upvalues: u20 (ref), u128 (copy), u19 (ref), u21 (ref)
            if u20 == u128 and not u19.heavy then
                warn("CoreCombat Heavy: failsafe re-enabled M2 (restore chain leaked)");
                u19.heavy = true;

                if u21 == u128 then
                    u21 = 0;
                end;
            end;
        end);
    end,

    ["Ki Blast"] = function(u143, p144) -- Line: 1008
        -- upvalues: LocalPlayer (copy), StateManager (copy), u6 (ref), u18 (ref), u24 (ref), u23 (ref), u22 (ref), u28 (ref), ServerRemote (copy), u4 (ref), u5 (ref), AnimationManager (copy)
        local u145 = LocalPlayer.Character or LocalPlayer.CharacterAdded:Wait();

        if not StateManager.CanPerformAction(u145, "Ki Blast") then
            return;
        end;

        if u145:GetAttribute("RagingSoul") == true then
            return;
        end;

        local v146 = u145:FindFirstChildOfClass("Tool") and u145:FindFirstChild("Humanoid");

        if v146 then
            v146:UnequipTools();
        end;

        if not u6 then
            return;
        end;

        if not u18.Enabled then
            return;
        end;

        if u24 then
            return;
        end;

        local v147 = time();

        if v147 - u23 > 1.5 then
            u22 = 0;
        end;

        u22 = u22 + 1;
        u23 = v147;
        u18.Enabled = false;
        u28 = false;
        ServerRemote:FireServer("Run", {
            Action = "Terminate"
        });

        if u22 >= (u145:GetAttribute("KiBlastBurst") or 3) then
            u22 = 0;
            u24 = true;
            task.delay(3.5, function() -- Line: 1041
                -- upvalues: u24 (ref), u18 (ref)
                u24 = false;
                u18.Enabled = true;
            end);
        end;

        local v148;

        if u4 then
            u5 = not u5;
            v148 = u5 and "Right Ki Blast" or "Ki Blast";
        else
            v148 = "Right Ki Blast";
        end;

        local v149 = AnimationManager.PlayAnimation(u145, v148, {
            AdjustSpeed = 2
        });

        if not v149 then
            warn("CoreCombat: animation not found:", v148, "(character:", u145.Name .. ")");
        end;

        if not v149 then
            u22 = math.max(u22 - 1, 0);
            u18.Enabled = true;

            return;
        end;

        local u150 = false;

        local function fireBlast() -- Line: 1076
            -- upvalues: u150 (ref), StateManager (ref), u145 (copy), ServerRemote (ref), u143 (copy)
            if u150 then
                return;
            end;

            u150 = true;

            if StateManager.IsInState(u145, "Stunned") then
                return;
            end;

            local Humanoid = u145:FindFirstChild("Humanoid");

            if Humanoid and Humanoid.Health <= 0 then
                return;
            end;

            ServerRemote:FireServer(u143);
        end;

        v149:GetMarkerReachedSignal("Fire"):Once(fireBlast);
        task.delay(0.12, fireBlast);
        v149.Stopped:Once(function() -- Line: 1092
            -- upvalues: u24 (ref), u18 (ref)
            if not u24 then
                u18.Enabled = true;
            end;
        end);
        task.delay(u18.KiBlast_CD, function() -- Line: 1101
            -- upvalues: u24 (ref), u18 (ref)
            if not u24 then
                u18.Enabled = true;
            end;
        end);
    end,

    ["Follow Up"] = function(p151, p152) -- Line: 1110
        -- upvalues: LocalPlayer (copy), ServerRemote (copy), u11 (ref)
        local v153 = LocalPlayer.Character or LocalPlayer.CharacterAdded:Wait();

        if not (v153:FindFirstChild("Follow Up") or v153:GetAttribute("EnderChainWindow")) then
            return;
        end;

        ServerRemote:FireServer(p151, {
            Combo = u11.Combo
        });
    end,

    Evade = function(p154, p155) -- Line: 1127
        -- upvalues: LocalPlayer (copy), SoundManager (copy), u11 (ref), StateManager (copy), ServerRemote (copy)
        local v156 = LocalPlayer.Character or LocalPlayer.CharacterAdded:Wait();

        if v156:GetAttribute("EvadeLocked") == true then
            SoundManager.AddSound("Incorrect", {
                Parent = workspace.CurrentCamera
            }, "Client");

            return;
        end;

        if not u11.EvadeDeb then
            return;
        end;

        if not StateManager.CanPerformAction(v156, "Evade") then
            return;
        end;

        if v156:FindFirstChild("Whiff") then
            return;
        end;

        u11.EvadeDeb = false;
        ServerRemote:FireServer(p154, {
            Combo = u11.Combo
        });
        task.delay(u11.EvadeCooldown, function() -- Line: 1141
            -- upvalues: u11 (ref)
            u11.EvadeDeb = true;
        end);
    end,

    Block = {
        Execute = function(p157, p158) -- Line: 1153
            -- upvalues: LocalPlayer (copy), StateManager (copy), ServerRemote (copy), AnimationManager (copy), checkMouseButtons (copy), u11 (ref), SpeedMultiplier (copy)
            local v159 = LocalPlayer.Character or LocalPlayer.CharacterAdded:Wait();

            if v159:GetAttribute("SuperPushCasting") then
                return;
            end;

            if (v159:GetAttribute("BlockLockUntil") or 0) > workspace:GetServerTimeNow() then
                return;
            end;

            if not StateManager.CanPerformAction(v159, "Block") then
                return;
            end;

            local v160 = v159:FindFirstChildOfClass("Humanoid");
            StateManager.SetState(v159, "Blocking");
            local u161 = false;
            task.delay(0.25, function() -- Line: 1176
                -- upvalues: u161 (ref)
                u161 = true;
            end);
            v160.WalkSpeed = 5;
            v160.JumpPower = 0;
            ServerRemote:FireServer(p157);
            local v162 = AnimationManager.PlayAnimation(v159, "Block[Melee]", {
                Looped = true,
                AdjustSpeed = 2
            });

            if not v162 then
                warn("CoreCombat: animation not found:", "Block[Melee]", "(character:", v159.Name .. ")");
            end;

            while StateManager.IsInState(v159, "Blocking") do
                local v163, _ = checkMouseButtons();

                if u11.Can_Perfect_Block and (u161 and v163) then
                    u11.Can_Perfect_Block = false;
                    ServerRemote:FireServer("Parry");
                    task.delay(u11.ParryCooldown, function() -- Line: 1195
                        -- upvalues: u11 (ref)
                        u11.Can_Perfect_Block = true;
                    end);
                end;

                task.wait();
            end;

            if v162 then
                v162:Stop();
            end;

            ServerRemote:FireServer("UnBlock");

            if not StateManager.IsInCategory(v159, "disabled") then
                if v159 then
                    v159 = v159:FindFirstChildOfClass("Humanoid");
                end;

                if v159 then
                    v159.WalkSpeed = game.StarterPlayer.CharacterWalkSpeed * (SpeedMultiplier and SpeedMultiplier.Value or 1);
                    v159.JumpPower = game.StarterPlayer.CharacterJumpPower;
                end;
            end;

            task.wait(u11.Block_Wait);
        end,

        Terminate = function(p164, p165) -- Line: 1211
            -- upvalues: LocalPlayer (copy), StateManager (copy)
            local v166 = LocalPlayer.Character or LocalPlayer.CharacterAdded:Wait();
            StateManager.ClearState(v166, "Blocking");
        end
    }
};
local u168 = { { "W", "Foward" }, { "S", "Backward" }, { "A", "Left" }, { "D", "Right" } };

local function resolveDashDirection(p169) -- Line: 1244
    -- upvalues: u168 (copy), UserInputService (copy)
    for _, v in ipairs(u168) do
        if UserInputService:IsKeyDown(Enum.KeyCode[v[1]]) then
            return v[2];
        end;
    end;

    local v170 = p169:FindFirstChildOfClass("Humanoid");
    local workspace_CurrentCamera = workspace.CurrentCamera;

    if not (v170 and workspace_CurrentCamera) then
        return "Foward";
    end;

    local MoveDirection = v170.MoveDirection;

    if MoveDirection.Magnitude < 0.15 then
        return "Foward";
    end;

    local CFrame2 = workspace_CurrentCamera.CFrame;
    local Vector3_new_ret = Vector3.new(CFrame2.LookVector.X, 0, CFrame2.LookVector.Z);
    local Vector3_new_ret2 = Vector3.new(CFrame2.RightVector.X, 0, CFrame2.RightVector.Z);

    if Vector3_new_ret.Magnitude < 0.0001 or Vector3_new_ret2.Magnitude < 0.0001 then
        return "Foward";
    end;

    local v171 = MoveDirection:Dot(Vector3_new_ret.Unit);
    local v172 = MoveDirection:Dot(Vector3_new_ret2.Unit);

    return math.abs(v171) >= math.abs(v172) and (v171 >= 0 and "Foward" or "Backward") or (v172 >= 0 and "Right" or "Left");
end;

function v167.Dash(p173, p174) -- Line: 1273
    -- upvalues: u12 (ref), LocalPlayer (copy), StateManager (copy), resolveDashDirection (copy), u28 (ref), ServerRemote (copy), script_DashModule (copy)
    if not u12.Enabled then
        return;
    end;

    local v175 = LocalPlayer.Character or LocalPlayer.CharacterAdded:Wait();

    if not StateManager.CanPerformAction(v175, "Dash") then
        return;
    end;

    u12.Enabled = false;
    local v176 = resolveDashDirection(v175);

    if v176 == "Foward" then
        u28 = false;
        ServerRemote:FireServer("Run", {
            Action = "Terminate"
        });
    end;

    script_DashModule[v176](v175);
    task.delay(u12.Dash_Wait, function() -- Line: 1300
        -- upvalues: u12 (ref)
        u12.Enabled = true;
    end);
end;

function v167.Grip(p177, p178) -- Line: 1310
    -- upvalues: LocalPlayer (copy), StateManager (copy), u14 (ref), ServerRemote (copy)
    local v179 = LocalPlayer.Character or LocalPlayer.CharacterAdded:Wait();

    if not StateManager.CanPerformAction(v179, "Grip") then
        return;
    end;

    if not u14.Enabled then
        return;
    end;

    u14.Enabled = false;
    ServerRemote:FireServer(p177);
    task.delay(u14.Debounce_Time, function() -- Line: 1317
        -- upvalues: u14 (ref)
        u14.Enabled = true;
    end);
end;

function v167.Carry(p180, p181) -- Line: 1322
    -- upvalues: LocalPlayer (copy), StateManager (copy), u14 (ref), ServerRemote (copy)
    local v182 = LocalPlayer.Character or LocalPlayer.CharacterAdded:Wait();

    if not StateManager.CanPerformAction(v182, "Carry") then
        return;
    end;

    if not u14.Enabled then
        return;
    end;

    u14.Enabled = false;
    ServerRemote:FireServer(p180);
    task.delay(u14.Debounce_Time, function() -- Line: 1329
        -- upvalues: u14 (ref)
        u14.Enabled = true;
    end);
end;

function v167.Loot(p183, p184) -- Line: 1336
    -- upvalues: u15 (ref), ServerRemote (copy)
    if not u15.Enabled then
        return;
    end;

    u15.Enabled = false;
    task.delay(u15.Debounce_Time, function() -- Line: 1339
        -- upvalues: u15 (ref)
        u15.Enabled = true;
    end);
    ServerRemote:FireServer(p183);
end;

v167["Ki Sense"] = function(p185, p186) -- Line: 1347
    -- upvalues: u17 (ref), u6 (ref), ServerRemote (copy)
    if not (u17.Enabled and u6) then
        return;
    end;

    u17.Enabled = false;
    task.delay(u17.Debounce_Time, function() -- Line: 1351
        -- upvalues: u17 (ref)
        u17.Enabled = true;
    end);
    ServerRemote:FireServer(p185);
end;

StatChangeRemote.OnClientEvent:Connect(function(p187, u188) -- Line: 1362
    -- upvalues: u3 (ref), u2 (ref), u4 (ref), u6 (ref), u7 (ref)
    local v189 = {
        Agility = function() -- Line: 1364
            -- upvalues: u3 (ref), u188 (copy)
            u3 = u188.NewAgility;
        end,

        ["Combat Style"] = function() -- Line: 1365
            -- upvalues: u2 (ref), u188 (copy)
            u2 = u188.NewStyle;
        end,

        Arm = function() -- Line: 1366
            -- upvalues: u4 (ref), u188 (copy)
            u4 = u188.NewArmState;
        end,

        KiUnlocked = function() -- Line: 1369
            -- upvalues: u6 (ref), u188 (copy)
            u6 = u188.NewValue;
        end,

        GravityMastery = function() -- Line: 1373
            -- upvalues: u7 (ref), u188 (copy)
            u7 = u188.NewValue;
        end
    };

    if v189[p187] then
        v189[p187]();
    end;
end);
LocalPlayer.CharacterAdded:Connect(function(p190) -- Line: 1382
    -- upvalues: resetControlsOnRespawn (copy), disableJump (copy), u25 (ref)
    resetControlsOnRespawn();
    local Humanoid = p190:WaitForChild("Humanoid");
    Humanoid.Jumping:Connect(function(p191) -- Line: 354
        -- upvalues: disableJump (ref), Humanoid (copy), u25 (ref)
        if p191 then
            disableJump(Humanoid, 1.5);
            u25 = true;
            task.delay(0.5, function() -- Line: 358
                -- upvalues: u25 (ref)
                u25 = false;
            end);
        end;
    end);
end);

if LocalPlayer.Character then
    local Humanoid = LocalPlayer.Character:WaitForChild("Humanoid");
    Humanoid.Jumping:Connect(function(p192) -- Line: 354
        -- upvalues: disableJump (copy), Humanoid (copy), u25 (ref)
        if p192 then
            disableJump(Humanoid, 1.5);
            u25 = true;
            task.delay(0.5, function() -- Line: 358
                -- upvalues: u25 (ref)
                u25 = false;
            end);
        end;
    end);
end;

return v167;