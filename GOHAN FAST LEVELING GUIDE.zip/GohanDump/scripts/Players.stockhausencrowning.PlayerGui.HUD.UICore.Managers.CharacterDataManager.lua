-- Decompiled with Potassium's decompiler.

local ReplicatedStorage = game:GetService("ReplicatedStorage");
local Metadata = ReplicatedStorage:WaitForChild("Modules").Metadata;
local Remotes = ReplicatedStorage:WaitForChild("Remotes");
local RankData = require(Metadata.CharacterData.RankData);
local GetServerInfo = Remotes.GetServerInfo;
local MainFrame = script:FindFirstAncestor("HUD").MainFrame;
local HUDisplay = MainFrame.HUDisplay;
local HUDMAIN = HUDisplay.HUDMAIN;
local NameHolder = HUDMAIN.NameHolder;
local AgeHolder = HUDMAIN.AgeHolder;
local RankFrame = HUDMAIN.RankFrame;
local KiLabel = HUDMAIN.KiLabel;
local FalseKiMeter = HUDMAIN.FalseKiMeter;
local OutputBar = HUDMAIN.OutputBar;
local LevelHolder = HUDisplay.LevelHolder;
local RankHolder = HUDisplay.RankHolder;
local LimitBreak = HUDisplay.LimitBreak;
local TitleHolder = HUDisplay.TitleHolder;
local OutputLabel = HUDisplay.OutputLabel;
local PDLabel = MainFrame.PDLabel;
local ServerInfo = MainFrame:WaitForChild("ServerInfo");
local Color3_fromRGB_ret = Color3.fromRGB(103, 255, 209);
local Color3_fromRGB_ret2 = Color3.fromRGB(255, 255, 255);
local u1 = {
    ServerName = {
        pos = 0,
        size = 0.24
    },
    ServerRegion = {
        pos = 0.25,
        size = 0.18
    },
    WorldYear = {
        pos = 0.44,
        size = 0.18
    },
    WorldEra = {
        pos = 0.63,
        size = 0.18
    },
    Uptime = {
        pos = 0.82,
        size = 0.18
    }
};

local function serverUptime() -- Line: 79
    -- upvalues: ReplicatedStorage (copy)
    local Attribute = ReplicatedStorage:GetAttribute("ServerStartTime");

    if Attribute then
        return workspace:GetServerTimeNow() - Attribute;
    end;

    return nil;
end;

local function formatUptime(p2) -- Line: 85
    if p2 == nil then
        return "--";
    end;

    local v3 = p2 < 0 and 0 or p2;
    local math_floor_ret = math.floor(v3 / 86400);
    local math_floor_ret2 = math.floor(v3 % 86400 / 3600);
    local math_floor_ret3 = math.floor(v3 % 3600 / 60);

    if math_floor_ret > 0 then
        return string.format("%dd %02dh %02dm", math_floor_ret, math_floor_ret2, math_floor_ret3);
    end;

    return string.format("%02dh %02dm", math_floor_ret2, math_floor_ret3);
end;

task.spawn(function() -- Line: 97
    -- upvalues: ServerInfo (copy), u1 (copy), ReplicatedStorage (copy), GetServerInfo (copy), formatUptime (copy)
    local ServerRegion = ServerInfo:WaitForChild("ServerRegion");
    ServerInfo.Size = UDim2.new(ServerInfo.Size.X.Scale, ServerInfo.Size.X.Offset, 0.12, 0);
    ServerInfo.ServerName.Size = UDim2.new(1, 0, u1.ServerName.size, 0);
    ServerInfo.ServerName.Position = UDim2.new(0, 0, u1.ServerName.pos, 0);
    ServerRegion.Size = UDim2.new(1, 0, u1.ServerRegion.size, 0);
    ServerRegion.Position = UDim2.new(0, 0, u1.ServerRegion.pos, 0);

    local function addRow(p4) -- Line: 109
        -- upvalues: ServerInfo (ref), ServerRegion (copy), u1 (ref)
        local v5 = ServerInfo:FindFirstChild(p4);

        if v5 then
            return v5;
        end;

        local v6 = ServerRegion:Clone();
        v6.Name = p4;
        v6.Size = UDim2.new(1, 0, u1[p4].size, 0);
        v6.Position = UDim2.new(0, 0, u1[p4].pos, 0);
        v6.Parent = ServerInfo;

        return v6;
    end;

    local u7 = addRow("WorldYear");
    local u8 = addRow("WorldEra");
    local u9 = addRow("Uptime");

    local function refreshWorld() -- Line: 124
        -- upvalues: ReplicatedStorage (ref), u7 (copy), u8 (copy)
        local Attribute = ReplicatedStorage:GetAttribute("WorldYear");
        local Attribute2 = ReplicatedStorage:GetAttribute("WorldEra");
        u7.Text = "WORLD YEAR: " .. tostring(Attribute or "?");
        u8.Text = string.upper(Attribute2 or "Modern Era");
    end;

    ReplicatedStorage:GetAttributeChangedSignal("WorldYear"):Connect(refreshWorld);
    ReplicatedStorage:GetAttributeChangedSignal("WorldEra"):Connect(refreshWorld);
    local Attribute = ReplicatedStorage:GetAttribute("WorldYear");
    local Attribute2 = ReplicatedStorage:GetAttribute("WorldEra");
    u7.Text = "WORLD YEAR: " .. tostring(Attribute or "?");
    u8.Text = string.upper(Attribute2 or "Modern Era");

    local function refreshIdentity() -- Line: 136
        -- upvalues: ReplicatedStorage (ref), ServerInfo (ref), ServerRegion (copy)
        local Attribute3 = ReplicatedStorage:GetAttribute("ServerName");
        local Attribute4 = ReplicatedStorage:GetAttribute("ServerRegion");

        if Attribute3 then
            ServerInfo.ServerName.Text = string.upper(Attribute3);
        end;

        if Attribute4 then
            ServerRegion.Text = "REGION: " .. string.upper(Attribute4);
        end;
    end;

    ReplicatedStorage:GetAttributeChangedSignal("ServerName"):Connect(refreshIdentity);
    ReplicatedStorage:GetAttributeChangedSignal("ServerRegion"):Connect(refreshIdentity);
    refreshIdentity();

    if ReplicatedStorage:GetAttribute("ServerRegion") == nil then
        task.spawn(function() -- Line: 147
            -- upvalues: GetServerInfo (ref), ReplicatedStorage (ref), ServerInfo (ref), ServerRegion (copy)
            local v10 = GetServerInfo:InvokeServer("GetServer") or {};

            if ReplicatedStorage:GetAttribute("ServerName") == nil then
                ServerInfo.ServerName.Text = string.upper(v10.Name or "None");
            end;

            if ReplicatedStorage:GetAttribute("ServerRegion") == nil then
                ServerRegion.Text = "REGION: " .. string.upper(v10.ServerRegion or "Unknown");
            end;
        end);
    end;

    local u11 = 0;

    local function refreshUptime() -- Line: 160
        -- upvalues: u9 (copy), formatUptime (ref), ReplicatedStorage (ref)
        local Attribute3 = ReplicatedStorage:GetAttribute("ServerStartTime");
        local v12;

        if Attribute3 then
            v12 = workspace:GetServerTimeNow() - Attribute3;
        else
            v12 = nil;
        end;

        u9.Text = "UPTIME: " .. formatUptime(v12);
    end;

    ReplicatedStorage:GetAttributeChangedSignal("ServerStartTime"):Connect(refreshUptime);
    local Attribute3 = ReplicatedStorage:GetAttribute("ServerStartTime");
    local v13;

    if Attribute3 then
        v13 = workspace:GetServerTimeNow() - Attribute3;
    else
        v13 = nil;
    end;

    u9.Text = "UPTIME: " .. formatUptime(v13);
    game:GetService("RunService").Heartbeat:Connect(function(p14) -- Line: 167
        -- upvalues: u11 (ref), u9 (copy), formatUptime (ref), ReplicatedStorage (ref)
        u11 = u11 + p14;

        if u11 < 1 then
            return;
        end;

        u11 = 0;
        local Attribute4 = ReplicatedStorage:GetAttribute("ServerStartTime");
        local v15;

        if Attribute4 then
            v15 = workspace:GetServerTimeNow() - Attribute4;
        else
            v15 = nil;
        end;

        u9.Text = "UPTIME: " .. formatUptime(v15);
    end);
end);
local v16 = {};
local ReplicatedStorage2 = game:GetService("ReplicatedStorage");
local u17 = nil;

local function ageText(p18) -- Line: 185
    -- upvalues: ReplicatedStorage2 (copy)
    local Attribute = ReplicatedStorage2:GetAttribute("WorldYear");

    return not (Attribute and (p18 and (p18 ~= 0 and Attribute >= p18))) and "Age: ?" or "Age: " .. Attribute - p18;
end;

ReplicatedStorage2:GetAttributeChangedSignal("WorldYear"):Connect(function() -- Line: 193
    -- upvalues: u17 (ref), AgeHolder (copy), ReplicatedStorage2 (copy)
    if u17 then
        local v19 = u17;
        local Attribute = ReplicatedStorage2:GetAttribute("WorldYear");
        AgeHolder.Text = not (Attribute and (v19 and (v19 ~= 0 and Attribute >= v19))) and "Age: ?" or "Age: " .. Attribute - v19;
    end;
end);

function v16.Update(p20, p21) -- Line: 199
    -- upvalues: NameHolder (copy), RankHolder (copy), RankData (copy), TitleHolder (copy), u17 (ref), AgeHolder (copy), ReplicatedStorage2 (copy), RankFrame (copy), LevelHolder (copy), PDLabel (copy), Color3_fromRGB_ret (copy), Color3_fromRGB_ret2 (copy), LimitBreak (copy), OutputBar (copy), KiLabel (copy), FalseKiMeter (copy), OutputLabel (copy)
    local CharacterData = p20.CharacterData;
    local GameLevel = p20.StatData.GameLevel;
    NameHolder.Text = CharacterData.Name;
    RankHolder.Text = RankData[CharacterData.Rank].Description;
    TitleHolder.Text = CharacterData.Title or "";
    u17 = CharacterData.BirthYear;
    local v22;

    if CharacterData.BirthYear then
        local BirthYear = CharacterData.BirthYear;
        local Attribute = ReplicatedStorage2:GetAttribute("WorldYear");
        v22 = not (Attribute and (BirthYear and (BirthYear ~= 0 and Attribute >= BirthYear))) and "Age: ?" or "Age: " .. Attribute - BirthYear or "Age: " .. CharacterData.Age;
    else
        v22 = "Age: " .. CharacterData.Age;
    end;

    AgeHolder.Text = v22;
    RankFrame.Image = RankData[tostring(CharacterData.SubRank)];
    LevelHolder.Text = "LVL: " .. GameLevel.Level;

    if p21 and p21.PD ~= nil then
        PDLabel.Visible = p21.PD;
    end;

    RankFrame.ImageColor3 = p20.StatData.CoreStats["Ungained TP"] == 0 and Color3_fromRGB_ret or Color3_fromRGB_ret2;

    if GameLevel.Can_Limit_Break then
        LimitBreak.Visible = true;
        LimitBreak.Bar.Meter:TweenSize(UDim2.new(GameLevel.LimitExp / GameLevel.MaxLimitExp, 0, 1, 0), "Out", "Sine", 0.1);
    else
        LimitBreak.Visible = false;
    end;

    if p20.StatData.Energy.KiUnlocked then
        OutputBar.Visible = true;
        KiLabel.Visible = true;
        FalseKiMeter.Visible = true;
        OutputLabel.Visible = true;
    end;
end;

return v16;