-- Decompiled with Potassium's decompiler.

local Players = game:GetService("Players");
local ReplicatedStorage = game:GetService("ReplicatedStorage");
local RunService = game:GetService("RunService");
local Signal = require(script.Parent.Signal);
local u1 = RunService:IsServer();
local u2, u3, u4;

if u1 then
    u2 = script:FindFirstChildOfClass("RemoteEvent") or Instance.new("RemoteEvent", script);
    u3 = script:FindFirstChildOfClass("RemoteFunction") or Instance.new("RemoteFunction", script);
    u4 = script:FindFirstChildOfClass("UnreliableRemoteEvent") or Instance.new("UnreliableRemoteEvent", script);
    u2.Name = "RemoteEvent";
    u3.Name = "RemoteFunction";
    u4.Name = "UnreliableRemoteEvent";
else
    u2 = script:WaitForChild("RemoteEvent");
    u3 = script:WaitForChild("RemoteFunction");
    u4 = script:WaitForChild("UnreliableRemoteEvent");
end;

if not (u1 or script:IsDescendantOf(ReplicatedStorage)) then
    warn("Remote module should be placed in ReplicatedStorage");
end;

local u5 = {};
u5.__index = u5;
local u6 = {};
local u7 = {};

local function newRemote(p8: string, p9: string?) -- Line: 119
    -- upvalues: Signal (copy), u2 (ref), u5 (copy), u6 (copy), u7 (copy)
    local v10 = {
        _id = p9,
        _key = p8,
        _signal = Signal.new(),
        _remote = u2
    };
    local v11 = setmetatable(v10, u5);
    u6[p8] = v11;

    if p9 then
        u7[p9] = v11;
    end;

    return v11;
end;

function u5.Connect(p12: any, p13: function) -- Line: 136
    return p12._signal:Connect(p13);
end;

function u5.Once(p14: any, p15: function) -- Line: 140
    return p14._signal:Once(p15);
end;

function u5.Wait(p16) -- Line: 144
    return p16._signal:Wait();
end;

function u5.FireAll(p17, ...) -- Line: 148
    p17._remote:FireAllClients(p17._id, ...);
end;

function u5.SetUnreliable(p18: any, p19: boolean) -- Line: 152
    -- upvalues: u1 (copy), u4 (ref), u2 (ref)
    if not u1 then
        warn((`Client cannot set reliability on Remote {p18._key}`));

        return;
    end;

    local v20 = p19 and u4 or u2;

    if p18._remote ~= v20 then
        p18._remote = v20;

        if p18._id then
            u2:FireAllClients(script, p19, p18._id);
        end;
    end;
end;

if u1 then
    function u5.Fire(p21: any, p22: userdata, ...) -- Line: 167
        p21._remote:FireClient(p22, p21._id, ...);
    end;

    function u5.Invoke(p23: any, p24: userdata, ...) -- Line: 171
        -- upvalues: u3 (ref)
        return u3:InvokeClient(p24, p23._id, ...);
    end;

    local u25 = 0;

    local function generateId() -- Line: 176
        -- upvalues: u25 (ref)
        local v26 = u25;
        u25 = u25 + 1;

        if v26 < 256 then
            return string.char(v26);
        end;

        return string.pack("<I2", v26);
    end;

    setmetatable(u6, {
        __index = function(p27: any, p28: string) -- Line: 184, Name: __index
            -- upvalues: u25 (ref), Signal (copy), u2 (ref), u5 (copy), u6 (copy), u7 (copy)
            local v29 = u25;
            u25 = u25 + 1;
            local v30;

            if v29 < 256 then
                v30 = string.char(v29);
            else
                v30 = string.pack("<I2", v29);
            end;

            local v31 = {
                _id = v30,
                _key = p28,
                _signal = Signal.new(),
                _remote = u2
            };
            local v32 = setmetatable(v31, u5);
            u6[p28] = v32;

            if v30 then
                u7[v30] = v32;
            end;

            u2:FireAllClients(script, p28, v30);

            return v32;
        end
    });
    local u33 = {};

    local function syncPayload(p34: userdata) -- Line: 194
        -- upvalues: u33 (copy), u6 (copy), u4 (ref), u2 (ref)
        if u33[p34.UserId] then
            return;
        end;

        u33[p34.UserId] = true;
        local v35 = {};

        for i, v in u6 do
            if i ~= script then
                v35[v._id] = { i, v._remote == u4 and true or nil };
            end;
        end;

        u2:FireClient(p34, script, v35);
    end;

    Players.PlayerRemoving:Connect(function(p36) -- Line: 214
        -- upvalues: u33 (copy)
        u33[p36.UserId] = nil;
    end);
    u7[script] = {
        _signal = {
            Fire = function(p37: any, p38: userdata) -- Line: 220, Name: Fire
                -- upvalues: syncPayload (copy)
                syncPayload(p38);
            end
        }
    };

    local function handleEvent(p39: userdata, p40: string, ...) -- Line: 226
        -- upvalues: u7 (copy)
        local v41 = u7[p40];

        if v41 then
            v41._signal:Fire(p39, ...);
        end;
    end;

    u2.OnServerEvent:Connect(handleEvent);
    u4.OnServerEvent:Connect(handleEvent);

    function u3.OnServerInvoke(p42, p43, ...) -- Line: 235
        -- upvalues: u7 (copy)
        local v44 = u7[p43];

        if v44 and v44.OnInvoke then
            return v44.OnInvoke(p42, ...);
        end;
    end;

    u2:SetAttribute("ServerReady", true);
else
    function u5.Fire(p45, ...) -- Line: 244
        if p45._id then
            p45._remote:FireServer(p45._id, ...);

            return;
        end;

        if not p45._fireQueue then
            p45._fireQueue = {};
        end;

        table.insert(p45._fireQueue, { ... });
    end;

    function u5.Invoke(p46, ...) -- Line: 255
        -- upvalues: u3 (ref)
        if p46._id then
            return u3:InvokeServer(p46._id, ...);
        end;

        if not p46._invokeQueue then
            p46._invokeQueue = {};
        end;

        local _invokeQueue = p46._invokeQueue;
        local v47 = { coroutine.running(), (...) };
        table.insert(_invokeQueue, v47);

        return coroutine.yield();
    end;

    setmetatable(u6, {
        __index = function(p48: any, u49: string) -- Line: 269, Name: __index
            -- upvalues: Signal (copy), u2 (ref), u5 (copy), u6 (copy)
            local v50 = {
                _id = nil,
                _key = u49,
                _signal = Signal.new(),
                _remote = u2
            };
            local u51 = setmetatable(v50, u5);
            u6[u49] = u51;
            task.delay(5, function() -- Line: 272
                -- upvalues: u51 (copy), u49 (copy)
                if not u51._id then
                    warn((`Infinite yield possible on Remote '{u49}'`));
                end;
            end);

            return u51;
        end
    });

    local function flushQueue(u52) -- Line: 282
        -- upvalues: u2 (ref), u3 (ref)
        if u52._fireQueue then
            for _, v in u52._fireQueue do
                u2:FireServer(u52._id, unpack(v));
            end;

            u52._fireQueue = nil;
        end;

        if u52._invokeQueue then
            for _, v in u52._invokeQueue do
                local u53 = v[1];
                task.spawn(function() -- Line: 293
                    -- upvalues: u3 (ref), u52 (copy), v (copy), u53 (copy)
                    local v54 = { pcall(function() -- Line: 295
                            -- upvalues: u3 (ref), u52 (ref), v (ref)
                            return u3:InvokeServer(u52._id, unpack(v, 2));
                        end) };

                    if coroutine.status(u53) == "suspended" then
                        if v54[1] then
                            task.spawn(u53, unpack(v54, 2));

                            return;
                        end;

                        warn("Error invoking remote function:", v54[2]);
                        task.spawn(u53);
                    end;
                end);
            end;

            u52._invokeQueue = nil;
        end;
    end;

    local function linkId(p55: string, p56: string, p57: boolean?) -- Line: 312
        -- upvalues: u6 (copy), Signal (copy), u2 (ref), u5 (copy), u7 (copy), u4 (ref), flushQueue (copy)
        local v58 = u6[p55];

        if not v58 then
            local v59 = {
                _id = nil,
                _key = p55,
                _signal = Signal.new(),
                _remote = u2
            };
            v58 = setmetatable(v59, u5);
            u6[p55] = v58;
        end;

        v58._id = p56;
        u7[p56] = v58;
        local v60;

        if p57 then
            v60 = u4;
        else
            v60 = u2;
        end;

        v58._remote = v60;
        flushQueue(v58);
    end;

    u7[script] = {
        _signal = {
            Fire = function(p61, p62, p63) -- Line: 327, Name: Fire
                -- upvalues: u6 (copy), Signal (copy), u2 (ref), u5 (copy), u7 (copy), flushQueue (copy), u4 (ref)
                if type(p62) ~= "string" then
                    if type(p62) == "boolean" then
                        local v64 = u7[p63];

                        if v64 then
                            v64:SetUnreliable(p62);

                            return;
                        end;
                    elseif type(p62) == "table" then
                        for i, v in p62 do
                            local v65 = v[1];
                            local v66 = v[2];
                            local v67 = u6[v65];

                            if not v67 then
                                local v68 = {
                                    _id = nil,
                                    _key = v65,
                                    _signal = Signal.new(),
                                    _remote = u2
                                };
                                v67 = setmetatable(v68, u5);
                                u6[v65] = v67;
                            end;

                            v67._id = i;
                            u7[i] = v67;
                            local v69;

                            if v66 then
                                v69 = u4;
                            else
                                v69 = u2;
                            end;

                            v67._remote = v69;
                            flushQueue(v67);
                        end;
                    end;

                    return;
                end;

                local v70 = u6[p62];

                if not v70 then
                    local v71 = {
                        _id = nil,
                        _key = p62,
                        _signal = Signal.new(),
                        _remote = u2
                    };
                    v70 = setmetatable(v71, u5);
                    u6[p62] = v70;
                end;

                v70._id = p63;
                u7[p63] = v70;
                v70._remote = u2;
                flushQueue(v70);
            end
        }
    };

    local function v74(p72: string, ...) -- Line: 349
        -- upvalues: u7 (copy)
        local v73 = u7[p72];

        if v73 then
            v73._signal:Fire(...);
        end;
    end;

    u2.OnClientEvent:Connect(v74);
    u4.OnClientEvent:Connect(v74);

    function u3.OnClientInvoke(p75, ...) -- Line: 358
        -- upvalues: u7 (copy)
        local v76 = u7[p75];

        if v76 and v76.OnInvoke then
            return v76.OnInvoke(...);
        end;
    end;

    if not u2:GetAttribute("ServerReady") then
        u2:GetAttributeChangedSignal("ServerReady"):Wait();
    end;

    u2:FireServer(script);
end;

return u6;