-- Decompiled with Potassium's decompiler.

local Players = game:GetService("Players");
local Remotes = game:GetService("ReplicatedStorage"):WaitForChild("Remotes");
local StatRetrieveRemote = Remotes:WaitForChild("StatRetrieveRemote");
local v1 = {};
local u2 = {};
local u3 = {};
local u4 = {};
local u5 = {};
local u6 = "?";

local function localName() -- Line: 59
    -- upvalues: Players (copy)
    local LocalPlayer = Players.LocalPlayer;

    return LocalPlayer and LocalPlayer.Name or "?";
end;

local function keyOf(p7, p8) -- Line: 64
    return tostring(p7) .. "|" .. tostring(p8 or "");
end;

local function fetch(u9, u10) -- Line: 68
    -- upvalues: u2 (copy), StatRetrieveRemote (copy), u6 (ref), Players (copy)
    local v11 = tostring(u9) .. "|" .. tostring(u10 or "");
    local v12 = u2[v11];

    if v12 then
        return v12.value;
    end;

    local success, result = pcall(function() -- Line: 73
        -- upvalues: StatRetrieveRemote (ref), u9 (copy), u10 (copy)
        return StatRetrieveRemote:InvokeServer(u9, u10);
    end);

    if not success then
        local v13 = warn;
        local v14 = tostring(u9);
        local LocalPlayer = Players.LocalPlayer;
        v13(("[DialogueContext] %s: fetching %q failed for %s — %s"):format(u6, v14, LocalPlayer and LocalPlayer.Name or "?", (tostring(result))));
        result = nil;
    end;

    u2[v11] = {
        value = result
    };

    return result;
end;

function v1.Begin(p15) -- Line: 94
    -- upvalues: u2 (copy), u3 (copy), u4 (copy), u5 (copy), u6 (ref)
    table.clear(u2);
    table.clear(u3);
    table.clear(u4);
    table.clear(u5);
    u6 = p15 or "?";
end;

function v1.Finish() -- Line: 102
    -- upvalues: u2 (copy), u3 (copy), u4 (copy), u5 (copy), u6 (ref)
    table.clear(u2);
    table.clear(u3);
    table.clear(u4);
    table.clear(u5);
    u6 = "?";
end;

function v1.Ready(p16, p17) -- Line: 117
    -- upvalues: u2 (copy), fetch (copy)
    local v18 = p16 or 5;
    local v19 = p17 or 0.4;

    for i = 1, v18 do
        table.clear(u2);

        if fetch("Level") ~= nil then
            return true;
        end;

        local v20;

        if i < v18 then
            task.wait(v19);
            v20 = i;
        else
            v20 = i;
        end;
    end;

    return false;
end;

function v1.Raw(p21, p22) -- Line: 131
    -- upvalues: fetch (copy)
    return fetch(p21, p22);
end;

function v1.Has(p23, p24) -- Line: 136
    -- upvalues: fetch (copy)
    return fetch(p23, p24) ~= nil;
end;

function v1.Number(p25, p26, p27) -- Line: 140
    -- upvalues: fetch (copy), u6 (ref)
    local v28 = fetch(p25, p26);

    if type(v28) == "number" then
        return v28;
    end;

    local v29 = p27 or 0;

    if v28 ~= nil then
        warn(("[DialogueContext] %s: %q is a %s, expected number — using %s"):format(u6, tostring(p25), typeof(v28), (tostring(v29))));
    end;

    return v29;
end;

function v1.Bool(p30, p31) -- Line: 151
    -- upvalues: fetch (copy)
    return fetch(p30, p31) == true;
end;

function v1.Table(p32, p33) -- Line: 155
    -- upvalues: fetch (copy)
    local v34 = fetch(p32, p33);

    return type(v34) == "table" and v34 and v34 or {};
end;

function v1.String(p35, p36, p37) -- Line: 160
    -- upvalues: fetch (copy)
    local v38 = fetch(p35, p36);

    return type(v38) ~= "string" and (p37 or "") or v38;
end;

v1.Remote = {};

function v1.Remote.InvokeServer(p39, p40, p41) -- Line: 194
    -- upvalues: fetch (copy)
    local v42 = fetch(p40, p41);

    return v42 == nil and (p41 == "TableStat" and {} or 0) or v42;
end;

local u43 = nil;
v1.StoryRemote = {};

function v1.StoryRemote.InvokeServer(p44, u45) -- Line: 221
    -- upvalues: u43 (ref), Remotes (copy), u6 (ref), Players (copy), u3 (copy)
    local v46 = tostring(u45 and (u45.Action or "GetStory") or "GetStory");
    u43 = u43 or Remotes:FindFirstChild("GetStoryRemote");

    if not u43 then
        warn(("[DialogueContext] %s: GetStoryRemote is missing"):format(u6));

        if v46 == "GetStory" then
            return 0, 0, "";
        end;

        return false;
    end;

    if v46 == "GetStory" then
        local v47 = u3[v46];

        if not v47 then
            local v48, v49, v50, v51 = pcall(function() -- Line: 259
                -- upvalues: u43 (ref), u45 (copy)
                return u43:InvokeServer(u45);
            end);

            if not v48 then
                local LocalPlayer = Players.LocalPlayer;
                warn(("[DialogueContext] %s: story lookup failed for %s — %s"):format(u6, LocalPlayer and LocalPlayer.Name or "?", (tostring(v49))));
                v49 = nil;
                v50 = nil;
                v51 = nil;
            end;

            v47 = { tonumber(v49) or 0, tonumber(v50) or 0, type(v51) == "string" and v51 and v51 or "" };
            u3[v46] = v47;
        end;

        return v47[1], v47[2], v47[3];
    end;

    local success, result = pcall(function() -- Line: 245
        -- upvalues: u43 (ref), u45 (copy)
        return u43:InvokeServer(u45);
    end);

    if success then
        u3.GetStory = nil;

        return result;
    end;

    local LocalPlayer = Players.LocalPlayer;
    warn(("[DialogueContext] %s: story mutation %q failed for %s — %s"):format(u6, v46, LocalPlayer and LocalPlayer.Name or "?", (tostring(result))));

    return false;
end;

local u52 = {
    GetTrainers = true,
    CheckReqs = true,
    CheckSkills = true,
    CheckCertainTrainer = true,
    GiveSkill = false,
    AddTrainer = false
};
v1.TrainerRemote = {};

function v1.TrainerRemote.InvokeServer(p53, u54, u55) -- Line: 322
    -- upvalues: u52 (copy), u4 (copy), Remotes (copy), u6 (ref), Players (copy)
    local v56 = u52[u55] == true;
    local v57 = tostring(u54) .. "|" .. tostring(u55);
    local v58 = v56 and u4[v57];

    if v58 then
        return table.unpack(v58, 1, v58.n);
    end;

    local TrainerRemote = Remotes:FindFirstChild("TrainerRemote");

    if not TrainerRemote then
        warn(("[DialogueContext] %s: TrainerRemote is missing"):format(u6));

        return false;
    end;

    local table_pack_ret = table.pack(pcall(function() -- Line: 339
        -- upvalues: TrainerRemote (copy), u54 (copy), u55 (copy)
        return TrainerRemote:InvokeServer(u54, u55);
    end));

    if table_pack_ret[1] then
        local table_pack_ret2 = table.pack(table.unpack(table_pack_ret, 2, table_pack_ret.n));

        if table_pack_ret2.n == 0 or table_pack_ret2[1] == nil then
            table_pack_ret2 = table.pack(false);
        end;

        if v56 then
            u4[v57] = table_pack_ret2;
        end;

        return table.unpack(table_pack_ret2, 1, table_pack_ret2.n);
    end;

    local v59 = warn;
    local v60 = tostring(u54);
    local v61 = tostring(u55);
    local LocalPlayer = Players.LocalPlayer;
    v59(("[DialogueContext] %s: trainer %q/%q failed for %s — %s"):format(u6, v60, v61, LocalPlayer and LocalPlayer.Name or "?", (tostring(table_pack_ret[2]))));

    return false;
end;

v1.DailyRemote = {};

function v1.DailyRemote.InvokeServer(p62, u63) -- Line: 372
    -- upvalues: u5 (copy), Remotes (copy), u6 (ref), Players (copy)
    local v64;

    if u63 then
        v64 = u63.Action;
    else
        v64 = u63;
    end;

    local v65 = v64 == "CheckTimeLeft";
    local v66 = tostring(v64);
    local v67;

    if u63 then
        v67 = u63.DailyName;
    else
        v67 = u63;
    end;

    local v68 = v66 .. "|" .. tostring(v67);
    local v69 = v65 and u5[v68];

    if v69 then
        return v69[1], v69[2];
    end;

    local DailyRemote = Remotes:FindFirstChild("DailyRemote");
    local v70 = nil;
    local v71 = nil;

    if DailyRemote then
        local v72;
        v72, v70, v71 = pcall(function() -- Line: 385
            -- upvalues: DailyRemote (copy), u63 (copy)
            return DailyRemote:InvokeServer(u63);
        end);

        if not v72 then
            local v73 = warn;
            local v74 = tostring(v64);
            local LocalPlayer = Players.LocalPlayer;
            v73(("[DialogueContext] %s: daily %q failed for %s — %s"):format(u6, v74, LocalPlayer and LocalPlayer.Name or "?", (tostring(v70))));
            v70 = nil;
            v71 = nil;
        end;
    else
        warn(("[DialogueContext] %s: DailyRemote is missing"):format(u6));
    end;

    if not v65 then
        return v70, v71;
    end;

    local v75 = tonumber(v70) or 0;
    local v76 = v71 == true;
    u5[v68] = { v75, v76 };

    return v75, v76;
end;

return v1;