-- Decompiled with Potassium's decompiler.

game.StarterGui:SetCoreGuiEnabled(Enum.CoreGuiType.Backpack, false);
local ReplicatedStorage = game:GetService("ReplicatedStorage");
local UserInputService = game:GetService("UserInputService");
local Players = game:GetService("Players");
local GuiService = game:GetService("GuiService");
local Modules = ReplicatedStorage:WaitForChild("Modules");
local Remotes = ReplicatedStorage:WaitForChild("Remotes");
local Shared = Modules.Shared;
local ControlData = require(Modules.Metadata.ControlData.ControlData);
local GlobalFunctions = require(Modules.GlobalFunctions);
local AnimationManager = require(Shared.AnimationManager);
local Platform = require(Shared.Platform);
local TweenService = game:GetService("TweenService");
local LocalPlayer = Players.LocalPlayer;
LocalPlayer:GetMouse();
local Parent = script.Parent.Parent;
local MainFrame = Parent:FindFirstChild("MainFrame");
local script_Parent = script.Parent;
local Space = script_Parent.Space;
local RegSlots = script_Parent.RegSlots;
local StatFrame = script_Parent.StatFrame;
local PartyFrame = script_Parent.PartyFrame;
local ItemTab = Space.ScrollingFrame.ItemTab;
local SkillsTab = Space.ScrollingFrame.SkillsTab;
local InventoryRemote = Remotes.InventoryRemote;
local StatRetrieveRemote = Remotes.StatRetrieveRemote;
local ServerRemote = Remotes.ServerRemote;
local u1 = Platform.IsConsole();
local Color3_fromRGB_ret = Color3.fromRGB(255, 255, 50);
local Color3_fromRGB_ret2 = Color3.fromRGB(255, 255, 255);
local UDim2_new_ret = UDim2.new(1.1, 0, 1.1, 0);
local TweenInfo_new_ret = TweenInfo.new(0.25, Enum.EasingStyle.Quad, Enum.EasingDirection.Out);
local Color3_fromRGB_ret3 = Color3.fromRGB(255, 255, 120);
local u2 = ControlData.Controls.CoreControls.Inventory[1];
local u3 = {
    [Enum.KeyCode.One] = "1",
    [Enum.KeyCode.Two] = "2",
    [Enum.KeyCode.Three] = "3",
    [Enum.KeyCode.Four] = "4",
    [Enum.KeyCode.Five] = "5",
    [Enum.KeyCode.Six] = "6",
    [Enum.KeyCode.Seven] = "7",
    [Enum.KeyCode.Eight] = "8",
    [Enum.KeyCode.Nine] = "9",
    [Enum.KeyCode.Zero] = "0"
};
local u4 = {};

for _, v in pairs(u3) do
    u4[v] = true;
end;

local u5 = {};
local u6 = "";
local u7 = {};
local u8 = "";
local u9 = false;
local u10 = "";
local u11 = {};

for _, child in ipairs(RegSlots:GetChildren()) do
    if child:IsA("Frame") then
        u5[child.Name] = child;
    end;
end;

local Backpack = LocalPlayer:WaitForChild("Backpack");
local u12 = {};
local u13 = 0;
local u14 = "";

local function frameMatchesFilter(p15: string, p16: string?) -- Line: 155
    -- upvalues: u14 (ref)
    if u14 == "" then
        return true;
    end;

    if p15:lower():find(u14, 1, true) then
        return true;
    end;

    local v17;

    if p16 == nil then
        v17 = false;
    else
        v17 = p16:lower():find(u14, 1, true) ~= nil;
    end;

    return v17;
end;

local u18 = {};
local u19 = false;
local u20 = false;
local u21 = false;

local function getCharacter() -- Line: 172
    -- upvalues: LocalPlayer (copy)
    return LocalPlayer.Character or LocalPlayer.CharacterAdded:Wait();
end;

local function clearConnections(p22) -- Line: 176
    for i, v in pairs(p22) do
        v:Disconnect();
        p22[i] = nil;
    end;
end;

local function slotItemFrame(p23: userdata) -- Line: 183
    return p23:FindFirstChild("ItemFrame");
end;

local function slotOccupantCount(p24: userdata) -- Line: 189
    local v25 = 0;

    for _, child in ipairs(p24:GetChildren()) do
        if child.Name == "ItemFrame" and child:IsA("GuiObject") then
            v25 = v25 + 1;
        end;
    end;

    return v25;
end;

local function isInInventoryContainer(p26: userdata) -- Line: 197
    local v27;

    if p26.Parent == nil then
        v27 = false;
    else
        v27 = p26.Parent.Name == "ItemContainer";
    end;

    return v27;
end;

local TweenInfo_new_ret2 = TweenInfo.new(0.12, Enum.EasingStyle.Quad, Enum.EasingDirection.Out);
local u28 = nil;

local function frameScale(p29: userdata) -- Line: 222
    local v30 = p29:FindFirstChildOfClass("UIScale");

    if not v30 then
        v30 = Instance.new("UIScale");
        v30.Parent = p29;
    end;

    return v30;
end;

local function targetScaleFor(p31: userdata) -- Line: 231
    -- upvalues: u4 (copy), Color3_fromRGB_ret (copy), u28 (ref)
    local Parent2 = p31.Parent;
    local v32;

    if Parent2 == nil then
        v32 = false;
    else
        v32 = u4[Parent2.Name] == true;
    end;

    return v32 and p31.Number.TextColor3 == Color3_fromRGB_ret and 1.2 or (p31 == u28 and 1.12 or 1);
end;

local function refreshFrameScale(p33: userdata?) -- Line: 241
    -- upvalues: TweenService (copy), TweenInfo_new_ret2 (copy), u4 (copy), Color3_fromRGB_ret (copy), u28 (ref)
    if not (p33 and p33.Parent) then
        return;
    end;

    local v34 = p33:FindFirstChildOfClass("UIScale");

    if not v34 then
        v34 = Instance.new("UIScale");
        v34.Parent = p33;
    end;

    local v35 = {};
    local Parent2 = p33.Parent;
    local v36;

    if Parent2 == nil then
        v36 = false;
    else
        v36 = u4[Parent2.Name] == true;
    end;

    v35.Scale = v36 and p33.Number.TextColor3 == Color3_fromRGB_ret and 1.2 or (p33 == u28 and 1.12 or 1);
    TweenService:Create(v34, TweenInfo_new_ret2, v35):Play();
end;

local function clearKeyColors() -- Line: 247
    -- upvalues: u5 (copy), Color3_fromRGB_ret2 (copy), refreshFrameScale (copy)
    for _, v in pairs(u5) do
        local ItemFrame = v:FindFirstChild("ItemFrame");

        if ItemFrame then
            ItemFrame.Number.TextColor3 = Color3_fromRGB_ret2;
            refreshFrameScale(ItemFrame);
        end;
    end;
end;

local function isSkillTool(p37: userdata?) -- Line: 260
    if not p37 then
        return false;
    end;

    if p37:FindFirstChild("Skill") then
        return true;
    end;

    local Attribute = p37:GetAttribute("SkillName");
    local v38;

    if Attribute == nil then
        v38 = false;
    else
        v38 = Attribute ~= "";
    end;

    return v38;
end;

local u39 = {
    Melee = Color3.fromRGB(255, 120, 60),
    Rush = Color3.fromRGB(255, 200, 60),
    Blasts = Color3.fromRGB(255, 70, 70),
    Wave = Color3.fromRGB(90, 160, 255),
    Explosion = Color3.fromRGB(255, 140, 0),
    Misc = Color3.fromRGB(200, 120, 255),
    ["Race Skills"] = Color3.fromRGB(120, 255, 160)
};
local u40 = {
    { "Evasive", Color3.fromRGB(255, 0, 255) },
    { "Defensive", Color3.fromRGB(150, 220, 255) },
    { "Healing", Color3.fromRGB(155, 255, 155) },
    { "Special", Color3.fromRGB(255, 150, 0) }
};
local v41 = {
    Consumables = Color3.fromRGB(150, 230, 130),
    Dragonballs = Color3.fromRGB(255, 190, 70),
    Training = Color3.fromRGB(170, 190, 220),
    Technology = Color3.fromRGB(90, 220, 220),
    Misc = Color3.fromRGB(190, 190, 190)
};

local function checkContainerVisibility() -- Line: 313
end;

local ScrollingFrame = Space.ScrollingFrame;
ScrollingFrame.AutomaticCanvasSize = Enum.AutomaticSize.Y;
ScrollingFrame.CanvasSize = UDim2.new(0, 0, 0, 0);
ScrollingFrame.ScrollingDirection = Enum.ScrollingDirection.Y;
ScrollingFrame.ScrollBarThickness = 6;
local u42 = {};

local function makeGridContainer(p43: userdata, p44: number) -- Line: 335
    local Frame = Instance.new("Frame");
    Frame.Name = "ItemContainer";
    Frame.BackgroundTransparency = 1;
    Frame.Size = UDim2.new(1, 0, 0, 0);
    Frame.LayoutOrder = p44;
    Frame.Parent = p43;
    local UIGridLayout = Instance.new("UIGridLayout");
    UIGridLayout.SortOrder = Enum.SortOrder.LayoutOrder;
    UIGridLayout.Parent = Frame;
    local UIPadding = Instance.new("UIPadding");
    UIPadding.PaddingTop = UDim.new(0, 4);
    UIPadding.PaddingBottom = UDim.new(0, 4);
    UIPadding.PaddingLeft = UDim.new(0, 4);
    UIPadding.PaddingRight = UDim.new(0, 4);
    UIPadding.Parent = Frame;

    return Frame, UIGridLayout;
end;

local function buildSubSectionedTab(u45: userdata, p46: table, p47: any) -- Line: 359
    -- upvalues: TweenService (copy), TweenInfo_new_ret (copy), makeGridContainer (copy), u14 (ref), u42 (copy)
    local TitleLabel = u45:FindFirstChild("TitleLabel");
    local ItemContainer = u45:FindFirstChild("ItemContainer");

    if ItemContainer then
        ItemContainer:Destroy();
    end;

    local v48 = u45:FindFirstChildOfClass("UIListLayout");
    v48.SortOrder = Enum.SortOrder.LayoutOrder;
    v48.Padding = UDim.new(0, 4);
    TitleLabel.LayoutOrder = 1;
    TitleLabel.Size = UDim2.new(1, 0, 0, 24);
    TitleLabel.Position = UDim2.new(0, 0, 0, 0);
    u45.AutomaticSize = Enum.AutomaticSize.None;
    u45.ClipsDescendants = true;
    local u49 = {};

    local function anyVisibleItem(p50: userdata) -- Line: 377
        for _, child in ipairs(p50:GetChildren()) do
            if child.Name == "ItemFrame" and child.Visible then
                return true;
            end;
        end;

        return false;
    end;

    local function recomputeTabHeight() -- Line: 384
        -- upvalues: u49 (copy), u45 (copy), TweenService (ref), TweenInfo_new_ret (ref)
        local v51 = 24;
        local v52 = false;

        for _, v in ipairs(u49) do
            if v.Visible then
                v51 = v51 + (4 + v.Size.Y.Offset);
                v52 = true;
            end;
        end;

        u45.Visible = v52;
        TweenService:Create(u45, TweenInfo_new_ret, {
            Size = UDim2.new(1, 0, 0, v52 and v51 and v51 or 0)
        }):Play();
    end;

    local v53 = {};
    local u54 = {};

    for i, v in ipairs(p46) do
        local Frame = Instance.new("Frame");
        Frame.Name = v;
        Frame.BackgroundTransparency = 1;
        Frame.Size = UDim2.new(1, 0, 0, 0);
        Frame.LayoutOrder = i + 1;
        Frame.Visible = false;
        Frame.ClipsDescendants = true;
        Frame.Parent = u45;
        local UIListLayout = Instance.new("UIListLayout");
        UIListLayout.SortOrder = Enum.SortOrder.LayoutOrder;
        UIListLayout.Padding = UDim.new(0, 2);
        UIListLayout.Parent = Frame;
        local TextButton = Instance.new("TextButton");
        TextButton.Name = "SubTitle";
        TextButton.BackgroundTransparency = 1;
        TextButton.AutoButtonColor = false;
        TextButton.Size = UDim2.new(1, 0, 0, 16);
        TextButton.LayoutOrder = 1;
        TextButton.Font = Enum.Font.Arcade;
        TextButton.TextScaled = true;
        TextButton.TextXAlignment = Enum.TextXAlignment.Left;
        TextButton.Text = "  ▼ " .. v;
        TextButton.TextColor3 = p47[v];
        TextButton.TextTransparency = 0.15;
        TextButton.Parent = Frame;
        local u55, u56 = makeGridContainer(Frame, 2);
        v53[v] = u55;
        table.insert(u49, Frame);

        local function onContent() -- Line: 434
            -- upvalues: u56 (copy), u55 (copy), u54 (copy), v (copy), u14 (ref), TextButton (copy), Frame (copy), recomputeTabHeight (copy)
            local Y = u56.AbsoluteContentSize.Y;
            local v57 = false;

            for _, child in ipairs(u55:GetChildren()) do
                if child.Name == "ItemFrame" and child.Visible then
                    v57 = true;
                    break;
                end;
            end;

            local v58 = u54[v] and u14 == "";
            TextButton.Text = "  " .. (v58 and "▶" or "▼") .. " " .. v;
            u55.Visible = not v58;
            local v59 = v57 and not v58 and (Y + 8 or 0) or 0;
            u55.Size = UDim2.new(1, 0, 0, v59);
            Frame.Visible = v57;
            Frame.Size = UDim2.new(1, 0, 0, v57 and 18 + v59 or 0);
            recomputeTabHeight();
        end;

        u42[u55] = {
            grid = u56,
            onContent = onContent
        };
        u56:GetPropertyChangedSignal("AbsoluteContentSize"):Connect(onContent);
        TextButton.Activated:Connect(function() -- Line: 451
            -- upvalues: u54 (copy), v (copy), onContent (copy)
            u54[v] = not u54[v];
            onContent();
        end);
    end;

    return v53;
end;

local u60 = buildSubSectionedTab(SkillsTab, { "Melee", "Rush", "Blasts", "Wave", "Explosion", "Misc", "Race Skills" }, u39);
local u61 = buildSubSectionedTab(ItemTab, { "Consumables", "Dragonballs", "Training", "Technology", "Misc" }, v41);

local function updateCellSizes() -- Line: 463
    -- upvalues: ScrollingFrame (copy), u42 (copy)
    local math_floor_ret = math.floor((ScrollingFrame.AbsoluteSize.X - 12 - 8 - 40) / 6);

    if math_floor_ret < 8 then
        return;
    end;

    for _, v in pairs(u42) do
        v.grid.CellSize = UDim2.fromOffset(math_floor_ret, math_floor_ret);
        v.grid.CellPadding = UDim2.fromOffset(8, 8);
        v.onContent();
    end;
end;

updateCellSizes();
ScrollingFrame:GetPropertyChangedSignal("AbsoluteSize"):Connect(updateCellSizes);
local TextBox = Instance.new("TextBox");
TextBox.Name = "SearchBar";
TextBox.AnchorPoint = Vector2.new(0.5, 1);
TextBox.Position = UDim2.new(0.5, 0, 0, -6);
TextBox.Size = UDim2.new(0.6, 0, 0, 26);
TextBox.BackgroundColor3 = Color3.fromRGB(18, 18, 18);
TextBox.BackgroundTransparency = 0.2;
TextBox.Font = Enum.Font.Arcade;
TextBox.PlaceholderText = "Search...";
TextBox.PlaceholderColor3 = Color3.fromRGB(150, 150, 150);
TextBox.Text = "";
TextBox.TextColor3 = Color3.fromRGB(255, 255, 255);
TextBox.TextSize = 16;
TextBox.ClearTextOnFocus = false;
TextBox.Parent = Space;
local UICorner = Instance.new("UICorner");
UICorner.CornerRadius = UDim.new(0, 6);
UICorner.Parent = TextBox;
local UIStroke = Instance.new("UIStroke");
UIStroke.Color = Color3.fromRGB(255, 255, 255);
UIStroke.Transparency = 0.6;
UIStroke.Parent = TextBox;

local function applyFilter() -- Line: 504
    -- upvalues: u7 (copy), frameMatchesFilter (copy), u42 (copy)
    for i, v in pairs(u7) do
        local v62;

        if v.Parent == nil then
            v62 = false;
        else
            v62 = v.Parent.Name == "ItemContainer";
        end;

        if v62 then
            v.Visible = frameMatchesFilter(i, v.Parent.Parent.Name);
        end;
    end;

    for _, v in pairs(u42) do
        v.onContent();
    end;
end;

TextBox:GetPropertyChangedSignal("Text"):Connect(function() -- Line: 516
    -- upvalues: u14 (ref), TextBox (copy), applyFilter (copy)
    u14 = TextBox.Text:lower();
    applyFilter();
end);

local function findTool(p63: string) -- Line: 522
    -- upvalues: Backpack (ref), LocalPlayer (copy)
    local v64 = Backpack:FindFirstChild(p63);

    if v64 and v64:IsA("Tool") then
        return v64;
    end;

    local Character = LocalPlayer.Character;

    if Character then
        Character = Character:FindFirstChild(p63);
    end;

    if Character and Character:IsA("Tool") then
        return Character;
    end;

    return nil;
end;

local function unequipTool() -- Line: 535
    -- upvalues: clearKeyColors (copy), LocalPlayer (copy), u8 (ref)
    clearKeyColors();
    (LocalPlayer.Character or LocalPlayer.CharacterAdded:Wait()):WaitForChild("Humanoid"):UnequipTools();
    u8 = "";
end;

local function equipTool(p65: userdata, p66: string) -- Line: 542
    -- upvalues: LocalPlayer (copy), u6 (ref), u8 (ref), InventoryRemote (copy)
    (LocalPlayer.Character or LocalPlayer.CharacterAdded:Wait()):WaitForChild("Humanoid"):UnequipTools();
    u6 = p66;
    u8 = p65.ItemName.Text;
    InventoryRemote:FireServer({
        Action = "Equip",
        ToolName = u8
    });
end;

local function homeContainerFor(p67: userdata?) -- Line: 558
    -- upvalues: u60 (copy), u61 (copy)
    local v68;

    if p67 then
        if p67:FindFirstChild("Skill") then
            v68 = true;
        else
            local Attribute = p67:GetAttribute("SkillName");

            if Attribute == nil then
                v68 = false;
            else
                v68 = Attribute ~= "";
            end;
        end;
    else
        v68 = false;
    end;

    if v68 then
        return u60[p67:GetAttribute("AttackType")] or u60.Misc;
    end;

    if p67 then
        p67 = p67:GetAttribute("ItemCategory");
    end;

    return u61[p67] or u61.Misc;
end;

local function parentToInventory(p69: userdata) -- Line: 568
    -- upvalues: Backpack (ref), LocalPlayer (copy), u60 (copy), u61 (copy), frameMatchesFilter (copy), refreshFrameScale (copy)
    p69.Number.Visible = false;
    local Text = p69.ItemName.Text;
    local v70 = Backpack:FindFirstChild(Text);

    if not (v70 and v70:IsA("Tool")) then
        v70 = LocalPlayer.Character;

        if v70 then
            v70 = v70:FindFirstChild(Text);
        end;

        if not (v70 and v70:IsA("Tool")) then
            v70 = nil;
        end;
    end;

    local v71;

    if v70 then
        if v70:FindFirstChild("Skill") then
            v71 = true;
        else
            local Attribute = v70:GetAttribute("SkillName");

            if Attribute == nil then
                v71 = false;
            else
                v71 = Attribute ~= "";
            end;
        end;
    else
        v71 = false;
    end;

    local v72;

    if v71 then
        v72 = u60[v70:GetAttribute("AttackType")] or u60.Misc;
    else
        if v70 then
            v70 = v70:GetAttribute("ItemCategory");
        end;

        v72 = u61[v70] or u61.Misc;
    end;

    p69.Parent = v72;
    p69.Visible = frameMatchesFilter(p69.ItemName.Text, p69.Parent.Parent.Name);
    refreshFrameScale(p69);
end;

local function parentToSlot(p73: userdata, p74: userdata) -- Line: 578
    -- upvalues: Backpack (ref), LocalPlayer (copy), u60 (copy), u61 (copy), frameMatchesFilter (copy), refreshFrameScale (copy), UDim2_new_ret (copy)
    for _, child in ipairs(p74:GetChildren()) do
        if child ~= p73 and (child.Name == "ItemFrame" and child:IsA("GuiObject")) then
            child.Number.Visible = false;
            local Text = child.ItemName.Text;
            local v75 = Backpack:FindFirstChild(Text);

            if not (v75 and v75:IsA("Tool")) then
                v75 = LocalPlayer.Character;

                if v75 then
                    v75 = v75:FindFirstChild(Text);
                end;

                if not (v75 and v75:IsA("Tool")) then
                    v75 = nil;
                end;
            end;

            local v76;

            if v75 then
                if v75:FindFirstChild("Skill") then
                    v76 = true;
                else
                    local Attribute = v75:GetAttribute("SkillName");

                    if Attribute == nil then
                        v76 = false;
                    else
                        v76 = Attribute ~= "";
                    end;
                end;
            else
                v76 = false;
            end;

            local v77;

            if v76 then
                v77 = u60[v75:GetAttribute("AttackType")] or u60.Misc;
            else
                if v75 then
                    v75 = v75:GetAttribute("ItemCategory");
                end;

                v77 = u61[v75] or u61.Misc;
            end;

            child.Parent = v77;
            child.Visible = frameMatchesFilter(child.ItemName.Text, child.Parent.Parent.Name);
            refreshFrameScale(child);
        end;
    end;

    p73.Parent = p74;
    p73.Visible = true;
    p73.Number.Visible = true;
    p73.Number.Text = p74.Name;
    p73.Size = UDim2_new_ret;
    p74.Visible = true;
    refreshFrameScale(p73);
end;

local function swapFrames(p78: userdata, p79: userdata, p80: userdata, p81) -- Line: 627
    -- upvalues: Backpack (ref), LocalPlayer (copy), u60 (copy), u61 (copy), frameMatchesFilter (copy), refreshFrameScale (copy), parentToSlot (copy), InventoryRemote (copy)
    if p78.Parent == p79.Parent then
        local LayoutOrder = p78.LayoutOrder;
        p78.LayoutOrder = p79.LayoutOrder;
        p79.LayoutOrder = LayoutOrder;

        return;
    end;

    local v82;

    if p78.Parent == nil then
        v82 = false;
    else
        v82 = p78.Parent.Name == "ItemContainer";
    end;

    local v83 = p80.Name == "ItemContainer";
    local Parent2 = p78.Parent;
    local Text = p78.Number.Text;
    local Size = p78.Size;

    if v83 then
        p78.Number.Visible = false;
        local Text2 = p78.ItemName.Text;
        local v84 = Backpack:FindFirstChild(Text2);

        if not (v84 and v84:IsA("Tool")) then
            v84 = LocalPlayer.Character;

            if v84 then
                v84 = v84:FindFirstChild(Text2);
            end;

            if not (v84 and v84:IsA("Tool")) then
                v84 = nil;
            end;
        end;

        local v85;

        if v84 then
            if v84:FindFirstChild("Skill") then
                v85 = true;
            else
                local Attribute = v84:GetAttribute("SkillName");

                if Attribute == nil then
                    v85 = false;
                else
                    v85 = Attribute ~= "";
                end;
            end;
        else
            v85 = false;
        end;

        local v86;

        if v85 then
            v86 = u60[v84:GetAttribute("AttackType")] or u60.Misc;
        else
            if v84 then
                v84 = v84:GetAttribute("ItemCategory");
            end;

            v86 = u61[v84] or u61.Misc;
        end;

        p78.Parent = v86;
        p78.Visible = frameMatchesFilter(p78.ItemName.Text, p78.Parent.Parent.Name);
        refreshFrameScale(p78);
        p78.Size = p81;
    else
        parentToSlot(p78, p80);
        p78.Size = p81;
    end;

    if v82 then
        p79.Number.Visible = false;
        local Text2 = p79.ItemName.Text;
        local v87 = Backpack:FindFirstChild(Text2);

        if not (v87 and v87:IsA("Tool")) then
            v87 = LocalPlayer.Character;

            if v87 then
                v87 = v87:FindFirstChild(Text2);
            end;

            if not (v87 and v87:IsA("Tool")) then
                v87 = nil;
            end;
        end;

        local v88;

        if v87 then
            if v87:FindFirstChild("Skill") then
                v88 = true;
            else
                local Attribute = v87:GetAttribute("SkillName");

                if Attribute == nil then
                    v88 = false;
                else
                    v88 = Attribute ~= "";
                end;
            end;
        else
            v88 = false;
        end;

        local v89;

        if v88 then
            v89 = u60[v87:GetAttribute("AttackType")] or u60.Misc;
        else
            if v87 then
                v87 = v87:GetAttribute("ItemCategory");
            end;

            v89 = u61[v87] or u61.Misc;
        end;

        p79.Parent = v89;
        p79.Visible = frameMatchesFilter(p79.ItemName.Text, p79.Parent.Parent.Name);
        refreshFrameScale(p79);
        p79.Size = Size;
    else
        parentToSlot(p79, Parent2);
        p79.Size = Size;
    end;

    if v82 then
        InventoryRemote:FireServer({
            Action = "Set",
            Tool_Slot = p80.Name,
            ToolName = p78.ItemName.Text
        });

        return;
    end;

    if v83 then
        InventoryRemote:FireServer({
            Action = "Set",
            Tool_Slot = Text,
            ToolName = p79.ItemName.Text
        });

        return;
    end;

    InventoryRemote:FireServer({
        Action = "Swap",
        Tool_Slot = p80.Name,
        Old_Tool_Slot = Text,
        ToolName = p78.ItemName.Text,
        Old_Tool_Name = p79.ItemName.Text
    });
end;

local u90 = Parent;

local function colorItemFrame(p91: userdata?, p92: userdata) -- Line: 284
    -- upvalues: u39 (copy), u40 (copy)
    local v93;

    if p91 then
        if p91:FindFirstChild("Skill") then
            v93 = true;
        else
            local Attribute = p91:GetAttribute("SkillName");

            if Attribute == nil then
                v93 = false;
            else
                v93 = Attribute ~= "";
            end;
        end;
    else
        v93 = false;
    end;

    if not v93 then
        return;
    end;

    local v94 = u39[p91:GetAttribute("AttackType")] or Color3.fromRGB(255, 0, 0);

    for _, v in ipairs(u40) do
        if p91:FindFirstChild(v[1]) then
            v94 = v[2];
            break;
        end;
    end;

    p92.ImageColor3 = v94;
end;

local function firstOpenSlot() -- Line: 615
    -- upvalues: u5 (copy)
    for _, v in ipairs({ "1", "2", "3", "4", "5", "6", "7", "8", "9", "0" }) do
        local v95 = u5[v];

        if v95 and not v95:FindFirstChild("ItemFrame") then
            return v95;
        end;
    end;

    return nil;
end;

while Parent and not Parent:IsA("ScreenGui") do
    Parent = Parent.Parent;
end;

local Frame = Instance.new("Frame");
Frame.Name = "DragLayer";
Frame.BackgroundTransparency = 1;
Frame.Size = UDim2.new(1, 0, 1, 0);
Frame.ZIndex = 100;
Frame.Parent = Parent;
local u96 = Parent and (Parent.IgnoreGuiInset and Vector2.zero) or GuiService:GetGuiInset();
local u97 = nil;
local u98 = nil;
local u99 = nil;
local u100 = nil;

local function dragPointer() -- Line: 733
    -- upvalues: u97 (ref), UserInputService (copy)
    if not (u97 and (u97.isTouch and u97.input)) then
        return UserInputService:GetMouseLocation();
    end;

    local Position = u97.input.Position;

    return Vector2.new(Position.X, Position.Y) + u97.touchOffset;
end;

local function clearHighlight() -- Line: 741
    -- upvalues: u97 (ref)
    if u97 and u97.highlightStroke then
        u97.highlightStroke:Destroy();
        u97.highlightStroke = nil;
        u97.highlightTarget = nil;
    end;
end;

local function setHighlight(p101: userdata) -- Line: 749
    -- upvalues: u97 (ref), Color3_fromRGB_ret3 (copy)
    if not u97 or u97.highlightTarget == p101 then
        return;
    end;

    if u97 and u97.highlightStroke then
        u97.highlightStroke:Destroy();
        u97.highlightStroke = nil;
        u97.highlightTarget = nil;
    end;

    local UIStroke2 = Instance.new("UIStroke");
    UIStroke2.Color = Color3_fromRGB_ret3;
    UIStroke2.Thickness = 3;
    UIStroke2.Parent = p101;
    u97.highlightStroke = UIStroke2;
    u97.highlightTarget = p101;
end;

local function dragHitPoint() -- Line: 781
    -- upvalues: u97 (ref), UserInputService (copy)
    local v102;

    if u97 and (u97.isTouch and u97.input) then
        local Position = u97.input.Position;
        v102 = Vector2.new(Position.X, Position.Y) + u97.touchOffset;
    else
        v102 = UserInputService:GetMouseLocation();
    end;

    return v102.X, v102.Y;
end;

local function dropTargetAt(p103: number, p104: number) -- Line: 786
    -- upvalues: LocalPlayer (copy), u97 (ref), u4 (copy), RegSlots (copy)
    local PlayerGui = LocalPlayer:WaitForChild("PlayerGui");

    for _, v in ipairs(PlayerGui:GetGuiObjectsAtPosition(p103, p104)) do
        if not u97 or v ~= u97.proxy then
            if v.Name == "ItemFrame" then
                if v ~= (u97 and u97.source) then
                    return "item", v;
                end;
            end;

            if u4[v.Name] and (v:IsA("Frame") and v.Parent == RegSlots) then
                return "slot", v;
            end;

            if v.Name == "ScrollingFrame" or v.Name == "ItemContainer" then
                return "panel", v;
            end;
        end;
    end;

    return nil, nil;
end;

local function positionProxy() -- Line: 801
    -- upvalues: u97 (ref), UserInputService (copy), u96 (copy)
    local v105;

    if u97 and (u97.isTouch and u97.input) then
        local Position = u97.input.Position;
        v105 = Vector2.new(Position.X, Position.Y) + u97.touchOffset;
    else
        v105 = UserInputService:GetMouseLocation();
    end;

    u97.proxy.Position = UDim2.fromOffset(v105.X - u96.X, v105.Y - u96.Y - 20);
end;

local function beginDrag(p106: userdata, p107: userdata?) -- Line: 823
    -- upvalues: u97 (ref), GuiService (copy), Frame (copy), UserInputService (copy), u5 (copy), Space (copy), u9 (ref), RegSlots (copy), u99 (ref), u96 (copy)
    if u97 then
        return;
    end;

    local v108;

    if p107 == nil then
        v108 = false;
    else
        v108 = p107.UserInputType == Enum.UserInputType.Touch;
    end;

    local Vector2_zero = Vector2.zero;

    if v108 then
        local Position = p107.Position;
        Vector2_zero = GuiService:GetGuiInset();
        local v109 = p106.AbsolutePosition.Y - 6;
        local v110 = p106.AbsolutePosition.Y + p106.AbsoluteSize.Y + 6;

        if v109 <= Position.Y and Position.Y <= v110 then
            Vector2_zero = Vector2.zero;
        elseif v109 > Position.Y + Vector2_zero.Y or Position.Y + Vector2_zero.Y > v110 then
            Vector2_zero = Vector2.zero;
        end;
    end;

    local v111 = p106:Clone();
    v111.Name = "DragProxy";
    v111.AnchorPoint = Vector2.new(0.5, 0.5);
    v111.Size = UDim2.fromOffset(p106.AbsoluteSize.X, p106.AbsoluteSize.Y);
    v111.ZIndex = 101;

    for _, descendant in ipairs(v111:GetDescendants()) do
        if descendant:IsA("GuiObject") then
            descendant.ZIndex = 101;
        end;
    end;

    v111.Parent = Frame;
    p106.ImageTransparency = 0.65;
    u97 = {
        moved = false,
        source = p106,
        proxy = v111,
        previousParent = p106.Parent,
        previousSize = p106.Size,
        input = p107,
        isTouch = v108,
        touchOffset = Vector2_zero,
        startPos = v108 and Vector2.new(p107.Position.X, p107.Position.Y) + Vector2_zero or UserInputService:GetMouseLocation(),
        slotVisibility = {}
    };

    for _, v in pairs(u5) do
        u97.slotVisibility[v] = v.Visible;
        v.Visible = true;
    end;

    if v108 then
        Space.ScrollingFrame.ScrollingEnabled = false;
        u97.scrollLocked = true;
    end;

    if v108 and not (u9 or (not p106.Parent or p106.Parent.Parent ~= RegSlots)) then
        u99();
        u97.autoOpened = true;
    end;

    local v112;

    if u97 and (u97.isTouch and u97.input) then
        local Position = u97.input.Position;
        v112 = Vector2.new(Position.X, Position.Y) + u97.touchOffset;
    else
        v112 = UserInputService:GetMouseLocation();
    end;

    u97.proxy.Position = UDim2.fromOffset(v112.X - u96.X, v112.Y - u96.Y - 20);
end;

local function endDrag() -- Line: 907
    -- upvalues: u97 (ref), dropTargetAt (copy), dragHitPoint (copy), Space (copy), refreshFrameScale (copy), u100 (ref), Backpack (ref), LocalPlayer (copy), u60 (copy), u61 (copy), frameMatchesFilter (copy), swapFrames (copy), parentToSlot (copy), InventoryRemote (copy)
    if not u97 then
        return;
    end;

    local source = u97.source;
    local previousParent = u97.previousParent;
    local previousSize = u97.previousSize;
    local moved = u97.moved;
    local v113, v114 = dropTargetAt(dragHitPoint());
    local slotVisibility = u97.slotVisibility;
    local scrollLocked = u97.scrollLocked;
    local autoOpened = u97.autoOpened;

    if u97 and u97.highlightStroke then
        u97.highlightStroke:Destroy();
        u97.highlightStroke = nil;
        u97.highlightTarget = nil;
    end;

    u97.proxy:Destroy();
    source.ImageTransparency = 0;
    u97 = nil;

    if scrollLocked then
        Space.ScrollingFrame.ScrollingEnabled = true;
    end;

    refreshFrameScale(source);

    if slotVisibility then
        for i, v in pairs(slotVisibility) do
            if i.Parent then
                i.Visible = v or i:FindFirstChild("ItemFrame") ~= nil;
            end;
        end;
    end;

    if not moved then
        if autoOpened then
            u100();
        end;

        return;
    end;

    if v113 == "item" then
        local v115;

        if v114.Parent == nil then
            v115 = false;
        else
            v115 = v114.Parent.Name == "ItemContainer";
        end;

        if v115 then
            local v116;

            if source.Parent == nil then
                v116 = false;
            else
                v116 = source.Parent.Name == "ItemContainer";
            end;

            if v116 and v114.Parent ~= source.Parent then
                source.Number.Visible = false;
                local Text = source.ItemName.Text;
                local v117 = Backpack:FindFirstChild(Text);

                if not (v117 and v117:IsA("Tool")) then
                    v117 = LocalPlayer.Character;

                    if v117 then
                        v117 = v117:FindFirstChild(Text);
                    end;

                    if not (v117 and v117:IsA("Tool")) then
                        v117 = nil;
                    end;
                end;

                local v118;

                if v117 then
                    if v117:FindFirstChild("Skill") then
                        v118 = true;
                    else
                        local Attribute = v117:GetAttribute("SkillName");

                        if Attribute == nil then
                            v118 = false;
                        else
                            v118 = Attribute ~= "";
                        end;
                    end;
                else
                    v118 = false;
                end;

                local v119;

                if v118 then
                    v119 = u60[v117:GetAttribute("AttackType")] or u60.Misc;
                else
                    if v117 then
                        v117 = v117:GetAttribute("ItemCategory");
                    end;

                    v119 = u61[v117] or u61.Misc;
                end;

                source.Parent = v119;
                source.Visible = frameMatchesFilter(source.ItemName.Text, source.Parent.Parent.Name);
                refreshFrameScale(source);
            else
                swapFrames(v114, source, previousParent, previousSize);
            end;
        else
            swapFrames(v114, source, previousParent, previousSize);
        end;
    elseif v113 == "slot" then
        local ItemFrame = v114:FindFirstChild("ItemFrame");

        if ItemFrame and ItemFrame ~= source then
            swapFrames(ItemFrame, source, previousParent, previousSize);
        elseif not ItemFrame then
            parentToSlot(source, v114);
            InventoryRemote:FireServer({
                Action = "Set",
                Tool_Slot = v114.Name,
                ToolName = source.ItemName.Text
            });
        end;
    elseif v113 == "panel" then
        if previousParent:FindFirstAncestor("RegSlots") then
            source.Number.Visible = false;
            local Text = source.ItemName.Text;
            local v120 = Backpack:FindFirstChild(Text);

            if not (v120 and v120:IsA("Tool")) then
                v120 = LocalPlayer.Character;

                if v120 then
                    v120 = v120:FindFirstChild(Text);
                end;

                if not (v120 and v120:IsA("Tool")) then
                    v120 = nil;
                end;
            end;

            local v121;

            if v120 then
                if v120:FindFirstChild("Skill") then
                    v121 = true;
                else
                    local Attribute = v120:GetAttribute("SkillName");

                    if Attribute == nil then
                        v121 = false;
                    else
                        v121 = Attribute ~= "";
                    end;
                end;
            else
                v121 = false;
            end;

            local v122;

            if v121 then
                v122 = u60[v120:GetAttribute("AttackType")] or u60.Misc;
            else
                if v120 then
                    v120 = v120:GetAttribute("ItemCategory");
                end;

                v122 = u61[v120] or u61.Misc;
            end;

            source.Parent = v122;
            source.Visible = frameMatchesFilter(source.ItemName.Text, source.Parent.Parent.Name);
            refreshFrameScale(source);
            InventoryRemote:FireServer({
                Action = "Set",
                ToolName = "",
                Tool_Slot = previousParent.Name
            });
        else
            local v123;

            if source.Parent == nil then
                v123 = false;
            else
                v123 = source.Parent.Name == "ItemContainer";
            end;

            if not v123 then
                source.Number.Visible = false;
                local Text = source.ItemName.Text;
                local v124 = Backpack:FindFirstChild(Text);

                if not (v124 and v124:IsA("Tool")) then
                    v124 = LocalPlayer.Character;

                    if v124 then
                        v124 = v124:FindFirstChild(Text);
                    end;

                    if not (v124 and v124:IsA("Tool")) then
                        v124 = nil;
                    end;
                end;

                local v125;

                if v124 then
                    if v124:FindFirstChild("Skill") then
                        v125 = true;
                    else
                        local Attribute = v124:GetAttribute("SkillName");

                        if Attribute == nil then
                            v125 = false;
                        else
                            v125 = Attribute ~= "";
                        end;
                    end;
                else
                    v125 = false;
                end;

                local v126;

                if v125 then
                    v126 = u60[v124:GetAttribute("AttackType")] or u60.Misc;
                else
                    if v124 then
                        v124 = v124:GetAttribute("ItemCategory");
                    end;

                    v126 = u61[v124] or u61.Misc;
                end;

                source.Parent = v126;
                source.Visible = frameMatchesFilter(source.ItemName.Text, source.Parent.Parent.Name);
                refreshFrameScale(source);
            end;
        end;
    end;

    if autoOpened then
        u100();
    end;
end;

local u127 = nil;

local function hotbarSlotOf(p128: userdata) -- Line: 1011
    -- upvalues: RegSlots (copy), u4 (copy)
    local Parent2 = p128.Parent;

    if Parent2 and (Parent2.Parent == RegSlots and u4[Parent2.Name]) then
        return Parent2;
    end;

    return nil;
end;

local function cancelTouchPress() -- Line: 1020
    -- upvalues: u127 (ref), refreshFrameScale (copy)
    local v129 = u127;

    if not v129 then
        return;
    end;

    u127 = nil;
    refreshFrameScale(v129.frame);
end;

local function touchHoldBegin(u130) -- Line: 1027
    -- upvalues: TweenService (copy), u127 (ref), refreshFrameScale (copy), beginDrag (copy)
    local frame = u130.frame;
    local v131 = frame:FindFirstChildOfClass("UIScale");

    if not v131 then
        v131 = Instance.new("UIScale");
        v131.Parent = frame;
    end;

    TweenService:Create(v131, TweenInfo.new(0.3, Enum.EasingStyle.Linear), {
        Scale = 1.3
    }):Play();
    task.delay(0.3, function() -- Line: 1031
        -- upvalues: u127 (ref), u130 (copy), refreshFrameScale (ref), beginDrag (ref)
        if u127 ~= u130 then
            return;
        end;

        u127 = nil;
        local UserInputState = u130.input.UserInputState;

        if UserInputState == Enum.UserInputState.End or (UserInputState == Enum.UserInputState.Cancel or not u130.frame.Parent) then
            refreshFrameScale(u130.frame);

            return;
        end;

        beginDrag(u130.frame, u130.input);
    end);
end;

local function beginTouchPress(p132: userdata, p133: userdata) -- Line: 1044
    -- upvalues: u97 (ref), u127 (ref), touchHoldBegin (copy)
    if u97 or u127 then
        return;
    end;

    local v134 = {
        frame = p132,
        input = p133,
        startPos = Vector2.new(p133.Position.X, p133.Position.Y)
    };
    u127 = v134;
    touchHoldBegin(v134);
end;

local function endTouchPress(p135) -- Line: 1056
    -- upvalues: u127 (ref), refreshFrameScale (copy), RegSlots (copy), u4 (copy), Backpack (ref), LocalPlayer (copy), u98 (ref)
    if u127 ~= p135 then
        return;
    end;

    u127 = nil;
    refreshFrameScale(p135.frame);

    if not p135.frame.Parent then
        return;
    end;

    local Parent2 = p135.frame.Parent;

    if not (Parent2 and (Parent2.Parent == RegSlots and u4[Parent2.Name])) then
        Parent2 = nil;
    end;

    if not Parent2 then
        return;
    end;

    local Text = p135.frame.ItemName.Text;
    local v136 = Backpack:FindFirstChild(Text);

    if not (v136 and v136:IsA("Tool")) then
        v136 = LocalPlayer.Character;

        if v136 then
            v136 = v136:FindFirstChild(Text);
        end;

        if not (v136 and v136:IsA("Tool")) then
            v136 = nil;
        end;
    end;

    if v136 then
        v136.ManualActivationOnly = false;
    end;

    u98(Parent2.Name);
end;

UserInputService.InputChanged:Connect(function(p137) -- Line: 1075
    -- upvalues: u127 (ref), refreshFrameScale (copy), u97 (ref), UserInputService (copy), u96 (copy), dropTargetAt (copy), dragHitPoint (copy), Color3_fromRGB_ret3 (copy)
    if u127 and p137 == u127.input then
        if (Vector2.new(p137.Position.X, p137.Position.Y) - u127.startPos).Magnitude >= 14 then
            local v138 = u127;

            if not v138 then
                return;
            end;

            u127 = nil;
            refreshFrameScale(v138.frame);
        end;

        return;
    end;

    if not u97 then
        return;
    end;

    if u97.isTouch then
        if p137 ~= u97.input then
            return;
        end;
    elseif p137.UserInputType ~= Enum.UserInputType.MouseMovement then
        return;
    end;

    local v139;

    if u97 and (u97.isTouch and u97.input) then
        local Position = u97.input.Position;
        v139 = Vector2.new(Position.X, Position.Y) + u97.touchOffset;
    else
        v139 = UserInputService:GetMouseLocation();
    end;

    u97.proxy.Position = UDim2.fromOffset(v139.X - u96.X, v139.Y - u96.Y - 20);
    local v140;

    if u97 and (u97.isTouch and u97.input) then
        local Position = u97.input.Position;
        v140 = Vector2.new(Position.X, Position.Y) + u97.touchOffset;
    else
        v140 = UserInputService:GetMouseLocation();
    end;

    if not u97.moved and (v140 - u97.startPos).Magnitude >= 6 then
        u97.moved = true;
    end;

    local v141, v142 = dropTargetAt(dragHitPoint());

    if u97.moved and (v141 == "item" or v141 == "slot") then
        if u97 then
            if u97.highlightTarget == v142 then
                return;
            end;

            if u97 and u97.highlightStroke then
                u97.highlightStroke:Destroy();
                u97.highlightStroke = nil;
                u97.highlightTarget = nil;
            end;

            local UIStroke2 = Instance.new("UIStroke");
            UIStroke2.Color = Color3_fromRGB_ret3;
            UIStroke2.Thickness = 3;
            UIStroke2.Parent = v142;
            u97.highlightStroke = UIStroke2;
            u97.highlightTarget = v142;
        end;
    elseif u97 and u97.highlightStroke then
        u97.highlightStroke:Destroy();
        u97.highlightStroke = nil;
        u97.highlightTarget = nil;
    end;
end);
UserInputService.InputEnded:Connect(function(p143) -- Line: 1109
    -- upvalues: u127 (ref), endTouchPress (copy), u97 (ref), endDrag (copy)
    if u127 and (p143 == u127.input or (u127.input.UserInputState == Enum.UserInputState.End or u127.input.UserInputState == Enum.UserInputState.Cancel)) then
        endTouchPress(u127);
    end;

    if not u97 then
        return;
    end;

    if u97.isTouch then
        local input = u97.input;

        if p143 == input or input and (input.UserInputState == Enum.UserInputState.End or input.UserInputState == Enum.UserInputState.Cancel) then
            endDrag();
        end;
    elseif p143.UserInputType == Enum.UserInputType.MouseButton1 then
        endDrag();
    end;
end);
game:GetService("RunService").Heartbeat:Connect(function() -- Line: 1134
    -- upvalues: u127 (ref), endTouchPress (copy), u97 (ref), endDrag (copy)
    if u127 then
        local UserInputState = u127.input.UserInputState;

        if UserInputState == Enum.UserInputState.End or UserInputState == Enum.UserInputState.Cancel then
            endTouchPress(u127);
        end;
    end;

    if not (u97 and (u97.isTouch and u97.input)) then
        return;
    end;

    local UserInputState = u97.input.UserInputState;

    if UserInputState == Enum.UserInputState.End or UserInputState == Enum.UserInputState.Cancel then
        endDrag();
    end;
end);
local u144 = nil;

local function countItem(p145: string, p146: userdata?) -- Line: 1157
    -- upvalues: LocalPlayer (copy), Backpack (ref), u7 (copy), u144 (ref), colorItemFrame (copy), Color3_fromRGB_ret (copy), u8 (ref), u6 (ref), u10 (ref), Color3_fromRGB_ret2 (copy), refreshFrameScale (copy)
    local v147 = LocalPlayer.Character or LocalPlayer.CharacterAdded:Wait();
    local v148 = 0;

    for _, child in ipairs(Backpack:GetChildren()) do
        if child:IsA("Tool") and child.Name == p145 then
            v148 = v148 + 1;
        end;
    end;

    for _, child in ipairs(v147:GetChildren()) do
        if child:IsA("Tool") and child.Name == p145 then
            v148 = v148 + 1;
        end;
    end;

    local v149 = u7[p145];

    if not v149 then
        return v148;
    end;

    if v148 == 0 then
        u144(p145);

        return 0;
    end;

    if v148 > 1 then
        v149.Amount.Visible = true;
        v149.Amount.Text = "x" .. v148;
    else
        v149.Amount.Visible = false;
        colorItemFrame(p146, v149);
    end;

    local v150;

    if v149.Parent == nil then
        v150 = false;
    else
        v150 = v149.Parent.Name == "ItemContainer";
    end;

    if not v150 then
        if v147:FindFirstChild(p145) then
            v149.Number.TextColor3 = Color3_fromRGB_ret;
            u8 = p145;
            u6 = v149.Number.Text;
            u10 = u6;
        else
            v149.Number.TextColor3 = Color3_fromRGB_ret2;
        end;

        refreshFrameScale(v149);
    end;

    return v148;
end;

u144 = function(p151: string) -- Line: 1200
    -- upvalues: u7 (copy), u4 (copy), LocalPlayer (copy), InventoryRemote (copy), u9 (ref)
    local v152 = u7[p151];

    if not v152 then
        return;
    end;

    u7[p151] = nil;
    local Parent2 = v152.Parent;
    v152:Destroy();

    if Parent2 and u4[Parent2.Name] then
        local Character = LocalPlayer.Character;
        local v153;

        if Character then
            v153 = Character:FindFirstChild("Humanoid");
        else
            v153 = Character;
        end;

        if Character and (Character.Parent and (v153 and (v153.Health > 0 and not Character:FindFirstChild("Dead")))) then
            InventoryRemote:FireServer({
                Action = "Set",
                ToolName = "",
                Tool_Slot = Parent2.Name
            });
        end;

        if not u9 then
            Parent2.Visible = false;
        end;
    end;
end;

local function addSlot(p154: string, p155: string?, p156: userdata?, p157: boolean?) -- Line: 1244
    -- upvalues: u7 (copy), unequipTool (copy), u5 (copy), parentToSlot (copy), Backpack (ref), LocalPlayer (copy), countItem (copy), u13 (ref), colorItemFrame (copy), Platform (copy), UserInputService (copy), beginTouchPress (copy), beginDrag (copy), u1 (copy), u28 (ref), refreshFrameScale (copy), firstOpenSlot (copy), Color3_fromRGB_ret (copy), InventoryRemote (copy), u60 (copy), u61 (copy), frameMatchesFilter (copy)
    local v158 = u7[p154];

    if v158 then
        if p156 then
            local v159;

            if v158.Parent == nil then
                v159 = false;
            else
                v159 = v158.Parent.Name == "ItemContainer";
            end;

            if v159 then
                task.defer(unequipTool);
            end;
        end;

        if p155 then
            local v160 = u5[p155];

            if v160 and v158.Parent ~= v160 then
                parentToSlot(v158, v160);
            end;
        end;

        local v161 = Backpack:FindFirstChild(p154);

        if not (v161 and v161:IsA("Tool")) then
            v161 = LocalPlayer.Character;

            if v161 then
                v161 = v161:FindFirstChild(p154);
            end;

            if not (v161 and v161:IsA("Tool")) then
                v161 = nil;
            end;
        end;

        if v161 then
            countItem(p154, p156);
        end;

        return;
    end;

    local u162 = script:WaitForChild("ItemFrame"):Clone();

    for _, descendant in ipairs(u162:GetDescendants()) do
        if descendant:IsA("GuiObject") then
            descendant.Active = false;
        end;
    end;

    u162.ItemName.Text = p154;
    u162.Amount.Text = "x1";
    u162.Number.Visible = true;
    u13 = u13 + 1;
    u162.LayoutOrder = u13;
    u7[p154] = u162;
    colorItemFrame(p156, u162);
    u162.InputBegan:Connect(function(p163) -- Line: 1319
        -- upvalues: Platform (ref), UserInputService (ref), beginTouchPress (ref), u162 (copy), beginDrag (ref)
        local UserInputType = p163.UserInputType;

        if UserInputType ~= Enum.UserInputType.MouseButton1 and UserInputType ~= Enum.UserInputType.Touch then
            return;
        end;

        if Platform.IsGamepadInput(UserInputService:GetLastInputType()) then
            return;
        end;

        if UserInputType == Enum.UserInputType.Touch then
            beginTouchPress(u162, p163);

            return;
        end;

        beginDrag(u162, p163);
    end);

    if u1 then
        u162.Selectable = true;
    end;

    u162.MouseEnter:Connect(function() -- Line: 1335
        -- upvalues: u28 (ref), u162 (copy), refreshFrameScale (ref)
        u28 = u162;
        refreshFrameScale(u162);
    end);
    u162.MouseLeave:Connect(function() -- Line: 1339
        -- upvalues: u28 (ref), u162 (copy), refreshFrameScale (ref)
        if u28 == u162 then
            u28 = nil;
        end;

        refreshFrameScale(u162);
    end);

    if p155 and u5[p155] then
        parentToSlot(u162, u5[p155]);
    else
        local v164;

        if p157 then
            v164 = nil;
        else
            v164 = firstOpenSlot() or nil;
        end;

        if v164 then
            parentToSlot(u162, v164);
            local Character = LocalPlayer.Character;

            if p156 and (Character and p156.Parent == Character) then
                u162.Number.TextColor3 = Color3_fromRGB_ret;
            end;

            InventoryRemote:FireServer({
                Action = "Set",
                Tool_Slot = v164.Name,
                ToolName = p154
            });
        else
            u162.Number.Visible = false;
            local Text = u162.ItemName.Text;
            local v165 = Backpack:FindFirstChild(Text);

            if not (v165 and v165:IsA("Tool")) then
                v165 = LocalPlayer.Character;

                if v165 then
                    v165 = v165:FindFirstChild(Text);
                end;

                if not (v165 and v165:IsA("Tool")) then
                    v165 = nil;
                end;
            end;

            local v166;

            if v165 then
                if v165:FindFirstChild("Skill") then
                    v166 = true;
                else
                    local Attribute = v165:GetAttribute("SkillName");

                    if Attribute == nil then
                        v166 = false;
                    else
                        v166 = Attribute ~= "";
                    end;
                end;
            else
                v166 = false;
            end;

            local v167;

            if v166 then
                v167 = u60[v165:GetAttribute("AttackType")] or u60.Misc;
            else
                if v165 then
                    v165 = v165:GetAttribute("ItemCategory");
                end;

                v167 = u61[v165] or u61.Misc;
            end;

            u162.Parent = v167;
            u162.Visible = frameMatchesFilter(u162.ItemName.Text, u162.Parent.Parent.Name);
            refreshFrameScale(u162);
        end;
    end;

    local v168 = Backpack:FindFirstChild(p154);

    if not (v168 and v168:IsA("Tool")) then
        v168 = LocalPlayer.Character;

        if v168 then
            v168 = v168:FindFirstChild(p154);
        end;

        if not (v168 and v168:IsA("Tool")) then
            v168 = nil;
        end;
    end;

    if v168 then
        countItem(p154, p156);
    end;
end;

local Stats = StatFrame.Stats;
local StatList = StatFrame:FindFirstChild("StatList", true);
local Info = StatFrame:FindFirstChild("Info");
local InfoBox = Info:FindFirstChild("InfoBox");
local Lore = StatFrame:FindFirstChild("Lore");
local u169;

if Lore then
    u169 = Lore:FindFirstChild("LoreScroll");
else
    u169 = Lore;
end;

local ViewportFrame = Stats.ViewportFrame;
local LoreRequestData = require(ReplicatedStorage.Modules.Metadata.MiscData.LoreRequestData);
local Color3_fromRGB_ret4 = Color3.fromRGB(28, 28, 30);
local Color3_fromRGB_ret5 = Color3.fromRGB(44, 44, 45);
local Color3_fromRGB_ret6 = Color3.fromRGB(72, 160, 255);
local Color3_fromRGB_ret7 = Color3.fromRGB(216, 213, 205);
local Color3_fromRGB_ret8 = Color3.fromRGB(150, 148, 142);
local u170 = nil;
local u171 = nil;
local u172 = {};

local function reqStroke(p173, p174) -- Line: 1403
    local UIStroke2 = Instance.new("UIStroke");
    UIStroke2.Color = Color3.new(0, 0, 0);
    UIStroke2.Thickness = p174 or 1.5;
    UIStroke2.Parent = p173;

    return UIStroke2;
end;

local function reqText(p175) -- Line: 1411
    p175.TextStrokeColor3 = Color3.new(0, 0, 0);
    p175.TextStrokeTransparency = 0.5;

    return p175;
end;

local function buildRequestsTab() -- Line: 1417
    -- upvalues: u170 (ref), StatFrame (copy), Lore (copy), Color3_fromRGB_ret4 (copy), Color3_fromRGB_ret6 (copy), u171 (ref), Color3_fromRGB_ret5 (copy), Color3_fromRGB_ret8 (copy), LoreRequestData (copy), Color3_fromRGB_ret7 (copy), ServerRemote (copy), u172 (copy)
    if u170 then
        return;
    end;

    if not StatFrame.Tabs:FindFirstChild("RequestTab") then
        local v176 = StatFrame.Tabs.LoreTab:Clone();
        v176.Name = "RequestTab";
        v176.LayoutOrder = StatFrame.Tabs.LoreTab.LayoutOrder + 1;
        local v177 = v176:FindFirstChildWhichIsA("TextLabel");

        if v177 then
            v177.Text = "Requests";
        end;

        v176.Parent = StatFrame.Tabs;
    end;

    u170 = Instance.new("Frame");
    u170.Name = "Requests";
    u170.AnchorPoint = Lore.AnchorPoint;
    u170.Position = Lore.Position;
    u170.Size = Lore.Size;
    u170.BackgroundColor3 = Color3_fromRGB_ret4;
    u170.BorderSizePixel = 0;
    u170.Visible = false;
    u170.Parent = StatFrame;
    local UIStroke2 = Instance.new("UIStroke");
    UIStroke2.Color = Color3.new(0, 0, 0);
    UIStroke2.Thickness = 2;
    UIStroke2.Parent = u170;
    local TextLabel = Instance.new("TextLabel");
    TextLabel.BackgroundTransparency = 1;
    TextLabel.Position = UDim2.new(0, 12, 0, 6);
    TextLabel.Size = UDim2.new(0.6, 0, 0, 26);
    TextLabel.Font = Enum.Font.Arcade;
    TextLabel.TextScaled = true;
    TextLabel.TextColor3 = Color3_fromRGB_ret6;
    TextLabel.TextXAlignment = Enum.TextXAlignment.Left;
    TextLabel.Text = "LORE REQUESTS";
    TextLabel.Parent = u170;
    TextLabel.TextStrokeColor3 = Color3.new(0, 0, 0);
    TextLabel.TextStrokeTransparency = 0.5;
    u171 = Instance.new("TextLabel");
    u171.AnchorPoint = Vector2.new(1, 0);
    u171.Position = UDim2.new(1, -10, 0, 8);
    u171.Size = UDim2.new(0.34, 0, 0, 22);
    u171.BackgroundColor3 = Color3_fromRGB_ret5;
    u171.BorderSizePixel = 0;
    u171.Font = Enum.Font.Arcade;
    u171.TextScaled = true;
    u171.TextColor3 = Color3_fromRGB_ret6;
    u171.Text = "LORE POINTS: ...";
    u171.Parent = u170;
    local UIStroke3 = Instance.new("UIStroke");
    UIStroke3.Color = Color3.new(0, 0, 0);
    UIStroke3.Thickness = 1.5;
    UIStroke3.Parent = u171;
    local v178 = u171;
    v178.TextStrokeColor3 = Color3.new(0, 0, 0);
    v178.TextStrokeTransparency = 0.5;
    local TextLabel2 = Instance.new("TextLabel");
    TextLabel2.BackgroundTransparency = 1;
    TextLabel2.Position = UDim2.new(0, 12, 0, 34);
    TextLabel2.Size = UDim2.new(1, -24, 0, 16);
    TextLabel2.Font = Enum.Font.Bangers;
    TextLabel2.TextScaled = true;
    TextLabel2.TextColor3 = Color3_fromRGB_ret8;
    TextLabel2.TextXAlignment = Enum.TextXAlignment.Left;
    TextLabel2.Text = "Spend Lore Points to request official lore events. The Lore Team reviews every request.";
    TextLabel2.Parent = u170;
    TextLabel2.TextStrokeColor3 = Color3.new(0, 0, 0);
    TextLabel2.TextStrokeTransparency = 0.5;
    local ScrollingFrame2 = Instance.new("ScrollingFrame");
    ScrollingFrame2.Name = "RequestScroll";
    ScrollingFrame2.Position = UDim2.new(0, 10, 0, 56);
    ScrollingFrame2.Size = UDim2.new(1, -20, 1, -66);
    ScrollingFrame2.BackgroundColor3 = Color3.fromRGB(20, 20, 22);
    ScrollingFrame2.BorderSizePixel = 0;
    ScrollingFrame2.ScrollBarThickness = 5;
    ScrollingFrame2.ScrollBarImageColor3 = Color3_fromRGB_ret6;
    ScrollingFrame2.CanvasSize = UDim2.new();
    ScrollingFrame2.AutomaticCanvasSize = Enum.AutomaticSize.Y;
    ScrollingFrame2.Parent = u170;
    local UIStroke4 = Instance.new("UIStroke");
    UIStroke4.Color = Color3.new(0, 0, 0);
    UIStroke4.Thickness = 1.5;
    UIStroke4.Parent = ScrollingFrame2;
    local UIListLayout = Instance.new("UIListLayout");
    UIListLayout.Padding = UDim.new(0, 6);
    UIListLayout.SortOrder = Enum.SortOrder.LayoutOrder;
    UIListLayout.Parent = ScrollingFrame2;
    local UIPadding = Instance.new("UIPadding");
    UIPadding.PaddingTop = UDim.new(0, 8);
    UIPadding.PaddingBottom = UDim.new(0, 8);
    UIPadding.PaddingLeft = UDim.new(0, 8);
    UIPadding.PaddingRight = UDim.new(0, 8);
    UIPadding.Parent = ScrollingFrame2;

    for i, v in ipairs(LoreRequestData.Requests) do
        local Frame2 = Instance.new("Frame");
        Frame2.Size = UDim2.new(1, 0, 0, 48);
        Frame2.BackgroundColor3 = Color3_fromRGB_ret5;
        Frame2.BorderSizePixel = 0;
        Frame2.LayoutOrder = i;
        Frame2.Parent = ScrollingFrame2;
        local UIStroke5 = Instance.new("UIStroke");
        UIStroke5.Color = Color3.new(0, 0, 0);
        UIStroke5.Thickness = 1.5;
        UIStroke5.Parent = Frame2;
        local TextLabel3 = Instance.new("TextLabel");
        TextLabel3.BackgroundTransparency = 1;
        TextLabel3.Position = UDim2.new(0, 10, 0, 0);
        TextLabel3.Size = UDim2.new(1, -190, 1, 0);
        TextLabel3.Font = Enum.Font.Bangers;
        TextLabel3.TextScaled = true;
        TextLabel3.TextXAlignment = Enum.TextXAlignment.Left;
        TextLabel3.TextColor3 = v.Enabled and Color3_fromRGB_ret7 or Color3_fromRGB_ret8;
        TextLabel3.Text = v.Name .. (v.Enabled == false and v.DisabledNote and (" -- " .. v.DisabledNote or "") or "");
        TextLabel3.Parent = Frame2;
        TextLabel3.TextStrokeColor3 = Color3.new(0, 0, 0);
        TextLabel3.TextStrokeTransparency = 0.5;
        local UITextSizeConstraint = Instance.new("UITextSizeConstraint");
        UITextSizeConstraint.MaxTextSize = 20;
        UITextSizeConstraint.Parent = TextLabel3;
        local TextLabel4 = Instance.new("TextLabel");
        TextLabel4.AnchorPoint = Vector2.new(1, 0.5);
        TextLabel4.Position = UDim2.new(1, -100, 0.5, 0);
        TextLabel4.Size = UDim2.new(0, 56, 0, 22);
        TextLabel4.BackgroundColor3 = Color3.fromRGB(20, 20, 22);
        TextLabel4.BorderSizePixel = 0;
        TextLabel4.Font = Enum.Font.Arcade;
        TextLabel4.TextScaled = true;
        TextLabel4.TextColor3 = v.Enabled and Color3_fromRGB_ret6 or Color3_fromRGB_ret8;
        TextLabel4.Text = v.Cost .. " LP";
        TextLabel4.Parent = Frame2;
        local UIStroke6 = Instance.new("UIStroke");
        UIStroke6.Color = Color3.new(0, 0, 0);
        UIStroke6.Thickness = 1;
        UIStroke6.Parent = TextLabel4;
        TextLabel4.TextStrokeColor3 = Color3.new(0, 0, 0);
        TextLabel4.TextStrokeTransparency = 0.5;
        local TextButton = Instance.new("TextButton");
        TextButton.AnchorPoint = Vector2.new(1, 0.5);
        TextButton.Position = UDim2.new(1, -8, 0.5, 0);
        TextButton.Size = UDim2.new(0, 84, 0, 32);
        TextButton.BorderSizePixel = 0;
        TextButton.Font = Enum.Font.Arcade;
        TextButton.TextScaled = true;
        TextButton.Parent = Frame2;
        local UIStroke7 = Instance.new("UIStroke");
        UIStroke7.Color = Color3.new(0, 0, 0);
        UIStroke7.Thickness = 1.5;
        UIStroke7.Parent = TextButton;
        TextButton.TextStrokeColor3 = Color3.new(0, 0, 0);
        TextButton.TextStrokeTransparency = 0.5;
        local UITextSizeConstraint2 = Instance.new("UITextSizeConstraint");
        UITextSizeConstraint2.MaxTextSize = 14;
        UITextSizeConstraint2.Parent = TextButton;

        if v.Enabled == false then
            TextButton.BackgroundColor3 = Color3.fromRGB(58, 58, 60);
            TextButton.TextColor3 = Color3_fromRGB_ret8;
            TextButton.Text = "LOCKED";
            TextButton.AutoButtonColor = false;
            TextButton.Active = false;
        else
            local u179 = v.ButtonText or "REQUEST";
            TextButton.BackgroundColor3 = Color3_fromRGB_ret6;
            TextButton.TextColor3 = Color3.fromRGB(235, 244, 255);
            TextButton.Text = u179;
            local u180 = false;
            TextButton.Activated:Connect(function() -- Line: 1569
                -- upvalues: u180 (ref), TextButton (copy), u179 (copy), ServerRemote (ref), v (copy), u170 (ref)
                if u180 then
                    return;
                end;

                u180 = true;
                TextButton.Text = "SENT...";
                task.delay(3, function() -- Line: 1573
                    -- upvalues: TextButton (ref), u180 (ref), u179 (ref)
                    if TextButton.Parent then
                        u180 = false;
                        TextButton.Text = u179;
                    end;
                end);
                ServerRemote:FireServer(nil, {
                    Module = "LoreRequestManager",
                    Action = "RequestLoreEvent",
                    RequestId = v.Id
                });
                task.delay(0.8, function() -- Line: 1585
                    -- upvalues: u170 (ref)
                    if u170 and u170.Visible then
                        renderLoreRequests();
                    end;
                end);
            end);
        end;

        table.insert(u172, {
            request = v,
            button = TextButton
        });
    end;

    u170.ZIndex = 2;

    for _, descendant in ipairs(u170:GetDescendants()) do
        if descendant:IsA("GuiObject") then
            local v181 = descendant;
            local v182 = v181;
            local v183 = v181;
            v181 = v182;
            v183 = v182;
            local v184 = 0;

            while v182 and v182 ~= u170 do
                v184 = v184 + 1;
                v182 = v182.Parent;
            end;

            v181.ZIndex = v184 + 2;
        end;
    end;

    local Frame2 = Instance.new("Frame");
    Frame2.Name = "Content";
    Frame2.BackgroundTransparency = 1;
    Frame2.Size = UDim2.fromScale(1, 1);
    Frame2.ZIndex = 3;
    Frame2.Parent = u170;

    for _, child in ipairs(u170:GetChildren()) do
        if child:IsA("GuiObject") and child ~= Frame2 then
            child.Parent = Frame2;
        end;
    end;

    local UIScale = Instance.new("UIScale");
    UIScale.Parent = Frame2;

    local function fitPanel() -- Line: 1629
        -- upvalues: u170 (ref), UIScale (copy), Frame2 (copy)
        local Y = u170.AbsoluteSize.Y;

        if Y <= 0 then
            return;
        end;

        local math_clamp_ret = math.clamp(Y / 360, 0.45, 1);
        UIScale.Scale = math_clamp_ret;
        Frame2.Size = UDim2.fromScale(1 / math_clamp_ret, 1 / math_clamp_ret);
    end;

    u170:GetPropertyChangedSignal("AbsoluteSize"):Connect(fitPanel);
    task.defer(fitPanel);
end;

function renderLoreRequests()
    -- upvalues: buildRequestsTab (copy), StatRetrieveRemote (copy), u171 (ref), u172 (copy)
    buildRequestsTab();
    task.spawn(function() -- Line: 1642
        -- upvalues: StatRetrieveRemote (ref), u171 (ref), u172 (ref)
        local success, result = pcall(function() -- Line: 1643
            -- upvalues: StatRetrieveRemote (ref)
            return StatRetrieveRemote:InvokeServer("LorePoints");
        end);
        local v185 = success and tonumber(result) or 0;

        if u171 then
            u171.Text = "LORE POINTS: " .. v185;
        end;

        for _, v in ipairs(u172) do
            if v.request.Enabled ~= false then
                v.button.BackgroundTransparency = v185 < v.request.Cost and 0.45 or 0;
            end;
        end;
    end);
end;

buildRequestsTab();
local u186 = {};

local function clearViewport() -- Line: 1668
    -- upvalues: ViewportFrame (copy)
    for _, child in ipairs(ViewportFrame:GetChildren()) do
        if not child:IsA("UIAspectRatioConstraint") then
            child:Destroy();
        end;
    end;
end;

local function turnOffTabs() -- Line: 1676
    -- upvalues: StatFrame (copy)
    for _, child in ipairs(StatFrame.Tabs:GetChildren()) do
        if child:IsA("ImageButton") then
            child.Image = "rbxassetid://126454867112626";
        end;
    end;
end;

local function closeOtherTabFrames() -- Line: 1684
    -- upvalues: StatFrame (copy), u18 (copy)
    for _, child in ipairs(StatFrame:GetChildren()) do
        if child:IsA("Frame") and child.Name ~= "Tabs" then
            child.Visible = false;
        end;
    end;

    local v187 = u18;

    for i, v in pairs(v187) do
        v:Disconnect();
        v187[i] = nil;
    end;
end;

local function fetchStats() -- Line: 1694
    -- upvalues: StatRetrieveRemote (copy)
    local u188 = 0;
    local u189 = {};

    for i, v in pairs({
        KiDmg = { "KiDmg", "Core" },
        Strength = { "Strength", "Core" },
        KiControl = { "KiControl", "Core" },
        Agility = { "Agility", "Core" },
        Durability = { "Durability", "Core" },
        UTP = { "Ungained TP" },
        GTP = { "Gained TP" },
        Name = { "Name" }
    }) do
        u188 = u188 + 1;
        task.spawn(function() -- Line: 1708
            -- upvalues: StatRetrieveRemote (ref), v (copy), u189 (copy), i (copy), u188 (ref)
            local success, result = pcall(function() -- Line: 1709
                -- upvalues: StatRetrieveRemote (ref), v (ref)
                return StatRetrieveRemote:InvokeServer(table.unpack(v));
            end);
            u189[i] = success and result and result or nil;
            u188 = u188 - 1;
        end);
    end;

    while u188 > 0 do
        task.wait();
    end;

    return u189;
end;

local Color3_fromRGB_ret9 = Color3.fromRGB(38, 38, 48);
local Color3_fromRGB_ret10 = Color3.fromRGB(255, 255, 255);
local Color3_fromRGB_ret11 = Color3.fromRGB(255, 214, 140);
local Color3_fromRGB_ret12 = Color3.fromRGB(255, 205, 110);
local u190 = {
    UTP = {
        Title = "Ungained TP",
        Body = "Potential you have not earned yet. You get 10 each level, and winning fights converts them into GTP."
    },
    GTP = {
        Title = "Gained TP",
        Body = "Earned potential, ready to spend. Training uses GTP to raise your Enhanced stats. You level up only when UTP and GTP are both zero."
    }
};
local u191 = nil;

local function killTip() -- Line: 1770
    -- upvalues: u191 (ref)
    if u191 then
        u191:Destroy();
        u191 = nil;
    end;
end;

local function tipLabel(p192, p193, p194, p195, p196, p197) -- Line: 1777
    local TextLabel = Instance.new("TextLabel");
    TextLabel.BackgroundTransparency = 1;
    TextLabel.Size = UDim2.new(1, 0, 0, 0);
    TextLabel.AutomaticSize = Enum.AutomaticSize.Y;
    TextLabel.Font = p197 and Enum.Font.GothamBold or Enum.Font.Gotham;
    TextLabel.Text = p193;
    TextLabel.TextSize = p194;
    TextLabel.TextColor3 = p195;
    TextLabel.TextXAlignment = Enum.TextXAlignment.Left;
    TextLabel.TextWrapped = true;
    TextLabel.LayoutOrder = p196;
    TextLabel.ZIndex = 52;
    TextLabel.Parent = p192;
    local UIStroke2 = Instance.new("UIStroke");
    UIStroke2.ApplyStrokeMode = Enum.ApplyStrokeMode.Contextual;
    UIStroke2.Color = Color3.new(0, 0, 0);
    UIStroke2.Thickness = 2;
    UIStroke2.Transparency = 0;
    UIStroke2.Parent = TextLabel;

    return TextLabel;
end;

local function buildTip(p198, p199, p200, p201) -- Line: 1808
    -- upvalues: u191 (ref), Color3_fromRGB_ret9 (copy), Color3_fromRGB_ret12 (copy), tipLabel (copy), Color3_fromRGB_ret10 (copy)
    if u191 then
        u191:Destroy();
        u191 = nil;
    end;

    local Frame2 = Instance.new("Frame");
    Frame2.Name = "StatTooltip";
    Frame2.BackgroundColor3 = Color3_fromRGB_ret9;
    Frame2.BackgroundTransparency = 0.05;
    Frame2.BorderSizePixel = 0;
    Frame2.Size = UDim2.new(0, 210, 0, 0);
    Frame2.AutomaticSize = Enum.AutomaticSize.Y;
    Frame2.ZIndex = 50;
    Frame2.Parent = p198;
    local UICorner2 = Instance.new("UICorner");
    UICorner2.CornerRadius = UDim.new(0, 4);
    UICorner2.Parent = Frame2;
    local Frame3 = Instance.new("Frame");
    Frame3.BackgroundColor3 = Color3_fromRGB_ret12;
    Frame3.BorderSizePixel = 0;
    Frame3.Size = UDim2.new(0, 3, 1, 0);
    Frame3.ZIndex = 51;
    Frame3.Parent = Frame2;
    local Frame4 = Instance.new("Frame");
    Frame4.BackgroundTransparency = 1;
    Frame4.Position = UDim2.new(0, 11, 0, 6);
    Frame4.Size = UDim2.new(1, -18, 0, 0);
    Frame4.AutomaticSize = Enum.AutomaticSize.Y;
    Frame4.ZIndex = 51;
    Frame4.Parent = Frame2;
    local UIPadding = Instance.new("UIPadding");
    UIPadding.PaddingBottom = UDim.new(0, 7);
    UIPadding.Parent = Frame4;
    local UIListLayout = Instance.new("UIListLayout");
    UIListLayout.SortOrder = Enum.SortOrder.LayoutOrder;
    UIListLayout.Padding = UDim.new(0, 3);
    UIListLayout.Parent = Frame4;
    tipLabel(Frame4, p200, 14, Color3_fromRGB_ret10, 1, true);

    for i, v in ipairs(p201) do
        tipLabel(Frame4, v.Text, v.Size or 13, v.Colour or Color3_fromRGB_ret10, i + 1, false);
    end;

    local workspace_CurrentCamera = workspace.CurrentCamera;
    local v202 = workspace_CurrentCamera and workspace_CurrentCamera.ViewportSize or Vector2.new(1280, 720);
    local AbsolutePosition = p199.AbsolutePosition;
    local v203 = AbsolutePosition.X + p199.AbsoluteSize.X + 8;

    if v203 + 210 > v202.X then
        v203 = AbsolutePosition.X - 210 - 8;
    end;

    local math_max_ret = math.max(4, v202.X - 210 - 4);
    local math_clamp_ret = math.clamp(v203, 4, math_max_ret);
    local Y = AbsolutePosition.Y;
    local math_max_ret2 = math.max(4, v202.Y - 120);
    local math_clamp_ret2 = math.clamp(Y, 4, math_max_ret2);
    Frame2.Position = UDim2.fromOffset(math_clamp_ret, math_clamp_ret2);
    u191 = Frame2;

    return Frame2;
end;

local function setupStatTooltips() -- Line: 1870
    -- upvalues: u20 (ref), Stats (copy), StatList (copy), u186 (copy), LocalPlayer (copy), buildTip (copy), Color3_fromRGB_ret11 (copy), killTip (copy), u190 (copy), u191 (ref)
    if u20 then
        return;
    end;

    u20 = true;
    local u204 = Stats:FindFirstAncestorWhichIsA("ScreenGui") or Stats;

    for _, child in ipairs(StatList:GetChildren()) do
        if child:IsA("GuiObject") then
            local Name = child.Name;

            if u186[Name] ~= nil or child:FindFirstChild("StatNum") then
                child.MouseEnter:Connect(function() -- Line: 1882
                    -- upvalues: u186 (ref), Name (copy), LocalPlayer (ref), buildTip (ref), u204 (copy), child (copy), Color3_fromRGB_ret11 (ref)
                    local v205 = u186[Name];

                    if typeof(v205) ~= "table" then
                        return;
                    end;

                    local PlayerStats = LocalPlayer:FindFirstChild("PlayerStats");

                    if PlayerStats then
                        PlayerStats = PlayerStats:FindFirstChild("TempStats", true);
                    end;

                    if PlayerStats then
                        PlayerStats = PlayerStats:FindFirstChild("Temp" .. Name);
                    end;

                    local v206 = v205["Base" .. Name] or 0;
                    local v207 = v205["Enhanced" .. Name] or 0;
                    local v208 = PlayerStats and PlayerStats.Value or 0;
                    buildTip(u204, child, Name, {
                        {
                            Text = "Base: " .. tostring(v206)
                        },
                        {
                            Text = "Enhanced: " .. tostring(v207)
                        },
                        {
                            Text = "Temp: " .. tostring(v208)
                        },
                        {
                            Size = 11,
                            Text = "Total: " .. tostring(v206 + v207 + v208),
                            Colour = Color3_fromRGB_ret11
                        }
                    });
                end);
                child.MouseLeave:Connect(killTip);
            end;
        end;
    end;

    for i, v in pairs(u190) do
        local u209 = Stats:FindFirstChild(i);

        if u209 and u209:IsA("GuiObject") then
            u209.MouseEnter:Connect(function() -- Line: 1908
                -- upvalues: u186 (ref), i (copy), buildTip (ref), u204 (copy), u209 (copy), v (copy), Color3_fromRGB_ret11 (ref)
                buildTip(u204, u209, v.Title, {
                    {
                        Size = 11,
                        Text = "You have: " .. tostring(u186[i] or 0),
                        Colour = Color3_fromRGB_ret11
                    },
                    {
                        Text = v.Body
                    }
                });
            end);
            u209.MouseLeave:Connect(killTip);
        end;
    end;

    Stats:GetPropertyChangedSignal("Visible"):Connect(function() -- Line: 1920
        -- upvalues: Stats (ref), u191 (ref)
        if not Stats.Visible and u191 then
            u191:Destroy();
            u191 = nil;
        end;
    end);
end;

local function renderStats() -- Line: 1924
    -- upvalues: fetchStats (copy), u186 (copy), Stats (copy), LocalPlayer (copy), setupStatTooltips (copy)
    local v210 = fetchStats();

    for i, v in pairs(v210) do
        u186[i] = v;
    end;

    Stats.NameLabel.Text.Text = v210.Name or "No Name Found";
    local PlayerStats = LocalPlayer:FindFirstChild("PlayerStats");

    if PlayerStats then
        PlayerStats = PlayerStats:FindFirstChild("TempStats", true);
    end;

    for _, descendant in ipairs(Stats:GetDescendants()) do
        local v211 = v210[descendant.Name];

        if v211 ~= nil and descendant:FindFirstChild("StatNum") then
            if typeof(v211) == "table" then
                local v212 = PlayerStats and (PlayerStats["Temp" .. descendant.Name].Value or 0) or 0;
                local v213 = v211["Base" .. descendant.Name] + v211["Enhanced" .. descendant.Name] + v212;

                if v212 > 0 then
                    descendant.StatNum.RichText = true;
                    descendant.StatNum.Text = "<font color=\"#FF6464\">" .. v213 .. "</font>";
                else
                    descendant.StatNum.Text = v213;
                end;
            else
                descendant.StatNum.Text = v211;
            end;
        end;
    end;

    setupStatTooltips();
end;

local function setupViewport() -- Line: 1956
    -- upvalues: clearViewport (copy), ViewportFrame (copy), LocalPlayer (copy), GlobalFunctions (copy), AnimationManager (copy), u19 (ref), Stats (copy), StatFrame (copy)
    clearViewport();
    local WorldModel = Instance.new("WorldModel");
    WorldModel.Parent = ViewportFrame;
    local Camera = Instance.new("Camera");
    Camera.Parent = ViewportFrame;
    ViewportFrame.CurrentCamera = Camera;
    local v214 = LocalPlayer.Character or LocalPlayer.CharacterAdded:Wait();
    v214.Archivable = true;
    local v215 = v214:Clone();
    v215.Name = "Clone";

    for _, child in ipairs(v215:GetChildren()) do
        if child:IsA("BaseScript") or child:IsA("ModuleScript") then
            child:Destroy();
        end;
    end;

    v215.Parent = WorldModel;
    local RootAndHumanoid = GlobalFunctions.GetRootAndHumanoid(v215);
    AnimationManager.PlayAnimation(v215, "Hover", {
        Looped = true
    });
    Camera.CFrame = RootAndHumanoid.CFrame * CFrame.new(0, 1, -5.5);
    Camera.CFrame = CFrame.lookAt(Camera.CFrame.Position, RootAndHumanoid.Position);

    if not u19 then
        u19 = true;
        Stats:GetPropertyChangedSignal("Visible"):Connect(function() -- Line: 1988
            -- upvalues: Stats (ref), clearViewport (ref)
            if not Stats.Visible then
                clearViewport();
            end;
        end);
        StatFrame:GetPropertyChangedSignal("Visible"):Connect(function() -- Line: 1991
            -- upvalues: StatFrame (ref), clearViewport (ref)
            if not StatFrame.Visible then
                clearViewport();
            end;
        end);
    end;
end;

local u241 = {
    StatTab = function() -- Line: 1998
        -- upvalues: Stats (copy), StatFrame (copy), setupViewport (copy), renderStats (copy)
        Stats.Visible = true;
        StatFrame.Tabs.StatTab.Image = "rbxassetid://126781002557225";
        setupViewport();
        task.spawn(renderStats);
    end,

    InfoTab = function() -- Line: 2005
        -- upvalues: Info (copy), StatRetrieveRemote (copy), Players (copy), InfoBox (copy)
        Info.Visible = true;
        task.spawn(function() -- Line: 2008
            -- upvalues: StatRetrieveRemote (ref), Players (ref), InfoBox (ref)
            local v216 = { { "Race" }, { "SubType" }, { "Rank" }, { "PotentialType" }, { "Class" }, { "CombatType" }, { "CombatLevel" }, { "MaxTransformation", "Core", "Transformation Mastery" }, { "Trainers", "TableStat" } };
            local u217 = 0;
            local u218 = {};
            local u219 = {
                Race = "Human",
                SubType = "None",
                Rank = "E",
                PotentialType = "E",
                Class = "None",
                CombatType = "Default",
                CombatLevel = 1,
                MaxTransformation = 1
            };

            for _, v in ipairs(v216) do
                u217 = u217 + 1;
                task.spawn(function() -- Line: 2033
                    -- upvalues: StatRetrieveRemote (ref), v (copy), u218 (copy), u219 (copy), u217 (ref)
                    local success, result = pcall(function() -- Line: 2034
                        -- upvalues: StatRetrieveRemote (ref), v (ref)
                        return StatRetrieveRemote:InvokeServer(table.unpack(v));
                    end);

                    if not (success and (result ~= nil and result)) then
                        result = u219[v[1]];
                    end;

                    u218[v[1]] = result;
                    u217 = u217 - 1;
                end);
            end;

            while u217 > 0 do
                task.wait();
            end;

            local v220 = {};

            for _, v in ipairs(v216) do
                local v221 = v[1];

                if v221 == "Trainers" then
                    table.insert(v220, "Trainers : ");

                    for _, v2 in pairs(u218.Trainers or {}) do
                        table.insert(v220, "\t" .. ((v2 == "" or not v2) and "None" or v2));
                    end;
                else
                    local v222 = (v[3] or v221) .. " : " .. tostring(u218[v221]);
                    table.insert(v220, v222);
                end;
            end;

            table.insert(v220, "");
            table.insert(v220, "Family :");
            local v223 = nil;
            local Attribute = Players.LocalPlayer:GetAttribute("FamilyMap");
            local v224;

            if type(Attribute) == "string" and Attribute ~= "" then
                local v225;
                v225, v224 = pcall(function() -- Line: 2070
                    -- upvalues: Attribute (copy)
                    return game:GetService("HttpService"):JSONDecode(Attribute);
                end);

                if not v225 then
                    v224 = v223;
                end;
            else
                v224 = v223;
            end;

            local v226 = {};
            local v227 = { "Father", "Mother", "Brother", "Sister", "Cousin", "Uncle", "Aunt", "Son", "Daughter", "Nephew", "Niece" };
            local v228 = {
                Father = true,
                Mother = true,
                Brother = true,
                Sister = true,
                Cousin = true,
                Uncle = true,
                Aunt = true
            };

            for i, v in pairs(v224 or {}) do
                v226[v] = v226[v] or {};
                local v229 = tonumber(i);
                local v230;

                if v229 then
                    v230 = Players:GetPlayerByUserId(v229);
                else
                    v230 = v229;
                end;

                local v231;

                if v230 then
                    v231 = v230.Name;
                elseif v229 then
                    local success, result = pcall(Players.GetNameFromUserIdAsync, Players, v229);
                    v231 = success and result and result or "User " .. i;
                else
                    v231 = tostring(i);
                end;

                table.insert(v226[v], v231);
            end;

            for _, v in ipairs(v227) do
                local v232 = v226[v];

                if v232 then
                    table.sort(v232);
                    local v233 = "\t" .. v .. " : " .. table.concat(v232, ", ");
                    table.insert(v220, v233);
                elseif v228[v] then
                    table.insert(v220, "\t" .. v .. " : None");
                end;
            end;

            InfoBox.Text = table.concat(v220, "\n") .. "\n";
        end);
    end,

    LoreTab = function() -- Line: 2120
        -- upvalues: Lore (copy), u169 (copy), StatRetrieveRemote (copy), LocalPlayer (copy)
        if not (Lore and u169) then
            return;
        end;

        Lore.Visible = true;
        task.spawn(function() -- Line: 2124
            -- upvalues: StatRetrieveRemote (ref), u169 (ref), LocalPlayer (ref)
            local success, result = pcall(function() -- Line: 2125
                -- upvalues: StatRetrieveRemote (ref)
                return StatRetrieveRemote:InvokeServer("LoreData", "TableStat");
            end);

            if not success or type(result) ~= "table" then
                return;
            end;

            local OfficialNotes = result.OfficialNotes;
            u169.OfficialNotes.Text = not (OfficialNotes and (OfficialNotes ~= "" and OfficialNotes)) and "No official lore recorded." or OfficialNotes;

            local function traitList(p234) -- Line: 2134
                local v235 = {};

                for i in pairs(p234 or {}) do
                    table.insert(v235, i);
                end;

                table.sort(v235);

                return #v235 > 0 and table.concat(v235, ", ") or "None";
            end;

            u169.OfficialBuffs.Text = traitList(result.OfficialBuffs);
            u169.OfficialDebuffs.Text = traitList(result.OfficialDebuffs);
            local SelfInfoBox = u169.SelfInfoBox;

            if not SelfInfoBox:IsFocused() then
                SelfInfoBox.Text = result.SelfInfo or "";
            end;

            local LoreStatsHeader = u169:FindFirstChild("LoreStatsHeader");
            local LoreStatsRow = u169:FindFirstChild("LoreStatsRow");

            if LoreStatsHeader and LoreStatsRow then
                local Attribute = LocalPlayer:GetAttribute("LoreStats");
                local v236 = nil;
                local v237;

                if type(Attribute) == "string" then
                    local v238;
                    v238, v237 = pcall(game.HttpService.JSONDecode, game.HttpService, Attribute);

                    if not v238 then
                        v237 = v236;
                    end;
                else
                    v237 = v236;
                end;

                local v239 = v237 ~= nil;
                LoreStatsHeader.Visible = v239;
                LoreStatsRow.Visible = v239;

                if v237 then
                    for _, child in ipairs(LoreStatsRow:GetChildren()) do
                        if child:IsA("Frame") then
                            local Value = child.Value;
                            local v240 = tonumber(v237[child.Name]) or 0;
                            local math_floor_ret = math.floor(v240);
                            Value.Text = tostring(math_floor_ret);
                        end;
                    end;
                end;
            end;
        end);
    end,

    RequestTab = function() -- Line: 2174
        -- upvalues: buildRequestsTab (copy), u170 (ref)
        buildRequestsTab();
        u170.Visible = true;
        renderLoreRequests();
    end
};

if u169 then
    local u242 = false;
    u169.SaveButton.Activated:Connect(function() -- Line: 2186
        -- upvalues: u242 (ref), u169 (copy), ServerRemote (copy)
        if u242 then
            return;
        end;

        u242 = true;
        task.delay(1, function() -- Line: 2189
            -- upvalues: u242 (ref)
            u242 = false;
        end);
        local SelfInfoBox = u169.SelfInfoBox;

        if #SelfInfoBox.Text > 2000 then
            SelfInfoBox.Text = SelfInfoBox.Text:sub(1, 2000);
        end;

        ServerRemote:FireServer(nil, {
            Module = "LoreManager",
            Action = "SaveSelfInfo",
            Text = SelfInfoBox.Text
        });
    end);
end;

local function setupTabButtons() -- Line: 2203
    -- upvalues: u21 (ref), StatFrame (copy), u241 (copy), turnOffTabs (copy), closeOtherTabFrames (copy)
    if u21 then
        return;
    end;

    u21 = true;

    for _, child in ipairs(StatFrame.Tabs:GetChildren()) do
        if child:IsA("ImageButton") and u241[child.Name] then
            child.Activated:Connect(function() -- Line: 2210
                -- upvalues: turnOffTabs (ref), closeOtherTabFrames (ref), child (copy), u241 (ref)
                turnOffTabs();
                closeOtherTabFrames();
                child.Image = "rbxassetid://126781002557225";
                u241[child.Name]();
            end);
        end;
    end;
end;

local InventoryMenuBlur = game:GetService("Lighting"):FindFirstChild("InventoryMenuBlur");

if not InventoryMenuBlur then
    InventoryMenuBlur = Instance.new("BlurEffect");
    InventoryMenuBlur.Name = "InventoryMenuBlur";
    InventoryMenuBlur.Parent = game:GetService("Lighting");
end;

InventoryMenuBlur.Size = 0;
InventoryMenuBlur.Enabled = false;

local function setMenuBlur(p243) -- Line: 2236
    -- upvalues: InventoryMenuBlur (ref)
    local TweenService2 = game:GetService("TweenService");

    if p243 then
        InventoryMenuBlur.Enabled = true;
        TweenService2:Create(InventoryMenuBlur, TweenInfo.new(0.25), {
            Size = 14
        }):Play();

        return;
    end;

    local v244 = TweenService2:Create(InventoryMenuBlur, TweenInfo.new(0.25), {
        Size = 0
    });
    v244.Completed:Once(function() -- Line: 2244
        -- upvalues: InventoryMenuBlur (ref)
        if InventoryMenuBlur.Size <= 0.05 then
            InventoryMenuBlur.Enabled = false;
        end;
    end);
    v244:Play();
end;

local DisplayOrder = u90.DisplayOrder;

local function seedPadSelection() -- Line: 2266
    -- upvalues: u1 (copy), Platform (copy), UserInputService (copy), u7 (copy), GuiService (copy), u5 (copy), StatFrame (copy)
    if not u1 then
        return;
    end;

    if not Platform.IsGamepadInput(UserInputService:GetLastInputType()) then
        return;
    end;

    for _, v in pairs(u7) do
        if v.Visible and v.Parent then
            local v245;

            if v.Parent == nil then
                v245 = false;
            else
                v245 = v.Parent.Name == "ItemContainer";
            end;

            if v245 then
                GuiService.SelectedObject = v;

                return;
            end;
        end;
    end;

    for _, v in pairs(u5) do
        local ItemFrame = v:FindFirstChild("ItemFrame");

        if ItemFrame then
            GuiService.SelectedObject = ItemFrame;

            return;
        end;
    end;

    for _, child in ipairs(StatFrame.Tabs:GetChildren()) do
        if child:IsA("ImageButton") then
            GuiService.SelectedObject = child;

            return;
        end;
    end;
end;

u99 = function() -- Line: 2295
    -- upvalues: u9 (ref), u90 (copy), InventoryMenuBlur (ref), Space (copy), StatFrame (copy), PartyFrame (copy), MainFrame (copy), u5 (copy), u1 (copy), setupTabButtons (copy), u241 (copy), seedPadSelection (copy)
    u9 = true;
    u90.DisplayOrder = 60;
    local TweenService2 = game:GetService("TweenService");
    InventoryMenuBlur.Enabled = true;
    TweenService2:Create(InventoryMenuBlur, TweenInfo.new(0.25), {
        Size = 14
    }):Play();
    Space.Visible = true;
    StatFrame.Visible = true;
    PartyFrame.Visible = false;
    MainFrame.Visible = false;

    for _, v in pairs(u5) do
        v.Visible = true;

        if u1 then
            v.Selectable = true;
        end;
    end;

    setupTabButtons();
    u241.StatTab();
    seedPadSelection();
end;

u100 = function() -- Line: 2316
    -- upvalues: u9 (ref), u90 (copy), DisplayOrder (copy), setMenuBlur (copy), Space (copy), StatFrame (copy), PartyFrame (copy), MainFrame (copy), TextBox (copy), u5 (copy), turnOffTabs (copy), closeOtherTabFrames (copy), u1 (copy), GuiService (copy), script_Parent (copy)
    u9 = false;
    u90.DisplayOrder = DisplayOrder;
    setMenuBlur(false);
    Space.Visible = false;
    StatFrame.Visible = false;
    PartyFrame.Visible = true;
    MainFrame.Visible = true;
    TextBox.Text = "";

    for _, v in pairs(u5) do
        if not v:FindFirstChild("ItemFrame") then
            v.Visible = false;
        end;
    end;

    turnOffTabs();
    closeOtherTabFrames();

    if u1 then
        for _, v in pairs(u5) do
            v.Selectable = false;
        end;

        local SelectedObject = GuiService.SelectedObject;

        if SelectedObject and SelectedObject:IsDescendantOf(script_Parent) then
            GuiService.SelectedObject = nil;
        end;
    end;
end;

local function toggleInventory() -- Line: 2348
    -- upvalues: Space (copy), u100 (ref), u99 (ref)
    if Space.Visible then
        u100();

        return;
    end;

    u99();
end;

u98 = function(p246) -- Line: 2362
    -- upvalues: clearKeyColors (copy), u5 (copy), u6 (ref), u10 (ref), LocalPlayer (copy), u8 (ref), Color3_fromRGB_ret2 (copy), Color3_fromRGB_ret (copy), equipTool (copy), refreshFrameScale (copy)
    clearKeyColors();
    local v247 = u5[p246];

    if v247 then
        v247 = v247:FindFirstChild("ItemFrame");
    end;

    u6 = p246;

    if v247 then
        if u6 == u10 then
            clearKeyColors();
            (LocalPlayer.Character or LocalPlayer.CharacterAdded:Wait()):WaitForChild("Humanoid"):UnequipTools();
            u8 = "";
            v247.Number.TextColor3 = Color3_fromRGB_ret2;
            u6 = "";
        else
            v247.Number.TextColor3 = Color3_fromRGB_ret;
            equipTool(v247, u6);
        end;

        refreshFrameScale(v247);
    end;

    u10 = u6;
end;

local u248 = { "1", "2", "3", "4", "5", "6", "7", "8", "9", "0" };

local function cycleHotbar(p249) -- Line: 2391
    -- upvalues: u248 (copy), u5 (copy), u10 (ref), u98 (ref)
    local v250 = {};

    for _, v in ipairs(u248) do
        local v251 = u5[v];

        if v251 and v251:FindFirstChild("ItemFrame") then
            v250[#v250 + 1] = v;
        end;
    end;

    if #v250 == 0 then
        return;
    end;

    local table_find_ret = table.find(v250, u10);
    local v252;

    if table_find_ret then
        v252 = (table_find_ret - 1 + p249) % #v250 + 1;
    else
        v252 = p249 > 0 and 1 or #v250;
    end;

    if v250[v252] == u10 then
        u10 = "";
    end;

    u98(v250[v252]);
end;

UserInputService.InputBegan:Connect(function(p253, p254) -- Line: 2411
    -- upvalues: u3 (copy), u98 (ref), u2 (copy), Space (copy), u100 (ref), u99 (ref)
    if p254 then
        return;
    end;

    local v255 = u3[p253.KeyCode];

    if v255 then
        u98(v255);
    end;

    if p253.KeyCode == Enum.KeyCode[u2] then
        if Space.Visible then
            u100();

            return;
        end;

        u99();
    end;
end);
ReplicatedStorage.Remotes:WaitForChild("TouchActionRemote").Event:Connect(function(p256, p257, p258) -- Line: 2437
    -- upvalues: Space (copy), u100 (ref), u99 (ref), cycleHotbar (copy), u5 (copy), u98 (ref)
    if p256 ~= "CoreControls" then
        return;
    end;

    if p257 == "Inventory" then
        if Space.Visible then
            u100();

            return;
        end;

        u99();

        return;
    end;

    if p257 == "Hotbar Next" or p257 == "Hotbar Prev" then
        cycleHotbar(p257 == "Hotbar Next" and 1 or -1);

        return;
    end;

    if p257 == "Hotbar Slot" and u5[tostring(p258)] then
        u98((tostring(p258)));
    end;
end);

if u1 then
    local ContextActionService = game:GetService("ContextActionService");
    local u259 = nil;
    local u260 = nil;
    local u261 = nil;

    local function releaseHolding() -- Line: 2474
        -- upvalues: u259 (ref), u261 (ref)
        if not u259 then
            return;
        end;

        u259.Size = u261;
        u259 = nil;
    end;

    local function storeHeldInInventory() -- Line: 2482
        -- upvalues: u259 (ref), u260 (ref), u261 (ref), Backpack (ref), LocalPlayer (copy), u60 (copy), u61 (copy), frameMatchesFilter (copy), refreshFrameScale (copy), u4 (copy), InventoryRemote (copy), GuiService (copy), seedPadSelection (copy)
        if not u259 then
            return;
        end;

        local v262 = u259;
        local v263 = u260;
        local v264;

        if v262.Parent == nil then
            v264 = false;
        else
            v264 = v262.Parent.Name == "ItemContainer";
        end;

        if v264 then
            if not u259 then
                return;
            end;

            u259.Size = u261;
            u259 = nil;

            return;
        end;

        v262.Number.Visible = false;
        local Text = v262.ItemName.Text;
        local v265 = Backpack:FindFirstChild(Text);

        if not (v265 and v265:IsA("Tool")) then
            v265 = LocalPlayer.Character;

            if v265 then
                v265 = v265:FindFirstChild(Text);
            end;

            if not (v265 and v265:IsA("Tool")) then
                v265 = nil;
            end;
        end;

        local v266;

        if v265 then
            if v265:FindFirstChild("Skill") then
                v266 = true;
            else
                local Attribute = v265:GetAttribute("SkillName");

                if Attribute == nil then
                    v266 = false;
                else
                    v266 = Attribute ~= "";
                end;
            end;
        else
            v266 = false;
        end;

        local v267;

        if v266 then
            v267 = u60[v265:GetAttribute("AttackType")] or u60.Misc;
        else
            if v265 then
                v265 = v265:GetAttribute("ItemCategory");
            end;

            v267 = u61[v265] or u61.Misc;
        end;

        v262.Parent = v267;
        v262.Visible = frameMatchesFilter(v262.ItemName.Text, v262.Parent.Parent.Name);
        refreshFrameScale(v262);

        if v263 and u4[v263.Name] then
            InventoryRemote:FireServer({
                Action = "Set",
                ToolName = "",
                Tool_Slot = v263.Name
            });
        end;

        if u259 then
            u259.Size = u261;
            u259 = nil;
        end;

        if v262.Parent and v262.Visible then
            GuiService.SelectedObject = v262;

            return;
        end;

        seedPadSelection();
    end;

    UserInputService.InputBegan:Connect(function(p268) -- Line: 2515
        -- upvalues: u9 (ref), Platform (copy), GuiService (copy), u259 (ref), u260 (ref), u261 (ref), Backpack (ref), LocalPlayer (copy), u60 (copy), u61 (copy), frameMatchesFilter (copy), refreshFrameScale (copy), swapFrames (copy), u4 (copy), parentToSlot (copy), InventoryRemote (copy)
        if not u9 then
            return;
        end;

        if p268.KeyCode ~= Enum.KeyCode.ButtonA then
            return;
        end;

        if Platform.IsButtonDown(Enum.KeyCode.ButtonL3) then
            return;
        end;

        local SelectedObject = GuiService.SelectedObject;

        if not SelectedObject then
            return;
        end;

        if SelectedObject.Name ~= "ItemFrame" then
            if u259 and (SelectedObject:IsA("Frame") and u4[SelectedObject.Name]) then
                local ItemFrame = SelectedObject:FindFirstChild("ItemFrame");

                if ItemFrame then
                    swapFrames(ItemFrame, u259, u260, u261);
                else
                    parentToSlot(u259, SelectedObject);
                    InventoryRemote:FireServer({
                        Action = "Set",
                        Tool_Slot = SelectedObject.Name,
                        ToolName = u259.ItemName.Text
                    });
                end;

                if not u259 then
                    return;
                end;

                u259.Size = u261;
                u259 = nil;
            end;

            return;
        end;

        if not u259 then
            u259 = SelectedObject;
            u260 = SelectedObject.Parent;
            u261 = SelectedObject.Size;
            SelectedObject.Size = UDim2.new(1.2, 0, 1.2, 0);

            return;
        end;

        if SelectedObject == u259 then
            if not u259 then
                return;
            end;

            u259.Size = u261;
            u259 = nil;

            return;
        end;

        local v269;

        if SelectedObject.Parent == nil then
            v269 = false;
        else
            v269 = SelectedObject.Parent.Name == "ItemContainer";
        end;

        if v269 then
            local v270 = u259;
            local v271;

            if v270.Parent == nil then
                v271 = false;
            else
                v271 = v270.Parent.Name == "ItemContainer";
            end;

            if v271 and SelectedObject.Parent ~= u259.Parent then
                local v272 = u259;
                v272.Number.Visible = false;
                local Text = v272.ItemName.Text;
                local v273 = Backpack:FindFirstChild(Text);

                if not (v273 and v273:IsA("Tool")) then
                    v273 = LocalPlayer.Character;

                    if v273 then
                        v273 = v273:FindFirstChild(Text);
                    end;

                    if not (v273 and v273:IsA("Tool")) then
                        v273 = nil;
                    end;
                end;

                local v274;

                if v273 then
                    if v273:FindFirstChild("Skill") then
                        v274 = true;
                    else
                        local Attribute = v273:GetAttribute("SkillName");

                        if Attribute == nil then
                            v274 = false;
                        else
                            v274 = Attribute ~= "";
                        end;
                    end;
                else
                    v274 = false;
                end;

                local v275;

                if v274 then
                    v275 = u60[v273:GetAttribute("AttackType")] or u60.Misc;
                else
                    if v273 then
                        v273 = v273:GetAttribute("ItemCategory");
                    end;

                    v275 = u61[v273] or u61.Misc;
                end;

                v272.Parent = v275;
                v272.Visible = frameMatchesFilter(v272.ItemName.Text, v272.Parent.Parent.Name);
                refreshFrameScale(v272);
            else
                swapFrames(SelectedObject, u259, u260, u261);
            end;
        else
            swapFrames(SelectedObject, u259, u260, u261);
        end;

        if not u259 then
            return;
        end;

        u259.Size = u261;
        u259 = nil;
    end);

    local function toggleEquipSelected() -- Line: 2571
        -- upvalues: u259 (ref), GuiService (copy), u4 (copy), clearKeyColors (copy), u6 (ref), u10 (ref), LocalPlayer (copy), u8 (ref), Color3_fromRGB_ret2 (copy), Color3_fromRGB_ret (copy), equipTool (copy), refreshFrameScale (copy)
        if u259 then
            return;
        end;

        local SelectedObject = GuiService.SelectedObject;

        if not SelectedObject or SelectedObject.Name ~= "ItemFrame" then
            return;
        end;

        local Parent2 = SelectedObject.Parent;

        if not (Parent2 and u4[Parent2.Name]) then
            return;
        end;

        clearKeyColors();
        u6 = Parent2.Name;

        if u6 == u10 then
            clearKeyColors();
            (LocalPlayer.Character or LocalPlayer.CharacterAdded:Wait()):WaitForChild("Humanoid"):UnequipTools();
            u8 = "";
            SelectedObject.Number.TextColor3 = Color3_fromRGB_ret2;
            u6 = "";
        else
            SelectedObject.Number.TextColor3 = Color3_fromRGB_ret;
            equipTool(SelectedObject, u6);
        end;

        refreshFrameScale(SelectedObject);
        u10 = u6;
    end;

    ContextActionService:BindActionAtPriority("InventoryPadPanelKeys", function(p276, p277, p278) -- Line: 2594, Name: padPanelKeys
        -- upvalues: u9 (ref), Platform (copy), u259 (ref), u260 (ref), u261 (ref), u100 (ref), toggleEquipSelected (copy), storeHeldInInventory (copy)
        if not u9 then
            return Enum.ContextActionResult.Pass;
        end;

        if Platform.IsButtonDown(Enum.KeyCode.ButtonL3) then
            return Enum.ContextActionResult.Pass;
        end;

        if p277 ~= Enum.UserInputState.Begin then
            return Enum.ContextActionResult.Pass;
        end;

        if p278.KeyCode == Enum.KeyCode.ButtonB then
            if u259 then
                u259.Parent = u260;

                if u259 then
                    u259.Size = u261;
                    u259 = nil;
                end;
            else
                u100();
            end;
        elseif p278.KeyCode == Enum.KeyCode.ButtonX then
            toggleEquipSelected();
        elseif p278.KeyCode == Enum.KeyCode.ButtonY then
            storeHeldInInventory();
        end;

        return Enum.ContextActionResult.Sink;
    end, false, Enum.ContextActionPriority.High.Value, Enum.KeyCode.ButtonX, Enum.KeyCode.ButtonY, Enum.KeyCode.ButtonB);
    UserInputService.LastInputTypeChanged:Connect(function(p279) -- Line: 2635
        -- upvalues: u9 (ref), Platform (copy), GuiService (copy), seedPadSelection (copy), script_Parent (copy)
        if not u9 then
            return;
        end;

        if Platform.IsGamepadInput(p279) then
            if not GuiService.SelectedObject then
                seedPadSelection();
            end;
        elseif p279 == Enum.UserInputType.MouseMovement or (p279 == Enum.UserInputType.Keyboard or (p279 == Enum.UserInputType.MouseButton1 or p279 == Enum.UserInputType.MouseButton2)) then
            local SelectedObject = GuiService.SelectedObject;

            if SelectedObject and SelectedObject:IsDescendantOf(script_Parent) then
                GuiService.SelectedObject = nil;
            end;
        end;
    end);
    local TextLabel = Instance.new("TextLabel");
    TextLabel.Name = "PadHint";
    TextLabel.BackgroundTransparency = 1;
    TextLabel.AnchorPoint = Vector2.new(0.5, 1);
    TextLabel.Position = UDim2.new(0.5, 0, 1, -4);
    TextLabel.Size = UDim2.new(1, -16, 0, 18);
    TextLabel.Font = Enum.Font.Gotham;
    TextLabel.TextSize = 13;
    TextLabel.TextColor3 = Color3.fromRGB(170, 170, 170);
    TextLabel.TextXAlignment = Enum.TextXAlignment.Center;
    TextLabel.Text = "A  Pick up / Drop      Y  Store in inventory      X  Equip      B  Cancel / Close";
    TextLabel.ZIndex = 99;
    TextLabel.Parent = Space;
end;

local u280 = 0;

local function isLoadingIn() -- Line: 2691
    -- upvalues: LocalPlayer (copy), u280 (ref)
    if LocalPlayer:GetAttribute("BackpackLoaded") == true then
        return false;
    end;

    return os.clock() < u280;
end;

local function hotBarSetup() -- Line: 2696
    -- upvalues: LocalPlayer (copy), Backpack (ref), u280 (ref), u12 (copy), addSlot (copy), u11 (copy), countItem (copy), u8 (ref), u7 (copy), clearKeyColors (copy), u6 (ref), u10 (ref), u5 (copy)
    local v281 = LocalPlayer.Character or LocalPlayer.CharacterAdded:Wait();
    Backpack = LocalPlayer:WaitForChild("Backpack");
    u280 = os.clock() + 8;
    local v282 = u12;

    for i, v in pairs(v282) do
        v:Disconnect();
        v282[i] = nil;
    end;

    table.insert(u12, Backpack.ChildAdded:Connect(function(p283) -- Line: 2719
        -- upvalues: addSlot (ref), u11 (ref), LocalPlayer (ref), u280 (ref)
        if p283:IsA("Tool") then
            local Name = p283.Name;
            local v284 = u11[p283.Name];
            local v285;

            if LocalPlayer:GetAttribute("BackpackLoaded") == true then
                v285 = false;
            else
                v285 = os.clock() < u280;
            end;

            addSlot(Name, v284, p283, v285);
        end;
    end));
    table.insert(u12, Backpack.ChildRemoved:Connect(function(p286) -- Line: 2725
        -- upvalues: countItem (ref)
        if p286:IsA("Tool") then
            countItem(p286.Name, p286);
        end;
    end));
    table.insert(u12, v281.ChildAdded:Connect(function(p287) -- Line: 2731
        -- upvalues: addSlot (ref), u11 (ref), LocalPlayer (ref), u280 (ref)
        if p287:IsA("Tool") then
            local Name = p287.Name;
            local v288 = u11[p287.Name];
            local v289;

            if LocalPlayer:GetAttribute("BackpackLoaded") == true then
                v289 = false;
            else
                v289 = os.clock() < u280;
            end;

            addSlot(Name, v288, p287, v289);
        end;
    end));
    table.insert(u12, v281.ChildRemoved:Connect(function(p290) -- Line: 2737
        -- upvalues: u8 (ref), u7 (ref), clearKeyColors (ref), u6 (ref), u10 (ref), countItem (ref)
        if p290:IsA("Tool") then
            if p290.Name == u8 then
                u8 = "";
                local v291 = u7[p290.Name];

                if v291 then
                    local v292;

                    if v291.Parent == nil then
                        v292 = false;
                    else
                        v292 = v291.Parent.Name == "ItemContainer";
                    end;

                    if not v292 then
                        clearKeyColors();
                        u6 = "";
                        u10 = "";
                    end;
                end;
            end;

            countItem(p290.Name, p290);
        end;
    end));

    for _, v in pairs(u5) do
        if not v:FindFirstChild("ItemFrame") then
            v.Visible = false;
        end;
    end;

    for _, child in ipairs(Backpack:GetChildren()) do
        if child:IsA("Tool") then
            addSlot(child.Name, u11[child.Name], child, true);
        end;
    end;
end;

local u298 = {
    ["Saved Slots"] = function(u293, p294) -- Line: 2772
        -- upvalues: u11 (copy), addSlot (copy), LocalPlayer (copy), u7 (copy), Backpack (ref), u144 (ref), InventoryRemote (copy)
        if p294 then
            p294 = p294.LoadingIn;
        end;

        table.clear(u11);
        local v295 = {};

        for i, v in pairs(u293) do
            if v ~= "" then
                u11[v] = i;
            end;
        end;

        for i, v in pairs(u293) do
            if v ~= "" then
                addSlot(v, i, nil, p294);
                table.insert(v295, v);
            end;
        end;

        task.delay(6, function() -- Line: 2797
            -- upvalues: LocalPlayer (ref), u293 (copy), u7 (ref), Backpack (ref), u144 (ref), InventoryRemote (ref)
            local v296 = LocalPlayer:GetAttribute("BackpackLoaded") == true;

            for i, v in pairs(u293) do
                if v ~= "" and u7[v] then
                    local v297 = Backpack:FindFirstChild(v);

                    if not (v297 and v297:IsA("Tool")) then
                        v297 = LocalPlayer.Character;

                        if v297 then
                            v297 = v297:FindFirstChild(v);
                        end;

                        if not (v297 and v297:IsA("Tool")) then
                            v297 = nil;
                        end;
                    end;

                    if not v297 then
                        u144(v);

                        if v296 then
                            InventoryRemote:FireServer({
                                Action = "Set",
                                ToolName = "",
                                Tool_Slot = i
                            });
                        end;
                    end;
                end;
            end;
        end);
    end,

    ["HotBar Setup"] = function() -- Line: 2825
        -- upvalues: hotBarSetup (copy)
        hotBarSetup();
    end,

    ["Character Changed"] = function() -- Line: 2828
    end
};
InventoryRemote.OnClientEvent:Connect(function(p299, p300, p301) -- Line: 2831
    -- upvalues: u298 (copy)
    local v302 = u298[p300];

    if v302 then
        v302(p299, p301);

        return;
    end;

    warn("Inventory: unknown action \'" .. tostring(p300) .. "\'");
end);