-- Decompiled with Potassium's decompiler.

local Players = game:GetService("Players");
local ReplicatedStorage = game:GetService("ReplicatedStorage");
local RunService = game:GetService("RunService");
local Lighting = game:GetService("Lighting");
local Platform = require(ReplicatedStorage.Modules.Shared.Platform);
local LocalPlayer = Players.LocalPlayer;
local u1 = { "SunRaysEffect", "DepthOfFieldEffect", "BloomEffect", "BlurEffect" };
local u2 = {};
local u3 = false;
local u4 = {};
local u5 = nil;
local u6 = nil;
local u7 = false;

local function remember(p8, p9) -- Line: 47
    -- upvalues: u4 (ref)
    local v10 = u4[p8];

    if not v10 then
        v10 = {};
        u4[p8] = v10;
    end;

    if v10[p9] == nil then
        v10[p9] = p8[p9];
    end;
end;

local u11 = { "Map", "Real Map" };

local function isScenery(p12) -- Line: 60
    -- upvalues: u11 (copy)
    local World = workspace:FindFirstChild("World");

    if not World then
        return false;
    end;

    for _, v in ipairs(u11) do
        local v13 = World:FindFirstChild(v);

        if v13 and p12:IsDescendantOf(v13) then
            return true;
        end;
    end;

    return false;
end;

local function applyToPart(p14) -- Line: 70
    -- upvalues: isScenery (copy), u3 (ref), u4 (ref)
    if not p14:IsA("BasePart") then
        return;
    end;

    if not isScenery(p14) then
        return;
    end;

    if u3 then
        if p14.CastShadow and p14.Size.Magnitude < 120 then
            local v15 = u4[p14];

            if not v15 then
                v15 = {};
                u4[p14] = v15;
            end;

            if v15.CastShadow == nil then
                v15.CastShadow = p14.CastShadow;
            end;

            p14.CastShadow = false;
        end;

        if p14:IsA("MeshPart") and p14.RenderFidelity ~= Enum.RenderFidelity.Performance then
            local v16 = u4[p14];

            if not v16 then
                v16 = {};
                u4[p14] = v16;
            end;

            if v16.RenderFidelity == nil then
                v16.RenderFidelity = p14.RenderFidelity;
            end;

            p14.RenderFidelity = Enum.RenderFidelity.Performance;
        end;
    end;
end;

local function applyToDecal(p17) -- Line: 85
    -- upvalues: isScenery (copy), u3 (ref), u4 (ref)
    if not (p17:IsA("Decal") or p17:IsA("Texture")) then
        return;
    end;

    local Parent = p17.Parent;

    if not (Parent and Parent:IsA("BasePart")) then
        return;
    end;

    if not isScenery(p17) then
        return;
    end;

    if u3 and Parent.Size.Magnitude < 40 then
        local v18 = u4[p17];

        if not v18 then
            v18 = {};
            u4[p17] = v18;
        end;

        if v18.Transparency == nil then
            v18.Transparency = p17.Transparency;
        end;

        p17.Transparency = 1;
    end;
end;

local function applyToOther(p19) -- Line: 96
    -- upvalues: isScenery (copy), u3 (ref), u4 (ref)
    if not isScenery(p19) then
        return;
    end;

    if p19:IsA("Light") then
        if u3 and p19.Shadows then
            local v20 = u4[p19];

            if not v20 then
                v20 = {};
                u4[p19] = v20;
            end;

            if v20.Shadows == nil then
                v20.Shadows = p19.Shadows;
            end;

            p19.Shadows = false;
        end;
    elseif p19:IsA("ParticleEmitter") and (u3 and p19.Enabled) then
        local v21 = u4[p19];

        if not v21 then
            v21 = {};
            u4[p19] = v21;
        end;

        if v21.Enabled == nil then
            v21.Enabled = p19.Enabled;
        end;

        p19.Enabled = false;
    end;
end;

local function applyOne(p22) -- Line: 111
    -- upvalues: applyToPart (copy), applyToDecal (copy), applyToOther (copy)
    applyToPart(p22);
    applyToDecal(p22);
    applyToOther(p22);
end;

local function restoreAll() -- Line: 117
    -- upvalues: u4 (ref)
    for i, v in pairs(u4) do
        if i.Parent then
            local u23 = i;

            for i2, v2 in pairs(v) do
                pcall(function() -- Line: 121
                    -- upvalues: u23 (copy), i2 (copy), v2 (copy)
                    u23[i2] = v2;
                end);
            end;
        end;
    end;

    u4 = {};
end;

local function applyLighting() -- Line: 128
    -- upvalues: u3 (ref), u6 (ref), Lighting (copy), u5 (ref), u1 (copy), u4 (ref)
    if not u3 then
        if u6 ~= nil then
            Lighting.GlobalShadows = u6;
            u6 = nil;
        end;

        if u5 then
            local v24 = u5[2];
            Lighting.FogEnd = u5[1];
            Lighting.FogStart = v24;
            u5 = nil;
        end;

        return;
    end;

    if u6 == nil then
        u6 = Lighting.GlobalShadows;
    end;

    if u5 == nil then
        u5 = { Lighting.FogEnd, Lighting.FogStart };
    end;

    Lighting.GlobalShadows = false;
    Lighting.FogEnd = 3500;
    Lighting.FogStart = 1200;

    for _, child in ipairs(Lighting:GetChildren()) do
        local v25 = child;

        for _, v in ipairs(u1) do
            if v25:IsA(v) and v25.Enabled then
                local v26 = u4[v25];

                if not v26 then
                    v26 = {};
                    u4[v25] = v26;
                end;

                if v26.Enabled == nil then
                    v26.Enabled = v25.Enabled;
                end;

                v25.Enabled = false;
            end;
        end;
    end;
end;

local function sweep() -- Line: 150
    -- upvalues: u7 (ref), applyToPart (copy), applyToDecal (copy), applyToOther (copy), RunService (copy)
    if u7 then
        return;
    end;

    u7 = true;
    task.spawn(function() -- Line: 153
        -- upvalues: applyToPart (ref), applyToDecal (ref), applyToOther (ref), RunService (ref), u7 (ref)
        local v27 = 400;

        for _, descendant in ipairs(workspace:GetDescendants()) do
            applyToPart(descendant);
            applyToDecal(descendant);
            applyToOther(descendant);
            v27 = v27 - 1;

            if v27 <= 0 then
                RunService.Heartbeat:Wait();
                v27 = 400;
            end;
        end;

        u7 = false;
    end);
end;

function u2.Set(p28) -- Line: 164
    -- upvalues: u3 (ref), applyLighting (copy), u7 (ref), applyToPart (copy), applyToDecal (copy), applyToOther (copy), RunService (copy), restoreAll (copy)
    if u3 == p28 then
        return;
    end;

    u3 = p28;
    applyLighting();

    if not u3 then
        restoreAll();

        return;
    end;

    if u7 then
        return;
    end;

    u7 = true;
    task.spawn(function() -- Line: 153
        -- upvalues: applyToPart (ref), applyToDecal (ref), applyToOther (ref), RunService (ref), u7 (ref)
        local v29 = 400;

        for _, descendant in ipairs(workspace:GetDescendants()) do
            applyToPart(descendant);
            applyToDecal(descendant);
            applyToOther(descendant);
            v29 = v29 - 1;

            if v29 <= 0 then
                RunService.Heartbeat:Wait();
                v29 = 400;
            end;
        end;

        u7 = false;
    end);
end;

function u2.IsLow() -- Line: 175
    -- upvalues: u3 (ref)
    return u3;
end;

workspace.DescendantAdded:Connect(function(p30) -- Line: 180
    -- upvalues: u3 (ref), applyOne (copy)
    if u3 then
        task.defer(applyOne, p30);
    end;
end);
LocalPlayer:GetAttributeChangedSignal("LowGraphics"):Connect(function() -- Line: 186
    -- upvalues: u2 (copy), LocalPlayer (copy)
    u2.Set(LocalPlayer:GetAttribute("LowGraphics") == true);
end);
task.spawn(function() -- Line: 191
    -- upvalues: ReplicatedStorage (copy), u2 (copy), Platform (copy)
    local u31 = nil;
    local u32 = nil;
    pcall(function() -- Line: 193
        -- upvalues: ReplicatedStorage (ref), u31 (ref), u32 (ref)
        local StatRetrieveRemote = ReplicatedStorage.Remotes.StatRetrieveRemote;
        u31 = StatRetrieveRemote:InvokeServer("GraphicsChosen");
        u32 = StatRetrieveRemote:InvokeServer("LowGraphics");
    end);

    if u31 == true then
        u2.Set(u32 == true);
    else
        u2.Set(Platform.IsTouch());
    end;
end);

return u2;