-- Decompiled with Potassium's decompiler.

return function(p1) -- Line: 2
end;