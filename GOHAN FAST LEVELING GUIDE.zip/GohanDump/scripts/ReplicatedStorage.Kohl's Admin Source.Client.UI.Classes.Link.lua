-- Decompiled with Potassium's decompiler.

local Parent = require(script.Parent.Parent);
local BaseClass = require(script.Parent:WaitForChild("BaseClass"));
local u1 = {
    Tooltip = Parent.Nil
};
local u2 = {};
u2.__index = u2;
setmetatable(u2, BaseClass);

function u2._updateSelection(p3) -- Line: 14
    local _instance = p3._instance;

    if _instance:IsFocused() and (_instance.SelectionStart ~= 1 or _instance.CursorPosition ~= #_instance.Text + 1) then
        _instance.SelectionStart = 1;
        _instance.CursorPosition = #_instance.Text + 1;
    end;
end;

function u2.Select(p4) -- Line: 22
    p4._instance:CaptureFocus();
    p4:_updateSelection();
end;

function u2.new(u5) -- Line: 27
    -- upvalues: u1 (copy), Parent (copy), u2 (copy)
    local table_clone_ret = table.clone(u1);
    Parent.makeStatefulDefaults(table_clone_ret, u5);

    local function update() -- Line: 31
        -- upvalues: table_clone_ret (copy)
        table_clone_ret:_updateSelection();
    end;

    local v6 = {};
    table_clone_ret._instance = Parent.new("TextBox")({
        AutoLocalize = false,
        AutomaticSize = Enum.AutomaticSize.X,
        BackgroundColor3 = Parent.Theme.Secondary,
        BackgroundTransparency = 0.25,
        FontFace = Parent.Theme.FontMono,
        TextSize = Parent.Theme.FontSize,
        TextColor3 = Parent.Theme.SecondaryText,
        TextStrokeColor3 = Parent.Theme.Secondary,
        TextStrokeTransparency = Parent.Theme.TextStrokeTransparency,
        TextEditable = false,
        ClearTextOnFocus = false,
        Parent.new("UICorner")({
            CornerRadius = Parent.Theme.CornerPadded
        }),
        Parent.new("UIPadding")({
            PaddingLeft = Parent.Theme.Padding,
            PaddingRight = Parent.Theme.Padding
        }),
        Focused = update,

        FocusLost = function() -- Line: 59, Name: FocusLost
            -- upvalues: table_clone_ret (copy)
            table_clone_ret._instance.SelectionStart = -1;
            table_clone_ret._instance.CursorPosition = -1;
        end,

        [Parent.Clean] = v6,
        [Parent.Event] = {
            CursorPosition = update,
            SelectionStart = update
        }
    });
    local u7 = Parent.state(table_clone_ret._instance, "RichText");
    local u8 = Parent.state(table_clone_ret._instance, "Text");
    Parent.new("UISizeConstraint")({
        Parent = table_clone_ret._instance,

        MinSize = function() -- Line: 76, Name: MinSize
            -- upvalues: Parent (ref), u5 (copy), u7 (copy), u8 (copy)
            local v9 = Parent.new("GetTextBoundsParams")({
                Width = (1 / 0),
                Font = u5 and u5.FontFace or Parent.Theme.FontMono,
                Size = u5 and u5.TextSize or Parent.Theme.FontSize,
                RichText = u7,
                Text = u8
            });

            return Vector2.new(Parent.retryGetTextBoundsAsync(v9).X + Parent.Theme.Padding().Offset * 2, Parent.Theme.FontSize + Parent.Theme.Padding().Offset * 2);
        end,

        MaxSize = Vector2.new((1 / 0), (1 / 0))
    });

    if Parent.UserInputService.KeyboardEnabled or table_clone_ret.Tooltip then
        local u10 = Parent.state(false);
        table_clone_ret._tooltip = Parent.new("Tooltip")({
            Parent = table_clone_ret._instance,
            FontFace = Parent.Theme.FontMono,
            Hovering = u10,
            Text = table_clone_ret.Tooltip or "<b>Copy:</b> Ctrl + C"
        });
        table.insert(v6, table_clone_ret._tooltip);
        table.insert(v6, table_clone_ret._instance.Focused:Connect(function() -- Line: 104
            -- upvalues: u10 (copy)
            u10(true);
        end));
        table.insert(v6, table_clone_ret._instance.FocusLost:Connect(function() -- Line: 110
            -- upvalues: u10 (copy)
            u10(false);
        end));
    end;

    return setmetatable(table_clone_ret, u2);
end;

return u2;