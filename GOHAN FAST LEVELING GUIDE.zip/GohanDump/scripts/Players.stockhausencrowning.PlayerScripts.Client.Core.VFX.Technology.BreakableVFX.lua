-- Decompiled with Potassium's decompiler.

game:GetService("ReplicatedStorage");
local Debris = game:GetService("Debris");
local TweenService = game:GetService("TweenService");
local u1 = { "rbxassetid://114303603199822", "rbxassetid://98609496290942" };
local Color3_fromRGB_ret = Color3.fromRGB(44, 44, 45);
local Color3_fromRGB_ret2 = Color3.fromRGB(28, 28, 30);
local Color3_fromRGB_ret3 = Color3.fromRGB(0, 0, 0);
local Color3_fromRGB_ret4 = Color3.fromRGB(255, 255, 255);
local Color3_fromRGB_ret5 = Color3.fromRGB(216, 213, 205);
local Color3_fromRGB_ret6 = Color3.fromRGB(90, 200, 120);
local Color3_fromRGB_ret7 = Color3.fromRGB(226, 62, 48);
local v2 = {};
local u3 = setmetatable({}, {
    __mode = "k"
});

local function stroked(p4) -- Line: 34
    -- upvalues: Color3_fromRGB_ret3 (copy)
    p4.TextStrokeColor3 = Color3_fromRGB_ret3;
    p4.TextStrokeTransparency = 0.5;

    return p4;
end;

local function outline(p5, p6) -- Line: 40
    -- upvalues: Color3_fromRGB_ret3 (copy)
    local UIStroke = Instance.new("UIStroke");
    UIStroke.Color = Color3_fromRGB_ret3;
    UIStroke.Thickness = p6 or 1.5;
    UIStroke.Parent = p5;

    return UIStroke;
end;

local function getRoot(p7) -- Line: 48
    if p7 then
        p7 = p7:FindFirstChild("HumanoidRootPart") or (p7.PrimaryPart or p7:FindFirstChildWhichIsA("BasePart"));
    end;

    return p7;
end;

local function buildBar(p8, p9) -- Line: 52
    -- upvalues: Color3_fromRGB_ret (copy), Color3_fromRGB_ret3 (copy), Color3_fromRGB_ret4 (copy), Color3_fromRGB_ret5 (copy), Color3_fromRGB_ret2 (copy), Color3_fromRGB_ret6 (copy)
    local BillboardGui = Instance.new("BillboardGui");
    BillboardGui.Name = "BreakableBar";
    BillboardGui.Adornee = p9;
    BillboardGui.Size = UDim2.fromOffset(180, 46);
    BillboardGui.StudsOffsetWorldSpace = Vector3.new(0, 7, 0);
    BillboardGui.AlwaysOnTop = true;
    BillboardGui.MaxDistance = 250;
    BillboardGui.ResetOnSpawn = false;
    local Frame = Instance.new("Frame");
    Frame.Size = UDim2.new(1, 0, 1, 0);
    Frame.BackgroundColor3 = Color3_fromRGB_ret;
    Frame.BorderSizePixel = 0;
    Frame.BackgroundTransparency = 1;
    Frame.Parent = BillboardGui;
    local UIStroke = Instance.new("UIStroke");
    UIStroke.Color = Color3_fromRGB_ret3;
    UIStroke.Thickness = 1.5;
    UIStroke.Parent = Frame;
    UIStroke.Transparency = 1;
    local TextLabel = Instance.new("TextLabel");
    TextLabel.BackgroundTransparency = 1;
    TextLabel.Position = UDim2.new(0, 8, 0, 4);
    TextLabel.Size = UDim2.new(0.5, -8, 0, 16);
    TextLabel.Font = Enum.Font.Arcade;
    TextLabel.TextSize = 14;
    TextLabel.TextColor3 = Color3_fromRGB_ret4;
    TextLabel.TextXAlignment = Enum.TextXAlignment.Left;
    TextLabel.Text = p8:GetAttribute("BarLabel") or "MACHINE";
    TextLabel.TextTruncate = Enum.TextTruncate.AtEnd;
    TextLabel.TextTransparency = 1;
    TextLabel.TextStrokeColor3 = Color3_fromRGB_ret3;
    TextLabel.TextStrokeTransparency = 0.5;
    TextLabel.Parent = Frame;
    local TextLabel2 = Instance.new("TextLabel");
    TextLabel2.BackgroundTransparency = 1;
    TextLabel2.Position = UDim2.new(0.5, 0, 0, 4);
    TextLabel2.Size = UDim2.new(0.5, -8, 0, 16);
    TextLabel2.Font = Enum.Font.Bangers;
    TextLabel2.TextSize = 16;
    TextLabel2.TextColor3 = Color3_fromRGB_ret5;
    TextLabel2.TextXAlignment = Enum.TextXAlignment.Right;
    TextLabel2.Text = "";
    TextLabel2.TextTransparency = 1;
    TextLabel2.TextStrokeColor3 = Color3_fromRGB_ret3;
    TextLabel2.TextStrokeTransparency = 0.5;
    TextLabel2.Parent = Frame;
    local Frame2 = Instance.new("Frame");
    Frame2.Position = UDim2.new(0, 8, 0, 26);
    Frame2.Size = UDim2.new(1, -16, 0, 12);
    Frame2.BackgroundColor3 = Color3_fromRGB_ret2;
    Frame2.BorderSizePixel = 0;
    Frame2.BackgroundTransparency = 1;
    Frame2.Parent = Frame;
    local UIStroke2 = Instance.new("UIStroke");
    UIStroke2.Color = Color3_fromRGB_ret3;
    UIStroke2.Thickness = 1.5;
    UIStroke2.Parent = Frame2;
    UIStroke2.Transparency = 1;
    local Frame3 = Instance.new("Frame");
    Frame3.Size = UDim2.new(1, 0, 1, 0);
    Frame3.BackgroundColor3 = Color3_fromRGB_ret6;
    Frame3.BorderSizePixel = 0;
    Frame3.BackgroundTransparency = 1;
    Frame3.Parent = Frame2;
    BillboardGui.Parent = p9;

    return {
        Token = 0,
        Gui = BillboardGui,
        Fill = Frame3,
        Value = TextLabel2,
        Fades = { Frame, Frame2, Frame3 },
        Strokes = { UIStroke, UIStroke2 },
        Texts = { TextLabel, TextLabel2 }
    };
end;

local function setVisible(p10, p11) -- Line: 121
    -- upvalues: TweenService (copy)
    local TweenInfo_new_ret = TweenInfo.new(0.4);
    local v12 = p11 and 0 or 1;

    for _, v in ipairs(p10.Fades) do
        TweenService:Create(v, TweenInfo_new_ret, {
            BackgroundTransparency = v12
        }):Play();
    end;

    for _, v in ipairs(p10.Strokes) do
        TweenService:Create(v, TweenInfo_new_ret, {
            Transparency = v12
        }):Play();
    end;

    for _, v in ipairs(p10.Texts) do
        TweenService:Create(v, TweenInfo_new_ret, {
            TextTransparency = v12,
            TextStrokeTransparency = p11 and 0.5 or 1
        }):Play();
    end;
end;

local function refresh(p13, p14) -- Line: 131
    -- upvalues: TweenService (copy), Color3_fromRGB_ret7 (copy), Color3_fromRGB_ret6 (copy)
    local v15 = tonumber(p13:GetAttribute("MaxHealth")) or 1;
    local v16 = tonumber(p13:GetAttribute("Health")) or v15;
    local v17 = v16 / math.max(1, v15);
    local math_clamp_ret = math.clamp(v17, 0, 1);
    TweenService:Create(p14.Fill, TweenInfo.new(0.18), {
        Size = UDim2.new(math_clamp_ret, 0, 1, 0)
    }):Play();
    p14.Fill.BackgroundColor3 = math_clamp_ret <= 0.3 and Color3_fromRGB_ret7 or Color3_fromRGB_ret6;
    p14.Value.Text = string.format("%d / %d", math.floor(v16), (math.floor(v15)));
end;

local function showBar(u18) -- Line: 140
    -- upvalues: u3 (copy), buildBar (copy), refresh (copy), setVisible (copy)
    local v19;

    if u18 then
        v19 = u18:FindFirstChild("HumanoidRootPart") or (u18.PrimaryPart or u18:FindFirstChildWhichIsA("BasePart"));
    else
        v19 = u18;
    end;

    if not v19 then
        return;
    end;

    local u20 = u3[u18];

    if not (u20 and u20.Gui.Parent) then
        u20 = buildBar(u18, v19);
        u3[u18] = u20;
        u20.Conn = u18:GetAttributeChangedSignal("Health"):Connect(function() -- Line: 147
            -- upvalues: u20 (ref), refresh (ref), u18 (copy)
            if u20.Gui.Parent then
                refresh(u18, u20);
            end;
        end);
    end;

    u20.Gui.Adornee = v19;
    refresh(u18, u20);
    setVisible(u20, true);
    u20.Token = u20.Token + 1;
    local Token = u20.Token;
    task.delay(6, function() -- Line: 156
        -- upvalues: u20 (ref), Token (copy), setVisible (ref)
        if u20.Token ~= Token or not u20.Gui.Parent then
            return;
        end;

        setVisible(u20, false);
    end);
end;

local function destroyBar(p21) -- Line: 162
    -- upvalues: u3 (copy)
    local v22 = u3[p21];

    if not v22 then
        return;
    end;

    u3[p21] = nil;

    if v22.Conn then
        v22.Conn:Disconnect();
    end;

    if v22.Gui then
        v22.Gui:Destroy();
    end;
end;

local function watch(u23) -- Line: 172
    -- upvalues: showBar (copy), u3 (copy)
    if not u23:IsA("Model") then
        return;
    end;

    local function check() -- Line: 174
        -- upvalues: u23 (copy), showBar (ref)
        if not u23:GetAttribute("Breakable") then
            return;
        end;

        local v24 = tonumber(u23:GetAttribute("MaxHealth"));
        local v25 = tonumber(u23:GetAttribute("Health"));

        if v24 and (v25 and (v25 < v24 and v25 > 0)) then
            showBar(u23);
        end;
    end;

    u23:GetAttributeChangedSignal("Health"):Connect(check);
    u23:GetAttributeChangedSignal("Breakable"):Connect(check);
    u23.AncestryChanged:Connect(function(p26, p27) -- Line: 182
        -- upvalues: u23 (copy), u3 (ref)
        if not p27 then
            local v28 = u23;
            local v29 = u3[v28];

            if not v29 then
                return;
            end;

            u3[v28] = nil;

            if v29.Conn then
                v29.Conn:Disconnect();
            end;

            if v29.Gui then
                v29.Gui:Destroy();
            end;
        end;
    end);
    task.defer(check);
end;

task.spawn(function() -- Line: 188
    -- upvalues: watch (copy)
    local Live = workspace:WaitForChild("World"):WaitForChild("Live", 30);

    if not Live then
        return;
    end;

    for _, child in ipairs(Live:GetChildren()) do
        watch(child);
    end;

    Live.ChildAdded:Connect(watch);
end);

local function sparkBurst(p30, p31) -- Line: 196
    -- upvalues: Debris (copy)
    local Attachment = Instance.new("Attachment");
    Attachment.Parent = p30;
    local ParticleEmitter = Instance.new("ParticleEmitter");
    ParticleEmitter.Color = ColorSequence.new(Color3.fromRGB(255, 190, 90), Color3.fromRGB(255, 80, 40));
    ParticleEmitter.LightEmission = 1;
    ParticleEmitter.Size = NumberSequence.new(0.8, 0);
    ParticleEmitter.Transparency = NumberSequence.new(0.1, 1);
    ParticleEmitter.Speed = NumberRange.new(18, 34);
    ParticleEmitter.Lifetime = NumberRange.new(0.25, 0.5);
    ParticleEmitter.SpreadAngle = Vector2.new(180, 180);
    ParticleEmitter.Rate = 0;
    ParticleEmitter.Parent = Attachment;
    local math_floor_ret = math.floor(p31 / 8);
    ParticleEmitter:Emit((math.clamp(math_floor_ret, 6, 40)));
    Debris:AddItem(Attachment, 1.5);
end;

function v2.Impact(p32) -- Line: 213
    -- upvalues: sparkBurst (copy), showBar (copy), u1 (copy), Debris (copy)
    local Model = p32.Model;
    local v33;

    if Model then
        v33 = Model:FindFirstChild("HumanoidRootPart") or (Model.PrimaryPart or Model:FindFirstChildWhichIsA("BasePart"));
    else
        v33 = Model;
    end;

    if not v33 then
        return;
    end;

    sparkBurst(v33, p32.Amount or 30);
    showBar(Model);
    local Sound = Instance.new("Sound");
    Sound.SoundId = u1[math.random(1, #u1)];
    Sound.PlaybackSpeed = math.random(70, 120) / 100;
    Sound.Volume = math.random(80, 120) / 100;
    Sound.RollOffMaxDistance = 300;
    Sound.Parent = v33;
    Sound:Play();
    Debris:AddItem(Sound, 3);
end;

return v2;