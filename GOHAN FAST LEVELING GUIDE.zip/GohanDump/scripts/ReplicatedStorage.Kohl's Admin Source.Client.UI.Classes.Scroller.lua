-- Decompiled with Potassium's decompiler.

local Parent = require(script.Parent.Parent);
local BaseClass = require(script.Parent:WaitForChild("BaseClass"));
local u1 = {};
local u2 = {};
u2.__index = u2;
setmetatable(u2, BaseClass);

function u2.new(p3) -- Line: 12
    -- upvalues: u1 (copy), Parent (copy), u2 (copy)
    local table_clone_ret = table.clone(u1);
    Parent.makeStatefulDefaults(table_clone_ret, p3);
    table_clone_ret._instance = Parent.new("ScrollingFrame")({
        Name = "Scroller",
        BorderSizePixel = 0,
        BackgroundTransparency = 1,
        Size = UDim2.new(1, 0, 1, 0),
        ScrollBarThickness = 8,
        ScrollBarImageColor3 = Parent.Theme.Secondary,
        ScrollBarImageTransparency = Parent.Theme.TransparencyClamped,
        TopImage = Parent.Theme.ScrollTopImage,
        MidImage = Parent.Theme.ScrollMidImage,
        BottomImage = Parent.Theme.ScrollBottomImage,
        CanvasSize = UDim2.new(0, 0, 0, 0),
        AutomaticCanvasSize = Enum.AutomaticSize.Y,
        VerticalScrollBarInset = Enum.ScrollBarInset.ScrollBar,
        Parent.new("UIListLayout")({
            SortOrder = Enum.SortOrder.LayoutOrder,
            Padding = Parent.Theme.Padding
        }),
        [Parent.Event] = {
            CanvasPosition = Parent.clearActiveStates
        }
    });
    local u4 = Parent.new("UIPadding")({
        Parent = table_clone_ret._instance,
        PaddingBottom = Parent.Theme.PaddingWithStroke,
        PaddingTop = Parent.Theme.PaddingWithStroke,
        PaddingLeft = Parent.Theme.PaddingStroke,
        PaddingRight = Parent.Theme.PaddingWithStroke
    });

    local function updatePadding() -- Line: 46
        -- upvalues: Parent (ref), u4 (copy), table_clone_ret (copy)
        local edit = Parent.edit;
        local v5 = {};
        local v6;

        if table_clone_ret._instance.AbsoluteCanvasSize.Y > table_clone_ret._instance.AbsoluteWindowSize.Y then
            v6 = Parent.Theme.PaddingWithStroke;
        else
            v6 = UDim.new();
        end;

        v5.PaddingRight = v6;
        edit(u4, v5);
    end;

    updatePadding();
    Parent.edit(u4, {
        [Parent.Clean] = { table_clone_ret._instance:GetPropertyChangedSignal("AbsoluteWindowSize"):Connect(updatePadding), table_clone_ret._instance:GetPropertyChangedSignal("AbsoluteCanvasSize"):Connect(updatePadding) }
    });

    return setmetatable(table_clone_ret, u2);
end;

return u2;