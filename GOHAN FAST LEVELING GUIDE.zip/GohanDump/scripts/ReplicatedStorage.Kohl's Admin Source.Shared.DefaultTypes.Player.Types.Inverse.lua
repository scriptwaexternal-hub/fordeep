-- Decompiled with Potassium's decompiler.

local Players = game:GetService("Players");
({
    postParse = function(p1, p2) -- Line: 6, Name: postParse
        -- upvalues: Players (copy)
        local v3 = {};

        if type(p1) ~= "table" then
            if typeof(p1) == "Instance" then
                for _, v in Players:GetPlayers() do
                    if v ~= p1 then
                        local v4 = p2._K.Auth.targetUserArgument(p2, v.UserId, v);

                        if v4 then
                            table.insert(v3, v4);
                        end;
                    end;
                end;
            end;

            return v3;
        end;

        for _, v in Players:GetPlayers() do
            local v5 = v;
            local v6 = nil;

            for _, v2 in p1 do
                if v5 == v2 then
                    v6 = true;
                    break;
                end;
            end;

            if not v6 then
                local v7 = p2._K.Auth.targetUserArgument(p2, v5.UserId, v5);

                if v7 then
                    table.insert(v3, v7);
                end;
            end;
        end;

        return v3;
    end
}).prefixes = {
    ["%$"] = "magicPlayers",
    ["@"] = "rolePlayers",
    ["%%"] = "teamPlayers"
};

return function(p8) -- Line: 43
end;