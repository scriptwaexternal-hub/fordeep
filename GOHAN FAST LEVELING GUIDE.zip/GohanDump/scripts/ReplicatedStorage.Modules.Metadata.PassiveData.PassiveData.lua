-- Decompiled with Potassium's decompiler.

local u1 = {
    Kinds = {
        Stat = "Stat",
        Module = "Module"
    }
};
u1.Passives = {
    ["Momentum Fighter"] = {
        Title = "Momentum Fighter",
        Description = "Landing hits builds Momentum (max 10). Each stack is +1 percent movement speed. Fades after 6 seconds without dealing damage.",
        Kind = u1.Kinds.Module
    },
    ["Relentless Pursuit"] = {
        Title = "Relentless Pursuit",
        Description = "Hitting an enemy grants +10 percent dash and sprint speed for 3 seconds. Refreshes on hit.",
        Kind = u1.Kinds.Module
    },
    ["Space Raider"] = {
        Title = "Space Raider",
        Description = "Landing a combo starter marks the target for 5 seconds. Marked targets take 10 percent more guard damage from you, and you move 5 percent faster while the mark holds.",
        Kind = u1.Kinds.Module
    },
    ["Criminal Ferocity"] = {
        Title = "Criminal Ferocity",
        Description = "Guard breaking an opponent grants +10 percent damage and +10 percent movement speed for 5 seconds.",
        Kind = u1.Kinds.Module
    },
    ["Pirate\'s Instinct"] = {
        Title = "Pirate\'s Instinct",
        Description = "8 consecutive hits grant Adrenaline: +10 percent attack speed for 5 seconds. Cannot refresh while active.",
        Kind = u1.Kinds.Module
    },
    ["Raging Soul"] = {
        Title = "Raging Soul",
        Description = "While in Ki Burst your melee changes: a 15-hit string at 2.5x speed that only launches on the final hit, then a 3 second recovery. Each hit does 80 percent damage and your ki will not shape into blasts.",
        Kind = u1.Kinds.Module
    },
    Majuub = {
        Title = "Majuub",
        Description = "Buu\'s body and yours are one. Far tougher, heals fast, strikes true, and your output ceiling is 200%.",
        Kind = u1.Kinds.Stat,
        Modifiers = { {
                Stat = "DurabilityBoost",
                Add = "DuraBoost"
            }, {
                Stat = "StrengthBoost",
                Add = "BlessPct"
            }, {
                Stat = "DurabilityBoost",
                Add = "BlessPct"
            }, {
                Stat = "AgilityBoost",
                Add = "BlessPct"
            }, {
                Stat = "KiDmgBoost",
                Add = "BlessPct"
            }, {
                Stat = "RegenMultiplier",
                Mul = "RegenMult"
            }, {
                Stat = "CriticalHitChance",
                Add = "CritChance"
            } }
    },
    ["Potential Unlock"] = {
        Title = "Potential Unlock",
        Description = "An Elder drew out your hidden power. Output ceiling 110%.",
        Kind = u1.Kinds.Stat
    },
    ["Ancient Potential Unlock"] = {
        Title = "Ancient Potential Unlock",
        Description = "A Namekian\'s own potential, fully awakened. Output ceiling 120%.",
        Kind = u1.Kinds.Stat
    },
    ["Namekian Fusion"] = {
        Title = "Namekian Fusion",
        Description = "You carry a fused Namekian within you. Output ceiling 150%, or 190% after a second fusion. Namekian Resilience: take less damage, shrug off stagger and knockback, and grow tougher as your health falls. Second fusion adds Fusion Adaptation: repeated ki, melee or grab attacks build a temporary resistance to that type. Last Cell: below 20% health, surge with faster regeneration, tougher skin, less stagger and cheaper ki for 10s (3 min cooldown).",
        Kind = u1.Kinds.Stat
    },
    Traitless = {
        Title = "Traitless",
        Description = "No trait, but nothing wasted - sharper strikes and faster growth.",
        Kind = u1.Kinds.Stat,
        Modifiers = { {
                Stat = "CriticalHitChance",
                Add = "CritBase"
            }, {
                Stat = "ExpGain",
                Mul = "GainBase"
            } }
    },
    Adept = {
        Title = "Adept",
        Description = "Provides a slight boost in all exp gain.",
        Kind = u1.Kinds.Stat,
        Modifiers = { {
                Stat = "ExpGain",
                Mul = "GainBase"
            } }
    },
    Proficient = {
        Title = "Proficient",
        Description = "Provides a moderate boost in all exp gain.",
        Kind = u1.Kinds.Stat,
        Modifiers = { {
                Stat = "ExpGain",
                Mul = "GainBase"
            } }
    },
    Prodigy = {
        Title = "Prodigy",
        Description = "Provides a large boost in all exp gain.",
        Kind = u1.Kinds.Stat,
        Modifiers = { {
                Stat = "ExpGain",
                Mul = "GainBase"
            } }
    },
    ["Blessed Energy"] = {
        Title = "Blessed Energy",
        Description = "Blessed Humans carry raw potential in every stat.",
        Kind = u1.Kinds.Stat,
        Modifiers = { {
                Stat = "StrengthBoost",
                Add = "BoostPct"
            }, {
                Stat = "DurabilityBoost",
                Add = "BoostPct"
            }, {
                Stat = "AgilityBoost",
                Add = "BoostPct"
            }, {
                Stat = "KiDmgBoost",
                Add = "BoostPct"
            } }
    },
    Perfect = {
        Title = "Perfect",
        Description = "The perfected form excels at everything.",
        Kind = u1.Kinds.Stat,
        Modifiers = { {
                Stat = "StrengthBoost",
                Add = "BoostPct"
            }, {
                Stat = "DurabilityBoost",
                Add = "BoostPct"
            }, {
                Stat = "KiDmgBoost",
                Add = "BoostPct"
            }, {
                Stat = "AgilityBoost",
                Add = "BoostPct"
            } }
    },
    Overconfident = {
        Title = "Overconfident",
        Description = "Narcissists fight better when they believe they cannot lose.",
        Kind = u1.Kinds.Stat,
        Modifiers = { {
                Stat = "StrengthBoost",
                Add = "BoostPct"
            }, {
                Stat = "DurabilityBoost",
                Add = "BoostPct"
            }, {
                Stat = "KiDmgBoost",
                Add = "BoostPct"
            }, {
                Stat = "AgilityBoost",
                Add = "BoostPct"
            } }
    },
    Suboptimal = {
        Title = "Suboptimal",
        Description = "Raw and unrefined - power without precision.",
        Kind = u1.Kinds.Stat,
        Modifiers = { {
                Stat = "StrengthBoost",
                Add = "BoostPct"
            }, {
                Stat = "DurabilityBoost",
                Add = "BoostPct"
            }, {
                Stat = "KiDmgBoost",
                Add = "BoostPct"
            }, {
                Stat = "AgilityBoost",
                Add = "BoostPct"
            } }
    },
    ["Hell Soldier"] = {
        Title = "Hell Soldier",
        Description = "Forged in Hell\'s armies.",
        Kind = u1.Kinds.Stat,
        Modifiers = { {
                Stat = "StrengthBoost",
                Add = "BoostPct"
            }, {
                Stat = "DurabilityBoost",
                Add = "BoostPct"
            } }
    },
    ["Weak Hell Soldier"] = {
        Title = "Weak Hell Soldier",
        Description = "Drilled in Hell\'s armies, never forged.",
        Kind = u1.Kinds.Stat,
        Modifiers = { {
                Stat = "StrengthBoost",
                Add = "BoostPct"
            }, {
                Stat = "DurabilityBoost",
                Add = "BoostPct"
            } }
    },
    ["Demonic Anomaly"] = {
        Title = "Demonic Anomaly",
        Description = "A being that should not exist - reality strains around it.",
        Kind = u1.Kinds.Stat,
        Modifiers = { {
                Stat = "StrengthBoost",
                Add = "BoostPct"
            }, {
                Stat = "DurabilityBoost",
                Add = "BoostPct"
            } }
    },
    ["Frost Soldier"] = {
        Title = "Frost Soldier",
        Description = "Cold-forged resilience of the frost demon line.",
        Kind = u1.Kinds.Stat,
        Modifiers = { {
                Stat = "StrengthBoost",
                Add = "BoostPct"
            }, {
                Stat = "DurabilityBoost",
                Add = "BoostPct"
            } }
    },
    ["Overflowing Power"] = {
        Title = "Overflowing Power",
        Description = "C-Type Saiyans run hot with surplus power. Taking and dealing damage in a fight fills a rage meter; each time it fills, your power surges higher.",
        Kind = u1.Kinds.Stat,
        Modifiers = { {
                Stat = "StrengthBoost",
                Add = "BoostPct"
            }, {
                Stat = "DurabilityBoost",
                Add = "BoostPct"
            } }
    },
    ["Kaioken Affinity"] = {
        Title = "Kaioken Affinity",
        Description = "Untainted human ki: greater ki control and a stronger Kaioken.",
        Kind = u1.Kinds.Stat,
        Modifiers = { {
                Stat = "TempKiControl",
                Add = "BoostPct"
            } }
    },
    ["Hybrid Strength"] = {
        Title = "Hybrid Strength",
        Description = "Half-Saiyan heritage gives a steady baseline edge.",
        Kind = u1.Kinds.Stat,
        Modifiers = { {
                Stat = "StrengthBoost",
                Add = "BoostPct"
            }, {
                Stat = "DurabilityBoost",
                Add = "BoostPct"
            } }
    },
    ["Predator Instinct"] = {
        Title = "Predator Instinct",
        Description = "A hunter\'s build - tough and ready to open.",
        Kind = u1.Kinds.Stat,
        Modifiers = { {
                Stat = "DurabilityBoost",
                Add = "BoostPct"
            } }
    },
    ["Ultimate Defiance"] = {
        Title = "Ultimate Defiance",
        Description = "Cooler\'s line refuses to yield.",
        Kind = u1.Kinds.Stat,
        Modifiers = { {
                Stat = "DurabilityBoost",
                Add = "BoostPct"
            } }
    },
    ["Deadly Precision"] = {
        Title = "Deadly Precision",
        Description = "Death Beam hits twice as hard and comes back faster.",
        Kind = u1.Kinds.Module
    },
    ["Unrelenting Blasts"] = {
        Title = "Unrelenting Blasts",
        Description = "Fire 5 ki blasts in a burst instead of 3.",
        Kind = u1.Kinds.Module
    },
    ["Emperor\'s Potential"] = {
        Title = "Emperor\'s Potential",
        Description = "The emperor\'s bloodline awakens new forms faster. Fourth Form mastered becomes your base form.",
        Kind = u1.Kinds.Module
    },
    ["Frozen Armor"] = {
        Title = "Frozen Armor",
        Description = "Cooler\'s armored lineage sheds incoming damage.",
        Kind = u1.Kinds.Stat,
        Modifiers = { {
                Stat = "DefenseMultiplier",
                Mul = "DefenseBase"
            } }
    },
    Mahoraga = {
        Title = "Mahoraga",
        Description = "Adapts to everything it survives. Damage taken in a fight builds stat stacks and adapts you to that kind of attack: less damage from repeated melee and ki, and a chance to slip repeated grabs.",
        Kind = u1.Kinds.Stat,
        Modifiers = { {
                Stat = "DurabilityBoost",
                Add = "BoostPct"
            } }
    },
    ["Lethal Understanding"] = {
        Title = "Lethal Understanding",
        Description = "Perfected cells recover techniques faster.",
        Kind = u1.Kinds.Stat,
        Modifiers = { {
                Stat = "CooldownFactor",
                Mul = "CooldownBase"
            } }
    },
    ["Instinct Reflex"] = {
        Title = "Instinct Reflex",
        Description = "A narcissist never lets a hit spoil the look.",
        Kind = u1.Kinds.Stat,
        Modifiers = { {
                Stat = "DodgeMultiplier",
                Mul = "DodgeBase"
            } }
    },
    ["Tuff Body"] = {
        Title = "Tuff Body",
        Description = "Thickened hide - incoming damage is reduced.",
        Kind = u1.Kinds.Stat,
        Modifiers = { {
                Stat = "DefenseMultiplier",
                Mul = "DefenseBase"
            } }
    },
    ["Reinforced Plating"] = {
        Title = "Reinforced Plating",
        Description = "Tank-unit armour plating.",
        Kind = u1.Kinds.Stat,
        Modifiers = { {
                Stat = "DefenseMultiplier",
                Mul = "DefenseBase"
            } }
    },
    ["Bibidi\'s Creation"] = {
        Title = "Bibidi\'s Creation",
        Description = "Built by a wizard to be a weapon. Majin bodies carry surplus strength and toughness.",
        Kind = u1.Kinds.Stat,
        Modifiers = { {
                Stat = "StrengthBoost",
                Add = "BoostPct"
            }, {
                Stat = "DurabilityBoost",
                Add = "BoostPct"
            } }
    },
    ["Elastic Body"] = {
        Title = "Elastic Body",
        Description = "Majin flesh slips punches.",
        Kind = u1.Kinds.Stat,
        Modifiers = { {
                Stat = "DodgeMultiplier",
                Mul = "DodgeBase"
            } }
    },
    ["Majin Bodies"] = {
        Title = "Majin Bodies",
        Description = "Every 3 absorptions stores a spare body. A killing blow spends one and you reform from the goo.",
        Kind = u1.Kinds.Stat,
        Modifiers = {}
    },
    ["Third Eye"] = {
        Title = "Third Eye",
        Description = "Sees the strike before it lands.",
        Kind = u1.Kinds.Stat,
        Modifiers = { {
                Stat = "DodgeMultiplier",
                Mul = "DodgeBase"
            } }
    },
    ["Adaptive Combat AI"] = {
        Title = "Adaptive Combat AI",
        Description = "Fighter-unit targeting reads the attack and slips it.",
        Kind = u1.Kinds.Stat,
        Modifiers = { {
                Stat = "DodgeMultiplier",
                Mul = "DodgeBase"
            } }
    },
    Boxer = {
        Title = "Boxer",
        Description = "Trained striker - lands clean hits more often.",
        Kind = u1.Kinds.Stat,
        Modifiers = { {
                Stat = "CriticalHitChance",
                Add = "CritChance"
            } }
    },
    ["Precision Strikes"] = {
        Title = "Precision Strikes",
        Description = "Fighter-unit targeting - finds the weak point.",
        Kind = u1.Kinds.Stat,
        Modifiers = { {
                Stat = "CriticalHitChance",
                Add = "CritChance"
            } }
    },
    ["Super Android"] = {
        Title = "Super Android",
        Description = "One core, two designs. Output 170%, a longer barrier that heals you as it holds, and every Android skill hits 1.5x harder.",
        Kind = u1.Kinds.Module
    }
};
u1.Grants = {
    Race = {
        Arcosian = {
            ["Tuff Body"] = {
                DefenseBase = 1.2
            },
            ["Frost Soldier"] = {
                BoostPct = 0.05
            }
        },
        ["Bio-Android"] = {
            ["Tuff Body"] = {
                DefenseBase = 1.65
            },
            Boxer = {
                CritChance = 11
            }
        },
        Saiyan = {
            Boxer = {
                CritChance = 7
            }
        },
        Majin = {
            ["Elastic Body"] = {
                DodgeBase = 1.25
            },
            ["Majin Bodies"] = {},
            ["Bibidi\'s Creation"] = {
                BoostPct = 0.22
            }
        },
        Human = {
            ["Third Eye"] = {
                DodgeBase = 1.5
            }
        },
        Android = {
            ["Super Android"] = {
                Output = 170,
                BarrierMult = 2,
                BarrierHealPct = 0.5,
                SkillMult = 1.5
            }
        }
    },
    RaceTrait = {
        Alien = {
            Hera = {
                ["Momentum Fighter"] = {
                    MaxStacks = 10,
                    SpeedPerStack = 0.01,
                    DecaySeconds = 6
                },
                ["Relentless Pursuit"] = {
                    SpeedPct = 0.1,
                    Duration = 3
                },
                ["Space Raider"] = {
                    MarkSeconds = 5,
                    GuardDamagePct = 0.1,
                    SpeedPct = 0.05,
                    StarterGap = 1.2
                },
                ["Criminal Ferocity"] = {
                    DamagePct = 0.1,
                    SpeedPct = 0.1,
                    Duration = 5
                },
                ["Pirate\'s Instinct"] = {
                    HitsNeeded = 8,
                    HitGap = 1.5,
                    AttackSpeedPct = 0.1,
                    Duration = 5
                },
                ["Raging Soul"] = {
                    ComboLength = 15,
                    AnimSpeed = 2.5,
                    Cooldown = 3,
                    DamageMult = 0.8
                }
            }
        },
        Human = {
            Blessed = {
                ["Blessed Energy"] = {
                    BoostPct = 0.11
                },
                Boxer = {
                    CritChance = 9
                }
            },
            None = {
                ["Kaioken Affinity"] = {
                    BoostPct = 0.08,
                    KaiokenMult = 1.25
                }
            }
        },
        ["Bio-Android"] = {
            Perfectionist = {
                Perfect = {
                    BoostPct = 0.1
                },
                Mahoraga = {
                    BoostPct = 0.06,
                    AdaptPct = 0.065,
                    MaxStacks = 8
                },
                ["Lethal Understanding"] = {
                    CooldownBase = 0.75
                }
            },
            Narcissist = {
                Overconfident = {
                    BoostPct = 0.07
                },
                ["Predator Instinct"] = {
                    BoostPct = 0.1,
                    HuntPct = 0.09
                },
                ["Instinct Reflex"] = {
                    DodgeBase = 1.55
                }
            },
            Primitive = {
                Suboptimal = {
                    BoostPct = 0.05
                }
            }
        },
        Saiyan = {
            ["C-Type"] = {
                ["Overflowing Power"] = {
                    BoostPct = 0.135
                }
            },
            ["Half Saiyan"] = {
                ["Hybrid Strength"] = {
                    BoostPct = 0.015
                }
            }
        },
        Demon = {
            Dabura = {
                ["Hell Soldier"] = {
                    BoostPct = 0.25
                }
            },
            Janemba = {
                ["Demonic Anomaly"] = {
                    BoostPct = 0.336875
                }
            },
            None = {
                ["Weak Hell Soldier"] = {
                    BoostPct = 0.2
                }
            }
        },
        Arcosian = {
            Cooler = {
                ["Ultimate Defiance"] = {
                    BoostPct = 0.05,
                    DefyStrMult = 1.8,
                    DefyKiMult = 1.6,
                    DefyDurAdd = 80,
                    DefyKiAdd = 280,
                    DefyAgiAdd = 1.3,
                    DefyCrit = 20
                },
                Boxer = {
                    CritChance = 7
                },
                ["Frozen Armor"] = {
                    DefenseBase = 1.4
                }
            },
            Frieza = {
                ["Deadly Precision"] = {
                    DeathBeamMult = 2,
                    DeathBeamCD = 0.8
                },
                ["Unrelenting Blasts"] = {
                    Blasts = 5
                },
                ["Emperor\'s Potential"] = {}
            }
        },
        Namekian = {
            Warrior = {
                Boxer = {
                    CritChance = 4
                }
            }
        },
        Android = {
            ["Tank Unit"] = {
                ["Reinforced Plating"] = {
                    DefenseBase = 1.75
                }
            },
            ["Fighter Unit"] = {
                ["Precision Strikes"] = {
                    CritChance = 22
                },
                ["Adaptive Combat AI"] = {
                    DodgeBase = 1.5
                }
            }
        }
    },
    Misc = {
        Majuub = {
            DuraBoost = 90,
            RegenMult = 2.5,
            CritChance = 42,
            BlessPct = 0.18,
            Output = 200
        },
        ["Potential Unlock"] = {
            Output = 110
        },
        ["Ancient Potential Unlock"] = {
            Output = 120
        },
        ["Namekian Fusion"] = {
            ResistBase = 0.1,
            ResistLowHpMax = 0.15,
            ResistLowHpFrom = 0.75,
            ResistLowHpFull = 0.2,
            ResistCap = 0.25,
            StaggerMult = 0.75,
            KnockbackMult = 0.75,
            AdaptDecayDelay = 4,
            AdaptDecayStep = 2,
            LastCellThreshold = 0.2,
            LastCellDuration = 10,
            LastCellCooldown = 180,
            LastCellRegenMult = 3,
            LastCellDR = 0.15,
            LastCellStaggerMult = 0.6,
            LastCellKiCostMult = 0.5,
            OutputByFusions = { 150, 190 },
            AdaptHitsPerStack = {
                Melee = 3,
                Ki = 3,
                Grab = 1
            },
            AdaptMaxStacks = {
                Melee = 5,
                Ki = 5,
                Grab = 3
            },
            AdaptPerStack = {
                Melee = 0.05,
                Ki = 0.05,
                Grab = 0.15
            }
        },
        Boxer = {
            CritChance = 7
        },
        Adept = {
            GainBase = 1.11
        },
        Proficient = {
            GainBase = 1.23
        },
        Prodigy = {
            GainBase = 1.35
        },
        Traitless = {
            CritBase = 7,
            GainBase = 1.25
        }
    }
};

function u1.GetParams(p2, p3, p4, p5) -- Line: 722
    -- upvalues: u1 (copy)
    local Grants = u1.Grants;

    if p3 == "Race" then
        local v6 = Grants.Race[p4];

        if v6 then
            v6 = v6[p2];
        end;

        return v6;
    end;

    if p3 ~= "RaceTrait" then
        if p3 == "Misc" then
            return Grants.Misc[p2];
        end;

        return nil;
    end;

    local v7 = Grants.RaceTrait[p4];

    if v7 then
        v7 = v7[p5];
    end;

    if v7 then
        v7 = v7[p2];
    end;

    return v7;
end;

return u1;