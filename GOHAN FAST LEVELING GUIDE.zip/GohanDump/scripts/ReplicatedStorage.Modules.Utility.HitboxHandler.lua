-- Decompiled with Potassium's decompiler.

local Players = game:GetService("Players");
game:GetService("Debris");
local ReplicatedStorage = game:GetService("ReplicatedStorage");
game:GetService("ServerStorage");
game:GetService("ServerScriptService");
game:GetService("RunService");
local Modules = ReplicatedStorage:WaitForChild("Modules");
ReplicatedStorage:WaitForChild("Remotes");
local _ = Modules.Metadata;
local _ = Modules.Shared;
local _ = Modules.Utility;
local DebugHandler = require(Modules.Utility.DebugHandler);
local GlobalFunctions = require(Modules.GlobalFunctions);
local Vizualize_Combat = DebugHandler.Vizualize_Combat;
local workspace_World = workspace.World;
local Visuals = workspace_World.Visuals;
local Zones = workspace_World.Map.Zones;

return {
    New = function(p1) -- Line: 35, Name: New
        -- upvalues: Visuals (copy), Zones (copy), Vizualize_Combat (copy), GlobalFunctions (copy)
        local Location = p1.Location;
        local v2 = p1.Size or Vector3.new(1, 1, 1);
        local v3 = p1.IgnoreList or { Visuals, Zones };

        if p1.IgnoreList then
            table.insert(v3, Zones);
            table.insert(v3, Visuals);
        end;

        local OverlapParams_new_ret = OverlapParams.new();
        OverlapParams_new_ret.FilterDescendantsInstances = v3;
        OverlapParams_new_ret.FilterType = Enum.RaycastFilterType.Exclude;
        local v4 = { Location, v2 };
        local v5;

        if Vizualize_Combat then
            v5 = GlobalFunctions.Visualize_HitBox(Location, v2);
        else
            v5 = nil;
        end;

        return v4, workspace:GetPartBoundsInBox(Location, v2, OverlapParams_new_ret), v5;
    end,

    GetScale = function(p6) -- Line: 71, Name: GetScale
        -- upvalues: Players (copy)
        local PlayerFromCharacter = Players:GetPlayerFromCharacter(p6);

        if not PlayerFromCharacter then
            return 1;
        end;

        local PlayerStats = PlayerFromCharacter:FindFirstChild("PlayerStats");

        if PlayerStats then
            PlayerStats = PlayerStats:FindFirstChild("Hitbox", true);
        end;

        return PlayerStats and PlayerStats.Value or 1;
    end
};