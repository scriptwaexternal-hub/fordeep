-- Decompiled with Potassium's decompiler.

local Players = game:GetService("Players");
local Debris = game:GetService("Debris");
local ReplicatedStorage = game:GetService("ReplicatedStorage");
local TweenService = game:GetService("TweenService");
local RunService = game:GetService("RunService");
local Modules = ReplicatedStorage:WaitForChild("Modules");
local Assets = ReplicatedStorage.Assets;
local Metadata = Modules.Metadata;
local Shared = Modules.Shared;
local _ = Modules.Utility;
local SoundManager = require(Shared.SoundManager);
local AnimationManager = require(Shared.AnimationManager);
local GlobalFunctions = require(Modules.GlobalFunctions);
local CraterHandler = require(Modules.Effects.VfxHandler.CraterHandler);
local Blood = require(Modules.Effects.VfxHandler.Blood);
local DamageIndicator = require(Modules.Effects.VfxHandler.DamageIndicator);
local CamShakeHandler = require(Shared.CamShakeHandler);
local KamiCard = require(Shared.KamiCard);
require(script.Parent.Parent.Misc.Z_VanishVFX);
local VfxHandler = require(Modules.Effects.VfxHandler);
local ControlData = require(Metadata.ControlData.ControlData);
require(Shared["Destroy Terrain"]);
local workspace_CurrentCamera = workspace.CurrentCamera;
local Visuals = workspace.World.Visuals;
local Effects = Assets.Effects;
local Particles = Effects.Particles;
local Meshes = Effects.Meshes;
local Sounds = Assets.Sounds;
local Gui = Assets.Gui;
local Combat = Assets.Gui.Combat;
local LocalPlayer = Players.LocalPlayer;
local _ = ReplicatedStorage.Remotes.ClientRemote;
local _ = ReplicatedStorage.Remotes.ServerRemote;
local u1 = nil;
local u2 = 0;

local function clearComboUI() -- Line: 119
    -- upvalues: LocalPlayer (copy), u1 (ref)
    local PlayerGui = LocalPlayer:FindFirstChild("PlayerGui");

    if PlayerGui then
        PlayerGui = PlayerGui:FindFirstChild("PopupGui");
    end;

    if PlayerGui then
        PlayerGui = PlayerGui:FindFirstChild("ComboLabel");
    end;

    if PlayerGui then
        PlayerGui:Destroy();
    end;

    local PlayerStats = LocalPlayer:FindFirstChild("PlayerStats");

    if PlayerStats then
        PlayerStats = PlayerStats:FindFirstChild("Combo", true);
    end;

    if PlayerStats then
        PlayerStats.Value = 0;
    end;

    u1 = nil;
end;

LocalPlayer.CharacterAdded:Connect(function(p3) -- Line: 135
    -- upvalues: u2 (ref), clearComboUI (copy)
    u2 = u2 + 1;
    clearComboUI();
    local v4 = p3:FindFirstChildOfClass("Humanoid") or p3:WaitForChild("Humanoid", 10);

    if v4 then
        v4.Died:Connect(function() -- Line: 141
            -- upvalues: u2 (ref), clearComboUI (ref)
            u2 = u2 + 1;
            clearComboUI();
        end);
    end;
end);

local function Hit_Counter_Function(p5) -- Line: 148
    -- upvalues: LocalPlayer (copy), u1 (ref), u2 (ref), clearComboUI (copy), Combat (copy), SoundManager (copy)
    local HumanoidRootPart = p5:FindFirstChild("HumanoidRootPart");
    local PlayerGui = LocalPlayer:FindFirstChild("PlayerGui");

    if PlayerGui then
        PlayerGui = PlayerGui:FindFirstChild("PopupGui");
    end;

    local PlayerStats = LocalPlayer:FindFirstChild("PlayerStats");

    if PlayerStats then
        PlayerStats = PlayerStats:FindFirstChild("Combo", true);
    end;

    if not (PlayerGui and PlayerStats) then
        return;
    end;

    PlayerStats.Value = PlayerStats.Value + 1;
    u1 = time();
    u2 = u2 + 1;
    local u6 = u2;
    task.delay(3, function() -- Line: 164
        -- upvalues: u2 (ref), u6 (copy), clearComboUI (ref)
        if u2 ~= u6 then
            return;
        end;

        clearComboUI();
    end);
    local ComboLabel = PlayerGui:FindFirstChild("ComboLabel");

    if not ComboLabel then
        if PlayerStats.Value <= 1 then
            return;
        end;

        ComboLabel = Combat:FindFirstChild("ComboLabel"):Clone();
        ComboLabel.Parent = PlayerGui;
    end;

    ComboLabel.Text = PlayerStats.Value;
    local math_clamp_ret = math.clamp(0.9 + PlayerStats.Value / 100, 0, 2);

    if PlayerStats.Value % 10 == 0 then
        SoundManager.AddSound("Sonic Ring Combo", {
            Parent = HumanoidRootPart,
            PlaybackSpeed = math_clamp_ret
        }, "Client");
    end;

    local v7 = PlayerStats.Value * 2;
    ComboLabel.TextColor3 = Color3.fromRGB(255, math.clamp(255 - v7 * 1.5, 0, 255), (math.clamp(255 - v7, 0, 255)));
    local v8 = ComboLabel:FindFirstChild("LoadingBar") and ComboLabel.LoadingBar:FindFirstChild("Bar");

    if v8 then
        v8.Size = UDim2.new(1, 0, 1, 0);
        v8:TweenSize(UDim2.new(0, 0, 1, 0), Enum.EasingDirection.Out, Enum.EasingStyle.Linear, 3, true);
    end;
end;

local function Default_Punch_Effect(p9) -- Line: 205
    -- upvalues: Players (copy), SoundManager (copy), AnimationManager (copy), VfxHandler (copy), Meshes (copy), Visuals (copy), Debris (copy), GlobalFunctions (copy), LocalPlayer (copy), Hit_Counter_Function (copy)
    local Character = p9.Character;
    local Victim = p9.Victim;

    if not Victim then
        return;
    end;

    if Victim:GetAttribute("State_Evade") then
        return;
    end;

    if Victim:GetAttribute("State_PerfectBlocking") then
        return;
    end;

    if Victim:GetAttribute("State_Dodging") then
        return;
    end;

    if Character and (Players:GetPlayerFromCharacter(Character) and Players:GetPlayerFromCharacter(Victim)) and Victim:GetAttribute("NoobProtected") == true ~= (Character:GetAttribute("NoobProtected") == true) then
        return;
    end;

    local HumanoidRootPart = Victim:FindFirstChild("HumanoidRootPart");
    local Humanoid = Victim:FindFirstChild("Humanoid");
    SoundManager.AddSound(p9.PunchType == "Heavy" and "Heavy_Punch" or "Punch", {
        Parent = HumanoidRootPart,
        PlaybackSpeed = math.random(90, 150) / 100
    }, "Client");

    if not Victim:FindFirstChild("No Body") then
        if Victim:GetAttribute("State_Blocking") then
            AnimationManager.PlayAnimation(Victim, "Block React " .. math.random(1, 2));

            return;
        end;

        AnimationManager.PlayAnimation(Victim, "Damaged" .. math.random(1, 4));
    end;

    local v10 = p9.MAX_ORBS or 4;
    local Color3_fromRGB_ret = Color3.fromRGB(255, 255, 255);
    local Neon = Enum.Material.Neon;

    if Humanoid.Health < Humanoid.MaxHealth * 0.3 then
        Color3_fromRGB_ret = p9.Color or Color3.fromRGB(155, 0, 0);
        Neon = Enum.Material.Glass;
    end;

    VfxHandler.DamageIndicator.Visual(Victim);

    for i = 1, v10 do
        local v11 = Meshes.Combat.Orb:Clone();
        v11.Parent = Visuals;
        v11.CFrame = HumanoidRootPart.CFrame;
        v11.Color = Color3_fromRGB_ret;
        v11.Material = Neon;
        Debris:AddItem(v11, 1);
        local v12 = Meshes.Combat.Oval:Clone();
        v12.Parent = Visuals;
        v12.CFrame = HumanoidRootPart.CFrame * CFrame.new(math.random(-1, 1), math.random(-1, 1), math.random(-1, 1));
        v12.CFrame = CFrame.lookAt(v12.Position, HumanoidRootPart.Position);
        v12.Color = Color3_fromRGB_ret;
        v12.Material = Neon;
        Debris:AddItem(v12, 1);
        GlobalFunctions.Tween({
            Duration = 0.75,
            Instance = v11,
            EasingStyle = Enum.EasingStyle.Exponential,
            EasingDirection = Enum.EasingDirection.Out
        }, {
            Size = Vector3.new(0, 0, 0),
            CFrame = v11.CFrame * CFrame.new(math.random(-5, 5), math.random(-5, 5), math.random(-5, 5))
        });
        GlobalFunctions.Tween({
            Duration = 1,
            Instance = v12,
            EasingStyle = Enum.EasingStyle.Exponential,
            EasingDirection = Enum.EasingDirection.Out
        }, {
            Size = Vector3.new(0, 0, 3),
            CFrame = v12.CFrame * CFrame.new(0, 0, 10)
        });
        local _ = i;
    end;

    if LocalPlayer.Character == Character and p9.CountCombo then
        Hit_Counter_Function(Character);
    end;
end;

local function Black_Lines(p13, p14) -- Line: 309
    -- upvalues: Visuals (copy), Debris (copy), GlobalFunctions (copy)
    for i = 1, 5 do
        local math_random_ret = math.random(1, 10);
        local math_random_ret2 = math.random(-10, 10);
        local math_random_ret3 = math.random(1, 5);
        local Part = Instance.new("Part");
        Part.Color = Color3.fromRGB(0, 0, 0);
        Part.Material = Enum.Material.Neon;
        Part.Parent = Visuals;
        Part.Anchored = true;
        Part.CanCollide = false;
        Part.Size = Vector3.new(0.05, 0.05, math_random_ret);
        Debris:AddItem(Part, 1);

        if p14 == "Forward" or p14 == "Backward" then
            Part.CFrame = p13.HumanoidRootPart.CFrame * CFrame.new(math_random_ret2, math_random_ret3, -5);
        else
            Part.CFrame = p13.HumanoidRootPart.CFrame * CFrame.Angles(0, 1.5707963267948966, 0) * CFrame.new(math_random_ret2, math_random_ret3, math.random(-15, 15));
        end;

        GlobalFunctions.Tween({
            Instance = Part,
            EasingStyle = Enum.EasingStyle.Exponential
        }, {
            Transparency = 1
        });
        local _ = i;
    end;
end;

local u15 = {
    [Enum.Material.Concrete] = {
        id = "Rock",
        speed = 1.29,
        max = 129,
        var = 20
    },
    [Enum.Material.Slate] = {
        id = "Rock",
        speed = 1.29,
        max = 129,
        var = 20
    },
    [Enum.Material.Wood] = {
        id = "Wood",
        speed = 1.2,
        max = 120,
        var = 20
    },
    [Enum.Material.WoodPlanks] = {
        id = "Wood",
        speed = 1.2,
        max = 120,
        var = 20
    },
    [Enum.Material.Metal] = {
        id = "Metal",
        speed = 0.85,
        max = 85,
        var = 20
    },
    [Enum.Material.Grass] = {
        id = "Grass",
        speed = 0.7,
        max = 70,
        var = 20
    },
    [Enum.Material.Sand] = {
        id = "Sand",
        speed = 2.5,
        max = 250,
        var = 20
    }
};

local function applyFootstepSound(p16, p17) -- Line: 354
    -- upvalues: u15 (copy), Sounds (copy)
    local v18 = u15[p17];

    if v18 then
        p16.SoundId = Sounds.Movement.FootSteps[v18.id].SoundId;
        p16.PlaybackSpeed = math.random(v18.max - v18.var, v18.max) / 100;

        return;
    end;

    p16.SoundId = Sounds.Movement.FootSteps.Step.SoundId;
    p16.PlaybackSpeed = 1;
end;

local u19 = {};
local u20 = {};

local function markPredicted(p21) -- Line: 396
    -- upvalues: u20 (copy)
    u20[p21] = os.clock();
end;

local function consumePrediction(p22) -- Line: 400
    -- upvalues: u20 (copy)
    local v23 = u20[p22];

    if not v23 then
        return false;
    end;

    u20[p22] = nil;

    return os.clock() - v23 <= 0.35;
end;

local u24 = 0;

function u19.LockCameraFOV(p25) -- Line: 419
    -- upvalues: u24 (ref)
    local v26 = tick() + p25;
    u24 = math.max(u24, v26);
end;

local function fovLocked() -- Line: 423
    -- upvalues: u24 (ref)
    return tick() < u24;
end;

function u19.Run(p27) -- Line: 427
    -- upvalues: u24 (ref), GlobalFunctions (copy), workspace_CurrentCamera (copy), u15 (copy), Sounds (copy)
    local Action = p27.Action;

    if Action == "Execute" then
        if tick() >= u24 then
            GlobalFunctions.Tween({
                Duration = 1,
                Instance = workspace_CurrentCamera,
                EasingStyle = Enum.EasingStyle.Circular,
                EasingDirection = Enum.EasingDirection.Out
            }, {
                FieldOfView = 90
            });
        end;
    elseif Action == "Terminate" then
        if tick() >= u24 then
            GlobalFunctions.Tween({
                Duration = 0.75,
                Instance = workspace_CurrentCamera,
                EasingStyle = Enum.EasingStyle.Circular,
                EasingDirection = Enum.EasingDirection.Out
            }, {
                FieldOfView = 70
            });
        end;
    else
        if Action == "Sound Execute" then
            local Character = p27.Character;

            if not Character then
                return;
            end;

            local RootAndHumanoid, v28 = GlobalFunctions.GetRootAndHumanoid(Character);
            local Running = RootAndHumanoid:FindFirstChild("Running");

            if not Running then
                return;
            end;

            local v29 = u15[v28.FloorMaterial];

            if v29 then
                Running.SoundId = Sounds.Movement.FootSteps[v29.id].SoundId;
                Running.PlaybackSpeed = math.random(v29.max - v29.var, v29.max) / 100;

                return;
            end;

            Running.SoundId = Sounds.Movement.FootSteps.Step.SoundId;
            Running.PlaybackSpeed = 1;

            return;
        end;

        if Action == "Sound Terminate" then
            local Character = p27.Character;

            if not Character then
                return;
            end;

            local RootAndHumanoid, v30 = GlobalFunctions.GetRootAndHumanoid(Character);
            local Running = RootAndHumanoid:FindFirstChild("Running");

            if not Running then
                return;
            end;

            Running.Volume = 1;
            local v31 = u15[v30.FloorMaterial];

            if v31 then
                Running.SoundId = Sounds.Movement.FootSteps[v31.id].SoundId;
                Running.PlaybackSpeed = math.random(v31.max - v31.var, v31.max) / 100;
            else
                Running.SoundId = Sounds.Movement.FootSteps.Step.SoundId;
                Running.PlaybackSpeed = 1;
            end;

            if v30.FloorMaterial == Enum.Material.Concrete or v30.FloorMaterial == Enum.Material.Slate then
                Running.Volume = 0.2;
            end;
        end;
    end;
end;

function u19.Light(p32) -- Line: 474
    -- upvalues: DamageIndicator (copy), LocalPlayer (copy), u20 (copy), Hit_Counter_Function (copy), Default_Punch_Effect (copy)
    local Character = p32.Character;
    local Victim = p32.Victim;
    local Damage = p32.Damage;

    if Victim == nil then
        return;
    end;

    if p32.isServer then
        DamageIndicator.Execute(Victim, Damage);
        p32.CountCombo = Character == LocalPlayer.Character;

        if Character == LocalPlayer.Character then
            local v33 = u20[Victim];
            local v34;

            if v33 then
                u20[Victim] = nil;
                v34 = os.clock() - v33 <= 0.35;
            else
                v34 = false;
            end;

            if v34 then
                if p32.CountCombo then
                    Hit_Counter_Function(Character);
                end;

                return;
            end;
        end;

        Default_Punch_Effect(p32);

        return;
    end;

    if Victim:FindFirstChild("IFrame") then
        return;
    end;

    u20[Victim] = os.clock();
    p32.CountCombo = false;
    Default_Punch_Effect(p32);
end;

function u19.Heavy(p35) -- Line: 507
    -- upvalues: DamageIndicator (copy), LocalPlayer (copy), u20 (copy), Hit_Counter_Function (copy), Default_Punch_Effect (copy)
    local Character = p35.Character;
    local Victim = p35.Victim;
    local Damage = p35.Damage;
    local isServer = p35.isServer;

    if Victim == nil then
        return;
    end;

    p35.PunchType = "Heavy";

    if isServer then
        DamageIndicator.Execute(Victim, Damage);
        p35.CountCombo = Character == LocalPlayer.Character;

        if Character == LocalPlayer.Character then
            local v36 = u20[Victim];
            local v37;

            if v36 then
                u20[Victim] = nil;
                v37 = os.clock() - v36 <= 0.35;
            else
                v37 = false;
            end;

            if v37 then
                if p35.CountCombo then
                    Hit_Counter_Function(Character);
                end;

                return;
            end;
        end;

        Default_Punch_Effect(p35);

        return;
    end;

    if Victim:FindFirstChild("IFrame") then
        return;
    end;

    u20[Victim] = os.clock();
    p35.CountCombo = false;
    Default_Punch_Effect(p35);
end;

function u19.Clash(p38) -- Line: 533
    -- upvalues: Visuals (copy), Debris (copy), Particles (copy), SoundManager (copy)
    local HumanoidRootPart = p38.Character:FindFirstChild("HumanoidRootPart");
    local Part = Instance.new("Part");
    Part.Parent = Visuals;
    Part.Anchored = true;
    Part.Transparency = 1;
    Part.Size = Vector3.new(1, 1, 1);
    Part.CanCollide = false;
    Part.CFrame = HumanoidRootPart.CFrame * CFrame.new(math.random(-2, 2), math.random(-2, 2), -2.5);
    Debris:AddItem(Part, 2);
    local Attachment = Instance.new("Attachment");
    Attachment.Parent = Part;
    local v39 = Particles.Wind:Clone();
    v39.Parent = Attachment;
    v39:Emit(5);
    local v40 = Particles.Clash_PFX:Clone();
    v40.Parent = Attachment;
    v40:Emit(1);
    SoundManager.AddSound("ClashSFX", {
        Parent = Part,
        PlaybackSpeed = math.random(95, 135) / 100
    }, "Client");
end;

function u19.Blood(p41) -- Line: 562
    -- upvalues: Blood (copy)
    local Victim = p41.Victim;

    if not Victim then
        return;
    end;

    local HumanoidRootPart = Victim:FindFirstChild("HumanoidRootPart");
    Blood.Splatter(HumanoidRootPart, p41);
end;

function u19.Evade(p42) -- Line: 569
    -- upvalues: workspace_CurrentCamera (copy)
    local HumanoidRootPart = p42.Victim:FindFirstChild("HumanoidRootPart");

    if not HumanoidRootPart then
        return;
    end;

    local Position = (HumanoidRootPart.CFrame * CFrame.new(0, 5, 5)).Position;
    workspace_CurrentCamera.CFrame = CFrame.lookAt(Position, HumanoidRootPart.Position);
end;

u19["Follow Up"] = function(p43) -- Line: 577
    -- upvalues: ControlData (copy), Players (copy), KamiCard (copy), Assets (copy), Debris (copy), SoundManager (copy), TweenService (copy), workspace_CurrentCamera (copy)
    local Character = p43.Character;
    local Victim = p43.Victim;
    local Action = p43.Action;
    local v44 = p43.Duration or 3;
    local v45 = p43.Vanish_Time or 0.5;
    local HumanoidRootPart = Character:FindFirstChild("HumanoidRootPart");

    if Victim then
        Victim = Victim:FindFirstChild("HumanoidRootPart");
    end;

    if Action ~= "Execute" then
        if Action ~= "ChainPrompt" then
            if Action == "ChainCancel" then
                local PlayerGui = Players.LocalPlayer:FindFirstChild("PlayerGui");

                if PlayerGui then
                    PlayerGui = PlayerGui:FindFirstChild("ChainPromptGui");
                end;

                if PlayerGui then
                    PlayerGui:Destroy();

                    return;
                end;
            else
                if Action == "ChainConfirm" then
                    local PlayerGui = Players.LocalPlayer:FindFirstChild("PlayerGui");

                    if PlayerGui then
                        PlayerGui = PlayerGui:FindFirstChild("ChainPromptGui");
                    end;

                    local u46;

                    if PlayerGui then
                        u46 = PlayerGui:FindFirstChildOfClass("Frame");
                    else
                        u46 = PlayerGui;
                    end;

                    if not u46 then
                        return;
                    end;

                    SoundManager.AddSound("Osu Hit", {
                        Volume = 2,
                        Parent = PlayerGui
                    }, "Client");
                    local u47 = u46:FindFirstChildOfClass("UIStroke");
                    local u48 = u46:FindFirstChildOfClass("TextLabel");
                    local v49 = u46:Clone();
                    v49.Parent = PlayerGui;
                    local v50 = v49:FindFirstChildOfClass("UIStroke");
                    local v51 = v49:FindFirstChildOfClass("TextLabel");
                    local TweenInfo_new_ret = TweenInfo.new(0.25, Enum.EasingStyle.Quad, Enum.EasingDirection.Out);
                    TweenService:Create(v49, TweenInfo_new_ret, {
                        BackgroundTransparency = 1,
                        Size = UDim2.fromOffset(math.floor(u46.AbsoluteSize.X * 1.6), (math.floor(u46.AbsoluteSize.Y * 1.6)))
                    }):Play();

                    if v50 then
                        TweenService:Create(v50, TweenInfo_new_ret, {
                            Transparency = 1
                        }):Play();
                    end;

                    if v51 then
                        TweenService:Create(v51, TweenInfo_new_ret, {
                            TextTransparency = 1
                        }):Play();
                        local v52 = v51:FindFirstChildOfClass("UIStroke");

                        if v52 then
                            TweenService:Create(v52, TweenInfo_new_ret, {
                                Transparency = 1
                            }):Play();
                        end;
                    end;

                    Debris:AddItem(v49, 0.3);
                    local Size = u46.Size;
                    local TweenInfo_new_ret2 = TweenInfo.new(0.08, Enum.EasingStyle.Back, Enum.EasingDirection.Out);
                    local TweenInfo_new_ret3 = TweenInfo.new(0.12, Enum.EasingStyle.Quad, Enum.EasingDirection.Out);
                    TweenService:Create(u46, TweenInfo_new_ret2, {
                        Size = UDim2.fromOffset(math.floor(u46.AbsoluteSize.X * 1.12), (math.floor(u46.AbsoluteSize.Y * 1.12)))
                    }):Play();

                    if u47 then
                        u47.Color = Color3.fromRGB(255, 255, 255);
                        u47.Thickness = 3;
                        TweenService:Create(u47, TweenInfo_new_ret3, {
                            Thickness = 2,
                            Color = Color3.fromRGB(88, 214, 106)
                        }):Play();
                    end;

                    task.delay(0.08, function() -- Line: 745
                        -- upvalues: u46 (copy), TweenService (ref), TweenInfo_new_ret3 (copy), Size (copy)
                        if u46.Parent then
                            TweenService:Create(u46, TweenInfo_new_ret3, {
                                Size = Size
                            }):Play();
                        end;
                    end);
                    task.delay(0.3, function() -- Line: 752
                        -- upvalues: PlayerGui (copy), u46 (copy), TweenService (ref), u47 (copy), u48 (copy), Debris (ref)
                        if not (PlayerGui and (PlayerGui.Parent and u46.Parent)) then
                            return;
                        end;

                        local TweenInfo_new_ret4 = TweenInfo.new(0.15, Enum.EasingStyle.Quad, Enum.EasingDirection.Out);
                        TweenService:Create(u46, TweenInfo_new_ret4, {
                            BackgroundTransparency = 1
                        }):Play();

                        if u47 then
                            TweenService:Create(u47, TweenInfo_new_ret4, {
                                Transparency = 1
                            }):Play();
                        end;

                        if u48 then
                            TweenService:Create(u48, TweenInfo_new_ret4, {
                                TextTransparency = 1
                            }):Play();
                            local v53 = u48:FindFirstChildOfClass("UIStroke");

                            if v53 then
                                TweenService:Create(v53, TweenInfo_new_ret4, {
                                    Transparency = 1
                                }):Play();
                            end;
                        end;

                        Debris:AddItem(PlayerGui, 0.2);
                    end);

                    return;
                end;

                if Action == "Remove Gui" then
                    if HumanoidRootPart then
                        for _, child in ipairs(HumanoidRootPart:GetChildren()) do
                            if child.Name == "Follow Up Gui" then
                                child:Destroy();
                            end;
                        end;
                    end;

                    if Character == Players.LocalPlayer.Character then
                        local PlayerGui = Players.LocalPlayer:FindFirstChild("PlayerGui");

                        if PlayerGui then
                            PlayerGui = PlayerGui:FindFirstChild("FollowUpCard");
                        end;

                        if PlayerGui then
                            PlayerGui:Destroy();

                            return;
                        end;
                    end;
                elseif Action == "SmackCam" then
                    if HumanoidRootPart and Victim then
                        local Position = (HumanoidRootPart.CFrame * CFrame.new(0, 5, 8)).Position;
                        workspace_CurrentCamera.CFrame = CFrame.lookAt(Position, Victim.Position + Vector3.new(0, -14, 0));

                        return;
                    end;
                elseif Action == "KickCam" then
                    local KickDir = p43.KickDir;

                    if HumanoidRootPart and KickDir then
                        workspace_CurrentCamera.CFrame = CFrame.lookAt(HumanoidRootPart.Position - KickDir * 10 + Vector3.new(0, 4, 0), HumanoidRootPart.Position + KickDir * 25);

                        return;
                    end;
                elseif Action == "Terminate" then
                    if Victim then
                        task.delay(v45, function() -- Line: 814
                            -- upvalues: Victim (copy), workspace_CurrentCamera (ref)
                            local Position = (Victim.CFrame * CFrame.new(0, 5, 5)).Position;
                            workspace_CurrentCamera.CFrame = CFrame.lookAt(Position, Victim.Position);
                        end);
                    end;

                    for _, child in ipairs(HumanoidRootPart:GetChildren()) do
                        if child.Name == "Follow Up Gui" then
                            child:Destroy();
                        end;
                    end;

                    if Character == Players.LocalPlayer.Character then
                        local PlayerGui = Players.LocalPlayer:FindFirstChild("PlayerGui");

                        if PlayerGui then
                            PlayerGui = PlayerGui:FindFirstChild("FollowUpCard");
                        end;

                        if PlayerGui then
                            PlayerGui:Destroy();
                        end;
                    end;
                end;
            end;

            return;
        end;

        local PlayerGui = game:GetService("Players").LocalPlayer:FindFirstChild("PlayerGui");

        if not PlayerGui then
            return;
        end;

        local ChainPromptGui = PlayerGui:FindFirstChild("ChainPromptGui");

        if ChainPromptGui then
            ChainPromptGui:Destroy();
        end;

        local ScreenGui = Instance.new("ScreenGui");
        ScreenGui.Name = "ChainPromptGui";
        ScreenGui.DisplayOrder = 80;
        ScreenGui.ResetOnSpawn = false;
        ScreenGui.Parent = PlayerGui;
        local Frame = Instance.new("Frame");
        Frame.AnchorPoint = Vector2.new(0.5, 0.5);
        Frame.Position = UDim2.fromScale(0.5, 0.66);
        Frame.Size = UDim2.fromOffset(250, 44);
        Frame.BackgroundColor3 = Color3.fromRGB(28, 28, 30);
        Frame.BorderSizePixel = 0;
        Frame.Parent = ScreenGui;
        local UIStroke = Instance.new("UIStroke");
        UIStroke.Color = Color3.fromRGB(88, 214, 106);
        UIStroke.Thickness = 2;
        UIStroke.Parent = Frame;
        local TextLabel = Instance.new("TextLabel");
        TextLabel.Size = UDim2.fromScale(1, 1);
        TextLabel.BackgroundTransparency = 1;
        TextLabel.Font = Enum.Font.Arcade;
        TextLabel.Text = "HIT Z AGAIN TO CHAIN!";
        TextLabel.TextSize = 18;
        TextLabel.TextColor3 = Color3.fromRGB(255, 255, 255);
        TextLabel.Parent = Frame;
        local UIStroke2 = Instance.new("UIStroke");
        UIStroke2.Color = Color3.fromRGB(0, 0, 0);
        UIStroke2.Thickness = 1.5;
        UIStroke2.Parent = TextLabel;
        Debris:AddItem(ScreenGui, v44);

        return;
    end;

    local v54 = {};

    for i, v in pairs(ControlData.Controls.Combat) do
        if i == "Follow Up" then
            if typeof(v) == "table" then
                for _, v2 in ipairs(v) do
                    table.insert(v54, v2);
                end;
            else
                table.insert(v54, v);
            end;

            break;
        end;
    end;

    local v55 = #v54 == 0 and { "Unknown" } or v54;

    if Character == Players.LocalPlayer.Character then
        local u56 = KamiCard.new({
            Name = "FollowUpCard",
            Width = 340,
            Height = 112,
            DisplayOrder = 80,
            Portrait = false
        });
        u56:Render({
            Counter = "",
            Title = "FOLLOW UP READY",
            Objective = "Strike again",
            Detail = "",
            Button = false,
            Keys = v55
        });
        u56:SlideIn();
        task.delay(v44, function() -- Line: 626
            -- upvalues: u56 (copy)
            u56:Dismiss();
        end);

        return;
    end;

    local v57 = Assets.Gui.Combat["Follow Up Gui"]:Clone();
    v57.Parent = HumanoidRootPart;
    v57.Frame.Key.Text = table.concat(v55, " / ");
    Debris:AddItem(v57, v44);
end;

local u58 = nil;

u19["Knockback Path"] = function(p59) -- Line: 857
    -- upvalues: LocalPlayer (copy), u58 (ref), RunService (copy)
    local Victim = p59.Victim;
    local v60 = p59.Action or "Execute";

    if Victim ~= LocalPlayer.Character then
        return;
    end;

    if u58 then
        u58:Disconnect();
        u58 = nil;
    end;

    if v60 == "Cancel" then
        return;
    end;

    local Path = p59.Path;
    local u61;

    if Victim then
        u61 = Victim:FindFirstChild("HumanoidRootPart");
    else
        u61 = Victim;
    end;

    if not (Path and u61) then
        return;
    end;

    local Vector3_new_ret = Vector3.new(Path.Velocity.X, 0, Path.Velocity.Z);
    local u62 = Vector3_new_ret.Magnitude > 0.05 and Vector3_new_ret.Unit or u61.CFrame.LookVector;
    local u63 = nil;
    u63 = RunService.RenderStepped:Connect(function() -- Line: 882
        -- upvalues: u63 (ref), u58 (ref), u61 (copy), Victim (copy), Path (copy), u62 (copy)
        if u63 ~= u58 then
            u63:Disconnect();

            return;
        end;

        if not (u61.Parent and (Victim.Parent and not u61.Anchored)) then
            u63:Disconnect();

            if u58 == u63 then
                u58 = nil;
            end;

            return;
        end;

        local v64 = workspace:GetServerTimeNow() - Path.StartTime;

        if Path.Duration <= v64 then
            u63:Disconnect();

            if u58 == u63 then
                u58 = nil;
            end;

            return;
        end;

        if v64 < 0 then
            return;
        end;

        local v65 = Path.Origin + Path.Velocity * v64 + Path.Accel * (0.5 * v64 * v64);
        u61.CFrame = CFrame.lookAt(v65, v65 + u62) * CFrame.Angles(-1.3089969389957472, 0, 0);
        u61.AssemblyLinearVelocity = Vector3.new(0, 0, 0);
        u61.AssemblyAngularVelocity = Vector3.new(0, 0, 0);
    end);
    u58 = u63;
end;

u19["Air Combat"] = function(p66) -- Line: 915
    -- upvalues: Meshes (copy), Visuals (copy), Debris (copy), GlobalFunctions (copy)
    local HumanoidRootPart = p66.Character:FindFirstChild("HumanoidRootPart");
    local v67 = 5;
    local v68 = 30;

    for i = 1, 3 do
        local v69 = Meshes.Combat.Ring:Clone();
        v69.Parent = Visuals;
        v69.CFrame = HumanoidRootPart.CFrame * CFrame.new(0, v67, 0);
        Debris:AddItem(v69, 2);
        GlobalFunctions.Tween({
            Duration = 1,
            Instance = v69,
            EasingStyle = Enum.EasingStyle.Back,
            EasingDirection = Enum.EasingDirection.Out
        }, {
            Transparency = 1,
            Size = Vector3.new(v68, 0.1, v68)
        });
        v68 = v68 / 2;
        v67 = v67 + 5;
        task.wait(0.2);
        local _ = i;
    end;
end;

u19["Drag Trail"] = function(p70) -- Line: 963
    -- upvalues: CraterHandler (copy)
    local v71 = p70.Victim or p70.Character;

    if not v71 then
        return;
    end;

    if p70.Action == "Terminate" then
        CraterHandler.StopDragTrail(v71);

        return;
    end;

    CraterHandler.CreateDragTrail(v71, p70);
end;

u19["Ground Slam"] = function(p72) -- Line: 975
    -- upvalues: CraterHandler (copy)
    local Location = p72.Location;
    local RayData = p72.RayData;

    if RayData and RayData.Result then
        p72.SurfaceMaterial = RayData.Result.Material;
        local Instance2 = RayData.Result.Instance;
        p72.SurfaceColor = Instance2 and Instance2.Color or nil;
    end;

    CraterHandler.CreateCraterAtPoint(Location, p72);
end;

u19["Wall Slam"] = function(p73) -- Line: 991
    -- upvalues: CraterHandler (copy)
    local Location = p73.Location;
    local RayData = p73.RayData;

    if not RayData then
        return;
    end;

    if RayData.Result then
        p73.SurfaceMaterial = RayData.Result.Material;
        local Instance2 = RayData.Result.Instance;
        p73.SurfaceColor = Instance2 and Instance2.Color or nil;
    end;

    CraterHandler.CreateWallCrater(Location, p73);
end;

u19["Block Gui"] = function(p74) -- Line: 1005
    -- upvalues: Players (copy), GlobalFunctions (copy), Gui (copy)
    local Character = p74.Character;
    local Posture = Players:GetPlayerFromCharacter(Character):FindFirstChild("PlayerStats").StatData.Misc.Posture;
    GlobalFunctions.GetRootAndHumanoid(Character);
    local u75 = Character:FindFirstChild("BlockGui") or Gui.Combat.BlockGui:Clone();
    u75.BlockFrame.BlockMeter.Size = UDim2.new(Posture.Value / 100, 0, 1, 0);
    u75.Parent = Character;
    local u77 = Posture.Changed:Connect(function(p76) -- Line: 1017
        -- upvalues: u75 (copy)
        if u75.Parent then
            u75.BlockFrame.BlockMeter:TweenSize(UDim2.new(p76 / 100, 0, 1, 0), Enum.EasingDirection.Out, Enum.EasingStyle.Sine, 0.1, true);
        end;
    end);
    u75.AncestryChanged:Connect(function() -- Line: 1026
        -- upvalues: u75 (copy), u77 (copy)
        if not u75.Parent then
            u77:Disconnect();
        end;
    end);
end;

function u19.Unblock(p78) -- Line: 1031
    for _, child in ipairs(p78.Character:GetChildren()) do
        if child.Name == "BlockGui" then
            child:Destroy();
        end;
    end;
end;

function u19.Block(p79) -- Line: 1038
    -- upvalues: Particles (copy), Visuals (copy), Debris (copy), AnimationManager (copy), SoundManager (copy)
    local Victim = p79.Victim;
    local v80;

    if Victim then
        v80 = Victim:FindFirstChild("HumanoidRootPart");
    else
        v80 = Victim;
    end;

    if not v80 then
        return;
    end;

    local v81 = Particles.Block:Clone();
    v81.Parent = Visuals;
    v81.CFrame = v80.CFrame;
    v81.Attachment.BlockEffect:Emit(1);
    Debris:AddItem(v81, 1);
    local math_random_ret = math.random(1, 2);
    AnimationManager.PlayAnimation(Victim, "Block React " .. math_random_ret);
    SoundManager.AddSound("Block " .. math_random_ret, {
        Parent = v80
    }, "Client");
end;

function u19.Parry(p82) -- Line: 1056
    -- upvalues: GlobalFunctions (copy), Particles (copy), SoundManager (copy)
    local RootAndHumanoid = GlobalFunctions.GetRootAndHumanoid(p82.Character);
    local v83 = Particles["Parry Effect"].Attachment:Clone();
    v83.Parent = RootAndHumanoid;

    for _, child in ipairs(v83:GetChildren()) do
        if child:IsA("ParticleEmitter") then
            child:Emit(1);
        end;
    end;

    SoundManager.AddSound("Parry", {
        Parent = RootAndHumanoid
    }, "Client");
end;

u19["Gut Punch"] = function(p84) -- Line: 1068
    -- upvalues: GlobalFunctions (copy), Gui (copy)
    local Character = p84.Character;
    local RootAndHumanoid = GlobalFunctions.GetRootAndHumanoid(Character);
    local u85 = Gui.Combat["Hurt Gui"]:Clone();
    u85.Parent = Character;
    u85.Adornee = RootAndHumanoid;
    u85.StudsOffset = Vector3.new(-3, 0, 0);
    local Back = Enum.EasingStyle.Back;

    local function setImageTransparency(p86) -- Line: 1080
        -- upvalues: u85 (copy), GlobalFunctions (ref), Back (copy)
        for _, descendant in ipairs(u85:GetDescendants()) do
            if descendant:IsA("ImageLabel") then
                GlobalFunctions.Tween({
                    Duration = 0.75,
                    Instance = descendant,
                    EasingStyle = Back
                }, {
                    ImageTransparency = p86
                });
            end;
        end;
    end;

    local function close() -- Line: 1099
        -- upvalues: setImageTransparency (copy), GlobalFunctions (ref), u85 (copy)
        setImageTransparency(1);
        GlobalFunctions.Tween({
            Duration = 0.75,
            Instance = u85
        }, {
            StudsOffset = Vector3.new(-3, 4.5, 0)
        });
    end;

    (function() -- Line: 1091, Name: open
        -- upvalues: setImageTransparency (copy), GlobalFunctions (ref), u85 (copy), Back (copy)
        setImageTransparency(0);
        GlobalFunctions.Tween({
            Duration = 0.75,
            Instance = u85,
            EasingStyle = Back
        }, {
            StudsOffset = Vector3.new(-3, 3, 0)
        });
    end)();
    task.delay(1, close);
end;

u19["Injure Effect"] = function(p87) -- Line: 1111
    -- upvalues: GlobalFunctions (copy), Particles (copy), Debris (copy)
    local RootAndHumanoid = GlobalFunctions.GetRootAndHumanoid(p87.Victim);
    local v88 = Particles["Injure Effect"].InjureEffect:Clone();
    v88.Parent = RootAndHumanoid;
    Debris:AddItem(v88, 2);

    for _, child in ipairs(v88:GetChildren()) do
        if child:IsA("ParticleEmitter") then
            child:Emit(1);
        end;
    end;
end;

u19["Guard Break"] = function(p89) -- Line: 1123
    -- upvalues: AnimationManager (copy), Particles (copy), Debris (copy)
    local Victim = p89.Victim;
    local HumanoidRootPart = Victim:FindFirstChild("HumanoidRootPart");
    AnimationManager.PlayAnimation(Victim, "BlockBroken");
    local v90 = Particles.GuardBreak:Clone();
    v90.Parent = HumanoidRootPart;
    v90:Emit(1);
    Debris:AddItem(v90, 2);
    local u91 = Particles["Star Effect"].Stars:Clone();
    u91.Parent = Victim:FindFirstChild("Head");
    Debris:AddItem(u91, 4);
    task.delay(2, function() -- Line: 1139
        -- upvalues: u91 (copy)
        for _, child in ipairs(u91:GetChildren()) do
            child.Enabled = false;
        end;
    end);
end;

function u19.Knock(p92) -- Line: 1146
    -- upvalues: LocalPlayer (copy), Assets (copy)
    local KO = p92.KO;
    local Character = p92.Character;
    local HumanoidRootPart = Character:FindFirstChild("HumanoidRootPart");

    if KO == true and LocalPlayer.Character ~= Character then
        task.spawn(function() -- Line: 1152
            -- upvalues: Assets (ref), HumanoidRootPart (copy), Character (copy)
            local v93 = Assets.Gui.Combat["Grip Gui"]:Clone();
            local v94 = Assets.Gui.Combat["Carry Gui"]:Clone();
            local v95 = Assets.Gui.Combat["Loot Gui"]:Clone();
            v93.Parent = HumanoidRootPart;
            v94.Parent = HumanoidRootPart;
            v95.Parent = HumanoidRootPart;

            while Character:FindFirstChild("Knocked") do
                task.wait();
            end;

            v94:Destroy();
            v93:Destroy();
            v95:Destroy();
        end);
    end;
end;

u19["Punch Shake"] = function(p96) -- Line: 1169
    -- upvalues: CamShakeHandler (copy)
    CamShakeHandler.Shake(p96);
end;

u19["Dash Effect"] = function(p97) -- Line: 1173
    -- upvalues: Players (copy), u19 (copy), GlobalFunctions (copy), workspace_CurrentCamera (copy), Black_Lines (copy)
    local Direction = p97.Direction;
    local Character = p97.Character;

    if not p97.ShiftPressed then
        return;
    end;

    local u98 = Character == Players.LocalPlayer.Character;

    if u98 then
        u19.LockCameraFOV(1.25);
        GlobalFunctions.Tween({
            Duration = 0.75,
            Instance = workspace_CurrentCamera,
            EasingStyle = Enum.EasingStyle.Circular,
            EasingDirection = Enum.EasingDirection.Out
        }, {
            FieldOfView = 120
        });
    end;

    local u99 = tick();
    task.spawn(function() -- Line: 1198
        -- upvalues: u99 (copy), Black_Lines (ref), Character (copy), Direction (copy), u98 (copy), GlobalFunctions (ref), workspace_CurrentCamera (ref)
        while tick() - u99 < 0.5 do
            Black_Lines(Character, Direction);
            task.wait();
        end;

        if u98 then
            GlobalFunctions.Tween({
                Duration = 0.75,
                Instance = workspace_CurrentCamera,
                EasingStyle = Enum.EasingStyle.Circular,
                EasingDirection = Enum.EasingDirection.Out
            }, {
                FieldOfView = 70
            });
        end;
    end);
end;

u19["Hit Counter"] = function(p100) -- Line: 1214
    -- upvalues: Hit_Counter_Function (copy)
    Hit_Counter_Function(p100.Character);
end;

u19["Damage Indicator"] = function(p101) -- Line: 1218
    -- upvalues: DamageIndicator (copy)
    DamageIndicator.Execute(p101.Victim, p101.Damage);
end;

function u19.Dodge(p102) -- Line: 1222
    -- upvalues: VfxHandler (copy), DamageIndicator (copy)
    VfxHandler.Afterimage.New(p102.Character);
    DamageIndicator.Miss(p102.Character);
end;

function u19.UpperCut(p103) -- Line: 1227
    -- upvalues: Meshes (copy), Visuals (copy), Debris (copy), GlobalFunctions (copy)
    local HumanoidRootPart = p103.Victim:FindFirstChild("HumanoidRootPart");
    local v104 = Meshes.Combat.Ring:Clone();
    v104.Parent = Visuals;
    v104.CFrame = HumanoidRootPart.CFrame;
    Debris:AddItem(v104, 2);
    GlobalFunctions.Tween({
        Duration = 1,
        Instance = v104,
        EasingStyle = Enum.EasingStyle.Back,
        EasingDirection = Enum.EasingDirection.Out
    }, {
        Size = Vector3.new(10, 0.5, 10),
        Transparency = 1
    });
end;

function u19.Voxel() -- Line: 1253
end;

u19["Voxel Carve"] = function() -- Line: 1254
end;

function u19.EmitWindBurst(p105, p106) -- Line: 1276
    local v107 = p106 or "Both";
    local u108;

    if p105 then
        u108 = p105:FindFirstChild("HumanoidRootPart");
    else
        u108 = p105;
    end;

    if not u108 then
        return;
    end;

    local ReplicatedStorage2 = game:GetService("ReplicatedStorage");
    local Debris2 = game:GetService("Debris");
    local u109 = ReplicatedStorage2:FindFirstChild("Assets") and (ReplicatedStorage2.Assets:FindFirstChild("Effects") and ReplicatedStorage2.Assets.Effects:FindFirstChild("Particles")) and ReplicatedStorage2.Assets.Effects.Particles:FindFirstChild("Wind Bursts");

    if not u109 then
        return;
    end;

    local function burst(p110, p111) -- Line: 1287
        -- upvalues: u109 (copy), u108 (copy), Debris2 (copy)
        local v112 = u109:FindFirstChild(p110);

        if not v112 then
            return;
        end;

        local Attachment = Instance.new("Attachment");
        Attachment.Position = p111;
        Attachment.Parent = u108;

        for _, descendant in ipairs(v112:GetDescendants()) do
            if descendant:IsA("ParticleEmitter") then
                local v113 = descendant:Clone();
                v113.Enabled = false;
                v113.Parent = Attachment;
                v113:Emit(1);
            end;
        end;

        Debris2:AddItem(Attachment, 4);
    end;

    if v107 == "Wind" or v107 == "Both" then
        local v114 = p105:FindFirstChildOfClass("Humanoid");
        local v115;

        if v114 and v114.RigType == Enum.HumanoidRigType.R15 then
            v115 = -(v114.HipHeight + u108.Size.Y / 2);
        else
            v115 = -1.3 * u108.Size.Y;
        end;

        burst("Wind", (Vector3.new(0, v115, 0)));
    end;

    if v107 == "Wind 2" or v107 == "Both" then
        burst("Wind 2", Vector3.new(0, 0, 0));
    end;
end;

u19["Super Push"] = function(p116) -- Line: 1321
    -- upvalues: u19 (copy)
    local Character = p116.Character;
    local u117;

    if Character then
        u117 = Character:FindFirstChild("HumanoidRootPart");
    else
        u117 = Character;
    end;

    if not u117 then
        return;
    end;

    local ReplicatedStorage2 = game:GetService("ReplicatedStorage");
    local Debris2 = game:GetService("Debris");
    local u118 = ReplicatedStorage2:FindFirstChild("Assets") and ReplicatedStorage2.Assets:FindFirstChild("Sounds");

    local function playSound(p119, p120) -- Line: 1330
        -- upvalues: u118 (copy), u117 (copy), Debris2 (copy)
        local u121 = u118 and u118:FindFirstChild(p119, true);

        if not u121 then
            return;
        end;

        task.delay(p120 or 0, function() -- Line: 1335
            -- upvalues: u117 (ref), u121 (copy), Debris2 (ref)
            if not u117.Parent then
                return;
            end;

            local v122 = u121:Clone();
            v122.Parent = u117;
            v122:Play();
            Debris2:AddItem(v122, 6);
        end);
    end;

    local Attachment = Instance.new("Attachment");
    local u123 = Character:FindFirstChildOfClass("Humanoid");
    local v124;

    if u123 and u123.RigType == Enum.HumanoidRigType.R15 then
        v124 = -(u123.HipHeight + u117.Size.Y / 2);
    else
        v124 = -1.3 * u117.Size.Y;
    end;

    Attachment.Position = Vector3.new(0, v124, 0);
    Attachment.Parent = u117;
    local TweenService2 = game:GetService("TweenService");
    local Highlight = Instance.new("Highlight");
    Highlight.FillTransparency = 1;
    Highlight.OutlineColor = Color3.fromRGB(255, 40, 40);
    Highlight.OutlineTransparency = 0;
    Highlight.DepthMode = Enum.HighlightDepthMode.Occluded;
    Highlight.Adornee = Character;
    Highlight.Parent = Character;
    task.delay(1.35, function() -- Line: 1369
        -- upvalues: Highlight (copy), TweenService2 (copy)
        if Highlight.Parent then
            TweenService2:Create(Highlight, TweenInfo.new(0.4), {
                OutlineTransparency = 1
            }):Play();
        end;
    end);
    Debris2:AddItem(Highlight, 1.8);
    local v125 = ReplicatedStorage2:FindFirstChild("Assets") and (ReplicatedStorage2.Assets:FindFirstChild("Effects") and ReplicatedStorage2.Assets.Effects:FindFirstChild("Meshes")) and ReplicatedStorage2.Assets.Effects.Meshes:FindFirstChild("Charging");
    local v126 = v125 and (v125:FindFirstChild("Charge Effects") and v125["Charge Effects"]:FindFirstChild("Dust")) and v125["Charge Effects"].Dust:FindFirstChild("Dust");

    if v126 then
        local v127 = v126:Clone();
        v127.Enabled = false;
        v127.Parent = Attachment;
        v127:Emit(6);
    end;

    local u128 = false;

    local function fireYell() -- Line: 1405
        -- upvalues: u128 (ref), u118 (copy), u117 (copy), Debris2 (copy)
        if u128 then
            return;
        end;

        u128 = true;
        local u129 = u118 and u118:FindFirstChild("Yell", true);

        if not u129 then
            return;
        end;

        task.delay(0, function() -- Line: 1335
            -- upvalues: u117 (ref), u129 (copy), Debris2 (ref)
            if not u117.Parent then
                return;
            end;

            local v130 = u129:Clone();
            v130.Parent = u117;
            v130:Play();
            Debris2:AddItem(v130, 6);
        end);
    end;

    local u131 = false;

    local function fireSphere() -- Line: 1416
        -- upvalues: u131 (ref), u117 (copy), TweenService2 (copy), Debris2 (copy)
        if u131 then
            return;
        end;

        u131 = true;

        if not u117.Parent then
            return;
        end;

        local Part = Instance.new("Part");
        Part.Shape = Enum.PartType.Ball;
        Part.Material = Enum.Material.ForceField;
        Part.Color = Color3.fromRGB(255, 60, 60);
        Part.Size = Vector3.new(0, 0, 0);
        Part.CFrame = u117.CFrame;
        Part.Anchored = true;
        Part.CanCollide = false;
        Part.CanQuery = false;
        Part.CanTouch = false;
        Part.Transparency = 0;
        Part.Parent = workspace;
        TweenService2:Create(Part, TweenInfo.new(0.5, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
            Size = Vector3.new(48, 48, 48),
            Transparency = 1
        }):Play();
        Debris2:AddItem(Part, 0.7);
    end;

    local u132 = false;

    local function fireImpact() -- Line: 1438
        -- upvalues: u132 (ref), u128 (ref), u118 (copy), u117 (copy), Debris2 (copy), fireSphere (copy), u19 (ref), Character (copy)
        if u132 then
            return;
        end;

        u132 = true;

        if not u128 then
            u128 = true;
            local u133 = u118 and u118:FindFirstChild("Yell", true);

            if u133 then
                task.delay(0, function() -- Line: 1335
                    -- upvalues: u117 (ref), u133 (copy), Debris2 (ref)
                    if not u117.Parent then
                        return;
                    end;

                    local v134 = u133:Clone();
                    v134.Parent = u117;
                    v134:Play();
                    Debris2:AddItem(v134, 6);
                end);
            end;
        end;

        fireSphere();
        local u135 = u118 and u118:FindFirstChild("Gravity Push", true);

        if u135 then
            task.delay(0, function() -- Line: 1335
                -- upvalues: u117 (ref), u135 (copy), Debris2 (ref)
                if not u117.Parent then
                    return;
                end;

                local v136 = u135:Clone();
                v136.Parent = u117;
                v136:Play();
                Debris2:AddItem(v136, 6);
            end);
        end;

        u19.EmitWindBurst(Character, "Both");
    end;

    local function hookMarker() -- Line: 1446
        -- upvalues: u123 (copy), fireImpact (copy), fireYell (copy), fireSphere (copy)
        local v137 = u123 and u123:FindFirstChildOfClass("Animator");

        if not v137 then
            return false;
        end;

        for _, v in ipairs(v137:GetPlayingAnimationTracks()) do
            local Animation = v.Animation;

            if Animation and Animation.Name == "Explosion Wave" or v.Name == "Explosion Wave" then
                v:GetMarkerReachedSignal("Explode"):Once(fireImpact);
                task.delay(math.max(0.55 - v.TimePosition, 0), fireYell);
                task.delay(math.max(0.8500000000000001 - v.TimePosition, 0), fireSphere);
                task.delay(1, fireYell);
                task.delay(1.5, fireImpact);

                return true;
            end;
        end;

        return false;
    end;

    task.spawn(function() -- Line: 1468
        -- upvalues: hookMarker (copy), u128 (ref), u118 (copy), u117 (copy), Debris2 (copy), fireImpact (copy)
        local os_clock_ret = os.clock();

        while os.clock() - os_clock_ret < 0.6 do
            if hookMarker() then
                return;
            end;

            task.wait(0.05);
        end;

        if not u128 then
            u128 = true;
            local u138 = u118 and u118:FindFirstChild("Yell", true);

            if u138 then
                task.delay(0, function() -- Line: 1335
                    -- upvalues: u117 (ref), u138 (copy), Debris2 (ref)
                    if not u117.Parent then
                        return;
                    end;

                    local v139 = u138:Clone();
                    v139.Parent = u117;
                    v139:Play();
                    Debris2:AddItem(v139, 6);
                end);
            end;
        end;

        task.delay(0.35, fireImpact);
    end);
    Debris2:AddItem(Attachment, 4);
end;

return u19;