-- Decompiled with Potassium's decompiler.

local Players = game:GetService("Players");
local ReplicatedStorage = game:GetService("ReplicatedStorage");
local LocalPlayer = Players.LocalPlayer;
local ContractRemote = ReplicatedStorage:WaitForChild("Remotes"):WaitForChild("ContractRemote");
local Color3_fromRGB_ret = Color3.fromRGB(28, 28, 30);
local Color3_fromRGB_ret2 = Color3.fromRGB(216, 213, 205);
local Color3_fromRGB_ret3 = Color3.fromRGB(201, 198, 191);
local Color3_fromRGB_ret4 = Color3.fromRGB(88, 214, 106);
local Color3_fromRGB_ret5 = Color3.fromRGB(225, 100, 90);
local Color3_fromRGB_ret6 = Color3.fromRGB(255, 255, 255);
local Color3_fromRGB_ret7 = Color3.fromRGB(0, 0, 0);
local Arcade = Enum.Font.Arcade;
local Bangers = Enum.Font.Bangers;

local function stroke(p1, p2, p3) -- Line: 30
    -- upvalues: Color3_fromRGB_ret7 (copy)
    local UIStroke = Instance.new("UIStroke");
    UIStroke.Color = p3 or Color3_fromRGB_ret7;
    UIStroke.Thickness = p2 or 2;
    UIStroke.Parent = p1;

    return UIStroke;
end;

local function corner(p4, p5) -- Line: 31
    local UICorner = Instance.new("UICorner");
    UICorner.CornerRadius = UDim.new(0, p5 or 6);
    UICorner.Parent = p4;

    return UICorner;
end;

local Inventory = LocalPlayer:WaitForChild("PlayerGui"):WaitForChild("HUD"):WaitForChild("Inventory");
local StatFrame = Inventory:WaitForChild("StatFrame");
local Tabs = StatFrame:WaitForChild("Tabs");
local LoreTab = Tabs:WaitForChild("LoreTab");
local Lore = StatFrame:WaitForChild("Lore");

if Tabs:FindFirstChild("CraftingTab") then
    return;
end;

local u6 = LoreTab:Clone();
u6.Name = "CraftingTab";
u6.LayoutOrder = 5;
u6.Image = "rbxassetid://126454867112626";
local v7 = u6:FindFirstChildWhichIsA("TextLabel");

if v7 then
    v7.Text = "Crafting";
end;

u6.Parent = Tabs;

for _, child in ipairs(Tabs:GetChildren()) do
    if child:IsA("ImageButton") then
        child.Size = UDim2.new(1, 0, 0.1, 0);
    end;
end;

local Frame = Instance.new("Frame");
Frame.Name = "Crafting";
Frame.AnchorPoint = Lore.AnchorPoint;
Frame.Position = Lore.Position;
Frame.Size = Lore.Size;
Frame.BackgroundColor3 = Lore.BackgroundColor3;
Frame.BackgroundTransparency = Lore.BackgroundTransparency;
Frame.BorderSizePixel = 0;
Frame.Visible = false;
Frame.ZIndex = 12;
Frame.DescendantAdded:Connect(function(p8) -- Line: 65
    if p8:IsA("GuiObject") then
        p8.ZIndex = 13;
    end;
end);
Frame.Parent = StatFrame;
local v9 = Lore:FindFirstChildOfClass("UICorner");

if v9 then
    local Offset = v9.CornerRadius.Offset;
    local UICorner = Instance.new("UICorner");
    UICorner.CornerRadius = UDim.new(0, Offset or 6);
    UICorner.Parent = Frame;
end;

local TextLabel = Instance.new("TextLabel");
TextLabel.BackgroundTransparency = 1;
TextLabel.Position = UDim2.new(0, 12, 0, 6);
TextLabel.Size = UDim2.new(1, -24, 0, 26);
TextLabel.Font = Bangers;
TextLabel.TextSize = 22;
TextLabel.TextColor3 = Color3_fromRGB_ret2;
TextLabel.TextXAlignment = Enum.TextXAlignment.Left;
TextLabel.Text = "CRAFTING";
TextLabel.Parent = Frame;
local TextLabel2 = Instance.new("TextLabel");
TextLabel2.BackgroundTransparency = 1;
TextLabel2.AnchorPoint = Vector2.new(1, 0);
TextLabel2.Position = UDim2.new(1, -12, 0, 10);
TextLabel2.Size = UDim2.new(0.5, 0, 0, 16);
TextLabel2.Font = Arcade;
TextLabel2.TextSize = 11;
TextLabel2.TextColor3 = Color3_fromRGB_ret3;
TextLabel2.TextXAlignment = Enum.TextXAlignment.Right;
TextLabel2.Text = "";
TextLabel2.Parent = Frame;
local Frame2 = Instance.new("Frame");
Frame2.Name = "Categories";
Frame2.BackgroundTransparency = 1;
Frame2.Position = UDim2.new(0, 12, 0, 40);
Frame2.Size = UDim2.new(0.5, -18, 0, 22);
Frame2.Parent = Frame;
local UIListLayout = Instance.new("UIListLayout");
UIListLayout.FillDirection = Enum.FillDirection.Horizontal;
UIListLayout.Padding = UDim.new(0, 6);
UIListLayout.SortOrder = Enum.SortOrder.LayoutOrder;
UIListLayout.Parent = Frame2;
local ScrollingFrame = Instance.new("ScrollingFrame");
ScrollingFrame.Name = "RecipeList";
ScrollingFrame.BackgroundTransparency = 1;
ScrollingFrame.BorderSizePixel = 0;
ScrollingFrame.Position = UDim2.new(0, 12, 0, 68);
ScrollingFrame.Size = UDim2.new(0.5, -18, 1, -80);
ScrollingFrame.ScrollBarThickness = 4;
ScrollingFrame.AutomaticCanvasSize = Enum.AutomaticSize.Y;
ScrollingFrame.CanvasSize = UDim2.new();
ScrollingFrame.ScrollingDirection = Enum.ScrollingDirection.Y;
ScrollingFrame.Parent = Frame;
local UIGridLayout = Instance.new("UIGridLayout");
UIGridLayout.CellSize = UDim2.new(0.5, -6, 0, 92);
UIGridLayout.CellPadding = UDim2.new(0, 6, 0, 6);
UIGridLayout.SortOrder = Enum.SortOrder.LayoutOrder;
UIGridLayout.Parent = ScrollingFrame;
local Frame3 = Instance.new("Frame");
Frame3.Name = "DescPanel";
Frame3.AnchorPoint = Vector2.new(1, 0);
Frame3.Position = UDim2.new(1, -12, 0, 40);
Frame3.Size = UDim2.new(0.5, -18, 1, -52);
Frame3.BackgroundColor3 = Color3.fromRGB(26, 26, 26);
Frame3.BackgroundTransparency = 0.1;
Frame3.BorderSizePixel = 0;
Frame3.ClipsDescendants = true;
Frame3.Parent = Frame;
local UICorner = Instance.new("UICorner");
UICorner.CornerRadius = UDim.new(0, 10);
UICorner.Parent = Frame3;
local Color3_fromRGB_ret8 = Color3.fromRGB(58, 58, 58);
local UIStroke = Instance.new("UIStroke");
UIStroke.Color = Color3_fromRGB_ret8 or Color3_fromRGB_ret7;
UIStroke.Thickness = 1;
UIStroke.Parent = Frame3;
local UIPadding = Instance.new("UIPadding");
UIPadding.PaddingLeft = UDim.new(0, 12);
UIPadding.PaddingRight = UDim.new(0, 12);
UIPadding.PaddingTop = UDim.new(0, 10);
UIPadding.PaddingBottom = UDim.new(0, 10);
UIPadding.Parent = Frame3;
local UIListLayout2 = Instance.new("UIListLayout");
UIListLayout2.Padding = UDim.new(0, 6);
UIListLayout2.SortOrder = Enum.SortOrder.LayoutOrder;
UIListLayout2.Parent = Frame3;
local TextLabel3 = Instance.new("TextLabel");
TextLabel3.BackgroundTransparency = 1;
TextLabel3.Size = UDim2.new(1, 0, 0, 20);
TextLabel3.LayoutOrder = 1;
TextLabel3.TextWrapped = true;
TextLabel3.AutomaticSize = Enum.AutomaticSize.Y;
TextLabel3.TextTruncate = Enum.TextTruncate.None;
TextLabel3.Font = Enum.Font.GothamBold;
TextLabel3.TextSize = 15;
TextLabel3.TextColor3 = Color3_fromRGB_ret6;
TextLabel3.TextXAlignment = Enum.TextXAlignment.Left;
TextLabel3.Text = "Select an item";
TextLabel3.Parent = Frame3;
local TextLabel4 = Instance.new("TextLabel");
TextLabel4.BackgroundTransparency = 1;
TextLabel4.Size = UDim2.new(1, 0, 0, 0);
TextLabel4.AutomaticSize = Enum.AutomaticSize.Y;
TextLabel4.LayoutOrder = 2;
TextLabel4.Font = Enum.Font.Gotham;
TextLabel4.TextSize = 12;
TextLabel4.TextColor3 = Color3.fromRGB(176, 176, 176);
TextLabel4.TextWrapped = true;
TextLabel4.TextYAlignment = Enum.TextYAlignment.Top;
TextLabel4.TextXAlignment = Enum.TextXAlignment.Left;
TextLabel4.Text = "Pick something on the left to see what it takes to build it.";
TextLabel4.Parent = Frame3;
local TextLabel5 = Instance.new("TextLabel");
TextLabel5.BackgroundTransparency = 1;
TextLabel5.Size = UDim2.new(1, 0, 0, 16);
TextLabel5.LayoutOrder = 3;
TextLabel5.Font = Enum.Font.GothamBold;
TextLabel5.TextSize = 12;
TextLabel5.TextColor3 = Color3_fromRGB_ret6;
TextLabel5.TextXAlignment = Enum.TextXAlignment.Left;
TextLabel5.Text = "";
TextLabel5.Parent = Frame3;
local Frame4 = Instance.new("Frame");
Frame4.BackgroundTransparency = 1;
Frame4.Size = UDim2.new(1, 0, 0, 0);
Frame4.AutomaticSize = Enum.AutomaticSize.Y;
Frame4.LayoutOrder = 4;
Frame4.Parent = Frame3;
local UIListLayout3 = Instance.new("UIListLayout");
UIListLayout3.Padding = UDim.new(0, 3);
UIListLayout3.SortOrder = Enum.SortOrder.LayoutOrder;
UIListLayout3.Parent = Frame4;
local TextButton = Instance.new("TextButton");
TextButton.AnchorPoint = Vector2.new(0.5, 1);
TextButton.Position = UDim2.new(0.5, 0, 1, 0);
TextButton.LayoutOrder = 99;
TextButton.Size = UDim2.new(1, 0, 0, 36);
TextButton.BackgroundColor3 = Color3.fromRGB(18, 18, 20);
TextButton.Font = Bangers;
TextButton.TextSize = 18;
TextButton.TextColor3 = Color3_fromRGB_ret3;
TextButton.Text = "BUILD";
TextButton.Visible = false;
TextButton.Parent = Frame3;
local UICorner2 = Instance.new("UICorner");
UICorner2.CornerRadius = UDim.new(0, 6);
UICorner2.Parent = TextButton;
local UIStroke2 = Instance.new("UIStroke");
UIStroke2.Color = Color3_fromRGB_ret7;
UIStroke2.Thickness = 2;
UIStroke2.Parent = TextButton;
local Frame5 = Instance.new("Frame");
Frame5.Name = "Content";
Frame5.BackgroundTransparency = 1;
Frame5.Size = UDim2.fromScale(1, 1);
Frame5.Parent = Frame;

for _, child in ipairs(Frame:GetChildren()) do
    if child:IsA("GuiObject") and child ~= Frame5 then
        child.Parent = Frame5;
    end;
end;

local UIScale = Instance.new("UIScale");
UIScale.Parent = Frame5;

local function fitPanel() -- Line: 201
    -- upvalues: Frame (copy), UIScale (copy), Frame5 (copy)
    local Y = Frame.AbsoluteSize.Y;

    if Y <= 0 then
        return;
    end;

    local math_clamp_ret = math.clamp(Y / 360, 0.45, 1);
    UIScale.Scale = math_clamp_ret;
    Frame5.Size = UDim2.fromScale(1 / math_clamp_ret, 1 / math_clamp_ret);
end;

Frame:GetPropertyChangedSignal("AbsoluteSize"):Connect(fitPanel);
task.defer(fitPanel);
local u10 = nil;
local u11 = {};
local u12 = false;
local u13 = "All";

local function applyFilter() -- Line: 215
    -- upvalues: ScrollingFrame (copy), u13 (ref)
    for _, child in ipairs(ScrollingFrame:GetChildren()) do
        if child:IsA("TextButton") then
            child.Visible = u13 == "All" and true or child:GetAttribute("Category") == u13;
        end;
    end;
end;

local u14 = nil;

local function buildChips(p15) -- Line: 223
    -- upvalues: u14 (ref), Frame2 (copy), u13 (ref), Color3_fromRGB_ret6 (copy), Color3_fromRGB_ret3 (copy), Color3_fromRGB_ret4 (copy), Color3_fromRGB_ret7 (copy), Color3_fromRGB_ret (copy), Bangers (copy), applyFilter (copy)
    local v16 = { "All" };

    for _, v in ipairs(p15 or {}) do
        v16[#v16 + 1] = v;
    end;

    local table_concat_ret = table.concat(v16, "|");

    if table_concat_ret == u14 then
        return;
    end;

    u14 = table_concat_ret;

    for _, child in ipairs(Frame2:GetChildren()) do
        if child:IsA("TextButton") then
            child:Destroy();
        end;
    end;

    local function paint() -- Line: 230
        -- upvalues: Frame2 (ref), u13 (ref), Color3_fromRGB_ret6 (ref), Color3_fromRGB_ret3 (ref), Color3_fromRGB_ret4 (ref), Color3_fromRGB_ret7 (ref)
        for _, child in ipairs(Frame2:GetChildren()) do
            if child:IsA("TextButton") then
                local v17 = child.Name == u13;
                child.TextColor3 = v17 and Color3_fromRGB_ret6 or Color3_fromRGB_ret3;
                local v18 = child:FindFirstChildOfClass("UIStroke");

                if v18 then
                    v18.Color = v17 and Color3_fromRGB_ret4 or Color3_fromRGB_ret7;
                end;
            end;
        end;
    end;

    for i, v in ipairs(v16) do
        local TextButton2 = Instance.new("TextButton");
        TextButton2.Name = v;
        TextButton2.AutoButtonColor = false;
        TextButton2.AutomaticSize = Enum.AutomaticSize.X;
        TextButton2.Size = UDim2.new(0, 0, 1, 0);
        TextButton2.BackgroundColor3 = Color3_fromRGB_ret;
        TextButton2.Font = Bangers;
        TextButton2.TextSize = 14;
        TextButton2.Text = v;
        TextButton2.LayoutOrder = i;
        TextButton2.Parent = Frame2;
        local UICorner3 = Instance.new("UICorner");
        UICorner3.CornerRadius = UDim.new(0, 6);
        UICorner3.Parent = TextButton2;
        local UIStroke3 = Instance.new("UIStroke");
        UIStroke3.Color = Color3_fromRGB_ret7 or Color3_fromRGB_ret7;
        UIStroke3.Thickness = 2;
        UIStroke3.Parent = TextButton2;
        local UIPadding2 = Instance.new("UIPadding");
        UIPadding2.PaddingLeft = UDim.new(0, 10);
        UIPadding2.PaddingRight = UDim.new(0, 10);
        UIPadding2.Parent = TextButton2;
        TextButton2.Activated:Connect(function() -- Line: 252
            -- upvalues: u13 (ref), v (copy), paint (copy), applyFilter (ref)
            u13 = v;
            paint();
            applyFilter();
        end);
    end;

    paint();
end;

local function showRecipe(p19) -- Line: 260
    -- upvalues: u10 (ref), Frame4 (copy), TextLabel3 (copy), TextLabel4 (copy), TextLabel5 (copy), TextButton (copy), Color3_fromRGB_ret4 (copy), Color3_fromRGB_ret5 (copy), Color3_fromRGB_ret6 (copy), Color3_fromRGB_ret3 (copy), UIStroke2 (copy), Color3_fromRGB_ret7 (copy)
    u10 = p19;

    for _, child in ipairs(Frame4:GetChildren()) do
        if child:IsA("TextLabel") then
            child:Destroy();
        end;
    end;

    if not p19 then
        TextLabel3.Text = "Select an item";
        TextLabel4.Text = "Pick something on the left to see what it takes to build it.";
        TextLabel5.Text = "";
        TextButton.Visible = false;

        return;
    end;

    TextLabel3.Text = p19.Title;
    TextLabel4.Text = p19.Desc;
    TextLabel5.Text = "Requirements";
    local u20 = 0;

    local function row(p21, p22) -- Line: 272
        -- upvalues: u20 (ref), Color3_fromRGB_ret4 (ref), Color3_fromRGB_ret5 (ref), Frame4 (ref)
        u20 = u20 + 1;
        local TextLabel6 = Instance.new("TextLabel");
        TextLabel6.BackgroundTransparency = 1;
        TextLabel6.Size = UDim2.new(1, 0, 0, 15);
        TextLabel6.AutomaticSize = Enum.AutomaticSize.Y;
        TextLabel6.TextWrapped = true;
        TextLabel6.Font = Enum.Font.Gotham;
        TextLabel6.TextSize = 12;
        TextLabel6.TextColor3 = p22 and Color3_fromRGB_ret4 or Color3_fromRGB_ret5;
        TextLabel6.TextXAlignment = Enum.TextXAlignment.Left;
        TextLabel6.LayoutOrder = u20;
        TextLabel6.Text = p21;
        TextLabel6.Parent = Frame4;
    end;

    for _, v in ipairs(p19.Materials) do
        row(("%s  %d / %d"):format(v.Name, v.Have, v.Need), v.Have >= v.Need);
    end;

    local v23 = tonumber(p19.Intelligence) or 0;

    if v23 > 0 then
        row((v23 >= 80 and "Genius-level" or (v23 >= 60 and "High" or (v23 >= 40 and "Considerable" or (v23 >= 20 and "Moderate" or "Low")))) .. " intelligence needed", p19.HasIntelligence);
    end;

    TextButton.Visible = true;
    TextButton.TextColor3 = p19.CanCraft and Color3_fromRGB_ret6 or Color3_fromRGB_ret3;
    UIStroke2.Color = p19.CanCraft and Color3_fromRGB_ret4 or Color3_fromRGB_ret7;
    TextButton.Text = p19.CanCraft and "BUILD" or "MISSING PARTS";
end;

local function makeCard(u24, p25) -- Line: 303
    -- upvalues: Color3_fromRGB_ret (copy), ScrollingFrame (copy), u10 (ref), Color3_fromRGB_ret4 (copy), Color3_fromRGB_ret7 (copy), ReplicatedStorage (copy), Bangers (copy), Color3_fromRGB_ret2 (copy), showRecipe (copy)
    local TextButton2 = Instance.new("TextButton");
    TextButton2.Name = u24.Name;
    TextButton2.Text = "";
    TextButton2.AutoButtonColor = false;
    TextButton2.BackgroundColor3 = Color3_fromRGB_ret;
    TextButton2.LayoutOrder = p25;
    TextButton2:SetAttribute("Category", u24.Category or "Other");
    TextButton2.Parent = ScrollingFrame;
    local UICorner3 = Instance.new("UICorner");
    UICorner3.CornerRadius = UDim.new(0, 6);
    UICorner3.Parent = TextButton2;
    local v26 = u10 and u10.Name == u24.Name and Color3_fromRGB_ret4 or Color3_fromRGB_ret7;
    local UIStroke3 = Instance.new("UIStroke");
    UIStroke3.Color = v26 or Color3_fromRGB_ret7;
    UIStroke3.Thickness = 2;
    UIStroke3.Parent = TextButton2;
    local ViewportFrame = Instance.new("ViewportFrame");
    ViewportFrame.BackgroundTransparency = 1;
    ViewportFrame.Position = UDim2.new(0, 4, 0, 4);
    ViewportFrame.Size = UDim2.new(1, -8, 0, 62);
    ViewportFrame.Ambient = Color3.fromRGB(200, 200, 200);
    ViewportFrame.LightColor = Color3.fromRGB(255, 255, 255);
    ViewportFrame.Parent = TextButton2;
    local v27 = ReplicatedStorage.Assets:FindFirstChild("Models") and ReplicatedStorage.Assets.Models:FindFirstChild(u24.Model);

    if v27 then
        local WorldModel = Instance.new("WorldModel");
        WorldModel.Parent = ViewportFrame;
        local v28 = v27:Clone();
        v28:PivotTo(CFrame.new());
        v28.Parent = WorldModel;
        local Camera = Instance.new("Camera");
        Camera.Parent = ViewportFrame;
        ViewportFrame.CurrentCamera = Camera;
        ViewportFrame:SetAttribute("SpinZoom", u24.SpinZoom or 10);
    end;

    local TextLabel6 = Instance.new("TextLabel");
    TextLabel6.BackgroundTransparency = 1;
    TextLabel6.Position = UDim2.new(0, 8, 1, -24);
    TextLabel6.Size = UDim2.new(1, -16, 0, 20);
    TextLabel6.Font = Bangers;
    TextLabel6.TextSize = 15;
    TextLabel6.TextColor3 = u24.CanCraft and Color3_fromRGB_ret4 or Color3_fromRGB_ret2;
    TextLabel6.TextXAlignment = Enum.TextXAlignment.Left;
    TextLabel6.TextTruncate = Enum.TextTruncate.AtEnd;
    TextLabel6.Text = u24.Title;
    TextLabel6.Parent = TextButton2;
    TextButton2.Activated:Connect(function() -- Line: 337
        -- upvalues: ScrollingFrame (ref), Color3_fromRGB_ret7 (ref), UIStroke3 (copy), Color3_fromRGB_ret4 (ref), showRecipe (ref), u24 (copy)
        for _, child in ipairs(ScrollingFrame:GetChildren()) do
            local v29 = child:FindFirstChildOfClass("UIStroke");

            if v29 then
                v29.Color = Color3_fromRGB_ret7;
            end;
        end;

        UIStroke3.Color = Color3_fromRGB_ret4;
        showRecipe(u24);
    end);
end;

local u30 = false;
local u31 = 0;
local u32 = nil;

local function refresh() -- Line: 348
    -- upvalues: u30 (ref), u31 (ref), ContractRemote (copy), Frame (copy), refresh (copy), u11 (ref), TextLabel2 (copy), buildChips (copy), u32 (ref), ScrollingFrame (copy), makeCard (copy), applyFilter (copy), Color3_fromRGB_ret4 (copy), Color3_fromRGB_ret2 (copy), u10 (ref), showRecipe (copy)
    if u30 then
        return;
    end;

    u30 = true;
    u31 = u31 + 1;
    local success, result = pcall(ContractRemote.InvokeServer, ContractRemote, {
        Action = "CraftList"
    });
    u30 = false;

    if u31 ~= u31 then
        return;
    end;

    if not success or type(result) ~= "table" then
        warn("[CraftingBoard] CraftList failed:", result);
        task.delay(1, function() -- Line: 358
            -- upvalues: Frame (ref), refresh (ref)
            if Frame.Visible then
                refresh();
            end;
        end);

        return;
    end;

    u11 = result.recipes or {};
    TextLabel2.Text = "";
    buildChips(result.categories);
    local v33 = {};

    for _, v in ipairs(u11) do
        v33[#v33 + 1] = v.Name;
    end;

    local table_concat_ret = table.concat(v33, "|");

    if table_concat_ret == u32 then
        for _, v in ipairs(u11) do
            local v34 = ScrollingFrame:FindFirstChild(v.Name);

            if v34 then
                v34 = v34:FindFirstChildWhichIsA("TextLabel");
            end;

            if v34 then
                v34.TextColor3 = v.CanCraft and Color3_fromRGB_ret4 or Color3_fromRGB_ret2;
            end;
        end;
    else
        u32 = table_concat_ret;

        for _, child in ipairs(ScrollingFrame:GetChildren()) do
            if child:IsA("TextButton") then
                child:Destroy();
            end;
        end;

        for i, v in ipairs(u11) do
            local success2, result2 = pcall(makeCard, v, i);

            if not success2 then
                warn("[CraftingBoard] card failed for", v.Name, result2);
            end;
        end;

        applyFilter();
    end;

    if not u10 then
        if #u11 == 1 then
            showRecipe(u11[1]);
            local v35 = ScrollingFrame:FindFirstChild(u11[1].Name);

            if v35 then
                v35 = v35:FindFirstChildOfClass("UIStroke");
            end;

            if v35 then
                v35.Color = Color3_fromRGB_ret4;
            end;
        end;

        return;
    end;

    local v36 = nil;

    for _, v in ipairs(u11) do
        if v.Name == u10.Name then
            v36 = v;
        end;
    end;

    showRecipe(v36);
end;

TextButton.Activated:Connect(function() -- Line: 395
    -- upvalues: u12 (ref), u10 (ref), ContractRemote (copy), TextButton (copy), refresh (copy)
    if u12 or not (u10 and u10.CanCraft) then
        return;
    end;

    u12 = true;
    local success, result = pcall(ContractRemote.InvokeServer, ContractRemote, {
        Action = "Craft",
        Name = u10.Name
    });
    u12 = false;

    if not (success and (type(result) == "table" and result.ok)) then
        refresh();

        return;
    end;

    TextButton.Text = "BUILT!";
    task.delay(1.2, refresh);
end);
u6.Activated:Connect(function() -- Line: 408
    -- upvalues: Tabs (copy), StatFrame (copy), u6 (copy), Frame (copy), refresh (copy)
    for _, child in ipairs(Tabs:GetChildren()) do
        if child:IsA("ImageButton") then
            child.Image = "rbxassetid://126454867112626";
        end;
    end;

    for _, child in ipairs(StatFrame:GetChildren()) do
        if child:IsA("Frame") and child.Name ~= "Tabs" then
            child.Visible = false;
        end;
    end;

    u6.Image = "rbxassetid://126781002557225";
    Frame.Visible = true;
    refresh();
end);
Frame:GetPropertyChangedSignal("Visible"):Connect(function() -- Line: 421
    -- upvalues: Frame (copy), refresh (copy)
    if Frame.Visible then
        refresh();
    end;
end);
task.spawn(function() -- Line: 422
    -- upvalues: Frame (copy), Inventory (copy), refresh (copy)
    while Frame.Parent do
        if Frame.Visible and Inventory.Visible then
            refresh();
            task.wait(4);
        else
            task.wait(0.5);
        end;
    end;
end);