-- Decompiled with Potassium's decompiler.

local Players = game:GetService("Players");
local UserInputService = game:GetService("UserInputService");
local ReplicatedStorage = game:GetService("ReplicatedStorage");
local RunService = game:GetService("RunService");
local TweenService = game:GetService("TweenService");
local LocalPlayer = Players.LocalPlayer;
local ServerRemote = ReplicatedStorage:WaitForChild("Remotes"):WaitForChild("ServerRemote");
local SoundManager = require(ReplicatedStorage:WaitForChild("Modules"):WaitForChild("Shared"):WaitForChild("SoundManager"));
local Font_new_ret = Font.new("rbxasset://fonts/families/PressStart2P.json");
local Color3_fromRGB_ret = Color3.fromRGB(255, 205, 120);
local Color3_fromRGB_ret2 = Color3.fromRGB(213, 0, 0);
local u1 = { "calm", "peace", "serenity", "focus", "still", "breathe", "patience", "balance", "clarity", "harmony", "tranquil", "gentle", "quiet", "control", "resolve", "steady" };
local u2 = { "anger", "rage", "fury", "hate", "wrath", "chaos", "scream", "destroy", "violence", "revenge", "burn", "crush" };

local function clear() -- Line: 31
    -- upvalues: LocalPlayer (copy)
    local SSJ4Minigame = LocalPlayer.PlayerGui:FindFirstChild("SSJ4Minigame");

    if SSJ4Minigame then
        SSJ4Minigame:Destroy();
    end;
end;

local function pick(p3, p4) -- Line: 36
    for i = 1, 20 do
        local v5 = p3[math.random(#p3)];

        if v5 ~= p4 then
            return v5;
        end;

        local _ = i;
    end;

    return p3[1];
end;

local function label(p6, p7, p8, p9, p10, p11, p12) -- Line: 44
    -- upvalues: Font_new_ret (copy)
    local TextLabel = Instance.new("TextLabel");
    TextLabel.Name = p7;
    TextLabel.AnchorPoint = Vector2.new(0.5, 0);
    TextLabel.Position = UDim2.new(0.5, 0, 0, p11);
    TextLabel.Size = UDim2.new(1, -20, 0, p12);
    TextLabel.BackgroundTransparency = 1;
    TextLabel.Text = p8;
    TextLabel.FontFace = Font_new_ret;
    TextLabel.TextSize = p9;
    TextLabel.TextColor3 = p10;
    TextLabel.TextWrapped = true;
    TextLabel.Parent = p6;
    local UIStroke = Instance.new("UIStroke");
    UIStroke.Color = Color3.fromRGB(16, 16, 18);
    UIStroke.Thickness = 2;
    UIStroke.Parent = TextLabel;

    return TextLabel;
end;

local function timerBar(p13, p14, p15) -- Line: 61
    -- upvalues: Color3_fromRGB_ret2 (copy)
    local Frame = Instance.new("Frame");
    Frame.Name = "Track";
    Frame.AnchorPoint = Vector2.new(0.5, 1);
    Frame.Position = p14;
    Frame.Size = UDim2.new(0, p15, 0, 8);
    Frame.BackgroundColor3 = Color3.fromRGB(61, 61, 61);
    Frame.BorderSizePixel = 0;
    Frame.Parent = p13;
    local Frame2 = Instance.new("Frame");
    Frame2.Name = "Bar";
    Frame2.AnchorPoint = Vector2.new(0, 0.5);
    Frame2.Position = UDim2.new(0, 0, 0.5, 0);
    Frame2.Size = UDim2.new(1, 0, 1, 0);
    Frame2.BackgroundColor3 = Color3_fromRGB_ret2;
    Frame2.BorderSizePixel = 0;
    Frame2.Parent = Frame;

    return Frame2;
end;

return {
    Start = function(p16) -- Line: 83
        -- upvalues: LocalPlayer (copy), UserInputService (copy), Color3_fromRGB_ret (copy), Color3_fromRGB_ret2 (copy), ServerRemote (copy), TweenService (copy), SoundManager (copy), label (copy), timerBar (copy), pick (copy), u1 (copy), Font_new_ret (copy), u2 (copy), RunService (copy)
        local SSJ4Minigame = LocalPlayer.PlayerGui:FindFirstChild("SSJ4Minigame");

        if SSJ4Minigame then
            SSJ4Minigame:Destroy();
        end;

        local u17 = UserInputService.KeyboardEnabled and not UserInputService.TouchEnabled;
        local ScreenGui = Instance.new("ScreenGui");
        ScreenGui.Name = "SSJ4Minigame";
        ScreenGui.ResetOnSpawn = false;
        ScreenGui.IgnoreGuiInset = true;
        ScreenGui.DisplayOrder = 60;
        local u18 = false;
        local u19 = 0;
        local u20 = nil;
        local u21 = 45;
        local u22 = {};
        local u23 = nil;
        local u24 = nil;
        local u25 = nil;

        local function finish(p26) -- Line: 98
            -- upvalues: u18 (ref), u22 (copy), u24 (ref), Color3_fromRGB_ret (ref), Color3_fromRGB_ret2 (ref), ServerRemote (ref), ScreenGui (copy)
            if u18 then
                return;
            end;

            u18 = true;

            for _, v in ipairs(u22) do
                v:Disconnect();
            end;

            if u24 then
                u24.Text = p26 and "STILL" or "...";
                u24.TextColor3 = p26 and Color3_fromRGB_ret or Color3_fromRGB_ret2;
            end;

            ServerRemote:FireServer(nil, {
                Module = "Ape Transformation",
                Action = p26 and "SSJ4MinigameDone" or "SSJ4MinigameFail"
            });
            task.delay(0.8, function() -- Line: 107
                -- upvalues: ScreenGui (ref)
                if ScreenGui.Parent then
                    ScreenGui:Destroy();
                end;
            end);
        end;

        local function flash(p27) -- Line: 110
            -- upvalues: u25 (ref), TweenService (ref)
            if u25 then
                TweenService:Create(u25, TweenInfo.new(0.12, Enum.EasingStyle.Quad, Enum.EasingDirection.Out, 0, true), {
                    Color = p27
                }):Play();
            end;
        end;

        local function wrong() -- Line: 116
            -- upvalues: SoundManager (ref), u21 (ref), flash (copy), Color3_fromRGB_ret2 (ref)
            SoundManager.AddSound("Incorrect", {
                Parent = workspace.CurrentCamera
            }, "Client");
            u21 = math.max(u21 - 3, 0);
            flash(Color3_fromRGB_ret2);
        end;

        local function advance() -- Line: 122
            -- upvalues: u19 (ref), SoundManager (ref), u17 (copy), u23 (ref), flash (copy), finish (copy)
            u19 = u19 + 1;
            SoundManager.AddSound("Osu Hit", {
                Parent = workspace.CurrentCamera
            }, "Client");

            if not u17 then
                u23.Text = u19 .. " / " .. 10;
            end;

            flash(Color3.fromRGB(120, 255, 160));

            if u19 < 10 then
                return false;
            end;

            finish(true);

            return true;
        end;

        local u28, u29;

        if u17 then
            local Frame = Instance.new("Frame");
            Frame.Name = "Root";
            Frame.AnchorPoint = Vector2.new(0.5, 0.5);
            Frame.Position = UDim2.new(0.5, 0, 0.42, 0);
            Frame.Size = UDim2.new(0, 600, 0, 160);
            Frame.BackgroundTransparency = 1;
            Frame.Parent = ScreenGui;
            u24 = label(Frame, "Word", "", 44, Color3.new(1, 1, 1), 20, 60);
            u24.RichText = true;
            u25 = u24:FindFirstChildOfClass("UIStroke");
            u25.Color = Color3.new(0, 0, 0);
            u25.Thickness = 3;
            u23 = label(Frame, "Prompt", "Type each letter of the word", 12, Color3.new(1, 1, 1), 96, 20);
            u23:FindFirstChildOfClass("UIStroke").Color = Color3.new(0, 0, 0);
            u28 = timerBar(Frame, UDim2.new(0.5, 0, 1, 0), 240);
            local u30 = 0;

            local function render() -- Line: 153
                -- upvalues: u20 (ref), u30 (ref), u24 (ref)
                u24.Text = ("<font color=\"%s\">%s</font>%s"):format("#5CFF8A", u20:sub(1, u30):upper(), (u20:sub(u30 + 1):upper()));
            end;

            u29 = function() -- Line: 158
                -- upvalues: u20 (ref), pick (ref), u1 (ref), u30 (ref), u24 (ref)
                u20 = pick(u1, u20);
                u30 = 0;
                u24.Text = ("<font color=\"%s\">%s</font>%s"):format("#5CFF8A", u20:sub(1, u30):upper(), (u20:sub(u30 + 1):upper()));
            end;

            table.insert(u22, UserInputService.InputBegan:Connect(function(p31, p32) -- Line: 163
                -- upvalues: u18 (ref), u20 (ref), u30 (ref), u24 (ref), advance (copy), u29 (ref), SoundManager (ref), u21 (ref), flash (copy), Color3_fromRGB_ret2 (ref)
                if u18 or not u20 then
                    return;
                end;

                if p31.UserInputType ~= Enum.UserInputType.Keyboard then
                    return;
                end;

                local Name = p31.KeyCode.Name;

                if #Name ~= 1 or not Name:match("%a") then
                    return;
                end;

                if u20:sub(u30 + 1, u30 + 1) == Name:lower() then
                    u30 = u30 + 1;
                    u24.Text = ("<font color=\"%s\">%s</font>%s"):format("#5CFF8A", u20:sub(1, u30):upper(), (u20:sub(u30 + 1):upper()));

                    if u30 >= #u20 and not advance() then
                        u29();
                    end;
                else
                    SoundManager.AddSound("Incorrect", {
                        Parent = workspace.CurrentCamera
                    }, "Client");
                    u21 = math.max(u21 - 3, 0);
                    flash(Color3_fromRGB_ret2);
                end;
            end));
        else
            local Frame = Instance.new("Frame");
            Frame.Name = "Panel";
            Frame.AnchorPoint = Vector2.new(0.5, 0.5);
            Frame.Position = UDim2.new(0.5, 0, 0.5, 0);
            Frame.Size = UDim2.new(0, 460, 0, 300);
            Frame.BackgroundColor3 = Color3.fromRGB(16, 16, 18);
            Frame.BackgroundTransparency = 0.1;
            Frame.BorderSizePixel = 0;
            Frame.Parent = ScreenGui;
            local UICorner = Instance.new("UICorner");
            UICorner.CornerRadius = UDim.new(0, 12);
            UICorner.Parent = Frame;
            u25 = Instance.new("UIStroke");
            u25.Color = Color3_fromRGB_ret;
            u25.Thickness = 2;
            u25.Parent = Frame;
            label(Frame, "Title", "FIND YOUR CALM", 18, Color3_fromRGB_ret, 16, 24);
            local u33 = label(Frame, "Hint", "Tap only the calm words. Never the angry ones.", 10, Color3.fromRGB(220, 220, 220), 46, 36);
            u23 = label(Frame, "Progress", "0 / " .. 10, 12, Color3.fromRGB(245, 245, 245), 84, 18);
            u28 = timerBar(Frame, UDim2.new(0.5, 0, 1, -16), 360);
            local Frame2 = Instance.new("Frame");
            Frame2.AnchorPoint = Vector2.new(0.5, 0);
            Frame2.Position = UDim2.new(0.5, 0, 0, 118);
            Frame2.Size = UDim2.new(1, -30, 0, 110);
            Frame2.BackgroundTransparency = 1;
            Frame2.Parent = Frame;
            local UIListLayout = Instance.new("UIListLayout");
            UIListLayout.FillDirection = Enum.FillDirection.Horizontal;
            UIListLayout.HorizontalAlignment = Enum.HorizontalAlignment.Center;
            UIListLayout.VerticalAlignment = Enum.VerticalAlignment.Center;
            UIListLayout.Padding = UDim.new(0, 12);
            UIListLayout.Parent = Frame2;
            local u34 = {};

            for i = 1, 3 do
                local TextButton = Instance.new("TextButton");
                TextButton.Name = "Choice" .. i;
                TextButton.Size = UDim2.new(0, 130, 0, 90);
                TextButton.BackgroundColor3 = Color3.fromRGB(28, 28, 32);
                TextButton.BorderSizePixel = 0;
                TextButton.AutoButtonColor = true;
                TextButton.FontFace = Font_new_ret;
                TextButton.TextSize = 14;
                TextButton.TextWrapped = true;
                TextButton.TextColor3 = Color3.fromRGB(245, 245, 245);
                TextButton.Parent = Frame2;
                local UICorner2 = Instance.new("UICorner");
                UICorner2.CornerRadius = UDim.new(0, 10);
                UICorner2.Parent = TextButton;
                local UIStroke = Instance.new("UIStroke");
                UIStroke.Color = Color3.fromRGB(245, 245, 245);
                UIStroke.Thickness = 1;
                UIStroke.Parent = TextButton;
                u34[i] = TextButton;
                local _ = i;
            end;

            u29 = function() -- Line: 228
                -- upvalues: u20 (ref), pick (ref), u1 (ref), u2 (ref), u34 (copy)
                u20 = pick(u1, u20);
                local math_random_ret = math.random(3);
                local v35 = pick(u2);
                local v36 = { v35, (pick(u2, v35)) };
                local v37 = 1;

                for i = 1, 3 do
                    local v38 = u34[i];
                    local v39;

                    if i == math_random_ret then
                        v38.Text = u20:upper();
                        v38:SetAttribute("Good", true);
                        v39 = i;
                    else
                        v38.Text = v36[v37]:upper();
                        v38:SetAttribute("Good", false);
                        v37 = v37 + 1;
                        v39 = i;
                    end;
                end;
            end;

            for _, v in ipairs(u34) do
                table.insert(u22, v.Activated:Connect(function() -- Line: 241
                    -- upvalues: u18 (ref), v (copy), advance (copy), u29 (ref), SoundManager (ref), u21 (ref), flash (copy), Color3_fromRGB_ret2 (ref), u19 (ref), u23 (ref), u33 (ref)
                    if u18 then
                        return;
                    end;

                    if v:GetAttribute("Good") then
                        if not advance() then
                            u29();
                        end;
                    else
                        SoundManager.AddSound("Incorrect", {
                            Parent = workspace.CurrentCamera
                        }, "Client");
                        u21 = math.max(u21 - 3, 0);
                        flash(Color3_fromRGB_ret2);
                        u19 = math.max(0, u19 - 1);
                        u23.Text = u19 .. " / " .. 10;
                        u33.Text = "Let it go. Only the calm words.";
                        u29();
                    end;
                end));
            end;
        end;

        ScreenGui.Parent = LocalPlayer.PlayerGui;
        u29();
        table.insert(u22, RunService.Heartbeat:Connect(function(p40) -- Line: 260
            -- upvalues: u18 (ref), u21 (ref), u28 (ref), finish (copy)
            if u18 then
                return;
            end;

            u21 = u21 - p40;
            u28.Size = UDim2.new(math.clamp(u21 / 45, 0, 1), 0, 1, 0);

            if u21 <= 0 then
                finish(false);
            end;
        end));
        local Character = LocalPlayer.Character;

        if Character then
            local AttributeChangedSignal = Character:GetAttributeChangedSignal("GoldenApe");
            table.insert(u22, AttributeChangedSignal:Connect(function() -- Line: 270
                -- upvalues: Character (copy), finish (copy)
                if not Character:GetAttribute("GoldenApe") then
                    finish(false);
                end;
            end));
            local v41 = Character:FindFirstChildOfClass("Humanoid");

            if v41 then
                table.insert(u22, v41.Died:Connect(function() -- Line: 274
                    -- upvalues: finish (copy)
                    finish(false);
                end));
            end;
        end;
    end,

    Clear = function() -- Line: 278
        -- upvalues: LocalPlayer (copy)
        local SSJ4Minigame = LocalPlayer.PlayerGui:FindFirstChild("SSJ4Minigame");

        if SSJ4Minigame then
            SSJ4Minigame:Destroy();
        end;
    end
};