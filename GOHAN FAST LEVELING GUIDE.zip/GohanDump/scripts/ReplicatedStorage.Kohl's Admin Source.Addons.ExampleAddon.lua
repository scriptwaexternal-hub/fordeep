-- Decompiled with Potassium's decompiler.

return function(p1) -- Line: 2
    p1.log("Hello World from ExampleAddon!", "INFO");
    p1.Registry.registerCommand(p1, {
        name = "customcommand",
        description = "Custom command description.",
        group = "General",
        aliases = { "customcommandalias", "customcommandalias2" },
        args = { {
                type = "stringGreedy",
                name = "Message",
                description = "The message to send.",
                optional = true,
                lowerRank = false,
                ignoreSelf = false,
                shouldRequest = false
            } },

        env = function(p2) -- Line: 58, Name: env
            p2.log("Hello World from ExampleAddon customcommand env!", "INFO");

            return {
                countServer = 0
            };
        end,

        envClient = function(p3) -- Line: 68, Name: envClient
            p3.log("Hello World from ExampleAddon customcommand envClient!", "INFO");

            return {
                countClient = 0
            };
        end,

        run = function(p4: any, p5: string?) -- Line: 95, Name: run
            local Message = Instance.new("Message", workspace);
            Message.Text = p5 == nil and "Default message" or p5;
            task.delay(5, Message.Destroy, Message);
            local env = p4.env;
            env.countServer = env.countServer + 1;
            print("Custom command ran on server!", p5, p4.env.countServer);
        end,

        runClient = function(p6, p7) -- Line: 112, Name: runClient
            local env = p6.env;
            env.countClient = env.countClient + 1;
            print("Custom command ran on the client!", p7, p6.env.countClient);
        end
    });
end;