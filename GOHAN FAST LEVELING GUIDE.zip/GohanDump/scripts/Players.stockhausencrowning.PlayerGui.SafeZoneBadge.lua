-- Decompiled with Potassium's decompiler.

local LocalPlayer = game:GetService("Players").LocalPlayer;
local Color3_fromRGB_ret = Color3.fromRGB(28, 28, 30);
local Color3_fromRGB_ret2 = Color3.fromRGB(216, 213, 205);
local Color3_fromRGB_ret3 = Color3.fromRGB(88, 214, 106);
local Color3_fromRGB_ret4 = Color3.fromRGB(0, 0, 0);
local ScreenGui = Instance.new("ScreenGui");
ScreenGui.Name = "SafeZoneBadge";
ScreenGui.ResetOnSpawn = false;
ScreenGui.IgnoreGuiInset = false;
ScreenGui.DisplayOrder = 30;
ScreenGui.Enabled = false;
ScreenGui.Parent = LocalPlayer:WaitForChild("PlayerGui");
local Frame = Instance.new("Frame");
Frame.AnchorPoint = Vector2.new(0.5, 0);
Frame.Position = UDim2.new(0.5, 0, 0, 68);
Frame.Size = UDim2.fromOffset(118, 22);
Frame.BackgroundColor3 = Color3_fromRGB_ret;
Frame.BackgroundTransparency = 0.15;
Frame.BorderSizePixel = 0;
Frame.Parent = ScreenGui;
local UICorner = Instance.new("UICorner");
UICorner.CornerRadius = UDim.new(0, 4);
UICorner.Parent = Frame;
local UIStroke = Instance.new("UIStroke");
UIStroke.Color = Color3_fromRGB_ret4;
UIStroke.Thickness = 2;
UIStroke.Parent = Frame;
local Frame2 = Instance.new("Frame");
Frame2.Size = UDim2.fromOffset(8, 8);
Frame2.Position = UDim2.new(0, 8, 0.5, -4);
Frame2.BackgroundColor3 = Color3_fromRGB_ret3;
Frame2.BorderSizePixel = 0;
Frame2.Parent = Frame;
local UICorner2 = Instance.new("UICorner");
UICorner2.CornerRadius = UDim.new(1, 0);
UICorner2.Parent = Frame2;
local TextLabel = Instance.new("TextLabel");
TextLabel.BackgroundTransparency = 1;
TextLabel.Position = UDim2.new(0, 22, 0, 0);
TextLabel.Size = UDim2.new(1, -28, 1, 0);
TextLabel.Font = Enum.Font.Arcade;
TextLabel.Text = "SAFE ZONE";
TextLabel.TextSize = 14;
TextLabel.TextColor3 = Color3_fromRGB_ret2;
TextLabel.TextXAlignment = Enum.TextXAlignment.Left;
TextLabel.Parent = Frame;

local function refresh(p1) -- Line: 65
    -- upvalues: ScreenGui (copy)
    if p1 then
        p1 = p1:GetAttribute("InSafeZone");
    end;

    local v2;

    if p1 == nil then
        v2 = false;
    else
        v2 = p1 ~= false;
    end;

    ScreenGui.Enabled = v2;
end;

local u3 = nil;

local function bind(u4) -- Line: 71
    -- upvalues: u3 (ref), ScreenGui (copy)
    if u3 then
        u3:Disconnect();
    end;

    u3 = u4:GetAttributeChangedSignal("InSafeZone"):Connect(function() -- Line: 73
        -- upvalues: u4 (copy), ScreenGui (ref)
        local v5 = u4;

        if v5 then
            v5 = v5:GetAttribute("InSafeZone");
        end;

        local v6;

        if v5 == nil then
            v6 = false;
        else
            v6 = v5 ~= false;
        end;

        ScreenGui.Enabled = v6;
    end);

    if u4 then
        u4 = u4:GetAttribute("InSafeZone");
    end;

    local v7;

    if u4 == nil then
        v7 = false;
    else
        v7 = u4 ~= false;
    end;

    ScreenGui.Enabled = v7;
end;

if LocalPlayer.Character then
    bind(LocalPlayer.Character);
end;

LocalPlayer.CharacterAdded:Connect(bind);
LocalPlayer.CharacterRemoving:Connect(function() -- Line: 81
    -- upvalues: ScreenGui (copy)
    ScreenGui.Enabled = false;
end);