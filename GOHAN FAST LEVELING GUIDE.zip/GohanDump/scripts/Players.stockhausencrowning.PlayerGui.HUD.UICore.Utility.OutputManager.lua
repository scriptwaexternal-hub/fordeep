-- Decompiled with Potassium's decompiler.

local OutputLabel = script:FindFirstAncestor("HUD").MainFrame.HUDisplay.OutputLabel;

return {
    Update = function(p1) -- Line: 9, Name: Update
        -- upvalues: OutputLabel (copy)
        OutputLabel.Text = math.floor(p1 * 100) / 100 .. "%";
    end
};