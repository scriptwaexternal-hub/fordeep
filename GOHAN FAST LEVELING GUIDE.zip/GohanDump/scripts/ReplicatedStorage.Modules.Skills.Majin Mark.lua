-- Decompiled with Potassium's decompiler.

local ReplicatedStorage = game:GetService("ReplicatedStorage");
local Players = game:GetService("Players");
local Modules = ReplicatedStorage:WaitForChild("Modules");
local Remotes = ReplicatedStorage:WaitForChild("Remotes");
local SkillData = require(Modules.Metadata.SkillData.SkillData);
local SkillRemote = Remotes.SkillRemote;
local LocalPlayer = Players.LocalPlayer;
local Color3_fromRGB_ret = Color3.fromRGB(214, 130, 255);
local Color3_fromRGB_ret2 = Color3.fromRGB(24, 24, 29);
local Color3_fromRGB_ret3 = Color3.fromRGB(41, 41, 50);
local Color3_fromRGB_ret4 = Color3.fromRGB(235, 235, 240);
local Color3_fromRGB_ret5 = Color3.fromRGB(150, 150, 162);
local Color3_fromRGB_ret6 = Color3.fromRGB(20, 20, 20);
local Color3_fromRGB_ret7 = Color3.fromRGB(235, 87, 87);
local u1 = {
    Self = true
};
local u2 = nil;
local u3 = nil;
local u4 = {};
local u5 = { {
        key = true,
        label = "Command Minions",
        hint = "Opens your mark control panel"
    }, {
        key = false,
        label = "Brand a Target",
        hint = "Marks the player in front of you"
    } };

local function corner(p6, p7) -- Line: 64
    local UICorner = Instance.new("UICorner");
    UICorner.CornerRadius = UDim.new(0, p7 or 8);
    UICorner.Parent = p6;
end;

local function setHint(p8, p9) -- Line: 70
    -- upvalues: u3 (ref), Color3_fromRGB_ret5 (copy)
    if not u3 then
        return;
    end;

    u3.Text = p8;
    u3.TextColor3 = p9 or Color3_fromRGB_ret5;
end;

local function refreshModeColors() -- Line: 76
    -- upvalues: u4 (ref), u1 (copy), Color3_fromRGB_ret (copy), Color3_fromRGB_ret3 (copy), Color3_fromRGB_ret6 (copy), Color3_fromRGB_ret4 (copy)
    for i, v in pairs(u4) do
        local v10 = i == u1.Self;
        v.BackgroundColor3 = v10 and Color3_fromRGB_ret or Color3_fromRGB_ret3;
        v.TextColor3 = v10 and Color3_fromRGB_ret6 or Color3_fromRGB_ret4;
    end;
end;

local function buildGui() -- Line: 84
    -- upvalues: u2 (ref), u4 (ref), Color3_fromRGB_ret2 (copy), Color3_fromRGB_ret (copy), u3 (ref), Color3_fromRGB_ret5 (copy), u5 (copy), Color3_fromRGB_ret3 (copy), Color3_fromRGB_ret4 (copy), u1 (copy), refreshModeColors (copy), LocalPlayer (copy)
    if u2 then
        u2:Destroy();
    end;

    u4 = {};
    u2 = Instance.new("ScreenGui");
    u2.Name = "MajinMarkPicker";
    u2.ResetOnSpawn = false;
    u2.DisplayOrder = 60;
    local Frame = Instance.new("Frame");
    Frame.Name = "Main";
    Frame.Size = UDim2.new(0, 250, 0, 190);
    Frame.AnchorPoint = Vector2.new(1, 0.5);
    Frame.Position = UDim2.new(0.99, 0, 0.5, 0);
    Frame.BackgroundColor3 = Color3_fromRGB_ret2;
    Frame.BorderSizePixel = 0;
    Frame.Parent = u2;
    local UICorner = Instance.new("UICorner");
    UICorner.CornerRadius = UDim.new(0, 12);
    UICorner.Parent = Frame;
    local UIStroke = Instance.new("UIStroke");
    UIStroke.Color = Color3_fromRGB_ret;
    UIStroke.Transparency = 0.5;
    UIStroke.Parent = Frame;
    local TextLabel = Instance.new("TextLabel");
    TextLabel.Size = UDim2.new(1, -20, 0, 26);
    TextLabel.Position = UDim2.new(0, 10, 0, 8);
    TextLabel.BackgroundTransparency = 1;
    TextLabel.Text = "Majin Mark";
    TextLabel.TextColor3 = Color3_fromRGB_ret;
    TextLabel.TextScaled = true;
    TextLabel.Font = Enum.Font.GothamBold;
    TextLabel.Parent = Frame;
    local UITextSizeConstraint = Instance.new("UITextSizeConstraint");
    UITextSizeConstraint.MaxTextSize = 18;
    UITextSizeConstraint.Parent = TextLabel;
    u3 = Instance.new("TextLabel");
    u3.Size = UDim2.new(1, -20, 0, 16);
    u3.Position = UDim2.new(0, 10, 0, 34);
    u3.BackgroundTransparency = 1;
    u3.TextColor3 = Color3_fromRGB_ret5;
    u3.TextScaled = true;
    u3.Font = Enum.Font.Gotham;
    u3.Parent = Frame;
    local UITextSizeConstraint2 = Instance.new("UITextSizeConstraint");
    UITextSizeConstraint2.MaxTextSize = 12;
    UITextSizeConstraint2.Parent = u3;

    for i, v in ipairs(u5) do
        local TextButton = Instance.new("TextButton");
        TextButton.Name = "Mode_" .. tostring(v.key);
        TextButton.Size = UDim2.new(1, -20, 0, 38);
        TextButton.Position = UDim2.new(0, 10, 0, 58 + (i - 1) * 46);
        TextButton.BackgroundColor3 = Color3_fromRGB_ret3;
        TextButton.BorderSizePixel = 0;
        TextButton.Text = v.label;
        TextButton.TextColor3 = Color3_fromRGB_ret4;
        TextButton.TextScaled = true;
        TextButton.Font = Enum.Font.Gotham;
        TextButton.Parent = Frame;
        local UICorner2 = Instance.new("UICorner");
        UICorner2.CornerRadius = UDim.new(0, 8);
        UICorner2.Parent = TextButton;
        local UITextSizeConstraint3 = Instance.new("UITextSizeConstraint");
        UITextSizeConstraint3.MaxTextSize = 14;
        UITextSizeConstraint3.Parent = TextButton;
        u4[v.key] = TextButton;
        TextButton.MouseButton1Up:Connect(function() -- Line: 151
            -- upvalues: u1 (ref), v (copy), refreshModeColors (ref), u3 (ref), Color3_fromRGB_ret5 (ref)
            u1.Self = v.key;
            refreshModeColors();

            if not u3 then
                return;
            end;

            u3.Text = v.hint;
            u3.TextColor3 = Color3_fromRGB_ret5;
        end);
    end;

    refreshModeColors();

    for _, v in ipairs(u5) do
        if v.key == u1.Self then
            local hint = v.hint;

            if u3 then
                u3.Text = hint;
                u3.TextColor3 = Color3_fromRGB_ret5;
            end;
        end;
    end;

    u2.Parent = LocalPlayer.PlayerGui;
end;

return {
    OnEquipped = function(p11, p12) -- Line: 168, Name: OnEquipped
        -- upvalues: buildGui (copy)
        buildGui();
    end,

    OnUnequipped = function(p13, p14) -- Line: 172, Name: OnUnequipped
        -- upvalues: u2 (ref), u3 (ref), u4 (ref)
        if u2 then
            u2:Destroy();
            u2 = nil;
            u3 = nil;
            u4 = {};
        end;
    end,

    OnActivated = function(p15, p16) -- Line: 181, Name: OnActivated
        -- upvalues: SkillData (copy), SkillRemote (copy), u1 (copy), Color3_fromRGB_ret7 (copy), u3 (ref), Color3_fromRGB_ret5 (copy), u5 (copy)
        local Any = SkillData.GetAny("Race Skills", "Majin Mark", "Demon");
        local v17 = {
            Module = "SkillHandler",
            SkillModule = "Majin Mark",
            Action = "Charge",
            Attack_Name = "Majin Mark",
            Attack_Type = "Race Skills",
            Race_Type = "Demon"
        };

        if Any then
            Any = Any.KiCost;
        end;

        v17.KiCost = Any;
        v17.MarkSettings = {
            Self = u1.Self
        };
        local v18 = SkillRemote:InvokeServer(v17);

        if not v18 then
            local v19 = Color3_fromRGB_ret7;

            if u3 then
                u3.Text = "Couldn\'t use Majin Mark right now";
                u3.TextColor3 = v19 or Color3_fromRGB_ret5;
            end;

            task.delay(1.5, function() -- Line: 199
                -- upvalues: u5 (ref), u1 (ref), u3 (ref), Color3_fromRGB_ret5 (ref)
                for _, v in ipairs(u5) do
                    if v.key == u1.Self then
                        local hint = v.hint;

                        if u3 then
                            u3.Text = hint;
                            u3.TextColor3 = Color3_fromRGB_ret5;
                        end;
                    end;
                end;
            end);
        end;

        return true, v18;
    end
};