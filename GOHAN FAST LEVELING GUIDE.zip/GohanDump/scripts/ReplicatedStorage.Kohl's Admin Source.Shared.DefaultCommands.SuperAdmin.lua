-- Decompiled with Potassium's decompiler.

local Util = require(script.Parent.Parent:WaitForChild("Util"));

return {
    {
        name = "badge",
        description = "Awards a badge to one or more player(s).",
        aliases = { "awardbadge", "givebadge" },
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) to award the badge."
            }, {
                type = "integer",
                name = "Badge ID",
                description = "The badge ID."
            } },

        run = function(u1, p2, u3) -- Line: 23, Name: run
            -- upvalues: Util (copy)
            local Badge = u1._K.Service.Badge;
            local v4 = Util.Tasks.new();

            for _, v in p2 do
                v4:add(function() -- Line: 28
                    -- upvalues: Util (ref), Badge (copy), v (copy), u3 (copy), u1 (copy)
                    local v5, v6 = Util.Retry(Badge.UserHasBadgeAsync, 5, 2, Badge, v.UserId, u3);

                    if not v5 then
                        error(v6);
                    end;

                    if not v6 then
                        local v7, v8 = Util.Retry(Badge.AwardBadge, 5, 2, Badge, v.UserId, u3);

                        if not v7 then
                            error(v8);
                        end;

                        return v8;
                    end;

                    u1._K.alert(u1.fromPlayer, (`{v.Name} already has the badge!`));
                end);
            end;

            for _, v in v4:wait() do
                local v9 = v[2];

                if not v[1] then
                    return `Failed to award badges: {v9}`;
                end;
            end;

            u1._K.alert(u1.fromPlayer, "Badges awarded!");
        end
    },
    {
        name = "btools",
        description = "Gives Building Tools by F3X to one or more player(s).",
        aliases = { "build", "f3x" },
        credit = { "GigsD4X", "Kohl @Scripth" },
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) to give Building Tools by F3X."
            } },

        env = function(u10) -- Line: 70, Name: env
            local u11 = {};
            task.defer(function() -- Line: 73
                -- upvalues: u11 (copy), u10 (copy)
                u11.tool = u10.Tools:WaitForChild("Building Tools");
                u11.tool.CanBeDropped = false;
                local Part = Instance.new("Part");
                Part.Name = "Handle";
                Part.Size = Vector3.new(0.8, 0.8, 0.8);
                Part.CastShadow = false;
                Part.CanTouch = false;
                Part.CanQuery = false;
                Part.TopSurface = 0;
                Part.BottomSurface = 0;

                for _, v in Enum.NormalId:GetEnumItems() do
                    local Decal = Instance.new("Decal");
                    Decal.Face = v;
                    Decal.Texture = "rbxassetid://129748355";
                    Decal.Parent = Part;
                end;

                Part.Parent = u11.tool;
            end);

            return u11;
        end,

        run = function(p12, p13) -- Line: 96, Name: run
            for _, v in p13 do
                local v14 = v:FindFirstChildOfClass("Backpack");

                if v14 and not v14:FindFirstChild("Building Tools") then
                    p12.env.tool:Clone().Parent = v14;
                end;
            end;
        end
    },
    {
        name = "chat",
        description = "Forces one or more player(s) to chat.",
        aliases = { "forcechat" },
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) who will be forced to chat.",
                shouldRequest = true
            }, {
                type = "string",
                name = "Message",
                description = "The chat message to send."
            } },

        envClient = function(u15) -- Line: 123, Name: envClient
            local function forceChat(p16: string) -- Line: 124
                -- upvalues: u15 (copy)
                u15.Service.TextChat:WaitForChild("TextChannels").RBXGeneral:SendAsync(p16);
            end;

            u15.Remote.ForceChat:Connect(forceChat);
            u15.forceChat = forceChat;
        end,

        env = function(p17) -- Line: 130, Name: env
            return {
                remote = p17.Remote.ForceChat
            };
        end,

        run = function(p18: any, p19: table, p20: string) -- Line: 133, Name: run
            for _, v in p19 do
                p18.env.remote:Fire(v, p20);
            end;
        end
    },
    {
        name = "clearterrain",
        description = "Removes all terrain.",
        aliases = { "cterrain", "clrterrain", "removeterrain" },
        args = {},

        run = function(p21) -- Line: 144, Name: run
            workspace.Terrain:Clear();
        end
    },
    {
        name = "explorer",
        description = "Shows the explorer.",
        args = {},

        runClient = function(p22) -- Line: 152, Name: runClient
            p22._K.client.Explorer.Show();
        end
    },
    {
        name = "incognito",
        description = "Hides one or more player(s) from lower rank players. (Persists until rejoin)",
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) to hide.",
                shouldRequest = true
            }, {
                type = "boolean",
                name = "Hide Character",
                description = "Hides the character, defaults to true.",
                optional = true
            } },

        envClient = function(u23) -- Line: 174, Name: envClient
            local u24 = {
                hidden = u23.UI.state({})
            };

            local function removeCharacter(p25: string) -- Line: 179
                local v26 = workspace:WaitForChild(p25);

                if not (v26 and v26:FindFirstChildOfClass("Humanoid")) then
                    v26 = nil;

                    for _, child in workspace:GetChildren() do
                        if child.Name == p25 and (child:IsA("Model") and child:FindFirstChildOfClass("Humanoid")) then
                            v26 = child;
                            break;
                        end;
                    end;
                end;

                if v26 then
                    v26:Destroy();
                end;
            end;

            u23.Remote.Incognito:Connect(function(p27: any, p28: number, p29: boolean?) -- Line: 196
                -- upvalues: u24 (copy), u23 (copy), removeCharacter (copy)
                if type(p27) == "number" then
                    if p29 == nil then
                        u24.hidden._value[p27] = nil;
                        u24.hidden(u24.hidden._value);

                        return;
                    end;

                    local PlayerByUserId = u23.Service.Players:GetPlayerByUserId(p27);

                    if PlayerByUserId then
                        u24.hidden._value[p27] = PlayerByUserId.Name;
                        u24.hidden(u24.hidden._value);

                        if u23.client.rank._value < p28 then
                            if p29 then
                                pcall(game.Destroy, PlayerByUserId.Character);
                            end;

                            PlayerByUserId:Destroy();
                        end;
                    end;
                elseif type(p27) == "string" and u23.client.rank._value < p28 then
                    removeCharacter(p27);
                end;
            end);
            u23.Remote.Incognito:Fire();

            return u24;
        end,

        env = function(u30) -- Line: 225, Name: env
            local u31 = {
                hidden = {},
                remote = u30.Remote.Incognito
            };

            function u31.apply(p32: userdata, p33: boolean?) -- Line: 231
                -- upvalues: u30 (copy), u31 (copy)
                local Rank = u30.Auth.getRank(p32.UserId);

                if u31.hidden[p32] == false and p33 then
                    u31.remote:FireAll(p32.Name, Rank, p33);
                else
                    u31.remote:FireAll(p32.UserId, Rank, p33);
                end;

                u31.hidden[p32] = p33;
            end;

            local function characterAdded(p34) -- Line: 241
                -- upvalues: u30 (copy), u31 (copy)
                local PlayerFromCharacter = u30.Service.Players:GetPlayerFromCharacter(p34);

                if u31.hidden[PlayerFromCharacter] ~= nil then
                    local Rank = u30.Auth.getRank(PlayerFromCharacter.UserId);
                    u31.remote:FireAll(p34.Name, Rank);
                end;
            end;

            local u35 = {};
            u30.Util.SafePlayerAdded(function(p36: userdata) -- Line: 251
                -- upvalues: u35 (copy), characterAdded (copy), u30 (copy), u31 (copy)
                u35[p36] = p36.CharacterAdded:Connect(characterAdded);

                if p36.Character then
                    local Character = p36.Character;
                    local PlayerFromCharacter = u30.Service.Players:GetPlayerFromCharacter(Character);

                    if u31.hidden[PlayerFromCharacter] ~= nil then
                        local Rank = u30.Auth.getRank(PlayerFromCharacter.UserId);
                        u31.remote:FireAll(Character.Name, Rank);
                    end;
                end;
            end);
            u30.Service.Players.PlayerRemoving:Connect(function(p37) -- Line: 258
                -- upvalues: u30 (copy), u35 (copy), u31 (copy)
                u30.Flux.cleanup(u35[p37]);
                u35[p37] = nil;

                if u31.hidden[p37] ~= nil then
                    u31.hidden[p37] = nil;
                    u31.remote:FireAll(p37.UserId);
                end;
            end);
            u31.remote:Connect(function(p38) -- Line: 267
                -- upvalues: u31 (copy), u30 (copy)
                for i, v in u31.hidden do
                    local Rank = u30.Auth.getRank(i.UserId);
                    u31.remote:Fire(p38, i.UserId, Rank, v);
                end;
            end);

            return u31;
        end,

        run = function(p39: any, p40: table, p41: boolean?) -- Line: 277, Name: run
            local v42 = p41 == nil and true or p41;

            for _, v in p40 do
                p39.env.apply(v, v42);
            end;
        end
    },
    {
        name = "incognitolist",
        description = "Views all incognito players in the server.",

        envClient = function(p43) -- Line: 290, Name: envClient
            local UI = p43.UI;
            local hidden = p43.Registry.commands.incognito.env.hidden;
            local v49 = UI.new("ScrollerFast")({
                Enabled = true,
                DictList = true,
                FilterInput = true,
                ReverseOrder = true,
                Visible = true,
                List = hidden,

                CreateItem = function(p44, p45) -- Line: 302, Name: CreateItem
                    -- upvalues: UI (copy)
                    return UI.new("Frame")({
                        BackgroundTransparency = 1,
                        Size = p44.ItemSize,
                        UI.new("UIPadding")({
                            PaddingTop = UI.Theme.PaddingHalf,
                            PaddingBottom = UI.Theme.PaddingHalf
                        }),
                        UI.new("UIListLayout")({
                            VerticalAlignment = Enum.VerticalAlignment.Center,
                            FillDirection = Enum.FillDirection.Horizontal,
                            SortOrder = Enum.SortOrder.LayoutOrder,
                            Padding = UI.Theme.Padding
                        }),
                        UI.new("ImageLabel")({
                            BackgroundTransparency = UI.Theme.TransparencyHeavy,
                            BackgroundColor3 = UI.Theme.PrimaryText,
                            Size = UDim2.new(1, 0, 1, 0),
                            SizeConstraint = Enum.SizeConstraint.RelativeYY,
                            UI.new("UICorner")({
                                CornerRadius = UDim.new(1, 0)
                            }),
                            UI.new("Stroke")({})
                        }),
                        UI.new("TextLabel")({
                            AutoLocalize = false,
                            AutomaticSize = Enum.AutomaticSize.X,
                            BackgroundTransparency = 1,
                            Size = UDim2.new(0, 0, 1, 0),
                            RichText = true,
                            FontFace = UI.Theme.FontMono,
                            TextSize = UI.Theme.FontSize,
                            TextColor3 = UI.Theme.PrimaryText,
                            TextStrokeColor3 = UI.Theme.Primary,
                            TextStrokeTransparency = UI.Theme.TextStrokeTransparency,
                            TextTruncate = Enum.TextTruncate.SplitWord,
                            TextXAlignment = Enum.TextXAlignment.Left,
                            UI.new("UIFlexItem")({
                                FlexMode = Enum.UIFlexMode.Fill
                            })
                        })
                    });
                end,

                RenderItem = function(p46, p47, p48) -- Line: 349, Name: RenderItem
                    -- upvalues: hidden (copy)
                    p47.ImageLabel.Image = `rbxthumb://type=AvatarHeadShot&id={p48}&w=48&h=48`;
                    p47.TextLabel.Text = `<b>{hidden._value[p48]}</b> <font transparency="0.5">[{p48}]</font>`;
                end
            });
            UI.edit(v49._scroller, { UI.new("UIFlexItem")({
                    FlexMode = Enum.UIFlexMode.Fill
                }) });
            UI.edit(v49._instance, { UI.new("UIPadding")({
                    PaddingTop = UI.Theme.PaddingStroke,
                    PaddingBottom = UI.Theme.PaddingStroke,
                    PaddingLeft = UI.Theme.PaddingStroke,
                    PaddingRight = UI.Theme.PaddingStroke
                }) });

            return {
                scroller = v49,
                window = UI.new("Window")({
                    Parent = UI.LayerTopInset,
                    Title = "Incognito Players",
                    Exitable = true,
                    Position = UDim2.new(0.5, -128, 0.5, -128),
                    Size = UDim2.new(0, 256, 0, 256),
                    v49
                })
            };
        end,

        runClient = function(p50, p51) -- Line: 384, Name: runClient
            p50.env.window._instance.Visible = true;
        end
    },
    {
        name = "reserve",
        description = "Reserves a private server.",
        aliases = { "privateserver" },
        args = { {
                type = "rawString",
                name = "AccessCode",
                description = "The access code for joining the reserved server."
            }, {
                type = "integer",
                name = "PlaceId",
                description = "The place identifier, omit for the current place.",
                optional = true
            } },

        env = function(u52) -- Line: 405, Name: env
            local ReservedServers = u52.Remote.ReservedServers;
            task.spawn(u52.Service.Messaging.SubscribeAsync, u52.Service.Messaging, "_K_ReservedServers", function(p53) -- Line: 411
                -- upvalues: u52 (copy), ReservedServers (copy)
                local Data = p53.Data;

                if type(Data) ~= "table" then
                    if type(Data) == "string" then
                        u52.Data.reservedServers[Data] = nil;
                        ReservedServers:FireAll(Data);
                    end;

                    return;
                end;

                u52.Data.reservedServers[Data[1]] = Data;

                for _, v in u52.Service.Players:GetPlayers() do
                    if u52.Auth.hasCommand(v.UserId, "place") or u52.Auth.hasCommand(v.UserId, "unreserve") then
                        ReservedServers:Fire(v, {
                            [Data[1]] = Data
                        });
                    end;
                end;
            end);

            return {
                remote = ReservedServers
            };
        end,

        envClient = function(u54) -- Line: 431, Name: envClient
            u54.Remote.ReservedServers:Connect(function(p55) -- Line: 432
                -- upvalues: u54 (copy)
                if type(p55) == "table" then
                    u54.Util.Table.merge(u54.Data.reservedServers, p55);

                    return;
                end;

                if type(p55) == "string" then
                    u54.Data.reservedServers[p55] = nil;
                end;
            end);
        end,

        run = function(p56: any, u57: string, p58: number?) -- Line: 440, Name: run
            if p56._K.Data.SEPARATE_DATASTORE then
                return "Reserve command is disabled in private servers.";
            end;

            if p56._K.Data.reservedServers[u57] then
                return `Server "<b>{u57}</b>" is already reserved.`;
            end;

            local v59 = p58 or game.PlaceId;
            local u60 = { u57, p56._K.Service.Teleport:ReserveServer(v59), v59 };
            p56._K.Data.Store.updateAsync("Servers", function(p61) -- Line: 451
                -- upvalues: u57 (copy), u60 (copy)
                local v62 = p61 == nil and {} or p61;

                for i, v in v62 do
                    if #v == 2 then
                        v62[i] = { i, v[1], v[2] };
                    end;
                end;

                v62[u57] = u60;

                return v62;
            end);
            p56.env.remote:FireAll({
                [u57] = u60
            });
            p56._K.Service.Messaging:PublishAsync("_K_ReservedServers", u60);
            p56._K.Remote.Notify:Fire(p56.fromPlayer, {
                Text = `Server "<b>{u57}</b>" has been reserved, use <b>{p56._K.getCommandPrefix(p56.from)}place me @{u57}</b> to join it!`
            });
        end
    },
    {
        name = "unreserve",
        description = "Removes a reserved server.",
        aliases = { "delreserve", "removereserve", "removeprivateserver" },
        args = { {
                type = "reservedServer",
                name = "AccessCode",
                description = "The access code of the reserved server."
            } },

        run = function(p63, p64) -- Line: 487, Name: run
            if p63._K.Data.SEPARATE_DATASTORE then
                return "Unreserve command is disabled in private servers.";
            end;

            local u65 = p64[1];
            local u66 = nil;
            p63._K.Data.Store.updateAsync("Servers", function(p67) -- Line: 494
                -- upvalues: u65 (copy), u66 (ref)
                local v68 = p67 == nil and {} or p67;

                if v68[u65] then
                    u66 = true;
                end;

                v68[u65] = nil;

                return v68;
            end);
            p63._K.Remote.ReservedServers:FireAll(u65);
            p63._K.Service.Messaging:PublishAsync("_K_ReservedServers", u65);
            p63._K.Remote.Notify:Fire(p63.fromPlayer, {
                Text = `Server "<b>{u65}</b>" {u66 and "has been removed" or "was NOT found"}!`
            });
        end
    },
    {
        name = "shutdown",
        description = "Shuts down the server.",
        aliases = { "stopserver" },
        args = { {
                type = "timeSimple",
                name = "Delay",
                description = "The delay before shutting down.",
                optional = true
            }, {
                type = "string",
                name = "Reason",
                description = "The reason for the shutdown.",
                optional = true
            } },

        run = function(p69: any, p70: number?, u71: string?) -- Line: 534, Name: run
            if p70 ~= nil then
                p69._K.Remote.Announce:FireAll({
                    Text = `Server will shut down in {p70} seconds`,
                    From = p69.from,
                    Duration = p70
                });
                task.wait(p70);
            end;

            local u72 = tostring(p69.fromPlayer or p69.from);
            game:GetService("Players").PlayerAdded:Connect(function(p73) -- Line: 544, Name: kick
                -- upvalues: u72 (copy), u71 (copy)
                p73:Kick((`{u72} has shutdown the server.{not u71 and "" or `\nReason: {u71}`}`));
            end);

            for _, v in game:GetService("Players"):GetPlayers() do
                v:Kick((`{u72} has shutdown the server.{not u71 and "" or `\nReason: {u71}`}`));
            end;
        end
    },
    {
        name = "global",
        description = "Runs a command string globally in all servers.",
        aliases = { "gcmd" },
        args = { {
                type = "rawString",
                name = "Command string",
                description = "The command string to run."
            } },

        env = function(u74) -- Line: 564, Name: env
            -- upvalues: Util (copy)
            task.spawn(function() -- Line: 565
                -- upvalues: u74 (copy), Util (ref)
                u74.Service.Messaging:SubscribeAsync("KA_GlobalCommand", function(p75) -- Line: 566
                    -- upvalues: Util (ref), u74 (ref)
                    if type(p75.Data) == "string" then
                        p75.Data = Util.Service.Http:JSONDecode(p75.Data);
                    end;

                    if type(p75.Data) ~= "table" then
                        return;
                    end;

                    local v76, v77 = unpack(p75.Data);

                    if v76 and v77 then
                        u74.Process.runCommands(u74, v76, v77, true, true);
                    end;
                end);
            end);
        end,

        run = function(p78: any, p79: string) -- Line: 582, Name: run
            if p78.global then
                return;
            end;

            if p78._K.Data.SEPARATE_DATASTORE then
                return "Global commands are disabled in private servers.";
            end;

            local CommandPrefix = p78._K.getCommandPrefix(p78.from);

            if string.find(p79, string.format("^%s[^%s\"`,%%s]", CommandPrefix, CommandPrefix)) ~= 1 then
                p79 = CommandPrefix .. p79;
            end;

            local v80, v81 = p78._K.Process.prepareCommands(p78._K, p78.from, p79);

            if not v80 then
                return v81;
            end;

            local v82 = { "hint", "privatehint", "message", "privatemessage", "fullmessage", "notify" };
            local v83 = {};

            for _, v in v81 do
                if not v.definition.args then
                    local v84 = v.array[#v.array];
                    local string_sub_ret = string.sub(p79, v.array[1][1], v84[1] + #v84[2]);
                    table.insert(v83, string_sub_ret);
                end;

                local v85 = table.find(v82, v.definition.name) and "rawString" or "string";
                local v86 = v;
                local v87 = {};

                for i, v2 in v.definition.args do
                    if v2.type == v85 then
                        local v88 = p78._K.Util.String.filterForBroadcast(v86.args[i].rawArg, p78.from);
                        table.insert(v87, v88);
                    else
                        table.insert(v87, v86.args[i].rawArg);
                    end;
                end;

                local v89 = `{CommandPrefix}{v86.definition.name} {table.concat(v87, " ")}`;
                table.insert(v83, v89);
            end;

            local table_concat_ret = table.concat(v83, " ");
            p78._K.Service.Messaging:PublishAsync("KA_GlobalCommand", { p78.from, table_concat_ret });
        end
    }
};