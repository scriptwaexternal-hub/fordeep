-- Decompiled with Potassium's decompiler.

local Players = game:GetService("Players");
local generateValidate = require(script.Parent.Parent:WaitForChild("generateValidate"));

return function(u1) -- Line: 5
    -- upvalues: Players (copy), generateValidate (copy)
    local function roleParse(p2, p3) -- Line: 6
        -- upvalues: u1 (copy), Players (ref)
        local v4 = {};
        local v5 = {};
        local v6 = false;

        for i in u1.Data.roles do
            if string.find(string.lower(i), p2, 1, true) == 1 then
                local v7 = i;
                v6 = true;

                for _, v in Players:GetPlayers() do
                    local v8 = u1.Data.members[tostring(v.UserId)];

                    if v8 and table.find(v8.roles, v7) then
                        local v9, v10 = p3._K.Auth.targetUserArgument(p3, v.UserId, v);

                        if v9 then
                            table.insert(v4, v9);
                        elseif not table.find(v5, v10) then
                            table.insert(v5, v10);
                        end;
                    end;
                end;

                break;
            end;
        end;

        if not v6 then
            return false, "Invalid role";
        end;

        if #v4 <= 0 then
            v4 = false;
        end;

        return v4, #v5 > 0 and table.concat(v5, "\n") or "No targetable player found";
    end;

    local u11 = {};
    local v14 = {
        listable = true,
        transform = string.lower,
        validate = generateValidate(roleParse),
        parse = roleParse,

        suggestions = function(p12, p13) -- Line: 41, Name: suggestions
            -- upvalues: u11 (copy)
            return u11;
        end
    };
    u1.Registry.registerType("rolePlayers", v14);
    task.defer(function() -- Line: 48
        -- upvalues: u1 (copy), u11 (copy)
        repeat
            task.wait();
        until u1.Data.roles;

        for i in u1.Data.roles do
            table.insert(u11, i);
        end;

        table.sort(u11, u1.Auth.roleIdSortAscending);

        for i, v in next, u11 do
            u11[i] = "@" .. v;
        end;
    end);
end;