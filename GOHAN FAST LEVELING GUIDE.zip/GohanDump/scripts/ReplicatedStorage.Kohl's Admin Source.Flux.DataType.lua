-- Decompiled with Potassium's decompiler.

local script_Parent = script.Parent;
require(script_Parent.Type);
local Oklab = require(script_Parent.Color).Oklab;

return {
    pack = function(p1: table, p2: string) -- Line: 14, Name: pack
        -- upvalues: Oklab (copy)
        if p2 == "number" then
            return p1[1];
        end;

        if p2 == "CFrame" then
            return CFrame.new(p1[1], p1[2], p1[3]) * CFrame.fromAxisAngle(Vector3.new(p1[4], p1[5], p1[6]).Unit, p1[7]);
        end;

        if p2 == "Color3" then
            return Oklab.toRGB(Vector3.new(p1[1], p1[2], p1[3]), false);
        end;

        if p2 == "ColorSequenceKeypoint" then
            return ColorSequenceKeypoint.new(p1[4], Oklab.toRGB(Vector3.new(p1[1], p1[2], p1[3]), false));
        end;

        if p2 == "DateTime" then
            return DateTime.fromUnixTimestampMillis(p1[1]);
        end;

        if p2 == "NumberRange" then
            return NumberRange.new(p1[1], p1[2]);
        end;

        if p2 == "NumberSequenceKeypoint" then
            return NumberSequenceKeypoint.new(p1[2], p1[1], p1[3]);
        end;

        if p2 == "PhysicalProperties" then
            return PhysicalProperties.new(p1[1], p1[2], p1[3], p1[4], p1[5]);
        end;

        if p2 == "Ray" then
            return Ray.new(Vector3.new(p1[1], p1[2], p1[3]), (Vector3.new(p1[4], p1[5], p1[6])));
        end;

        if p2 == "Rect" then
            return Rect.new(p1[1], p1[2], p1[3], p1[4]);
        end;

        if p2 == "Region3" then
            local Vector3_new_ret = Vector3.new(p1[1], p1[2], p1[3]);
            local Vector3_new_ret2 = Vector3.new(p1[4] / 2, p1[5] / 2, p1[6] / 2);

            return Region3.new(Vector3_new_ret - Vector3_new_ret2, Vector3_new_ret + Vector3_new_ret2);
        end;

        if p2 == "Region3int16" then
            return Region3int16.new(Vector3int16.new(math.round(p1[1]), math.round(p1[2]), (math.round(p1[3]))), Vector3int16.new(math.round(p1[4]), math.round(p1[5]), (math.round(p1[6]))));
        end;

        if p2 == "UDim" then
            return UDim.new(p1[1], (math.round(p1[2])));
        end;

        if p2 == "UDim2" then
            return UDim2.new(p1[1], math.round(p1[2]), p1[3], (math.round(p1[4])));
        end;

        if p2 == "Vector2" then
            return Vector2.new(p1[1], p1[2]);
        end;

        if p2 == "Vector2int16" then
            return Vector2int16.new(math.round(p1[1]), (math.round(p1[2])));
        end;

        if p2 == "Vector3" then
            return Vector3.new(p1[1], p1[2], p1[3]);
        end;

        if p2 == "Vector3int16" then
            return Vector3int16.new(math.round(p1[1]), math.round(p1[2]), (math.round(p1[3])));
        end;

        return nil;
    end,

    unpack = function(p3: any, p4: string) -- Line: 67, Name: unpack
        -- upvalues: Oklab (copy)
        if p4 == "number" then
            return { p3 };
        end;

        if p4 == "CFrame" then
            local v5, v6 = p3:ToAxisAngle();

            return {
                p3.X,
                p3.Y,
                p3.Z,
                v5.X,
                v5.Y,
                v5.Z,
                v6
            };
        end;

        if p4 == "Color3" then
            local v7 = Oklab.fromRGB(p3);

            return { v7.X, v7.Y, v7.Z };
        end;

        if p4 ~= "ColorSequenceKeypoint" then
            return p4 == "DateTime" and { p3.UnixTimestampMillis } or (p4 == "NumberRange" and { p3.Min, p3.Max } or (p4 == "NumberSequenceKeypoint" and { p3.Value, p3.Time, p3.Envelope } or (p4 == "PhysicalProperties" and {
                p3.Density,
                p3.Friction,
                p3.Elasticity,
                p3.FrictionWeight,
                p3.ElasticityWeight
            } or (p4 == "Ray" and {
                p3.Origin.X,
                p3.Origin.Y,
                p3.Origin.Z,
                p3.Direction.X,
                p3.Direction.Y,
                p3.Direction.Z
            } or (p4 == "Rect" and {
                p3.Min.X,
                p3.Min.Y,
                p3.Max.X,
                p3.Max.Y
            } or (p4 == "Region3" and {
                p3.CFrame.X,
                p3.CFrame.Y,
                p3.CFrame.Z,
                p3.Size.X,
                p3.Size.Y,
                p3.Size.Z
            } or (p4 == "Region3int16" and {
                p3.Min.X,
                p3.Min.Y,
                p3.Min.Z,
                p3.Max.X,
                p3.Max.Y,
                p3.Max.Z
            } or (p4 == "UDim" and { p3.Scale, p3.Offset } or (p4 == "UDim2" and {
                p3.X.Scale,
                p3.X.Offset,
                p3.Y.Scale,
                p3.Y.Offset
            } or (p4 == "Vector2" and { p3.X, p3.Y } or (p4 == "Vector2int16" and { p3.X, p3.Y } or (p4 == "Vector3" and { p3.X, p3.Y, p3.Z } or (p4 == "Vector3int16" and { p3.X, p3.Y, p3.Z } or {})))))))))))));
        end;

        local v8 = Oklab.fromRGB(p3.Value);

        return {
            v8.X,
            v8.Y,
            v8.Z,
            p3.Time
        };
    end
};