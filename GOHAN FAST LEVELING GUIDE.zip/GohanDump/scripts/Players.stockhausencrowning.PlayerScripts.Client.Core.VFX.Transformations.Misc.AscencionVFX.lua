-- Decompiled with Potassium's decompiler.

local Players = game:GetService("Players");
local Debris = game:GetService("Debris");
local ReplicatedStorage = game:GetService("ReplicatedStorage");
game:GetService("RunService");
game:GetService("CollectionService");
local UserInputService = game:GetService("UserInputService");
local ContextActionService = game:GetService("ContextActionService");
local Modules = ReplicatedStorage:WaitForChild("Modules");
local Remotes = ReplicatedStorage:WaitForChild("Remotes");
local Assets = ReplicatedStorage:WaitForChild("Assets");
local _ = Modules.Metadata;
local Shared = Modules.Shared;
local _ = Modules.Utility;
require(Shared.SoundManager);
local GlobalFunctions = require(Modules.GlobalFunctions);
local SoundManager = require(Shared.SoundManager);
require(Shared.CamManager);
local CinemaManager = require(Shared.CinemaManager);
local v1 = script:FindFirstAncestor("VFX");
require(v1:FindFirstChild("ChargeVFX", true));
local ServerRemote = ReplicatedStorage.Remotes.ServerRemote;
local TouchActionRemote = Remotes:WaitForChild("TouchActionRemote");
local LocalPlayer = Players.LocalPlayer;
local Ascension = Assets.Gui.Transformation.Ascension;
local u2 = { "W", "A", "S", "D" };
local u3 = true;
local u4 = false;
local u5 = UserInputService.TouchEnabled and not UserInputService.KeyboardEnabled;
local u6 = {
    [Enum.KeyCode.ButtonY] = "W",
    [Enum.KeyCode.ButtonX] = "A",
    [Enum.KeyCode.ButtonA] = "S",
    [Enum.KeyCode.ButtonB] = "D"
};
local u7 = {
    W = "Y",
    A = "X",
    S = "A",
    D = "B"
};
local u8 = {
    Enum.KeyCode.W,
    Enum.KeyCode.A,
    Enum.KeyCode.S,
    Enum.KeyCode.D,
    Enum.KeyCode.X,
    Enum.KeyCode.F,
    Enum.KeyCode.Space,
    Enum.KeyCode.ButtonY,
    Enum.KeyCode.ButtonX,
    Enum.KeyCode.ButtonA,
    Enum.KeyCode.ButtonB
};

local function gamepadActive() -- Line: 94
    -- upvalues: UserInputService (copy)
    return UserInputService:GetLastInputType().Name:find("Gamepad") ~= nil;
end;

local u9 = false;

local function setPadFocus(p10) -- Line: 102
    -- upvalues: u5 (copy), u9 (ref), TouchActionRemote (copy)
    if not u5 then
        return;
    end;

    if p10 == u9 then
        return;
    end;

    u9 = p10;
    TouchActionRemote:Fire("TouchPad", "EventFocus", p10);
end;

local function Toggle_Can_Place(p11) -- Line: 110
    -- upvalues: u3 (ref)
    u3 = false;
    task.delay(p11, function() -- Line: 112
        -- upvalues: u3 (ref)
        u3 = true;
    end);
end;

local function ClearGui() -- Line: 117
    -- upvalues: LocalPlayer (copy)
    for _, child in pairs(LocalPlayer.PlayerGui:GetChildren()) do
        if child.Name == "AscencionGui" then
            child:Destroy();
        end;
    end;
end;

return {
    Fire = function(u12) -- Line: 129
        -- upvalues: u4 (ref), u3 (ref), LocalPlayer (copy), GlobalFunctions (copy), CinemaManager (copy), u5 (copy), u9 (ref), TouchActionRemote (copy), Ascension (copy), SoundManager (copy), ContextActionService (copy), u6 (copy), u2 (copy), Debris (copy), u8 (copy), ServerRemote (copy), ClearGui (copy), UserInputService (copy), u7 (copy)
        local Time_Limit = u12.Time_Limit;
        local Goal = u12.Goal;
        local _ = u12.Distance or -10;
        u4 = false;
        u3 = true;
        local Character = LocalPlayer.Character;
        local RootAndHumanoid, _ = GlobalFunctions.GetRootAndHumanoid(Character);
        CinemaManager.FadeIn(LocalPlayer);

        if u5 and u9 ~= true then
            u9 = true;
            TouchActionRemote:Fire("TouchPad", "EventFocus", true);
        end;

        local u13 = Ascension.AscencionGui:Clone();
        local Bar = u13.MainFrame.Bar;
        u13.Parent = LocalPlayer.PlayerGui;
        Bar:TweenSize(UDim2.new(0, 0, 1, 0), Enum.EasingDirection.Out, Enum.EasingStyle.Linear, Time_Limit);
        SoundManager.AddSound("Ascension Scream", {
            Parent = RootAndHumanoid
        }, "Client");
        SoundManager.AddSound("Aura Burst", {
            Parent = RootAndHumanoid
        }, "Client");
        local v14 = tick();
        local u15 = 0;
        local u16 = nil;

        local function unbindSink() -- Line: 174
            -- upvalues: ContextActionService (ref)
            pcall(ContextActionService.UnbindAction, ContextActionService, "AscensionInputSink");
        end;

        ContextActionService:BindActionAtPriority("AscensionInputSink", function(p17, p18, p19) -- Line: 180
            -- upvalues: u13 (copy), u3 (ref), u6 (ref), u16 (ref), u2 (ref), SoundManager (ref), RootAndHumanoid (copy), Debris (ref)
            if p18 ~= Enum.UserInputState.Begin then
                return Enum.ContextActionResult.Sink;
            end;

            local KeyItem = u13:FindFirstChild("KeyItem");

            if KeyItem and u3 then
                local v20 = KeyItem:GetAttribute("Letter") or KeyItem.Text;
                local v21 = u6[p19.KeyCode] or p19.KeyCode.Name;

                if v21 == v20 then
                    u16(KeyItem);
                elseif table.find(u2, v21) then
                    KeyItem.TextColor3 = Color3.fromRGB(255, 0, 0);
                    KeyItem.Text = "Wrong!";
                    SoundManager.AddSound("SynthSFX", {
                        Parent = RootAndHumanoid
                    }, "Client");
                    Debris:AddItem(KeyItem, 1.5);
                    u3 = false;
                    task.delay(1.5, function() -- Line: 112
                        -- upvalues: u3 (ref)
                        u3 = true;
                    end);
                end;
            end;

            return Enum.ContextActionResult.Sink;
        end, false, Enum.ContextActionPriority.High.Value + 500, table.unpack(u8));

        u16 = function(p22) -- Line: 203, Name: registerHit
            -- upvalues: SoundManager (ref), RootAndHumanoid (copy), Debris (ref), u3 (ref), u15 (ref), Goal (copy), u4 (ref), ServerRemote (ref), u12 (copy), ContextActionService (ref), ClearGui (ref)
            p22.TextColor3 = Color3.fromRGB(0, 255, 0);
            SoundManager.AddSound("Aura Burst", {
                Parent = RootAndHumanoid
            }, "Client");
            Debris:AddItem(p22, 0.15);
            u3 = false;
            task.delay(0.15, function() -- Line: 112
                -- upvalues: u3 (ref)
                u3 = true;
            end);
            u15 = u15 + 1;

            if Goal <= u15 then
                u4 = true;
                ServerRemote:FireServer(nil, {
                    Module = "TransformationHandler",
                    Action = "SetTransformation",
                    Success = true,
                    Race = u12.Race,
                    Transformation_Name = u12.Transformation_Name
                });
                pcall(ContextActionService.UnbindAction, ContextActionService, "AscensionInputSink");
                ClearGui();
            end;
        end;

        while tick() - v14 < Time_Limit and (not Character:FindFirstChild("K.O") and u15 < Goal) do
            if u3 and not u13:FindFirstChild("KeyItem") then
                local v23 = u2[math.random(1, #u2)];
                local u24 = Ascension.KeyItem:Clone();
                u24.Parent = u13;
                u24:SetAttribute("Letter", v23);

                if UserInputService:GetLastInputType().Name:find("Gamepad") ~= nil then
                    v23 = u7[v23] or v23;
                end;

                u24.Text = v23;

                if u5 then
                    u24.Activated:Connect(function() -- Line: 245
                        -- upvalues: u3 (ref), u24 (copy), u16 (ref)
                        if not u3 then
                            return;
                        end;

                        if u24.Parent == nil then
                            return;
                        end;

                        u16(u24);
                    end);
                end;

                Debris:AddItem(u24, 3);
            end;

            task.wait();
        end;

        CinemaManager.FadeOut(LocalPlayer);

        if u5 and u9 ~= false then
            u9 = false;
            TouchActionRemote:Fire("TouchPad", "EventFocus", false);
        end;

        pcall(ContextActionService.UnbindAction, ContextActionService, "AscensionInputSink");
        ClearGui();

        if u4 == false then
            ServerRemote:FireServer(nil, {
                Module = "TransformationHandler",
                Action = "SetTransformation",
                Success = false,
                Race = u12.Race,
                Transformation_Name = u12.Transformation_Name
            });
        end;
    end
};