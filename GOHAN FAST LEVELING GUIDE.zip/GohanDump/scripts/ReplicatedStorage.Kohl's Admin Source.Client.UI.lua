-- Decompiled with Potassium's decompiler.

local Players = game:GetService("Players");
local GuiService = game:GetService("GuiService");
local TextService = game:GetService("TextService");
local SoundService = game:GetService("SoundService");
local UserInputService = game:GetService("UserInputService");
local Parent = script.Parent.Parent;
local Flux = require(Parent:WaitForChild("Flux"));
require(Parent.Flux:WaitForChild("Type"));
local state = Flux.state;
script:WaitForChild("Classes");
local v1 = Players.LocalPlayer and Players.LocalPlayer:WaitForChild("PlayerGui");
local u2 = {
    Class = {}
};
u2.__index = u2;
setmetatable(u2, Flux);
u2.Fonts = require(script.Fonts);
u2.Theme = require(script.Theme);
u2.Themes = u2.Theme.Themes;
u2.Sound = {};
local v3 = Flux.new("SoundGroup")({
    Name = "_KASounds",
    Parent = SoundService,

    Volume = function() -- Line: 29, Name: Volume
        -- upvalues: u2 (copy)
        return not u2.Theme.SoundEnabled() and 0 or u2.Theme.Volume();
    end
});

for i, v in u2.Theme.Sound do
    u2.Sound[i] = Flux.new("Sound")({
        Name = i,
        Parent = v3,
        SoundId = v,
        SoundGroup = v3
    });
end;

u2.Haptic = {
    Click = Flux.new("HapticEffect")({
        Parent = workspace,
        Type = Enum.HapticEffectType.Custom,
        Flux.action(function(p4) -- Line: 47
            p4:SetWaveformKeys({ FloatCurveKey.new(0, 0.1, Enum.KeyInterpolationMode.Constant), FloatCurveKey.new(1, 0, Enum.KeyInterpolationMode.Constant) });
        end)
    }),
    Hover = Flux.new("HapticEffect")({
        Parent = workspace,
        Type = Enum.HapticEffectType.UIHover
    }),
    Notification = Flux.new("HapticEffect")({
        Parent = workspace,
        Type = Enum.HapticEffectType.UINotification
    })
};

function u2.getFontName(p5) -- Line: 64
    -- upvalues: u2 (copy)
    if typeof(p5) ~= "Font" then
        return p5.Name;
    end;

    local string_match_ret = string.match(p5.Family, "%d+$");

    if string_match_ret then
        return u2.Fonts[string_match_ret];
    end;

    return string.match(p5.Family, "/([^/]+)%.json$");
end;

u2.GuiService = GuiService;
u2.TextService = TextService;
u2.UserInputService = UserInputService;
u2.LocalPlayer = Players.LocalPlayer;
u2.PlayerGui = v1;
u2.Touch = UserInputService.TouchEnabled;
u2.IsConsoleScreen = GuiService:IsTenFootInterface();
u2.Platform = UserInputService.VREnabled and "VR" or (u2.IsConsoleScreen and "Console" or (UserInputService.KeyboardEnabled and UserInputService.MouseEnabled and "PC" or "Mobile"));
u2.Hook = table.freeze({
    type = "Symbol"
});
u2.Function = table.freeze({
    type = "Symbol"
});
u2.Nil = table.freeze({
    type = "Symbol"
});
u2.TopbarInset = state(GuiService, "TopbarInset");
u2.TopbarPadding = Flux.compute(function() -- Line: 137
    -- upvalues: u2 (copy)
    return UDim.new(0, u2.IsConsoleScreen and 10 or u2.TopbarInset().Height - 46);
end);
u2.LayerBottom = Flux.new("ScreenGui")({
    Name = "FluxUILayerBottom",
    ResetOnSpawn = false,
    IgnoreGuiInset = true,
    Parent = v1,
    ZIndexBehavior = Enum.ZIndexBehavior.Sibling,
    ScreenInsets = Enum.ScreenInsets.None
});
u2.LayerDefault = Flux.new("ScreenGui")({
    Name = "FluxUILayerDefault",
    DisplayOrder = 2,
    ResetOnSpawn = false,
    IgnoreGuiInset = true,
    Parent = v1,
    ZIndexBehavior = Enum.ZIndexBehavior.Sibling,
    ScreenInsets = Enum.ScreenInsets.None
});
u2.LayerTop = Flux.new("ScreenGui")({
    Name = "FluxUILayerTop",
    DisplayOrder = 999999999,
    ResetOnSpawn = false,
    IgnoreGuiInset = true,
    Parent = v1,
    ZIndexBehavior = Enum.ZIndexBehavior.Sibling,
    ScreenInsets = Enum.ScreenInsets.None
});
u2.LayerTopInset = u2.new("Frame")({
    Name = "TopbarInset",
    BackgroundTransparency = 1,
    Parent = u2.LayerTop,
    AnchorPoint = Vector2.new(0, 1),
    Position = UDim2.fromScale(0, 1),
    Size = not u2.IsConsoleScreen and function() -- Line: 187
        -- upvalues: u2 (copy)
        return UDim2.new(1, 0, 1, -u2.TopbarInset().Height);
    end or UDim2.new(1, 0, 1, -54)
});
u2.LayerTopbar = Flux.new("ScreenGui")({
    Name = "FluxUILayerTopbar",
    DisplayOrder = 999999999,
    ResetOnSpawn = false,
    IgnoreGuiInset = true,
    Parent = v1,
    ZIndexBehavior = Enum.ZIndexBehavior.Sibling,
    ScreenInsets = Enum.ScreenInsets.TopbarSafeInsets
});
local Frame = u2.new("Frame");
local v6 = {
    Parent = u2.LayerTopbar,
    BackgroundTransparency = 1,
    Position = UDim2.new(0, 0, 0, u2.IsConsoleScreen and 4 or 0),

    Size = function() -- Line: 212, Name: Size
        -- upvalues: u2 (copy)
        return UDim2.new(1, 0, 0, u2.TopbarInset().Height + (u2.IsConsoleScreen and 50 or 0));
    end,

    Visible = function() -- Line: 215, Name: Visible
        -- upvalues: u2 (copy)
        return u2.IsConsoleScreen or u2.TopbarInset().Height > 0;
    end
};
local v7 = u2.new("UIListLayout")({
    FillDirection = Enum.FillDirection.Horizontal,
    SortOrder = Enum.SortOrder.LayoutOrder,
    VerticalAlignment = Enum.VerticalAlignment.Bottom,
    Padding = u2.TopbarPadding
});
local UIPadding = u2.new("UIPadding");
local v8 = {
    PaddingLeft = not u2.IsConsoleScreen and function() -- Line: 228
        -- upvalues: u2 (copy)
        return UDim.new(0, 2 + u2.TopbarPadding().Offset / 2);
    end or UDim.new(0, 10),
    PaddingRight = u2.TopbarPadding
};
local v9;

if u2.IsConsoleScreen then
    v9 = UDim.new(0, 6);
else
    v9 = u2.TopbarPadding;
end;

v8.PaddingTop = v9;
v8.PaddingBottom = UDim.new(0, u2.IsConsoleScreen and 0 or 2);
v6[1], v6[2] = v7, UIPadding(v8);
u2.TopbarFrame = Frame(v6);
u2._activeState = {};

function u2.activateState(p10: any, p11: string) -- Line: 244
    -- upvalues: Flux (copy), u2 (copy)
    if not Flux.isState(p10) then
        error("Invalid active state");
    end;

    local v12 = u2._activeState[p11];

    if v12 and v12 ~= p10 then
        v12(false);
    end;

    u2._activeState[p11] = p10;
    p10(true);
end;

function u2.deactivateState(p13: any, p14: string) -- Line: 263
    -- upvalues: Flux (copy), u2 (copy)
    if not Flux.isState(p13) then
        error("Invalid active state");
    end;

    local v15 = u2._activeState[p14];

    if v15 and v15 == p13 then
        u2._activeState[p14] = nil;
    end;

    p13(false);
end;

function u2.toggleState(p16: any, p17: string) -- Line: 279
    -- upvalues: Flux (copy), u2 (copy)
    if not Flux.isState(p16) then
        error("Invalid active state");
    end;

    if p16._value then
        u2.deactivateState(p16, p17);

        return;
    end;

    u2.activateState(p16, p17);
end;

function u2.clearState(p18: string) -- Line: 291
    -- upvalues: u2 (copy), Flux (copy)
    local v19 = u2._activeState[p18];

    if Flux.isState(v19) then
        v19(false);
        u2._activeState[p18] = nil;
    end;
end;

function u2.clearActiveStates() -- Line: 300
    -- upvalues: u2 (copy)
    for i in u2._activeState do
        u2.clearState(i);
    end;
end;

function u2.getLuminance(p20) -- Line: 307
    return math.sqrt(0.299 * p20.R ^ 2 + 0.587 * p20.G ^ 2 + 0.114 * p20.B ^ 2);
end;

function u2.invertLuminance(p21, p22: number) -- Line: 312
    local v23 = 0.299 * p21.R ^ 2;
    local v24 = 0.587 * p21.G ^ 2;
    local v25 = 0.114 * p21.B ^ 2;
    local math_sqrt_ret = math.sqrt(v23 + v24 + v25);

    if math_sqrt_ret > 0.5 then
        p22 = -p22;
    end;

    local v26 = math.clamp(math_sqrt_ret + p22, 0, 1) / math_sqrt_ret;
    local math_sqrt_ret2 = math.sqrt(v23 * v26 / 0.299);
    local math_clamp_ret = math.clamp(math_sqrt_ret2, 0, 1);
    local math_sqrt_ret3 = math.sqrt(v24 * v26 / 0.587);
    local math_clamp_ret2 = math.clamp(math_sqrt_ret3, 0, 1);
    local math_sqrt_ret4 = math.sqrt(v25 * v26 / 0.114);
    local math_clamp_ret3 = math.clamp(math_sqrt_ret4, 0, 1);

    return Color3.new(math_clamp_ret, math_clamp_ret2, math_clamp_ret3);
end;

function u2.pointInGuiObject(p27: number, p28: number, p29: userdata) -- Line: 331
    local AbsoluteSize = p29.AbsoluteSize;
    local AbsolutePosition = p29.AbsolutePosition;
    local v30;

    if AbsolutePosition.X <= p27 and (p27 <= AbsolutePosition.X + AbsoluteSize.X and AbsolutePosition.Y <= p28) then
        v30 = p28 <= AbsolutePosition.Y + AbsoluteSize.Y;
    else
        v30 = false;
    end;

    return v30;
end;

function u2.sinkInput(p31: number, p32: number, p33: userdata) -- Line: 337
    -- upvalues: u2 (copy)
    for _, v in u2.PlayerGui:GetGuiObjectsAtPosition(p31, p32) do
        if v == p33 then
            break;
        end;

        if v.Active or v:IsA("GuiButton") then
            return true;
        end;
    end;

    return false;
end;

function u2.retryGetTextBoundsAsync(p34) -- Line: 349
    -- upvalues: TextService (copy)
    local success, result = pcall(TextService.GetTextBoundsAsync, TextService, p34);
    local v35 = 1;

    while not success do
        task.wait(2 ^ v35);
        v35 = v35 + 1;
        success, result = pcall(TextService.GetTextBoundsAsync, TextService, p34);
    end;

    return result;
end;

function u2.makeStatefulDefaults(p36, p37) -- Line: 361
    -- upvalues: u2 (copy), Flux (copy)
    for i, v in p36 do
        local v38;

        if p37 and p37[i] ~= nil then
            v38 = p37[i];
        else
            v38 = v;
        end;

        if typeof(v38) == "function" and p36[i] ~= u2.Function then
            v38 = Flux.compute(v38);
        end;

        if v38 == u2.Nil or v38 == u2.Function then
            p36[i] = nil;
        else
            if not Flux.isState(v38) then
                v38 = Flux.state(v38);
            end;

            p36[i] = v38;
        end;
    end;

    return p36;
end;

function u2.newSinkHoverState(u39: userdata, p40: any) -- Line: 381
    -- upvalues: u2 (copy)
    local u41 = p40 or u2.state(false);
    u2.edit(u39, {
        InputChanged = function(p42, p43) -- Line: 387, Name: InputChanged
            -- upvalues: u2 (ref), u39 (copy), u41 (ref)
            if p43 then
                return;
            end;

            if p42.UserInputType == Enum.UserInputType.MouseMovement or p42.UserInputType == Enum.UserInputType.Touch then
                if u2.sinkInput(p42.Position.X, p42.Position.Y, u39) then
                    u2.deactivateState(u41, "hover");

                    return;
                end;

                u2.activateState(u41, "hover");
            end;
        end,

        InputEnded = function(p44) -- Line: 402, Name: InputEnded
            -- upvalues: u2 (ref), u41 (ref)
            if p44.UserInputType == Enum.UserInputType.MouseMovement or p44.UserInputType == Enum.UserInputType.Touch then
                u2.deactivateState(u41, "hover");
            end;
        end
    });

    return u41;
end;

function u2.edit(p45, p46) -- Line: 419
    -- upvalues: u2 (copy), Flux (copy)
    local v47 = {};
    local v48, v49;

    if type(p45) == "table" then
        v48 = p45._instance;
        v49 = p45._content or p45._instance;
    else
        v48 = p45;
        v49 = v48;
        local v50 = v48;
        v48 = v49;
        v50 = v49;
    end;

    for i, v in p46 do
        if type(i) == "number" and i == math.floor(i) then
            local v51;

            if type(v) == "table" and v._instance then
                v51 = v._instance;
            else
                v51 = v;
            end;

            if typeof(v51) == "Instance" then
                if v51:IsA("GuiObject") then
                    local v52;

                    if v51.LayoutOrder == 0 then
                        v52 = i;
                    else
                        v52 = v51.LayoutOrder;
                    end;

                    v51.LayoutOrder = v52;
                end;

                v51.Parent = v49;
                p46[i] = nil;
            end;
        end;
    end;

    if type(p45) == "table" then
        local v53 = p46[u2.Hook];
        p46[u2.Hook] = nil;

        if v53 then
            for i, v in v53 do
                local v54 = p45[i];

                if not u2.isState(v54) then
                    error((`Invalid UI State Hook {i}`));
                end;

                if type(v) == "function" then
                    table.insert(v47, v54:Connect(v));
                end;
            end;
        end;

        for i, v in p46 do
            local v55 = p45[i];

            if v55 ~= nil then
                p46[i] = nil;

                if typeof(v55) == "RBXScriptSignal" then
                    v55:Connect(v);
                end;
            end;
        end;
    end;

    if not p46[Flux.Clean] then
        p46[Flux.Clean] = {};
    end;

    for _, v in v47 do
        table.insert(p46[Flux.Clean], v);
    end;

    local Parent2 = p46.Parent;

    if Parent2 then
        if type(Parent2) == "table" then
            Parent2 = Parent2._content or Parent2._instance;
        end;

        p46.Parent = Parent2;
    end;

    Flux.edit(v48, p46);

    return p45;
end;

local u56 = require(script.DefaultProperties)(u2);
local u57 = {};
setmetatable(u57, {
    __index = function(p58: any, u59: string) -- Line: 496, Name: __index
        -- upvalues: u2 (copy), u56 (copy)
        local u60 = u2.Class[u59];
        local v61;

        if u60 then
            v61 = function(p62) -- Line: 501
                -- upvalues: u2 (ref), u60 (copy)
                return u2.edit(u60.new(p62), p62);
            end;
        else
            v61 = function(p63) -- Line: 505
                -- upvalues: u59 (copy), u56 (ref), u2 (ref)
                local Instance_new_ret = Instance.new(u59);

                if u56[u59] then
                    u2.edit(Instance_new_ret, u56[u59]);
                end;

                return u2.edit(Instance_new_ret, p63);
            end;
        end;

        p58[u59] = v61;

        return v61;
    end
});

function u2.new(p64) -- Line: 550
    -- upvalues: u57 (copy)
    return u57[p64];
end;

function u2.register(p65: string, p66: any) -- Line: 555
    -- upvalues: u2 (copy)
    if u2.Class[p65] then
        error((`UI class "{p65}" already exists`));
    end;

    u2.Class[p65] = p66;
end;

function u2.registerClasses() -- Line: 563
    -- upvalues: u2 (copy)
    u2.registerClasses = nil;

    for _, child in script.Classes:GetChildren() do
        if child:IsA("ModuleScript") then
            u2.register(child.Name, require(child));
        end;
    end;

    return u2;
end;

return u2;