-- Decompiled with Potassium's decompiler.

local ReplicatedStorage = game:GetService("ReplicatedStorage");
local PhysicsService = game:GetService("PhysicsService");
local TweenService = game:GetService("TweenService");
local Debris = game:GetService("Debris");

local function resolveModules() -- Line: 40
    -- upvalues: ReplicatedStorage (copy)
    local Modules = ReplicatedStorage:FindFirstChild("Modules");

    if Modules then
        return Modules;
    end;

    local success, result = pcall(function() -- Line: 43
        return game:GetService("ServerStorage").OldModel.Data.ReplicatedStorage.Modules;
    end);

    return success and result and result or ReplicatedStorage:WaitForChild("Modules");
end;

local Modules = ReplicatedStorage:FindFirstChild("Modules");

if not Modules then
    local success, result = pcall(function() -- Line: 43
        return game:GetService("ServerStorage").OldModel.Data.ReplicatedStorage.Modules;
    end);
    Modules = success and result and result or ReplicatedStorage:WaitForChild("Modules");
end;

local Shared = Modules.Shared;
local VoxelPool = require(Shared.Vex.VoxelPool);
local u1 = nil;

local function playImpactSound(u2) -- Line: 55
    -- upvalues: u1 (ref), Shared (copy)
    task.spawn(function() -- Line: 59
        -- upvalues: u1 (ref), Shared (ref), u2 (copy)
        if pcall(function() -- Line: 60
            -- upvalues: u1 (ref), Shared (ref)
            u1 = u1 or require(Shared.SoundManager);
        end) and u1 then
            pcall(function() -- Line: 64
                -- upvalues: u1 (ref), u2 (ref)
                u1.AddSound("Rock Impact", {
                    Parent = u2
                }, "Client");
            end);
        end;
    end);
end;

pcall(function() -- Line: 72
    -- upvalues: PhysicsService (copy)
    PhysicsService:RegisterCollisionGroup("Debris");
end);
pcall(function() -- Line: 73
    -- upvalues: PhysicsService (copy)
    PhysicsService:CollisionGroupSetCollidable("Debris", "Debris", false);
end);

for _, v in ipairs({ "Self", "Ragdoll Part", "Phase" }) do
    pcall(function() -- Line: 75
        -- upvalues: PhysicsService (copy), v (copy)
        PhysicsService:CollisionGroupSetCollidable("Debris", v, false);
    end);
end;

local u3 = {
    Debug = false,
    CellSize = 2.5,
    BiteScale = 0.45,
    MaxBiteRadius = 7.5,
    MaxCellsPerRadius = 4,
    EdgeRoughness = 0.35,
    MaxDebris = 5,
    DebrisLifetime = 2.5,
    FadeTime = 1,
    VaporizeFlightTime = 0.25,
    VaporizeTime = 1.2,
    VaporizeRiseMin = 5,
    VaporizeRiseMax = 10,
    HealTime = 15,
    HealFadeTime = 0.6,
    BlastForce = 60,
    HybridDebrisChance = 0.5
};
local Random_new_ret = Random.new();
local u4 = {};
local u5 = 0;

local function getRecord(p6) -- Line: 119
    -- upvalues: u4 (copy), u5 (ref)
    local Attribute = p6:GetAttribute("VexRoot");

    if Attribute and u4[Attribute] then
        return Attribute, u4[Attribute];
    end;

    u5 = u5 + 1;
    local v7 = u5;
    local v8 = p6:Clone();
    v8:SetAttribute("VexRoot", nil);
    local v9 = {
        gen = 0,
        lattice = nil,
        clone = v8,
        parent = p6.Parent,
        pieces = {}
    };
    u4[v7] = v9;

    return v7, v9;
end;

local function fadeInstanceSet(p10, p11, p12) -- Line: 133
    -- upvalues: TweenService (copy)
    local v13 = { p10 };

    for _, descendant in ipairs(p10:GetDescendants()) do
        if descendant:IsA("BasePart") or (descendant:IsA("Decal") or descendant:IsA("Texture")) then
            table.insert(v13, descendant);
        end;
    end;

    for _, v in ipairs(v13) do
        local v14;

        if type(p11) == "table" then
            v14 = p11[v] or p11;
        else
            v14 = p11;
        end;

        if v14 ~= nil then
            TweenService:Create(v, TweenInfo.new(p12), {
                Transparency = v14
            }):Play();
        end;
    end;

    return v13;
end;

local function scheduleHeal(u15, u16, p17) -- Line: 149
    -- upvalues: u4 (copy), fadeInstanceSet (copy)
    u16.gen = u16.gen + 1;
    local gen = u16.gen;
    task.delay(p17, function() -- Line: 152
        -- upvalues: u4 (ref), u15 (copy), u16 (copy), gen (copy), fadeInstanceSet (ref)
        if u4[u15] ~= u16 or u16.gen ~= gen then
            return;
        end;

        u4[u15] = nil;

        for _, v in ipairs(u16.pieces) do
            if v.Parent then
                v:SetAttribute("VexRoot", nil);
            end;
        end;

        if not (u16.parent and u16.parent:IsDescendantOf(game)) then
            for _, v in ipairs(u16.pieces) do
                if v.Parent then
                    v:Destroy();
                end;
            end;

            return;
        end;

        local clone = u16.clone;
        local CanCollide = clone.CanCollide;
        clone.CanCollide = false;
        clone:SetAttribute("VoxHealFade", true);
        local Size = clone.Size;
        local math_max_ret = math.max(Size.X - 0.04, 0.05);
        local math_max_ret2 = math.max(Size.Y - 0.04, 0.05);
        local math_max_ret3 = math.max(Size.Z - 0.04, 0.05);
        clone.Size = Vector3.new(math_max_ret, math_max_ret2, math_max_ret3);
        local v18 = { clone };
        local v19 = {};

        for _, descendant in ipairs(clone:GetDescendants()) do
            if descendant:IsA("BasePart") or (descendant:IsA("Decal") or descendant:IsA("Texture")) then
                table.insert(v18, descendant);
            end;
        end;

        for _, v in ipairs(v18) do
            v19[v] = v.Transparency;
            v.Transparency = 1;
        end;

        clone.Parent = u16.parent;
        fadeInstanceSet(clone, v19, 0.6);
        task.delay(0.6, function() -- Line: 210
            -- upvalues: u16 (ref), clone (copy), Size (copy), CanCollide (copy)
            for _, v in ipairs(u16.pieces) do
                if v.Parent then
                    v:Destroy();
                end;
            end;

            if clone.Parent then
                clone.Size = Size;
                clone.CanCollide = CanCollide;
                clone:SetAttribute("VoxHealFade", nil);
            end;
        end);
    end);
end;

local function buildingOwner(p20) -- Line: 230
    local Parent = p20.Parent;

    while Parent and (Parent ~= workspace and Parent ~= game) do
        if Parent:IsA("Model") or Parent:IsA("Folder") then
            local Attribute = Parent:GetAttribute("Building");

            if Attribute ~= nil then
                return Attribute == true and Parent and Parent or nil;
            end;
        end;

        Parent = Parent.Parent;
    end;

    return nil;
end;

local function isBreakable(p21) -- Line: 242
    -- upvalues: buildingOwner (copy)
    if not p21:IsA("BasePart") then
        return false;
    end;

    if buildingOwner(p21) then
        return false;
    end;

    if p21:GetAttribute("VoxHealFade") then
        return false;
    end;

    if p21.Transparency >= 1 then
        return false;
    end;

    local Attribute = p21:GetAttribute("Breakable");

    if Attribute ~= nil then
        return Attribute == true;
    end;

    local Parent = p21.Parent;

    while Parent and (Parent ~= workspace and Parent ~= game) do
        if Parent:IsA("Model") or Parent:IsA("Folder") then
            local Attribute2 = Parent:GetAttribute("Breakable");

            if Attribute2 ~= nil then
                return Attribute2 == true;
            end;
        end;

        Parent = Parent.Parent;
    end;

    return false;
end;

local function collectBuildings(p22, p23) -- Line: 284
    -- upvalues: buildingOwner (copy)
    local OverlapParams_new_ret = OverlapParams.new();
    OverlapParams_new_ret.FilterType = Enum.RaycastFilterType.Exclude;
    local VoxelDebris = workspace:FindFirstChild("VoxelDebris");

    if VoxelDebris then
        OverlapParams_new_ret.FilterDescendantsInstances = { VoxelDebris };
    end;

    local v24 = {};
    local v25 = {};

    for _, v in ipairs(workspace:GetPartBoundsInBox(p22, p23, OverlapParams_new_ret)) do
        local v26 = buildingOwner(v);

        if v26 and not v24[v26] then
            v24[v26] = true;
            v25[#v25 + 1] = v26;
        end;
    end;

    return v25;
end;

local function collectBreakable(p27, p28) -- Line: 301
    -- upvalues: isBreakable (copy)
    local OverlapParams_new_ret = OverlapParams.new();
    OverlapParams_new_ret.FilterType = Enum.RaycastFilterType.Exclude;
    local VoxelDebris = workspace:FindFirstChild("VoxelDebris");

    if VoxelDebris then
        OverlapParams_new_ret.FilterDescendantsInstances = { VoxelDebris };
    end;

    local v29 = {};

    for _, v in ipairs(workspace:GetPartBoundsInBox(p27, p28, OverlapParams_new_ret)) do
        if isBreakable(v) then
            table.insert(v29, v);
        end;
    end;

    return v29;
end;

local function makeSlab(p30, p31, p32, p33, p34) -- Line: 315
    local v35 = p33 - p32;

    if v35.X < 0.05 or (v35.Y < 0.05 or v35.Z < 0.05) then
        return nil;
    end;

    local Part = Instance.new("Part");
    Part.Size = v35;
    Part.CFrame = p31 * CFrame.new((p32 + p33) / 2);
    Part.Anchored = true;
    Part.Material = p30.Material;
    Part.Color = p30.Color;
    Part.Transparency = p30.Transparency;
    Part.Reflectance = p30.Reflectance;
    Part.CanCollide = p30.CanCollide;
    Part.CastShadow = p30.CastShadow;
    Part.TopSurface = Enum.SurfaceType.Smooth;
    Part.BottomSurface = Enum.SurfaceType.Smooth;

    for i, v in pairs(p30:GetAttributes()) do
        Part:SetAttribute(i, v);
    end;

    for _, child in ipairs(p30:GetChildren()) do
        if child:IsA("Texture") or child:IsA("Decal") then
            child:Clone().Parent = Part;
        end;
    end;

    Part:SetAttribute("VexRoot", p34);
    Part.Name = p30.Name;
    Part.Parent = p30.Parent;

    return Part;
end;

local function launchCube(p36, p37, p38) -- Line: 348
    local v39 = p36.Position - p37;
    local v40 = v39.Magnitude > 0.05 and v39.Unit or Vector3.new(0, 1, 0);
    local v41;

    if p38 and p38.Magnitude > 0.05 then
        v41 = (-p38.Unit * 1.4 + v40 * 0.6 + Vector3.new(0, 0.35, 0)).Unit;
    else
        v41 = (v40 + Vector3.new(0, 0.35, 0)).Unit;
    end;

    p36.AssemblyLinearVelocity = v41 * 60;
end;

local function retireCube(u42) -- Line: 360
    -- upvalues: TweenService (copy), VoxelPool (copy)
    task.delay(1.5, function() -- Line: 361
        -- upvalues: u42 (copy), TweenService (ref), VoxelPool (ref)
        if not u42.Parent then
            return;
        end;

        TweenService:Create(u42, TweenInfo.new(1), {
            Transparency = 1
        }):Play();
        task.delay(1, function() -- Line: 364
            -- upvalues: u42 (ref), VoxelPool (ref)
            if u42.Parent then
                u42.Transparency = 0;
                VoxelPool.release(u42);
            end;
        end);
    end);
end;

local function vaporizeCube(u43) -- Line: 381
    -- upvalues: Random_new_ret (copy), TweenService (copy), VoxelPool (copy)
    task.delay(0.25, function() -- Line: 382
        -- upvalues: u43 (copy), Random_new_ret (ref), TweenService (ref), VoxelPool (ref)
        if not u43.Parent then
            return;
        end;

        local Color = u43.Color;
        u43.Anchored = true;
        u43.CanCollide = false;
        u43.Color = Color3.fromRGB(0, 0, 0);
        local v44 = Random_new_ret:NextNumber(5, 10);
        TweenService:Create(u43, TweenInfo.new(1.2, Enum.EasingStyle.Linear), {
            Transparency = 1,
            Position = u43.Position + Vector3.new(0, v44, 0)
        }):Play();
        task.delay(1.2, function() -- Line: 394
            -- upvalues: u43 (ref), Color (copy), VoxelPool (ref)
            if u43.Parent then
                u43.Color = Color;
                u43.Transparency = 0;
                VoxelPool.release(u43);
            end;
        end);
    end);
end;

local function carvePart(u45, u46, p47, p48, p49, u50, u51, p52, p53) -- Line: 410
    -- upvalues: collectBuildings (copy), Random_new_ret (copy), makeSlab (copy), VoxelPool (copy), u3 (copy), TweenService (copy)
    for _, v in ipairs((collectBuildings(u46, p47))) do
        task.spawn(function() -- Line: 422
            -- upvalues: v (copy), u46 (copy)
            local success, result = pcall(function() -- Line: 423
                -- upvalues: v (ref), u46 (ref)
                require(script.Parent["Building Collapse"]).Collapse(v, u46.Position);
            end);

            if not success then
                warn("[VoxelDestruction] building collapse failed:", result);
            end;
        end);
    end;

    local v54 = p53 and p53.MaxBiteRadius or 7.5;
    local v55 = math.min(p47.X, p47.Y, p47.Z) * 0.45;
    local v56 = math.clamp(v55, 1.875, v54) / 4;
    local math_max_ret = math.max(2.5, v56);
    local Rotation = u45.CFrame.Rotation;
    local v57 = Rotation:Inverse();
    local v58 = v57 * u45.Position;
    local v59 = u45.Size / 2;
    local v60 = v58 - v59;
    local v61 = v58 + v59;
    local lattice = u51.lattice;

    if not lattice then
        lattice = {
            origin = v60
        };
        u51.lattice = lattice;
    end;

    local origin = lattice.origin;
    local v62 = v57 * u46.Position;
    local v63 = math.min(p47.X, p47.Y, p47.Z) * 0.45;
    local math_clamp_ret = math.clamp(v63, math_max_ret * 0.75, v54);
    local v64 = math_clamp_ret + math_max_ret * 0.9;

    local function idx(p65, p66) -- Line: 465
        -- upvalues: math_max_ret (copy)
        return math.floor((p65 - p66) / math_max_ret);
    end;

    local v67 = (math.max(v62.X - v64, v60.X) - origin.X) / math_max_ret;
    local math_floor_ret = math.floor(v67);
    local math_floor_ret2 = math.floor((v60.X + 0.05 - origin.X) / math_max_ret);
    local math_max_ret2 = math.max(math_floor_ret, math_floor_ret2);
    local v68 = (math.max(v62.Y - v64, v60.Y) - origin.Y) / math_max_ret;
    local math_floor_ret3 = math.floor(v68);
    local math_floor_ret4 = math.floor((v60.Y + 0.05 - origin.Y) / math_max_ret);
    local math_max_ret3 = math.max(math_floor_ret3, math_floor_ret4);
    local v69 = (math.max(v62.Z - v64, v60.Z) - origin.Z) / math_max_ret;
    local math_floor_ret5 = math.floor(v69);
    local math_floor_ret6 = math.floor((v60.Z + 0.05 - origin.Z) / math_max_ret);
    local math_max_ret4 = math.max(math_floor_ret5, math_floor_ret6);
    local v70 = (math.min(v62.X + v64, v61.X) - 0.05 - origin.X) / math_max_ret;
    local math_floor_ret7 = math.floor(v70);
    local v71 = (math.min(v62.Y + v64, v61.Y) - 0.05 - origin.Y) / math_max_ret;
    local math_floor_ret8 = math.floor(v71);
    local v72 = (math.min(v62.Z + v64, v61.Z) - 0.05 - origin.Z) / math_max_ret;
    local math_floor_ret9 = math.floor(v72);

    if math_floor_ret7 < math_max_ret2 or (math_floor_ret8 < math_max_ret3 or math_floor_ret9 < math_max_ret4) then
        return nil;
    end;

    local function key(p73, p74, p75) -- Line: 477
        return p73 .. "," .. p74 .. "," .. p75;
    end;

    local u76 = {};
    local v77 = {};
    local v78 = 0;

    for i = math_max_ret2, math_floor_ret7 do
        local v79 = i;

        for i2 = math_max_ret3, math_floor_ret8 do
            local v80 = i2;

            for i3 = math_max_ret4, math_floor_ret9 do
                local v81 = origin + Vector3.new((v79 + 0.5) * math_max_ret, (v80 + 0.5) * math_max_ret, (i3 + 0.5) * math_max_ret);
                local v82;

                if v81.X > v60.X and (v81.X < v61.X and (v81.Y > v60.Y and (v81.Y < v61.Y and v81.Z > v60.Z))) then
                    v82 = v81.Z < v61.Z;
                else
                    v82 = false;
                end;

                local v83;

                if v82 then
                    local Magnitude = (v81 - v62).Magnitude;
                    local v84;

                    if Magnitude <= math_clamp_ret then
                        v84 = true;
                    elseif Magnitude <= v64 then
                        v84 = Random_new_ret:NextNumber() < 0.35;
                    else
                        v84 = false;
                    end;

                    if v84 then
                        v77[v79 .. "," .. v80 .. "," .. i3] = v81;
                        v78 = v78 + 1;
                        v83 = i3;
                    else
                        u76[v79 .. "," .. v80 .. "," .. i3] = true;
                        v83 = i3;
                    end;
                else
                    v83 = i3;
                end;
            end;
        end;
    end;

    if v78 == 0 then
        return nil;
    end;

    local math_max_ret5 = math.max(origin.X + math_max_ret2 * math_max_ret, v60.X);
    local math_max_ret6 = math.max(origin.Y + math_max_ret3 * math_max_ret, v60.Y);
    local math_max_ret7 = math.max(origin.Z + math_max_ret4 * math_max_ret, v60.Z);
    local Vector3_new_ret = Vector3.new(math_max_ret5, math_max_ret6, math_max_ret7);
    local math_min_ret = math.min(origin.X + (math_floor_ret7 + 1) * math_max_ret, v61.X);
    local math_min_ret2 = math.min(origin.Y + (math_floor_ret8 + 1) * math_max_ret, v61.Y);
    local math_min_ret3 = math.min(origin.Z + (math_floor_ret9 + 1) * math_max_ret, v61.Z);
    local Vector3_new_ret2 = Vector3.new(math_min_ret, math_min_ret2, math_min_ret3);
    local u85 = 0;

    local function addSlab(p86, p87) -- Line: 513
        -- upvalues: makeSlab (ref), u45 (copy), Rotation (copy), u50 (copy), u85 (ref), u51 (copy)
        local v88 = makeSlab(u45, Rotation, p86, p87, u50);

        if v88 then
            u85 = u85 + 1;
            table.insert(u51.pieces, v88);
        end;
    end;

    local v89 = makeSlab(u45, Rotation, v60, Vector3.new(Vector3_new_ret.X, v61.Y, v61.Z), u50);

    if v89 then
        u85 = u85 + 1;
        table.insert(u51.pieces, v89);
    end;

    local v90 = makeSlab(u45, Rotation, Vector3.new(Vector3_new_ret2.X, v60.Y, v60.Z), v61, u50);

    if v90 then
        u85 = u85 + 1;
        table.insert(u51.pieces, v90);
    end;

    local v91 = makeSlab(u45, Rotation, Vector3.new(Vector3_new_ret.X, v60.Y, v60.Z), Vector3.new(Vector3_new_ret2.X, Vector3_new_ret.Y, v61.Z), u50);

    if v91 then
        u85 = u85 + 1;
        table.insert(u51.pieces, v91);
    end;

    local v92 = makeSlab(u45, Rotation, Vector3.new(Vector3_new_ret.X, Vector3_new_ret2.Y, v60.Z), Vector3.new(Vector3_new_ret2.X, v61.Y, v61.Z), u50);

    if v92 then
        u85 = u85 + 1;
        table.insert(u51.pieces, v92);
    end;

    local v93 = makeSlab(u45, Rotation, Vector3.new(Vector3_new_ret.X, Vector3_new_ret.Y, v60.Z), Vector3.new(Vector3_new_ret2.X, Vector3_new_ret2.Y, Vector3_new_ret.Z), u50);

    if v93 then
        u85 = u85 + 1;
        table.insert(u51.pieces, v93);
    end;

    local v94 = makeSlab(u45, Rotation, Vector3.new(Vector3_new_ret.X, Vector3_new_ret.Y, Vector3_new_ret2.Z), Vector3.new(Vector3_new_ret2.X, Vector3_new_ret2.Y, v61.Z), u50);

    if v94 then
        u85 = u85 + 1;
        table.insert(u51.pieces, v94);
    end;

    local u95 = {};

    for i = math_max_ret3, math_floor_ret8 do
        local v96 = i;

        for i2 = math_max_ret4, math_floor_ret9 do
            local u97 = i2;

            for i3 = math_max_ret2, math_floor_ret7 do
                local v98 = i3 .. "," .. v96 .. "," .. u97;
                local u99;

                if u76[v98] and not u95[v98] then
                    local u100 = i3;
                    u99 = u100;
                    local v101 = u100;
                    u100 = u99;
                    v101 = u99;

                    while u76[u100 + 1 .. "," .. v96 .. "," .. u97] and (not u95[u100 + 1 .. "," .. v96 .. "," .. u97] and u100 < math_floor_ret7) do
                        u100 = u100 + 1;
                    end;

                    local function rowFree(p102, p103) -- Line: 540
                        -- upvalues: u99 (copy), u100 (ref), u76 (copy), u95 (copy)
                        for i4 = u99, u100 do
                            local v104 = i4 .. "," .. p103 .. "," .. p102;

                            if not u76[v104] or u95[v104] then
                                return false;
                            end;

                            local _ = i4;
                        end;

                        return true;
                    end;

                    local u105 = u97;

                    while u97 < math_floor_ret9 and rowFree(u97 + 1, v96) do
                        u97 = u97 + 1;
                    end;

                    local function planeFree(p106) -- Line: 549
                        -- upvalues: u105 (copy), u97 (ref), rowFree (copy)
                        for i4 = u105, u97 do
                            if not rowFree(i4, p106) then
                                return false;
                            end;

                            local _ = i4;
                        end;

                        return true;
                    end;

                    local v107 = v96;

                    while v96 < math_floor_ret8 do
                        local v108 = v96 + 1;
                        local v109 = true;

                        for i4 = u105, u97 do
                            if not rowFree(i4, v108) then
                                v109 = false;
                                break;
                            end;

                            local _ = i4;
                        end;

                        if not v109 then
                            break;
                        end;

                        v96 = v96 + 1;
                    end;

                    for i4 = u99, u100 do
                        local v110 = i4;

                        for i5 = v107, v96 do
                            local v111 = i5;

                            for i6 = u105, u97 do
                                u95[v110 .. "," .. v111 .. "," .. i6] = true;
                                local _ = i6;
                            end;
                        end;
                    end;

                    local math_max_ret8 = math.max(origin.X + u99 * math_max_ret, v60.X);
                    local math_max_ret9 = math.max(origin.Y + v107 * math_max_ret, v60.Y);
                    local math_max_ret10 = math.max(origin.Z + u105 * math_max_ret, v60.Z);
                    local Vector3_new_ret3 = Vector3.new(math_max_ret8, math_max_ret9, math_max_ret10);
                    local math_min_ret4 = math.min(origin.X + (u100 + 1) * math_max_ret, v61.X);
                    local math_min_ret5 = math.min(origin.Y + (v96 + 1) * math_max_ret, v61.Y);
                    local math_min_ret6 = math.min(origin.Z + (u97 + 1) * math_max_ret, v61.Z);
                    local v112 = makeSlab(u45, Rotation, Vector3_new_ret3, Vector3.new(math_min_ret4, math_min_ret5, math_min_ret6), u50);

                    if v112 then
                        u85 = u85 + 1;
                        table.insert(u51.pieces, v112);
                    end;

                    u97 = u105;
                    v96 = v107;
                else
                    u99 = i3;
                end;
            end;
        end;
    end;

    local v113 = 0;

    if p48 ~= "vaporize" then
        for _, v in pairs(v77) do
            local v114;

            if p48 == "debris" or p48 == "energyDebris" then
                v114 = true;
            elseif p48 == "hybrid" then
                v114 = Random_new_ret:NextNumber() < 0.5;
            else
                v114 = false;
            end;

            if v114 and p52.left > 0 then
                p52.left = p52.left - 1;
                local u115 = VoxelPool.get(Vector3.new(1, 1, 1) * math_max_ret, u45.Material, u45.Color, "Debris");
                u115.CFrame = Rotation * CFrame.new(v);
                u115.Anchored = false;
                u115.Transparency = 0;
                local v116 = u115.Position - u46.Position;
                local v117 = v116.Magnitude > 0.05 and v116.Unit or Vector3.new(0, 1, 0);
                local v118;

                if p49 and p49.Magnitude > 0.05 then
                    v118 = (-p49.Unit * 1.4 + v117 * 0.6 + Vector3.new(0, 0.35, 0)).Unit;
                else
                    v118 = (v117 + Vector3.new(0, 0.35, 0)).Unit;
                end;

                u115.AssemblyLinearVelocity = v118 * u3.BlastForce;

                if p48 == "energyDebris" then
                    task.delay(u3.VaporizeFlightTime, function() -- Line: 382
                        -- upvalues: u115 (copy), Random_new_ret (ref), TweenService (ref), VoxelPool (ref)
                        if not u115.Parent then
                            return;
                        end;

                        local Color = u115.Color;
                        u115.Anchored = true;
                        u115.CanCollide = false;
                        u115.Color = Color3.fromRGB(0, 0, 0);
                        local v119 = Random_new_ret:NextNumber(5, 10);
                        TweenService:Create(u115, TweenInfo.new(1.2, Enum.EasingStyle.Linear), {
                            Transparency = 1,
                            Position = u115.Position + Vector3.new(0, v119, 0)
                        }):Play();
                        task.delay(1.2, function() -- Line: 394
                            -- upvalues: u115 (ref), Color (copy), VoxelPool (ref)
                            if u115.Parent then
                                u115.Color = Color;
                                u115.Transparency = 0;
                                VoxelPool.release(u115);
                            end;
                        end);
                    end);
                else
                    task.delay(u3.DebrisLifetime - u3.FadeTime, function() -- Line: 361
                        -- upvalues: u115 (copy), TweenService (ref), VoxelPool (ref)
                        if not u115.Parent then
                            return;
                        end;

                        TweenService:Create(u115, TweenInfo.new(1), {
                            Transparency = 1
                        }):Play();
                        task.delay(1, function() -- Line: 364
                            -- upvalues: u115 (ref), VoxelPool (ref)
                            if u115.Parent then
                                u115.Transparency = 0;
                                VoxelPool.release(u115);
                            end;
                        end);
                    end);
                end;

                v113 = v113 + 1;
            end;
        end;
    end;

    return u85, v113, v78;
end;

local function shatter(p120, p121, p122, p123, p124, p125, p126) -- Line: 603
    -- upvalues: collectBreakable (copy), getRecord (copy), carvePart (copy), u4 (copy), fadeInstanceSet (copy)
    local v127 = 2 * ((p126 and (p126.MaxBiteRadius or 7.5) or 7.5) * 1.25 + 2.5);
    local math_min_ret = math.min(p122.X, v127);
    local math_min_ret2 = math.min(p122.Y, v127);
    local math_min_ret3 = math.min(p122.Z, v127);
    local Vector3_new_ret = Vector3.new(math_min_ret, math_min_ret2, math_min_ret3);
    local v128 = {
        left = 5
    };
    local v129 = nil;
    local v130 = p123 or 15;
    local v131 = p125 or "debris";

    for _, v in ipairs((collectBreakable(p121, Vector3_new_ret))) do
        if v.Parent then
            local u132, u133 = getRecord(v);
            local v134, _, _ = carvePart(v, p121, p122, v131, p124, u132, u133, v128, p126);

            if v134 then
                v129 = v129 or u133.pieces[#u133.pieces];
                v:Destroy();
                u133.gen = u133.gen + 1;
                local gen = u133.gen;
                task.delay(v130, function() -- Line: 152
                    -- upvalues: u4 (ref), u132 (copy), u133 (copy), gen (copy), fadeInstanceSet (ref)
                    if u4[u132] ~= u133 or u133.gen ~= gen then
                        return;
                    end;

                    u4[u132] = nil;

                    for _, v2 in ipairs(u133.pieces) do
                        if v2.Parent then
                            v2:SetAttribute("VexRoot", nil);
                        end;
                    end;

                    if not (u133.parent and u133.parent:IsDescendantOf(game)) then
                        for _, v2 in ipairs(u133.pieces) do
                            if v2.Parent then
                                v2:Destroy();
                            end;
                        end;

                        return;
                    end;

                    local clone = u133.clone;
                    local CanCollide = clone.CanCollide;
                    clone.CanCollide = false;
                    clone:SetAttribute("VoxHealFade", true);
                    local Size = clone.Size;
                    local math_max_ret = math.max(Size.X - 0.04, 0.05);
                    local math_max_ret2 = math.max(Size.Y - 0.04, 0.05);
                    local math_max_ret3 = math.max(Size.Z - 0.04, 0.05);
                    clone.Size = Vector3.new(math_max_ret, math_max_ret2, math_max_ret3);
                    local v135 = { clone };
                    local v136 = {};

                    for _, descendant in ipairs(clone:GetDescendants()) do
                        if descendant:IsA("BasePart") or (descendant:IsA("Decal") or descendant:IsA("Texture")) then
                            table.insert(v135, descendant);
                        end;
                    end;

                    for _, v2 in ipairs(v135) do
                        v136[v2] = v2.Transparency;
                        v2.Transparency = 1;
                    end;

                    clone.Parent = u133.parent;
                    fadeInstanceSet(clone, v136, 0.6);
                    task.delay(0.6, function() -- Line: 210
                        -- upvalues: u133 (ref), clone (copy), Size (copy), CanCollide (copy)
                        for _, v2 in ipairs(u133.pieces) do
                            if v2.Parent then
                                v2:Destroy();
                            end;
                        end;

                        if clone.Parent then
                            clone.Size = Size;
                            clone.CanCollide = CanCollide;
                            clone:SetAttribute("VoxHealFade", nil);
                        end;
                    end);
                end);
            elseif u133.gen == 0 and #u133.pieces == 0 then
                u4[u132] = nil;
            end;
        end;
    end;

    return v129;
end;

local function soundAnchor(p137) -- Line: 645
    -- upvalues: Debris (copy)
    local Part = Instance.new("Part");
    Part.Size = Vector3.new(1, 1, 1);
    Part.Transparency = 1;
    Part.Anchored = true;
    Part.CanCollide = false;
    Part.CanTouch = false;
    Part.CanQuery = false;
    Part.CFrame = p137;
    Part.Parent = workspace;
    Debris:AddItem(Part, 4);

    return Part;
end;

return {
    Destroy = function(p138, p139, p140, p141) -- Line: 663, Name: Destroy
        -- upvalues: shatter (copy), Debris (copy), u1 (ref), Shared (copy)
        local Location = p138.Location;
        local u142 = shatter("Destroy", Location, p139 or Vector3.new(14, 14, 14), nil, p140, p141 or "vaporize");

        if not u142 then
            u142 = Instance.new("Part");
            u142.Size = Vector3.new(1, 1, 1);
            u142.Transparency = 1;
            u142.Anchored = true;
            u142.CanCollide = false;
            u142.CanTouch = false;
            u142.CanQuery = false;
            u142.CFrame = Location;
            u142.Parent = workspace;
            Debris:AddItem(u142, 4);
        end;

        task.spawn(function() -- Line: 59
            -- upvalues: u1 (ref), Shared (ref), u142 (copy)
            if pcall(function() -- Line: 60
                -- upvalues: u1 (ref), Shared (ref)
                u1 = u1 or require(Shared.SoundManager);
            end) and u1 then
                pcall(function() -- Line: 64
                    -- upvalues: u1 (ref), u142 (ref)
                    u1.AddSound("Rock Impact", {
                        Parent = u142
                    }, "Client");
                end);
            end;
        end);
    end,

    Carve = function(p143, p144, p145, p146, p147, p148) -- Line: 671, Name: Carve
        -- upvalues: shatter (copy)
        shatter("Carve", p143.Location, p144 or Vector3.new(14, 14, 14), p145, p146, p147, p148);
    end,

    BeamCarve = function(p149, p150, p151, p152) -- Line: 680, Name: BeamCarve
        -- upvalues: shatter (copy)
        shatter("BeamCarve", p149.Location, p150 or Vector3.new(14, 14, 14), p151, p152, "energyDebris");
    end
};