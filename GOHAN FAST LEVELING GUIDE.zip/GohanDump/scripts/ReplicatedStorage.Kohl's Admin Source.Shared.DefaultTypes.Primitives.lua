-- Decompiled with Potassium's decompiler.

local u1 = { "+", "true", "yes", "enabled" };
local u2 = {};
local u3 = { "-", "false", "no", "disabled" };

local function startMatch(p4: table, p5: any) -- Line: 7
    for _, v in p4 do
        local string_find_ret, v6 = string.find(v, p5, 1, true);

        if string_find_ret == 1 and v6 > 0 then
            return true;
        end;
    end;

    return false;
end;

local function notNil(p7) -- Line: 3
    return p7 ~= nil, "Invalid value";
end;

local u8 = nil;

for i, v in u1 do
    table.insert(u2, v);
    table.insert(u2, u3[i]);
end;

local u13 = {
    transform = string.lower,

    validate = function(p9) -- Line: 26, Name: validate
        -- upvalues: startMatch (copy), u1 (copy), u3 (copy)
        if p9 == "" then
            return true;
        end;

        return startMatch(u1, p9) or startMatch(u3, p9), "Invalid boolean";
    end,

    parse = function(p10) -- Line: 32, Name: parse
        -- upvalues: startMatch (copy), u1 (copy), u3 (copy)
        if p10 == "" then
            return true;
        end;

        if startMatch(u1, p10) then
            return true;
        end;

        if startMatch(u3, p10) then
            return false;
        end;

        return nil, "Invalid boolean";
    end,

    suggestions = function(p11: string, p12: number) -- Line: 43, Name: suggestions
        -- upvalues: u2 (copy)
        return u2;
    end
};
local u18 = {
    filterLog = true,

    transform = function(p14) -- Line: 50, Name: transform
        return p14 == "" and 0 or tonumber(p14), "Invalid number";
    end,

    validate = function(p15) -- Line: 53, Name: validate
        local v16;

        if p15 == nil then
            v16 = false;
        else
            v16 = p15 == math.floor(p15);
        end;

        return v16, "Only whole numbers are valid";
    end,

    parse = function(p17) -- Line: 56, Name: parse
        return p17;
    end
};
local u20 = {
    filterLog = true,
    transform = u18.transform,
    validate = notNil,

    parse = function(p19) -- Line: 65, Name: parse
        return p19;
    end
};
local u21 = {
    filterLog = true,
    validate = notNil,
    parse = tostring
};
local u22 = {
    validate = notNil
};

return function(p23) -- Line: 80
    -- upvalues: u8 (ref), u13 (copy), u18 (copy), u20 (copy), u21 (copy), u22 (copy)
    u8 = p23;
    u8.Registry.registerType("boolean", u13);
    u8.Registry.registerType("booleans", {
        listable = true
    }, u13);
    u8.Registry.registerType("integer", u18);
    u8.Registry.registerType("integers", {
        listable = true
    }, u18);
    u8.Registry.registerType("number", u20);
    u8.Registry.registerType("numbers", {
        listable = true
    }, u20);
    u8.Registry.registerType("stringGreedy", u21);
    u8.Registry.registerType("rawString", u21);
    u8.Registry.registerType("rawStrings", {
        listable = true
    }, u21);

    function u22.parse(p24, p25) -- Line: 99
        -- upvalues: u8 (ref)
        if u8.Service.RunService:IsClient() or p25.command.global then
            return p24;
        end;

        return not (u8.Auth.hasRestrictedRole(p25.command.from) or u8.Service.TextChat:CanUserChatAsync(p25.command.from)) and "User cannot chat" or u8.Util.String.filterForBroadcast(p24, p25.command.from);
    end;

    u8.Registry.registerType("string", u22);
    u8.Registry.registerType("strings", {
        listable = true
    }, u22);
end;