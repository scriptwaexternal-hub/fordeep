-- Decompiled with Potassium's decompiler.

local Players = game:GetService("Players");
local Debris = game:GetService("Debris");
local ReplicatedStorage = game:GetService("ReplicatedStorage");
game:GetService("RunService");
game:GetService("CollectionService");
local Modules = ReplicatedStorage:WaitForChild("Modules");
ReplicatedStorage:WaitForChild("Remotes");
local Assets = ReplicatedStorage.Assets;
local _ = Modules.Metadata;
local Shared = Modules.Shared;
local _ = Modules.Utility;
local SoundManager = require(Shared.SoundManager);
local GlobalFunctions = require(Modules.GlobalFunctions);
require(Shared.CinemaManager);
local StatRetrieveRemote = ReplicatedStorage.Remotes.StatRetrieveRemote;
local workspace_World = workspace.World;
local Visuals = workspace_World.Visuals;
local LocalPlayer = Players.LocalPlayer;
local _ = Assets.Sounds;
local Particles = Assets.Effects.Particles;

return {
    Dust = function(p1) -- Line: 41
        -- upvalues: GlobalFunctions (copy), Visuals (copy), workspace_World (copy), Particles (copy), Debris (copy)
        local v2 = GlobalFunctions.CastRay(p1.Character.HumanoidRootPart.Position, Vector3.new(0, -10, 0), { Visuals, workspace_World.Live });

        if not v2 then
            return;
        end;

        local v3 = Particles.Dust:Clone();
        v3.Parent = Visuals;
        v3.CFrame = CFrame.new(v2.Position);
        Debris:AddItem(v3, 5);
        local Color = v2.Instance.Color;
        v3.Effect.Color = ColorSequence.new({ ColorSequenceKeypoint.new(0, Color), ColorSequenceKeypoint.new(0.5, Color), ColorSequenceKeypoint.new(1, Color) });
        v3.Effect:Emit(3);
        v3.Effect.Lifetime = NumberRange.new(1, 2);
    end,

    ["Capsule Explosion"] = function(p4) -- Line: 65
        -- upvalues: Particles (copy), Visuals (copy), Debris (copy), SoundManager (copy)
        local _ = p4.Capsule;
        local Position = p4.Capsule.Position;
        local v5 = Particles["Capsule Explosion"]:Clone();
        v5.Parent = Visuals;
        v5.CFrame = CFrame.new(Position);
        local v6 = Particles["Flipbook Explosion 1"].Attachment:Clone();
        v6.Parent = v5;
        local Color3_fromRGB_ret = Color3.fromRGB(255, 175, 38);

        for _, child in pairs(v6:GetChildren()) do
            if child:IsA("ParticleEmitter") then
                child.Color = ColorSequence.new({ ColorSequenceKeypoint.new(0, Color3_fromRGB_ret), ColorSequenceKeypoint.new(1, Color3_fromRGB_ret) });
                child.LightEmission = 1;
                child:Emit(1);
            end;
        end;

        Debris:AddItem(v6, 1);
        local Attachment = v5.Attachment;
        SoundManager.AddSound("Capsule Explosion", {
            Parent = v5
        }, "Client");

        for _, child in pairs(Attachment:GetChildren()) do
            if child:IsA("ParticleEmitter") then
                child:Emit(10);
            end;
        end;

        Debris:AddItem(v5, 20);
    end,

    Sweat = function(p7) -- Line: 105
        -- upvalues: Particles (copy), Debris (copy)
        local v8 = p7.Rate or 10;

        for _, child in pairs(p7.Character:GetChildren()) do
            if child:IsA("Part") then
                local Sweat = child:FindFirstChild("Sweat");

                if Sweat then
                    Sweat.Rate = v8;
                else
                    local u9 = Particles.Sweat:Clone();
                    u9.Parent = child;
                    u9.Rate = v8;
                    task.delay(20, function() -- Line: 121
                        -- upvalues: u9 (copy), Debris (ref)
                        u9.Enabled = false;
                        Debris:AddItem(u9, 3);
                    end);
                end;
            end;
        end;
    end,

    ["New Aura VFX"] = function(p10) -- Line: 140
        -- upvalues: Debris (copy), Particles (copy)
        local Character = p10.Character;

        if not (Character and Character.Parent) then
            return;
        end;

        local HumanoidRootPart = Character:FindFirstChild("HumanoidRootPart");

        if not HumanoidRootPart then
            return;
        end;

        local v11 = p10.Duration or 4;
        local u12 = p10.FadeTime or 3;

        local function killExisting() -- Line: 150
            -- upvalues: Character (copy), Debris (ref), u12 (copy)
            for _, descendant in pairs(Character:GetDescendants()) do
                if descendant.Name == "NewAuraVFX" and descendant:IsA("BasePart") then
                    for _, descendant2 in pairs(descendant:GetDescendants()) do
                        if descendant2:IsA("ParticleEmitter") then
                            descendant2.Enabled = false;
                        end;
                    end;

                    Debris:AddItem(descendant, u12);
                end;
            end;
        end;

        if p10.Stop then
            killExisting();

            return;
        end;

        killExisting();
        local v13 = Particles:FindFirstChild("New Aura VFX");

        if not v13 then
            return;
        end;

        local u14 = v13:Clone();
        u14.Name = "NewAuraVFX";
        u14.CFrame = HumanoidRootPart.CFrame;
        local Color = p10.Color;
        local v15 = tonumber(p10.SizeMult);
        local v16 = tonumber(p10.RateMult);

        for _, descendant in pairs(u14:GetDescendants()) do
            if descendant:IsA("ParticleEmitter") then
                if Color then
                    descendant.Color = ColorSequence.new(Color);
                end;

                local v17;

                if v15 and v15 ~= 1 then
                    v17 = descendant;
                    local v18 = {};

                    for _, v in ipairs(descendant.Size.Keypoints) do
                        table.insert(v18, NumberSequenceKeypoint.new(v.Time, v.Value * v15, v.Envelope * v15));
                    end;

                    v17.Size = NumberSequence.new(v18);
                else
                    v17 = descendant;
                end;

                if v16 and v16 ~= 1 then
                    v17.Rate = v17.Rate * v16;
                end;
            end;
        end;

        local WeldConstraint = Instance.new("WeldConstraint");
        WeldConstraint.Part0 = u14;
        WeldConstraint.Part1 = HumanoidRootPart;
        WeldConstraint.Parent = u14;
        u14.Parent = HumanoidRootPart;
        task.delay(v11, function() -- Line: 203
            -- upvalues: u14 (copy), Debris (ref), u12 (copy)
            if not u14.Parent then
                return;
            end;

            for _, descendant in pairs(u14:GetDescendants()) do
                if descendant:IsA("ParticleEmitter") then
                    descendant.Enabled = false;
                end;
            end;

            Debris:AddItem(u14, u12);
        end);
    end,

    Gravity = function(p19) -- Line: 212
        -- upvalues: LocalPlayer (copy), StatRetrieveRemote (copy), Particles (copy)
        local Character = LocalPlayer.Character;
        local CurrentGravity = LocalPlayer:WaitForChild("PlayerStats"):FindFirstChild("CurrentGravity", true);
        local v20 = StatRetrieveRemote:InvokeServer("GravityMastery") / CurrentGravity.Value;
        math.clamp(v20, 0.75, 1);
        local v21 = {};

        for _, child in pairs(Character:GetChildren()) do
            local v22 = Particles:FindFirstChild("Gravity Effect"):Clone();

            if v22 then
                v22.Parent = child;
                table.insert(v21, v22);
            end;
        end;

        while Character.Parent ~= nil do
            local v23 = StatRetrieveRemote:InvokeServer("GravityMastery") / CurrentGravity.Value;

            if math.clamp(v23, 0.75, 1) >= 1 then
                for _, v in pairs(v21) do
                    v.Rate = 0;
                end;
            else
                for _, v in pairs(v21) do
                    v.Rate = 5;
                end;
            end;

            task.wait(2);
        end;
    end
};