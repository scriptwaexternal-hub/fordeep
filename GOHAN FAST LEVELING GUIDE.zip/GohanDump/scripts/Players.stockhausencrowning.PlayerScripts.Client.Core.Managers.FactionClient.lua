-- Decompiled with Potassium's decompiler.

local ReplicatedStorage = game:GetService("ReplicatedStorage");
local Players = game:GetService("Players");
local Modules = ReplicatedStorage:WaitForChild("Modules");
local Remotes = ReplicatedStorage:WaitForChild("Remotes");
local Factions = ReplicatedStorage.Assets.Gui.Factions;
local UtilityHandler = require(Modules.Utility.UtilityHandler);
local FactionRemote = Remotes.FactionRemote;
local NameCheckRemote = Remotes.NameCheckRemote;
local LocalPlayer = Players.LocalPlayer;
local u1 = {
    Leader = Color3.fromRGB(240, 190, 90),
    ["Co-Commander"] = Color3.fromRGB(226, 163, 58),
    General = Color3.fromRGB(196, 132, 62),
    ["Elite Fighter"] = Color3.fromRGB(158, 122, 78),
    Member = Color3.fromRGB(150, 138, 120)
};
local Color3_fromRGB_ret = Color3.fromRGB(12, 12, 13);
local Color3_fromRGB_ret2 = Color3.fromRGB(28, 28, 30);
Color3.fromRGB(36, 36, 38);
local Color3_fromRGB_ret3 = Color3.fromRGB(44, 44, 45);
local Color3_fromRGB_ret4 = Color3.fromRGB(70, 70, 72);
local Color3_fromRGB_ret5 = Color3.fromRGB(216, 213, 205);
local Color3_fromRGB_ret6 = Color3.fromRGB(201, 198, 191);
local Color3_fromRGB_ret7 = Color3.fromRGB(88, 214, 106);
local Color3_fromRGB_ret8 = Color3.fromRGB(188, 74, 42);
local Arcade = Enum.Font.Arcade;
local Bangers = Enum.Font.Bangers;
local u2 = nil;
local u3 = false;
local u4 = nil;

local function getWindow() -- Line: 85
    -- upvalues: LocalPlayer (copy), Factions (copy)
    local PlayerGui = LocalPlayer.PlayerGui;
    local FactionGuiV2 = PlayerGui:FindFirstChild("FactionGuiV2");

    if FactionGuiV2 then
        return FactionGuiV2;
    end;

    local v5 = Factions.FactionGuiV2:Clone();
    v5.Parent = PlayerGui;
    wireWindow(v5);

    return v5;
end;

local function closeWindow() -- Line: 96
    -- upvalues: LocalPlayer (copy)
    local FactionGuiV2 = LocalPlayer.PlayerGui:FindFirstChild("FactionGuiV2");

    if FactionGuiV2 then
        FactionGuiV2:Destroy();
    end;
end;

local function fitPanel(p6) -- Line: 116
    local AutoScale = p6:FindFirstChild("AutoScale");

    if not AutoScale then
        return;
    end;

    local workspace_CurrentCamera = workspace.CurrentCamera;

    if not workspace_CurrentCamera then
        return;
    end;

    local ViewportSize = workspace_CurrentCamera.ViewportSize;
    local math_min_ret = math.min(ViewportSize.X / 900, ViewportSize.Y / 620);
    AutoScale.Scale = math.clamp(math_min_ret, 0.55, 1.15);
end;

local function bindPanelScaling(u7) -- Line: 126
    local AutoScale = u7:FindFirstChild("AutoScale");
    local v8 = AutoScale and workspace.CurrentCamera;

    if v8 then
        local ViewportSize = v8.ViewportSize;
        local math_min_ret = math.min(ViewportSize.X / 900, ViewportSize.Y / 620);
        AutoScale.Scale = math.clamp(math_min_ret, 0.55, 1.15);
    end;

    local workspace_CurrentCamera = workspace.CurrentCamera;

    if workspace_CurrentCamera then
        workspace_CurrentCamera:GetPropertyChangedSignal("ViewportSize"):Connect(function() -- Line: 130
            -- upvalues: u7 (copy)
            local AutoScale2 = u7:FindFirstChild("AutoScale");

            if not AutoScale2 then
                return;
            end;

            local workspace_CurrentCamera2 = workspace.CurrentCamera;

            if not workspace_CurrentCamera2 then
                return;
            end;

            local ViewportSize = workspace_CurrentCamera2.ViewportSize;
            local math_min_ret = math.min(ViewportSize.X / 900, ViewportSize.Y / 620);
            AutoScale2.Scale = math.clamp(math_min_ret, 0.55, 1.15);
        end);
    end;
end;

local function showPage(p9, p10) -- Line: 136
    -- upvalues: Color3_fromRGB_ret3 (copy), Color3_fromRGB_ret2 (copy), Color3_fromRGB_ret5 (copy), Color3_fromRGB_ret6 (copy), Color3_fromRGB_ret7 (copy), Color3_fromRGB_ret4 (copy)
    for _, child in ipairs(p9.Main.Pages:GetChildren()) do
        child.Visible = child.Name == p10;
    end;

    local v11 = {
        MyFaction = "Tab_My Faction",
        Members = "Tab_Members",
        Browse = "Tab_Browse Factions"
    };

    for _, child in ipairs(p9.Main.Tabs:GetChildren()) do
        if child:IsA("TextButton") then
            local v12 = child.Name == v11[p10];
            child.BackgroundColor3 = v12 and Color3_fromRGB_ret3 or Color3_fromRGB_ret2;
            child.TextColor3 = v12 and Color3_fromRGB_ret5 or Color3_fromRGB_ret6;
            local AccentBar = child:FindFirstChild("AccentBar");

            if AccentBar then
                AccentBar.BackgroundColor3 = Color3_fromRGB_ret7;
                AccentBar.BackgroundTransparency = v12 and 0 or 1;
            end;

            local v13 = child:FindFirstChildOfClass("UIStroke");

            if v13 then
                v13.Color = v12 and Color3_fromRGB_ret7 or Color3_fromRGB_ret4;
                v13.Transparency = v12 and 0.15 or 0.45;
            end;
        end;
    end;
end;

function wireWindow(p14)
    -- upvalues: closeWindow (copy), FactionRemote (copy), u3 (ref), LocalPlayer (copy), NameCheckRemote (copy)
    local Main = p14.Main;
    Main.Header.Close.MouseButton1Up:Connect(closeWindow);
    Main.Tabs["Tab_My Faction"].MouseButton1Up:Connect(function() -- Line: 183
        -- upvalues: FactionRemote (ref)
        FactionRemote:InvokeServer("View Faction", {});
    end);
    Main.Tabs.Tab_Members.MouseButton1Up:Connect(function() -- Line: 186
        -- upvalues: u3 (ref), FactionRemote (ref)
        if u3 then
            FactionRemote:InvokeServer("Manage Faction", {});

            return;
        end;

        FactionRemote:InvokeServer("Faction Members", {});
    end);
    Main.Tabs["Tab_Browse Factions"].MouseButton1Up:Connect(function() -- Line: 193
        -- upvalues: FactionRemote (ref)
        FactionRemote:InvokeServer("Show Faction List", {});
    end);
    local InfoRight = Main.Pages.MyFaction.InfoRight;
    local u15 = false;
    InfoRight.LeaveBtn.MouseButton1Up:Connect(function() -- Line: 200
        -- upvalues: u15 (ref), InfoRight (copy), FactionRemote (ref), LocalPlayer (ref)
        if u15 then
            FactionRemote:InvokeServer("Leave", {});
            local FactionGuiV2 = LocalPlayer.PlayerGui:FindFirstChild("FactionGuiV2");

            if FactionGuiV2 then
                FactionGuiV2:Destroy();
            end;

            return;
        end;

        u15 = true;
        InfoRight.LeaveBtn.Text = "Confirm Leave?";
        task.delay(3, function() -- Line: 204
            -- upvalues: u15 (ref), InfoRight (ref)
            u15 = false;
            InfoRight.LeaveBtn.Text = "Leave Faction";
        end);
    end);
    InfoRight.InviteBtn.MouseButton1Up:Connect(function() -- Line: 215
        -- upvalues: InfoRight (copy)
        InfoRight.InviteRow.Visible = not InfoRight.InviteRow.Visible;
    end);
    InfoRight.InviteRow.InviteGo.MouseButton1Up:Connect(function() -- Line: 218
        -- upvalues: InfoRight (copy), FactionRemote (ref)
        local Text = InfoRight.InviteRow.InviteBox.Text;

        if Text == "" then
            return;
        end;

        InfoRight.InviteRow.Visible = false;
        InfoRight.InviteRow.InviteBox.Text = "";
        FactionRemote:InvokeServer("Send Invite", {
            Name = Text
        });
    end);
    local InfoLeft = Main.Pages.MyFaction.InfoLeft;
    InfoLeft.EditBio.MouseButton1Up:Connect(function() -- Line: 228
        -- upvalues: InfoLeft (copy)
        InfoLeft.BioEditBox.Visible = not InfoLeft.BioEditBox.Visible;
        InfoLeft.BioSubmit.Visible = InfoLeft.BioEditBox.Visible;
    end);
    InfoLeft.BioSubmit.MouseButton1Up:Connect(function() -- Line: 232
        -- upvalues: InfoLeft (copy), NameCheckRemote (ref), FactionRemote (ref)
        local Text = InfoLeft.BioEditBox.Text;

        if Text == "" then
            return;
        end;

        local v16 = NameCheckRemote:InvokeServer(Text);
        InfoLeft.BioPanel.BioText.Text = v16;
        FactionRemote:InvokeServer("Edit Faction", {
            Action = "Edit Bio",
            NewDesc = v16
        });
        InfoLeft.BioEditBox.Visible = false;
        InfoLeft.BioSubmit.Visible = false;
    end);
    InfoLeft.EditImage.MouseButton1Up:Connect(function() -- Line: 244
        -- upvalues: InfoLeft (copy)
        InfoLeft.ImageEditBox.Visible = not InfoLeft.ImageEditBox.Visible;
        InfoLeft.ImageSubmit.Visible = InfoLeft.ImageEditBox.Visible;
    end);
    InfoLeft.ImageSubmit.MouseButton1Up:Connect(function() -- Line: 248
        -- upvalues: InfoLeft (copy), FactionRemote (ref), Main (copy)
        local Text = InfoLeft.ImageEditBox.Text;

        if Text == "" then
            return;
        end;

        FactionRemote:InvokeServer("Edit Faction", {
            Action = "Edit Image",
            NewImage = Text
        });
        Main.Header.Emblem.Image = "http://www.roblox.com/asset/?id=" .. Text;
        InfoLeft.ImageEditBox.Visible = false;
        InfoLeft.ImageSubmit.Visible = false;
    end);
    local Members = Main.Pages.Members;
    Members.Column.Search:GetPropertyChangedSignal("Text"):Connect(function() -- Line: 262
        -- upvalues: Members (copy)
        local string_lower_ret = string.lower(Members.Column.Search.Text);

        for _, child in ipairs(Members.Column.List:GetChildren()) do
            if child:IsA("Frame") then
                child.Visible = string_lower_ret == "" and true or string.find(string.lower(child.PlayerName.Text), string_lower_ret, 1, true) ~= nil;
            end;
        end;
    end);
end;

local function setHeader(p17, p18, p19) -- Line: 277
    -- upvalues: UtilityHandler (copy)
    if not p19 then
        return;
    end;

    local Header = p17.Main.Header;
    local v20 = UtilityHandler:Length(p19.Members);
    Header.FactionName.Text = p18 or "Faction";
    Header.SubTitle.Text = "Leader: " .. (p19.Leader and (p19.Leader[1] or "?") or "?") .. "  •  " .. (p19.ID or "");
    Header.MemberPill.Count.Text = v20 .. " / 50";
    Header.Emblem.Image = p19.Image or "";
end;

local function populateMyFaction(p21, p22, p23) -- Line: 288
    -- upvalues: FactionRemote (copy), u2 (ref), u3 (ref), LocalPlayer (copy), setHeader (copy), UtilityHandler (copy), Color3_fromRGB_ret6 (copy), showPage (copy)
    if not (p23 and p23.Members) then
        FactionRemote:InvokeServer("Show Faction List", {});

        return;
    end;

    u2 = p22;
    local v24;

    if p23.Leader == nil then
        v24 = false;
    else
        v24 = p23.Leader[2] == LocalPlayer.UserId;
    end;

    u3 = v24;
    setHeader(p21, p22, p23);
    local InfoLeft = p21.Main.Pages.MyFaction.InfoLeft;
    local InfoRight = p21.Main.Pages.MyFaction.InfoRight;
    local Desc = p23.Desc;
    local v25 = p23.Allies or {};
    local v26 = p23.Enemies or {};
    local v27 = #v25 > 0 and table.concat(v25, ", ") or "None declared";
    local v28 = #v26 > 0 and table.concat(v26, ", ") or "None declared";
    InfoLeft.BioPanel.BioText.Text = (not (Desc and (Desc ~= "" and Desc)) and "No description set." or Desc) .. "\n\n🤝 Allies: " .. v27 .. "\n⚔ Enemies: " .. v28;
    local v29 = p23.Core == true;
    InfoRight.LeaderRow.V.Text = p23.Leader and (p23.Leader[1] or "?") or "?";
    InfoRight.IDRow.V.Text = p23.ID or "?";
    InfoRight.MembersRow.V.Text = tostring(UtilityHandler:Length(p23.Members)) .. " / 50";
    local v30 = ({
        ["Galactic Patrol"] = "✔ Patrol salary: periodic Zeni, EXP, Karma, and item rewards while enlisted."
    })[p22];

    if v30 then
        InfoRight.BenefitsText.Text = v30;
        InfoRight.BenefitsText.TextColor3 = Color3.fromRGB(126, 168, 96);
    else
        InfoRight.BenefitsText.Text = "No faction benefits.";
        InfoRight.BenefitsText.TextColor3 = Color3_fromRGB_ret6;
    end;

    InfoLeft.EditBio.Visible = u3;
    InfoLeft.EditImage.Visible = u3;
    InfoRight.InviteBtn.Visible = u3;
    InfoRight.LeaveBtn.Text = v29 and u3 and "Step Down & Leave" or "Leave Faction";

    if not u3 then
        InfoLeft.BioEditBox.Visible = false;
        InfoLeft.BioSubmit.Visible = false;
        InfoLeft.ImageEditBox.Visible = false;
        InfoLeft.ImageSubmit.Visible = false;
        InfoRight.InviteRow.Visible = false;
    end;

    showPage(p21, "MyFaction");
end;

local function populateMembers(p31, p32, p33) -- Line: 359
    -- upvalues: FactionRemote (copy), setHeader (copy), u2 (ref), u1 (copy), Color3_fromRGB_ret6 (copy), showPage (copy)
    if not (p32 and p32.Members) then
        FactionRemote:InvokeServer("Show Faction List", {});

        return;
    end;

    setHeader(p31, u2 or p31.Main.Header.FactionName.Text, p32);
    local List = p31.Main.Pages.Members.Column.List;

    for _, child in ipairs(List:GetChildren()) do
        if child:IsA("Frame") then
            child:Destroy();
        end;
    end;

    p31.Main.Pages.Members.Column.Search.Text = "";
    local MemberCard = p31.Templates.MemberCard;
    local v34 = {
        Leader = 1,
        ["Co-Commander"] = 2,
        General = 3,
        ["Elite Fighter"] = 4,
        Member = 5
    };

    for i, v in pairs(p32.Members) do
        local v35 = MemberCard:Clone();
        v35.Visible = true;
        v35.Name = "Member_" .. v.Name;
        v35.LayoutOrder = v34[v.Rank] or 6;
        v35.PlayerName.Text = v.Name;
        v35.SubLine.Text = "ID: " .. tostring(v.ID);
        v35.RankBadge.RankText.Text = v.Rank;
        v35.RankBadge.RankText.TextColor3 = u1[v.Rank] or Color3_fromRGB_ret6;
        v35.Avatar.Image = "rbxthumb://type=AvatarHeadShot&id=" .. tostring(v.ID) .. "&w=48&h=48";
        local v36;

        if p33 then
            v36 = v.Rank ~= "Leader";
        else
            v36 = p33;
        end;

        v35.Promote.Visible = v36;
        v35.Demote.Visible = v36;
        v35.Kick.Visible = v36;

        if v36 then
            local function act(p37) -- Line: 392
                -- upvalues: FactionRemote (ref), i (copy)
                FactionRemote:InvokeServer(p37, {
                    ID = i
                });
                FactionRemote:InvokeServer("Manage Faction", {});
            end;

            v35.Promote.MouseButton1Up:Connect(function() -- Line: 397
                -- upvalues: act (copy)
                act("Promote");
            end);
            v35.Demote.MouseButton1Up:Connect(function() -- Line: 398
                -- upvalues: act (copy)
                act("Demote");
            end);
            v35.Kick.MouseButton1Up:Connect(function() -- Line: 399
                -- upvalues: act (copy)
                act("Kick");
            end);
        end;

        v35.Parent = List;
    end;

    showPage(p31, "Members");
end;

local function closeFactionDetail(p38) -- Line: 412
    local FactionDetail = p38.Main.Pages.Browse:FindFirstChild("FactionDetail");

    if FactionDetail then
        FactionDetail:Destroy();
    end;
end;

local function showFactionDetail(u39, u40, p41) -- Line: 418
    -- upvalues: Color3_fromRGB_ret2 (copy), Arcade (copy), Bangers (copy), Color3_fromRGB_ret7 (copy), Color3_fromRGB_ret (copy), UtilityHandler (copy), Color3_fromRGB_ret5 (copy), Color3_fromRGB_ret6 (copy), Color3_fromRGB_ret8 (copy), u3 (ref), u2 (ref), FactionRemote (copy)
    local Browse = u39.Main.Pages.Browse;
    local FactionDetail = u39.Main.Pages.Browse:FindFirstChild("FactionDetail");

    if FactionDetail then
        FactionDetail:Destroy();
    end;

    local Frame = Instance.new("Frame");
    Frame.Name = "FactionDetail";
    Frame.Size = UDim2.fromScale(1, 1);
    Frame.BackgroundColor3 = Color3_fromRGB_ret2;
    Frame.BorderSizePixel = 0;
    Frame.ZIndex = 50;
    Frame.Parent = Browse;
    local UICorner = Instance.new("UICorner");
    UICorner.CornerRadius = UDim.new(0, 2);
    UICorner.Parent = Frame;
    local UIPadding = Instance.new("UIPadding");
    UIPadding.PaddingTop = UDim.new(0, 12);
    UIPadding.PaddingBottom = UDim.new(0, 12);
    UIPadding.PaddingLeft = UDim.new(0, 14);
    UIPadding.PaddingRight = UDim.new(0, 14);
    UIPadding.Parent = Frame;
    local UIListLayout = Instance.new("UIListLayout");
    UIListLayout.Padding = UDim.new(0, 6);
    UIListLayout.SortOrder = Enum.SortOrder.LayoutOrder;
    UIListLayout.Parent = Frame;
    local u42 = 0;

    local function line(p43, p44, p45, p46) -- Line: 441
        -- upvalues: u42 (ref), Arcade (ref), Bangers (ref), Frame (copy)
        u42 = u42 + 1;
        local TextLabel = Instance.new("TextLabel");
        TextLabel.LayoutOrder = u42;
        TextLabel.Size = UDim2.new(1, 0, 0, p44 + 6);
        TextLabel.BackgroundTransparency = 1;
        TextLabel.Font = p46 and Arcade or Bangers;
        TextLabel.Text = p43;
        TextLabel.TextSize = p44;
        TextLabel.TextColor3 = p45;
        TextLabel.TextXAlignment = Enum.TextXAlignment.Left;
        TextLabel.TextWrapped = true;
        TextLabel.ZIndex = 51;
        TextLabel.Parent = Frame;

        return TextLabel;
    end;

    local TextButton = Instance.new("TextButton");
    TextButton.LayoutOrder = 0;
    TextButton.Size = UDim2.new(0, 120, 0, 26);
    TextButton.BackgroundColor3 = Color3_fromRGB_ret7;
    TextButton.Font = Arcade;
    TextButton.Text = "← Back to list";
    TextButton.TextSize = 13;
    TextButton.TextColor3 = Color3_fromRGB_ret;
    TextButton.ZIndex = 51;
    TextButton.Parent = Frame;
    local UICorner2 = Instance.new("UICorner");
    UICorner2.CornerRadius = UDim.new(0, 2);
    UICorner2.Parent = TextButton;
    TextButton.MouseButton1Up:Connect(function() -- Line: 469
        -- upvalues: u39 (copy)
        local FactionDetail2 = u39.Main.Pages.Browse:FindFirstChild("FactionDetail");

        if FactionDetail2 then
            FactionDetail2:Destroy();
        end;
    end);
    local v47 = UtilityHandler:Length(p41.Members or {});
    local v48 = p41.Created and (os.date("%b %d, %Y", p41.Created) or "Unknown") or "Unknown";
    local v49 = p41.Public ~= false;
    local v50 = p41.Allies or {};
    local v51 = p41.Enemies or {};
    line(u40, 22, Color3_fromRGB_ret5, true);
    line((p41.ID or "#?") .. "  •  " .. (v49 and "Public" or "Private"), 12, Color3_fromRGB_ret6);
    line("Leader: " .. (p41.Leader and (p41.Leader[1] or "?") or "?"), 14, Color3.fromRGB(255, 201, 77));
    line("Members: " .. v47 .. " / 50", 14, Color3_fromRGB_ret5);
    line("Founded: " .. v48, 14, Color3_fromRGB_ret5);
    local Desc = p41.Desc;
    line(not (Desc and (Desc ~= "" and Desc)) and "No description set." or Desc, 13, Color3_fromRGB_ret6);
    line("🤝 Allies: " .. (#v50 > 0 and table.concat(v50, ", ") or "None declared"), 13, Color3.fromRGB(126, 168, 96));
    line("⚔ Enemies: " .. (#v51 > 0 and table.concat(v51, ", ") or "None declared"), 13, Color3_fromRGB_ret8);

    if u3 and (u2 and u40 ~= u2) then
        local function diploBtn(p52, u53, p54) -- Line: 494
            -- upvalues: u42 (ref), Arcade (ref), Color3_fromRGB_ret (ref), Frame (copy), FactionRemote (ref), u40 (copy)
            u42 = u42 + 1;
            local TextButton2 = Instance.new("TextButton");
            TextButton2.LayoutOrder = u42;
            TextButton2.Size = UDim2.new(0, 170, 0, 28);
            TextButton2.BackgroundColor3 = p54;
            TextButton2.Font = Arcade;
            TextButton2.Text = p52;
            TextButton2.TextSize = 13;
            TextButton2.TextColor3 = Color3_fromRGB_ret;
            TextButton2.ZIndex = 51;
            TextButton2.Parent = Frame;
            local UICorner3 = Instance.new("UICorner");
            UICorner3.CornerRadius = UDim.new(0, 2);
            UICorner3.Parent = TextButton2;
            TextButton2.MouseButton1Up:Connect(function() -- Line: 507
                -- upvalues: FactionRemote (ref), u40 (ref), u53 (copy)
                FactionRemote:InvokeServer("Set Diplomacy", {
                    TargetFaction = u40,
                    Relation = u53
                });
                FactionRemote:InvokeServer("Show Faction List", {});
            end);
        end;

        diploBtn("Declare Ally", "Ally", Color3.fromRGB(126, 168, 96));
        diploBtn("Declare Enemy", "Enemy", Color3_fromRGB_ret8);
        diploBtn("Set Neutral", "Neutral", Color3_fromRGB_ret6);
    end;
end;

local function populateBrowse(u55, p56) -- Line: 522
    -- upvalues: u4 (ref), UtilityHandler (copy), showFactionDetail (copy), u2 (ref), showPage (copy)
    if not p56 then
        return;
    end;

    u4 = p56;
    local FactionDetail = u55.Main.Pages.Browse:FindFirstChild("FactionDetail");

    if FactionDetail then
        FactionDetail:Destroy();
    end;

    local List = u55.Main.Pages.Browse.Column.List;

    for _, child in ipairs(List:GetChildren()) do
        if child:IsA("Frame") then
            child:Destroy();
        end;
    end;

    local FactionCard = u55.Templates.FactionCard;

    for i, v in pairs(p56) do
        local v57 = FactionCard:Clone();
        v57.Visible = true;
        v57.Name = "Faction_" .. i;
        v57.FactionName.Text = i;
        local Desc = v.Desc;
        v57.FactionDesc.Text = not (Desc and (Desc ~= "" and Desc)) and "No description" or Desc;
        v57.FactionMeta.Text = "Leader: " .. (v.Leader and (v.Leader[1] or "?") or "?") .. "  •  Members: " .. UtilityHandler:Length(v.Members);
        v57.IDPill.IDText.Text = v.ID or "#?";
        v57.FactionImage.Image = v.Image or "";
        local TextButton = Instance.new("TextButton");
        TextButton.Name = "ViewBtn";
        TextButton.Size = UDim2.fromScale(1, 1);
        TextButton.BackgroundTransparency = 1;
        TextButton.Text = "";
        TextButton.ZIndex = 10;
        TextButton.Parent = v57;
        TextButton.MouseButton1Up:Connect(function() -- Line: 553
            -- upvalues: u4 (ref), i (copy), showFactionDetail (ref), u55 (copy)
            local v58 = u4 and u4[i];

            if v58 then
                showFactionDetail(u55, i, v58);
            end;
        end);
        v57.Parent = List;
    end;

    if not u2 then
        u55.Main.Header.FactionName.Text = "Factions";
        u55.Main.Header.SubTitle.Text = "Browse every faction on the server • click one for details";
        u55.Main.Header.MemberPill.Count.Text = tostring(UtilityHandler:Length(p56)) .. " factions";
    end;

    showPage(u55, "Browse");
end;

return {
    ["Show Factions"] = function(p59) -- Line: 579
        -- upvalues: populateBrowse (copy), LocalPlayer (copy), Factions (copy)
        local PlayerGui = LocalPlayer.PlayerGui;
        local FactionGuiV2 = PlayerGui:FindFirstChild("FactionGuiV2");

        if not FactionGuiV2 then
            FactionGuiV2 = Factions.FactionGuiV2:Clone();
            FactionGuiV2.Parent = PlayerGui;
            wireWindow(FactionGuiV2);
        end;

        populateBrowse(FactionGuiV2, p59.FactionData);
    end,

    ["View Faction"] = function(p60) -- Line: 583
        -- upvalues: populateMyFaction (copy), LocalPlayer (copy), Factions (copy)
        local PlayerGui = LocalPlayer.PlayerGui;
        local FactionGuiV2 = PlayerGui:FindFirstChild("FactionGuiV2");

        if not FactionGuiV2 then
            FactionGuiV2 = Factions.FactionGuiV2:Clone();
            FactionGuiV2.Parent = PlayerGui;
            wireWindow(FactionGuiV2);
        end;

        populateMyFaction(FactionGuiV2, p60.FactionName, p60.FactionData);
    end,

    ["See Current Faction"] = function(p61) -- Line: 589
        -- upvalues: LocalPlayer (copy), populateMyFaction (copy), Factions (copy), populateBrowse (copy)
        local FactionData = p61.FactionData;
        local v62 = tostring(LocalPlayer.UserId);

        for i, v in pairs(FactionData) do
            if v.Members and v.Members[v62] then
                local PlayerGui = LocalPlayer.PlayerGui;
                local FactionGuiV2 = PlayerGui:FindFirstChild("FactionGuiV2");

                if not FactionGuiV2 then
                    FactionGuiV2 = Factions.FactionGuiV2:Clone();
                    FactionGuiV2.Parent = PlayerGui;
                    wireWindow(FactionGuiV2);
                end;

                populateMyFaction(FactionGuiV2, i, v);

                return;
            end;
        end;

        local PlayerGui = LocalPlayer.PlayerGui;
        local FactionGuiV2 = PlayerGui:FindFirstChild("FactionGuiV2");

        if not FactionGuiV2 then
            FactionGuiV2 = Factions.FactionGuiV2:Clone();
            FactionGuiV2.Parent = PlayerGui;
            wireWindow(FactionGuiV2);
        end;

        populateBrowse(FactionGuiV2, FactionData);
    end,

    ["Edit Faction"] = function(p63) -- Line: 604
        -- upvalues: populateMyFaction (copy), LocalPlayer (copy), Factions (copy)
        local PlayerGui = LocalPlayer.PlayerGui;
        local FactionGuiV2 = PlayerGui:FindFirstChild("FactionGuiV2");

        if not FactionGuiV2 then
            FactionGuiV2 = Factions.FactionGuiV2:Clone();
            FactionGuiV2.Parent = PlayerGui;
            wireWindow(FactionGuiV2);
        end;

        populateMyFaction(FactionGuiV2, p63.FactionName, p63.FactionData);
    end,

    ["Manage Faction"] = function(p64) -- Line: 609
        -- upvalues: populateMembers (copy), LocalPlayer (copy), Factions (copy)
        local PlayerGui = LocalPlayer.PlayerGui;
        local FactionGuiV2 = PlayerGui:FindFirstChild("FactionGuiV2");

        if not FactionGuiV2 then
            FactionGuiV2 = Factions.FactionGuiV2:Clone();
            FactionGuiV2.Parent = PlayerGui;
            wireWindow(FactionGuiV2);
        end;

        populateMembers(FactionGuiV2, p64.FactionData, true);
    end,

    ["Faction Members"] = function(p65) -- Line: 613
        -- upvalues: populateMembers (copy), LocalPlayer (copy), Factions (copy)
        local PlayerGui = LocalPlayer.PlayerGui;
        local FactionGuiV2 = PlayerGui:FindFirstChild("FactionGuiV2");

        if not FactionGuiV2 then
            FactionGuiV2 = Factions.FactionGuiV2:Clone();
            FactionGuiV2.Parent = PlayerGui;
            wireWindow(FactionGuiV2);
        end;

        populateMembers(FactionGuiV2, p65.FactionData, false);
    end
};