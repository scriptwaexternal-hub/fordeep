-- Decompiled with Potassium's decompiler.

local TrainerClassData = require(script.Parent.TrainerClassData);
local u1 = {
    Crane = Color3.fromRGB(90, 170, 235),
    Brawler = Color3.fromRGB(220, 70, 60),
    Turtle = Color3.fromRGB(232, 118, 44)
};
local u2 = {
    Brawler = true
};
local Color3_fromRGB_ret = Color3.fromRGB(120, 200, 255);
local Color3_fromRGB_ret2 = Color3.fromRGB(170, 110, 230);
local u3 = {
    Tsuru = "Crane",
    Senshi = "Brawler",
    Kame = "Turtle"
};
local u4 = {
    Moori = true,
    Tomata = true,
    Boshi = true
};
local u5 = {
    Dorik = "BUFF BODY",
    ["Lord Slug"] = "GIANT"
};

return {
    Get = function(p6) -- Line: 32, Name: Get
        -- upvalues: u3 (copy), TrainerClassData (copy), u1 (copy), u2 (copy), u4 (copy), Color3_fromRGB_ret (copy), u5 (copy), Color3_fromRGB_ret2 (copy)
        if type(p6) ~= "string" then
            return nil;
        end;

        local v7 = u3[p6];

        if not v7 then
            for _, v in pairs(TrainerClassData) do
                if v[p6] then
                    v7 = v[p6];
                    break;
                end;
            end;
        end;

        if v7 then
            return string.upper(v7) .. " STYLE", u1[v7] or u1.Turtle, u2[v7] == true;
        end;

        if u4[p6] then
            return "KI TRAINER", Color3_fromRGB_ret;
        end;

        if u5[p6] then
            return "FORM: " .. u5[p6], Color3_fromRGB_ret2;
        end;

        return nil;
    end
};