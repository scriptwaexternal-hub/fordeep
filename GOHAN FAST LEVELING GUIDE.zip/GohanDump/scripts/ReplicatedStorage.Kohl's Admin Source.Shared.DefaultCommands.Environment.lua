-- Decompiled with Potassium's decompiler.

local Lighting = game:GetService("Lighting");

return {
    {
        name = "fix",
        description = "Reverts the environment to the original state.",

        env = function(p1) -- Line: 9, Name: env
            -- upvalues: Lighting (copy)
            local v2 = {
                [workspace] = { "AirDensity", "GlobalWind", "Gravity" },
                [workspace.Terrain] = { "WaterColor", "WaterReflectance", "WaterTransparency", "WaterWaveSize", "WaterWaveSpeed" },
                [p1.Service.Lighting] = { "Ambient", "Brightness", "ColorShift_Bottom", "ColorShift_Top", "EnvironmentDiffuseScale", "EnvironmentSpecularScale", "ExposureCompensation", "GeographicLatitude", "GlobalShadows", "OutdoorAmbient", "ShadowColor", "ClockTime", "FogColor", "FogEnd", "FogStart" }
            };
            local v3 = Lighting:FindFirstChildOfClass("Atmosphere");

            if v3 then
                v2[v3] = { "Density", "Offset", "Color", "Decay", "Glare", "Haze" };
            end;

            for i, v in v2 do
                local v4 = i;
                local v5 = v;

                for i2 = 1, #v do
                    local v6 = v5[i2];
                    v5[v6] = v4[v6];
                    v5[i2] = nil;
                    local _ = i2;
                end;
            end;

            return v2;
        end,

        run = function(p7) -- Line: 63, Name: run
            local disco = p7._K.Registry.commands.disco;

            if disco then
                task.spawn(disco.env.cleanup);
            end;

            pcall(game.Destroy, p7._K.Service.Lighting:FindFirstChild("_KSky"));

            for i, v in p7.env do
                local v8 = i;

                for i2, v2 in v do
                    v8[i2] = v2;
                end;
            end;
        end
    },
    {
        name = "ambient",
        description = "Changes the color of Lighting.Ambient.",
        args = { {
                type = "color",
                name = "Hue",
                description = "The lighting hue applied to areas that are occluded from the sky, such as indoor areas."
            } },

        run = function(p9, p10) -- Line: 86, Name: run
            -- upvalues: Lighting (copy)
            Lighting.Ambient = p10;
        end
    },
    {
        name = "outdoorambient",
        description = "Changes the color of Lighting.OutdoorAmbient.",
        args = { {
                type = "color",
                name = "Hue",
                description = "The lighting hue applied to outdoor areas."
            } },

        run = function(p11, p12) -- Line: 100, Name: run
            -- upvalues: Lighting (copy)
            Lighting.OutdoorAmbient = p12;
        end
    },
    {
        name = "atmosphere",
        description = "Changes the values of a Ligthing.Atmosphere.",
        args = { {
                type = "number",
                name = "Density",
                description = "How thick the air is, making it harder to see through."
            }, {
                type = "number",
                name = "Offset",
                description = "Affects how the sky and distant objects blend. Higher values create a horizon line; lower values create a seamless sky.",
                optional = true
            }, {
                type = "color",
                name = "Color",
                description = "The color of the sky. Combine with Haze for a more visible effect.",
                optional = true
            }, {
                type = "color",
                name = "DecayColor",
                description = "The color of the sky far from the sun. Requires Glare and Haze for a visible effect.",
                optional = true
            }, {
                type = "number",
                name = "Glare",
                description = "How much the sun glows. Higher values create stronger sunlight effects. Requires Haze for a visible effect.",
                optional = true
            }, {
                type = "number",
                name = "Haze",
                description = "How hazy the sky is. Affects both the sky and distant objects.",
                optional = true
            } },

        run = function(p13, p14, p15, p16, p17, p18, p19) -- Line: 144, Name: run
            -- upvalues: Lighting (copy)
            local v20 = Lighting:FindFirstChildOfClass("Atmosphere");

            if v20 then
                v20.Density = p14;
                v20.Offset = p15 or v20.Offset;
                v20.Color = p16 or v20.Color;
                v20.Decay = p17 or v20.Decay;
                v20.Glare = p18 or v20.Glare;
                v20.Haze = p19 or v20.Haze;
            end;
        end
    },
    {
        name = "fogcolor",
        description = "Changes the color of Lighting.FogColor.",
        args = { {
                type = "color",
                name = "Color3",
                description = "The lighting hue applied to fog."
            } },

        run = function(p21, p22) -- Line: 166, Name: run
            -- upvalues: Lighting (copy)
            Lighting.FogColor = p22;
            local v23 = Lighting:FindFirstChildOfClass("Atmosphere");

            if v23 then
                v23.Color = p22;
                v23.Haze = math.max(2.3283064365386963e-10, v23.Haze);
            end;
        end
    },
    {
        name = "fogstart",
        description = "Changes the value of Lighting.FogStart.",
        args = { {
                type = "number",
                name = "Studs",
                description = "The depth from the Workspace.CurrentCamera, in studs, at which fog begins to show."
            } },

        run = function(p24, p25) -- Line: 185, Name: run
            -- upvalues: Lighting (copy)
            Lighting.FogStart = p25;
            local v26 = Lighting:FindFirstChildOfClass("Atmosphere");

            if v26 then
                v26.Density = (64 / p25) ^ 0.25;
                v26.Haze = math.max(2.3283064365386963e-10, 5 / p25 ^ 0.1);
            end;
        end
    },
    {
        name = "fogend",
        description = "Changes the value of Lighting.FogEnd.",
        args = { {
                type = "number",
                name = "Studs",
                description = "The depth from the Workspace.CurrentCamera, in studs, at which fog will be completely opaque."
            } },

        run = function(p27, p28) -- Line: 204, Name: run
            -- upvalues: Lighting (copy)
            Lighting.FogEnd = p28;
            local v29 = Lighting:FindFirstChildOfClass("Atmosphere");

            if v29 then
                v29.Density = (64 / p28) ^ 0.25;
                v29.Haze = math.max(2.3283064365386963e-10, 5 / p28 ^ 0.1);
            end;
        end
    },
    {
        name = "brightness",
        description = "Changes the value of Lighting.Brightness.",
        args = { {
                type = "number",
                name = "Intensity",
                description = "The intensity of illumination in the place."
            } },

        run = function(p30, p31) -- Line: 223, Name: run
            -- upvalues: Lighting (copy)
            Lighting.Brightness = p31;
        end
    },
    {
        name = "colorshift",
        description = "Changes the colors of Lighting.ColorShift_Bottom and Lighting.ColorShift_Top.",
        args = { {
                type = "color",
                name = "BottomHue",
                description = "The hue represented in light reflected in the opposite surfaces to those facing the sun or moon."
            }, {
                type = "color",
                name = "TopHue",
                description = "The hue represented in light reflected from surfaces facing the sun or moon."
            } },

        run = function(p32: any, p33, p34) -- Line: 242, Name: run
            -- upvalues: Lighting (copy)
            Lighting.ColorShift_Bottom = p33;
            Lighting.ColorShift_Top = p34;
        end
    },
    {
        name = "diffusescale",
        description = "Changes the value of Lighting.EnvironmentDiffuseScale.",
        args = { {
                type = "number",
                name = "Scale",
                description = "Ambient light that is derived from the environment. The value of this property defaults to 0."
            } },

        run = function(p35, p36) -- Line: 257, Name: run
            -- upvalues: Lighting (copy)
            Lighting.EnvironmentDiffuseScale = p36;
        end
    },
    {
        name = "specularscale",
        description = "Changes the value of Lighting.EnvironmentSpecularScale.",
        args = { {
                type = "number",
                name = "Scale",
                description = "Specular light derived from environment. The value of this property defaults to 0."
            } },

        run = function(p37, p38) -- Line: 271, Name: run
            -- upvalues: Lighting (copy)
            Lighting.EnvironmentSpecularScale = p38;
        end
    },
    {
        name = "exposure",
        description = "Changes the value of Lighting.ExposureCompensation.",
        args = { {
                type = "number",
                name = "Amount",
                description = "The exposure compensation amount which applies a bias to the exposure level of the scene prior to the tonemap step. Defaults to 0."
            } },

        run = function(p39, p40) -- Line: 285, Name: run
            -- upvalues: Lighting (copy)
            Lighting.ExposureCompensation = p40;
        end
    },
    {
        name = "time",
        description = "Changes the value of Lighting.ClockTime.",
        aliases = { "clocktime" },
        credit = { "Realistic @iiRealistic_Dev", "Kohl @Scripth" },
        args = { {
                type = "string",
                name = "Time",
                description = "The time of day, can be HH, HH:MM, or HH:MM:SS."
            }, {
                type = "number",
                name = "Duration",
                description = "Transition duration to the new time of day. Defaults to instant.",
                optional = true
            } },

        run = function(p41: any, p42: string, p43: number?) -- Line: 310, Name: run
            -- upvalues: Lighting (copy)
            local v44, v45, v46 = unpack(string.split(p42, ":"));
            local v47 = tonumber(v44) or 0;
            local math_clamp_ret = math.clamp(v47, 0, 23);
            local v48 = tonumber(v45) or 0;
            local math_clamp_ret2 = math.clamp(v48, 0, 59);
            local v49 = tonumber(v46) or 0;
            local math_clamp_ret3 = math.clamp(v49, 0, 59);
            local v50 = math_clamp_ret + math_clamp_ret2 / 60 + math_clamp_ret3 / 3600;

            if p43 then
                p41._K.Service.TweenService:Create(Lighting, TweenInfo.new(p43, Enum.EasingStyle.Linear), {
                    ClockTime = v50
                }):Play();

                return;
            end;

            Lighting.ClockTime = v50;
        end
    },
    {
        name = "latitude",
        description = "Changes the value of Lighting.GeographicLatitude.",
        aliases = { "geographiclatitude" },
        args = { {
                type = "number",
                name = "Degrees",
                description = "The geographic latitude, in degrees, of the scene, influencing the result of time on the position of the sun and moon.",
                optional = true
            } },

        env = function(p51) -- Line: 339, Name: env
            -- upvalues: Lighting (copy)
            return {
                defaultLatitude = Lighting.GeographicLatitude
            };
        end,

        run = function(p52, p53) -- Line: 342, Name: run
            -- upvalues: Lighting (copy)
            if p53 == nil then
                p53 = p52.env.defaultLatitude;
            end;

            Lighting.GeographicLatitude = p53;
        end
    },
    {
        name = "shadows",
        description = "Changes the value of Lighting.GlobalShadows.",
        aliases = { "globalshadows" },
        args = { {
                type = "boolean",
                name = "Enabled",
                description = "Toggles voxel-based dynamic lighting in the game."
            } },

        run = function(p54, p55) -- Line: 357, Name: run
            -- upvalues: Lighting (copy)
            Lighting.GlobalShadows = p55;
        end
    },
    {
        name = "skybox",
        description = "Changes the skybox.",
        aliases = { "sky", "unskybox", "unsky" },
        args = { {
                type = "image",
                name = "Bottom",
                description = "The bottom image.",
                optional = true
            }, {
                type = "image",
                name = "Back",
                description = "The back image.",
                optional = true
            }, {
                type = "image",
                name = "Left",
                description = "The left image.",
                optional = true
            }, {
                type = "image",
                name = "Top",
                description = "The top image.",
                optional = true
            }, {
                type = "image",
                name = "Front",
                description = "The front image.",
                optional = true
            }, {
                type = "image",
                name = "Right",
                description = "The right image.",
                optional = true
            } },

        run = function(p56, p57, p58, p59, p60, p61, p62) -- Line: 403, Name: run
            if not p57 or p56.undo then
                pcall(game.Destroy, p56._K.Service.Lighting:FindFirstChild("_KSky"));

                return;
            end;

            local v63 = p56._K.Service.Lighting:FindFirstChildOfClass("Sky");

            if not v63 or v63.Name ~= "_KSky" then
                v63 = Instance.new("Sky");
                v63.Name = "_KSky";
            end;

            v63.SkyboxDn = p57;
            v63.SkyboxBk = p58 or p57;
            v63.SkyboxLf = p59 or p57;
            v63.SkyboxUp = p60 or p57;
            v63.SkyboxFt = p61 or (p58 or p57);
            v63.SkyboxRt = p62 or (p59 or p57);
            v63.Parent = p56._K.Service.Lighting;
        end
    },
    {
        name = "airdensity",
        description = "Changes the air density used in aerodynamic forces model.",
        args = {
            {
                type = "number",
                name = "Density",
                description = `The density of the air, default is {workspace.AirDensity}.`
            }
        },

        run = function(p64, p65) -- Line: 433, Name: run
            workspace.AirDensity = p65;
        end
    },
    {
        name = "gravity",
        description = "Changes the world\'s gravity.",
        args = {
            {
                type = "number",
                name = "Gravity",
                optional = true,
                description = `The gravity acceleration in stud/s, default is {string.format("%.1f", workspace.Gravity)}.`
            }
        },

        env = function(p66) -- Line: 448, Name: env
            return {
                gravity = workspace.Gravity
            };
        end,

        run = function(p67, p68) -- Line: 453, Name: run
            if p68 == nil then
                p68 = p67.env.gravity;
            end;

            workspace.Gravity = p68;
        end
    },
    {
        name = "winddir",
        description = "Orients the wind direction along your camera.",
        aliases = { "winddirection" },
        args = {},

        run = function(u69) -- Line: 462, Name: run
            if u69.fromPlayer then
                u69._K.Remote.SpectateSubject:Once(function(p70, p71) -- Line: 464
                    -- upvalues: u69 (copy)
                    if p70 == u69.fromPlayer then
                        local Magnitude = workspace.GlobalWind.Magnitude;

                        if Magnitude ~= Magnitude then
                            return;
                        end;

                        for _, v in { p71:GetComponents() } do
                            if v ~= v then
                                return;
                            end;
                        end;

                        workspace.GlobalWind = p71.LookVector * workspace.GlobalWind.Magnitude;
                    end;
                end);
                u69._K.Remote.SpectateSubject:Fire(u69.fromPlayer, true);
            end;
        end
    },
    {
        name = "windspeed",
        description = "Changes the global wind speed.",
        args = {
            {
                type = "number",
                name = "Speed",
                description = `The speed of the wind in studs per second, default is {workspace.GlobalWind.Magnitude}.`
            }
        },

        run = function(p72, p73) -- Line: 492, Name: run
            if p73 ~= p73 then
                return;
            end;

            workspace.GlobalWind = p73 * (workspace.GlobalWind.Magnitude <= 0 and Vector3.new(-1, -0, -0) or workspace.GlobalWind.Unit);
        end
    },
    {
        name = "watercolor",
        description = "Changes the color of Terrain water.",
        args = {
            {
                type = "color",
                name = "Color",
                description = `The color of the water, default is {workspace.Terrain.WaterColor}.`
            }
        },

        run = function(p74, p75) -- Line: 511, Name: run
            workspace.Terrain.WaterColor = p75;
        end
    },
    {
        name = "waterreflectance",
        description = "Changes the reflectance of Terrain water.",
        args = {
            {
                type = "number",
                name = "Reflectance",
                description = `The reflectance of the water, default is {workspace.Terrain.WaterReflectance}.`
            }
        },

        run = function(p76, p77) -- Line: 525, Name: run
            workspace.Terrain.WaterReflectance = p77;
        end
    },
    {
        name = "watertransparency",
        description = "Changes the transparency of Terrain water.",
        args = {
            {
                type = "number",
                name = "Transparency",
                description = `The transparency of the water, default is {workspace.Terrain.WaterTransparency}.`
            }
        },

        run = function(p78, p79) -- Line: 539, Name: run
            workspace.Terrain.WaterTransparency = p79;
        end
    },
    {
        name = "watersize",
        description = "Changes the wave size of Terrain water.",
        args = {
            {
                type = "number",
                name = "Size",
                description = `The wave size of the water, default is {workspace.Terrain.WaterWaveSize}.`
            }
        },

        run = function(p80, p81) -- Line: 553, Name: run
            workspace.Terrain.WaterWaveSize = p81;
        end
    },
    {
        name = "waterspeed",
        description = "Changes the wave speed of Terrain water.",
        args = {
            {
                type = "number",
                name = "Speed",
                description = `The wave speed of the water, default is {string.format("%.1f", workspace.Terrain.WaterWaveSpeed)}.`
            }
        },

        run = function(p82, p83) -- Line: 570, Name: run
            workspace.Terrain.WaterWaveSpeed = p83;
        end
    }
};