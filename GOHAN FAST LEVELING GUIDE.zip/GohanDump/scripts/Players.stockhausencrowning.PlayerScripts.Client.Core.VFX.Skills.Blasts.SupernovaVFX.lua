-- Decompiled with Potassium's decompiler.

local Debris = game:GetService("Debris");
local ReplicatedStorage = game:GetService("ReplicatedStorage");
local Modules = ReplicatedStorage:WaitForChild("Modules");
local GlobalFunctions = require(Modules.GlobalFunctions);
local ScaleModel = require(Modules.Shared.ScaleModel);
local Visuals = workspace.World.Visuals;
local Meshes = ReplicatedStorage.Assets.Effects.Meshes;

return {
    Execute = function(p1) -- Line: 26
        -- upvalues: GlobalFunctions (copy), Meshes (copy), Visuals (copy), Debris (copy), ScaleModel (copy)
        local Character = p1.Character;

        if not Character then
            return;
        end;

        local RootAndHumanoid = GlobalFunctions.GetRootAndHumanoid(Character);

        if not RootAndHumanoid then
            return;
        end;

        local u2 = Meshes.Skills.Blasts.Supernova["Supernova Model"]:Clone();
        u2.Name = "Supernova" .. Character.Name;
        u2.Handle.CFrame = RootAndHumanoid.CFrame * CFrame.new(0, 7, 0);
        u2.Handle.Anchored = false;
        u2:ScaleTo(0.001);
        u2.Parent = Visuals;
        Debris:AddItem(u2, 15);
        local WeldConstraint = Instance.new("WeldConstraint");
        WeldConstraint.Part0 = u2.Handle;
        WeldConstraint.Part1 = RootAndHumanoid;
        WeldConstraint.Parent = u2;

        for _, descendant in ipairs(u2:GetDescendants()) do
            if descendant:IsA("ParticleEmitter") then
                descendant.Enabled = true;
            end;
        end;

        ScaleModel.Scale({
            MaxScale = 20,
            Speed = 0.03,
            ModelToScale = u2
        });
        task.spawn(function() -- Line: 57
            -- upvalues: Character (copy), u2 (copy), WeldConstraint (copy)
            while Character:FindFirstChild("Charging Beam") do
                if Character:FindFirstChild("Stun") then
                    u2:Destroy();

                    return;
                end;

                task.wait();
            end;

            WeldConstraint:Destroy();
        end);
    end,

    Cancel = function(p3) -- Line: 72
        -- upvalues: Visuals (copy)
        local Character = p3.Character;

        if not Character then
            return;
        end;

        local v4 = Visuals:FindFirstChild("Supernova" .. Character.Name);

        if v4 then
            v4:Destroy();
        end;
    end
};