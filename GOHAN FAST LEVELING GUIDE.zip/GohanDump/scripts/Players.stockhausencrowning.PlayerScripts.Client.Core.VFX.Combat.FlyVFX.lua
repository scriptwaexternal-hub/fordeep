-- Decompiled with Potassium's decompiler.

game:GetService("Players");
local Debris = game:GetService("Debris");
local ReplicatedStorage = game:GetService("ReplicatedStorage");
game:GetService("TweenService");
game:GetService("RunService");
game:GetService("UserInputService");
local Assets = ReplicatedStorage.Assets;
local Modules = ReplicatedStorage:WaitForChild("Modules");
ReplicatedStorage:WaitForChild("Remotes");
local _ = Modules.Metadata;
local Shared = Modules.Shared;
local _ = Modules.Utility;
local _ = Assets.Gui;
local SoundManager = require(Shared.SoundManager);
local GlobalFunctions = require(Modules.GlobalFunctions);
require(Shared.CamShakeHandler);
local workspace_World = workspace.World;
local Visuals = workspace_World.Visuals;
local _ = Assets.Effects.Particles;
local _ = Assets.Effects.Meshes.Charging;

return {
    ["Boost Start"] = function(p1) -- Line: 38
        -- upvalues: SoundManager (copy), Assets (copy), Visuals (copy), workspace_World (copy), Debris (copy), GlobalFunctions (copy)
        local Character = p1.Character;
        local _ = p1.Color or nil;
        local HumanoidRootPart = Character:FindFirstChild("HumanoidRootPart");
        local Humanoid = Character:FindFirstChild("Humanoid");

        if not (HumanoidRootPart and Humanoid) then
            return;
        end;

        local u2 = SoundManager.AddSound("Aura Burst", {
            Parent = HumanoidRootPart
        }, "Client");
        local u3 = Assets.Sounds.Combat.Charging["Aura Loop"]:Clone();
        u3.Name = "BoostAuraLoop";
        u3.Parent = HumanoidRootPart;
        u3:Play();
        local u4 = Assets.Effects.Meshes["Fly Effect 2"]:Clone();
        u4.CFrame = HumanoidRootPart.CFrame;
        u4.Parent = Visuals;
        local WeldConstraint = Instance.new("WeldConstraint");
        WeldConstraint.Part0 = u4;
        WeldConstraint.Part1 = HumanoidRootPart;
        WeldConstraint.Parent = u4;

        for _, descendant in pairs(u4:GetDescendants()) do
            if descendant:IsA("ParticleEmitter") then
                descendant.Enabled = true;
            end;
        end;

        local function Black_Lines() -- Line: 69
            -- upvalues: workspace_World (ref), Character (copy), Debris (ref), GlobalFunctions (ref)
            local math_random_ret = math.random(-10, 10);
            local math_random_ret2 = math.random(-10, 10);
            local math_random_ret3 = math.random(-5, -5);
            local math_random_ret4 = math.random(1, 10);
            local Part = Instance.new("Part");
            Part.Color = Color3.fromRGB(0, 0, 0);
            Part.Material = Enum.Material.Neon;
            Part.Parent = workspace_World.Visuals;
            Part.CFrame = Character.HumanoidRootPart.CFrame * CFrame.new(math_random_ret, math_random_ret2, math_random_ret3);
            Part.Transparency = 0.09;
            Part.Size = Vector3.new(0.04, 0.04, math_random_ret4);
            Part.Anchored = true;
            Part.CanCollide = false;
            Debris:AddItem(Part, 1);
            GlobalFunctions.TransparencyTween({
                Instance = Part
            });
        end;

        task.spawn(function() -- Line: 99
            -- upvalues: Character (copy), Humanoid (copy), Black_Lines (copy), u4 (copy), u2 (copy), u3 (copy), Debris (ref)
            local os_clock_ret = os.clock();

            while Character:FindFirstChild("FlyBoost") and (Character.Parent and (not Humanoid or Humanoid.Health > 0)) and Character:FindFirstChild("HumanoidRootPart") do
                if os.clock() - os_clock_ret > 30 then
                    warn("[FlyVFX] boost ran past", 30, "s - forcing cleanup");
                    break;
                end;

                Black_Lines();
                task.wait();
            end;

            for _, descendant in pairs(u4:GetDescendants()) do
                if descendant:IsA("ParticleEmitter") then
                    descendant.Enabled = false;
                elseif descendant:IsA("Trail") then
                    descendant.Enabled = false;
                end;
            end;

            if u2 then
                pcall(function() -- Line: 120
                    -- upvalues: u2 (ref)
                    u2:Destroy();
                end);
            end;

            if u3 then
                pcall(function() -- Line: 121
                    -- upvalues: u3 (ref)
                    u3:Destroy();
                end);
            end;

            if u4 then
                Debris:AddItem(u4, 2);
            end;
        end);
    end,

    ["Boost End"] = function(p5) -- Line: 126
        -- upvalues: Debris (copy)
        local Character = p5.Character;
        Character:FindFirstChild("HumanoidRootPart");
        Character:FindFirstChild("Humanoid");

        for _, descendant in pairs(Character:GetDescendants()) do
            if descendant.Name == "CloneTachment" then
                for _, child in pairs(descendant:GetChildren()) do
                    child.Enabled = false;
                end;

                Debris:AddItem(descendant, 2);
            elseif descendant.Name == "BoostAuraLoop" then
                descendant:Destroy();
            end;
        end;
    end
};