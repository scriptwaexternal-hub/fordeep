-- Decompiled with Potassium's decompiler.

local HUDMAIN = script:FindFirstAncestor("HUD").MainFrame.HUDisplay.HUDMAIN;
local Health = HUDMAIN.Health;
local FalseHealth = HUDMAIN.FalseHealth;

return {
    Update = function(p1) -- Line: 16, Name: Update
        -- upvalues: Health (copy), FalseHealth (copy)
        local math_clamp_ret = math.clamp(p1.Health / p1.MaxHealth, 0, 1);
        Health:TweenSize(UDim2.new(math_clamp_ret * 0.624, 0, 0.115, 0), "Out", "Linear", 0.1, true);
        FalseHealth:TweenSize(UDim2.new(math_clamp_ret * 0.624, 0, 0.115, 0), "Out", "Linear", 0.7, true);
    end
};