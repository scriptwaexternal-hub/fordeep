-- Decompiled with Potassium's decompiler.

local Color3_fromRGB_ret = Color3.fromRGB(255, 205, 60);
local Color3_fromRGB_ret2 = Color3.fromRGB(150, 130, 70);
local Color3_fromRGB_ret3 = Color3.fromRGB(235, 45, 45);
local u1 = {};

local function refresh(p2) -- Line: 22
    -- upvalues: u1 (copy), Color3_fromRGB_ret3 (copy), Color3_fromRGB_ret2 (copy), Color3_fromRGB_ret (copy)
    local v3 = u1[p2];

    if not v3 then
        return;
    end;

    local v4 = p2:GetAttribute("State_HyperArmor") ~= nil;
    local v5 = p2:GetAttribute("State_SuperArmor") ~= nil;
    local v6 = p2:GetAttribute("SuperArmorBroken") == true;

    if not (v4 or v5) then
        if v3.hl then
            v3.hl:Destroy();
            v3.hl = nil;
        end;

        return;
    end;

    local hl = v3.hl;

    if not hl then
        hl = Instance.new("Highlight");
        hl.Name = "ArmorHighlight";
        hl.DepthMode = Enum.HighlightDepthMode.Occluded;
        hl.Adornee = p2;
        hl.Parent = p2;
        v3.hl = hl;
    end;

    if v4 then
        hl.OutlineColor = Color3_fromRGB_ret3;
        hl.FillColor = Color3_fromRGB_ret3;
        hl.FillTransparency = 0.82;
        hl.OutlineTransparency = 0;

        return;
    end;

    if v6 then
        hl.OutlineColor = Color3_fromRGB_ret2;
        hl.FillColor = Color3_fromRGB_ret2;
        hl.FillTransparency = 0.95;
        hl.OutlineTransparency = 0.5;

        return;
    end;

    hl.OutlineColor = Color3_fromRGB_ret;
    hl.FillColor = Color3_fromRGB_ret;
    hl.FillTransparency = 0.88;
    hl.OutlineTransparency = 0.15;
end;

local Live = workspace:WaitForChild("World"):WaitForChild("Live");

local function watch(u7) -- Line: 53
    -- upvalues: u1 (copy), refresh (copy)
    if u1[u7] or not (u7:IsA("Model") and u7:FindFirstChildOfClass("Humanoid")) then
        return;
    end;

    local v8 = {
        hl = nil,
        conns = {}
    };
    u1[u7] = v8;

    for _, v in ipairs({ "State_SuperArmor", "State_HyperArmor", "SuperArmorBroken" }) do
        v8.conns[#v8.conns + 1] = u7:GetAttributeChangedSignal(v):Connect(function() -- Line: 58
            -- upvalues: refresh (ref), u7 (copy)
            refresh(u7);
        end);
    end;

    refresh(u7);
end;

local function unwatch(p9) -- Line: 63
    -- upvalues: u1 (copy)
    local v10 = u1[p9];

    if not v10 then
        return;
    end;

    for _, v in ipairs(v10.conns) do
        v:Disconnect();
    end;

    if v10.hl then
        v10.hl:Destroy();
    end;

    u1[p9] = nil;
end;

local v11 = {};

for _, descendant in ipairs(Live:GetDescendants()) do
    watch(descendant);
end;

Live.DescendantAdded:Connect(function(p12) -- Line: 73
    -- upvalues: watch (copy)
    if p12:IsA("Model") then
        watch(p12);

        return;
    end;

    if p12:IsA("Humanoid") and p12.Parent then
        watch(p12.Parent);
    end;
end);
Live.DescendantRemoving:Connect(function(p13) -- Line: 78
    -- upvalues: u1 (copy), unwatch (copy)
    if u1[p13] then
        unwatch(p13);
    end;
end);

return v11;