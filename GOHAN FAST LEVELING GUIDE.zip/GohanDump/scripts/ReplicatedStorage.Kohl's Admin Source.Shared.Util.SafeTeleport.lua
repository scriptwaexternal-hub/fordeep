-- Decompiled with Potassium's decompiler.

local TeleportService = game:GetService("TeleportService");

local function SafeTeleport(u1, u2, u3) -- Line: 7
    -- upvalues: TeleportService (copy)
    local v4 = 0;

    while true do
        local success, result = pcall(function() -- Line: 12
            -- upvalues: TeleportService (ref), u1 (copy), u2 (copy), u3 (copy)
            return TeleportService:TeleportAsync(u1, u2, u3);
        end);
        v4 = v4 + 1;

        if not success then
            task.wait(1);
        end;

        if success or v4 == 5 then
            if not success then
                warn(result);
            end;

            return success, result;
        end;
    end;
end;

TeleportService.TeleportInitFailed:Connect(function(p5, p6, p7, p8, p9) -- Line: 28, Name: handleFailedTeleport
    -- upvalues: SafeTeleport (copy)
    if p6 == Enum.TeleportResult.Flooded then
        task.wait(15);
    elseif p6 == Enum.TeleportResult.Failure then
        task.wait(1);
    end;

    if p6 == Enum.TeleportResult.GameNotFound or (p6 == Enum.TeleportResult.Unauthorized or string.find(p7, "Roblox Studio")) then
        return;
    end;

    SafeTeleport(p8, { p5 }, p9);
end);

return SafeTeleport;