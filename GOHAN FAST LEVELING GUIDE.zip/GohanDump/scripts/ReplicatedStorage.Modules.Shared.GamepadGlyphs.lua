-- Decompiled with Potassium's decompiler.

local UserInputService = game:GetService("UserInputService");
local u1 = {};
local u2 = {
    MouseButton1 = "M1",
    MouseButton2 = "M2",
    MouseButton3 = "M3",
    LeftControl = "CTRL",
    RightControl = "R-CTRL",
    LeftAlt = "ALT",
    RightAlt = "R-ALT",
    LeftShift = "SHIFT",
    RightShift = "R-SHIFT",
    Backquote = "`",
    Space = "SPACE"
};
local u3 = {
    ButtonA = "A",
    ButtonB = "B",
    ButtonX = "X",
    ButtonY = "Y",
    ButtonL1 = "LB",
    ButtonR1 = "RB",
    ButtonL2 = "LT",
    ButtonR2 = "RT",
    ButtonL3 = "LS",
    ButtonR3 = "RS",
    ButtonStart = "Menu",
    ButtonSelect = "View",
    DPadUp = "D-Pad Up",
    DPadDown = "D-Pad Down",
    DPadLeft = "D-Pad Left",
    DPadRight = "D-Pad Right",
    Thumbstick1 = "L-Stick",
    Thumbstick2 = "R-Stick"
};
local u4 = {
    ButtonA = "Cross",
    ButtonB = "Circle",
    ButtonX = "Square",
    ButtonY = "Triangle",
    ButtonL1 = "L1",
    ButtonR1 = "R1",
    ButtonL2 = "L2",
    ButtonR2 = "R2",
    ButtonL3 = "L3",
    ButtonR3 = "R3",
    ButtonStart = "Options",
    ButtonSelect = "Create",
    DPadUp = "D-Pad Up",
    DPadDown = "D-Pad Down",
    DPadLeft = "D-Pad Left",
    DPadRight = "D-Pad Right",
    Thumbstick1 = "L-Stick",
    Thumbstick2 = "R-Stick"
};
local u5 = { "Button", "DPad", "Thumbstick" };

function u1.IsGamepadKey(p6) -- Line: 56
    -- upvalues: u5 (copy)
    for _, v in ipairs(u5) do
        if string.sub(p6, 1, #v) == v then
            return true;
        end;
    end;

    return false;
end;

function u1.IsPlayStation() -- Line: 68
    -- upvalues: UserInputService (copy)
    local success, result = pcall(function() -- Line: 69
        -- upvalues: UserInputService (ref)
        return UserInputService:GetStringForKeyCode(Enum.KeyCode.ButtonA);
    end);

    if success then
        success = result == "ButtonCross";
    end;

    return success;
end;

function u1.HasGamepad() -- Line: 75
    -- upvalues: UserInputService (copy)
    return UserInputService.GamepadEnabled;
end;

function u1.Image(p7) -- Line: 84
    -- upvalues: u1 (copy), UserInputService (copy)
    if not u1.IsGamepadKey(p7) then
        return nil;
    end;

    local u8 = Enum.KeyCode[p7];

    if not u8 then
        return nil;
    end;

    local success, result = pcall(function() -- Line: 88
        -- upvalues: UserInputService (ref), u8 (copy)
        return UserInputService:GetImageForKeyCode(u8);
    end);

    if success and (result and result ~= "") then
        return result;
    end;

    return nil;
end;

function u1.Label(p9) -- Line: 100
    -- upvalues: u1 (copy), u2 (copy), u4 (copy), u3 (copy)
    if u1.IsGamepadKey(p9) then
        return (u1.IsPlayStation() and u4 or u3)[p9] or p9;
    end;

    return u2[p9] or string.upper(p9);
end;

function u1.Describe(p10) -- Line: 112
    -- upvalues: u1 (copy)
    if typeof(p10) ~= "table" then
        return nil, nil, nil;
    end;

    local v11 = nil;
    local v12 = nil;
    local v13 = nil;

    for _, v in ipairs(p10) do
        if u1.IsGamepadKey(v) then
            if not v11 then
                v11 = u1.Label(v);
                v13 = v;
            end;
        else
            v12 = v12 or u1.Label(v);
        end;
    end;

    return v12, v11, v13;
end;

local u14 = {
    DPadUp = "D-UP",
    DPadDown = "D-DOWN",
    DPadLeft = "D-LEFT",
    DPadRight = "D-RIGHT"
};

function u1.Short(p15) -- Line: 130
    -- upvalues: u14 (copy), u1 (copy)
    return u14[p15] or u1.Label(p15);
end;

function u1.PadBinding(p16, p17, p18) -- Line: 141
    -- upvalues: u1 (copy)
    local ControlData = require(script.Parent.Parent.Metadata.ControlData.ControlData);
    local v19 = p18 and u1.Short or u1.Label;
    local v20 = ControlData.Controls and ControlData.Controls[p16];

    if v20 then
        v20 = v20[p17];
    end;

    if typeof(v20) == "table" then
        for _, v in ipairs(v20) do
            if u1.IsGamepadKey(v) then
                return v19(v), v;
            end;
        end;
    end;

    local PadLayer = ControlData.PadLayer;

    if not PadLayer then
        return nil;
    end;

    for i, v in pairs(PadLayer.Bank) do
        if v.group == p16 and v.action == p17 then
            if p18 then
                return v19(PadLayer.Modifier) .. "+" .. v19(i), i, PadLayer.Modifier;
            end;

            return "hold " .. v19(PadLayer.Modifier) .. " + " .. v19(i), i, PadLayer.Modifier;
        end;
    end;

    if p16 == "Combat" then
        for i, v in pairs(PadLayer.Hold) do
            if v == p17 then
                return "hold " .. v19(i), i;
            end;
        end;
    end;

    return nil;
end;

return u1;