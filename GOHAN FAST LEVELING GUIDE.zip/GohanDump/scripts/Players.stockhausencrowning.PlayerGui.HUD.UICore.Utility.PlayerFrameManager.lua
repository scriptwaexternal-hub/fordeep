-- Decompiled with Potassium's decompiler.

local Players = game:GetService("Players");
local RunService = game:GetService("RunService");
local LocalPlayer = Players.LocalPlayer;
local ViewportFrame = script:FindFirstAncestor("HUD").MainFrame.HUDisplay.PlayerFrame.ViewportFrame;
local u1 = {
    MeshPart = true,
    Part = true,
    Accessory = true,
    SpecialMesh = true,
    Model = true,
    Humanoid = true,
    Decal = true,
    Shirt = true,
    Pants = true,
    ShirtGraphic = true
};
local u2 = 0;
local u3 = nil;
local u4 = {};

local function stopMirror() -- Line: 42
    -- upvalues: u3 (ref)
    if u3 then
        u3:Disconnect();
        u3 = nil;
    end;
end;

local function startMirror(u5, u6, u7, u8) -- Line: 55
    -- upvalues: u3 (ref), RunService (copy), stopMirror (copy)
    if u3 then
        u3:Disconnect();
        u3 = nil;
    end;

    local v9 = {};

    for _, descendant in ipairs(u6:GetDescendants()) do
        if descendant:IsA("Motor6D") then
            v9[descendant.Parent.Name .. "/" .. descendant.Name] = descendant;
        end;
    end;

    local u10 = {};

    for _, descendant in ipairs(u5:GetDescendants()) do
        if descendant:IsA("Motor6D") then
            local v11 = v9[descendant.Parent.Name .. "/" .. descendant.Name];

            if v11 then
                table.insert(u10, { descendant, v11 });
            end;
        end;
    end;

    local u12;

    if u7 then
        if u8 then
            u12 = u7.CFrame.Position - u8.Position;
        else
            u12 = u8;
        end;
    else
        u12 = u7;
    end;

    u3 = RunService.PreRender:Connect(function() -- Line: 82
        -- upvalues: u5 (copy), u6 (copy), u3 (ref), u10 (copy), u12 (copy), u7 (copy), u8 (copy)
        if u5.Parent == nil or u6.Parent == nil then
            if u3 then
                u3:Disconnect();
                u3 = nil;
            end;

            return;
        end;

        for _, v in ipairs(u10) do
            v[2].Transform = v[1].Transform;
        end;

        if u12 and (u7.Parent and u8.Parent) then
            local CFrame_lookAt_ret = CFrame.lookAt(u8.Position + u12, u8.Position);
            u7.CFrame = u7.CFrame:Lerp(CFrame_lookAt_ret, 0.12);
        end;
    end);
    u6.Destroying:Once(stopMirror);
end;

function u4.Update(p13) -- Line: 100
    -- upvalues: u2 (ref), LocalPlayer (copy), u1 (copy), u3 (ref), ViewportFrame (copy), startMirror (copy)
    u2 = u2 + 1;
    local u14 = u2;
    task.spawn(function() -- Line: 104
        -- upvalues: LocalPlayer (ref), u14 (copy), u2 (ref), u1 (ref), u3 (ref), ViewportFrame (ref), startMirror (ref)
        local v15 = LocalPlayer.Character or LocalPlayer.CharacterAdded:Wait();
        task.wait(2);

        if u14 ~= u2 then
            return;
        end;

        if not v15.Parent then
            v15 = LocalPlayer.Character;

            if not (v15 and v15.Parent) then
                return;
            end;
        end;

        v15.Archivable = true;
        local v16 = v15:Clone();

        if not v16 then
            return;
        end;

        for _, child in ipairs(v16:GetChildren()) do
            if not u1[child.ClassName] then
                child:Destroy();
            end;
        end;

        local v17 = v16:FindFirstChildOfClass("Humanoid");

        if v17 then
            v17.EvaluateStateMachine = false;
        end;

        local Head = v16:FindFirstChild("Head");

        if not Head then
            v16:Destroy();

            return;
        end;

        if u14 ~= u2 then
            v16:Destroy();

            return;
        end;

        if u3 then
            u3:Disconnect();
            u3 = nil;
        end;

        ViewportFrame:ClearAllChildren();
        local WorldModel = Instance.new("WorldModel");
        WorldModel.Parent = ViewportFrame;
        v16.Parent = WorldModel;
        local Camera = Instance.new("Camera");
        Camera.CFrame = CFrame.lookAt((Head.CFrame * CFrame.new(0, 0.15, -2)).Position, Head.Position);
        Camera.Parent = ViewportFrame;
        ViewportFrame.CurrentCamera = Camera;
        startMirror(v15, v16, Camera, Head);
    end);
end;

task.spawn(function() -- Line: 171
    -- upvalues: LocalPlayer (copy), u4 (copy)
    local PlayerStats = LocalPlayer:WaitForChild("PlayerStats", 30);

    if not PlayerStats then
        return;
    end;

    local function hookValue(p18) -- Line: 175
        -- upvalues: PlayerStats (copy), u4 (ref)
        local v19 = PlayerStats:FindFirstChild(p18, true);

        if v19 then
            v19.Changed:Connect(function() -- Line: 178
                -- upvalues: u4 (ref)
                u4.Update();
            end);

            return;
        end;

        warn("PlayerFrameManager: no " .. p18 .. " stat to watch");
    end;

    local Form = PlayerStats:FindFirstChild("Form", true);

    if Form then
        Form.Changed:Connect(function() -- Line: 178
            -- upvalues: u4 (ref)
            u4.Update();
        end);
    else
        warn("PlayerFrameManager: no Form stat to watch");
    end;

    local SubForm = PlayerStats:FindFirstChild("SubForm", true);

    if SubForm then
        SubForm.Changed:Connect(function() -- Line: 178
            -- upvalues: u4 (ref)
            u4.Update();
        end);
    else
        warn("PlayerFrameManager: no SubForm stat to watch");
    end;

    LocalPlayer.CharacterAdded:Connect(function() -- Line: 188
        -- upvalues: u4 (ref)
        u4.Update();
    end);
end);
u4.Update();

return u4;