-- Decompiled with Potassium's decompiler.

local ReplicatedStorage = game:GetService("ReplicatedStorage");
local CollectionService = game:GetService("CollectionService");
local Modules = ReplicatedStorage:WaitForChild("Modules");
local Remotes = ReplicatedStorage:WaitForChild("Remotes");
Modules:WaitForChild("Metadata");
local Shared = Modules:WaitForChild("Shared");
Modules:WaitForChild("Utility");
local SoundManager = require(Shared:WaitForChild("SoundManager"));
require(Shared:WaitForChild("AnimationManager"));
local DialogueContext = require(Shared:WaitForChild("DialogueContext"));
local DialogueBindable = Remotes:WaitForChild("DialogueBindable");
local ServerRemote = Remotes:WaitForChild("ServerRemote");
local u1 = {};
local u2 = {};
local u3 = {
    ["King Yemma"] = {
        Prompt = 75,
        Dialogue = 90
    },
    Guru = {
        Prompt = 75,
        Dialogue = 90
    },
    Alucard = {
        Prompt = 45,
        Dialogue = 45
    }
};

function Setup_NPC(u4)
    -- upvalues: u1 (copy), u2 (copy), u3 (copy), SoundManager (copy), DialogueContext (copy), ServerRemote (copy), DialogueBindable (copy)
    if u1[u4] then
        return;
    end;

    u1[u4] = true;
    local HumanoidRootPart = u4:WaitForChild("HumanoidRootPart", 30);

    if not HumanoidRootPart then
        u1[u4] = nil;

        if not u2[u4] then
            local u5 = nil;
            u5 = u4.ChildAdded:Connect(function(p6) -- Line: 93
                -- upvalues: u5 (ref), u2 (ref), u4 (copy)
                if p6.Name ~= "HumanoidRootPart" then
                    return;
                end;

                u5:Disconnect();
                u2[u4] = nil;
                task.spawn(function() -- Line: 97
                    -- upvalues: u4 (ref)
                    local success, result = pcall(Setup_NPC, u4);

                    if not success then
                        warn("[MasterDialogue] late (stream-in) setup failed for", u4:GetFullName(), result);
                    end;
                end);
            end);
            u2[u4] = u5;
        end;

        warn("[MasterDialogue] no HumanoidRootPart yet for NPC (re-wires on stream-in):", u4:GetFullName());

        return;
    end;

    local u7 = {
        Range = 15,
        Position = HumanoidRootPart.Position,
        Speaker = u4.Name,
        NPC = u4
    };

    if u4:FindFirstAncestor("Ki Trainers") and not u4:FindFirstChild("Ki Trainer Marker") then
        local v8 = script["Ki Trainer Marker"]:Clone();
        v8.Parent = u4;
        v8.Enabled = true;
    end;

    u4.HumanoidRootPart.Anchored = true;
    local v9 = u4.HumanoidRootPart:FindFirstChild("ProximityPrompt") or Instance.new("ProximityPrompt", u4.HumanoidRootPart);
    v9.RequiresLineOfSight = false;
    v9.ObjectText = u7.Speaker;
    v9.ActionText = "Speak.";
    v9.HoldDuration = 0;
    local v10 = u3[u4.Name];

    if v10 then
        u7.Range = v10.Dialogue;
        v9.MaxActivationDistance = v10.Prompt;
    end;

    local u11 = false;
    u1[u4] = v9.Triggered:Connect(function(u12) -- Line: 159
        -- upvalues: u11 (ref), SoundManager (ref), u4 (copy), DialogueContext (ref), ServerRemote (ref), DialogueBindable (ref), u7 (copy)
        if u11 then
            return;
        end;

        u11 = true;
        local u13 = 0;
        local success, result = pcall(function() -- Line: 165
            -- upvalues: SoundManager (ref), u4 (ref), DialogueContext (ref), u12 (copy), ServerRemote (ref), DialogueBindable (ref), u7 (ref), u13 (ref)
            SoundManager.AddSound("Click", {
                Parent = u4
            }, "Client");
            local v14 = script:FindFirstChild(u4.Name, true) or script:FindFirstChild("DefaultNPC", true);

            if not v14 then
                warn(("[MasterDialogue] %s has no dialogue tree, and DefaultNPC is missing too -- nothing to open."):format(u4.Name));

                return;
            end;

            if not DialogueContext.Ready() then
                warn(("[MasterDialogue] %s: %s\'s profile is not loaded -- refusing to open dialogue rather than dead-ending in it."):format(u4.Name, u12.Name));

                return;
            end;

            ServerRemote:FireServer(nil, {
                Module = "NPCDataHandler",
                Action = "Spoke",
                Name = u4.Name,
                Player = u12
            });
            DialogueBindable:Fire(v14, u7);
            u13 = 0.5;
        end);

        if not success then
            warn(("[MasterDialogue] %s failed to open for %s: %s"):format(u4.Name, u12.Name, (tostring(result))));
        end;

        if u13 > 0 then
            task.delay(u13, function() -- Line: 210
                -- upvalues: u11 (ref)
                u11 = false;
            end);
        else
            u11 = false;
        end;
    end);
end;

local function safeSetup(u15) -- Line: 229
    task.spawn(function() -- Line: 230
        -- upvalues: u15 (copy)
        local success, result = pcall(Setup_NPC, u15);

        if not success then
            warn("[MasterDialogue] setup failed for", u15:GetFullName(), result);
        end;
    end);
end;

for _, v in pairs(CollectionService:GetTagged("NPC")) do
    task.spawn(function() -- Line: 230
        -- upvalues: v (copy)
        local success, result = pcall(Setup_NPC, v);

        if not success then
            warn("[MasterDialogue] setup failed for", v:GetFullName(), result);
        end;
    end);
end;

CollectionService:GetInstanceAddedSignal("NPC"):Connect(safeSetup);
script.Destroying:Connect(function() -- Line: 247
    -- upvalues: u1 (copy), u2 (copy)
    for i, v in pairs(u1) do
        if typeof(v) == "RBXScriptConnection" then
            v:Disconnect();
        end;

        u1[i] = nil;
    end;

    for i, v in pairs(u2) do
        v:Disconnect();
        u2[i] = nil;
    end;
end);