-- Decompiled with Potassium's decompiler.

local script_Parent = script.Parent;
local Auth = require(script_Parent:WaitForChild("Auth"));
local Defaults = require(script_Parent.Data:WaitForChild("Defaults"));
local Hook = require(script_Parent:WaitForChild("Hook"));
local Registry = require(script_Parent:WaitForChild("Registry"));
local Util = require(script_Parent:WaitForChild("Util"));
local Command = require(script:WaitForChild("Command"));
require(script_Parent:WaitForChild("Type"));
local u1 = {
    ignoreFormat = "\"`%%$%%%%^%%*%%.%%+%%-%%(%%)%%[%%]{}%%p"
};

function u1.rawParse(p2: string, p3: table, p4: string) -- Line: 23
    -- upvalues: Util (copy), u1 (copy)
    local v5 = Util.String.escapePattern(p4);
    local v6 = `%s[^%s"\`,{v5}]`;
    local v7 = nil;
    local v8 = nil;

    for _, v in p3 do
        local v9 = Util.String.escapePattern(v);
        v8 = string.find(p2, string.format(v6, v9, v9));

        if v8 then
            v7 = v;
            break;
        end;
    end;

    if v7 then
        local string_format_ret = string.format(`[%s{u1.ignoreFormat}{v5}]`, Util.String.escapePattern(v7));
        local string_sub_ret = string.sub(p2, v8 + #v7);
        local utf8_len_ret, v10 = utf8.len(string_sub_ret);

        if not utf8_len_ret then
            string_sub_ret = string.sub(string_sub_ret, v10 - 1);
        end;

        local v11 = { 1 };
        local v12 = { v11 };
        local v13 = nil;
        local v14 = "";
        local v15 = { v12 };

        for i, v in utf8.graphemes(string_sub_ret) do
            local string_sub_ret2 = string.sub(string_sub_ret, i, v);

            if v13 then
                table.insert(v11, string_sub_ret2);

                if string_sub_ret2 == v13 then
                    v13 = nil;
                end;
            elseif v14 == v7 and (#v11 == 1 and string.find(string_sub_ret2, string_format_ret)) then
                table.remove(v15);
                v12 = v15[#v15];
                v11 = { i - 1, v7, string_sub_ret2 };
                table.insert(v12, v11);
            elseif string_sub_ret2 == v7 and (string.find(v14, "%s") or string.find(v14, p4)) then
                if #v11 == 1 or (string.find(v11[2], "%s") or string.find(v11[2], p4)) then
                    table.remove(v12);
                elseif string.find(v14, "%s") then
                    table.remove(v11);
                end;

                v11 = { i + 1 };
                v12 = { v11 };
                table.insert(v15, v12);
            elseif string_sub_ret2 == "`" or string_sub_ret2 == "\"" then
                if string.find(v14, p4) then
                    if #v11 == 1 then
                        v11[1] = i;
                        v11[2] = string_sub_ret2;
                        v13 = string_sub_ret2;
                    else
                        v11 = { i, string_sub_ret2 };
                        table.insert(v12, v11);
                        v13 = string_sub_ret2;
                    end;
                else
                    table.insert(v11, string_sub_ret2);
                    v13 = string_sub_ret2;
                end;
            elseif string.find(string_sub_ret2, p4) and not string.find(v14, p4) then
                v11 = { i + 1 };
                table.insert(v12, v11);
            else
                table.insert(v11, string_sub_ret2);
            end;

            v14 = string_sub_ret2;
        end;

        for _, v in v15 do
            for _, v2 in v do
                local v16 = v2[1];
                local table_concat_ret = table.concat(v2, nil, 2);
                table.clear(v2);
                v2[1] = v16 + #v7;
                v2[2] = table_concat_ret;
            end;
        end;

        return v15;
    end;
end;

function u1.prepareCommands(p17: any, p18: number, p19: string) -- Line: 112
    -- upvalues: Util (copy), u1 (copy), Registry (copy), Auth (copy), Defaults (copy), Command (copy)
    if not utf8.len(p19) then
        return false, "Invalid utf8 string";
    end;

    local v20 = Util.String.trimStart(p19);
    local v21 = u1.rawParse(v20, { p17.getCommandPrefix(p18), unpack(p17.Data.settings.prefix) }, p17.Data.settings.splitKey or " ");

    if v21 then
        local v22 = {};

        for _, v in v21 do
            local v23 = v[1][2];
            local string_lower_ret = string.lower(v23);
            local v24 = Registry.commands[string_lower_ret];

            if not v24 then
                return false, `Invalid command: {v23}, did you mean "{Registry.suggestCommandAlias(string_lower_ret)}"?`;
            end;

            if not Auth.hasCommand(p18, v24) then
                if not p17.IsClient then
                    return false, `"<b>{v23}</b>" command restricted`;
                end;

                for i, v2 in Defaults.roles do
                    if (i == "vip" and p17.Data.settings.vip or v2.gamepasses) and Auth.roleCanUseCommand(i, v24) then
                        if i == "vip" and p17.Data.settings.vip then
                            p17.PromptPurchaseVIP();
                        elseif v2.gamepasses[1] then
                            p17.Service.Marketplace:PromptGamePassPurchase(p17.LocalPlayer, v2.gamepasses[1]);
                        end;
                    end;
                end;

                return false, `"<b>{v23}</b>" command restricted to <b>{v24.RestrictedToRole.name}</b>`;
            end;

            local v25 = Command.new(p17, string_lower_ret, v24, v, p18, v20);
            local v26, v27 = v25:validate();
            table.insert(v22, v25);

            if not v26 then
                v25.Error = v27;

                return false, v27;
            end;
        end;

        return true, v22;
    end;
end;

local u28 = {};

local function resetLimit(p29: number) -- Line: 173
    -- upvalues: u28 (copy)
    u28[p29] = nil;
end;

function u1.runCommands(u30: any, p31: number, u32: string, u33: boolean?, p34: boolean?) -- Line: 177
    -- upvalues: u28 (copy), u1 (copy), Hook (copy), resetLimit (copy), Util (copy)
    local u35 = p31 or u30.creatorId;
    local v36 = nil;
    local v37 = nil;

    if u30.IsServer then
        local _, v38 = u30.Auth.getRank(u35);

        if v38.limits then
            v36 = v38.limits.cooldown;
            v37 = v38.limits.commands;
        end;

        if (v37 or (1 / 0)) < (u28[u35] or 0) then
            u30.alert(u35, "<b>Command usage on cooldown!</b>", true);

            return false;
        end;

        if #u32 > 1024 and not u30.Auth.hasRestrictedRole(u35) then
            u32 = string.sub(u32, 1, 1024);
        end;
    end;

    local v39, v40 = u1.prepareCommands(u30, u35, u32);
    local u41 = {};
    local v42 = {};

    if v39 then
        Hook.runPreparedCommands:Fire(u35, v40, u32);

        for i, v in v40 do
            if p34 then
                v.global = true;
            end;

            local _, v43 = v:run();

            if v43 then
                local v44 = u30.Util.String.escapeRichText(v43);
                local v45 = `<b>"{v.alias}" command failed:</b> {v44}`;
                table.insert(v42, v45);
            else
                table.insert(u41, v);
            end;

            if u30.IsServer and v37 then
                if not u28[u35] then
                    u28[u35] = 0;
                    task.delay(v36, resetLimit, u35);
                end;

                local v46 = u28;
                v46[u35] = v46[u35] + 1;

                if v37 < u28[u35] then
                    local v47 = v;
                    local v48 = {};

                    for i2 = i, #v40 do
                        table.insert(v48, v47.alias);
                        local _ = i2;
                    end;

                    local v49 = #v48 == 0 and "" or `\nCommands not ran: {table.concat(v48, ", ")}`;
                    u30.alert(u35, `<b>Command limit reached!</b>{v49}`, true);
                    break;
                end;
            end;
        end;
    else
        table.insert(v42, v40);
    end;

    if #v42 > 0 then
        local v50 = `{table.concat(v42, "\n")}`;

        if u30.IsServer then
            local PlayerByUserId = u30.Service.Players:GetPlayerByUserId(u35);

            if PlayerByUserId then
                u30.Remote.Notify:Fire(PlayerByUserId, {
                    From = "_K",
                    Sound = "Call_Leave",
                    Text = v50,
                    TextColor3 = Color3.new(1, 0, 0)
                });
                local v51 = u30.Logger:encode("ERROR");
                local ServerTimeNow = workspace:GetServerTimeNow();
                local Name = PlayerByUserId.Name;

                for _, v in v42 do
                    u30.Remote.Log:Fire(PlayerByUserId, {
                        v,
                        v51,
                        ServerTimeNow,
                        u35,
                        Name
                    });
                end;
            end;
        else
            task.spawn(u30.Notify, {
                From = "_K",
                Sound = "Call_Leave",
                Text = v50,
                TextColor3 = Color3.new(1, 0, 0)
            });

            for _, v in v42 do
                u30.log(v, "ERROR", u35);
            end;
        end;
    end;

    if u30.IsClient and #u41 > 0 then
        local CommandPrefix = u30.getCommandPrefix(u35);
        local v52 = {};
        local v53 = false;

        for _, v in u41 do
            if v.definition.run then
                local v54 = v.array[#v.array];
                local string_sub_ret = string.sub(u32, v.array[1][1], v54[1] + #v54[2]);
                table.insert(v52, string_sub_ret);
                v53 = true;
            end;
        end;

        if v53 then
            u30.Remote.Command:Fire((`{CommandPrefix}{table.concat(v52, " " .. CommandPrefix)}`));
        end;
    end;

    if #u41 == 0 and #v42 == 0 then
        return true;
    end;

    task.spawn(function() -- Line: 285
        -- upvalues: u33 (copy), u41 (copy), Util (ref), u30 (copy), u35 (ref), u32 (ref)
        if u33 then
            return;
        end;

        local v55;

        if #u41 > 0 then
            local v56 = Util.Tasks.new();
            local CommandPrefix = u30.getCommandPrefix();
            local u57 = {};
            local u58 = 1;

            for _, v in u41 do
                if not (v.definition.noLog or u30.IsClient and not v.definition.runClient) then
                    u57[u58] = CommandPrefix .. v.alias;
                    u58 = u58 + 1;

                    for _, v2 in v.args do
                        v56:add(function() -- Line: 303
                            -- upvalues: v2 (copy), Util (ref), u30 (ref), u35 (ref), u57 (copy), u58 (copy)
                            local v59;

                            if v2.rawType.log then
                                v59 = v2.rawType.log(v2);
                            else
                                v59 = Util.Table.concat(v2.parsedArgs, ",");

                                if v2.rawType.filterLog and u30.IsServer then
                                    v59 = Util.String.filterForBroadcast(v59, u35);
                                end;
                            end;

                            u57[u58] = v59;
                        end);
                        u58 = u58 + 1;
                    end;
                end;
            end;

            v56:wait();

            if #u57 == 0 then
                return;
            end;

            v55 = table.concat(u57, " ");
        else
            v55 = Util.String.trim(u32);

            if #v55 == 0 then
                return;
            end;

            if u30.IsServer then
                v55 = Util.String.filterForBroadcast(v55, u35);
            end;
        end;

        u30.log(v55 or "", "COMMAND", u35);
    end);

    return #v42 == 0;
end;

return u1;