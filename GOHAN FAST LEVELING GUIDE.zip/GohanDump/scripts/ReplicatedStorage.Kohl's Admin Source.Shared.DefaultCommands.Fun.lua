-- Decompiled with Potassium's decompiler.

return {
    {
        name = "disco",
        description = "It\'s time to party! 🎉",
        aliases = { "🪩", "un🪩", "undisco" },

        env = function(u1) -- Line: 8, Name: env
            local u2 = {
                id = false,
                restore = false
            };

            function u2.cleanup() -- Line: 10
                -- upvalues: u2 (copy), u1 (copy)
                if u2.restore then
                    local Lighting = u1.Service.Lighting;
                    local Lighting2 = u1.Service.Lighting;
                    local v3, v4 = unpack(u2.restore);
                    Lighting.Ambient = v3;
                    Lighting2.FogColor = v4;
                    u2.restore = false;
                end;

                u2.id = false;
            end;

            return u2;
        end,

        run = function(u5) -- Line: 20, Name: run
            if u5.undo then
                return u5.env.cleanup();
            end;

            if not u5.env.restore then
                u5.env.restore = { u5._K.Service.Lighting.Ambient, u5._K.Service.Lighting.FogColor };
            end;

            local u6 = time();
            u5.env.id = u6;
            task.spawn(function() -- Line: 31
                -- upvalues: u6 (copy), u5 (copy)
                repeat
                    local Color3_fromHSV_ret = Color3.fromHSV((time() - u6) % 1, 1, 1);
                    u5._K.Service.Lighting.Ambient = Color3_fromHSV_ret;
                    u5._K.Service.Lighting.FogColor = Color3_fromHSV_ret;
                    task.wait(0.3141592653589793);
                until u5.env.id ~= u6;
            end);
        end
    },
    {
        name = "creeper",
        description = "Turns one or more player(s) into a creeper? Aww, man...",
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) to turn into a creeper.",
                shouldRequest = true
            } },

        env = function(u7) -- Line: 53, Name: env
            return {
                apply = function(p8) -- Line: 55, Name: apply
                    -- upvalues: u7 (copy)
                    local Character = p8.Character;
                    local v9;

                    if Character then
                        v9 = Character:FindFirstChildOfClass("Humanoid");
                    else
                        v9 = Character;
                    end;

                    if not (v9 and (Character.PrimaryPart and not Character:GetAttribute("_KCreeper"))) then
                        return;
                    end;

                    local RigType = v9.RigType;

                    if v9.RigType == Enum.HumanoidRigType.R15 then
                        Character = u7.Registry.commands.r6.env.apply(p8, Enum.HumanoidRigType.R6);
                    end;

                    Character:SetAttribute("_KCreeper", RigType);
                    local Torso = Character:FindFirstChild("Torso");

                    if not Torso then
                        return;
                    end;

                    Torso.Transparency = 0;
                    local Neck = Torso:FindFirstChild("Neck");
                    local v10 = Torso:FindFirstChild("Right Shoulder");
                    local v11 = Torso:FindFirstChild("Left Shoulder");
                    local v12 = Torso:FindFirstChild("Right Hip");
                    local v13 = Torso:FindFirstChild("Left Hip");

                    if Neck then
                        Neck.C0 = CFrame.new(0, 1, 0) * CFrame.Angles(1.5707963267948966, 3.141592653589793, 0);
                    end;

                    if v10 then
                        v10.C0 = CFrame.new(0, -1.5, -0.5) * CFrame.Angles(0, 1.5707963267948966, 0);
                    end;

                    if v11 then
                        v11.C0 = CFrame.new(0, -1.5, -0.5) * CFrame.Angles(0, -1.5707963267948966, 0);
                    end;

                    if v12 then
                        v12.C0 = CFrame.new(0, -1, 0.5) * CFrame.Angles(0, 1.5707963267948966, 0);
                    end;

                    if v13 then
                        v13.C0 = CFrame.new(0, -1, 0.5) * CFrame.Angles(0, -1.5707963267948966, 0);
                    end;

                    u7.Registry.commands.crm.env.update(Character, Color3.new(0, 0.5, 0), 0, Enum.Material.SmoothPlastic);
                end
            };
        end,

        run = function(p14: any, p15: table) -- Line: 108, Name: run
            for _, v in p15 do
                p14.env.apply(v);
            end;
        end
    },
    {
        name = "uncreeper",
        description = "Reverts one or more player(s) from a creeper",
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) to revert from a creeper.",
                shouldRequest = true
            } },

        env = function(u16) -- Line: 125, Name: env
            return {
                apply = function(p17) -- Line: 127, Name: apply
                    -- upvalues: u16 (copy)
                    local Character = p17.Character;
                    local v18;

                    if Character then
                        v18 = Character:FindFirstChildOfClass("Humanoid");
                    else
                        v18 = Character;
                    end;

                    local v19;

                    if Character then
                        v19 = Character:GetAttribute("_KCreeper");
                    else
                        v19 = Character;
                    end;

                    if not (v18 and (Character.PrimaryPart and v19)) then
                        return;
                    end;

                    Character:SetAttribute("_KCreeper", nil);

                    if v19 == Enum.HumanoidRigType.R15 then
                        u16.Registry.commands.r15.env.apply(p17, Enum.HumanoidRigType.R15);

                        return;
                    end;

                    local Torso = Character:FindFirstChild("Torso");

                    if not Torso then
                        return;
                    end;

                    Torso.Transparency = 0;
                    local Neck = Torso:FindFirstChild("Neck");
                    local v20 = Torso:FindFirstChild("Right Shoulder");
                    local v21 = Torso:FindFirstChild("Left Shoulder");
                    local v22 = Torso:FindFirstChild("Right Hip");
                    local v23 = Torso:FindFirstChild("Left Hip");

                    if Neck then
                        Neck.C0 = CFrame.new(0, 1, 0) * CFrame.Angles(1.5707963267948966, 3.141592653589793, 0);
                    end;

                    if v20 then
                        v20.C0 = CFrame.new(1, 0.5, 0) * CFrame.Angles(0, 1.5707963267948966, 0);
                    end;

                    if v21 then
                        v21.C0 = CFrame.new(-1, 0.5, 0) * CFrame.Angles(0, -1.5707963267948966, 0);
                    end;

                    if v22 then
                        v22.C0 = CFrame.new(1, -1, 0) * CFrame.Angles(0, 1.5707963267948966, 0);
                    end;

                    if v23 then
                        v23.C0 = CFrame.new(-1, -1, 0) * CFrame.Angles(0, -1.5707963267948966, 0);
                    end;

                    u16.Registry.commands.crm.env.update(Character);
                end
            };
        end,

        run = function(p24: any, p25: table) -- Line: 176, Name: run
            for _, v in p25 do
                p24.env.apply(v);
            end;
        end
    },
    {
        name = "dog",
        description = "Turns one or more player(s) into dog",
        aliases = { "🐶", "🐎", "horse" },
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) to turn into a dog.",
                shouldRequest = true
            } },

        env = function(u26) -- Line: 194, Name: env
            return {
                R6 = function(p27) -- Line: 196, Name: R6
                    -- upvalues: u26 (copy)
                    if not (p27 and p27.PrimaryPart) then
                        return;
                    end;

                    local Torso = p27:FindFirstChild("Torso");

                    if not Torso then
                        return;
                    end;

                    Torso.Transparency = 1;
                    local Neck = Torso:FindFirstChild("Neck");
                    local v28 = Torso:FindFirstChild("Right Shoulder");
                    local v29 = Torso:FindFirstChild("Left Shoulder");
                    local v30 = Torso:FindFirstChild("Right Hip");
                    local v31 = Torso:FindFirstChild("Left Hip");

                    if Neck then
                        Neck.C0 = CFrame.new(0, -0.5, -2) * CFrame.Angles(1.5707963267948966, 3.141592653589793, 0);
                    end;

                    if v28 then
                        v28.C0 = CFrame.new(0.5, -1.5, -1.5) * CFrame.Angles(0, 1.5707963267948966, 0);
                    end;

                    if v29 then
                        v29.C0 = CFrame.new(-0.5, -1.5, -1.5) * CFrame.Angles(0, -1.5707963267948966, 0);
                    end;

                    if v30 then
                        v30.C0 = CFrame.new(1.5, -1, 1.5) * CFrame.Angles(0, 1.5707963267948966, 0);
                    end;

                    if v31 then
                        v31.C0 = CFrame.new(-1.5, -1, 1.5) * CFrame.Angles(0, -1.5707963267948966, 0);
                    end;

                    local v32 = u26.Flux.new("Seat")({
                        Name = "_KDogSeat",
                        Transparency = 0,
                        CastShadow = false,
                        CanQuery = false,
                        CanCollide = false,
                        Massless = true,
                        Size = Vector3.new(3, 1, 4),
                        TopSurface = 0,
                        BottomSurface = 0,
                        Color = Torso.Color,
                        Material = Torso.Material,
                        CFrame = Torso.CFrame
                    });
                    u26.Flux.new("Weld")({
                        Parent = v32,
                        Part0 = Torso,
                        Part1 = v32,
                        C1 = CFrame.new(0, 0.5, 0)
                    });
                    v32.Parent = p27;
                end,

                R15 = function(p33) -- Line: 254, Name: R15
                    -- upvalues: u26 (copy)
                    if not (p33 and p33.PrimaryPart) then
                        return;
                    end;

                    local UpperTorso = p33:FindFirstChild("UpperTorso");

                    if not UpperTorso then
                        return;
                    end;

                    local v34 = p33:FindFirstChild("LowerTorso") and p33.LowerTorso:FindFirstChild("Root");
                    local v35 = p33:FindFirstChild("Head") and p33.Head:FindFirstChild("Neck");
                    local v36 = p33:FindFirstChild("UpperTorso") and p33.UpperTorso:FindFirstChild("Waist");
                    local RightShoulder = p33:FindFirstChild("RightShoulder", true);
                    local LeftShoulder = p33:FindFirstChild("LeftShoulder", true);
                    local RightHip = p33:FindFirstChild("RightHip", true);
                    local LeftHip = p33:FindFirstChild("LeftHip", true);

                    if v34 then
                        v34.C0 = v34.C0 * (CFrame.Angles(-1.0471975511965976, 0, 0) - Vector3.new(0, 0.5, 0));
                    end;

                    if v36 then
                        v36.C0 = v36.C0 * CFrame.Angles(-0.5235987755982988, 0, 0);
                    end;

                    if v35 then
                        v35.C0 = v35.C0 * CFrame.Angles(1.5707963267948966, 0, 0);
                    end;

                    if RightShoulder then
                        RightShoulder.C0 = RightShoulder.C0 * CFrame.Angles(0.7853981633974483, 0, 0);
                    end;

                    if LeftShoulder then
                        LeftShoulder.C0 = LeftShoulder.C0 * CFrame.Angles(0.7853981633974483, 0, 0);
                    end;

                    if RightHip then
                        RightHip.C0 = RightHip.C0 * CFrame.Angles(-0.7853981633974483, 0, 0);
                    end;

                    if LeftHip then
                        LeftHip.C0 = LeftHip.C0 * CFrame.Angles(-0.7853981633974483, 0, 0);
                    end;

                    local v37 = u26.Flux.new("Seat")({
                        Name = "_KDogSeat",
                        Transparency = 1,
                        CastShadow = false,
                        CanQuery = false,
                        CanCollide = false,
                        Massless = true,
                        Size = Vector3.new(2, 1, 2),
                        CFrame = UpperTorso.CFrame
                    });
                    u26.Flux.new("Weld")({
                        Parent = v37,
                        Part0 = UpperTorso,
                        Part1 = v37,
                        C1 = CFrame.new(0, 0.1, -0.7) * CFrame.Angles(-1.5707963267948966, 0, 0)
                    });
                    v37.Parent = p33;
                end
            };
        end,

        run = function(p38, p39) -- Line: 318, Name: run
            for _, v in p39 do
                if v.Character and (v.Character.PrimaryPart and (v.Character:FindFirstChild("Humanoid") and not v.Character:FindFirstChild("_KDogSeat"))) then
                    local Humanoid = v.Character:FindFirstChild("Humanoid");

                    if Humanoid then
                        if Humanoid.RigType == Enum.HumanoidRigType.R6 then
                            p38.env.R6(v.Character);
                        else
                            p38.env.R15(v.Character);
                        end;
                    end;
                end;
            end;
        end
    },
    {
        name = "undog",
        description = "Reverts one or more player(s) from dog",
        aliases = { "un🐶", "un🐎", "unhorse" },
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) to revert dog from.",
                shouldRequest = true
            } },

        env = function(p40) -- Line: 352, Name: env
            return {
                R6 = function(p41) -- Line: 354, Name: R6
                    if not (p41 and p41.PrimaryPart) then
                        return;
                    end;

                    local Torso = p41:FindFirstChild("Torso");

                    if not Torso then
                        return;
                    end;

                    Torso.Transparency = 0;
                    local Neck = Torso:FindFirstChild("Neck");
                    local v42 = Torso:FindFirstChild("Right Shoulder");
                    local v43 = Torso:FindFirstChild("Left Shoulder");
                    local v44 = Torso:FindFirstChild("Right Hip");
                    local v45 = Torso:FindFirstChild("Left Hip");

                    if Neck then
                        Neck.C0 = CFrame.new(0, 1, 0) * CFrame.Angles(1.5707963267948966, 3.141592653589793, 0);
                    end;

                    if v42 then
                        v42.C0 = CFrame.new(1, 0.5, 0) * CFrame.Angles(0, 1.5707963267948966, 0);
                    end;

                    if v43 then
                        v43.C0 = CFrame.new(-1, 0.5, 0) * CFrame.Angles(0, -1.5707963267948966, 0);
                    end;

                    if v44 then
                        v44.C0 = CFrame.new(1, -1, 0) * CFrame.Angles(0, 1.5707963267948966, 0);
                    end;

                    if v45 then
                        v45.C0 = CFrame.new(-1, -1, 0) * CFrame.Angles(0, -1.5707963267948966, 0);
                    end;
                end,

                R15 = function(p46) -- Line: 388, Name: R15
                    if not (p46 and p46.PrimaryPart) then
                        return;
                    end;

                    if not p46:FindFirstChild("UpperTorso") then
                        return;
                    end;

                    local v47 = p46:FindFirstChild("LowerTorso") and p46.LowerTorso:FindFirstChild("Root");
                    local v48 = p46:FindFirstChild("Head") and p46.Head:FindFirstChild("Neck");
                    local v49 = p46:FindFirstChild("UpperTorso") and p46.UpperTorso:FindFirstChild("Waist");
                    local RightShoulder = p46:FindFirstChild("RightShoulder", true);
                    local LeftShoulder = p46:FindFirstChild("LeftShoulder", true);
                    local RightHip = p46:FindFirstChild("RightHip", true);
                    local LeftHip = p46:FindFirstChild("LeftHip", true);

                    if v47 then
                        v47.C0 = v47.C0 * (CFrame.Angles(1.0471975511965976, 0, 0) + Vector3.new(0, 0.5, 0));
                    end;

                    if v49 then
                        v49.C0 = v49.C0 * CFrame.Angles(0.5235987755982988, 0, 0);
                    end;

                    if v48 then
                        v48.C0 = v48.C0 * CFrame.Angles(-1.5707963267948966, 0, 0);
                    end;

                    if RightShoulder then
                        RightShoulder.C0 = RightShoulder.C0 * CFrame.Angles(-0.7853981633974483, 0, 0);
                    end;

                    if LeftShoulder then
                        LeftShoulder.C0 = LeftShoulder.C0 * CFrame.Angles(-0.7853981633974483, 0, 0);
                    end;

                    if RightHip then
                        RightHip.C0 = RightHip.C0 * CFrame.Angles(0.7853981633974483, 0, 0);
                    end;

                    if LeftHip then
                        LeftHip.C0 = LeftHip.C0 * CFrame.Angles(0.7853981633974483, 0, 0);
                    end;
                end
            };
        end,

        run = function(p50, p51, p52) -- Line: 432, Name: run
            for _, v in p51 do
                if v.Character then
                    local _KDogSeat = v.Character:FindFirstChild("_KDogSeat");

                    if _KDogSeat then
                        _KDogSeat:Destroy();
                        local Humanoid = v.Character:FindFirstChild("Humanoid");

                        if Humanoid then
                            if Humanoid.RigType == Enum.HumanoidRigType.R6 then
                                p50.env.R6(v.Character);
                            else
                                p50.env.R15(v.Character);
                            end;
                        end;
                    end;
                end;
            end;
        end
    },
    {
        name = "char",
        description = "Changes the character of one or more player(s).",
        aliases = { "character" },
        credit = { "Kohl @Scripth", "@AlanDev09" },
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) whose character to change.",
                shouldRequest = true
            }, {
                type = "userId",
                name = "UserId",
                description = "The identifier of the Roblox user.",
                optional = true
            } },

        run = function(p53, p54, p55) -- Line: 472, Name: run
            local HumanoidDescriptionFromUserId = p53._K.Service.Players:GetHumanoidDescriptionFromUserId(p55);

            if not HumanoidDescriptionFromUserId then
                return "Invalid character appearance!";
            end;

            for _, v in p54 do
                local v56;

                if p55 == nil then
                    v56 = v.UserId;
                else
                    v56 = p55;
                end;

                v.CharacterAppearanceId = v56;
                local v57 = v.Character and v.Character:FindFirstChildOfClass("Humanoid");

                if v57 then
                    local _KHumanoidDescription = v:FindFirstChild("_KHumanoidDescription");

                    if _KHumanoidDescription then
                        _KHumanoidDescription:Destroy();
                    end;

                    task.spawn(v57.ApplyDescription, v57, HumanoidDescriptionFromUserId);
                end;
            end;
        end
    },
    {
        name = "unchar",
        description = "Restores the character of one or more player(s).",
        aliases = { "uncharacter" },
        credit = { "Kohl @Scripth", "@AlanDev09" },
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) whose character to restore."
            } },

        env = function(u58) -- Line: 504, Name: env
            return {
                apply = function(p59, p60) -- Line: 506, Name: apply
                    -- upvalues: u58 (copy)
                    local HumanoidDescriptionFromUserId = u58.Service.Players:GetHumanoidDescriptionFromUserId(p59.UserId);

                    if HumanoidDescriptionFromUserId then
                        p60:ApplyDescription(HumanoidDescriptionFromUserId);
                    end;
                end
            };
        end,

        run = function(p61, p62) -- Line: 514, Name: run
            for _, v in p62 do
                if v.CharacterAppearanceId ~= v.UserId then
                    v.CharacterAppearanceId = v.UserId;
                    local v63 = v.Character:FindFirstChildOfClass("Humanoid");

                    if v63 then
                        local _KHumanoidDescription = v:FindFirstChild("_KHumanoidDescription");

                        if _KHumanoidDescription then
                            _KHumanoidDescription:Destroy();
                        end;

                        task.spawn(p61.env.apply, v, v63);
                    end;
                end;
            end;
        end
    },
    {
        name = "clone",
        description = "Clones the character of one or more player(s).",
        aliases = {},
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) whose character to clone."
            } },

        run = function(p64, p65, p66) -- Line: 544, Name: run
            for _, v in p65 do
                if v.Character then
                    v.Character.Archivable = true;
                    local v67 = v.Character:Clone();
                    v.Character.Archivable = false;
                    v67.Name = v67.Name .. "Clone";
                    v67.Parent = workspace;
                    table.insert(p64._K.cleanupCommands, v67);
                    v67:MoveTo(v.Character:GetPivot().Position);
                end;
            end;
        end
    },
    {
        name = "control",
        description = "Controls the character of a player.",
        aliases = { "takeover" },
        args = { {
                type = "player",
                name = "Player",
                description = "The player to control.",
                shouldRequest = true,
                ignoreSelf = true
            } },

        envClient = function(p68) -- Line: 571, Name: envClient
            p68.Remote.ControlCommand:Connect(function(p69: userdata) -- Line: 572
                if p69 then
                    workspace.CurrentCamera.CameraSubject = p69;
                end;
            end);
        end,

        env = function(p70) -- Line: 578, Name: env
            return {
                connections = {},
                remote = p70.Remote.ControlCommand
            };
        end,

        run = function(u71: any, u72: userdata) -- Line: 584, Name: run
            local u73;

            if u72 then
                u73 = u72.Character;
            else
                u73 = u72;
            end;

            if not u73 then
                return `{u72} doesn't have a character!`;
            end;

            local u74 = u73:FindFirstChildOfClass("Humanoid");

            if not u74 then
                return `{u72} doesn't have a humanoid!`;
            end;

            u71.fromPlayer.Character = u73;
            u71.env.remote:Fire(u71.fromPlayer, u74);
            u71.env.remote:Fire(u72, u74);

            for _, descendant in u73:GetDescendants() do
                if descendant:IsA("BasePart") and descendant:CanSetNetworkOwnership() then
                    descendant:SetNetworkOwner(u71.fromPlayer);
                end;
            end;

            if not u71.env.connections[u72] then
                u71.env.connections[u72] = u71.fromPlayer:GetPropertyChangedSignal("Character"):Once(function() -- Line: 607
                    -- upvalues: u71 (copy), u72 (copy), u74 (copy), u73 (copy)
                    u71.env.connections[u72] = nil;

                    if u72 and (u72.Parent and (u74 and u74.Health > 0)) then
                        local Pivot = u73:GetPivot();
                        u72:LoadCharacterAsync();
                        u72.Character:PivotTo(Pivot);
                        u71._K.Remote.Refresh:Fire(u72);
                    end;
                end);
            end;
        end
    },
    {
        name = "jumpscare",
        description = "Jumpscares a player with an image and sound.",
        group = "Fun",
        aliases = { "js" },
        credit = { "Kohl @Scripth", "Pok @vonials" },
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) whose performance to improve.",
                shouldRequest = true
            }, {
                type = "image",
                name = "DecalId",
                description = "The image to show the player(s).",
                optional = true
            }, {
                type = "number",
                name = "SoundId",
                description = "The sound to play.",
                optional = true
            } },

        envClient = function(u75) -- Line: 648, Name: envClient
            u75.Remote.Jumpscare:Connect(function(p76: string, p77: number) -- Line: 649
                -- upvalues: u75 (copy)
                local v78 = u75.UI.new("ImageLabel")({
                    Name = "JumpScare",
                    BackgroundTransparency = 0,
                    ZIndex = 900000000,
                    Parent = u75.UI.LayerTop,
                    BackgroundColor3 = Color3.new(0, 0, 0),
                    Size = UDim2.fromScale(1, 1),
                    Image = p76
                });
                u75.UI.new("Sound")({
                    Volume = 5,
                    Parent = v78,
                    SoundId = "rbxassetid://" .. (tonumber(p77) or 0)
                }):Play();
                task.delay(2, game.Destroy, v78);
            end);
        end,

        env = function(p79) -- Line: 668, Name: env
            return {
                remote = p79.Remote.Jumpscare
            };
        end,

        run = function(p80: any, p81: table, p82: string?, p83: number?) -- Line: 671, Name: run
            local v84 = p82 or "rbxassetid://1119705746";
            local v85 = p83 or 130285917830946;

            for _, v in p81 do
                p80.env.remote:Fire(v, v84, v85);
            end;
        end
    },
    {
        name = "glitch",
        description = "Makes one or more player(s) start glitching.",
        aliases = { "unglitch", "vibrate", "unvibrate" },
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) to glitch.",
                shouldRequest = true
            }, {
                type = "number",
                name = "Distance",
                description = "The glitch distance.",
                optional = true
            } },

        envClient = function(u86) -- Line: 699, Name: envClient
            local u87 = nil;
            u86.Remote.Glitch:Connect(function(p88: boolean?, p89: number?) -- Line: 701
                -- upvalues: u87 (ref), u86 (copy)
                if u87 then
                    u87:Disconnect();
                end;

                local Character = u86.LocalPlayer.Character;

                if p88 and Character then
                    local u90 = p89 or 1;
                    local u91 = false;
                    u87 = u86.Service.RunService.preRender:Connect(function() -- Line: 709
                        -- upvalues: u91 (ref), Character (copy), u90 (copy)
                        u91 = not u91;
                        local Pivot = Character:GetPivot();
                        local v92;

                        if u91 then
                            v92 = -u90;
                        else
                            v92 = u90;
                        end;

                        Character:PivotTo(Pivot * CFrame.new(0, 0, v92));
                    end);
                end;
            end);
        end,

        env = function(p93) -- Line: 716, Name: env
            return {
                remote = p93.Remote.Glitch
            };
        end,

        run = function(p94: any, p95: table, p96: number) -- Line: 721, Name: run
            for _, v in p95 do
                p94.env.remote:Fire(v, not p94.undo, p96);
            end;
        end
    },
    {
        name = "seizure",
        description = "Makes one or more player(s) start seizing.",
        aliases = { "seize" },
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) to seize.",
                shouldRequest = true
            } },

        env = function(p97) -- Line: 740, Name: env
            return {
                apply = function(p98: userdata) -- Line: 742, Name: apply
                    if p98:GetAttribute("_KSeizure") then
                        return;
                    end;

                    p98:SetAttribute("_KSeizure", true);
                    p98:PivotTo(p98:GetPivot() * CFrame.Angles(1.5707963267948966, 0, 0));
                    local v99 = p98:FindFirstChildOfClass("Humanoid");

                    while p98 and (p98.Parent and (p98.PrimaryPart and (v99 and p98:GetAttribute("_KSeizure")))) do
                        v99.PlatformStand = true;
                        local PrimaryPart = p98.PrimaryPart;
                        local math_random_ret = math.random(-10, 10);
                        local math_random_ret2 = math.random(-5, 1);
                        PrimaryPart.AssemblyLinearVelocity = Vector3.new(math_random_ret, math_random_ret2, math.random(-10, 10));
                        local PrimaryPart2 = p98.PrimaryPart;
                        local math_random_ret3 = math.random(-5, 5);
                        local math_random_ret4 = math.random(-5, 5);
                        PrimaryPart2.AssemblyAngularVelocity = Vector3.new(math_random_ret3, math_random_ret4, math.random(-5, 5));
                        task.wait();
                    end;

                    if v99 then
                        v99.PlatformStand = false;
                    end;
                end
            };
        end,

        run = function(p100: any, p101: table) -- Line: 769, Name: run
            for _, v in p101 do
                if v.Character then
                    p100.env.apply(v.Character);
                end;
            end;
        end
    },
    {
        name = "unseizure",
        description = "Saves one or more player(s) from seizing.",
        aliases = { "unseize" },
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) to save.",
                shouldRequest = true
            } },

        run = function(p102: any, p103: table) -- Line: 790, Name: run
            for _, v in p103 do
                if v.Character then
                    v.Character:SetAttribute("_KSeizure", nil);
                end;
            end;
        end
    },
    {
        name = "infect",
        description = "Infects of one or more player(s), starting a zombie outbreak!",
        aliases = { "zombie" },
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) to infect.",
                shouldRequest = true
            } },

        env = function(u104) -- Line: 810, Name: env
            local u105 = {
                infected = {}
            };

            function u105.infect(p106, u107) -- Line: 813
                -- upvalues: u104 (copy), u105 (copy)
                if not u107 then
                    return;
                end;

                local v108 = u107:FindFirstChildOfClass("Humanoid");

                if not v108 then
                    return;
                end;

                local v109 = u107:FindFirstChild("Head") and u107.Head:FindFirstChild("face");

                if v109 then
                    if not v109:GetAttribute("_KInfectOriginal") then
                        v109:SetAttribute("_KInfectOriginal", v109.Texture);
                    end;

                    v109.Texture = "rbxassetid://629946036";
                end;

                local v110 = u107:FindFirstChildOfClass("BodyColors");

                if v110 then
                    v110.HeadColor3 = Color3.fromRGB(50, 100, 50);
                    v110.LeftArmColor3 = Color3.fromRGB(50, 100, 50);
                    v110.RightArmColor3 = Color3.fromRGB(50, 100, 50);
                    v110.TorsoColor3 = Color3.fromRGB(100, 50, 20);
                    v110.LeftLegColor3 = Color3.fromRGB(100, 50, 20);
                    v110.RightLegColor3 = Color3.fromRGB(100, 50, 20);
                end;

                local v111 = u107:FindFirstChildOfClass("Shirt");

                if v111 then
                    v111:Destroy();
                end;

                local v112 = u107:FindFirstChildOfClass("Pants");

                if v112 then
                    v112:Destroy();
                end;

                u104.Flux.new("Sound")({
                    PlayOnRemove = true,
                    SoundId = "rbxassetid://9114030073",
                    Parent = u107.PrimaryPart
                }):Destroy();
                u105.infected[u107] = v108.Touched:Connect(function(p113) -- Line: 858
                    -- upvalues: u105 (ref), u104 (ref)
                    if not (p113 and (p113.Parent and not u105.infected[p113.Parent])) then
                        return;
                    end;

                    local PlayerFromCharacter = u104.Service.Players:GetPlayerFromCharacter(p113.Parent);

                    if not PlayerFromCharacter then
                        return;
                    end;

                    u105.infect(PlayerFromCharacter, p113.Parent);
                end);
                p106.CharacterRemoving:Once(function() -- Line: 871
                    -- upvalues: u105 (ref), u107 (copy)
                    if u105.infected[u107] then
                        u105.infected[u107]:Disconnect();
                        u105.infected[u107] = nil;
                    end;
                end);
            end;

            return u105;
        end,

        run = function(p114, p115) -- Line: 882, Name: run
            for _, v in p115 do
                p114.env.infect(v, v.Character);
            end;
        end
    },
    {
        name = "explode",
        description = "Explodes one or more player(s).",
        aliases = { "boom", "💥" },
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) to explode.",
                shouldRequest = true
            } },

        run = function(p116, p117, p118) -- Line: 901, Name: run
            for _, v in p117 do
                if v.Character then
                    local v119 = v.Character:FindFirstChildOfClass("Humanoid");

                    if v119 then
                        v119.MaxHealth = math.max(1, v119.MaxHealth);
                        v119.Health = 0;
                        local Explosion = Instance.new("Explosion");
                        Explosion.ExplosionType = Enum.ExplosionType.NoCraters;
                        Explosion.Position = v.Character:GetPivot().Position;
                        Explosion.DestroyJointRadiusPercent = 0;
                        Explosion.Parent = v.Character;
                    end;
                end;
            end;
        end
    },
    {
        name = "nuke",
        description = "Nuke one or more player(s).",
        aliases = {},
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) to nuke.",
                shouldRequest = true
            } },

        env = function(u120) -- Line: 933, Name: env
            local u121 = u120.Flux.new("Sound")({
                SoundId = "rbxassetid://9114224354",
                EmitterSize = 512,
                Volume = 1
            });
            local u122 = nil;
            task.defer(function() -- Line: 940
                -- upvalues: u120 (copy), u122 (ref)
                local v123, v124 = u120.Util.Retry(function() -- Line: 941
                    -- upvalues: u120 (ref)
                    return u120.Service.Insert:CreateMeshPartAsync("rbxassetid://116325731356319", Enum.CollisionFidelity.Box, Enum.RenderFidelity.Precise);
                end);

                if not v123 then
                    u122 = Instance.new("MeshPart");

                    return;
                end;

                u122 = v124;
                u120.Flux.edit(u122, {
                    Name = "Sphere",
                    Transparency = 0.75,
                    Anchored = true,
                    EnableFluidForces = false,
                    CastShadow = false,
                    CanCollide = false,
                    CanTouch = false,
                    CanQuery = false,
                    Massless = true,
                    Size = Vector3.new(0, 0, 0),
                    Color = Color3.new(1, 0, 0),
                    Material = Enum.Material.Neon
                });
            end);

            local function explode(p125, p126) -- Line: 970
                if p125:GetAttribute("_KNuked") then
                    return;
                end;

                p125:SetAttribute("_KNuked", true);
                local Explosion = Instance.new("Explosion");
                Explosion.ExplosionType = Enum.ExplosionType.NoCraters;
                Explosion.Position = p126;
                Explosion.DestroyJointRadiusPercent = 0;
                Explosion.Parent = p125;
                local v127 = p125:FindFirstChildOfClass("Humanoid");

                if not v127 then
                    return;
                end;

                v127.MaxHealth = math.max(1, v127.MaxHealth);
                v127.Health = 0;
            end;

            return {
                explode = explode,

                nuke = function(p128: userdata?, p129: any, p130: any) -- Line: 993, Name: nuke
                    -- upvalues: u122 (ref), u121 (copy), u120 (copy), explode (copy)
                    local u131 = u122:Clone();
                    u131.Position = p130;
                    local v132 = u122:Clone();
                    v132.Color = Color3.new(1, 1, 0);
                    v132.Position = p130 + Vector3.new(0, 0.1, 0);
                    v132.Parent = u131;
                    local v133 = u122:Clone();
                    v133.Color = Color3.new(1, 1, 1);
                    v133.Position = p130 - Vector3.new(0, 0.1, 0);
                    v133.Parent = u131;
                    u131.Parent = workspace;
                    local v134 = u121:Clone();
                    v134.Parent = u131;
                    v134:Play();
                    task.delay(2, function() -- Line: 1012
                        -- upvalues: u121 (ref), u131 (copy)
                        local v135 = u121:Clone();
                        v135.Volume = 1;
                        v135.Parent = u131;
                        v135:Play();
                    end);
                    local v136 = tick();

                    while true do
                        local Tween = u120.Service.Tween;
                        local v137 = (tick() + 1 - v136) / 8;
                        local Value = Tween:GetValue(1 - (1 - math.clamp(v137, 0, 1)) ^ 2, Enum.EasingStyle.Bounce, Enum.EasingDirection.In);
                        local v138 = Value * 512;
                        u131.Size = Vector3.new(1, 1, 1) * v138;
                        v132.Size = u131.Size * 0.9;
                        v133.Size = u131.Size * 0.5;

                        for _, v in u120.Service.Players:GetPlayers() do
                            if p128 and p128.UserId == u120.creatorId or p129 > u120.Auth.getRank(v.UserId) then
                                local v139 = v.Character and not v.Character:GetAttribute("_KNuked") and p130 - v.Character:GetPivot().Position;

                                if v139 and v139.Magnitude <= v138 / 2 then
                                    explode(v.Character, v.Character:GetPivot().Position + v139.unit);
                                end;
                            end;
                        end;

                        task.wait();

                        if Value == 1 then
                            local v140 = tick();
                            local v141;

                            repeat
                                local Tween2 = u120.Service.Tween;
                                local v142 = (tick() - v140) / 1;
                                v141 = Tween2:GetValue(math.clamp(v142, 0, 1), Enum.EasingStyle.Cubic, Enum.EasingDirection.In);
                                u131.Transparency = v141 * 0.25 + 0.75;
                                v132.Transparency = u131.Transparency;
                                v133.Transparency = u131.Transparency;
                                u131.Size = Vector3.new(1, 1, 1) * (512 - v141 * 512);
                                v132.Size = u131.Size * 0.9;
                                v133.Size = u131.Size * 0.5;
                                task.wait();
                            until v141 == 1;

                            task.wait(4);
                            u131:Destroy();

                            return;
                        end;
                    end;
                end
            };
        end,

        run = function(p143, p144) -- Line: 1068, Name: run
            for _, v in p144 do
                if v.Character then
                    local Position = v.Character:GetPivot().Position;
                    p143.env.explode(v.Character, Position);
                    task.spawn(p143.env.nuke, p143.fromPlayer, p143.fromRank, Position);
                end;
            end;
        end
    },
    {
        name = "smite",
        description = "Smites one or more player(s).",
        credit = { "@Yuruzuu", "Kohl @Scripth" },
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) to smite.",
                shouldRequest = true
            } },

        run = function(u145, p146) -- Line: 1090, Name: run
            for _, v in p146 do
                if v.Character then
                    local v147 = v.Character:FindFirstChild("HumanoidRootPart") or v.Character.PrimaryPart;
                    local u148 = v.Character:FindFirstChildOfClass("Humanoid");

                    if u148 and v147 then
                        local u149 = v;

                        for _, descendant in v.Character:GetDescendants() do
                            if descendant:IsA("BasePart") then
                                task.delay(math.random(), function() -- Line: 1101
                                    -- upvalues: u145 (copy), descendant (copy)
                                    u145._K.Flux.new("ParticleEmitter")({
                                        LockedToPart = true,
                                        Brightness = 4,
                                        LightEmission = 1,
                                        LightInfluence = 0,
                                        Texture = "rbxassetid://11492870634",
                                        ZOffset = 2,
                                        Rate = 2,
                                        Parent = descendant,
                                        Color = ColorSequence.new(Color3.new(1, 1, 0.5)),
                                        Transparency = NumberSequence.new(0.5),
                                        Orientation = Enum.ParticleOrientation.FacingCamera,
                                        Lifetime = NumberRange.new(0.5, 0.75),
                                        Speed = NumberRange.new(0),
                                        Rotation = NumberRange.new(-360, 360),
                                        FlipbookLayout = Enum.ParticleFlipbookLayout.Grid4x4,
                                        FlipbookMode = Enum.ParticleFlipbookMode.OneShot
                                    }):Emit(1);
                                end);
                            end;
                        end;

                        u145._K.Flux.new("Sound")({
                            PlayOnRemove = true,
                            Volume = 1,
                            Parent = workspace,
                            SoundId = `rbxassetid://{({ 9116282544, 9116282647, 9116282646, 9116282791, 9116282875 })[math.random(4)]}`
                        }):Destroy();
                        local u150;

                        if u148.RigType == Enum.HumanoidRigType.R15 then
                            u150 = u148.HipHeight + v147.Size.Y / 2;
                        else
                            u150 = v147.Size.Y * 1.5;
                        end;

                        task.delay(2.2, function() -- Line: 1138
                            -- upvalues: u145 (copy), u149 (copy), u150 (copy), u148 (copy)
                            local v151 = u145._K.Flux.new("Part")({
                                Parent = workspace,
                                Transparency = 0.9,
                                Material = Enum.Material.Neon,
                                Color = Color3.new(1, 1, 1),
                                Anchored = true,
                                CanCollide = false,
                                CanQuery = false,
                                CanTouch = false,
                                CastShadow = false,
                                Size = Vector3.new(1, 1, 1),
                                CFrame = CFrame.new(u149.Character:GetPivot().Position - Vector3.new(0, u150, 0)),
                                u145._K.Flux.new("BlockMesh")({
                                    Scale = Vector3.new(2, 10000, 2),
                                    Offset = Vector3.new(0, 5000, 0)
                                })
                            });

                            for i = 1, 4 do
                                local v152 = v151:Clone();
                                v152.Mesh.Scale = Vector3.new(i + 2, 10000, i + 2);
                                v152.Parent = v151;
                                local _ = i;
                            end;

                            u148.MaxHealth = math.max(1, u148.MaxHealth);
                            u148.Health = 0;
                            task.delay(0.4, v151.Destroy, v151);
                        end);
                    end;
                end;
            end;
        end
    },
    {
        name = "confuse",
        description = "Inverts the controls of one or more player(s).",
        aliases = { "reverse", "unconfuse", "unreverse" },
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) to confuse.",
                shouldRequest = true
            } },

        envClient = function(u153) -- Line: 1184, Name: envClient
            task.spawn(function() -- Line: 1185
                -- upvalues: u153 (copy)
                local function invertControls(p154, p155, p156) -- Line: 1186
                    p154.Move(p154, -p155, p156);
                end;

                u153.Remote.Confuse:Connect(function(p157) -- Line: 1189
                    -- upvalues: u153 (ref), invertControls (copy)
                    local LocalPlayer = u153.Service.Players.LocalPlayer;
                    local PlayerScripts = LocalPlayer:WaitForChild("PlayerScripts");
                    local Controls = require(PlayerScripts:WaitForChild("PlayerModule")):GetControls();
                    local v158;

                    if p157 then
                        v158 = invertControls;
                    else
                        v158 = LocalPlayer.Move;
                    end;

                    Controls.moveFunction = v158;
                end);
            end);
        end,

        env = function(p159) -- Line: 1197, Name: env
            return {
                remote = p159.Remote.Confuse
            };
        end,

        run = function(p160, p161) -- Line: 1203, Name: run
            for _, v in p161 do
                p160.env.remote:Fire(v, not p160.undo);
            end;
        end
    },
    {
        name = "fling",
        description = "Flings one or more player(s).",
        aliases = {},
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) to fling.",
                shouldRequest = true
            }, {
                type = "number",
                name = "Strength",
                description = "The strength of the fling, 1 is default.",
                optional = true
            } },

        env = function(p162) -- Line: 1227, Name: env
            return {
                apply = function(p163, p164) -- Line: 1229, Name: apply
                    local v165 = p164 * 10;

                    if p163 and p163:FindFirstChild("HumanoidRootPart") then
                        p163:PivotTo(p163:GetPivot() * CFrame.Angles(3.141592653589793, 0, 0));
                        local LookVector = CFrame.Angles(0, math.random() * 3.141592653589793 * 2, 0).LookVector;
                        local HumanoidRootPart = p163.HumanoidRootPart;
                        local v166 = LookVector * math.random(p164 * 160, p164 * 200);
                        local math_random_ret = math.random(p164 * 160, p164 * 200);
                        HumanoidRootPart.AssemblyLinearVelocity = v166 + Vector3.new(0, math_random_ret, 0);
                        local HumanoidRootPart2 = p163.HumanoidRootPart;
                        local math_random_ret2 = math.random(-v165, v165);
                        local math_random_ret3 = math.random(-v165, v165);
                        HumanoidRootPart2.AssemblyAngularVelocity = Vector3.new(math_random_ret2, math_random_ret3, math.random(-v165, v165));
                    end;
                end
            };
        end,

        run = function(p167: any, p168: table, p169: number?) -- Line: 1248, Name: run
            for _, v in p168 do
                p167.env.apply(v.Character, p169 or 1);
            end;
        end
    },
    {
        name = "loopfling",
        description = "Flings one or more player(s) repeatedly.",
        aliases = { "unloopfling" },
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) to fling repeatedly.",
                shouldRequest = true
            }, {
                type = "number",
                name = "Strength",
                description = "The strength of the fling, 1 is default.",
                optional = true
            } },

        env = function(u170) -- Line: 1272, Name: env
            local u171 = {};
            task.spawn(function() -- Line: 1274
                -- upvalues: u171 (copy), u170 (copy)
                while true do
                    for i, v in u171 do
                        local PlayerByUserId = u170.Service.Players:GetPlayerByUserId(i);

                        if PlayerByUserId and PlayerByUserId.Character then
                            u170.Registry.commands.fling.env.apply(PlayerByUserId.Character, v);
                        end;
                    end;

                    task.wait(2);

                    if u170.Data.gameClosing then
                        return;
                    end;
                end;
            end);

            return {
                flinging = u171
            };
        end,

        run = function(p172: any, p173: table, p174: number?) -- Line: 1288, Name: run
            for _, v in p173 do
                p172.env.flinging[v.UserId] = not p172.undo and (p174 or 1) or nil;
            end;
        end
    },
    {
        name = "poison",
        description = "Damages one or more player(s) over time.",
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) to poison.",
                shouldRequest = true
            }, {
                type = "number",
                name = "Damage",
                description = "The damage to deal to their health."
            }, {
                type = "number",
                name = "Duration",
                description = "The duration of the poison effect in seconds, defaults to 8.",
                optional = true
            } },

        env = function(p175) -- Line: 1317, Name: env
            local function removeEffect(p176: userdata) -- Line: 1318
                p176.Enabled = false;
                task.wait(5);
                p176:Destroy();
            end;

            return {
                apply = function(p177: userdata, p178: number, p179: number?) -- Line: 1324, Name: apply
                    -- upvalues: removeEffect (copy)
                    local Smoke = Instance.new("Smoke");
                    Smoke.Name = "_KPoisonEffect";
                    Smoke.Color = Color3.new(0.5, 0, 1);
                    Smoke.Opacity = 0.1;
                    Smoke.RiseVelocity = 0;
                    Smoke.Parent = p177.RootPart;
                    task.delay(math.clamp(p179 or 8, 0, 999), removeEffect, Smoke);
                    local v180 = 0;

                    repeat
                        local v181 = p178 / (p179 or 8) * task.wait(0.8);
                        local math_min_ret = math.min(v181, p178 - v180);
                        v180 = v180 + math_min_ret;
                        p177:TakeDamage(math_min_ret);
                    until p178 <= v180;
                end
            };
        end,

        run = function(p182, p183, p184, p185) -- Line: 1341, Name: run
            for _, v in p183 do
                local v186 = v.Character and v.Character:FindFirstChildOfClass("Humanoid");

                if v186 then
                    task.spawn(p182.env.apply, v186, p184, p185);
                end;
            end;
        end
    },
    {
        name = "spin",
        description = "Spins one or more player(s).",
        aliases = {},
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) to spin.",
                shouldRequest = true
            }, {
                type = "number",
                name = "Speed",
                description = "The speed of the spin, 1 is default.",
                optional = true
            } },

        run = function(p187, p188, p189) -- Line: 1369, Name: run
            local Vector3_new_ret = Vector3.new(0, 30 * (p189 or 1));

            for _, v in p188 do
                if v.Character and (v.Character.PrimaryPart and v.Character.PrimaryPart:FindFirstChildOfClass("Attachment")) then
                    local _KSpin = v.Character:FindFirstChild("_KSpin");

                    if _KSpin then
                        _KSpin:Destroy();
                    end;

                    local AngularVelocity = Instance.new("AngularVelocity");
                    AngularVelocity.Name = "_KSpin";
                    AngularVelocity.Attachment0 = v.Character.PrimaryPart:FindFirstChildOfClass("Attachment");
                    AngularVelocity.AngularVelocity = Vector3_new_ret;
                    AngularVelocity.MaxTorque = (1 / 0);
                    AngularVelocity.Parent = v.Character;
                end;
            end;
        end
    },
    {
        name = "unspin",
        description = "Stops spinning one or more player(s).",
        aliases = {},
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) to stop spinning."
            } },

        run = function(p190, p191) -- Line: 1405, Name: run
            for _, v in p191 do
                if v.Character then
                    local _KSpin = v.Character:FindFirstChild("_KSpin");

                    if _KSpin then
                        _KSpin:Destroy();
                    end;
                end;
            end;
        end
    },
    {
        name = "setgravity",
        description = "Sets the gravity of one or more player(s).",
        aliases = { "setgrav", "grav", "nograv", "ungravity", "ungrav", "resetgravity", "resetgrav" },
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) whose gravity to change.",
                shouldRequest = true
            }, {
                type = "number",
                name = "Strength",
                description = "The gravity strength, default is 1.",
                optional = true
            } },

        env = function(p192) -- Line: 1434, Name: env
            return {
                resetAlias = { "ungravity", "ungrav", "resetgravity", "resetgrav" }
            };
        end,

        run = function(p193, p194, p195) -- Line: 1438, Name: run
            local v196 = p193.alias == "nograv" and -1 or (table.find(p193.env.resetAlias, p193.alias) and 1 or (p195 or 1));

            for _, v in p194 do
                if v.Character and (v.Character.PrimaryPart and v.Character.PrimaryPart:FindFirstChildOfClass("Attachment")) then
                    local _KGravityForce = v.Character:FindFirstChild("_KGravityForce");

                    if _KGravityForce then
                        _KGravityForce:Destroy();
                    end;

                    if v196 ~= 1 then
                        local VectorForce = Instance.new("VectorForce");
                        VectorForce.Name = "_KGravityForce";
                        VectorForce.ApplyAtCenterOfMass = true;
                        VectorForce.Attachment0 = v.Character.PrimaryPart:FindFirstChildOfClass("Attachment");
                        VectorForce.RelativeTo = Enum.ActuatorRelativeTo.World;
                        VectorForce.Force = Vector3.new(0, v.Character.PrimaryPart.AssemblyMass * -v196 * workspace.Gravity);
                        VectorForce.Parent = v.Character;
                    end;
                end;
            end;
        end
    },
    {
        name = "skydive",
        description = "Sends one or more player(s) into the sky.",
        aliases = { "freefall" },
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) to send into the sky.",
                shouldRequest = true
            }, {
                type = "number",
                name = "Distance",
                description = "The distance, in studs, that players are sent into the sky.",
                optional = true
            } },

        run = function(p197, p198, p199) -- Line: 1490, Name: run
            for _, v in p198 do
                if v.Character then
                    v.Character:TranslateBy((Vector3.new(0, p199 or 8000, 0)));
                end;
            end;
        end
    },
    {
        name = "trip",
        description = "Trips one or more player(s).",
        aliases = {},
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) to trip.",
                shouldRequest = true
            } },

        envClient = function(u200) -- Line: 1510, Name: envClient
            u200.Remote.Trip:Connect(function() -- Line: 1511
                -- upvalues: u200 (copy)
                local Character = u200.LocalPlayer.Character;
                local v201;

                if Character then
                    v201 = Character:FindFirstChildOfClass("Humanoid");
                else
                    v201 = Character;
                end;

                if v201 then
                    v201:ChangeState(Enum.HumanoidStateType.FallingDown);
                    local LookVector = CFrame.Angles(0, math.random() * 3.141592653589793 * 2, 0).LookVector;
                    Character.PrimaryPart.AssemblyAngularVelocity = LookVector * 8;
                end;
            end);

            return true;
        end,

        env = function(p202) -- Line: 1523, Name: env
            return {
                remote = p202.Remote.Trip
            };
        end,

        run = function(p203, p204) -- Line: 1529, Name: run
            for _, v in p204 do
                p203.env.remote:Fire(v);
            end;
        end
    },
    {
        name = "rocket",
        description = "Attaches a rocket to one or more player(s).",
        aliases = { "🚀" },
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) to attach a rocket to.",
                shouldRequest = true
            } },

        run = function(p205, p206, p207) -- Line: 1548, Name: run
            for _, v in p206 do
                if v.Character and (v.Character.PrimaryPart and (v.Character:FindFirstChildOfClass("Humanoid") and not v.Character:FindFirstChild("_KRocket"))) then
                    v.Character:FindFirstChildOfClass("Humanoid").Jump = true;
                    local Attachment = Instance.new("Attachment");
                    Attachment.Position = Vector3.new(0, -3, 0);
                    p205._K.Flux.new("Fire")({
                        Size = 2,
                        Parent = Attachment
                    });
                    local u208 = p205._K.Flux.new("Part")({
                        Parent = v.Character,
                        Name = "_KRocket",
                        Size = Vector3.new(1, 6, 1),
                        Anchored = false,
                        CanCollide = false,
                        Massless = true,
                        TopSurface = 0,
                        BottomSurface = 0,
                        Material = Enum.Material.Metal,
                        Attachment,
                        p205._K.Flux.new("VectorForce")({
                            ApplyAtCenterOfMass = true,
                            RelativeTo = Enum.ActuatorRelativeTo.World,
                            Force = Vector3.new(0, v.Character.PrimaryPart.AssemblyMass * workspace.Gravity + 800),
                            Attachment0 = Attachment
                        })
                    });
                    p205._K.Flux.new("Weld")({
                        Parent = u208,
                        Part0 = u208,
                        Part1 = v.Character.PrimaryPart,
                        C1 = CFrame.new(0, 0, 1)
                    });
                    task.delay(5, function() -- Line: 1596
                        -- upvalues: v (copy), u208 (copy)
                        if v.Character then
                            v.Character:BreakJoints();
                            u208:Destroy();
                            local Explosion = Instance.new("Explosion");
                            Explosion.ExplosionType = Enum.ExplosionType.NoCraters;
                            Explosion.Position = u208.Position;
                            Explosion.DestroyJointRadiusPercent = 0;
                            Explosion.Parent = v.Character;
                        end;
                    end);
                end;
            end;
        end
    },
    {
        name = "size",
        description = "Resizes one or more player(s).",
        aliases = { "resize", "scale", "unsize", "unresize", "unscale" },
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) to resize.",
                shouldRequest = true
            }, {
                type = "number",
                name = "Scale",
                description = "The scale of the character, 1 is default.",
                optional = true
            } },

        run = function(p209, p210, p211) -- Line: 1631, Name: run
            for _, v in p210 do
                v.Character:ScaleTo(math.clamp(p211, 0.01, 50) or 1);
            end;
        end
    },
    {
        name = "slim",
        description = "Makes one or more player(s) slim.",
        aliases = { "unslim" },
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) to make slim.",
                shouldRequest = true
            } },

        env = function(p212) -- Line: 1649, Name: env
            return {
                slim = function(p213, p214, p215) -- Line: 1651, Name: slim
                    local Attribute = p213:GetAttribute("_KSlimOriginal");

                    if p215 or not Attribute then
                        local v216;

                        if p215 then
                            v216 = nil;
                        else
                            v216 = p213[p214].Z;
                        end;

                        p213:SetAttribute("_KSlimOriginal", v216);
                    end;

                    local v217 = p213[p214];
                    p213[p214] = Vector3.new(v217.X, v217.Y, not p215 and 0.2 or (Attribute or v217));
                end
            };
        end,

        run = function(p218, p219) -- Line: 1662, Name: run
            for _, v in p219 do
                local Character = v.Character;
                local v220;

                if Character then
                    v220 = Character:FindFirstChildOfClass("Humanoid");
                else
                    v220 = Character;
                end;

                if v220 and (not p218.undo or v220:GetAttribute("_KSlim")) then
                    v220:SetAttribute("_KSlim", not p218.undo);

                    for _, child in Character:GetChildren() do
                        if child:IsA("BasePart") then
                            p218.env.slim(child, "Size", p218.undo);
                        elseif child:IsA("Accessory") then
                            local v221 = child:FindFirstChildWhichIsA("BasePart");

                            if v221 then
                                p218.env.slim(v221, "Size", p218.undo);
                                local v222 = v221:FindFirstChildOfClass("SpecialMesh");

                                if v222 then
                                    p218.env.slim(v222, "Scale", p218.undo);
                                end;
                            end;
                        end;
                    end;
                end;
            end;
        end
    },
    {
        name = "noobify",
        description = "Turn one or more player(s) into a noob",
        aliases = { "noob" },
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) to transform into a noob.",
                shouldRequest = true
            } },

        env = function(p223) -- Line: 1699, Name: env
            local Color = BrickColor.new("Bright blue").Color;
            local Color2 = BrickColor.new("Br. yellowish green").Color;
            local Color4 = BrickColor.new("Bright yellow").Color;

            return {
                properties = {
                    Pants = 0,
                    Shirt = 0,
                    GraphicTShirt = 0,
                    LeftArm = 0,
                    RightArm = 0,
                    LeftLeg = 0,
                    RightLeg = 0,
                    Torso = 0,
                    HeadColor = Color4,
                    LeftArmColor = Color4,
                    RightArmColor = Color4,
                    LeftLegColor = Color2,
                    RightLegColor = Color2,
                    TorsoColor = Color
                },
                accessoryColors = {
                    [Enum.AccessoryType.Hat] = Color4,
                    [Enum.AccessoryType.Hair] = Color4,
                    [Enum.AccessoryType.Face] = Color,
                    [Enum.AccessoryType.Neck] = Color,
                    [Enum.AccessoryType.Shoulder] = Color,
                    [Enum.AccessoryType.Front] = Color,
                    [Enum.AccessoryType.Back] = Color,
                    [Enum.AccessoryType.Waist] = Color,
                    [Enum.AccessoryType.TShirt] = Color,
                    [Enum.AccessoryType.Shirt] = Color,
                    [Enum.AccessoryType.Pants] = Color2,
                    [Enum.AccessoryType.Jacket] = Color,
                    [Enum.AccessoryType.Sweater] = Color,
                    [Enum.AccessoryType.Shorts] = Color2,
                    [Enum.AccessoryType.LeftShoe] = Color2,
                    [Enum.AccessoryType.RightShoe] = Color2,
                    [Enum.AccessoryType.DressSkirt] = Color
                },
                fallback = Color4,

                getDescription = function(p224: userdata, p225: userdata) -- Line: 1741, Name: getDescription
                    local _KHumanoidDescription = p224:FindFirstChild("_KHumanoidDescription");

                    if _KHumanoidDescription then
                        if _KHumanoidDescription:GetAttribute("_KNoob") then
                            return _KHumanoidDescription;
                        end;

                        _KHumanoidDescription:Destroy();
                    end;

                    local AppliedDescription = p225:GetAppliedDescription();
                    AppliedDescription.Name = "_KHumanoidDescription";
                    AppliedDescription:SetAttribute("_KNoob", true);
                    AppliedDescription.Parent = p224;

                    return AppliedDescription;
                end
            };
        end,

        run = function(p226, p227) -- Line: 1757, Name: run
            local crm = p226._K.Registry.commands.crm;

            if not crm then
                return;
            end;

            for _, v in p227 do
                local u228 = v.Character and v.Character:FindFirstChildOfClass("Humanoid");

                if u228 then
                    local u229 = p226.env.getDescription(v, u228):Clone();

                    for i, v2 in p226.env.properties do
                        u229[i] = v2;
                    end;

                    task.defer(function() -- Line: 1771
                        -- upvalues: u228 (copy), u229 (copy)
                        u228:ApplyDescription(u229, Enum.AssetTypeVerification.Always);
                        u229:Destroy();
                    end);

                    for _, child in v.Character:GetChildren() do
                        if child:IsA("Accessory") then
                            local v230 = child;

                            for _, descendant in child:GetDescendants() do
                                if descendant:IsA("BasePart") then
                                    crm.env.updatePart(descendant, p226.env.accessoryColors[v230.AccessoryType] or p226.env.fallback, 0, Enum.Material.Plastic);
                                elseif descendant:IsA("SurfaceAppearance") and not descendant:FindFirstChild("_KParent") then
                                    local ObjectValue = Instance.new("ObjectValue");
                                    ObjectValue.Name = "_KParent";
                                    ObjectValue.Value = descendant.Parent;
                                    ObjectValue.Parent = descendant;
                                    descendant.Parent = u228;
                                end;
                            end;
                        end;
                    end;
                end;
            end;
        end
    },
    {
        name = "slippery",
        description = "Makes one or more player(s) slide when they walk",
        aliases = { "iceskate", "icewalk", "slide" },
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) to make slippery.",
                shouldRequest = true
            } },

        envClient = function(p231) -- Line: 1813, Name: envClient
            local u232 = nil;
            p231.Remote.Slippery:Connect(function(u233: userdata?) -- Line: 1815
                -- upvalues: u232 (ref)
                if typeof(u232) == "thread" and coroutine.status(u232) == "suspended" then
                    task.cancel(u232);
                    u232 = nil;
                end;

                if u233 then
                    u232 = task.spawn(function() -- Line: 1821
                        -- upvalues: u233 (copy)
                        while u233 and u233.Parent do
                            local AssemblyLinearVelocity = u233.Parent.AssemblyLinearVelocity;
                            u233.Velocity = Vector3.new(AssemblyLinearVelocity.X, 0, AssemblyLinearVelocity.Z);
                            task.wait(0.1);
                        end;
                    end);
                end;
            end);
        end,

        env = function(p234) -- Line: 1831, Name: env
            return {
                remote = p234.Remote.Slippery
            };
        end,

        run = function(p235, p236) -- Line: 1836, Name: run
            for _, v in p236 do
                local v237 = v.Character and v.Character:FindFirstChild("HumanoidRootPart");

                if v237 then
                    local _K_Slippery = v237:FindFirstChild("_K_Slippery");

                    if _K_Slippery then
                        _K_Slippery:Destroy();
                    end;

                    if not p235.undo then
                        p235.env.remote:Fire(v, p235._K.Flux.new("BodyVelocity")({
                            Name = "_K_Slippery",
                            MaxForce = Vector3.new(5000, 0, 5000),
                            Parent = v237
                        }));
                    end;
                end;
            end;
        end
    }
};