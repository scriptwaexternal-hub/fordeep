-- Decompiled with Potassium's decompiler.

game:GetService("TweenService");
local RunService = game:GetService("RunService");
local LocalPlayer = game:GetService("Players").LocalPlayer;
local Color3_fromRGB_ret = Color3.fromRGB(44, 44, 45);
local Color3_fromRGB_ret2 = Color3.fromRGB(28, 28, 30);
local Color3_fromRGB_ret3 = Color3.fromRGB(255, 255, 255);
local Color3_fromRGB_ret4 = Color3.fromRGB(216, 213, 205);
local Color3_fromRGB_ret5 = Color3.fromRGB(0, 0, 0);
local Color3_fromRGB_ret6 = Color3.fromRGB(255, 196, 68);
local Color3_fromRGB_ret7 = Color3.fromRGB(140, 138, 132);
local Color3_fromRGB_ret8 = Color3.fromRGB(120, 235, 120);
local Arcade = Enum.Font.Arcade;
local Bangers = Enum.Font.Bangers;
local u1 = nil;
local u2 = nil;
local u3 = nil;
local u4 = nil;
local u5 = nil;
local u6 = nil;
local u7 = nil;
local u8 = nil;
local u9 = 0;
local u10 = 1;

local function stroke(p11, p12) -- Line: 38
    -- upvalues: Color3_fromRGB_ret5 (copy)
    local UIStroke = Instance.new("UIStroke");
    UIStroke.Color = Color3_fromRGB_ret5;
    UIStroke.Thickness = p12 or 2;
    UIStroke.ApplyStrokeMode = Enum.ApplyStrokeMode.Border;
    UIStroke.Parent = p11;

    return UIStroke;
end;

local function ensureGui() -- Line: 47
    -- upvalues: u1 (ref), LocalPlayer (copy), u2 (ref), Color3_fromRGB_ret (copy), Color3_fromRGB_ret5 (copy), Color3_fromRGB_ret2 (copy), u3 (ref), Arcade (copy), Color3_fromRGB_ret6 (copy), u4 (ref), Bangers (copy), Color3_fromRGB_ret3 (copy), u7 (ref), Color3_fromRGB_ret7 (copy), u5 (ref), u6 (ref)
    if u1 and u1.Parent then
        return;
    end;

    u1 = Instance.new("ScreenGui");
    u1.Name = "DragonballHoldGui";
    u1.ResetOnSpawn = false;
    u1.DisplayOrder = 45;
    u1.Parent = LocalPlayer:WaitForChild("PlayerGui");
    u2 = Instance.new("Frame");
    u2.Name = "Card";
    u2.AnchorPoint = Vector2.new(1, 0.5);
    u2.Position = UDim2.new(1, -18, 0.42, 0);
    u2.Size = UDim2.fromOffset(210, 84);
    u2.BackgroundColor3 = Color3_fromRGB_ret;
    u2.BorderSizePixel = 0;
    u2.Visible = false;
    u2.Parent = u1;
    local UIStroke = Instance.new("UIStroke");
    UIStroke.Color = Color3_fromRGB_ret5;
    UIStroke.Thickness = 3;
    UIStroke.ApplyStrokeMode = Enum.ApplyStrokeMode.Border;
    UIStroke.Parent = u2;
    local Frame = Instance.new("Frame");
    Frame.Name = "Header";
    Frame.Size = UDim2.new(1, 0, 0, 22);
    Frame.BackgroundColor3 = Color3_fromRGB_ret2;
    Frame.BorderSizePixel = 0;
    Frame.Parent = u2;
    u3 = Instance.new("TextLabel");
    u3.Name = "Title";
    u3.BackgroundTransparency = 1;
    u3.Size = UDim2.new(1, -12, 1, 0);
    u3.Position = UDim2.fromOffset(6, 0);
    u3.Font = Arcade;
    u3.TextSize = 12;
    u3.TextColor3 = Color3_fromRGB_ret6;
    u3.TextXAlignment = Enum.TextXAlignment.Left;
    u3.Text = "DRAGON BALL";
    u3.Parent = Frame;
    u4 = Instance.new("TextLabel");
    u4.Name = "Clock";
    u4.BackgroundTransparency = 1;
    u4.Position = UDim2.fromOffset(8, 24);
    u4.Size = UDim2.new(1, -16, 0, 34);
    u4.Font = Bangers;
    u4.TextSize = 32;
    u4.TextColor3 = Color3_fromRGB_ret3;
    u4.TextStrokeColor3 = Color3_fromRGB_ret5;
    u4.TextStrokeTransparency = 0;
    u4.TextXAlignment = Enum.TextXAlignment.Left;
    u4.Text = "5:00";
    u4.Parent = u2;
    u7 = Instance.new("TextLabel");
    u7.Name = "Hint";
    u7.BackgroundTransparency = 1;
    u7.AnchorPoint = Vector2.new(1, 0);
    u7.Position = UDim2.new(1, -8, 0, 30);
    u7.Size = UDim2.new(0.6, 0, 0, 24);
    u7.Font = Arcade;
    u7.TextSize = 10;
    u7.TextColor3 = Color3_fromRGB_ret7;
    u7.TextXAlignment = Enum.TextXAlignment.Right;
    u7.TextWrapped = true;
    u7.Text = "HOLD TO CLAIM\nDROP = RESET";
    u7.Parent = u2;
    u5 = Instance.new("Frame");
    u5.Name = "Bar";
    u5.Position = UDim2.new(0, 8, 1, -14);
    u5.Size = UDim2.new(1, -16, 0, 6);
    u5.BackgroundColor3 = Color3_fromRGB_ret2;
    u5.BorderSizePixel = 0;
    u5.Parent = u2;
    local UIStroke2 = Instance.new("UIStroke");
    UIStroke2.Color = Color3_fromRGB_ret5;
    UIStroke2.Thickness = 1;
    UIStroke2.ApplyStrokeMode = Enum.ApplyStrokeMode.Border;
    UIStroke2.Parent = u5;
    u6 = Instance.new("Frame");
    u6.Name = "Fill";
    u6.Size = UDim2.new(0, 0, 1, 0);
    u6.BackgroundColor3 = Color3_fromRGB_ret6;
    u6.BorderSizePixel = 0;
    u6.Parent = u5;
end;

local function fmt(p13) -- Line: 131
    local math_ceil_ret = math.ceil(p13);
    local math_max_ret = math.max(0, math_ceil_ret);

    return ("%d:%02d"):format(math_max_ret // 60, math_max_ret % 60);
end;

local function stopStep() -- Line: 136
    -- upvalues: u8 (ref)
    if u8 then
        u8:Disconnect();
        u8 = nil;
    end;
end;

local function hide() -- Line: 140
    -- upvalues: u8 (ref), u2 (ref)
    if u8 then
        u8:Disconnect();
        u8 = nil;
    end;

    if u2 then
        u2.Visible = false;
    end;
end;

return {
    Start = function(p14) -- Line: 147, Name: Start
        -- upvalues: ensureGui (copy), u10 (ref), u9 (ref), u3 (ref), u4 (ref), Color3_fromRGB_ret3 (copy), u7 (ref), Color3_fromRGB_ret7 (copy), u6 (ref), Color3_fromRGB_ret6 (copy), u2 (ref), u8 (ref), RunService (copy)
        ensureGui();
        local v15 = tonumber(p14.Duration) or 300;
        u10 = math.max(1, v15);
        u9 = os.clock() + u10;
        u3.Text = string.upper((tostring(p14.Ball or "DRAGON BALL")));
        u4.TextColor3 = Color3_fromRGB_ret3;
        u7.Text = "HOLD TO CLAIM\nDROP = RESET";
        u7.TextColor3 = Color3_fromRGB_ret7;
        u6.BackgroundColor3 = Color3_fromRGB_ret6;
        u6.Size = UDim2.new(0, 0, 1, 0);
        u2.Visible = true;

        if u8 then
            u8:Disconnect();
            u8 = nil;
        end;

        u8 = RunService.Heartbeat:Connect(function() -- Line: 160
            -- upvalues: u9 (ref), u4 (ref), u6 (ref), u10 (ref), Color3_fromRGB_ret6 (ref)
            local v16 = u9 - os.clock();
            local math_ceil_ret = math.ceil(v16);
            local math_max_ret = math.max(0, math_ceil_ret);
            u4.Text = ("%d:%02d"):format(math_max_ret // 60, math_max_ret % 60);
            u6.Size = UDim2.new(math.clamp(1 - v16 / u10, 0, 1), 0, 1, 0);

            if v16 <= 10 then
                u4.TextColor3 = Color3_fromRGB_ret6;
            end;
        end);
    end,

    Stop = function(p17) -- Line: 168, Name: Stop
        -- upvalues: u8 (ref), u2 (ref)
        if u8 then
            u8:Disconnect();
            u8 = nil;
        end;

        if u2 then
            u2.Visible = false;
        end;
    end,

    Claimed = function(p18) -- Line: 172, Name: Claimed
        -- upvalues: ensureGui (copy), u8 (ref), u4 (ref), Color3_fromRGB_ret8 (copy), u7 (ref), Color3_fromRGB_ret4 (copy), u6 (ref), u2 (ref)
        ensureGui();

        if u8 then
            u8:Disconnect();
            u8 = nil;
        end;

        u4.Text = "CLAIMED";
        u4.TextColor3 = Color3_fromRGB_ret8;
        u7.Text = "ADDED TO\nINVENTORY";
        u7.TextColor3 = Color3_fromRGB_ret4;
        u6.BackgroundColor3 = Color3_fromRGB_ret8;
        u6.Size = UDim2.new(1, 0, 1, 0);
        u2.Visible = true;
        task.delay(1.6, function() -- Line: 182
            -- upvalues: u4 (ref), u2 (ref)
            if u4.Text == "CLAIMED" then
                u2.Visible = false;
            end;
        end);
    end
};