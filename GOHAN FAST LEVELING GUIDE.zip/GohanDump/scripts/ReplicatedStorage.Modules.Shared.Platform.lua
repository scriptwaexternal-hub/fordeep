-- Decompiled with Potassium's decompiler.

local UserInputService = game:GetService("UserInputService");
local GuiService = game:GetService("GuiService");
local u1 = {
    [Enum.UserInputType.Gamepad1] = true,
    [Enum.UserInputType.Gamepad2] = true,
    [Enum.UserInputType.Gamepad3] = true,
    [Enum.UserInputType.Gamepad4] = true
};
local u2 = {
    IsConsole = function() -- Line: 53, Name: IsConsole
        -- upvalues: GuiService (copy), UserInputService (copy)
        if GuiService:IsTenFootInterface() then
            return true;
        end;

        return UserInputService.GamepadEnabled and not UserInputService.MouseEnabled and not UserInputService.TouchEnabled;
    end
};

function u2.HasKeyboard() -- Line: 60
    -- upvalues: UserInputService (copy), u2 (copy)
    local v3 = UserInputService.KeyboardEnabled and not u2.IsConsole();

    return v3;
end;

function u2.HasGamepad() -- Line: 64
    -- upvalues: UserInputService (copy)
    return UserInputService.GamepadEnabled;
end;

function u2.ActiveGamepad() -- Line: 76
    -- upvalues: UserInputService (copy)
    local ConnectedGamepads = UserInputService:GetConnectedGamepads();

    if #ConnectedGamepads == 0 then
        return nil;
    end;

    table.sort(ConnectedGamepads, function(p4, p5) -- Line: 79
        return p4.Value < p5.Value;
    end);

    return ConnectedGamepads[1];
end;

function u2.IsGamepadInput(p6) -- Line: 84
    -- upvalues: u1 (copy)
    return u1[p6] == true;
end;

function u2.IsButtonDown(p7) -- Line: 89
    -- upvalues: u2 (copy), UserInputService (copy)
    local v8 = u2.ActiveGamepad();
    local v9;

    if v8 == nil then
        v9 = false;
    else
        v9 = UserInputService:IsGamepadButtonDown(v8, p7);
    end;

    return v9;
end;

function u2.IsTouch() -- Line: 95
    -- upvalues: UserInputService (copy), u2 (copy)
    local v10 = UserInputService.TouchEnabled and not u2.HasKeyboard() and not u2.IsConsole();

    return v10;
end;

function u2.Get() -- Line: 106
    -- upvalues: u2 (copy)
    return u2.IsConsole() and "Console" or (u2.IsTouch() and "Touch" or "Keyboard");
end;

function u2.PreferGamepadGlyphs() -- Line: 119
    -- upvalues: u2 (copy), UserInputService (copy)
    if u2.IsConsole() then
        return true;
    end;

    if not UserInputService.GamepadEnabled then
        return false;
    end;

    local LastInputType = UserInputService:GetLastInputType();

    return (LastInputType == Enum.UserInputType.Gamepad1 or (LastInputType == Enum.UserInputType.Gamepad2 or LastInputType == Enum.UserInputType.Gamepad3)) and true or LastInputType == Enum.UserInputType.Gamepad4;
end;

local function isRealMenuSelection() -- Line: 166
    -- upvalues: GuiService (copy)
    local SelectedObject = GuiService.SelectedObject;

    if SelectedObject then
        return SelectedObject:GetAttribute("CorrespondingIconUID") == nil;
    end;

    return false;
end;

function u2.InputBlocked(p11, p12) -- Line: 173
    -- upvalues: u1 (copy), GuiService (copy)
    if not p12 then
        return false;
    end;

    if not (p11 and (u1[p11.UserInputType] and p11.KeyCode == Enum.KeyCode.ButtonA)) then
        return true;
    end;

    local SelectedObject = GuiService.SelectedObject;

    if SelectedObject then
        return SelectedObject:GetAttribute("CorrespondingIconUID") == nil;
    end;

    return false;
end;

return u2;