-- Decompiled with Potassium's decompiler.

local Debris = game:GetService("Debris");
local ReplicatedStorage = game:GetService("ReplicatedStorage");
local Assets = ReplicatedStorage.Assets;
local Modules = ReplicatedStorage:WaitForChild("Modules");
local Gui = Assets.Gui;
local SoundManager = require(Modules.Shared.SoundManager);
local GlobalFunctions = require(Modules.GlobalFunctions);
local VfxHandler = require(Modules.Effects.VfxHandler);
local workspace_World = workspace.World;
local Visuals = workspace_World.Visuals;
local Effects = Assets.Effects;
local Meshes = Effects.Meshes;
local Particles = Effects.Particles;

return {
    Explosion = function(p1) -- Line: 34
        -- upvalues: Meshes (copy), workspace_World (copy), Debris (copy), GlobalFunctions (copy), SoundManager (copy), VfxHandler (copy)
        local Location = p1.Location;

        if not Location then
            return;
        end;

        local Instance2 = p1.Instance;
        local v2 = p1.Size or 40;
        local v3 = p1.Color or Color3.fromRGB(255, 255, 255);
        local u4 = Meshes.Skills.Explosion:Clone();
        u4.Parent = workspace_World.Visuals;
        u4.CFrame = Location;
        u4.Size = Vector3.new(0, 0, 0);
        u4.Color = v3;
        u4.CanCollide = false;
        Debris:AddItem(u4, 2.5);
        local v5 = Meshes["Blast Effect"].BlastEffect:Clone();
        v5.Parent = u4;
        v5.PFX:Emit(10);
        GlobalFunctions.Tween({
            Duration = 0.5,
            Instance = u4,
            EasingStyle = Enum.EasingStyle.Exponential
        }, {
            Size = Vector3.new(1, 1, 1) * (v2 >= 500 and 500 or v2)
        }).Completed:Once(function() -- Line: 75
            -- upvalues: GlobalFunctions (ref), u4 (copy)
            GlobalFunctions.TransparencyTween({
                Duration = 0.35,
                Instance = u4
            });
        end);
        SoundManager.AddSound("Explosion (DBZ)", {
            Parent = u4
        }, "Client");

        if Instance2 then
            VfxHandler.BlockDebris.Execute({
                Location = Location,
                Material = Instance2.Material,
                Color = Instance2.Color,
                Transparency = Instance2.Transparency
            });
        end;
    end,

    Splatter = function(p6) -- Line: 92
        -- upvalues: Visuals (copy), Debris (copy), Particles (copy), SoundManager (copy)
        local Location = p6.Location;

        if not Location then
            return;
        end;

        local Part = Instance.new("Part");
        Part.Size = Vector3.new(1, 1, 1);
        Part.Parent = Visuals;
        Part.Transparency = 1;
        Part.CanCollide = false;
        Part.Material = Enum.Material.Neon;
        Part.CFrame = Location;
        Part.Anchored = true;
        Debris:AddItem(Part, 3);
        local v7 = Particles.Sparks:Clone();
        v7.Parent = Part;
        v7:Emit(10);
        v7.Color = ColorSequence.new({ ColorSequenceKeypoint.new(0, Color3.fromRGB(255, 255, 255)), ColorSequenceKeypoint.new(1, Color3.fromRGB(255, 255, 255)) });
        Debris:AddItem(v7, 2);
        SoundManager.AddSound("Splatter", {
            Parent = Part
        }, "Client");
    end,

    ["Ki Explosion"] = function(p8) -- Line: 117
        -- upvalues: Meshes (copy), Visuals (copy), Debris (copy), SoundManager (copy), GlobalFunctions (copy)
        local Location = p8.Location;
        local v9 = p8.Color or Color3.fromRGB(255, 255, 255);
        local math_min_ret = math.min(p8.Size or 40, 150);
        math.random(1, 360);
        math.random(1, 360);
        math.random(1, 360);
        local v10 = Meshes.Skills["Ki Explosion 2"]:Clone();
        v10.Parent = Visuals;
        v10.CFrame = CFrame.new(Location.Position);
        Debris:AddItem(v10, 4);
        SoundManager.AddSound("Explosion (DBZ)", {
            Parent = v10
        }, "Client");

        local function multNumberSequence(p11, p12) -- Line: 139
            local v13 = {};

            for i = 1, #p11.Keypoints do
                local v14 = p11.Keypoints[i];
                table.insert(v13, NumberSequenceKeypoint.new(v14.Time, v14.Value * p12));
                local _ = i;
            end;

            return NumberSequence.new(v13);
        end;

        local function Fix_Particles(p15, p16) -- Line: 148
            -- upvalues: multNumberSequence (copy)
            p15.Size = multNumberSequence(p15.Size, 0.1 * p16 / 3);
        end;

        for _, child in pairs(v10.Explosion:GetChildren()) do
            child.Color = ColorSequence.new({ ColorSequenceKeypoint.new(0, v9), ColorSequenceKeypoint.new(1, v9) });
            child.Size = multNumberSequence(child.Size, 0.1 * math_min_ret / 3);
            child:Emit((math.random(5, 10)));
        end;

        if p8.NoSphere then
            return;
        end;

        local u17 = Meshes.Skills.Explosion:Clone();
        u17.CFrame = CFrame.new(Location.Position);
        u17.Size = Vector3.new(0, 0, 0);
        u17.Color = v9;
        u17.CanCollide = false;
        u17.Anchored = true;
        u17.Parent = Visuals;
        Debris:AddItem(u17, 4);
        GlobalFunctions.Tween({
            Duration = 0.5,
            Instance = u17,
            EasingStyle = Enum.EasingStyle.Exponential
        }, {
            Size = Vector3.new(1, 1, 1) * math_min_ret
        }).Completed:Once(function() -- Line: 203
            -- upvalues: u17 (copy), GlobalFunctions (ref)
            if not u17.Parent then
                return;
            end;

            GlobalFunctions.TransparencyTween({
                Duration = 1,
                Instance = u17
            });
        end);
    end,

    ["New Explosion"] = function(p18) -- Line: 208
        -- upvalues: Meshes (copy), workspace_World (copy), Debris (copy), SoundManager (copy), GlobalFunctions (copy), VfxHandler (copy)
        local Location = p18.Location;

        if not Location then
            return;
        end;

        local Instance2 = p18.Instance;
        local math_min_ret = math.min(p18.Size or 85, 250);
        local u19 = math_min_ret * 0.7;
        local v20 = p18.Color or Color3.fromRGB(255, 255, 255);
        local u21 = Meshes.Skills:FindFirstChild("New Explosion"):Clone();
        u21.Parent = workspace_World.Visuals;
        u21.CFrame = Location;
        u21.Size = Vector3.new(0, 0, 0);
        u21.Color = v20;
        Debris:AddItem(u21, 4.5);
        SoundManager.AddSound("Explosion (DBZ)", {
            Parent = u21
        }, "Client");
        local v22 = Meshes["Blast Effect"].BlastEffect:Clone();
        v22.Parent = u21;
        v22.PFX:Emit(10);
        GlobalFunctions.Tween({
            Duration = 0.1,
            Instance = u21
        }, {
            Size = Vector3.new(1, 1, 1) * math_min_ret
        }).Completed:Once(function() -- Line: 249
            -- upvalues: u21 (copy), u19 (copy), GlobalFunctions (ref)
            for _, descendant in pairs(u21:GetDescendants()) do
                if descendant:IsA("ParticleEmitter") then
                    descendant.Enabled = true;

                    if descendant.Parent.Name == "Sphere" then
                        descendant.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, u19), NumberSequenceKeypoint.new(0.5, u19), NumberSequenceKeypoint.new(1, u19) });
                    end;

                    if descendant.Name == "Sphere1" then
                        descendant.ZOffset = u19 - 2;
                    end;
                end;
            end;

            task.delay(2, function() -- Line: 269
                -- upvalues: u21 (ref), GlobalFunctions (ref)
                for _, descendant in pairs(u21:GetDescendants()) do
                    if descendant:IsA("ParticleEmitter") then
                        descendant.Enabled = false;
                    end;
                end;

                GlobalFunctions.TransparencyTween({
                    Duration = 1,
                    Instance = u21
                });
            end);
        end);

        if Instance2 then
            VfxHandler.BlockDebris.Execute({
                Location = Location,
                Material = Instance2.Material,
                Color = Instance2.Color,
                Transparency = Instance2.Transparency
            });
        end;
    end,

    TargetZone = function(p23) -- Line: 296
        -- upvalues: GlobalFunctions (copy), Effects (copy), Visuals (copy)
        local Location = p23.Location;

        if not Location then
            return;
        end;

        local v24 = p23.Size or 40;
        local v25 = GlobalFunctions.CastRay(Location.Position, Vector3.new(0, -10, 0));

        if not v25 then
            warn("No Ground Found.");

            return;
        end;

        local u26 = Effects.Meshes:FindFirstChild("Target Zone", true):Clone();
        u26.Parent = Visuals;
        u26.Size = Vector3.new(0, 0, 0);
        u26.CFrame = CFrame.new(v25.Position);
        u26.CanCollide = false;
        local v27 = {
            Instance = u26,
            EasingStyle = Enum.EasingStyle.Exponential
        };
        local v28 = {
            Transparency = 0.1,
            Size = Vector3.new(v24, 0.05, v24)
        };
        GlobalFunctions.Tween(v27, v28).Completed:Once(function() -- Line: 323
            -- upvalues: u26 (copy)
            u26:Destroy();
        end);
    end,

    Portal = function(p29) -- Line: 333
        -- upvalues: Effects (copy), Visuals (copy), GlobalFunctions (copy)
        local Location = p29.Location;

        if not Location then
            return;
        end;

        local u30 = p29.Duration or 1;
        local v31 = p29.Size or 40;
        local u32 = Effects.Meshes:FindFirstChild("Target Zone", true):Clone();
        u32.Parent = Visuals;
        u32.Size = Vector3.new(0, 0, 0);
        u32.CFrame = CFrame.new(Location);
        u32.CanCollide = false;
        local v33 = {
            Instance = u32,
            EasingStyle = Enum.EasingStyle.Exponential
        };
        local v34 = {
            Transparency = 0.1,
            Size = Vector3.new(v31, 0.05, v31)
        };
        GlobalFunctions.Tween(v33, v34).Completed:Once(function() -- Line: 356
            -- upvalues: u30 (copy), u32 (copy), GlobalFunctions (ref)
            task.wait(u30);
            GlobalFunctions.Tween({
                Instance = u32,
                EasingStyle = Enum.EasingStyle.Exponential
            }, {
                Size = Vector3.new(0, 0, 0)
            }).Completed:Once(function() -- Line: 368
                -- upvalues: u32 (ref)
                u32:Destroy();
            end);
        end);
    end,

    Aura = function(p35) -- Line: 374
        -- upvalues: SoundManager (copy), Particles (copy), Debris (copy)
        local Character = p35.Character;

        if not Character then
            return;
        end;

        local HumanoidRootPart = Character:FindFirstChild("HumanoidRootPart");
        local v36 = p35.Color or Color3.fromRGB(253, 255, 129);
        local v37 = p35.Duration or 1;

        if HumanoidRootPart then
            SoundManager.AddSound("Aura Burst", {
                Parent = HumanoidRootPart
            }, "Client");
        end;

        for _, child in pairs(Character:GetChildren()) do
            if child:IsA("Part") or child:IsA("MeshPart") then
                local u38 = Particles:FindFirstChild("Default Aura", true).Aura:Clone();
                u38.Parent = child;
                u38.Enabled = true;
                u38.Color = ColorSequence.new({ ColorSequenceKeypoint.new(0, v36), ColorSequenceKeypoint.new(0.5, v36), ColorSequenceKeypoint.new(1, v36) });
                task.delay(v37, function() -- Line: 397
                    -- upvalues: u38 (copy), Debris (ref)
                    u38.Enabled = false;
                    Debris:AddItem(u38, 2);
                end);
            end;
        end;
    end,

    Burn = function(p39) -- Line: 405
        -- upvalues: SoundManager (copy), Particles (copy), GlobalFunctions (copy)
        local Character = p39.Character;

        if not Character then
            return;
        end;

        local HumanoidRootPart = Character:FindFirstChild("HumanoidRootPart");
        local v40 = p39.LitTime or 1;

        if HumanoidRootPart then
            SoundManager.AddSound("Burn", {
                Parent = HumanoidRootPart
            }, "Client");
        end;

        local u41 = false;

        for _, child in ipairs(Character:GetChildren()) do
            if child:IsA("BasePart") then
                local u42 = Particles:FindFirstChild("LitPFX"):Clone();
                u42.Parent = child;
                task.delay(v40, function() -- Line: 424
                    -- upvalues: GlobalFunctions (ref), u42 (copy), HumanoidRootPart (copy), u41 (ref), SoundManager (ref)
                    GlobalFunctions.Tween({
                        Duration = 1,
                        Instance = u42
                    }, {
                        Rate = 0
                    }).Completed:Once(function() -- Line: 427
                        -- upvalues: HumanoidRootPart (ref), u41 (ref), SoundManager (ref)
                        if HumanoidRootPart and not u41 then
                            u41 = true;
                            SoundManager.AddSound("Burn End", {
                                Parent = HumanoidRootPart
                            }, "Client");
                        end;
                    end);
                end);
                task.delay(v40 + 1, function() -- Line: 435
                    -- upvalues: u42 (copy)
                    u42:Destroy();
                end);
            end;
        end;
    end,

    Poison = function(p43) -- Line: 441
        -- upvalues: SoundManager (copy), Particles (copy), Debris (copy)
        local Character = p43.Character;

        if not Character then
            return;
        end;

        local HumanoidRootPart = Character:FindFirstChild("HumanoidRootPart");
        local v44 = p43.Color or Color3.fromRGB(55, 0, 55);
        local v45 = p43.Duration or 1;

        if HumanoidRootPart then
            SoundManager.AddSound("Poison", {
                Parent = HumanoidRootPart
            }, "Client");
        end;

        local v46 = Particles:FindFirstChild("Smoke Aura", true);

        if not v46 then
            return;
        end;

        for _, child in pairs(Character:GetChildren()) do
            if child:IsA("Part") or child:IsA("MeshPart") then
                local v47 = child;

                for _, child2 in pairs(v46:GetChildren()) do
                    local u48 = child2:Clone();
                    u48.Parent = v47;
                    u48.Enabled = true;
                    u48.Color = ColorSequence.new({ ColorSequenceKeypoint.new(0, v44), ColorSequenceKeypoint.new(0.5, v44), ColorSequenceKeypoint.new(1, v44) });
                    task.delay(v45, function() -- Line: 469
                        -- upvalues: u48 (copy), Debris (ref)
                        u48.Enabled = false;
                        Debris:AddItem(u48, 2);
                    end);
                end;
            end;
        end;
    end,

    ["Ki Burst"] = function(p49) -- Line: 480
        -- upvalues: GlobalFunctions (copy), Particles (copy), Debris (copy), SoundManager (copy)
        local Character = p49.Character;

        if not Character then
            return;
        end;

        local RootAndHumanoid = GlobalFunctions.GetRootAndHumanoid(Character);

        if not RootAndHumanoid then
            return;
        end;

        local v50 = p49.Duration or 1;
        local u51 = Particles.BurstPFX["Lines [2]"]:Clone();
        u51.Parent = RootAndHumanoid;
        u51["Lines [2]"].Enabled = true;
        u51["Lines [2]"]:Emit(100);
        Debris:AddItem(u51, v50);
        task.delay(v50 * 0.5, function() -- Line: 493
            -- upvalues: u51 (copy)
            u51["Lines [2]"].Enabled = false;
        end);
        SoundManager.AddSound("Aura Burst", {
            Parent = RootAndHumanoid
        }, "Client");
    end,

    Sparks = function(p52) -- Line: 499
        -- upvalues: Visuals (copy), Debris (copy), Particles (copy), SoundManager (copy)
        local BulletData = p52.BulletData;

        if BulletData then
            local Part = Instance.new("Part");
            Part.Size = Vector3.new(1, 1, 1);
            Part.Parent = Visuals;
            Part.Transparency = 1;
            Part.CanCollide = false;
            Part.Material = Enum.Material.Neon;
            Part.CFrame = BulletData.CFrame;
            Part.Anchored = true;
            Debris:AddItem(Part, 3);
            local v53 = Particles.Sparks:Clone();
            v53.Parent = Part;
            v53:Emit(10);
            Debris:AddItem(v53, 2);
            SoundManager.AddSound("Kienzan Hit", {
                Parent = Part
            }, "Client");
        end;
    end,

    Barrier = function(p54) -- Line: 520
        -- upvalues: Meshes (copy), Visuals (copy), GlobalFunctions (copy), SoundManager (copy)
        local Character = p54.Character;

        if not Character then
            return;
        end;

        local HumanoidRootPart = Character:FindFirstChild("HumanoidRootPart");

        if not HumanoidRootPart then
            return;
        end;

        local v55 = p54.Color or Color3.fromRGB(253, 255, 129);
        local v56 = p54.Duration or 2;
        local u57 = Meshes:FindFirstChild("Sphere"):Clone();
        u57.Parent = Visuals;
        u57.Size = Vector3.new(0, 0, 0);
        u57.CFrame = HumanoidRootPart.CFrame;
        u57.CanCollide = false;
        u57.Anchored = false;
        u57.Color = v55;
        local WeldConstraint = Instance.new("WeldConstraint");
        WeldConstraint.Part0 = u57;
        WeldConstraint.Part1 = HumanoidRootPart;
        WeldConstraint.Parent = u57;
        local u58 = {
            Duration = 0.75,
            Instance = u57
        };
        GlobalFunctions.Tween(u58, {
            Size = Vector3.new(10, 10, 10)
        });
        SoundManager.AddSound("Energy Shield", {
            Parent = u57
        }, "Client");
        task.delay(v56, function() -- Line: 552
            -- upvalues: SoundManager (ref), u57 (copy), GlobalFunctions (ref), u58 (copy)
            SoundManager.AddSound("Energy Shield Deactivate", {
                Parent = u57
            }, "Client");
            GlobalFunctions.Tween(u58, {
                Size = Vector3.new(0, 0, 0)
            }).Completed:Once(function() -- Line: 556
                -- upvalues: u57 (ref)
                u57:Destroy();
            end);
        end);
    end,

    MangaFrame = function(p59) -- Line: 563
        -- upvalues: GlobalFunctions (copy), Gui (copy), Debris (copy), SoundManager (copy)
        local Character = p59.Character;

        if not Character then
            return;
        end;

        local Attack_Name = p59.Attack_Name;
        local JapaneseName = p59.JapaneseName;
        local RootAndHumanoid = GlobalFunctions.GetRootAndHumanoid(Character);

        if not RootAndHumanoid then
            return;
        end;

        local u60 = Gui.Misc.MangaFrame:Clone();
        u60.Parent = Character;
        u60.Adornee = RootAndHumanoid;
        Debris:AddItem(u60, 10);
        local Bubble = u60.Bubble;
        local SkillName = Bubble.SkillName;
        local JapaneseName2 = Bubble.JapaneseName;
        local Back = Enum.EasingStyle.Back;
        u60.StudsOffset = Vector3.new(-3, 5, 0);
        Bubble.SkillName.Text = Attack_Name;

        if JapaneseName then
            Bubble.JapaneseName.Text = JapaneseName;
        end;

        Bubble.BackgroundTransparency = 1;
        Bubble.ImageTransparency = 1;
        JapaneseName2.TextTransparency = 1;
        JapaneseName2.TextStrokeTransparency = 1;
        SkillName.TextTransparency = 1;
        SkillName.TextStrokeTransparency = 1;

        local function Close() -- Line: 645
            -- upvalues: u60 (copy), Back (copy), GlobalFunctions (ref)
            for _, descendant in pairs(u60:GetDescendants()) do
                if descendant:IsA("ImageLabel") then
                    GlobalFunctions.Tween({
                        Instance = descendant,
                        EasingStyle = Back,
                        Duration = 0.75
                    }, {
                        ImageTransparency = 1
                    });
                elseif descendant:IsA("TextLabel") then
                    GlobalFunctions.Tween({
                        Instance = descendant,
                        Duration = 0.75,
                        EasingStyle = Back
                    }, {
                        TextTransparency = 1,
                        TextStrokeTransparency = 1
                    });
                end;
            end;

            GlobalFunctions.Tween({
                Instance = u60,
                Duration = 0.75
            }, {
                StudsOffset = Vector3.new(-3, 5, 0)
            });
        end;

        (function() -- Line: 603, Name: Open
            -- upvalues: SoundManager (ref), RootAndHumanoid (copy), u60 (copy), Back (copy), GlobalFunctions (ref)
            SoundManager.AddSound("Manga Flip", {
                Parent = RootAndHumanoid
            }, "Client");

            for _, descendant in pairs(u60:GetDescendants()) do
                if descendant:IsA("ImageLabel") then
                    GlobalFunctions.Tween({
                        Instance = descendant,
                        Duration = 0.75,
                        EasingStyle = Back
                    }, {
                        ImageTransparency = 0
                    });
                elseif descendant:IsA("TextLabel") then
                    GlobalFunctions.Tween({
                        Instance = descendant,
                        Duration = 0.75,
                        EasingStyle = Back
                    }, {
                        TextTransparency = 0,
                        TextStrokeTransparency = 0.81
                    });
                end;
            end;

            GlobalFunctions.Tween({
                Instance = u60,
                EasingStyle = Back,
                Duration = 0.75
            }, {
                StudsOffset = Vector3.new(-3, 2, 0)
            });
        end)();
        task.delay(2, Close);
    end
};