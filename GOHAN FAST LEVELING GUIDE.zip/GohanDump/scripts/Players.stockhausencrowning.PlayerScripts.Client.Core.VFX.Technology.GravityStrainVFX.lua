-- Decompiled with Potassium's decompiler.

local Players = game:GetService("Players");
local ReplicatedStorage = game:GetService("ReplicatedStorage");
local TweenService = game:GetService("TweenService");
game:GetService("RunService");
local LocalPlayer = Players.LocalPlayer;
local StatRetrieveRemote = ReplicatedStorage:WaitForChild("Remotes"):WaitForChild("StatRetrieveRemote");
local u1 = { 2, 4 };
local u2 = { 40, 140 };
local v3 = {};
local u4 = nil;
local u5 = nil;
local u6 = nil;
local u7 = false;
local u8 = 0;

local function ensureGui() -- Line: 38
    -- upvalues: u4 (ref), LocalPlayer (copy), u5 (ref), u6 (ref)
    if u4 and u4.Parent then
        return;
    end;

    u4 = Instance.new("ScreenGui");
    u4.Name = "GravityStrain";
    u4.IgnoreGuiInset = true;
    u4.ResetOnSpawn = false;
    u4.DisplayOrder = 5;
    u4.Parent = LocalPlayer:WaitForChild("PlayerGui");
    u5 = Instance.new("Frame");
    u5.Name = "Tint";
    u5.Size = UDim2.fromScale(1, 1);
    u5.BackgroundColor3 = Color3.fromRGB(255, 40, 40);
    u5.BackgroundTransparency = 1;
    u5.BorderSizePixel = 0;
    u5.Parent = u4;
    u6 = Instance.new("Frame");
    u6.Name = "Bars";
    u6.Size = UDim2.fromScale(1, 1);
    u6.BackgroundTransparency = 1;
    u6.ClipsDescendants = true;
    u6.Parent = u4;
end;

local function setTint(p9) -- Line: 61
    -- upvalues: ensureGui (copy), TweenService (copy), u5 (ref)
    ensureGui();
    TweenService:Create(u5, TweenInfo.new(0.6), {
        BackgroundTransparency = p9 and 0.92 or 1
    }):Play();
end;

local function spawnBar() -- Line: 66
    -- upvalues: u1 (copy), u2 (copy), u6 (ref), TweenService (copy)
    local math_random_ret = math.random(u1[1], u1[2]);
    local math_random_ret2 = math.random(u2[1], u2[2]);
    local Frame = Instance.new("Frame");
    Frame.Size = UDim2.fromOffset(math_random_ret, math_random_ret2);
    Frame.Position = UDim2.new(math.random(), 0, 0, -math_random_ret2);
    Frame.BackgroundColor3 = Color3.new(0, 0, 0);
    Frame.BackgroundTransparency = 0.15;
    Frame.BorderSizePixel = 0;
    Frame.Parent = u6;
    local v10 = TweenService:Create(Frame, TweenInfo.new(0.55, Enum.EasingStyle.Quad, Enum.EasingDirection.In), {
        Position = UDim2.new(Frame.Position.X.Scale, 0, 1, 0)
    });
    v10.Completed:Once(function() -- Line: 77
        -- upvalues: Frame (copy)
        Frame:Destroy();
    end);
    v10:Play();
end;

local function setCrushing(p11) -- Line: 81
    -- upvalues: u7 (ref), ensureGui (copy), spawnBar (copy)
    if p11 == u7 then
        return;
    end;

    u7 = p11;

    if not p11 then
        return;
    end;

    ensureGui();
    task.spawn(function() -- Line: 86
        -- upvalues: u7 (ref), spawnBar (ref)
        while u7 do
            spawnBar();
            task.wait(0.12);
        end;
    end);
end;

local function evaluate(p12) -- Line: 94
    -- upvalues: setTint (copy), u8 (ref), u7 (ref), ensureGui (copy), spawnBar (copy)
    local v13 = p12 > 1;
    setTint(v13);
    local v14 = p12 > 0 and u8 / p12 or 1;

    if v13 then
        v13 = v14 < 0.1;
    end;

    if v13 == u7 then
        return;
    end;

    u7 = v13;

    if not v13 then
        return;
    end;

    ensureGui();
    task.spawn(function() -- Line: 86
        -- upvalues: u7 (ref), spawnBar (ref)
        while u7 do
            spawnBar();
            task.wait(0.12);
        end;
    end);
end;

local function findCurrentGravity() -- Line: 104
    -- upvalues: LocalPlayer (copy)
    local v15 = os.clock() + 60;

    while os.clock() < v15 do
        local PlayerStats = LocalPlayer:FindFirstChild("PlayerStats");

        if PlayerStats then
            PlayerStats = PlayerStats:FindFirstChild("CurrentGravity", true);
        end;

        if PlayerStats then
            return PlayerStats;
        end;

        task.wait(0.5);
    end;

    return nil;
end;

local function watch(u16) -- Line: 115
    -- upvalues: findCurrentGravity (copy), StatRetrieveRemote (copy), u8 (ref), setTint (copy), u7 (ref), ensureGui (copy), spawnBar (copy), LocalPlayer (copy), TweenService (copy), u5 (ref)
    local u17 = findCurrentGravity();

    if not (u17 and u16.Parent) then
        return;
    end;

    local function refreshMastery() -- Line: 118
        -- upvalues: StatRetrieveRemote (ref), u8 (ref)
        local success, result = pcall(StatRetrieveRemote.InvokeServer, StatRetrieveRemote, "GravityMastery");

        if success and tonumber(result) then
            u8 = tonumber(result);
        end;
    end;

    local success, result = pcall(StatRetrieveRemote.InvokeServer, StatRetrieveRemote, "GravityMastery");

    if success and tonumber(result) then
        u8 = tonumber(result);
    end;

    local Value = u17.Value;
    local v18 = Value > 1;
    setTint(v18);
    local v19 = Value > 0 and u8 / Value or 1;

    if v18 then
        v18 = v19 < 0.1;
    end;

    if v18 ~= u7 then
        u7 = v18;

        if v18 then
            ensureGui();
            task.spawn(function() -- Line: 86
                -- upvalues: u7 (ref), spawnBar (ref)
                while u7 do
                    spawnBar();
                    task.wait(0.12);
                end;
            end);
        end;
    end;

    local u23 = u17.Changed:Connect(function(p20) -- Line: 124
        -- upvalues: setTint (ref), u8 (ref), u7 (ref), ensureGui (ref), spawnBar (ref)
        local v21 = p20 > 1;
        setTint(v21);
        local v22 = p20 > 0 and u8 / p20 or 1;

        if v21 then
            v21 = v22 < 0.1;
        end;

        if v21 == u7 then
            return;
        end;

        u7 = v21;

        if not v21 then
            return;
        end;

        ensureGui();
        task.spawn(function() -- Line: 86
            -- upvalues: u7 (ref), spawnBar (ref)
            while u7 do
                spawnBar();
                task.wait(0.12);
            end;
        end);
    end);
    task.spawn(function() -- Line: 126
        -- upvalues: u16 (copy), u17 (ref), LocalPlayer (ref), u23 (ref), findCurrentGravity (ref), setTint (ref), u8 (ref), u7 (ref), ensureGui (ref), spawnBar (ref), StatRetrieveRemote (ref), TweenService (ref), u5 (ref)
        while u16.Parent do
            if not u17:IsDescendantOf(LocalPlayer) then
                u23:Disconnect();
                u17 = findCurrentGravity();

                if not u17 then
                    break;
                end;

                u23 = u17.Changed:Connect(function(p24) -- Line: 133
                    -- upvalues: setTint (ref), u8 (ref), u7 (ref), ensureGui (ref), spawnBar (ref)
                    local v25 = p24 > 1;
                    setTint(v25);
                    local v26 = p24 > 0 and u8 / p24 or 1;

                    if v25 then
                        v25 = v26 < 0.1;
                    end;

                    if v25 == u7 then
                        return;
                    end;

                    u7 = v25;

                    if not v25 then
                        return;
                    end;

                    ensureGui();
                    task.spawn(function() -- Line: 86
                        -- upvalues: u7 (ref), spawnBar (ref)
                        while u7 do
                            spawnBar();
                            task.wait(0.12);
                        end;
                    end);
                end);
                local Value2 = u17.Value;
                local v27 = Value2 > 1;
                setTint(v27);
                local v28 = Value2 > 0 and u8 / Value2 or 1;

                if v27 then
                    v27 = v28 < 0.1;
                end;

                if v27 ~= u7 then
                    u7 = v27;

                    if v27 then
                        ensureGui();
                        task.spawn(function() -- Line: 86
                            -- upvalues: u7 (ref), spawnBar (ref)
                            while u7 do
                                spawnBar();
                                task.wait(0.12);
                            end;
                        end);
                    end;
                end;
            end;

            if u17.Value > 1 then
                local success2, result2 = pcall(StatRetrieveRemote.InvokeServer, StatRetrieveRemote, "GravityMastery");

                if success2 and tonumber(result2) then
                    u8 = tonumber(result2);
                end;

                local Value2 = u17.Value;
                local v29 = Value2 > 1;
                setTint(v29);
                local v30 = Value2 > 0 and u8 / Value2 or 1;

                if v29 then
                    v29 = v30 < 0.1;
                end;

                if v29 ~= u7 then
                    u7 = v29;

                    if v29 then
                        ensureGui();
                        task.spawn(function() -- Line: 86
                            -- upvalues: u7 (ref), spawnBar (ref)
                            while u7 do
                                spawnBar();
                                task.wait(0.12);
                            end;
                        end);
                    end;
                end;
            end;

            task.wait(2);
        end;

        u23:Disconnect();

        if u7 ~= false then
            u7 = false;
        end;

        ensureGui();
        TweenService:Create(u5, TweenInfo.new(0.6), {
            BackgroundTransparency = 1
        }):Play();
    end);
end;

if LocalPlayer.Character then
    task.spawn(watch, LocalPlayer.Character);
end;

LocalPlayer.CharacterAdded:Connect(function(p31) -- Line: 146
    -- upvalues: watch (copy)
    task.spawn(watch, p31);
end);

return v3;