-- Decompiled with Potassium's decompiler.

if shared._K_INTERFACE then
    return shared._K_INTERFACE;
end;

local RunService = game:GetService("RunService");
local os_clock_ret = os.clock();
local Client = script:WaitForChild("Client");
local v1 = RunService:IsServer() and script:WaitForChild("Server");
local Shared = script:WaitForChild("Shared");
local Util = require(Shared:WaitForChild("Util"));
local v2 = game.PlaceId == 2569622788;

if v1 then
    v1.Parent = Util.Service.ServerStorage;
end;

local u3 = {
    UI = nil,
    client = nil,
    pinnedAnnouncement = nil,
    ready = false,
    Notify = nil,
    _serverLock = false,
    _addonTag = "Kohl\'s Admin Addon",
    script = script,
    IsClient = RunService:IsClient(),
    IsServer = RunService:IsServer(),
    IsStudio = RunService:IsStudio(),
    DEBUG = v2,
    VERSION = Util.String.trim(script:WaitForChild("VERSION").Value),
    Logger = Util.Logger.new(true),
    Util = Util,
    Data = require(Shared:WaitForChild("Data")),
    Hook = require(Shared:WaitForChild("Hook")),
    Remote = Util.Remote,
    Flux = require(script:WaitForChild("Flux")),
    Z = require(script:WaitForChild("Z")),
    Auth = require(Shared:WaitForChild("Auth")),
    Process = require(Shared:WaitForChild("Process")),
    Registry = require(Shared:WaitForChild("Registry")),
    VIP = require(Shared:WaitForChild("VIP")),
    Service = Util.Service,
    Server = v1
};
local v4;

if v1 then
    v4 = v1:WaitForChild("Tools");
else
    v4 = v1;
end;

u3.Tools = v4;
u3.cleanupCommands = {};
u3.Z.BUFFER = buffer.create(4194304);
task.spawn(function() -- Line: 98
    -- upvalues: u3 (copy), Util (copy)
    if game.CreatorType == Enum.CreatorType.Group then
        u3.groupId = game.CreatorId;
        local v5, v6 = Util.Retry(function() -- Line: 101
            -- upvalues: u3 (ref)
            return u3.Service.Group:GetGroupInfoAsync(game.CreatorId);
        end);
        u3.creatorId = not v5 and 0 or v6.Owner.Id;
    else
        u3.creatorId = game.CreatorId;
    end;

    u3.Data.creatorId = u3.creatorId;

    if u3.IsServer then
        local os_clock_ret2 = os.clock();

        while not u3.Data.roles and os.clock() - os_clock_ret2 < 10 do
            task.wait();
        end;

        if u3.Data.roles then
            u3.Auth.userRoleAdd(u3.creatorId, "creator");
        end;
    end;
end);

function u3.getCommandPrefix(p7: number?) -- Line: 121
    -- upvalues: u3 (copy)
    return not u3.IsClient and (u3.Data.playerPrefix[p7] or ";") or u3.client.playerPrefix._value;
end;

function u3.removeExcessLogs() -- Line: 128
    -- upvalues: u3 (copy)
    local logs = u3.Data.logs;
    local v8 = #logs - u3.Logger.limit;

    if v8 > 0 then
        u3.Util.Table.fastRemove(logs, 1, v8);
    end;
end;

function u3.log(u9: string, u10: any, u11: number?, u12: boolean?) -- Line: 136
    -- upvalues: u3 (copy), Util (copy)
    if u3.Data.logsHidden[u11] then
        return;
    end;

    local u13 = u3.Logger:log(u9, u10, u11, true);

    if u13 then
        if u3.IsClient then
            u13[6] = true;
        end;

        task.defer(function() -- Line: 149
            -- upvalues: u11 (copy), u13 (copy), Util (ref), u3 (ref), u12 (copy), u9 (copy), u10 (copy)
            if u11 then
                u13[5] = Util.getUserInfo(u11).Username;
            end;

            if u3.IsServer then
                if #u13[1] > 16384 then
                    u13[1] = string.sub(u13[1], 1, 16384);
                end;

                if u11 and u12 then
                    u13[1] = Util.String.filterForBroadcast(u9, u11);
                end;

                if u10 == "CHAT" and u3.Data.settings.saveChatLogs or u10 == "COMMAND" and (u3.Data.settings.saveLogs and (not u11 or (u3.Data.settings.saveLogsForAllRoles or u3.Auth.hasRestrictedRole(u11)))) then
                    table.insert(u3.Data.Sync.logs, u13);
                end;

                for _, v in u3.Service.Players:GetPlayers() do
                    if v:GetAttribute("_K_READY") and u3.Auth.hasPermission(v.UserId, "serverlogs") then
                        u3.Remote.Log:Fire(v, u13);
                    end;
                end;
            elseif u3.client and u3.client.dashboard then
                u3.client.dashboard.Logs:updateList();
            end;

            table.insert(u3.Data.logs, u13);
            u3.Hook.log:Fire(u13);
            u3.removeExcessLogs();
        end);

        return u13;
    end;
end;

u3.Logger.logs = u3.Data.logs;

function u3.alert(p14: any, p15: string, p16: boolean?) -- Line: 190
    -- upvalues: u3 (copy)
    if type(p14) == "number" then
        p14 = u3.Service.Players:GetPlayerByUserId(p14);
    end;

    if typeof(p14) == "Instance" and p14:IsA("Player") then
        local v17 = {
            Text = p15,
            From = p16 and "_K" or nil
        };

        if p16 then
            v17.TextColor3 = Color3.new(1, 0, 0);
            v17.Sound = "Call_Leave";
        end;

        if u3.IsServer then
            u3.Remote.Notify:Fire(p14, v17);

            return;
        end;

        u3.Notify(v17);
    end;
end;

if u3.IsClient then
    u3.UI = require(Client:WaitForChild("UI"));
    local os_clock_ret2 = os.clock();
    u3.UI.registerClasses();
    local task_spawn = task.spawn;
    local log = u3.log;
    local v18 = (os.clock() - os_clock_ret2) * 1000;
    task_spawn(log, `UI classes registered in {math.round(v18)} ms`, "DEBUG");
end;

local os_clock_ret2 = os.clock();

for _, child in Shared.DefaultTypes:GetChildren() do
    require(child)(u3);
end;

local task_spawn = task.spawn;
local log = u3.log;
local v19 = (os.clock() - os_clock_ret2) * 1000;
task_spawn(log, `Default Types registered in {math.round(v19)} ms`, "DEBUG");
local os_clock_ret3 = os.clock();

for _, child in Shared.DefaultCommands:GetChildren() do
    u3.Registry.registerCommandModule(u3, child);
end;

local task_spawn2 = task.spawn;
local log2 = u3.log;
local v20 = (os.clock() - os_clock_ret3) * 1000;
task_spawn2(log2, `Default Commands registered in {math.round(v20)} ms`, "DEBUG");
shared._K_INTERFACE = u3;

if u3.IsServer then
    require(v1)(u3);
elseif not u3.IsStudio or v2 then
    print((`🛡️ Running Kohl's Admin v{u3.VERSION} by @Scripth`));
end;

local task_spawn3 = task.spawn;
local log3 = u3.log;
local v21 = (os.clock() - os_clock_ret) * 1000;
task_spawn3(log3, `Required in {math.round(v21)} ms`, "DEBUG");

return u3;