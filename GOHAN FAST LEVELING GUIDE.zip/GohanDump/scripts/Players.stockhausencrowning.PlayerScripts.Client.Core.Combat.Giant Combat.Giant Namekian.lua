-- Decompiled with Potassium's decompiler.

local ReplicatedStorage = game:GetService("ReplicatedStorage");
local Players = game:GetService("Players");
local Modules = ReplicatedStorage:WaitForChild("Modules");
local Remotes = ReplicatedStorage:WaitForChild("Remotes");
local Utility = Modules.Utility;
local ControlData = require(Modules.Metadata.ControlData.ControlData);
local StateManager = require(ReplicatedStorage.Modules.Metadata.ControlData.StateManager);
local UtilityHandler = require(Utility.UtilityHandler);
local ServerRemote = Remotes.ServerRemote;
local LocalPlayer = Players.LocalPlayer;
local u1 = UtilityHandler:DeepCopy(ControlData.Controls["Giant Namekian"].Push_Controls);

local function markCooldown(p2, p3, p4) -- Line: 35
    p2:SetAttribute("ApeCD_" .. p3, workspace:GetServerTimeNow() + p4);
end;

return {
    Push = function(p5, p6) -- Line: 42
        -- upvalues: LocalPlayer (copy), StateManager (copy), u1 (copy), ServerRemote (copy)
        local v7 = LocalPlayer.Character or LocalPlayer.CharacterAdded:Wait();

        if not StateManager.CanPerformAction(v7, "Push") then
            return;
        end;

        if not u1.Enabled then
            return;
        end;

        u1.Enabled = false;
        local CD = u1.CD;
        v7:SetAttribute("ApeCD_Push", workspace:GetServerTimeNow() + CD);
        task.delay(u1.CD, function() -- Line: 49
            -- upvalues: u1 (ref)
            u1.Enabled = true;
        end);
        ServerRemote:FireServer(nil, {
            Module = "Ape Combat",
            Action = "Push"
        });
    end
};