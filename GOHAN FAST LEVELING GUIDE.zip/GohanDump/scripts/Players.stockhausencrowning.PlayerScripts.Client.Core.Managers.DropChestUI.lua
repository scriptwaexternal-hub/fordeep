-- Decompiled with Potassium's decompiler.

local Players = game:GetService("Players");
local ReplicatedStorage = game:GetService("ReplicatedStorage");
game:GetService("TweenService");
local ServerRemote = ReplicatedStorage.Remotes.ServerRemote;
local LocalPlayer = Players.LocalPlayer;
local Color3_fromRGB_ret = Color3.fromRGB(242, 124, 30);
local Color3_fromRGB_ret2 = Color3.fromRGB(38, 86, 176);
local Color3_fromRGB_ret3 = Color3.fromRGB(16, 26, 46);
local Color3_fromRGB_ret4 = Color3.fromRGB(10, 17, 31);
local Color3_fromRGB_ret5 = Color3.fromRGB(240, 244, 252);
local Color3_fromRGB_ret6 = Color3.fromRGB(126, 148, 184);
local Color3_fromRGB_ret7 = Color3.fromRGB(255, 205, 74);
local u1 = {};
local u2 = nil;
local u3 = nil;
local u4 = nil;
local u5 = nil;
local u6 = nil;

local function ensureGui() -- Line: 47
    -- upvalues: u2 (ref), LocalPlayer (copy), Color3_fromRGB_ret3 (copy), Color3_fromRGB_ret (copy), Color3_fromRGB_ret6 (copy), u1 (copy), Color3_fromRGB_ret2 (copy), u5 (ref), u3 (ref), u4 (ref), u6 (ref), ServerRemote (copy)
    if u2 and u2.Parent then
        return;
    end;

    u2 = Instance.new("ScreenGui");
    u2.Name = "DropChestGui";
    u2.ResetOnSpawn = false;
    u2.IgnoreGuiInset = true;
    u2.DisplayOrder = 15;
    u2.Enabled = false;
    u2.Parent = LocalPlayer:WaitForChild("PlayerGui");
    local Frame = Instance.new("Frame");
    Frame.Name = "Panel";
    Frame.AnchorPoint = Vector2.new(0.5, 0.5);
    Frame.Position = UDim2.fromScale(0.5, 0.5);
    Frame.Size = UDim2.fromOffset(300, 120);
    Frame.BackgroundColor3 = Color3_fromRGB_ret3;
    Frame.BorderSizePixel = 0;
    Frame.Parent = u2;
    local UICorner = Instance.new("UICorner");
    UICorner.CornerRadius = UDim.new(0, 6);
    UICorner.Parent = Frame;
    local UIStroke = Instance.new("UIStroke");
    UIStroke.Color = Color3_fromRGB_ret;
    UIStroke.Transparency = 0.35;
    UIStroke.Thickness = 1;
    UIStroke.Parent = Frame;
    local TextLabel = Instance.new("TextLabel");
    TextLabel.Name = "Title";
    TextLabel.Size = UDim2.new(1, -20, 0, 26);
    TextLabel.Position = UDim2.fromOffset(12, 8);
    TextLabel.BackgroundTransparency = 1;
    TextLabel.Text = "CHEST";
    TextLabel.TextColor3 = Color3_fromRGB_ret;
    TextLabel.Font = Enum.Font.Bangers;
    TextLabel.TextSize = 18;
    TextLabel.TextXAlignment = Enum.TextXAlignment.Left;
    TextLabel.Parent = Frame;
    local TextButton = Instance.new("TextButton");
    TextButton.Name = "Close";
    TextButton.AnchorPoint = Vector2.new(1, 0);
    TextButton.Position = UDim2.new(1, -10, 0, 8);
    TextButton.Size = UDim2.fromOffset(22, 22);
    TextButton.BackgroundTransparency = 1;
    TextButton.Text = "X";
    TextButton.TextColor3 = Color3_fromRGB_ret6;
    TextButton.Font = Enum.Font.Bangers;
    TextButton.TextSize = 16;
    TextButton.Parent = Frame;
    TextButton.MouseButton1Click:Connect(function() -- Line: 100
        -- upvalues: u1 (ref)
        u1.Close();
    end);
    local Frame2 = Instance.new("Frame");
    Frame2.Name = "Belt";
    Frame2.Position = UDim2.fromOffset(12, 30);
    Frame2.Size = UDim2.new(1, -24, 0, 2);
    Frame2.BackgroundColor3 = Color3_fromRGB_ret2;
    Frame2.BorderSizePixel = 0;
    Frame2.Parent = Frame;
    u5 = Instance.new("TextLabel");
    u5.Name = "Zeni";
    u5.Size = UDim2.new(1, -20, 0, 16);
    u5.Position = UDim2.fromOffset(12, 36);
    u5.BackgroundTransparency = 1;
    u5.Text = "";
    u5.TextColor3 = Color3_fromRGB_ret2;
    u5.Font = Enum.Font.Bangers;
    u5.TextSize = 15;
    u5.TextXAlignment = Enum.TextXAlignment.Left;
    u5.Parent = Frame;
    u3 = Instance.new("ScrollingFrame");
    u3.Name = "List";
    u3.Position = UDim2.fromOffset(10, 56);
    u3.Size = UDim2.new(1, -20, 1, -96);
    u3.BackgroundTransparency = 1;
    u3.BorderSizePixel = 0;
    u3.ScrollBarThickness = 3;
    u3.ScrollBarImageColor3 = Color3_fromRGB_ret2;
    u3.CanvasSize = UDim2.new();
    u3.Parent = Frame;
    local UIListLayout = Instance.new("UIListLayout");
    UIListLayout.Padding = UDim.new(0, 4);
    UIListLayout.SortOrder = Enum.SortOrder.LayoutOrder;
    UIListLayout.Parent = u3;
    u4 = Instance.new("TextButton");
    u4.Name = "TakeAll";
    u4.AnchorPoint = Vector2.new(0.5, 1);
    u4.Position = UDim2.new(0.5, 0, 1, -10);
    u4.Size = UDim2.new(1, -20, 0, 28);
    u4.BackgroundColor3 = Color3_fromRGB_ret;
    u4.BorderSizePixel = 0;
    u4.Text = "TAKE ALL";
    u4.TextColor3 = Color3.fromRGB(255, 252, 246);
    u4.Font = Enum.Font.Bangers;
    u4.TextSize = 17;
    u4.Parent = Frame;
    local UICorner2 = Instance.new("UICorner");
    UICorner2.CornerRadius = UDim.new(0, 4);
    UICorner2.Parent = u4;
    u4.MouseButton1Click:Connect(function() -- Line: 157
        -- upvalues: u6 (ref), ServerRemote (ref)
        if not u6 then
            return;
        end;

        ServerRemote:FireServer("TakeAll", {
            Module = "DropChestHandler",
            ChestId = u6
        });
    end);
end;

local function buildRow(u7) -- Line: 163
    -- upvalues: Color3_fromRGB_ret4 (copy), Color3_fromRGB_ret5 (copy), u6 (ref), ServerRemote (copy)
    local u8 = u7.IsZeni == true;
    local TextButton = Instance.new("TextButton");
    TextButton.Name = u8 and "Zeni" or u7.Name;
    TextButton.Size = UDim2.new(1, -4, 0, 34);
    TextButton.BackgroundColor3 = Color3_fromRGB_ret4;
    TextButton.BorderSizePixel = 0;
    TextButton.Text = "";
    TextButton.AutoButtonColor = true;
    TextButton.LayoutOrder = u8 and 0 or u7.Index;
    local UICorner = Instance.new("UICorner");
    UICorner.CornerRadius = UDim.new(0, 4);
    UICorner.Parent = TextButton;
    local Frame = Instance.new("Frame");
    Frame.Size = UDim2.new(0, 4, 1, -10);
    Frame.Position = UDim2.fromOffset(0, 5);
    Frame.BackgroundColor3 = u7.Color;
    Frame.BorderSizePixel = 0;
    Frame.Parent = TextButton;
    local UICorner2 = Instance.new("UICorner");
    UICorner2.CornerRadius = UDim.new(0, 2);
    UICorner2.Parent = Frame;
    local TextLabel = Instance.new("TextLabel");
    TextLabel.Size = UDim2.new(1, -110, 1, 0);
    TextLabel.Position = UDim2.fromOffset(14, 0);
    TextLabel.BackgroundTransparency = 1;
    TextLabel.Text = u7.Name;
    TextLabel.TextColor3 = Color3_fromRGB_ret5;
    TextLabel.Font = Enum.Font.Bangers;
    TextLabel.TextSize = 16;
    TextLabel.TextXAlignment = Enum.TextXAlignment.Left;
    TextLabel.TextTruncate = Enum.TextTruncate.AtEnd;
    TextLabel.Parent = TextButton;
    local TextLabel2 = Instance.new("TextLabel");
    TextLabel2.AnchorPoint = Vector2.new(1, 0.5);
    TextLabel2.Position = UDim2.new(1, -10, 0.5, 0);
    TextLabel2.Size = UDim2.fromOffset(94, 34);
    TextLabel2.BackgroundTransparency = 1;
    TextLabel2.Text = u7.TypeLabel;
    TextLabel2.TextColor3 = u7.Color;
    TextLabel2.Font = Enum.Font.Bangers;
    TextLabel2.TextSize = 14;
    TextLabel2.TextXAlignment = Enum.TextXAlignment.Right;
    TextLabel2.Parent = TextButton;
    TextButton.MouseButton1Click:Connect(function() -- Line: 214
        -- upvalues: u6 (ref), u8 (copy), ServerRemote (ref), u7 (copy)
        if not u6 then
            return;
        end;

        if u8 then
            ServerRemote:FireServer("TakeZeni", {
                Module = "DropChestHandler",
                ChestId = u6
            });

            return;
        end;

        ServerRemote:FireServer("Take", {
            Module = "DropChestHandler",
            ChestId = u6,
            Index = u7.Index
        });
    end);

    return TextButton;
end;

local function render(p9) -- Line: 225
    -- upvalues: ensureGui (copy), u6 (ref), u3 (ref), buildRow (copy), Color3_fromRGB_ret7 (copy), u2 (ref), u5 (ref), u4 (ref)
    ensureGui();
    u6 = p9.ChestId;

    for _, child in ipairs(u3:GetChildren()) do
        if child:IsA("GuiObject") then
            child:Destroy();
        end;
    end;

    local v10 = (p9.Zeni or 0) > 0;

    if v10 then
        buildRow({
            IsZeni = true,
            Index = 0,
            TypeLabel = "ZENI",
            Name = p9.Zeni .. " Zeni",
            Color = Color3_fromRGB_ret7
        }).Parent = u3;
    end;

    for _, v in ipairs(p9.Items) do
        buildRow(v).Parent = u3;
    end;

    local v11 = #p9.Items + (v10 and 1 or 0);
    u3.CanvasSize = UDim2.fromOffset(0, v11 * 38);
    local math_clamp_ret = math.clamp(v11, 1, 8);
    local Panel = u2.Panel;
    Panel.Size = UDim2.fromOffset(300, math_clamp_ret * 38 + 96);
    u5.Text = "";
    u4.Visible = v11 > 0;
    u4.Text = "TAKE ALL";
    Panel.Title.Text = v11 > 0 and "CHEST" or "EMPTY";
end;

function u1.Open(p12) -- Line: 261
    -- upvalues: render (copy), u2 (ref)
    if not (p12 and p12.Chest) then
        return;
    end;

    render(p12.Chest);
    u2.Enabled = true;
end;

function u1.Update(p13) -- Line: 267
    -- upvalues: u6 (ref), render (copy)
    if not (p13 and p13.Chest) then
        return;
    end;

    if p13.Chest.ChestId ~= u6 then
        return;
    end;

    render(p13.Chest);
end;

function u1.Close() -- Line: 273
    -- upvalues: u6 (ref), ServerRemote (copy), u2 (ref)
    if u6 then
        ServerRemote:FireServer("CloseChest", {
            Module = "DropChestHandler",
            ChestId = u6
        });
    end;

    u6 = nil;

    if u2 then
        u2.Enabled = false;
    end;
end;

return u1;