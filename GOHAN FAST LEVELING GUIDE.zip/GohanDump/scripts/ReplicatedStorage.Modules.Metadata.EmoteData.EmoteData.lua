-- Decompiled with Potassium's decompiler.

local u1 = {
    Defaults = {
        Walkable = false
    },
    Emotes = {
        Sleep = {
            Walkable = false
        },
        Swim = {
            Walkable = true
        },
        ["At Ease"] = {
            Walkable = false
        },
        Bow = {
            Walkable = false
        },
        HakariDance = {
            Walkable = false
        },
        Kneel = {
            Walkable = false
        },
        ["Kneel Normal"] = {
            Walkable = false
        },
        Salute = {
            Walkable = false
        },
        Laugh = {
            Walkable = false
        },
        Facepalm = {
            Walkable = false
        },
        DuckDance = {
            Walkable = false
        }
    }
};

function u1.Get(p2) -- Line: 41
    -- upvalues: u1 (copy)
    local v3 = u1.Emotes[p2];
    local v4 = {};

    for i, v in pairs(u1.Defaults) do
        v4[i] = v;
    end;

    if type(v3) == "table" then
        for i, v in pairs(v3) do
            v4[i] = v;
        end;
    end;

    return v4;
end;

function u1.IsWalkable(p5) -- Line: 57
    -- upvalues: u1 (copy)
    return u1.Get(p5).Walkable == true;
end;

return u1;