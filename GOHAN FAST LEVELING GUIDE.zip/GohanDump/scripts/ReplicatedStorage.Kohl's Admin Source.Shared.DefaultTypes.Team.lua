-- Decompiled with Potassium's decompiler.

local Teams = game:GetService("Teams");
local u1 = nil;
local u8 = {
    validate = function(p2: string, p3: number) -- Line: 6, Name: validate
        -- upvalues: Teams (copy)
        local string_lower_ret = string.lower(p2);
        local Teams2 = Teams:GetTeams();

        if #Teams2 == 0 then
            return false, "No teams available";
        end;

        for _, v in Teams2 do
            if string.find(string.lower(v.Name), string_lower_ret, 1, true) == 1 then
                return true;
            end;
        end;

        return false, "Invalid team";
    end,

    parse = function(p4: string, p5: number) -- Line: 19, Name: parse
        -- upvalues: Teams (copy)
        local string_lower_ret = string.lower(p4);

        for _, v in Teams:GetTeams() do
            if string.find(string.lower(v.Name), string_lower_ret, 1, true) == 1 then
                return v;
            end;
        end;

        error("Invalid team value");
    end,

    suggestions = function(p6: string, p7: number) -- Line: 28, Name: suggestions
        -- upvalues: u1 (ref), Teams (copy)
        return u1.Util.Suggest.new(Teams:GetTeams());
    end
};
local u9 = {
    listable = true
};

return function(p10) -- Line: 37
    -- upvalues: u1 (ref), u8 (copy), u9 (copy)
    u1 = p10;
    u1.Registry.registerType("team", u8);
    u1.Registry.registerType("teams", u9, u8);
end;