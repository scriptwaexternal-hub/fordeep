-- Decompiled with Potassium's decompiler.

local Parent = require(script.Parent.Parent);
local BaseClass = require(script.Parent:WaitForChild("BaseClass"));
local u1 = {
    Adornee = false,
    RightAlign = false,
    Visible = false
};
local u2 = {};
u2.__index = u2;
setmetatable(u2, BaseClass);
local u3 = Parent.state(Parent.LayerTop, "AbsoluteSize");

function u2.new(p4) -- Line: 18
    -- upvalues: u1 (copy), Parent (copy), u3 (copy), u2 (copy)
    local table_clone_ret = table.clone(u1);
    Parent.makeStatefulDefaults(table_clone_ret, p4);
    local v5 = {};
    table_clone_ret._list = Parent.new("UIListLayout")({
        SortOrder = Enum.SortOrder.LayoutOrder,
        FillDirection = Enum.FillDirection.Vertical,
        VerticalAlignment = Enum.VerticalAlignment.Top
    });
    local u6 = Parent.state(table_clone_ret._list, "AbsoluteContentSize");
    table.insert(v5, u6);
    table_clone_ret._content = Parent.new("ScrollingFrame")({
        Name = "Menu",
        ZIndex = 100,
        BackgroundTransparency = 1,
        ClipsDescendants = false,
        Size = UDim2.new(1, 0, 1, 0),

        CanvasSize = function() -- Line: 39, Name: CanvasSize
            -- upvalues: u6 (copy)
            return UDim2.new(0, 0, 0, u6().Y);
        end,

        AutomaticCanvasSize = Enum.AutomaticSize.Y,
        ScrollBarThickness = 0,
        table_clone_ret._list,
        [Parent.Event] = {
            CanvasPosition = function() -- Line: 48, Name: CanvasPosition
                -- upvalues: Parent (ref)
                Parent.clearState("hover");
            end
        }
    });
    table_clone_ret._instance = Parent.new("TextButton")({
        Name = "Menu",
        ZIndex = 100,
        Visible = table_clone_ret.Visible,
        Parent = Parent.LayerTop,

        AnchorPoint = function() -- Line: 59, Name: AnchorPoint
            -- upvalues: table_clone_ret (copy)
            if table_clone_ret.RightAlign() then
                return Vector2.new(1, 0);
            end;

            return Vector2.zero;
        end,

        BackgroundColor3 = Parent.Theme.Primary,
        ClipsDescendants = true,
        AutoButtonColor = false,
        Text = "",
        table_clone_ret._content,
        Parent.new("UICorner")({
            CornerRadius = Parent.Theme.CornerRadius
        }),
        Parent.new("Gradient")({}),
        Parent.new("Stroke")({}),
        [Parent.Clean] = v5
    });
    local u7 = Parent.state(Vector2.zero);
    local u8 = Parent.state(Vector2.zero);
    local u9 = Parent.state(table_clone_ret._instance, "AbsoluteSize");
    table.insert(v5, u7);
    table.insert(v5, u8);
    table.insert(v5, u9);
    local v18 = Parent.compute(function() -- Line: 85
        -- upvalues: u9 (copy), u3 (ref), u7 (copy), u8 (copy), table_clone_ret (copy), Parent (ref)
        local v10 = u9();
        local v11 = u3();
        local v12 = u7();
        local v13 = u8();
        local v14 = table_clone_ret.RightAlign();
        local Offset = Parent.Theme.Padding().Offset;
        local Height = Parent.TopbarInset().Height;
        local v15 = v12.X + (not v14 and 0 or v13.X);
        local v16 = v12.Y + v13.Y + Offset + Height;
        local UDim2_fromOffset = UDim2.fromOffset;
        local v17;

        if v14 then
            local X = v10.X;
            local math_max_ret = math.max(v10.X, v11.X);
            v17 = math.clamp(v15, X, math_max_ret);
        else
            local math_max_ret = math.max(0, v11.X - v10.X);
            v17 = math.clamp(v15, 0, math_max_ret);
        end;

        local math_max_ret = math.max(0, v11.Y - v10.Y);

        return UDim2_fromOffset(v17, (math.clamp(v16, 0, math_max_ret)));
    end);
    Parent.edit(table_clone_ret._instance, {
        Position = v18
    });
    table.insert(v5, Parent.UserInputService.InputBegan:Connect(function(p19, p20) -- Line: 111
        -- upvalues: table_clone_ret (copy), Parent (ref)
        if (p19.UserInputType == Enum.UserInputType.MouseButton1 or (p19.UserInputType == Enum.UserInputType.Touch or p19.UserInputType == Enum.UserInputType.TextInput)) and (table_clone_ret.Visible._value and not (Parent.pointInGuiObject(p19.Position.X, p19.Position.Y, table_clone_ret.Adornee._value) or Parent.pointInGuiObject(p19.Position.X, p19.Position.Y, table_clone_ret._instance))) then
            Parent.deactivateState(table_clone_ret.Visible, "floating");
        end;
    end));
    local PropertyChangedSignal = table_clone_ret._instance:GetPropertyChangedSignal("Visible");
    table.insert(v5, PropertyChangedSignal:Connect(function() -- Line: 129
        -- upvalues: table_clone_ret (copy), u7 (copy), u8 (copy)
        local _value = table_clone_ret.Adornee._value;

        if not (table_clone_ret._instance.Visible and (typeof(_value) == "Instance" and _value:IsA("GuiObject"))) then
            if u7._bindConnection then
                u7._bindConnection:Disconnect();
            end;

            if u8._bindConnection then
                u8._bindConnection:Disconnect();
            end;

            return;
        end;

        u7(_value.AbsolutePosition, true);
        u8(_value.AbsoluteSize, true);
        u7:_bindToProperty(_value, "AbsolutePosition");
        u8:_bindToProperty(_value, "AbsoluteSize");
    end));

    return setmetatable(table_clone_ret, u2);
end;

return u2;