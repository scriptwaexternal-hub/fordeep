-- Decompiled with Potassium's decompiler.

local Parent = require(script.Parent.Parent);
local BaseClass = require(script.Parent:WaitForChild("BaseClass"));
require(script.Parent:WaitForChild("ColorPicker"));
local u1 = {
    Text = "ListItem Label",
    Value = Color3.new(1, 0, 0)
};
local u2 = {};
u2.__index = u2;
setmetatable(u2, BaseClass);

function u2.new(p3) -- Line: 19
    -- upvalues: u1 (copy), Parent (copy), u2 (copy)
    local table_clone_ret = table.clone(u1);
    Parent.makeStatefulDefaults(table_clone_ret, p3);
    table_clone_ret._instance = Parent.new("TextButton")({
        AutoLocalize = false,
        Text = "",
        BackgroundColor3 = table_clone_ret.Value,
        AnchorPoint = Vector2.new(1, 0.5),

        Size = function() -- Line: 28, Name: Size
            -- upvalues: Parent (ref)
            local v4 = Parent.Theme.FontSize() + Parent.Theme.Padding().Offset;

            return UDim2.new(0, v4, 0, v4);
        end,

        Position = UDim2.new(1, 0, 0.5, 0),
        Parent.new("UICorner")({
            CornerRadius = Parent.Theme.CornerPadded
        }),
        Parent.new("Stroke")({}),

        Activated = function() -- Line: 39, Name: Activated
            -- upvalues: Parent (ref), table_clone_ret (copy)
            Parent.toggleState(table_clone_ret._dialog.Visible, "floating");

            if Parent.raw(table_clone_ret._dialog.Visible) then
                Parent.Sound.Hover03:Play();

                return;
            end;

            Parent.Sound.Hover01:Play();
        end
    });
    table_clone_ret._dialog = Parent.new("ColorPicker")({
        RightAlign = true,
        BackgroundTransparency = 0,
        Adornee = table_clone_ret._instance,
        Value = table_clone_ret.Value,
        BackgroundColor3 = Parent.Theme.Primary
    });

    return setmetatable(table_clone_ret, u2);
end;

return u2;