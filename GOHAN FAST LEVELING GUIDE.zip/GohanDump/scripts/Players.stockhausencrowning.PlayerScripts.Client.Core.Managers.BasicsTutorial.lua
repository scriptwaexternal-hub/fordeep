-- Decompiled with Potassium's decompiler.

local ReplicatedStorage = game:GetService("ReplicatedStorage");
local ServerRemote = ReplicatedStorage:WaitForChild("Remotes").ServerRemote;
local KamiCard = require(ReplicatedStorage:WaitForChild("Modules").Shared.KamiCard);
local ControlData = require(ReplicatedStorage:WaitForChild("Modules").Metadata.ControlData.ControlData);
local GamepadGlyphs = require(ReplicatedStorage.Modules.Shared.GamepadGlyphs);
local Platform = require(ReplicatedStorage.Modules.Shared.Platform);
local UserInputService = game:GetService("UserInputService");

local function bindFor(p1, p2, p3) -- Line: 43
    -- upvalues: ControlData (copy)
    local v4 = ControlData.Controls and ControlData.Controls[p1];

    if v4 then
        v4 = v4[p2];
    end;

    if v4 then
        v4 = v4[1];
    end;

    if typeof(v4) == "string" and (v4 ~= "" and v4) then
        p3 = v4;
    end;

    return p3;
end;

local function onPad() -- Line: 53
    -- upvalues: Platform (copy), UserInputService (copy)
    return Platform.IsConsole() or Platform.IsGamepadInput(UserInputService:GetLastInputType());
end;

local function keyFor(p5, p6, p7) -- Line: 57
    -- upvalues: Platform (copy), UserInputService (copy), GamepadGlyphs (copy), ControlData (copy)
    local v8 = (Platform.IsConsole() or Platform.IsGamepadInput(UserInputService:GetLastInputType())) and GamepadGlyphs.PadBinding(p5, p6, true);

    if v8 then
        return v8;
    end;

    local v9 = ControlData.Controls and ControlData.Controls[p5];

    if v9 then
        v9 = v9[p6];
    end;

    if v9 then
        v9 = v9[1];
    end;

    if typeof(v9) == "string" and (v9 ~= "" and v9) then
        p7 = v9;
    end;

    return p7;
end;

local function padPhrase(p10, p11) -- Line: 66
    -- upvalues: Platform (copy), UserInputService (copy), GamepadGlyphs (copy)
    if not (Platform.IsConsole() or Platform.IsGamepadInput(UserInputService:GetLastInputType())) then
        return nil;
    end;

    local _, v12, v13 = GamepadGlyphs.PadBinding(p10, p11);

    if not v12 then
        return nil;
    end;

    if v13 then
        return "hold " .. GamepadGlyphs.Label(v13) .. ", then press " .. GamepadGlyphs.Label(v12);
    end;

    return "press " .. GamepadGlyphs.Label(v12);
end;

local u14 = nil;

local function buildSteps() -- Line: 91
    -- upvalues: Platform (copy), UserInputService (copy), GamepadGlyphs (copy), ControlData (copy), padPhrase (copy)
    local v15 = Platform.IsConsole() or Platform.IsGamepadInput(UserInputService:GetLastInputType());
    local v16;

    if v15 then
        local v17 = (Platform.IsConsole() or Platform.IsGamepadInput(UserInputService:GetLastInputType())) and GamepadGlyphs.PadBinding("Combat", "Light", true);

        if not v17 then
            local v18 = ControlData.Controls and ControlData.Controls.Combat;

            if v18 then
                v18 = v18.Light;
            end;

            if v18 then
                v18 = v18[1];
            end;

            v17 = (typeof(v18) ~= "string" or (v18 == "" or not v18)) and "X" or v18;
        end;

        v16 = v17 or "M1";
    else
        v16 = "M1";
    end;

    local v19;

    if v15 then
        local v20 = (Platform.IsConsole() or Platform.IsGamepadInput(UserInputService:GetLastInputType())) and GamepadGlyphs.PadBinding("Combat", "Heavy", true);

        if not v20 then
            local v21 = ControlData.Controls and ControlData.Controls.Combat;

            if v21 then
                v21 = v21.Heavy;
            end;

            if v21 then
                v21 = v21[1];
            end;

            v20 = (typeof(v21) ~= "string" or (v21 == "" or not v21)) and "Y" or v21;
        end;

        v19 = v20 or "M2";
    else
        v19 = "M2";
    end;

    local v22 = (Platform.IsConsole() or Platform.IsGamepadInput(UserInputService:GetLastInputType())) and GamepadGlyphs.PadBinding("Combat", "Block", true);

    if not v22 then
        local v23 = ControlData.Controls and ControlData.Controls.Combat;

        if v23 then
            v23 = v23.Block;
        end;

        if v23 then
            v23 = v23[1];
        end;

        v22 = (typeof(v23) ~= "string" or (v23 == "" or not v23)) and "F" or v23;
    end;

    local v24 = (Platform.IsConsole() or Platform.IsGamepadInput(UserInputService:GetLastInputType())) and GamepadGlyphs.PadBinding("Combat", "Dash", true);

    if not v24 then
        local v25 = ControlData.Controls and ControlData.Controls.Combat;

        if v25 then
            v25 = v25.Dash;
        end;

        if v25 then
            v25 = v25[1];
        end;

        v24 = (typeof(v25) ~= "string" or (v25 == "" or not v25)) and "Q" or v25;
    end;

    local v26 = (Platform.IsConsole() or Platform.IsGamepadInput(UserInputService:GetLastInputType())) and GamepadGlyphs.PadBinding("Combat", "Evade", true);

    if not v26 then
        local v27 = ControlData.Controls and ControlData.Controls.Combat;

        if v27 then
            v27 = v27.Evade;
        end;

        if v27 then
            v27 = v27[1];
        end;

        v26 = (typeof(v27) ~= "string" or (v27 == "" or not v27)) and "R" or v27;
    end;

    local v28 = (Platform.IsConsole() or Platform.IsGamepadInput(UserInputService:GetLastInputType())) and GamepadGlyphs.PadBinding("Combat", "Transform", true);

    if not v28 then
        local v29 = ControlData.Controls and ControlData.Controls.Combat;

        if v29 then
            v29 = v29.Transform;
        end;

        if v29 then
            v29 = v29[1];
        end;

        v28 = (typeof(v29) ~= "string" or (v29 == "" or not v29)) and "X" or v29;
    end;

    local v30 = (Platform.IsConsole() or Platform.IsGamepadInput(UserInputService:GetLastInputType())) and GamepadGlyphs.PadBinding("CoreControls", "Meditate", true);

    if not v30 then
        local v31 = ControlData.Controls and ControlData.Controls.CoreControls;

        if v31 then
            v31 = v31.Meditate;
        end;

        if v31 then
            v31 = v31[1];
        end;

        v30 = (typeof(v31) ~= "string" or (v31 == "" or not v31)) and "M" or v31;
    end;

    local v32 = (Platform.IsConsole() or Platform.IsGamepadInput(UserInputService:GetLastInputType())) and GamepadGlyphs.PadBinding("CoreControls", "Inventory", true);

    if not v32 then
        local v33 = ControlData.Controls and ControlData.Controls.CoreControls;

        if v33 then
            v33 = v33.Inventory;
        end;

        if v33 then
            v33 = v33[1];
        end;

        v32 = (typeof(v33) ~= "string" or (v33 == "" or not v33)) and "Tab" or v33;
    end;

    local v34 = (Platform.IsConsole() or Platform.IsGamepadInput(UserInputService:GetLastInputType())) and GamepadGlyphs.PadBinding("UI", "Skill Tree", true);

    if not v34 then
        local v35 = ControlData.Controls and ControlData.Controls.UI;

        if v35 then
            v35 = v35["Skill Tree"];
        end;

        if v35 then
            v35 = v35[1];
        end;

        v34 = (typeof(v35) ~= "string" or (v35 == "" or not v35)) and "L" or v35;
    end;

    local v36 = (Platform.IsConsole() or Platform.IsGamepadInput(UserInputService:GetLastInputType())) and GamepadGlyphs.PadBinding("UI", "Transformations", true);

    if not v36 then
        local v37 = ControlData.Controls and ControlData.Controls.UI;

        if v37 then
            v37 = v37.Transformations;
        end;

        if v37 then
            v37 = v37[1];
        end;

        v36 = (typeof(v37) ~= "string" or (v37 == "" or not v37)) and "G" or v37;
    end;

    local v38 = (Platform.IsConsole() or Platform.IsGamepadInput(UserInputService:GetLastInputType())) and GamepadGlyphs.PadBinding("Menu_UI", "Menu", true);

    if not v38 then
        local v39 = ControlData.Controls and ControlData.Controls.Menu_UI;

        if v39 then
            v39 = v39.Menu;
        end;

        if v39 then
            v39 = v39[1];
        end;

        v38 = (typeof(v39) ~= "string" or (v39 == "" or not v39)) and "K" or v39;
    end;

    local v40 = v15 and GamepadGlyphs.Label(ControlData.PadLayer.Modifier) or "Shift";

    return {
        {
            Section = "BASICS",
            Title = "Unlock Your Ki",
            Objective = "Meditate to draw out your ki",
            Detail = (v15 and "To meditate, " .. padPhrase("CoreControls", "Meditate") .. ". " or "") .. "Keep at it and you\'ll draw out your Ki -- it\'s what every technique in the game runs on.",
            Keys = { v30 }
        },
        {
            Section = "BASICS",
            Title = "Find Yamcha",
            Objective = "Follow your Getting Started objectives",
            Detail = "Your quest tracker points you to Yamcha -- he starts the main story and carries a marker over his head. Look for him near Capsule Corp."
        },
        {
            Section = "BASICS",
            Title = "Fighting",
            Objective = v15 and (v16 .. " punches, " .. v19 .. " for heavies" or "Left click to punch, right click for heavies") or "Left click to punch, right click for heavies",
            Detail = v22 .. " blocks, " .. v26 .. " evades, and " .. v24 .. " dashes -- hold " .. v40 .. " with it to vanish.",
            Keys = v15 and ({ v16, v19, v24 } or {
                "M1",
                "M2",
                v22,
                v26,
                v24
            }) or {
                "M1",
                "M2",
                v22,
                v26,
                v24
            }
        },
        {
            Section = "BASICS",
            Title = "Your Menus",
            Objective = "Open your inventory and stats",
            Detail = v32 .. " opens your inventory. " .. v34 .. " is the skill tree, where you spend points on new techniques. " .. v36 .. " picks a transformation and " .. v28 .. " triggers it. " .. v38 .. " is the main menu.",
            Keys = v15 and ({ v32, v38 } or {
                v32,
                v34,
                v36,
                v38
            }) or {
                v32,
                v34,
                v36,
                v38
            }
        },
        {
            Section = "BASICS",
            Title = "Trainers",
            Objective = "Only Trainers teach lasting techniques",
            Detail = "Trainers around the world teach you skills -- and ONLY trainer-taught skills stay with your character. Each one lists its requirements before you commit."
        },
        {
            Section = "BASICS",
            Title = "Missions",
            Objective = v15 and "Queue for a mission from your inventory" or "Queue for a mission from the Tab menu",
            Detail = "Missions are the quickest early way to make Zeni. Open " .. (v15 and "your inventory (" .. v32 .. ")" or "the TAB menu") .. ", go to Contracts > Missions, pick a difficulty and queue up -- clear it and you\'ll be paid in Zeni and EXP. You can queue solo or with a party."
        },
        {
            Section = "BASICS",
            Title = "Training Points",
            Objective = "Fight AND train to level up",
            Detail = "UTP is potential you haven\'t earned yet -- fighting turns it into GTP. Training then spends GTP to raise your stats. You only level up once BOTH reach zero."
        },
        {
            Section = "BASICS",
            Title = "Good Luck",
            Objective = "That\'s everything you need to get going",
            Detail = "The rest is yours to find out. Good luck out there!",
            Button = "GOOD LUCK"
        }
    };
end;

local v41 = {};
local u42 = false;

function v41.Fire(p43) -- Line: 222
    -- upvalues: u42 (ref), u14 (ref), buildSteps (copy), KamiCard (copy), ServerRemote (copy)
    if u42 then
        return;
    end;

    u42 = true;
    u14 = buildSteps();
    local u44 = KamiCard.new({
        Name = "BasicsTutorialGui",
        ProgressBar = true
    });
    local u45 = 0;

    local function show(p46) -- Line: 234
        -- upvalues: u14 (ref), u44 (copy)
        local v47 = u14[p46];
        u44:Render({
            Speaker = "Kami",
            Counter = string.format("%s   %d / %d", v47.Section, p46, #u14),
            Title = v47.Title,
            Objective = v47.Objective,
            Detail = v47.Detail,
            Keys = v47.Keys,
            Button = v47.Button or "CONTINUE",
            Progress = (p46 - 1) / #u14
        });
    end;

    local function finish() -- Line: 248
        -- upvalues: ServerRemote (ref), u44 (copy), u42 (ref)
        ServerRemote:FireServer(nil, {
            Module = "BasicsTutorialHandler",
            Action = "Finish"
        });
        u44:Dismiss(function() -- Line: 255
            -- upvalues: u42 (ref)
            u42 = false;
        end);
    end;

    local function advance() -- Line: 258
        -- upvalues: u45 (ref), u14 (ref), finish (copy), show (copy)
        u45 = u45 + 1;

        if u45 > #u14 then
            finish();

            return;
        end;

        show(u45);
    end;

    local u48 = false;
    u44.Button.MouseButton1Click:Connect(function() -- Line: 282
        -- upvalues: u48 (ref), u45 (ref), u14 (ref), finish (copy), show (copy)
        if u48 then
            return;
        end;

        u48 = true;
        local v49 = u45 >= #u14;
        u45 = u45 + 1;

        if u45 > #u14 then
            finish();
        else
            show(u45);
        end;

        if not v49 then
            task.delay(0.3, function() -- Line: 288
                -- upvalues: u48 (ref)
                u48 = false;
            end);
        end;
    end);
    u45 = u45 + 1;

    if #u14 < u45 then
        finish();
    else
        show(u45);
    end;

    u44:SlideIn();
end;

return v41;