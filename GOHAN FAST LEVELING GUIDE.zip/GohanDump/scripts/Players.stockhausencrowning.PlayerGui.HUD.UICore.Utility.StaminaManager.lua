-- Decompiled with Potassium's decompiler.

return {
    Update = function(p1) -- Line: 12, Name: Update
    end
};