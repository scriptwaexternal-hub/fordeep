-- Decompiled with Potassium's decompiler.

local Players = game:GetService("Players");
local RunService = game:GetService("RunService");
local UserInputService = game:GetService("UserInputService");
local Notify = require(script.Parent:WaitForChild("Notify"));
local UI = require(script.Parent:WaitForChild("UI"));
local LocalPlayer = Players.LocalPlayer;
local u1 = 128;
local Attachment = Instance.new("Attachment");
local AlignOrientation = Instance.new("AlignOrientation", Attachment);
AlignOrientation.Attachment0 = Attachment;
AlignOrientation.Mode = "OneAttachment";
AlignOrientation.RigidityEnabled = true;
AlignOrientation.Enabled = true;
local LinearVelocity = Instance.new("LinearVelocity", Attachment);
LinearVelocity.Attachment0 = Attachment;
LinearVelocity.ForceLimitsEnabled = false;
LinearVelocity.Enabled = true;
local u2 = 0;

local function updateFly(p3: number, p4: boolean?) -- Line: 26
    -- upvalues: LocalPlayer (copy), AlignOrientation (copy), UserInputService (copy), u2 (ref), u1 (ref), LinearVelocity (copy)
    local v5 = LocalPlayer.Character and LocalPlayer.Character:FindFirstChildOfClass("Humanoid");

    if not v5 then
        return;
    end;

    AlignOrientation.CFrame = workspace.CurrentCamera.CFrame;
    local v6 = v5.Jump and 1 or (UserInputService:IsKeyDown(Enum.KeyCode.LeftControl) and -1 or 0);

    if v6 == 0 and v5.MoveDirection == Vector3.new(0, 0, 0) then
        local v7 = p4 and u1;

        if not v7 then
            local math_min_ret = math.min(v5.WalkSpeed, u1);
            v7 = math.clamp(u2 - p3 * u1 / 2, math_min_ret, u1);
        end;

        u2 = v7;
        LinearVelocity.VectorVelocity = Vector3.new(0, 0, 0);

        return;
    end;

    local LookVector = AlignOrientation.CFrame.LookVector;
    local Unit = CFrame.lookAlong(AlignOrientation.CFrame.Position, Vector3.new(LookVector.X, 0, LookVector.Z), Vector3.new(0, 1, 0)):VectorToObjectSpace(v5.MoveDirection).Unit;
    local v8 = p4 and u1;

    if not v8 then
        local math_min_ret = math.min(v5.WalkSpeed, u1);
        v8 = math.clamp(u2 + p3 * u1 / 4, math_min_ret, u1);
    end;

    u2 = v8;
    LinearVelocity.VectorVelocity = (AlignOrientation.CFrame:VectorToWorldSpace(Unit ~= Unit and Vector3.new(0, 0, 0) or Unit) + AlignOrientation.CFrame.UpVector * v6) * u2;
end;

local u9 = nil;

local function noClip(p10: userdata, p11: boolean?) -- Line: 51
    -- upvalues: u9 (ref)
    if u9 or p11 then
        for _, descendant in p10:GetDescendants() do
            if descendant:IsA("BasePart") then
                if p11 then
                    local Attribute = descendant:GetAttribute("_KInitialCanCollide");

                    if Attribute ~= nil then
                        descendant.CanCollide = Attribute;
                    end;
                else
                    if not descendant:GetAttribute("_KInitialCanCollide") then
                        descendant:SetAttribute("_KInitialCanCollide", descendant.CanCollide);
                    end;

                    descendant.CanCollide = false;
                end;
            end;
        end;
    end;
end;

local u12 = {};
local u13 = false;
local u14 = false;
local u15 = false;
local u16 = nil;

function u12.fly(p17: boolean, u18: boolean?) -- Line: 76
    -- upvalues: u15 (ref), u16 (ref), LocalPlayer (copy), u13 (ref), u14 (ref), Attachment (copy), RunService (copy), updateFly (copy), LinearVelocity (copy)
    if p17 == u15 then
        return;
    end;

    if typeof(u16) == "RBXScriptConnection" then
        u16:Disconnect();
        u16 = nil;
    end;

    local Character = LocalPlayer.Character;

    if Character then
        Character = Character:FindFirstChildOfClass("Humanoid");
    end;

    if not (Character and Character.RootPart) then
        return;
    end;

    u15 = p17;

    if not u15 then
        Attachment.Parent = nil;
        LinearVelocity.VectorVelocity = Vector3.new(0, 0, 0);
        Character.PlatformStand = false;
        Character:ChangeState(Enum.HumanoidStateType.GettingUp);

        return;
    end;

    task.delay(0.3, function() -- Line: 95
        -- upvalues: u13 (ref), u14 (ref)
        u13 = false;
        u14 = false;
    end);
    Character.PlatformStand = true;
    Attachment.Parent = Character.RootPart;
    u16 = RunService.Heartbeat:Connect(function(p19) -- Line: 100
        -- upvalues: updateFly (ref), u18 (copy)
        updateFly(p19, u18 or false);
    end);
    task.defer(Character.ChangeState, Character, Enum.HumanoidStateType.Freefall);
end;

function u12.noclip(p20: boolean) -- Line: 112
    -- upvalues: u9 (ref), LocalPlayer (copy), noClip (copy)
    u9 = p20;

    if LocalPlayer.Character then
        noClip(LocalPlayer.Character, not p20);
    end;
end;

local u21 = {};

local function onCharacter(u22) -- Line: 123
    -- upvalues: u12 (copy), u21 (copy), noClip (copy), u13 (ref), u14 (ref)
    u12.fly(false);
    u12.noclip(false);
    local Humanoid = u22:WaitForChild("Humanoid");

    if u21[u22] then
        u21[u22]:Disconnect();
    end;

    u21[u22] = Humanoid.StateChanged:Connect(function(p23, p24) -- Line: 130
        -- upvalues: noClip (ref), u22 (copy), u13 (ref), u14 (ref), Humanoid (copy)
        noClip(u22);

        if p24 ~= Enum.HumanoidStateType.Landed then
            if p24 == Enum.HumanoidStateType.Freefall then
                task.wait(p23 == Enum.HumanoidStateType.Jumping and 0.1 or 0.4);

                if Humanoid:GetState() == Enum.HumanoidStateType.Freefall then
                    u13 = true;
                end;
            end;

            return;
        end;

        u13 = false;
        u14 = false;
    end);
end;

local u25 = 0;

local function onJumpRequest() -- Line: 145
    -- upvalues: u14 (ref), LocalPlayer (copy), u25 (ref), u15 (ref), u12 (copy), u13 (ref), u9 (ref), UI (copy), Notify (copy)
    if u14 then
        return;
    end;

    local Character = LocalPlayer.Character;
    local v26;

    if Character then
        v26 = Character:FindFirstChildOfClass("Humanoid");
    else
        v26 = Character;
    end;

    if v26 and (v26:GetState() ~= Enum.HumanoidStateType.Dead and Character:IsDescendantOf(workspace)) then
        local v27 = tick();
        local v28 = v27 - u25;
        u25 = v27;

        if u15 then
            if v28 < 0.4 then
                u12.noclip(false);
                u12.fly(false);
            end;
        elseif u13 then
            u14 = true;
            local Attribute = LocalPlayer:GetAttribute("_KNoClip");
            local Attribute2 = LocalPlayer:GetAttribute("_KFly");
            local v29 = LocalPlayer:GetAttribute("_KFlyConstant") and true or false;

            if Attribute then
                u12.noclip(Attribute2 and true or not u9);

                if not Attribute2 then
                    local v30;

                    if u9 then
                        v30 = `<font color="#{UI.Theme.Valid._value:ToHex()}">enabled`;
                    else
                        v30 = `<font color="#{UI.Theme.Invalid._value:ToHex()}">disabled`;
                    end;

                    Notify({
                        Text = `<b>Noclip {v30}</font>.</b>\nDouble tap <b>jump</b> to toggle.`
                    });
                end;
            end;

            if Attribute2 then
                u12.fly(true, v29);
            end;
        end;
    end;
end;

LocalPlayer:GetAttributeChangedSignal("_KFly"):Connect(function() -- Line: 182
    -- upvalues: LocalPlayer (copy), u1 (ref), u12 (copy), u15 (ref), Notify (copy)
    local Attribute = LocalPlayer:GetAttribute("_KFly");
    local v31 = LocalPlayer:GetAttribute("_KFlyConstant") and true or false;
    local Attribute2 = LocalPlayer:GetAttribute("_KNoClip");
    u1 = math.max(0, Attribute or 128);
    u12.fly(Attribute, v31);

    if not (u15 or (Attribute2 or not Attribute)) then
        Notify({
            Text = "Double tap <b>jump</b> to toggle fly."
        });
    end;
end);
LocalPlayer:GetAttributeChangedSignal("_KNoClip"):Connect(function() -- Line: 195
    -- upvalues: LocalPlayer (copy), u12 (copy), Notify (copy)
    local Attribute = LocalPlayer:GetAttribute("_KNoClip");
    u12.noclip(Attribute);

    if Attribute then
        Notify({
            Text = "Double tap <b>jump</b> to toggle noclip."
        });
    end;
end);

if LocalPlayer.Character then
    task.spawn(onCharacter, LocalPlayer.Character);
end;

LocalPlayer.CharacterAdded:Connect(onCharacter);
LocalPlayer.CharacterRemoving:Connect(function(p32) -- Line: 209
    -- upvalues: u21 (copy)
    if u21[p32] and u21[p32].Connected then
        u21[p32]:Disconnect();
    end;

    u21[p32] = nil;
end);
UserInputService.JumpRequest:Connect(onJumpRequest);

return u12;