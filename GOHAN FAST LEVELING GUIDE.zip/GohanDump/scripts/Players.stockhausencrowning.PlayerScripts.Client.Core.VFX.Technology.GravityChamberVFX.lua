-- Decompiled with Potassium's decompiler.

local ReplicatedStorage = game:GetService("ReplicatedStorage");
local UserInputService = game:GetService("UserInputService");
game:GetService("Debris");
local Players = game:GetService("Players");
local Modules = ReplicatedStorage:WaitForChild("Modules");
local Remotes = ReplicatedStorage:WaitForChild("Remotes");
local _ = ReplicatedStorage.Assets;
local _ = Modules.Metadata;
local Shared = Modules.Shared;
local GravityChamber = ReplicatedStorage.Assets.Gui.Tech.GravityChamber;
require(Modules.Utility.Create);
require(Shared.CinemaManager);
require(Modules.GlobalFunctions);
require(Shared.SoundManager);
local ServerRemote = Remotes.ServerRemote;
local LocalPlayer = Players.LocalPlayer;
local workspace_World = workspace.World;
local _ = workspace_World.Live;
local Technology = workspace_World.Map.Technology;
local u1 = {};

function Clean_Connections()
    -- upvalues: u1 (copy)
    for _, v in pairs(u1) do
        v:Disconnect();
    end;

    table.clear(u1);
end;

local Color3_fromRGB_ret = Color3.fromRGB(44, 44, 45);
local Color3_fromRGB_ret2 = Color3.fromRGB(28, 28, 30);
local Color3_fromRGB_ret3 = Color3.fromRGB(0, 0, 0);
local Color3_fromRGB_ret4 = Color3.fromRGB(255, 255, 255);
local Color3_fromRGB_ret5 = Color3.fromRGB(216, 213, 205);
local Color3_fromRGB_ret6 = Color3.fromRGB(150, 150, 150);
local Color3_fromRGB_ret7 = Color3.fromRGB(88, 214, 106);
local Color3_fromRGB_ret8 = Color3.fromRGB(255, 100, 100);
local Color3_fromRGB_ret9 = Color3.fromRGB(72, 160, 255);
local Arcade = Enum.Font.Arcade;
local Bangers = Enum.Font.Bangers;

local function stroke(p2) -- Line: 83
    -- upvalues: Color3_fromRGB_ret3 (copy)
    p2.TextStrokeColor3 = Color3_fromRGB_ret3;
    p2.TextStrokeTransparency = 0.5;

    return p2;
end;

local function outline(p3, p4) -- Line: 89
    -- upvalues: Color3_fromRGB_ret3 (copy)
    local UIStroke = Instance.new("UIStroke");
    UIStroke.Color = Color3_fromRGB_ret3;
    UIStroke.Thickness = p4 or 1.5;
    UIStroke.Parent = p3;

    return UIStroke;
end;

local function mkLabel(p5, p6, p7, p8, p9, p10) -- Line: 95
    -- upvalues: Color3_fromRGB_ret3 (copy)
    local TextLabel = Instance.new("TextLabel");
    TextLabel.BackgroundTransparency = 1;
    TextLabel.Font = p7;
    TextLabel.TextSize = p8;
    TextLabel.TextColor3 = p9;
    TextLabel.TextXAlignment = p10 or Enum.TextXAlignment.Left;
    TextLabel.Text = p6;
    TextLabel.Parent = p5;
    TextLabel.TextStrokeColor3 = Color3_fromRGB_ret3;
    TextLabel.TextStrokeTransparency = 0.5;

    return TextLabel;
end;

local function mkButton(p11, p12, p13, p14, p15) -- Line: 105
    -- upvalues: Color3_fromRGB_ret2 (copy), Arcade (copy), Color3_fromRGB_ret4 (copy), Color3_fromRGB_ret3 (copy)
    local TextButton = Instance.new("TextButton");
    TextButton.Size = p13;
    TextButton.Position = p14;
    TextButton.BackgroundColor3 = p15 or Color3_fromRGB_ret2;
    TextButton.BorderSizePixel = 0;
    TextButton.AutoButtonColor = true;
    TextButton.Selectable = true;
    TextButton.Font = Arcade;
    TextButton.TextSize = 12;
    TextButton.TextColor3 = Color3_fromRGB_ret4;
    TextButton.Text = p12;
    TextButton.Parent = p11;
    TextButton.TextStrokeColor3 = Color3_fromRGB_ret3;
    TextButton.TextStrokeTransparency = 0.5;
    local UIStroke = Instance.new("UIStroke");
    UIStroke.Color = Color3_fromRGB_ret3;
    UIStroke.Thickness = 1.5;
    UIStroke.Parent = TextButton;

    return TextButton;
end;

local function fireSetting(p16) -- Line: 120
    -- upvalues: ServerRemote (copy)
    p16.Module = "TechManager";
    p16.Action = "Gravity Chamber Settings";
    ServerRemote:FireServer(nil, p16);
end;

local function buildPanel(p17, u18, u19, u20) -- Line: 126
    -- upvalues: LocalPlayer (copy), Color3_fromRGB_ret (copy), Color3_fromRGB_ret3 (copy), Color3_fromRGB_ret9 (copy), Arcade (copy), Color3_fromRGB_ret4 (copy), Color3_fromRGB_ret2 (copy), Bangers (copy), Color3_fromRGB_ret5 (copy), ServerRemote (copy), Color3_fromRGB_ret6 (copy), Color3_fromRGB_ret7 (copy), Color3_fromRGB_ret8 (copy), u1 (copy)
    local GravityChamberPanel = LocalPlayer.PlayerGui:FindFirstChild("GravityChamberPanel");

    if GravityChamberPanel then
        GravityChamberPanel:Destroy();
    end;

    local ScreenGui = Instance.new("ScreenGui");
    ScreenGui.Name = "GravityChamberPanel";
    ScreenGui.ResetOnSpawn = false;
    ScreenGui.IgnoreGuiInset = true;
    ScreenGui.DisplayOrder = 30;
    ScreenGui.Enabled = false;
    ScreenGui.Parent = LocalPlayer.PlayerGui;
    local Frame = Instance.new("Frame");
    Frame.Name = "Card";
    Frame.AnchorPoint = Vector2.new(1, 0.5);
    Frame.Position = UDim2.new(1, -16, 0.5, 0);
    Frame.Size = UDim2.fromOffset(224, 236);
    Frame.BackgroundColor3 = Color3_fromRGB_ret;
    Frame.BorderSizePixel = 0;
    Frame.Parent = ScreenGui;
    local UIStroke = Instance.new("UIStroke");
    UIStroke.Color = Color3_fromRGB_ret3;
    UIStroke.Thickness = 2;
    UIStroke.Parent = Frame;
    local Frame2 = Instance.new("Frame");
    Frame2.BackgroundColor3 = Color3_fromRGB_ret9;
    Frame2.BorderSizePixel = 0;
    Frame2.Size = UDim2.new(1, 0, 0, 4);
    Frame2.Parent = Frame;
    local TextLabel = Instance.new("TextLabel");
    TextLabel.BackgroundTransparency = 1;
    TextLabel.Font = Arcade;
    TextLabel.TextSize = 12;
    TextLabel.TextColor3 = Color3_fromRGB_ret4;
    TextLabel.TextXAlignment = Enum.TextXAlignment.Left;
    TextLabel.Text = "GRAVITY CHAMBER";
    TextLabel.Parent = Frame;
    TextLabel.TextStrokeColor3 = Color3_fromRGB_ret3;
    TextLabel.TextStrokeTransparency = 0.5;
    TextLabel.Position = UDim2.fromOffset(10, 10);
    TextLabel.Size = UDim2.new(1, -20, 0, 16);
    local UDim2_fromOffset_ret = UDim2.fromOffset(44, 40);
    local UDim2_fromOffset_ret2, v21 = UDim2.fromOffset(10, 34);
    local TextButton = Instance.new("TextButton");
    TextButton.Size = UDim2_fromOffset_ret;
    TextButton.Position = UDim2_fromOffset_ret2;
    TextButton.BackgroundColor3 = v21 or Color3_fromRGB_ret2;
    TextButton.BorderSizePixel = 0;
    TextButton.AutoButtonColor = true;
    TextButton.Selectable = true;
    TextButton.Font = Arcade;
    TextButton.TextSize = 12;
    TextButton.TextColor3 = Color3_fromRGB_ret4;
    TextButton.Text = "-";
    TextButton.Parent = Frame;
    TextButton.TextStrokeColor3 = Color3_fromRGB_ret3;
    TextButton.TextStrokeTransparency = 0.5;
    local UIStroke2 = Instance.new("UIStroke");
    UIStroke2.Color = Color3_fromRGB_ret3;
    UIStroke2.Thickness = 1.5;
    UIStroke2.Parent = TextButton;
    TextButton.TextSize = 20;
    local UDim2_fromOffset_ret3 = UDim2.fromOffset(44, 40);
    local UDim2_fromOffset_ret4, v22 = UDim2.fromOffset(170, 34);
    local TextButton2 = Instance.new("TextButton");
    TextButton2.Size = UDim2_fromOffset_ret3;
    TextButton2.Position = UDim2_fromOffset_ret4;
    TextButton2.BackgroundColor3 = v22 or Color3_fromRGB_ret2;
    TextButton2.BorderSizePixel = 0;
    TextButton2.AutoButtonColor = true;
    TextButton2.Selectable = true;
    TextButton2.Font = Arcade;
    TextButton2.TextSize = 12;
    TextButton2.TextColor3 = Color3_fromRGB_ret4;
    TextButton2.Text = "+";
    TextButton2.Parent = Frame;
    TextButton2.TextStrokeColor3 = Color3_fromRGB_ret3;
    TextButton2.TextStrokeTransparency = 0.5;
    local UIStroke3 = Instance.new("UIStroke");
    UIStroke3.Color = Color3_fromRGB_ret3;
    UIStroke3.Thickness = 1.5;
    UIStroke3.Parent = TextButton2;
    TextButton2.TextSize = 20;
    local Center = Enum.TextXAlignment.Center;
    local TextLabel2 = Instance.new("TextLabel");
    TextLabel2.BackgroundTransparency = 1;
    TextLabel2.Font = Bangers;
    TextLabel2.TextSize = 26;
    TextLabel2.TextColor3 = Color3_fromRGB_ret9;
    TextLabel2.TextXAlignment = Center or Enum.TextXAlignment.Left;
    TextLabel2.Text = "0 G";
    TextLabel2.Parent = Frame;
    TextLabel2.TextStrokeColor3 = Color3_fromRGB_ret3;
    TextLabel2.TextStrokeTransparency = 0.5;
    TextLabel2.Position = UDim2.fromOffset(58, 34);
    TextLabel2.Size = UDim2.fromOffset(108, 40);

    local function refreshReadout() -- Line: 168
        -- upvalues: TextLabel2 (copy), u20 (copy)
        TextLabel2.Text = tostring(u20.Value) .. " G";
    end;

    TextLabel2.Text = tostring(u20.Value) .. " G";
    local TextLabel3 = Instance.new("TextLabel");
    TextLabel3.BackgroundTransparency = 1;
    TextLabel3.Font = Arcade;
    TextLabel3.TextSize = 10;
    TextLabel3.TextColor3 = Color3_fromRGB_ret5;
    TextLabel3.TextXAlignment = Enum.TextXAlignment.Left;
    TextLabel3.Text = "TRAINING";
    TextLabel3.Parent = Frame;
    TextLabel3.TextStrokeColor3 = Color3_fromRGB_ret3;
    TextLabel3.TextStrokeTransparency = 0.5;
    TextLabel3.Position = UDim2.fromOffset(10, 84);
    TextLabel3.Size = UDim2.new(1, -20, 0, 14);
    local math_max_ret = math.max(#p17, 1);
    local math_floor_ret = math.floor((204 - (math_max_ret - 1) * 6) / math_max_ret);
    local u23 = {};

    for i, v in ipairs(p17) do
        local string_upper_ret = string.upper(v);
        local UDim2_fromOffset_ret5 = UDim2.fromOffset(math_floor_ret, 32);
        local UDim2_fromOffset_ret6, v24 = UDim2.fromOffset(10 + (i - 1) * (math_floor_ret + 6), 102);
        local TextButton3 = Instance.new("TextButton");
        TextButton3.Size = UDim2_fromOffset_ret5;
        TextButton3.Position = UDim2_fromOffset_ret6;
        TextButton3.BackgroundColor3 = v24 or Color3_fromRGB_ret2;
        TextButton3.BorderSizePixel = 0;
        TextButton3.AutoButtonColor = true;
        TextButton3.Selectable = true;
        TextButton3.Font = Arcade;
        TextButton3.TextSize = 12;
        TextButton3.TextColor3 = Color3_fromRGB_ret4;
        TextButton3.Text = string_upper_ret;
        TextButton3.Parent = Frame;
        TextButton3.TextStrokeColor3 = Color3_fromRGB_ret3;
        TextButton3.TextStrokeTransparency = 0.5;
        local UIStroke4 = Instance.new("UIStroke");
        UIStroke4.Color = Color3_fromRGB_ret3;
        UIStroke4.Thickness = 1.5;
        UIStroke4.Parent = TextButton3;
        TextButton3.TextSize = 11;
        u23[v] = TextButton3;
        TextButton3.Activated:Connect(function() -- Line: 186
            -- upvalues: u19 (copy), v (copy), ServerRemote (ref)
            if u19.Value == false then
                ServerRemote:FireServer(nil, {
                    CurrentTrainingState = v,
                    Module = "TechManager",
                    Action = "Gravity Chamber Settings"
                });
            end;
        end);
    end;

    local function refreshOptions() -- Line: 193
        -- upvalues: u23 (copy), u18 (copy), Color3_fromRGB_ret9 (ref), Color3_fromRGB_ret2 (ref), Color3_fromRGB_ret4 (ref)
        for i, v in pairs(u23) do
            v.BackgroundColor3 = u18.Value == i and Color3_fromRGB_ret9 or Color3_fromRGB_ret2;
            v.TextColor3 = Color3_fromRGB_ret4;
            v.TextStrokeTransparency = 0.5;
        end;
    end;

    refreshOptions();
    local TextLabel4 = Instance.new("TextLabel");
    TextLabel4.BackgroundTransparency = 1;
    TextLabel4.Font = Bangers;
    TextLabel4.TextSize = 12;
    TextLabel4.TextColor3 = Color3_fromRGB_ret6;
    TextLabel4.TextXAlignment = Enum.TextXAlignment.Left;
    TextLabel4.Text = "";
    TextLabel4.Parent = Frame;
    TextLabel4.TextStrokeColor3 = Color3_fromRGB_ret3;
    TextLabel4.TextStrokeTransparency = 0.5;
    TextLabel4.Position = UDim2.fromOffset(10, 140);
    TextLabel4.Size = UDim2.new(1, -20, 0, 14);
    TextLabel4.TextTruncate = Enum.TextTruncate.AtEnd;
    local TextLabel5 = Instance.new("TextLabel");
    TextLabel5.BackgroundTransparency = 1;
    TextLabel5.Font = Bangers;
    TextLabel5.TextSize = 12;
    TextLabel5.TextColor3 = Color3_fromRGB_ret5;
    TextLabel5.TextXAlignment = Enum.TextXAlignment.Left;
    TextLabel5.Text = 4500 .. " ZENI TO START";
    TextLabel5.Parent = Frame;
    TextLabel5.TextStrokeColor3 = Color3_fromRGB_ret3;
    TextLabel5.TextStrokeTransparency = 0.5;
    TextLabel5.Position = UDim2.fromOffset(10, 156);
    TextLabel5.Size = UDim2.new(1, -20, 0, 14);
    local UDim2_new_ret = UDim2.new(1, -20, 0, 40);
    local UDim2_fromOffset_ret5 = UDim2.fromOffset(10, 182);
    local TextButton3 = Instance.new("TextButton");
    TextButton3.Size = UDim2_new_ret;
    TextButton3.Position = UDim2_fromOffset_ret5;
    TextButton3.BackgroundColor3 = Color3_fromRGB_ret7 or Color3_fromRGB_ret2;
    TextButton3.BorderSizePixel = 0;
    TextButton3.AutoButtonColor = true;
    TextButton3.Selectable = true;
    TextButton3.Font = Arcade;
    TextButton3.TextSize = 12;
    TextButton3.TextColor3 = Color3_fromRGB_ret4;
    TextButton3.Text = "START";
    TextButton3.Parent = Frame;
    TextButton3.TextStrokeColor3 = Color3_fromRGB_ret3;
    TextButton3.TextStrokeTransparency = 0.5;
    local UIStroke4 = Instance.new("UIStroke");
    UIStroke4.Color = Color3_fromRGB_ret3;
    UIStroke4.Thickness = 1.5;
    UIStroke4.Parent = TextButton3;
    TextButton3.TextColor3 = Color3_fromRGB_ret4;
    TextButton3.TextStrokeTransparency = 0.5;
    TextButton3.TextSize = 14;

    local function refreshTraining() -- Line: 218
        -- upvalues: u19 (copy), TextButton3 (copy), Color3_fromRGB_ret8 (ref), Color3_fromRGB_ret7 (ref), TextLabel4 (copy), u18 (copy)
        local v25 = u19.Value == true;
        TextButton3.BackgroundColor3 = v25 and Color3_fromRGB_ret8 or Color3_fromRGB_ret7;
        TextButton3.Text = v25 and "ENTER TRAINING ZONE" or "START";
        TextLabel4.Text = v25 and "Running: " .. tostring(u18.Value) or "Pick a type, set gravity, start";
    end;

    local v26 = u19.Value == true;
    TextButton3.BackgroundColor3 = v26 and Color3_fromRGB_ret8 or Color3_fromRGB_ret7;
    TextButton3.Text = v26 and "ENTER TRAINING ZONE" or "START";
    TextLabel4.Text = v26 and ("Running: " .. tostring(u18.Value) or "Pick a type, set gravity, start") or "Pick a type, set gravity, start";
    TextButton.Activated:Connect(function() -- Line: 226
        -- upvalues: ServerRemote (ref)
        ServerRemote:FireServer(nil, {
            decrease_Gravity = true,
            Module = "TechManager",
            Action = "Gravity Chamber Settings"
        });
    end);
    TextButton2.Activated:Connect(function() -- Line: 227
        -- upvalues: ServerRemote (ref)
        ServerRemote:FireServer(nil, {
            increase_Gravity = true,
            Module = "TechManager",
            Action = "Gravity Chamber Settings"
        });
    end);
    TextButton3.Activated:Connect(function() -- Line: 228
        -- upvalues: u19 (copy), ServerRemote (ref)
        if u19.Value == false then
            ServerRemote:FireServer(nil, {
                is_Training = true,
                Module = "TechManager",
                Action = "Gravity Chamber Settings"
            });
        end;
    end);
    table.insert(u1, u20.Changed:Connect(refreshReadout));
    table.insert(u1, u18.Changed:Connect(refreshOptions));
    table.insert(u1, u19.Changed:Connect(refreshTraining));

    return ScreenGui, TextButton2;
end;

local function bindProximity(u27, u28, u29) -- Line: 243
    -- upvalues: LocalPlayer (copy), UserInputService (copy), u1 (copy)
    local RunService = game:GetService("RunService");
    local GuiService = game:GetService("GuiService");
    local u30 = 0;
    local v32 = RunService.Heartbeat:Connect(function(p31) -- Line: 247
        -- upvalues: u30 (ref), u27 (copy), u29 (copy), LocalPlayer (ref), GuiService (copy), UserInputService (ref), u28 (copy)
        u30 = u30 + p31;

        if u30 < 0.15 then
            return;
        end;

        u30 = 0;

        if not (u27.Parent and u29.Parent) then
            return;
        end;

        local Character = LocalPlayer.Character;

        if Character then
            Character = Character:FindFirstChild("HumanoidRootPart");
        end;

        if not Character then
            if u27.Enabled then
                u27.Enabled = false;
            end;

            return;
        end;

        local Magnitude = (u29.Position - Character.Position).Magnitude;

        if u27.Enabled then
            if Magnitude > 46 then
                u27.Enabled = false;

                if GuiService.SelectedObject and GuiService.SelectedObject:IsDescendantOf(u27) then
                    GuiService.SelectedObject = nil;
                end;
            end;
        elseif Magnitude <= 40 then
            u27.Enabled = true;

            if UserInputService.GamepadEnabled and UserInputService:GetLastInputType().Name:find("Gamepad") then
                GuiService.SelectedObject = u28;
            end;
        end;
    end);
    table.insert(u1, v32);
end;

return {
    ["Gravity Chamber Gui"] = function(p33) -- Line: 277
        -- upvalues: Technology (copy), GravityChamber (copy), LocalPlayer (copy), u1 (copy), buildPanel (copy), bindProximity (copy)
        local OptionTypes = p33.OptionTypes;
        local CurrentTrainingState = p33.CurrentTrainingState;
        local is_Training = p33.is_Training;
        ({
            On = function() -- Line: 284
                -- upvalues: Technology (ref), GravityChamber (ref), LocalPlayer (ref), CurrentTrainingState (copy), u1 (ref), buildPanel (ref), OptionTypes (copy), is_Training (copy), bindProximity (ref)
                local v34 = Technology["Gravity Chamber"]["Gravity Machine"];
                local u35 = GravityChamber["TrainingState Gui"]:Clone();
                u35.Parent = LocalPlayer.PlayerGui;
                u35.Adornee = v34.TrainingState;
                local v37 = CurrentTrainingState.Changed:Connect(function(p36) -- Line: 293
                    -- upvalues: u35 (copy)
                    u35.TextLabel.Text = p36;
                end);
                table.insert(u1, v37);
                local v38, v39 = buildPanel(OptionTypes, CurrentTrainingState, is_Training, v34.GravityValue);
                bindProximity(v38, v39, v34.Options);
            end,

            Off = function() -- Line: 302
                -- upvalues: LocalPlayer (ref)
                local v40 = { "GravitySetterGui", "GravityNumberSetterGui", "Option Gui", "TrainingState Gui", "GravityChamberPanel" };

                for _, child in pairs(LocalPlayer.PlayerGui:GetChildren()) do
                    if table.find(v40, child.Name) then
                        child:Destroy();
                    end;
                end;

                Clean_Connections();
            end
        })[p33.Action]();
    end
};