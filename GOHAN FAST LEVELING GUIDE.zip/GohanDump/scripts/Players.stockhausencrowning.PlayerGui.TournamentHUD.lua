-- Decompiled with Potassium's decompiler.

local Players = game:GetService("Players");
local ReplicatedStorage = game:GetService("ReplicatedStorage");
local UserInputService = game:GetService("UserInputService");
local LocalPlayer = Players.LocalPlayer;
local Remotes = ReplicatedStorage:WaitForChild("Remotes");
local TournamentRemote = Remotes:WaitForChild("TournamentRemote");
local GetTournamentStatus = Remotes:WaitForChild("GetTournamentStatus");
local Color3_fromRGB_ret = Color3.fromRGB(44, 44, 45);
local Color3_fromRGB_ret2 = Color3.fromRGB(28, 28, 30);
local Color3_fromRGB_ret3 = Color3.fromRGB(0, 0, 0);
local Color3_fromRGB_ret4 = Color3.fromRGB(255, 255, 255);
local Color3_fromRGB_ret5 = Color3.fromRGB(216, 213, 205);
local Color3_fromRGB_ret6 = Color3.fromRGB(90, 200, 255);
local Color3_fromRGB_ret7 = Color3.fromRGB(120, 255, 140);
local Color3_fromRGB_ret8 = Color3.fromRGB(90, 200, 120);
local Color3_fromRGB_ret9 = Color3.fromRGB(226, 62, 48);
local Color3_fromRGB_ret10 = Color3.fromRGB(255, 120, 120);
local Arcade = Enum.Font.Arcade;
local Bangers = Enum.Font.Bangers;
local ScreenGui = Instance.new("ScreenGui");
ScreenGui.Name = "TournamentHUDGui";
ScreenGui.ResetOnSpawn = false;
ScreenGui.DisplayOrder = 6;
ScreenGui.Parent = LocalPlayer:WaitForChild("PlayerGui");

local function outline(p1, p2) -- Line: 49
    -- upvalues: Color3_fromRGB_ret3 (copy)
    local UIStroke = Instance.new("UIStroke");
    UIStroke.Color = Color3_fromRGB_ret3;
    UIStroke.Thickness = p2 or 1.5;
    UIStroke.Parent = p1;

    return UIStroke;
end;

local function stroked(p3) -- Line: 57
    -- upvalues: Color3_fromRGB_ret3 (copy)
    p3.TextStrokeColor3 = Color3_fromRGB_ret3;
    p3.TextStrokeTransparency = 0.5;

    return p3;
end;

local function label(p4, p5, p6, p7, p8, p9, p10, p11) -- Line: 63
    -- upvalues: Color3_fromRGB_ret3 (copy)
    local TextLabel = Instance.new("TextLabel");
    TextLabel.BackgroundTransparency = 1;
    TextLabel.Position = p5;
    TextLabel.Size = p6;
    TextLabel.Font = p7;
    TextLabel.TextSize = p8;
    TextLabel.TextColor3 = p9;
    TextLabel.Text = p10;
    TextLabel.TextXAlignment = p11 or Enum.TextXAlignment.Center;
    TextLabel.TextTruncate = Enum.TextTruncate.AtEnd;
    TextLabel.TextStrokeColor3 = Color3_fromRGB_ret3;
    TextLabel.TextStrokeTransparency = 0.5;
    TextLabel.Parent = p4;

    return TextLabel;
end;

local Frame = Instance.new("Frame");
Frame.Name = "MatchCard";
Frame.Size = UDim2.new(0, 360, 0, 100);
Frame.Position = UDim2.new(0.5, -180, 0, 12);
Frame.BackgroundColor3 = Color3_fromRGB_ret;
Frame.BorderSizePixel = 0;
Frame.Visible = false;
Frame.Parent = ScreenGui;
local UIStroke = Instance.new("UIStroke");
UIStroke.Color = Color3_fromRGB_ret3;
UIStroke.Thickness = 1.5;
UIStroke.Parent = Frame;
local UDim2_new_ret = UDim2.new(0, 8, 0, 4);
local UDim2_new_ret2 = UDim2.new(1, -16, 0, 16);
local TextLabel = Instance.new("TextLabel");
TextLabel.BackgroundTransparency = 1;
TextLabel.Position = UDim2_new_ret;
TextLabel.Size = UDim2_new_ret2;
TextLabel.Font = Arcade;
TextLabel.TextSize = 14;
TextLabel.TextColor3 = Color3_fromRGB_ret6;
TextLabel.Text = "MATCH TIME";
TextLabel.TextXAlignment = Enum.TextXAlignment.Center;
TextLabel.TextTruncate = Enum.TextTruncate.AtEnd;
TextLabel.TextStrokeColor3 = Color3_fromRGB_ret3;
TextLabel.TextStrokeTransparency = 0.5;
TextLabel.Parent = Frame;
local UDim2_new_ret3 = UDim2.new(0, 0, 0, 20);
local UDim2_new_ret4 = UDim2.new(1, 0, 0, 32);
local TextLabel2 = Instance.new("TextLabel");
TextLabel2.BackgroundTransparency = 1;
TextLabel2.Position = UDim2_new_ret3;
TextLabel2.Size = UDim2_new_ret4;
TextLabel2.Font = Bangers;
TextLabel2.TextSize = 30;
TextLabel2.TextColor3 = Color3_fromRGB_ret5;
TextLabel2.Text = "0:00";
TextLabel2.TextXAlignment = Enum.TextXAlignment.Center;
TextLabel2.TextTruncate = Enum.TextTruncate.AtEnd;
TextLabel2.TextStrokeColor3 = Color3_fromRGB_ret3;
TextLabel2.TextStrokeTransparency = 0.5;
TextLabel2.Parent = Frame;

local function healthBar(p12, p13) -- Line: 94
    -- upvalues: Frame (copy), Arcade (copy), Color3_fromRGB_ret4 (copy), Color3_fromRGB_ret3 (copy), Color3_fromRGB_ret2 (copy), Color3_fromRGB_ret8 (copy)
    local v14 = p13 and Enum.TextXAlignment.Right or Enum.TextXAlignment.Left;
    local UDim2_new_ret5 = UDim2.new(p12, 8, 0, 56);
    local UDim2_new_ret6 = UDim2.new(0.5, -16, 0, 14);
    local TextLabel3 = Instance.new("TextLabel");
    TextLabel3.BackgroundTransparency = 1;
    TextLabel3.Position = UDim2_new_ret5;
    TextLabel3.Size = UDim2_new_ret6;
    TextLabel3.Font = Arcade;
    TextLabel3.TextSize = 12;
    TextLabel3.TextColor3 = Color3_fromRGB_ret4;
    TextLabel3.Text = "";
    TextLabel3.TextXAlignment = v14 or Enum.TextXAlignment.Center;
    TextLabel3.TextTruncate = Enum.TextTruncate.AtEnd;
    TextLabel3.TextStrokeColor3 = Color3_fromRGB_ret3;
    TextLabel3.TextStrokeTransparency = 0.5;
    TextLabel3.Parent = Frame;
    local Frame2 = Instance.new("Frame");
    Frame2.Position = UDim2.new(p12, 8, 0, 74);
    Frame2.Size = UDim2.new(0.5, -16, 0, 12);
    Frame2.BackgroundColor3 = Color3_fromRGB_ret2;
    Frame2.BorderSizePixel = 0;
    Frame2.Parent = Frame;
    local UIStroke2 = Instance.new("UIStroke");
    UIStroke2.Color = Color3_fromRGB_ret3;
    UIStroke2.Thickness = 1.5;
    UIStroke2.Parent = Frame2;
    local Frame3 = Instance.new("Frame");
    Frame3.Size = UDim2.new(1, 0, 1, 0);
    Frame3.BackgroundColor3 = Color3_fromRGB_ret8;
    Frame3.BorderSizePixel = 0;

    if p13 then
        Frame3.AnchorPoint = Vector2.new(1, 0);
        Frame3.Position = UDim2.new(1, 0, 0, 0);
    end;

    Frame3.Parent = Frame2;

    return {
        Name = TextLabel3,
        Fill = Frame3,
        Track = Frame2
    };
end;

local u15 = healthBar(0, false);
local u16 = healthBar(0.5, true);
local u17 = nil;
local u18 = 0;
local u19 = nil;
local u20 = nil;
local u21 = "";

local function fighterPlayer(p22) -- Line: 125
    -- upvalues: Players (copy)
    return p22 and Players:GetPlayerByUserId(p22) or nil;
end;

local function fighterHumanoid(p23) -- Line: 129
    -- upvalues: Players (copy)
    local v24 = p23 and Players:GetPlayerByUserId(p23) or nil;

    if v24 then
        v24 = v24.Character;
    end;

    if v24 then
        v24 = v24:FindFirstChildOfClass("Humanoid");
    end;

    if v24 and v24.Health > 0 then
        return v24;
    end;

    return nil;
end;

local function fighterName(p25) -- Line: 137
    -- upvalues: Players (copy)
    local v26 = p25 and Players:GetPlayerByUserId(p25) or nil;

    return v26 and v26.DisplayName or "?";
end;

local function myMatch() -- Line: 142
    -- upvalues: u19 (ref), LocalPlayer (copy), u20 (ref)
    return u19 == LocalPlayer.UserId and true or u20 == LocalPlayer.UserId;
end;

local function setCard(p27, p28) -- Line: 146
    -- upvalues: u17 (ref), u18 (ref), TextLabel (copy), u21 (ref), u15 (copy), u16 (copy), Frame (copy)
    u17 = p27;
    u18 = p28 or 0;
    local v29 = p27 == "match";

    if v29 then
        TextLabel.Text = string.upper(u21 == "" and "MATCH TIME" or (u21 or "MATCH TIME"));
    elseif p27 == "prep" then
        TextLabel.Text = "WMAT BEGINS IN";
    end;

    for _, v in ipairs({ u15, u16 }) do
        v.Name.Visible = v29;
        v.Track.Visible = v29;
    end;

    Frame.Size = UDim2.new(0, 360, 0, v29 and 100 or 60);
    Frame.Visible = p27 ~= nil;
end;

local function refreshBar(p30, p31) -- Line: 163
    -- upvalues: Players (copy), Color3_fromRGB_ret9 (copy), Color3_fromRGB_ret8 (copy)
    local Name = p30.Name;
    local v32;

    if p31 then
        v32 = Players:GetPlayerByUserId(p31) or nil;
    else
        v32 = nil;
    end;

    Name.Text = v32 and v32.DisplayName or "?";
    local v33 = p31 and Players:GetPlayerByUserId(p31) or nil;

    if v33 then
        v33 = v33.Character;
    end;

    if v33 then
        v33 = v33:FindFirstChildOfClass("Humanoid");
    end;

    if not v33 or v33.Health <= 0 then
        v33 = nil;
    end;

    local v34;

    if v33 then
        local v35 = v33.Health / math.max(1, v33.MaxHealth);
        v34 = math.clamp(v35, 0, 1) or 0;
    else
        v34 = 0;
    end;

    p30.Fill.Size = UDim2.new(v34, 0, 1, 0);
    p30.Fill.BackgroundColor3 = v34 <= 0.3 and Color3_fromRGB_ret9 or Color3_fromRGB_ret8;
end;

local workspace_CurrentCamera = workspace.CurrentCamera;
local u36 = nil;
local Frame2 = Instance.new("Frame");
Frame2.Name = "Spectate";
Frame2.Size = UDim2.new(0, 190, 0, 118);
Frame2.Position = UDim2.new(1, -206, 0.5, -59);
Frame2.BackgroundTransparency = 1;
Frame2.Visible = false;
Frame2.Parent = ScreenGui;

local function specButton(p37, p38, p39) -- Line: 185
    -- upvalues: Color3_fromRGB_ret (copy), Arcade (copy), Color3_fromRGB_ret6 (copy), Frame2 (copy), Color3_fromRGB_ret3 (copy)
    local TextButton = Instance.new("TextButton");
    TextButton.Size = UDim2.new(1, 0, 0, 36);
    TextButton.Position = UDim2.new(0, 0, 0, p38);
    TextButton.BackgroundColor3 = Color3_fromRGB_ret;
    TextButton.BorderSizePixel = 0;
    TextButton.Font = Arcade;
    TextButton.TextSize = 15;
    TextButton.TextColor3 = p39 or Color3_fromRGB_ret6;
    TextButton.Text = p37;
    TextButton.AutoButtonColor = true;
    TextButton.Selectable = true;
    TextButton.Parent = Frame2;
    local UIStroke2 = Instance.new("UIStroke");
    UIStroke2.Color = Color3_fromRGB_ret3;
    UIStroke2.Thickness = 1.5;
    UIStroke2.Parent = TextButton;
    TextButton.TextStrokeColor3 = Color3_fromRGB_ret3;
    TextButton.TextStrokeTransparency = 0.5;

    return TextButton;
end;

local u40 = specButton("SPECTATE", 0);
local u41 = specButton("SWITCH FIGHTER", 0);
local u42 = specButton("STOP SPECTATING", 42, Color3_fromRGB_ret10);
local UDim2_new_ret5 = UDim2.new(0, 0, 0, 84);
local UDim2_new_ret6 = UDim2.new(1, 0, 0, 14);
local TextLabel3 = Instance.new("TextLabel");
TextLabel3.BackgroundTransparency = 1;
TextLabel3.Position = UDim2_new_ret5;
TextLabel3.Size = UDim2_new_ret6;
TextLabel3.Font = Arcade;
TextLabel3.TextSize = 11;
TextLabel3.TextColor3 = Color3_fromRGB_ret5;
TextLabel3.Text = "";
TextLabel3.TextXAlignment = Enum.TextXAlignment.Center;
TextLabel3.TextTruncate = Enum.TextTruncate.AtEnd;
TextLabel3.TextStrokeColor3 = Color3_fromRGB_ret3;
TextLabel3.TextStrokeTransparency = 0.5;
TextLabel3.Parent = Frame2;
local UDim2_new_ret7 = UDim2.new(0, 0, 0, 100);
local UDim2_new_ret8 = UDim2.new(1, 0, 0, 14);
local TextLabel4 = Instance.new("TextLabel");
TextLabel4.BackgroundTransparency = 1;
TextLabel4.Position = UDim2_new_ret7;
TextLabel4.Size = UDim2_new_ret8;
TextLabel4.Font = Arcade;
TextLabel4.TextSize = 10;
TextLabel4.TextColor3 = Color3_fromRGB_ret5;
TextLabel4.Text = "";
TextLabel4.TextXAlignment = Enum.TextXAlignment.Center;
TextLabel4.TextTruncate = Enum.TextTruncate.AtEnd;
TextLabel4.TextStrokeColor3 = Color3_fromRGB_ret3;
TextLabel4.TextStrokeTransparency = 0.5;
TextLabel4.Parent = Frame2;
TextLabel4.TextTransparency = 0.35;

local function myHumanoid() -- Line: 210
    -- upvalues: LocalPlayer (copy)
    local Character = LocalPlayer.Character;

    if Character then
        Character = Character:FindFirstChildOfClass("Humanoid");
    end;

    return Character;
end;

local function specHint() -- Line: 215
    -- upvalues: UserInputService (copy)
    return UserInputService.GamepadEnabled and not UserInputService.KeyboardEnabled and "DPAD LEFT: SWITCH" or (UserInputService.TouchEnabled and not UserInputService.KeyboardEnabled and "" or "Q: SWITCH");
end;

local function refreshSpecButtons() -- Line: 221
    -- upvalues: u36 (ref), u40 (copy), u41 (copy), u42 (copy), TextLabel3 (copy), TextLabel4 (copy), UserInputService (copy)
    local v43 = u36 ~= nil;
    u40.Visible = not v43;
    u41.Visible = v43;
    u42.Visible = v43;
    TextLabel3.Visible = v43;
    TextLabel4.Visible = v43;
    TextLabel4.Text = v43 and (UserInputService.GamepadEnabled and not UserInputService.KeyboardEnabled and "DPAD LEFT: SWITCH" or (UserInputService.TouchEnabled and not UserInputService.KeyboardEnabled and "" or "Q: SWITCH") or "") or "";
end;

local function stopSpectate() -- Line: 231
    -- upvalues: u36 (ref), workspace_CurrentCamera (copy), LocalPlayer (copy), u40 (copy), u41 (copy), u42 (copy), TextLabel3 (copy), TextLabel4 (copy), UserInputService (copy)
    if u36 == nil then
        return;
    end;

    u36 = nil;
    workspace_CurrentCamera.CameraType = Enum.CameraType.Custom;
    local Character = LocalPlayer.Character;

    if Character then
        Character = Character:FindFirstChildOfClass("Humanoid");
    end;

    if Character then
        workspace_CurrentCamera.CameraSubject = Character;
    end;

    local v44 = u36 ~= nil;
    u40.Visible = not v44;
    u41.Visible = v44;
    u42.Visible = v44;
    TextLabel3.Visible = v44;
    TextLabel4.Visible = v44;
    TextLabel4.Text = v44 and (UserInputService.GamepadEnabled and not UserInputService.KeyboardEnabled and "DPAD LEFT: SWITCH" or (UserInputService.TouchEnabled and not UserInputService.KeyboardEnabled and "" or "Q: SWITCH") or "") or "";
end;

local function applySpectate() -- Line: 240
    -- upvalues: u36 (ref), u20 (ref), u19 (ref), Players (copy), workspace_CurrentCamera (copy), LocalPlayer (copy), u40 (copy), u41 (copy), u42 (copy), TextLabel3 (copy), TextLabel4 (copy), UserInputService (copy)
    local v45 = u36 == 2 and u20 or u19;
    local v46;

    if v45 then
        v46 = Players:GetPlayerByUserId(v45) or nil;
    else
        v46 = nil;
    end;

    if v46 then
        v46 = v46.Character;
    end;

    if v46 then
        v46 = v46:FindFirstChildOfClass("Humanoid");
    end;

    if not v46 or v46.Health <= 0 then
        v46 = nil;
    end;

    local v47;

    if v46 then
        v47 = v45;
    else
        local v48 = u36 == 2 and 1 or 2;
        v47 = v48 == 2 and u20 or u19;

        if v47 then
            v46 = Players:GetPlayerByUserId(v47) or nil;
        else
            v46 = nil;
        end;

        if v46 then
            v46 = v46.Character;
        end;

        if v46 then
            v46 = v46:FindFirstChildOfClass("Humanoid");
        end;

        if not v46 or v46.Health <= 0 then
            v46 = nil;
        end;

        if v46 then
            u36 = v48;
        else
            v47 = v45;
        end;
    end;

    if v46 then
        workspace_CurrentCamera.CameraType = Enum.CameraType.Custom;

        if workspace_CurrentCamera.CameraSubject ~= v46 then
            workspace_CurrentCamera.CameraSubject = v46;
        end;

        local string_upper = string.upper;
        local v49 = v47 and Players:GetPlayerByUserId(v47) or nil;
        TextLabel3.Text = "WATCHING: " .. string_upper(v49 and v49.DisplayName or "?");

        return;
    end;

    if u36 == nil then
        return;
    end;

    u36 = nil;
    workspace_CurrentCamera.CameraType = Enum.CameraType.Custom;
    local Character = LocalPlayer.Character;

    if Character then
        Character = Character:FindFirstChildOfClass("Humanoid");
    end;

    if Character then
        workspace_CurrentCamera.CameraSubject = Character;
    end;

    local v50 = u36 ~= nil;
    u40.Visible = not v50;
    u41.Visible = v50;
    u42.Visible = v50;
    TextLabel3.Visible = v50;
    TextLabel4.Visible = v50;
    TextLabel4.Text = v50 and (UserInputService.GamepadEnabled and not UserInputService.KeyboardEnabled and "DPAD LEFT: SWITCH" or (UserInputService.TouchEnabled and not UserInputService.KeyboardEnabled and "" or "Q: SWITCH") or "") or "";
end;

local function startSpectate(p51) -- Line: 256
    -- upvalues: u19 (ref), u20 (ref), u36 (ref), u40 (copy), u41 (copy), u42 (copy), TextLabel3 (copy), TextLabel4 (copy), UserInputService (copy), applySpectate (copy)
    if not (u19 or u20) then
        return;
    end;

    u36 = p51 or 1;
    local v52 = u36 ~= nil;
    u40.Visible = not v52;
    u41.Visible = v52;
    u42.Visible = v52;
    TextLabel3.Visible = v52;
    TextLabel4.Visible = v52;
    TextLabel4.Text = v52 and (UserInputService.GamepadEnabled and not UserInputService.KeyboardEnabled and "DPAD LEFT: SWITCH" or (UserInputService.TouchEnabled and not UserInputService.KeyboardEnabled and "" or "Q: SWITCH") or "") or "";
    applySpectate();
end;

local function switchSpectate() -- Line: 263
    -- upvalues: u36 (ref), applySpectate (copy)
    if u36 == nil then
        return;
    end;

    u36 = u36 == 1 and 2 or 1;
    applySpectate();
end;

u40.Activated:Connect(function() -- Line: 269
    -- upvalues: u19 (ref), u20 (ref), u36 (ref), u40 (copy), u41 (copy), u42 (copy), TextLabel3 (copy), TextLabel4 (copy), UserInputService (copy), applySpectate (copy)
    if not (u19 or u20) then
        return;
    end;

    u36 = 1;
    local v53 = u36 ~= nil;
    u40.Visible = not v53;
    u41.Visible = v53;
    u42.Visible = v53;
    TextLabel3.Visible = v53;
    TextLabel4.Visible = v53;
    TextLabel4.Text = v53 and (UserInputService.GamepadEnabled and not UserInputService.KeyboardEnabled and "DPAD LEFT: SWITCH" or (UserInputService.TouchEnabled and not UserInputService.KeyboardEnabled and "" or "Q: SWITCH") or "") or "";
    applySpectate();
end);
u41.Activated:Connect(switchSpectate);
u42.Activated:Connect(stopSpectate);
UserInputService.InputBegan:Connect(function(p54, p55) -- Line: 273
    -- upvalues: u36 (ref), applySpectate (copy)
    if p55 or u36 == nil then
        return;
    end;

    if p54.KeyCode == Enum.KeyCode.Q or p54.KeyCode == Enum.KeyCode.DPadLeft then
        if u36 == nil then
            return;
        end;

        u36 = u36 == 1 and 2 or 1;
        applySpectate();
    end;
end);
local u56 = nil;

local function findVenuePart() -- Line: 282
    -- upvalues: u56 (ref)
    if u56 and u56.Parent then
        return u56;
    end;

    local World = workspace:FindFirstChild("World");
    local v57 = World and World:FindFirstChild("Map") and World.Map:FindFirstChild("Zones");

    if v57 then
        v57 = v57:FindFirstChild("World Martial Arts Tournament") or v57:FindFirstChild("World Martial Arts Arena");
    end;

    local v58;

    if v57 then
        v58 = v57.PrimaryPart or v57:FindFirstChildWhichIsA("BasePart") or nil;
    else
        v58 = nil;
    end;

    u56 = v58;

    return u56;
end;

local function insideVenue() -- Line: 291
    -- upvalues: findVenuePart (copy), LocalPlayer (copy)
    local v59 = findVenuePart();
    local Character = LocalPlayer.Character;

    if Character then
        Character = Character:FindFirstChild("HumanoidRootPart");
    end;

    if not (v59 and Character) then
        return false;
    end;

    local v60 = v59.CFrame:PointToObjectSpace(Character.Position);
    local v61 = v59.Size / 2;
    local v62;

    if math.abs(v60.X) <= v61.X and math.abs(v60.Y) <= v61.Y then
        v62 = math.abs(v60.Z) <= v61.Z;
    else
        v62 = false;
    end;

    return v62;
end;

task.spawn(function() -- Line: 306
    -- upvalues: u17 (ref), u18 (ref), TextLabel2 (copy), Color3_fromRGB_ret10 (copy), Color3_fromRGB_ret5 (copy), refreshBar (copy), u15 (copy), u19 (ref), u16 (copy), u20 (ref), Color3_fromRGB_ret7 (copy), setCard (copy)
    while true do
        repeat
            task.wait(0.1);
        until u17;

        local v63 = u18 - workspace:GetServerTimeNow();
        local math_max_ret = math.max(0, v63);

        if u17 == "match" then
            TextLabel2.Text = string.format("%d:%02d", math.floor(math_max_ret / 60), (math.floor(math_max_ret % 60)));
            TextLabel2.TextColor3 = math_max_ret <= 30 and Color3_fromRGB_ret10 or Color3_fromRGB_ret5;
            refreshBar(u15, u19);
            refreshBar(u16, u20);
        else
            local math_ceil_ret = math.ceil(math_max_ret);
            TextLabel2.Text = tostring(math_ceil_ret);
            TextLabel2.TextColor3 = Color3_fromRGB_ret7;

            if math_max_ret <= 0 then
                setCard(nil);
            end;
        end;
    end;
end);
task.spawn(function() -- Line: 328
    -- upvalues: u19 (ref), u20 (ref), insideVenue (copy), LocalPlayer (copy), Frame2 (copy), u36 (ref), workspace_CurrentCamera (copy), u40 (copy), u41 (copy), u42 (copy), TextLabel3 (copy), TextLabel4 (copy), UserInputService (copy), applySpectate (copy), u17 (ref), setCard (copy), u18 (ref)
    while true do
        task.wait(0.5);
        local v64 = u19 ~= nil and true or u20 ~= nil;
        local v65 = insideVenue();
        local v66;

        if v64 then
            if v65 then
                v66 = not (u19 == LocalPlayer.UserId and true or u20 == LocalPlayer.UserId);
            else
                v66 = v65;
            end;
        else
            v66 = v64;
        end;

        Frame2.Visible = v66 or u36 ~= nil;

        if u36 ~= nil then
            if v66 then
                applySpectate();
            else
                if u36 ~= nil then
                    u36 = nil;
                    workspace_CurrentCamera.CameraType = Enum.CameraType.Custom;
                    local Character = LocalPlayer.Character;

                    if Character then
                        Character = Character:FindFirstChildOfClass("Humanoid");
                    end;

                    if Character then
                        workspace_CurrentCamera.CameraSubject = Character;
                    end;

                    local v67 = u36 ~= nil;
                    u40.Visible = not v67;
                    u41.Visible = v67;
                    u42.Visible = v67;
                    TextLabel3.Visible = v67;
                    TextLabel4.Visible = v67;
                    TextLabel4.Text = v67 and (UserInputService.GamepadEnabled and not UserInputService.KeyboardEnabled and "DPAD LEFT: SWITCH" or (UserInputService.TouchEnabled and not UserInputService.KeyboardEnabled and "" or "Q: SWITCH") or "") or "";
                end;

                Frame2.Visible = false;
            end;
        end;

        if v64 then
            local v68 = u19 == LocalPlayer.UserId and true or u20 == LocalPlayer.UserId or (v65 or u36 ~= nil);

            if v68 and u17 ~= "match" then
                setCard("match", u18);
            elseif not v68 and u17 == "match" then
                setCard(nil);
            end;
        end;
    end;
end);
LocalPlayer.CharacterAdded:Connect(function() -- Line: 354
    -- upvalues: u36 (ref), u40 (copy), u41 (copy), u42 (copy), TextLabel3 (copy), TextLabel4 (copy), UserInputService (copy)
    u36 = nil;
    local v69 = u36 ~= nil;
    u40.Visible = not v69;
    u41.Visible = v69;
    u42.Visible = v69;
    TextLabel3.Visible = v69;
    TextLabel4.Visible = v69;
    TextLabel4.Text = v69 and (UserInputService.GamepadEnabled and not UserInputService.KeyboardEnabled and "DPAD LEFT: SWITCH" or (UserInputService.TouchEnabled and not UserInputService.KeyboardEnabled and "" or "Q: SWITCH") or "") or "";
end);
TournamentRemote.OnClientEvent:Connect(function(p70) -- Line: 362
    -- upvalues: u19 (ref), u20 (ref), u21 (ref), u18 (ref), LocalPlayer (copy), insideVenue (copy), u36 (ref), setCard (copy), applySpectate (copy), u17 (ref), workspace_CurrentCamera (copy), u40 (copy), u41 (copy), u42 (copy), TextLabel3 (copy), TextLabel4 (copy), UserInputService (copy), Frame2 (copy)
    if type(p70) ~= "table" then
        return;
    end;

    if p70.Event == "MatchTimer" then
        u19 = p70.FighterA;
        u20 = p70.FighterB;
        u21 = p70.Label or "";
        u18 = p70.EndsAt or 0;

        if u19 == LocalPlayer.UserId and true or u20 == LocalPlayer.UserId or (insideVenue() or u36 ~= nil) then
            setCard("match", p70.EndsAt);
        end;

        if u36 ~= nil then
            applySpectate();
        end;
    elseif p70.Event == "MatchEnd" then
        u19 = nil;
        u20 = nil;
        u21 = "";

        if u17 == "match" then
            setCard(nil);
        end;

        if u36 ~= nil then
            if u36 ~= nil then
                u36 = nil;
                workspace_CurrentCamera.CameraType = Enum.CameraType.Custom;
                local Character = LocalPlayer.Character;

                if Character then
                    Character = Character:FindFirstChildOfClass("Humanoid");
                end;

                if Character then
                    workspace_CurrentCamera.CameraSubject = Character;
                end;

                local v71 = u36 ~= nil;
                u40.Visible = not v71;
                u41.Visible = v71;
                u42.Visible = v71;
                TextLabel3.Visible = v71;
                TextLabel4.Visible = v71;
                TextLabel4.Text = v71 and (UserInputService.GamepadEnabled and not UserInputService.KeyboardEnabled and "DPAD LEFT: SWITCH" or (UserInputService.TouchEnabled and not UserInputService.KeyboardEnabled and "" or "Q: SWITCH") or "") or "";
            end;

            Frame2.Visible = false;
        end;
    elseif p70.Event == "PrepCountdown" then
        setCard("prep", p70.EndsAt);
    end;
end);
task.spawn(function() -- Line: 383
    -- upvalues: GetTournamentStatus (copy), u19 (ref), u20 (ref), u21 (ref), u18 (ref), LocalPlayer (copy), insideVenue (copy), setCard (copy)
    local success, result = pcall(function() -- Line: 384
        -- upvalues: GetTournamentStatus (ref)
        return GetTournamentStatus:InvokeServer();
    end);

    if not (success and (type(result) == "table" and result.Available)) then
        return;
    end;

    u19 = result.FighterA;
    u20 = result.FighterB;
    u21 = result.CurrentMatchText or "";

    if result.MatchEndsAt and (u19 or u20) then
        u18 = result.MatchEndsAt;

        if u19 == LocalPlayer.UserId and true or u20 == LocalPlayer.UserId or insideVenue() then
            setCard("match", result.MatchEndsAt);
        end;
    elseif result.PrepEndsAt then
        setCard("prep", result.PrepEndsAt);
    end;
end);
local v72 = u36 ~= nil;
u40.Visible = not v72;
u41.Visible = v72;
u42.Visible = v72;
TextLabel3.Visible = v72;
TextLabel4.Visible = v72;
TextLabel4.Text = v72 and (UserInputService.GamepadEnabled and not UserInputService.KeyboardEnabled and "DPAD LEFT: SWITCH" or (UserInputService.TouchEnabled and not UserInputService.KeyboardEnabled and "" or "Q: SWITCH") or "") or "";