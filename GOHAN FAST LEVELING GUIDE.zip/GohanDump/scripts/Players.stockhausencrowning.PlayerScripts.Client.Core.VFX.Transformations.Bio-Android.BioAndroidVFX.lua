-- Decompiled with Potassium's decompiler.

local Players = game:GetService("Players");
local Debris = game:GetService("Debris");
local ReplicatedStorage = game:GetService("ReplicatedStorage");
game:GetService("RunService");
game:GetService("CollectionService");
local Modules = ReplicatedStorage:WaitForChild("Modules");
ReplicatedStorage:WaitForChild("Remotes");
local Assets = ReplicatedStorage.Assets;
local _ = Modules.Metadata;
local Shared = Modules.Shared;
local _ = Modules.Utility;
require(Shared.SoundManager);
require(Modules.GlobalFunctions);
require(Shared.SoundManager);
local VfxHandler = require(Modules.Effects.VfxHandler);
local _ = workspace.World.Visuals;
local _ = Players.LocalPlayer;
local _ = Assets.Sounds;
local Particles = Assets.Effects.Particles;

return {
    ["Semi Perfect"] = function(p1) -- Line: 36
        -- upvalues: Players (copy), VfxHandler (copy)
        local Form_Quota = p1.Form_Quota;
        local Character = p1.Character;
        local v2 = p1.Delay or 2;
        local v3 = p1.LightningAmt or 5;
        local PlayerFromCharacter = Players:GetPlayerFromCharacter(Character);

        if PlayerFromCharacter then
            PlayerFromCharacter = PlayerFromCharacter:FindFirstChild("PlayerStats");
        end;

        if not PlayerFromCharacter then
            return;
        end;

        local v4 = PlayerFromCharacter:FindFirstChild("Evolution", true) or PlayerFromCharacter:FindFirstChild("Form", true);

        if not v4 then
            return;
        end;

        local v5 = {
            Amt = v3,
            WidthScale = p1.WidthScale,
            MaxSegments = p1.MaxSegments
        };

        while Character.Parent ~= nil and v4.Value == Form_Quota do
            VfxHandler.Lightning.Aura(Character, v5);

            if p1.DelayMin and p1.DelayMax then
                task.wait(math.random(p1.DelayMin, p1.DelayMax));
            else
                task.wait(v2);
            end;
        end;
    end,

    Disable = function(p6) -- Line: 78
        -- upvalues: Debris (copy)
        for _, descendant in pairs(p6.Character:GetDescendants()) do
            if descendant.Name == "Majin Glow" then
                descendant.Enabled = false;
                Debris:AddItem(descendant, 5);
            end;
        end;
    end,

    ["Super Perfect"] = function(p7) -- Line: 95
        -- upvalues: Particles (copy)
        local Character = p7.Character;

        if not Character then
            return;
        end;

        local SuperPerfectAura = Particles:FindFirstChild("SuperPerfectAura");

        if not SuperPerfectAura then
            return;
        end;

        BioAndroidVFX["Super Perfect Disable"]({
            Character = Character
        });

        local function tag(p8) -- Line: 103
            p8:SetAttribute("SuperPerfectFX", true);

            return p8;
        end;

        for _, v in ipairs({ "Head", "Left Arm", "Right Arm", "Left Leg", "Right Leg" }) do
            local v9 = Character:FindFirstChild(v);

            if v9 then
                for _, child in ipairs(SuperPerfectAura.Limb:GetChildren()) do
                    local v10 = child:Clone();
                    v10:SetAttribute("SuperPerfectFX", true);
                    v10.Parent = v9;
                end;
            end;
        end;

        local Torso = Character:FindFirstChild("Torso");

        if Torso then
            for _, child in ipairs(SuperPerfectAura.Torso:GetChildren()) do
                local v11 = child:Clone();
                v11:SetAttribute("SuperPerfectFX", true);
                v11.Parent = Torso;
            end;
        end;
    end,

    ["Super Perfect Disable"] = function(p12) -- Line: 125
        -- upvalues: Debris (copy)
        local Character = p12.Character;

        if not Character then
            return;
        end;

        for _, descendant in ipairs(Character:GetDescendants()) do
            if descendant:GetAttribute("SuperPerfectFX") then
                if descendant:IsA("ParticleEmitter") then
                    descendant.Enabled = false;
                    Debris:AddItem(descendant, 3);
                elseif descendant:IsA("Attachment") then
                    for _, descendant2 in ipairs(descendant:GetDescendants()) do
                        if descendant2:IsA("ParticleEmitter") then
                            descendant2.Enabled = false;
                        end;

                        if descendant2:IsA("Light") then
                            descendant2.Enabled = false;
                        end;
                    end;

                    Debris:AddItem(descendant, 3);
                else
                    descendant:Destroy();
                end;
            end;
        end;
    end
};