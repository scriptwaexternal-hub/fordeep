-- Decompiled with Potassium's decompiler.

local ReplicatedStorage = game:GetService("ReplicatedStorage");
local RunService = game:GetService("RunService");
local Players = game:GetService("Players");
local Modules = ReplicatedStorage:WaitForChild("Modules");
local Metadata = Modules.Metadata;
local GlobalFunctions = require(Modules.GlobalFunctions);
local StateManager = require(Metadata.ControlData.StateManager);
local _ = Players.LocalPlayer;
local u1 = require(Modules:WaitForChild("Shared"):WaitForChild("Mouse")).new();

local function isCharging(p2) -- Line: 52
    -- upvalues: StateManager (copy)
    return StateManager.IsInState(p2, "ChargingBeam") or p2:FindFirstChild("Charging Beam") ~= nil;
end;

local function isUsingSkill(p3) -- Line: 56
    -- upvalues: StateManager (copy)
    return StateManager.IsInState(p3, "UsedSkill") or (p3:FindFirstChild("UsedSkill") ~= nil and true or p3:FindFirstChild("UsingSkill") ~= nil);
end;

local function isStunned(p4) -- Line: 61
    -- upvalues: StateManager (copy)
    return StateManager.IsInState(p4, "Stunned") or p4:FindFirstChild("Stun") ~= nil;
end;

local function destroyRig(p5, p6) -- Line: 66
    if p5 then
        p5 = p5:FindFirstChild("AimAssistHold");
    end;

    if p5 then
        p5:Destroy();
    end;

    if p6 and p6.Parent then
        p6.AutoRotate = true;
    end;
end;

return {
    Execution = function(p7) -- Line: 75
        -- upvalues: GlobalFunctions (copy), StateManager (copy), RunService (copy), u1 (copy)
        local Character = p7.Character;
        local RootAndHumanoid, u8 = GlobalFunctions.GetRootAndHumanoid(Character);

        if not (RootAndHumanoid and u8) then
            return;
        end;

        task.spawn(function() -- Line: 80
            -- upvalues: Character (copy), StateManager (ref), RootAndHumanoid (copy), u8 (copy), RunService (ref), u1 (ref)
            local os_clock_ret = os.clock();

            while true do
                local v9 = Character;

                if StateManager.IsInState(v9, "ChargingBeam") or v9:FindFirstChild("Charging Beam") ~= nil or os.clock() - os_clock_ret >= 0.5 then
                    break;
                end;

                task.wait();
            end;

            local v10 = Character;

            if not StateManager.IsInState(v10, "ChargingBeam") and v10:FindFirstChild("Charging Beam") == nil then
                return;
            end;

            local v11 = RootAndHumanoid;

            if v11 then
                v11 = v11:FindFirstChild("AimAssistHold");
            end;

            if v11 then
                v11:Destroy();
            end;

            u8.AutoRotate = false;
            local Attachment = Instance.new("Attachment");
            Attachment.Name = "AimAssistHold";
            Attachment.Parent = RootAndHumanoid;
            local LinearVelocity = Instance.new("LinearVelocity");
            LinearVelocity.Attachment0 = Attachment;
            LinearVelocity.MaxForce = math.max(RootAndHumanoid.AssemblyMass, 1) * 12000;
            LinearVelocity.VectorVelocity = Vector3.new(0, 0, 0);
            LinearVelocity.Parent = Attachment;
            local AlignOrientation = Instance.new("AlignOrientation");
            AlignOrientation.Attachment0 = Attachment;
            AlignOrientation.Mode = Enum.OrientationAlignmentMode.OneAttachment;
            AlignOrientation.RigidityEnabled = false;
            AlignOrientation.Responsiveness = 30;
            AlignOrientation.MaxTorque = (1 / 0);
            AlignOrientation.Parent = Attachment;
            local u12 = nil;
            u12 = RunService.Heartbeat:Connect(function() -- Line: 126
                -- upvalues: Attachment (copy), u12 (ref), u1 (ref), RootAndHumanoid (ref), AlignOrientation (copy)
                if not Attachment.Parent then
                    u12:Disconnect();

                    return;
                end;

                local v13 = u1.Hit.Position - RootAndHumanoid.Position;

                if v13.Magnitude > 0.05 then
                    AlignOrientation.CFrame = CFrame.lookAt(Vector3.new(0, 0, 0), v13.Unit);
                end;
            end);

            while Attachment.Parent do
                local v14 = Character;

                if not StateManager.IsInState(v14, "ChargingBeam") and v14:FindFirstChild("Charging Beam") == nil then
                    break;
                end;

                local v15 = Character;

                if StateManager.IsInState(v15, "Stunned") or v15:FindFirstChild("Stun") ~= nil or os.clock() - os_clock_ret >= 15 then
                    break;
                end;

                task.wait();
            end;

            u12:Disconnect();

            while Attachment.Parent do
                local v16 = Character;

                if not (StateManager.IsInState(v16, "UsedSkill") or (v16:FindFirstChild("UsedSkill") ~= nil or v16:FindFirstChild("UsingSkill") ~= nil)) then
                    break;
                end;

                local v17 = Character;

                if StateManager.IsInState(v17, "Stunned") or v17:FindFirstChild("Stun") ~= nil or os.clock() - os_clock_ret >= 15 then
                    break;
                end;

                task.wait();
            end;

            local v18 = RootAndHumanoid;
            local v19 = u8;

            if v18 then
                v18 = v18:FindFirstChild("AimAssistHold");
            end;

            if v18 then
                v18:Destroy();
            end;

            if v19 and v19.Parent then
                v19.AutoRotate = true;
            end;
        end);
    end,

    FlyAssist = function(p20) -- Line: 159
        -- upvalues: GlobalFunctions (copy), u1 (copy)
        local Character = p20.Character;
        local RootAndHumanoid, _ = GlobalFunctions.GetRootAndHumanoid(Character);
        local BodyGyro = Instance.new("BodyGyro");
        BodyGyro.Parent = RootAndHumanoid;
        BodyGyro.Name = "Aim_Gyro";
        BodyGyro.MaxTorque = Vector3.new(100000, 100000, 100000);
        BodyGyro.P = 40000;

        while Character:FindFirstChild("Flying") do
            task.wait();
            BodyGyro.CFrame = u1.Hit;
        end;

        BodyGyro:Destroy();
    end,

    Remove = function(p21) -- Line: 176
        -- upvalues: GlobalFunctions (copy)
        local Character = p21.Character;
        local RootAndHumanoid, v22 = GlobalFunctions.GetRootAndHumanoid(Character);
        local v23;

        if RootAndHumanoid then
            v23 = RootAndHumanoid:FindFirstChild("AimAssistHold");
        else
            v23 = RootAndHumanoid;
        end;

        if v23 then
            v23:Destroy();
        end;

        if v22 and v22.Parent then
            v22.AutoRotate = true;
        end;

        for _, descendant in pairs(Character:GetDescendants()) do
            if descendant:IsA("BodyGyro") and descendant.Name == "Aim_Gyro" then
                descendant:Destroy();
            elseif descendant.Name == "FlyVelocity" then
                descendant:Destroy();
            end;
        end;

        RootAndHumanoid.CFrame = CFrame.new(RootAndHumanoid.Position);
    end
};