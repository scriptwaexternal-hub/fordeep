-- Decompiled with Potassium's decompiler.

local Players = game:GetService("Players");
local ReplicatedStorage = game:GetService("ReplicatedStorage");
local UserInputService = game:GetService("UserInputService");
local Debris = game:GetService("Debris");
local Modules = ReplicatedStorage:WaitForChild("Modules");
local Remotes = ReplicatedStorage:WaitForChild("Remotes");
local Shared = Modules.Shared;
local Assets = ReplicatedStorage.Assets;
local GameMessage = require(Modules.Utility.GameMessage);
local AnimationManager = require(Shared.AnimationManager);
local SoundManager = require(Shared.SoundManager);
local GlobalFunctions = require(Modules.GlobalFunctions);
local Platform = require(Shared.Platform);
local ServerRemote = Remotes.ServerRemote;
local StatRetrieveRemote = Remotes.StatRetrieveRemote;
local LocalPlayer = Players.LocalPlayer;
local Meditate = Assets.Gui.Meditate;
local Trainings = Assets.Gui.Trainings;
local Pushup = Trainings.Pushup;
local u1 = { "LetterLabel", "Circle", "GoalFrame" };

local function getTrainingGui() -- Line: 72
    -- upvalues: LocalPlayer (copy)
    return LocalPlayer.PlayerGui:WaitForChild("PopupGui");
end;

local function clearTrainingGui() -- Line: 76
    -- upvalues: LocalPlayer (copy), u1 (copy)
    local PopupGui = LocalPlayer.PlayerGui:WaitForChild("PopupGui");

    for _, child in ipairs(PopupGui:GetChildren()) do
        if table.find(u1, child.Name) then
            child:Destroy();
        end;
    end;
end;

local function fireStatGain(p2, p3, p4) -- Line: 85
    -- upvalues: ServerRemote (copy)
    ServerRemote:FireServer(nil, {
        Module = "StatManager",
        Action = "Gain",
        ClientVerified = true,
        Stat = p2,
        StatType = p3,
        ItemType = p4
    });
end;

local function isConfirmPress(p5) -- Line: 99
    return (p5.KeyCode == Enum.KeyCode.Space or p5.KeyCode == Enum.KeyCode.ButtonA) and true or p5.UserInputType == Enum.UserInputType.Touch;
end;

local function newSession(u6, u7) -- Line: 110
    local u8 = {
        finished = false,
        character = u6,
        startTime = os.clock(),
        duration = u7,
        cleanup = {}
    };

    function u8.onFinish(p9) -- Line: 119
        -- upvalues: u8 (copy)
        table.insert(u8.cleanup, p9);
    end;

    function u8.finish() -- Line: 123
        -- upvalues: u8 (copy)
        if u8.finished then
            return;
        end;

        u8.finished = true;

        for _, v in ipairs(u8.cleanup) do
            task.spawn(v);
        end;
    end;

    local u10 = false;

    function u8.isActive() -- Line: 143
        -- upvalues: u8 (copy), u6 (copy), u7 (copy), u10 (ref)
        if u8.finished then
            return false;
        end;

        if not u6.Parent then
            return false;
        end;

        if u7 <= os.clock() - u8.startTime then
            return false;
        end;

        local v11 = u6:GetAttribute("State_Training") ~= nil;

        if v11 then
            u10 = true;
        end;

        if u10 and not v11 then
            return false;
        end;

        if not u10 and os.clock() - u8.startTime > 1 then
            return false;
        end;

        if u6:GetAttribute("State_Stunned") == nil then
            return not u6:FindFirstChild("Stun");
        end;

        return false;
    end;

    task.spawn(function() -- Line: 160
        -- upvalues: u8 (copy)
        while u8.isActive() do
            task.wait(0.1);
        end;

        u8.finish();
    end);

    return u8;
end;

local function runPushupOSU(p12, p13, u14) -- Line: 174
    -- upvalues: LocalPlayer (copy), newSession (copy), GlobalFunctions (copy), AnimationManager (copy), clearTrainingGui (copy), Pushup (copy), SoundManager (copy), UserInputService (copy), Platform (copy), ServerRemote (copy), GameMessage (copy)
    local PopupGui = LocalPlayer.PlayerGui:WaitForChild("PopupGui");
    local Character = p12.Character;

    if PopupGui:FindFirstChild("GoalFrame") then
        return;
    end;

    local u15 = newSession(Character, p12.Duration);
    local RootAndHumanoid = GlobalFunctions.GetRootAndHumanoid(Character);
    AnimationManager.PlayAnimation(Character, u14.Hold_Anim, {
        Looped = true
    });
    u15.onFinish(function() -- Line: 183
        -- upvalues: AnimationManager (ref), Character (copy), u14 (copy), clearTrainingGui (ref)
        AnimationManager.StopAnimation(Character, u14.Hold_Anim);
        clearTrainingGui();
    end);
    local u16 = Pushup.GoalFrame:Clone();
    local u17 = Pushup.Circle:Clone();
    u16.Parent = PopupGui;
    u17.Parent = PopupGui;
    u16.Size = u16.Size + UDim2.new(u14.Goal_Frame_Size, 0, u14.Goal_Frame_Size, 0);
    local u18 = (p13 or 0.01) * 60;
    local Color3_fromRGB_ret = Color3.fromRGB(155, 255, 144);
    local Color3_fromRGB_ret2 = Color3.fromRGB(255, 155, 155);
    local Color3_fromRGB_ret3 = Color3.fromRGB(255, 255, 255);
    local u19 = false;

    local function increaseSpeedInFlow() -- Line: 208
        -- upvalues: u18 (ref), SoundManager (ref), RootAndHumanoid (copy)
        if u18 < 3 then
            u18 = u18 + 0.3;

            return;
        end;

        u18 = 3;
        SoundManager.AddSound("Have No Heart", {
            Parent = RootAndHumanoid
        }, "Client");
    end;

    local function u22() -- Line: 219
        -- upvalues: u15 (copy), u16 (copy), Color3_fromRGB_ret3 (copy), u17 (copy), u19 (ref), u18 (ref), Color3_fromRGB_ret2 (copy), u22 (ref)
        if u15.finished then
            return;
        end;

        local v20 = math.random(30, 70) / 100;
        u16.Position = UDim2.new(v20, 0, v20, 0);
        u16.ImageColor3 = Color3_fromRGB_ret3;
        u17.Position = u16.Position;
        local u21 = 1.93;
        u17.Size = UDim2.new(u21, 0, u21, 0);
        task.spawn(function() -- Line: 234
            -- upvalues: u17 (ref), u19 (ref), u15 (ref), u21 (ref), u18 (ref), u16 (ref), Color3_fromRGB_ret2 (ref), u22 (ref)
            local os_clock_ret = os.clock();

            while u17.Parent and not (u19 or u15.finished) do
                local os_clock_ret2 = os.clock();
                u21 = u21 - u18 * (os_clock_ret2 - os_clock_ret);

                if u21 <= 0 then
                    break;
                end;

                u17.Size = UDim2.new(u21, 0, u21, 0);
                task.wait();
                os_clock_ret = os_clock_ret2;
            end;

            if not (u19 or u15.finished) then
                u19 = true;
                u17.Size = UDim2.new(0, 0, 0, 0);
                u16.ImageColor3 = Color3_fromRGB_ret2;
                u18 = 0.6;
                task.delay(0.25, function() -- Line: 251
                    -- upvalues: u19 (ref), u22 (ref)
                    u19 = false;
                    u22();
                end);
            end;
        end);
    end;

    local u25 = UserInputService.InputBegan:Connect(function(p23, p24) -- Line: 259
        -- upvalues: Platform (ref), u15 (copy), u19 (ref), u17 (copy), u16 (copy), AnimationManager (ref), Character (copy), u14 (copy), SoundManager (ref), RootAndHumanoid (copy), ServerRemote (ref), Color3_fromRGB_ret (copy), u18 (ref), Color3_fromRGB_ret2 (copy), u22 (ref)
        if Platform.InputBlocked(p23, p24) or u15.finished then
            return;
        end;

        if p23.KeyCode ~= Enum.KeyCode.Space and p23.KeyCode ~= Enum.KeyCode.ButtonA and p23.UserInputType ~= Enum.UserInputType.Touch or u19 then
            return;
        end;

        u19 = true;

        if u17.Size.X.Scale <= u16.Size.X.Scale + 0.1 then
            AnimationManager.PlayAnimation(Character, u14.Pushup_Anim);
            SoundManager.AddSound("Breath Out", {
                Parent = RootAndHumanoid
            }, "Client");
            SoundManager.AddSound("Osu Hit", {
                Parent = RootAndHumanoid
            }, "Client");
            ServerRemote:FireServer(nil, {
                Module = "StatManager",
                Action = "Gain",
                Stat = "Strength",
                StatType = "Str",
                ClientVerified = true,
                ItemType = u14.Pushup_EXP_Type
            });
            u16.ImageColor3 = Color3_fromRGB_ret;

            if u18 >= 3 then
                u18 = 3;
                SoundManager.AddSound("Have No Heart", {
                    Parent = RootAndHumanoid
                }, "Client");
            else
                u18 = u18 + 0.3;
            end;
        else
            u16.ImageColor3 = Color3_fromRGB_ret2;
            u18 = 0.6;
        end;

        task.delay(0.25, function() -- Line: 277
            -- upvalues: u19 (ref), u22 (ref)
            u19 = false;
            u22();
        end);
    end);
    u15.onFinish(function() -- Line: 282
        -- upvalues: u25 (copy)
        u25:Disconnect();
    end);
    local v26 = Platform.PreferGamepadGlyphs() and "Press A when the Circle is in the middle of the Goal Frame!" or (Platform.IsTouch() and "Tap when the Circle is in the middle of the Goal Frame!" or "Press Space when the Circle is in the middle of the Goal Frame!");
    GameMessage.SendMessage(LocalPlayer, v26);
    u22();
end;

local function pushupVariant(u27, u28, u29, u30, u31) -- Line: 294
    -- upvalues: runPushupOSU (copy)
    return function(p32) -- Line: 295
        -- upvalues: runPushupOSU (ref), u30 (copy), u27 (copy), u28 (copy), u29 (copy), u31 (copy)
        runPushupOSU(p32, u30, {
            Hold_Anim = u27,
            Pushup_Anim = u28,
            Pushup_EXP_Type = u29,
            Goal_Frame_Size = u31
        });
    end;
end;

local u33 = {};
local u34 = 0.02;
local u35 = "Pushup Hold Anim";
local u36 = "Pushup Anim";
local u37 = "Pushup";
local u38 = 0.2;

function u33.Pushup(p39) -- Line: 295
    -- upvalues: runPushupOSU (copy), u34 (copy), u35 (copy), u36 (copy), u37 (copy), u38 (copy)
    runPushupOSU(p39, u34, {
        Hold_Anim = u35,
        Pushup_Anim = u36,
        Pushup_EXP_Type = u37,
        Goal_Frame_Size = u38
    });
end;

local u40 = 0.03;
local u41 = "One Arm Pushup Hold Anim";
local u42 = "One Arm Pushup Anim";
local u43 = "One Arm Pushup";
local u44 = 0.1;

u33["One Arm Pushup"] = function(p45) -- Line: 295
    -- upvalues: runPushupOSU (copy), u40 (copy), u41 (copy), u42 (copy), u43 (copy), u44 (copy)
    runPushupOSU(p45, u40, {
        Hold_Anim = u41,
        Pushup_Anim = u42,
        Pushup_EXP_Type = u43,
        Goal_Frame_Size = u44
    });
end;

local u46 = 0.04;
local u47 = "Handstand Pushup Hold";
local u48 = "Handstand Pushup";
local u49 = "Handstand Pushup";
local u50 = 0;

u33["Handstand Pushup"] = function(p51) -- Line: 295
    -- upvalues: runPushupOSU (copy), u46 (copy), u47 (copy), u48 (copy), u49 (copy), u50 (copy)
    runPushupOSU(p51, u46, {
        Hold_Anim = u47,
        Pushup_Anim = u48,
        Pushup_EXP_Type = u49,
        Goal_Frame_Size = u50
    });
end;

function u33.Squat(p52) -- Line: 314
    -- upvalues: LocalPlayer (copy), newSession (copy), GlobalFunctions (copy), Platform (copy), AnimationManager (copy), clearTrainingGui (copy), UserInputService (copy), Debris (copy), SoundManager (copy), ServerRemote (copy), Trainings (copy)
    local PopupGui = LocalPlayer.PlayerGui:WaitForChild("PopupGui");
    local Character = p52.Character;
    local u53 = newSession(Character, p52.Duration);
    local RootAndHumanoid = GlobalFunctions.GetRootAndHumanoid(Character);
    local u54 = Platform.PreferGamepadGlyphs();
    local u55 = u54 and { "X", "Y", "A", "B" } or { "W", "A", "S", "D" };
    local u56 = {};

    for _, v in ipairs(u55) do
        local v57;

        if u54 then
            v57 = "Button" .. v or v;
        else
            v57 = v;
        end;

        u56[v57] = true;
    end;

    local u58 = true;

    local function pauseSpawning(p59) -- Line: 332
        -- upvalues: u58 (ref)
        u58 = false;
        task.delay(p59, function() -- Line: 334
            -- upvalues: u58 (ref)
            u58 = true;
        end);
    end;

    AnimationManager.PlayAnimation(Character, "Squat Hold Anim", {
        Looped = true
    });
    u53.onFinish(function() -- Line: 338
        -- upvalues: AnimationManager (ref), Character (copy), clearTrainingGui (ref)
        AnimationManager.StopAnimation(Character, "Squat Hold Anim");
        clearTrainingGui();
    end);
    local u62 = UserInputService.InputBegan:Connect(function(p60, p61) -- Line: 343
        -- upvalues: Platform (ref), u53 (copy), PopupGui (copy), u58 (ref), u54 (copy), Debris (ref), AnimationManager (ref), Character (copy), SoundManager (ref), RootAndHumanoid (copy), ServerRemote (ref), u56 (copy)
        if Platform.InputBlocked(p60, p61) or u53.finished then
            return;
        end;

        local LetterLabel = PopupGui:FindFirstChild("LetterLabel");

        if not (LetterLabel and u58) then
            return;
        end;

        if (u54 and "Button" .. LetterLabel.Text or LetterLabel.Text) ~= p60.KeyCode.Name then
            if not u56[p60.KeyCode.Name] then
                return;
            end;

            LetterLabel.TextColor3 = Color3.fromRGB(255, 0, 0);
            Debris:AddItem(LetterLabel, 1.5);
            u58 = false;
            task.delay(1.5, function() -- Line: 334
                -- upvalues: u58 (ref)
                u58 = true;
            end);

            return;
        end;

        LetterLabel.TextColor3 = Color3.fromRGB(0, 255, 0);
        Debris:AddItem(LetterLabel, 0.25);
        u58 = false;
        task.delay(0.25, function() -- Line: 334
            -- upvalues: u58 (ref)
            u58 = true;
        end);
        AnimationManager.PlayAnimation(Character, "Squat Anim");
        SoundManager.AddSound("Breath Out", {
            Parent = RootAndHumanoid
        }, "Client");
        ServerRemote:FireServer(
            nil,
            {
                Module = "StatManager",
                Action = "Gain",
                Stat = "Agility",
                StatType = "Agl",
                ItemType = "Squat",
                ClientVerified = true
            }
        );
    end);
    u53.onFinish(function() -- Line: 365
        -- upvalues: u62 (copy)
        u62:Disconnect();
    end);
    task.spawn(function() -- Line: 368
        -- upvalues: u53 (copy), u58 (ref), PopupGui (copy), Trainings (ref), Debris (ref), AnimationManager (ref), Character (copy), SoundManager (ref), RootAndHumanoid (copy), ServerRemote (ref), u55 (copy)
        while u53.isActive() do
            if u58 and not PopupGui:FindFirstChild("LetterLabel") then
                local u63 = Trainings.LetterLabel:Clone();
                u63.Active = true;
                u63.InputBegan:Connect(function(p64) -- Line: 375
                    -- upvalues: u53 (ref), u58 (ref), u63 (copy), Debris (ref), AnimationManager (ref), Character (ref), SoundManager (ref), RootAndHumanoid (ref), ServerRemote (ref)
                    if u53.finished or not u58 then
                        return;
                    end;

                    if p64.UserInputType ~= Enum.UserInputType.Touch and p64.UserInputType ~= Enum.UserInputType.MouseButton1 then
                        return;
                    end;

                    if not u63.Parent then
                        return;
                    end;

                    u63.TextColor3 = Color3.fromRGB(0, 255, 0);
                    Debris:AddItem(u63, 0.25);
                    u58 = false;
                    task.delay(0.25, function() -- Line: 334
                        -- upvalues: u58 (ref)
                        u58 = true;
                    end);
                    AnimationManager.PlayAnimation(Character, "Squat Anim");
                    SoundManager.AddSound("Breath Out", {
                        Parent = RootAndHumanoid
                    }, "Client");
                    ServerRemote:FireServer(
                        nil,
                        {
                            Module = "StatManager",
                            Action = "Gain",
                            Stat = "Agility",
                            StatType = "Agl",
                            ItemType = "Squat",
                            ClientVerified = true
                        }
                    );
                end);
                u63.Parent = PopupGui;
                u63.Text = u55[math.random(1, #u55)];
                Debris:AddItem(u63, 3);
            end;

            task.wait(0.05);
        end;
    end);
end;

function u33.Situp(p65, p66) -- Line: 398
    -- upvalues: newSession (copy), AnimationManager (copy), Meditate (copy), Platform (copy), StatRetrieveRemote (copy), SoundManager (copy), ServerRemote (copy), UserInputService (copy)
    local u67 = p66 or "Situp";
    local Character = p65.Character;
    local u68 = newSession(Character, p65.Duration);
    local HumanoidRootPart = Character:FindFirstChild("HumanoidRootPart");

    if not HumanoidRootPart then
        u68.finish();

        return;
    end;

    AnimationManager.PlayAnimation(Character, "Situp Hold anim", {
        Looped = true
    });
    u68.onFinish(function() -- Line: 411
        -- upvalues: AnimationManager (ref), Character (copy)
        AnimationManager.StopAnimation(Character, "Situp Hold anim");
    end);
    local u69 = Meditate.Mini_Medi_Gui:Clone();
    u69.Parent = HumanoidRootPart;
    u69.Name = "Mini_Medi";
    u68.onFinish(function() -- Line: 418
        -- upvalues: u69 (copy)
        u69:Destroy();
    end);
    local Bar = u69.Bar;
    local Goal = Bar.Goal;
    local Slider = Bar.Slider;
    local TextLabel = Goal:FindFirstChild("TextLabel");

    if TextLabel then
        if Platform.PreferGamepadGlyphs() then
            TextLabel.Text = "Press A";
        elseif Platform.IsTouch() then
            TextLabel.Text = "Tap";
        end;
    end;

    local Color3_fromRGB_ret = Color3.fromRGB(255, 75, 78);
    local Color3_fromRGB_ret2 = Color3.fromRGB(75, 255, 78);
    local success, result = pcall(StatRetrieveRemote.InvokeServer, StatRetrieveRemote, "Durability", "Core");
    local v70 = (not success or type(result) ~= "table") and 0 or (result.BaseDurability or 0) + (result.EnhancedDurability or 0);
    local u71 = math.random(40, 50) - v70 / 20;

    local function repositionGoal() -- Line: 451
        -- upvalues: Goal (copy), u71 (copy)
        Goal.Size = UDim2.new(u71 / 100, 0, 1, 0);
        Goal.Position = UDim2.new(math.random(u71 / 2, 100 - u71 / 2) / 100, 0, 0.5, 0);
    end;

    repositionGoal();
    local u72 = false;
    local u73 = false;
    local u74 = 1;

    local function hitGoal() -- Line: 463
        -- upvalues: u72 (ref), SoundManager (ref), HumanoidRootPart (copy), AnimationManager (ref), Character (copy), u67 (ref), ServerRemote (ref), Goal (copy), Color3_fromRGB_ret2 (copy), repositionGoal (copy), Color3_fromRGB_ret (copy)
        if u72 then
            return;
        end;

        u72 = true;
        SoundManager.AddSound("In Goal", {
            Parent = HumanoidRootPart
        }, "Client");
        AnimationManager.PlayAnimation(Character, "Situp");
        ServerRemote:FireServer(nil, {
            Module = "StatManager",
            Action = "Gain",
            Stat = "Durability",
            StatType = "Dura",
            ClientVerified = true,
            ItemType = u67
        });
        Goal.BackgroundColor3 = Color3_fromRGB_ret2;
        task.delay(0.15, function() -- Line: 470
            -- upvalues: u72 (ref), repositionGoal (ref), Goal (ref), Color3_fromRGB_ret (ref)
            u72 = false;
            repositionGoal();
            Goal.BackgroundColor3 = Color3_fromRGB_ret;
        end);
    end;

    local u77 = UserInputService.InputBegan:Connect(function(p75, p76) -- Line: 477
        -- upvalues: Platform (ref), u68 (copy), u73 (ref), Goal (copy), Slider (copy), hitGoal (copy)
        if Platform.InputBlocked(p75, p76) or (u68.finished or u73) then
            return;
        end;

        if p75.KeyCode ~= Enum.KeyCode.Space and p75.KeyCode ~= Enum.KeyCode.ButtonA and p75.UserInputType ~= Enum.UserInputType.Touch then
            return;
        end;

        local Scale = Slider.Position.X.Scale;

        if Goal.Position.X.Scale - Goal.Size.X.Scale / 2 <= Scale and Scale <= Goal.Position.X.Scale + Goal.Size.X.Scale / 2 then
            hitGoal();

            return;
        end;

        u73 = true;
        task.delay(1, function() -- Line: 490
            -- upvalues: u73 (ref)
            u73 = false;
        end);
    end);
    u68.onFinish(function() -- Line: 493
        -- upvalues: u77 (copy)
        u77:Disconnect();
    end);
    task.spawn(function() -- Line: 496
        -- upvalues: u68 (copy), u69 (copy), u73 (ref), Slider (copy), u74 (ref)
        local os_clock_ret = os.clock();

        while u68.isActive() and u69.Parent do
            local os_clock_ret2 = os.clock();

            if not u73 then
                local v78 = Slider.Position.X.Scale + u74 * 0.6 * (os_clock_ret2 - os_clock_ret);

                if v78 >= 1 then
                    v78 = 1;
                    u74 = -1;
                elseif v78 <= 0 then
                    v78 = 0;
                    u74 = 1;
                end;

                Slider.Position = UDim2.new(v78, 0, Slider.Position.Y.Scale, 0);
            end;

            task.wait();
            os_clock_ret = os_clock_ret2;
        end;

        u68.finish();
    end);
end;

u33["Advanced Situp"] = function(p79) -- Line: 518
    -- upvalues: u33 (copy)
    return u33.Situp(p79, "Advanced Situp");
end;

return u33;