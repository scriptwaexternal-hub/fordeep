-- Decompiled with Potassium's decompiler.

local Players = game:GetService("Players");
local u1 = {};
Players.PlayerRemoving:Connect(function(p2) -- Line: 9
    -- upvalues: u1 (copy)
    for i, v in u1 do
        if v and v.Connected then
            i[p2] = nil;
        else
            u1[i] = nil;
            table.clear(i);
        end;
    end;
end);

return function(u3) -- Line: 20
    -- upvalues: Players (copy), u1 (copy)
    local u4 = {};

    local function playerAdded(p5) -- Line: 23
        -- upvalues: u4 (copy), u3 (copy)
        if u4[p5] then
            return;
        end;

        u4[p5] = true;
        u3(p5);
    end;

    local v6 = Players.PlayerAdded:Connect(playerAdded);
    u1[u4] = v6;

    for _, v in Players:GetPlayers() do
        task.spawn(playerAdded, v);
    end;

    return v6;
end;