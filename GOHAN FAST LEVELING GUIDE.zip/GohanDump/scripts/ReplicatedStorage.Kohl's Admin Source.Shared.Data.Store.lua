-- Decompiled with Potassium's decompiler.

local DataStoreService = game:GetService("DataStoreService");
local RunService = game:GetService("RunService");
local Util = require(script.Parent.Parent:WaitForChild("Util"));
local u2 = {
    dataStore = nil,

    getBudget = function(p1) -- Line: 10, Name: getBudget
        -- upvalues: DataStoreService (copy)
        return DataStoreService:GetRequestBudgetForRequestType(p1);
    end
};

function u2.getAsync(u3: string, u4: userdata?) -- Line: 14
    -- upvalues: Util (copy), u2 (copy)
    return Util.Retry(function() -- Line: 15
        -- upvalues: u2 (ref), u3 (copy), u4 (copy)
        return u2.dataStore:GetAsync(u3, u4);
    end, (1 / 0));
end;

function u2.setAsync(u5: string, u6: any, u7: table?, u8: userdata?) -- Line: 20
    -- upvalues: Util (copy), u2 (copy)
    return Util.Retry(function() -- Line: 21
        -- upvalues: u2 (ref), u5 (copy), u6 (copy), u7 (copy), u8 (copy)
        return u2.dataStore:SetAsync(u5, u6, u7, u8);
    end, (1 / 0));
end;

function u2.updateAsync(u9: string, u10: function) -- Line: 26
    -- upvalues: Util (copy), u2 (copy)
    return Util.Retry(function() -- Line: 27
        -- upvalues: u2 (ref), u9 (copy), u10 (copy)
        return u2.dataStore:UpdateAsync(u9, u10);
    end, (1 / 0));
end;

function u2.removeAsync(u11: string) -- Line: 32
    -- upvalues: Util (copy), u2 (copy)
    return Util.Retry(function() -- Line: 33
        -- upvalues: u2 (ref), u11 (copy)
        return u2.dataStore:RemoveAsync(u11);
    end, (1 / 0));
end;

local u12 = true;

function u2.loadStore(u13, u14) -- Line: 40
    -- upvalues: u2 (copy), u12 (ref), DataStoreService (copy), RunService (copy), Util (copy)
    if u2.dataStore then
        return u12, u2.dataStore;
    end;

    print((`[Kohl's Admin] Initializing DataStore {u13}...`));
    local success, result = pcall(DataStoreService.GetDataStore, DataStoreService, u13, u14);

    if not success then
        if RunService:IsStudio() and (type(result) == "string" and string.find(result, "publish", 1, true)) then
            u12 = false;
            warn("You must publish this game to Roblox for full features.");
        end;

        success, result = Util.Retry(function() -- Line: 55
            -- upvalues: DataStoreService (ref), u13 (copy), u14 (copy)
            return DataStoreService:GetDataStore(u13, u14);
        end);
    end;

    if not success then
        u12 = false;
        warn(result);
    end;

    local success2, result2 = pcall(result.GetAsync, result, "__TEST");

    if not success2 and string.find(result2, "Studio access", 1, true) then
        result = "Enable Studio access to API services in Experience Settings for full features.";
        u12 = false;
        warn(result);
    end;

    if u12 then
        u2.dataStore = result;
    end;

    return u12, result;
end;

return u2;