-- Decompiled with Potassium's decompiler.

game:GetService("Players");
game:GetService("TweenService");
local ReplicatedStorage = game:GetService("ReplicatedStorage");
game:GetService("RunService");
local ContentProvider = game:GetService("ContentProvider");
local Modules = ReplicatedStorage:WaitForChild("Modules");
ReplicatedStorage:WaitForChild("Remotes");
local Assets = ReplicatedStorage.Assets;
local _ = Modules.Metadata;
local _ = Modules.Shared;
local _ = Modules.Utility;
local Client = require(script.Variations.Client);
local Descendants = Assets.Sounds:GetDescendants();
local u1 = {
    CachedSounds = {}
};
local u5 = {
    Client = function(p2, p3, p4) -- Line: 33
        -- upvalues: Client (copy), u1 (copy)
        return Client(u1.CachedSounds, p2, p3, p4);
    end
};

for _, v in ipairs(Descendants) do
    if v:IsA("Sound") then
        u1.CachedSounds[v.Name] = v;
    end;
end;

function u1.AddSound(p6, p7, p8, p9) -- Line: 45
    -- upvalues: u5 (copy)
    return u5[p8](p6, p7, p9);
end;

task.spawn(function() -- Line: 49
    -- upvalues: ContentProvider (copy), Descendants (copy)
    ContentProvider:PreloadAsync(Descendants);
end);

return u1;