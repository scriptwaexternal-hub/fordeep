-- Decompiled with Potassium's decompiler.

local Parent = require(script.Parent.Parent);
local Notify = require(script.Parent:WaitForChild("Notify"));

return function(p1) -- Line: 4
    -- upvalues: Notify (copy), Parent (copy)
    return Notify(Parent.Util.Table.merge(p1, {
        Announce = true
    }));
end;