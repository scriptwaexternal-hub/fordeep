-- Decompiled with Potassium's decompiler.

local ReplicatedStorage = game:GetService("ReplicatedStorage");
game:GetService("UserInputService");
local Debris = game:GetService("Debris");
game:GetService("Players");
local Modules = ReplicatedStorage:WaitForChild("Modules");
ReplicatedStorage:WaitForChild("Remotes");
local Assets = ReplicatedStorage.Assets;
local _ = Modules.Metadata;
local Shared = Modules.Shared;
require(Modules.Utility.Create);
local GlobalFunctions = require(Modules.GlobalFunctions);
local SoundManager = require(Shared.SoundManager);
local workspace_World = workspace.World;
local Visuals = workspace_World.Visuals;
local Particles = Assets.Effects.Particles;

local function AfterImage(p1) -- Line: 30
    -- upvalues: Particles (copy), Debris (copy)
    for _, descendant in pairs(p1:GetDescendants()) do
        if descendant:IsA("Part") or (descendant:IsA("MeshPart") or descendant:IsA("UnionOperation")) then
            local Color = descendant.Color;

            if Color ~= BrickColor.new("Medium stone grey") then
                local v2 = Particles.AfterImage_Vfx:Clone();
                v2.Parent = descendant;
                v2.Lifetime = NumberRange.new(1);
                v2.Color = ColorSequence.new({ ColorSequenceKeypoint.new(0, Color), ColorSequenceKeypoint.new(0.5, Color), ColorSequenceKeypoint.new(1, Color) });
                v2:Emit(100);
                Debris:AddItem(v2);
            end;
        end;
    end;
end;

local function Dust(p3) -- Line: 50
    -- upvalues: GlobalFunctions (copy), Visuals (copy), workspace_World (copy), Particles (copy), Debris (copy)
    local RootAndHumanoid, _ = GlobalFunctions.GetRootAndHumanoid(p3);

    if not RootAndHumanoid then
        return;
    end;

    local v4 = GlobalFunctions.CastRay(RootAndHumanoid.Position, Vector3.new(0, -10, 0), { Visuals, workspace_World.Live });

    if not v4 then
        return;
    end;

    local v5 = Particles.Dust:Clone();
    v5.Parent = Visuals;
    v5.CFrame = CFrame.new(v4.Position);
    Debris:AddItem(v5, 5);
    local Color = v4.Instance.Color;
    v5.Effect.Color = ColorSequence.new({ ColorSequenceKeypoint.new(0, Color), ColorSequenceKeypoint.new(0.5, Color), ColorSequenceKeypoint.new(1, Color) });
    v5.Effect:Emit(30);
end;

local function Dash_Effect(p6) -- Line: 76
    -- upvalues: SoundManager (copy)
    local HumanoidRootPart = p6:FindFirstChild("HumanoidRootPart");
    p6:FindFirstChild("Humanoid");
    SoundManager.AddSound("Instant", {
        Parent = HumanoidRootPart
    }, "Client");
end;

return {
    Vanish = function(p7) -- Line: 83
        -- upvalues: AfterImage (copy), SoundManager (copy), Dust (copy)
        local Character = p7.Character;
        local Vanish_Time = p7.Vanish_Time;
        task.spawn(function() -- Line: 86
            -- upvalues: AfterImage (ref), Character (copy), SoundManager (ref), Dust (ref), Vanish_Time (copy)
            for i = 1, 2 do
                AfterImage(Character);
                local v8 = Character;
                local HumanoidRootPart = v8:FindFirstChild("HumanoidRootPart");
                v8:FindFirstChild("Humanoid");
                SoundManager.AddSound("Instant", {
                    Parent = HumanoidRootPart
                }, "Client");
                Dust(Character);
                wait(Vanish_Time);
                local _ = i;
            end;
        end);
    end
};