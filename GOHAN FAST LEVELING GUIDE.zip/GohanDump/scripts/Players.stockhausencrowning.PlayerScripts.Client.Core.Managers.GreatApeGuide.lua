-- Decompiled with Potassium's decompiler.

local Players = game:GetService("Players");
local ReplicatedStorage = game:GetService("ReplicatedStorage");
game:GetService("UserInputService");
local GuiService = game:GetService("GuiService");
local Remotes = ReplicatedStorage:WaitForChild("Remotes");
local ServerRemote = Remotes.ServerRemote;
local TouchActionRemote = Remotes:WaitForChild("TouchActionRemote");
local Modules = ReplicatedStorage:WaitForChild("Modules");
local KamiCard = require(Modules.Shared.KamiCard);
local GamepadGlyphs = require(Modules.Shared.GamepadGlyphs);
local Platform = require(Modules.Shared.Platform);
local ControlData = require(Modules.Metadata.ControlData.ControlData);
local LocalPlayer = Players.LocalPlayer;
local u1 = { "HUD", "MissionGui", "LoreThoughtsGui", "QuestTrackerGui" };
local Color3_fromRGB_ret = Color3.fromRGB(44, 44, 45);
local Color3_fromRGB_ret2 = Color3.fromRGB(28, 28, 30);
local Color3_fromRGB_ret3 = Color3.fromRGB(255, 255, 255);
local Color3_fromRGB_ret4 = Color3.fromRGB(216, 213, 205);
local Color3_fromRGB_ret5 = Color3.fromRGB(0, 0, 0);
local Color3_fromRGB_ret6 = Color3.fromRGB(88, 214, 106);
local Color3_fromRGB_ret7 = Color3.fromRGB(255, 196, 68);
local Color3_fromRGB_ret8 = Color3.fromRGB(140, 138, 132);
local Color3_fromRGB_ret9 = Color3.fromRGB(226, 62, 48);
local Arcade = Enum.Font.Arcade;

local function platform() -- Line: 90
    -- upvalues: Platform (copy)
    local v2 = Platform.Get();

    return v2 == "Console" and "Pad" or (v2 == "Touch" and "Touch" or (Platform.PreferGamepadGlyphs() and "Pad" or "Keyboard"));
end;

local function bindingFor(p3) -- Line: 98
    -- upvalues: ControlData (copy)
    return ControlData.Controls["Great Ape"] and ControlData.Controls["Great Ape"][p3];
end;

local function synthKey(p4) -- Line: 105
    -- upvalues: ControlData (copy)
    local v5 = ControlData.Controls["Great Ape"] and ControlData.Controls["Great Ape"][p4];

    if typeof(v5) == "table" then
        v5 = v5[1] or v5;
    end;

    return v5;
end;

local function chipLabel(p6, p7) -- Line: 111
    -- upvalues: GamepadGlyphs (copy), ControlData (copy)
    local v8, v9 = GamepadGlyphs.Describe(ControlData.Controls["Great Ape"] and ControlData.Controls["Great Ape"][p6]);

    return p7 == "Pad" and (v9 or "--") or (p7 == "Touch" and "TAP" or (v8 or "--"));
end;

local u10 = { {
        Action = "Beam",
        Name = "Mouth Beam",
        Desc = "Fires a beam straight ahead. Long cooldown."
    }, {
        Action = "Grab",
        Name = "Grab",
        Desc = "Snatch a fighter up, then throw them."
    }, {
        Action = "Push",
        Name = "Super Push",
        Desc = "Radial shockwave that hurls everyone nearby."
    } };
local u11 = {};
u11.Beam = ControlData.Controls["Great Ape"] and ControlData.Controls["Great Ape"].Beam_Controls and ControlData.Controls["Great Ape"].Beam_Controls.CD;
u11.Grab = ControlData.Controls["Great Ape"] and ControlData.Controls["Great Ape"].Grab_Controls and ControlData.Controls["Great Ape"].Grab_Controls.CD;
u11.Push = ControlData.Controls["Great Ape"] and ControlData.Controls["Great Ape"].Push_Controls and ControlData.Controls["Great Ape"].Push_Controls.CD;
local u12 = {};
local u13 = false;
local u14 = nil;
local u15 = {};

local function setInterfaceHidden(p16) -- Line: 165
    -- upvalues: LocalPlayer (copy), u15 (copy), u1 (copy)
    local PlayerGui = LocalPlayer:FindFirstChild("PlayerGui");

    if not PlayerGui then
        return;
    end;

    if p16 then
        table.clear(u15);

        for _, v in ipairs(u1) do
            local v17 = PlayerGui:FindFirstChild(v);

            if v17 and v17:IsA("ScreenGui") then
                u15[v] = v17.Enabled;
                v17.Enabled = false;
            end;
        end;

        return;
    end;

    for _, v in ipairs(u1) do
        local v18 = PlayerGui:FindFirstChild(v);

        if v18 and v18:IsA("ScreenGui") then
            local v19 = u15[v];
            v18.Enabled = v19 == nil and true or v19;
        end;
    end;

    table.clear(u15);
end;

local function buildBar(p20, p21, p22, p23, p24, p25) -- Line: 198
    -- upvalues: Color3_fromRGB_ret2 (copy), Color3_fromRGB_ret5 (copy), Arcade (copy), Color3_fromRGB_ret3 (copy)
    local Frame = Instance.new("Frame");
    Frame.Name = p21;
    Frame.AnchorPoint = Vector2.new(0.5, 1);
    Frame.Position = UDim2.new(0.5, 0, 1, p22);
    Frame.Size = UDim2.fromOffset(420, p23);
    Frame.BackgroundColor3 = Color3_fromRGB_ret2;
    Frame.BorderSizePixel = 0;
    Frame.Parent = p20;
    local UIStroke = Instance.new("UIStroke");
    UIStroke.Color = Color3_fromRGB_ret5;
    UIStroke.Thickness = 2;
    UIStroke.Parent = Frame;
    local Frame2 = Instance.new("Frame");
    Frame2.Name = "Fill";
    Frame2.Size = UDim2.fromScale(1, 1);
    Frame2.BackgroundColor3 = p24;
    Frame2.BorderSizePixel = 0;
    Frame2.Parent = Frame;
    local TextLabel = Instance.new("TextLabel");
    TextLabel.Name = "Label";
    TextLabel.Size = UDim2.fromScale(1, 1);
    TextLabel.BackgroundTransparency = 1;
    TextLabel.Font = Arcade;
    TextLabel.TextSize = p25;
    TextLabel.TextColor3 = Color3_fromRGB_ret3;
    TextLabel.TextStrokeColor3 = Color3_fromRGB_ret5;
    TextLabel.TextStrokeTransparency = 0.5;
    TextLabel.Text = "";
    TextLabel.Parent = Frame;

    return Frame, Frame2, TextLabel;
end;

function u12.Fire(u26) -- Line: 236
    -- upvalues: u13 (ref), Platform (copy), u10 (copy), setInterfaceHidden (copy), LocalPlayer (copy), buildBar (copy), Color3_fromRGB_ret9 (copy), Color3_fromRGB_ret7 (copy), ControlData (copy), Color3_fromRGB_ret (copy), Color3_fromRGB_ret5 (copy), Arcade (copy), Color3_fromRGB_ret6 (copy), GamepadGlyphs (copy), Color3_fromRGB_ret4 (copy), u11 (copy), Color3_fromRGB_ret8 (copy), TouchActionRemote (copy), GuiService (copy), KamiCard (copy), ServerRemote (copy), u14 (ref)
    if u13 then
        return;
    end;

    u13 = true;
    local v27;

    if u26 then
        v27 = u26.ShowGuide;
    else
        v27 = u26;
    end;

    local v28;

    if u26 then
        v28 = u26.Berserk;
    else
        v28 = u26;
    end;

    local u29 = v28 == true;
    local v30;

    if u26 then
        v30 = u26.StarAt;
    else
        v30 = u26;
    end;

    local u31 = tonumber(v30) or 20;
    local v32 = Platform.Get();
    local v33 = v32 == "Console" and "Pad" or (v32 == "Touch" and "Touch" or (Platform.PreferGamepadGlyphs() and "Pad" or "Keyboard"));
    local u34 = u26 and (u26.FormState or "GreatApe") or "GreatApe";
    local u35 = u26 and (u26.MasteryAttr or "ApeMastery") or "ApeMastery";
    local u36 = tostring(u26 and (u26.StarsLabel or "STAR 1 OF 5") or "STAR 1 OF 5");
    local v37 = u26 and (u26.Guide or {
        Counter = "GREAT APE",
        Title = "You\'ve Turned Oozaru",
        Footnote = "Punch and heavy are unchanged."
    }) or {
        Counter = "GREAT APE",
        Title = "You\'ve Turned Oozaru",
        Footnote = "Punch and heavy are unchanged."
    };
    local v38 = u10;

    if u26 and type(u26.Abilities) == "table" then
        v38 = {};

        for _, v in ipairs(u10) do
            if table.find(u26.Abilities, v.Action) then
                v38[#v38 + 1] = v;
            end;
        end;
    end;

    setInterfaceHidden(true);
    local PlayerGui = LocalPlayer:WaitForChild("PlayerGui");
    local GreatApePanelGui = PlayerGui:FindFirstChild("GreatApePanelGui");

    if GreatApePanelGui then
        GreatApePanelGui:Destroy();
    end;

    local ScreenGui = Instance.new("ScreenGui");
    ScreenGui.Name = "GreatApePanelGui";
    ScreenGui.ResetOnSpawn = false;
    ScreenGui.DisplayOrder = 55;
    ScreenGui.IgnoreGuiInset = true;
    ScreenGui.Parent = PlayerGui;
    local Frame = Instance.new("Frame");
    Frame.Name = "Scaler";
    Frame.Size = UDim2.fromScale(1, 1);
    Frame.BackgroundTransparency = 1;
    Frame.Parent = ScreenGui;
    local UIScale = Instance.new("UIScale");
    UIScale.Parent = Frame;

    local function fitPanel() -- Line: 304
        -- upvalues: UIScale (copy)
        local workspace_CurrentCamera = workspace.CurrentCamera;

        if workspace_CurrentCamera then
            workspace_CurrentCamera = workspace_CurrentCamera.ViewportSize;
        end;

        if not workspace_CurrentCamera or workspace_CurrentCamera.X <= 0 then
            return;
        end;

        UIScale.Scale = math.clamp(workspace_CurrentCamera.X * 0.88 / 420, 0.6, 1);
    end;

    local workspace_CurrentCamera = workspace.CurrentCamera;
    local v39 = workspace_CurrentCamera and workspace_CurrentCamera.ViewportSize;

    if v39 and v39.X > 0 then
        UIScale.Scale = math.clamp(v39.X * 0.88 / 420, 0.6, 1);
    end;

    local u40;

    if workspace.CurrentCamera then
        u40 = workspace.CurrentCamera:GetPropertyChangedSignal("ViewportSize"):Connect(fitPanel);
    else
        u40 = nil;
    end;

    local _, u41, u42 = buildBar(Frame, "ApeHealth", u29 and -28 or -8, 22, Color3_fromRGB_ret9, 15);
    local u43, u44;

    if u29 then
        local v45;
        v45, u43, u44 = buildBar(Frame, "ApeMastery", -8, 16, Color3_fromRGB_ret7, 12);
    else
        u43 = nil;
        u44 = nil;
    end;

    local Frame2 = Instance.new("Frame");
    Frame2.Name = "Abilities";
    Frame2.AnchorPoint = Vector2.new(0.5, 1);
    Frame2.Position = UDim2.new(0.5, 0, 1, u29 and -58 or -38);
    Frame2.Size = UDim2.fromOffset(420, 54);
    Frame2.BackgroundTransparency = 1;
    Frame2.Parent = Frame;
    local UIListLayout = Instance.new("UIListLayout");
    UIListLayout.FillDirection = Enum.FillDirection.Horizontal;
    UIListLayout.HorizontalAlignment = Enum.HorizontalAlignment.Center;
    UIListLayout.VerticalAlignment = Enum.VerticalAlignment.Center;
    UIListLayout.SortOrder = Enum.SortOrder.LayoutOrder;
    UIListLayout.Padding = UDim.new(0, 10);
    UIListLayout.Parent = Frame2;
    local v46 = nil;
    local u47 = {};

    for i, v in ipairs(v38) do
        local u48 = ControlData.Controls["Great Ape"] and ControlData.Controls["Great Ape"][v.Action];

        if typeof(u48) == "table" then
            u48 = u48[1] or u48;
        end;

        local TextButton = Instance.new("TextButton");
        TextButton.Name = v.Action;
        TextButton.Size = UDim2.fromOffset(150, 46);
        TextButton.BackgroundColor3 = Color3_fromRGB_ret;
        TextButton.BorderSizePixel = 0;
        TextButton.Text = "";
        TextButton.AutoButtonColor = true;
        TextButton.LayoutOrder = i;
        TextButton.Selectable = true;
        TextButton.Parent = Frame2;
        local UIStroke = Instance.new("UIStroke");
        UIStroke.Color = Color3_fromRGB_ret5;
        UIStroke.Thickness = 2;
        UIStroke.Parent = TextButton;
        local Frame3 = Instance.new("Frame");
        Frame3.Name = "Cooldown";
        Frame3.Size = UDim2.fromScale(0, 1);
        Frame3.BackgroundColor3 = Color3_fromRGB_ret5;
        Frame3.BackgroundTransparency = 0.55;
        Frame3.BorderSizePixel = 0;
        Frame3.ZIndex = 0;
        Frame3.Parent = TextButton;
        local TextLabel = Instance.new("TextLabel");
        TextLabel.Position = UDim2.fromOffset(10, 4);
        TextLabel.Size = UDim2.new(1, -20, 0, 20);
        TextLabel.BackgroundTransparency = 1;
        TextLabel.Font = Arcade;
        TextLabel.TextSize = 17;
        TextLabel.TextColor3 = Color3_fromRGB_ret6;
        TextLabel.TextXAlignment = Enum.TextXAlignment.Left;
        TextLabel.TextStrokeColor3 = Color3_fromRGB_ret5;
        TextLabel.TextStrokeTransparency = 0.5;
        TextLabel.ZIndex = 2;
        TextLabel.Text = string.upper(v.Name);
        TextLabel.Parent = TextButton;
        local v49, v50 = GamepadGlyphs.Describe(ControlData.Controls["Great Ape"] and ControlData.Controls["Great Ape"][v.Action]);
        local u51 = v33 == "Pad" and (v50 or "--") or (v33 == "Touch" and "TAP" or (v49 or "--"));
        local TextLabel2 = Instance.new("TextLabel");
        TextLabel2.AnchorPoint = Vector2.new(1, 1);
        TextLabel2.Position = UDim2.new(1, -8, 1, -5);
        TextLabel2.Size = UDim2.fromOffset(90, 18);
        TextLabel2.BackgroundTransparency = 1;
        TextLabel2.Font = Arcade;
        TextLabel2.TextSize = 14;
        TextLabel2.TextColor3 = Color3_fromRGB_ret4;
        TextLabel2.TextXAlignment = Enum.TextXAlignment.Right;
        TextLabel2.TextStrokeColor3 = Color3_fromRGB_ret5;
        TextLabel2.TextStrokeTransparency = 0.5;
        TextLabel2.ZIndex = 2;
        TextLabel2.Text = u51;
        TextLabel2.Parent = TextButton;

        if u48 then
            local u52 = "ApeCD_" .. v.Action;

            local function refreshCooldown() -- Line: 447
                -- upvalues: LocalPlayer (ref), u52 (copy), u11 (ref), v (copy), TextLabel2 (copy), Color3_fromRGB_ret8 (ref), TextLabel (copy), Frame3 (copy), u51 (copy), u29 (copy), Color3_fromRGB_ret4 (ref), Color3_fromRGB_ret6 (ref)
                local Character = LocalPlayer.Character;

                if Character then
                    Character = Character:GetAttribute(u52);
                end;

                local v53 = Character and Character - workspace:GetServerTimeNow() or 0;

                if v53 <= 0 then
                    TextLabel2.Text = u51;
                    TextLabel2.TextColor3 = u29 and Color3_fromRGB_ret8 or Color3_fromRGB_ret4;
                    TextLabel.TextColor3 = u29 and Color3_fromRGB_ret8 or Color3_fromRGB_ret6;
                    Frame3.Size = UDim2.fromScale(0, 1);

                    return;
                end;

                local v54 = u11[v.Action] or v53;
                local math_ceil_ret = math.ceil(v53);
                TextLabel2.Text = tostring(math_ceil_ret);
                TextLabel2.TextColor3 = Color3_fromRGB_ret8;
                TextLabel.TextColor3 = Color3_fromRGB_ret8;
                Frame3.Size = UDim2.fromScale(math.clamp(v53 / v54, 0, 1), 1);
            end;

            refreshCooldown();
            table.insert(u47, refreshCooldown);

            if u29 then
                TextButton.AutoButtonColor = false;
                TextButton.Selectable = false;
                TextButton.BackgroundTransparency = 0.35;
                UIStroke.Transparency = 0.35;
            else
                TextButton.MouseButton1Click:Connect(function() -- Line: 490
                    -- upvalues: TouchActionRemote (ref), v (copy), u48 (copy), refreshCooldown (copy)
                    TouchActionRemote:Fire("SynthKey", v.Action, u48, "Begin");
                    task.defer(function() -- Line: 494
                        -- upvalues: TouchActionRemote (ref), v (ref), u48 (ref), refreshCooldown (ref)
                        TouchActionRemote:Fire("SynthKey", v.Action, u48, "End");
                        refreshCooldown();
                    end);
                end);
                v46 = v46 or TextButton;
            end;
        else
            TextButton.AutoButtonColor = false;
            TextLabel.TextColor3 = Color3_fromRGB_ret4;
            TextLabel2.Text = "UNBOUND";
        end;
    end;

    if v33 == "Pad" and v46 then
        Frame2.SelectionGroup = true;
        Frame2.SelectionBehaviorLeft = Enum.SelectionBehavior.Stop;
        Frame2.SelectionBehaviorRight = Enum.SelectionBehavior.Stop;
        GuiService.SelectedObject = v46;
    end;

    task.spawn(function() -- Line: 527
        -- upvalues: u13 (ref), u47 (copy)
        while u13 do
            for _, v in ipairs(u47) do
                v();
            end;

            task.wait(0.25);
        end;
    end);

    local function bindHealth(u55) -- Line: 537
        -- upvalues: u41 (copy), u42 (copy)
        if u55 then
            u55 = u55:FindFirstChildOfClass("Humanoid");
        end;

        if not u55 then
            return;
        end;

        local function refresh() -- Line: 540
            -- upvalues: u55 (copy), u41 (ref), u42 (ref)
            local math_max_ret = math.max(u55.MaxHealth, 1);
            u41.Size = UDim2.fromScale(math.clamp(u55.Health / math_max_ret, 0, 1), 1);
            u42.Text = string.format("%d / %d", math.floor(u55.Health + 0.5), (math.floor(math_max_ret + 0.5)));
        end;

        refresh();
        u55.HealthChanged:Connect(refresh);
        u55:GetPropertyChangedSignal("MaxHealth"):Connect(refresh);
    end;

    bindHealth(LocalPlayer.Character);

    if u29 and u43 then
        local function refreshMastery() -- Line: 563
            -- upvalues: LocalPlayer (ref), u35 (copy), u26 (copy), u43 (ref), u31 (copy), u44 (ref), u36 (copy)
            local Character = LocalPlayer.Character;

            if Character then
                Character = Character:GetAttribute(u35);
            end;

            local v56 = tonumber(Character);

            if not v56 then
                v56 = tonumber(u26 and u26.Mastery) or 0;
            end;

            u43.Size = UDim2.fromScale(math.clamp(v56 / u31, 0, 1), 1);
            u44.Text = string.format("MASTERY   %.1f / %d   %s", v56, u31, u36);
        end;

        refreshMastery();
        table.insert(u47, refreshMastery);
        local Character = LocalPlayer.Character;

        if Character then
            Character:GetAttributeChangedSignal(u35):Connect(refreshMastery);
        end;
    end;

    local u57;

    if v27 == true then
        local v58 = {};

        for i, v in ipairs(v38) do
            local v59 = {
                Name = v.Name,
                Desc = v.Desc
            };
            local v60 = {};
            local v61, v62 = GamepadGlyphs.Describe(ControlData.Controls["Great Ape"] and ControlData.Controls["Great Ape"][v.Action]);
            v60[1] = v33 == "Pad" and (v62 or "--") or (v33 == "Touch" and "TAP" or (v61 or "--"));
            v59.Keys = v60;
            v58[i] = v59;
        end;

        u57 = KamiCard.new({
            Name = "GreatApeGuideGui",
            Height = 210,
            BottomOffset = -104
        });
        u57:Render({
            Speaker = "Kami",
            Button = "GOT IT",
            Counter = v37.Counter,
            Title = v37.Title,
            Rows = v58,
            Footnote = v37.Footnote
        });
        local u63 = false;
        u57.Button.MouseButton1Click:Connect(function() -- Line: 610
            -- upvalues: u63 (ref), ServerRemote (ref), u57 (ref)
            if u63 then
                return;
            end;

            u63 = true;
            ServerRemote:FireServer(nil, {
                Module = "GreatApeGuideHandler",
                Action = "Finish"
            });
            u57:Dismiss();
        end);
        u57:SlideIn();
    else
        u57 = nil;
    end;

    local function teardown() -- Line: 625
        -- upvalues: u13 (ref), u40 (ref), GuiService (ref), ScreenGui (copy), u57 (ref), setInterfaceHidden (ref)
        if not u13 then
            return;
        end;

        u13 = false;

        if u40 then
            u40:Disconnect();
            u40 = nil;
        end;

        if GuiService.SelectedObject and GuiService.SelectedObject:IsDescendantOf(ScreenGui) then
            GuiService.SelectedObject = nil;
        end;

        if u57 then
            u57:Destroy();
        end;

        ScreenGui:Destroy();
        setInterfaceHidden(false);
    end;

    u14 = teardown;
    local Character = LocalPlayer.Character;
    local v64 = Character and Character:FindFirstChildOfClass("Humanoid");

    if v64 then
        v64.Died:Once(function() -- Line: 644
            -- upvalues: teardown (copy)
            teardown();
        end);
    end;

    LocalPlayer.CharacterRemoving:Once(function() -- Line: 645
        -- upvalues: teardown (copy)
        teardown();
    end);
    task.spawn(function() -- Line: 659
        -- upvalues: u13 (ref), LocalPlayer (ref), u34 (copy), teardown (copy)
        local v65 = os.clock() + 5;
        local v66 = false;

        while u13 do
            local Character2 = LocalPlayer.Character;

            if Character2 and Character2.Parent then
                if Character2:GetAttribute("State_" .. u34) == true then
                    v66 = true;
                elseif v66 or v65 < os.clock() then
                    break;
                end;
            elseif v66 or v65 < os.clock() then
                break;
            end;

            task.wait(0.5);
        end;

        teardown();
    end);
    local u67 = nil;
    u67 = LocalPlayer.CharacterAdded:Connect(function(p68) -- Line: 683
        -- upvalues: u13 (ref), u67 (ref), setInterfaceHidden (ref), bindHealth (copy)
        if not u13 then
            if u67 then
                u67:Disconnect();
            end;

            return;
        end;

        task.wait(1);

        if not u13 then
            return;
        end;

        setInterfaceHidden(true);
        bindHealth(p68);
    end);
end;

function u12.Refire(p69) -- Line: 697
    -- upvalues: u14 (ref), u12 (copy)
    if u14 then
        u14();
    end;

    task.wait();
    u12.Fire(p69);
end;

function u12.Clear() -- Line: 705
    -- upvalues: u14 (ref)
    if u14 then
        u14();
    end;
end;

return u12;