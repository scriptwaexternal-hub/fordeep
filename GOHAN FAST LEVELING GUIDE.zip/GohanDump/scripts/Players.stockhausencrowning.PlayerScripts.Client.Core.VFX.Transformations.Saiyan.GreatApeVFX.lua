-- Decompiled with Potassium's decompiler.

local Players = game:GetService("Players");
local Debris = game:GetService("Debris");
local ReplicatedStorage = game:GetService("ReplicatedStorage");
local Lighting = game:GetService("Lighting");
local RunService = game:GetService("RunService");
local _ = ReplicatedStorage.Assets;
local Modules = ReplicatedStorage:WaitForChild("Modules");
local Remotes = ReplicatedStorage:WaitForChild("Remotes");
local Metadata = Modules.Metadata;
local Shared = Modules.Shared;
local SoundManager = require(Shared.SoundManager);
local GlobalFunctions = require(Modules.GlobalFunctions);
require(Shared.CamManager);
local CinemaManager = require(Shared.CinemaManager);
local SkillData = require(Metadata.SkillData.SkillData);
local StateManager = require(ReplicatedStorage.Modules.Metadata.ControlData.StateManager);
local ServerRemote = Remotes.ServerRemote;
local LocalPlayer = Players.LocalPlayer;
local Visuals = workspace.World.Visuals;
local workspace_CurrentCamera = workspace.CurrentCamera;
local v1 = {};

local function lerp(p2, p3, p4) -- Line: 77
    return p2 + (p3 - p2) * p4;
end;

local u5 = { {
        upTo = 0.3,
        words = { "I feel power", "I feel strong", "So much energy", "My blood is boiling", "Stronger...", "What is this?", "My heart..." }
    }, {
        upTo = 0.6,
        words = { "MORE", "I want to fight", "Can\'t hold it back", "It\'s taking over", "CRUSH THEM", "LET ME OUT", "I NEED TO HIT SOMETHING", "NO CONTROL" }
    }, {
        upTo = 1,
        words = { "ME DESTROY", "MUST KILL", "SMASH", "ME STRONG", "KILL KILL KILL", "BREAK", "ME CRUSH", "NO THINK", "RAAGH", "ME HUNGRY FOR FIGHT" }
    } };
local Color3_fromRGB_ret = Color3.fromRGB(0, 0, 0);
local Color3_fromRGB_ret2 = Color3.fromRGB(255, 255, 255);
local Color3_fromRGB_ret3 = Color3.fromRGB(255, 45, 30);
local u6 = {
    Vector2.new(0, -1),
    Vector2.new(0, 1),
    Vector2.new(-1, 0),
    Vector2.new(1, 0),
    Vector2.new(-1, -1),
    Vector2.new(1, -1),
    Vector2.new(-1, 1),
    Vector2.new(1, 1)
};

local function pickWord(p7) -- Line: 120
    -- upvalues: u5 (copy)
    for _, v in ipairs(u5) do
        if p7 <= v.upTo then
            return v.words[math.random(1, #v.words)];
        end;
    end;

    local words = u5[#u5].words;

    return words[math.random(1, #words)];
end;

local function makeWordLabel(p8, p9, p10) -- Line: 130
    -- upvalues: Color3_fromRGB_ret2 (copy), Color3_fromRGB_ret3 (copy), Color3_fromRGB_ret (copy)
    local TextLabel = Instance.new("TextLabel");
    TextLabel.BackgroundTransparency = 1;
    TextLabel.AnchorPoint = Vector2.new(0.5, 0.5);
    TextLabel.Font = p10 > 0.6 and Enum.Font.Arcade or Enum.Font.Bangers;
    local v11 = 26 + 28 * p10 + math.random(-6, 6);
    TextLabel.TextSize = math.floor(v11);
    TextLabel.TextColor3 = Color3_fromRGB_ret2:Lerp(Color3_fromRGB_ret3, (math.clamp((p10 - 0.3) / 0.7, 0, 1)));
    TextLabel.TextStrokeColor3 = Color3_fromRGB_ret;
    TextLabel.TextStrokeTransparency = 0.3;
    TextLabel.TextTransparency = 1;
    TextLabel.Text = p9;
    TextLabel.AutomaticSize = Enum.AutomaticSize.XY;
    TextLabel.Size = UDim2.fromOffset(0, 0);
    TextLabel.Rotation = math.random(-45, 45);
    TextLabel.ZIndex = 5;
    TextLabel.Parent = p8;

    return TextLabel;
end;

local function startWordStorm(p12, p13, u14) -- Line: 149
    -- upvalues: LocalPlayer (copy), RunService (copy), workspace_CurrentCamera (copy), makeWordLabel (copy), pickWord (copy), u6 (copy), Color3_fromRGB_ret3 (copy), Color3_fromRGB_ret (copy), Color3_fromRGB_ret2 (copy)
    local PlayerGui = LocalPlayer:WaitForChild("PlayerGui");
    local ApeWordStorm = PlayerGui:FindFirstChild("ApeWordStorm");

    if ApeWordStorm then
        ApeWordStorm:Destroy();
    end;

    local ScreenGui = Instance.new("ScreenGui");
    ScreenGui.Name = "ApeWordStorm";
    ScreenGui.ResetOnSpawn = false;
    ScreenGui.IgnoreGuiInset = true;
    ScreenGui.DisplayOrder = 80;
    ScreenGui.Parent = PlayerGui;
    local u15 = true;
    local u16 = {};
    local u17 = p12 + p13 - 1;
    local u18 = p12 + p13 + 0.6;
    local os_clock_ret = os.clock();
    local u19 = 0.15;
    local u20 = nil;
    local u30 = RunService.RenderStepped:Connect(function() -- Line: 170
        -- upvalues: u15 (ref), os_clock_ret (copy), workspace_CurrentCamera (ref), u17 (copy), u19 (ref), u16 (copy), makeWordLabel (ref), ScreenGui (copy), pickWord (ref), u6 (ref), u18 (copy), u20 (ref), Color3_fromRGB_ret3 (ref), Color3_fromRGB_ret (ref), u14 (copy), Color3_fromRGB_ret2 (ref)
        if not u15 then
            return;
        end;

        local v21 = os.clock() - os_clock_ret;
        local ViewportSize = workspace_CurrentCamera.ViewportSize;

        if v21 < u17 and u19 <= v21 then
            local math_clamp_ret = math.clamp(v21 / u17, 0, 1);

            if #u16 < 18 then
                local v22 = makeWordLabel(ScreenGui, pickWord(math_clamp_ret), math_clamp_ret);
                v22.Position = UDim2.fromOffset(math.random(math.floor(ViewportSize.X * 0.12), (math.floor(ViewportSize.X * 0.88))), math.random(math.floor(ViewportSize.Y * 0.12), (math.floor(ViewportSize.Y * 0.88))));
                u16[#u16 + 1] = {
                    Label = v22,
                    Born = v21,
                    Dir = u6[math.random(1, #u6)],
                    Origin = v22.Position,
                    Spin = math.random(-25, 25)
                };
            end;

            u19 = v21 + (1.4 + -1.22 * math_clamp_ret ^ 1.5);
        end;

        for i = #u16, 1, -1 do
            local v23 = u16[i];
            local v24 = (v21 - v23.Born) / 2.4;
            local v25;

            if u17 <= v21 then
                v25 = 1 - math.clamp((v21 - u17) / 0.6, 0, 1);
            else
                v25 = v24 < 0.2 and v24 / 0.2 or (v24 > 0.75 and ((1 - v24) / 0.25 or 1) or 1);
            end;

            local v26;

            if v24 >= 1 then
                v26 = true;
            elseif u17 <= v21 then
                v26 = v25 <= 0;
            else
                v26 = false;
            end;

            local v27;

            if v26 then
                v23.Label:Destroy();
                table.remove(u16, i);
                v27 = i;
            else
                local v28 = v23.Dir * (220 * v24);
                v23.Label.Position = v23.Origin + UDim2.fromOffset(v28.X, v28.Y);
                v23.Label.Rotation = v23.Label.Rotation + v23.Spin * 0.016666666666666666;
                v23.Label.TextTransparency = 1 - v25;
                v23.Label.TextStrokeTransparency = 1 - v25 * 0.7;
                v27 = i;
            end;
        end;

        if u18 <= v21 then
            if not u20 then
                u20 = Instance.new("TextLabel");
                u20.BackgroundTransparency = 1;
                u20.AnchorPoint = Vector2.new(0.5, 0.5);
                u20.Size = UDim2.new(1, 0, 0, 120);
                u20.Font = Enum.Font.Arcade;
                u20.TextScaled = true;
                u20.TextColor3 = Color3_fromRGB_ret3;
                u20.TextStrokeColor3 = Color3_fromRGB_ret;
                u20.TextStrokeTransparency = 0;
                u20.Text = "ROAAAAAAAAAAARRRRRRRR!!!!!!!!";
                u20.ZIndex = 10;
                u20.Parent = ScreenGui;
                local UITextSizeConstraint = Instance.new("UITextSizeConstraint");
                UITextSizeConstraint.MaxTextSize = 96;
                UITextSizeConstraint.Parent = u20;
            end;

            local v29 = math.clamp((v21 - u18) / u14, 0, 1) * 0.6 + 1;
            u20.Position = UDim2.new(0.5, math.random(-22, 22) * v29, 0.5, math.random(-22, 22) * v29);
            u20.Rotation = 0;
            u20.TextColor3 = math.random() < 0.15 and Color3_fromRGB_ret2 or Color3_fromRGB_ret3;
        end;
    end);

    return function() -- Line: 240
        -- upvalues: u15 (ref), u30 (ref), ScreenGui (copy)
        if not u15 then
            return;
        end;

        u15 = false;
        u30:Disconnect();
        ScreenGui:Destroy();
    end;
end;

local function easeInOut(p31) -- Line: 254
    if p31 < 0.5 then
        return 4 * p31 * p31 * p31;
    end;

    local v32 = -2 * p31 + 2;

    return 1 - v32 * v32 * v32 / 2;
end;

local function flatLook(p33) -- Line: 263
    local Vector3_new_ret = Vector3.new(p33.LookVector.X, 0, p33.LookVector.Z);

    return Vector3_new_ret.Magnitude < 0.0001 and Vector3.new(0, 0, -1) or Vector3_new_ret.Unit;
end;

function v1.Transform(p34) -- Line: 269
    -- upvalues: workspace_CurrentCamera (copy), CinemaManager (copy), LocalPlayer (copy), startWordStorm (copy), RunService (copy)
    local Character = p34.Character;

    if not Character then
        return;
    end;

    local HumanoidRootPart = Character:FindFirstChild("HumanoidRootPart");

    if not (HumanoidRootPart and Character:FindFirstChild("Head")) then
        return;
    end;

    local u35 = p34.HeartbeatTime or 4;
    local u36 = p34.TwirlTime or 5;
    local u37 = p34.RoarTime or 3;
    local u38 = u35 + u36 + u37;
    local CFrame2 = HumanoidRootPart.CFrame;
    local Vector3_new_ret = Vector3.new(CFrame2.LookVector.X, 0, CFrame2.LookVector.Z);
    local u39 = Vector3_new_ret.Magnitude < 0.0001 and Vector3.new(0, 0, -1) or Vector3_new_ret.Unit;
    local FieldOfView = workspace_CurrentCamera.FieldOfView;
    local CameraType = workspace_CurrentCamera.CameraType;
    CinemaManager.FadeIn(LocalPlayer);
    workspace_CurrentCamera.CameraType = Enum.CameraType.Scriptable;
    local u40 = startWordStorm(u35, u36, u37);
    local u41 = nil;
    local u42 = false;

    local function endCinematic() -- Line: 301
        -- upvalues: u42 (ref), u41 (ref), u40 (copy), workspace_CurrentCamera (ref), FieldOfView (copy), CameraType (copy), CinemaManager (ref), LocalPlayer (ref)
        if u42 then
            return;
        end;

        u42 = true;

        if u41 then
            u41:Disconnect();
        end;

        u40();
        workspace_CurrentCamera.FieldOfView = FieldOfView;
        workspace_CurrentCamera.CameraType = CameraType == Enum.CameraType.Scriptable and Enum.CameraType.Custom or CameraType;
        CinemaManager.FadeOut(LocalPlayer);
    end;

    local os_clock_ret = os.clock();
    u41 = RunService.RenderStepped:Connect(function() -- Line: 314
        -- upvalues: u42 (ref), Character (copy), u41 (ref), u40 (copy), workspace_CurrentCamera (ref), FieldOfView (copy), CameraType (copy), CinemaManager (ref), LocalPlayer (ref), os_clock_ret (copy), u35 (copy), u39 (copy), u36 (copy), u38 (copy), u37 (copy)
        if u42 then
            return;
        end;

        local HumanoidRootPart2 = Character:FindFirstChild("HumanoidRootPart");
        local Head = Character:FindFirstChild("Head");

        if not (HumanoidRootPart2 and Character.Parent) then
            if u42 then
                return;
            end;

            u42 = true;

            if u41 then
                u41:Disconnect();
            end;

            u40();
            workspace_CurrentCamera.FieldOfView = FieldOfView;
            workspace_CurrentCamera.CameraType = CameraType == Enum.CameraType.Scriptable and Enum.CameraType.Custom or CameraType;
            CinemaManager.FadeOut(LocalPlayer);

            return;
        end;

        local v43 = os.clock() - os_clock_ret;
        local Position = HumanoidRootPart2.Position;

        if v43 < u35 then
            if Head then
                Position = Head.Position or Position;
            end;

            local v44 = Position + Vector3.new(0, 0.35, 0);
            workspace_CurrentCamera.CFrame = CFrame.lookAt(v44 + u39 * 2.4, v44);

            return;
        end;

        if v43 < u35 + u36 then
            local v45 = (v43 - u35) / u36;
            local v46;

            if v45 < 0.5 then
                v46 = 4 * v45 * v45 * v45;
            else
                local v47 = -2 * v45 + 2;
                v46 = 1 - v47 * v47 * v47 / 2;
            end;

            local v48 = CFrame.fromAxisAngle(Vector3.new(0, 1, 0), v46 * 1 * 3.141592653589793 * 2) * u39;
            local v49 = Position + Vector3.new(0, 1.5 + 4.5 * v45, 0);
            workspace_CurrentCamera.CFrame = CFrame.lookAt(v49 + v48 * (7 + 25 * v45) + Vector3.new(0, 1.5 + -3.5 * v45, 0), v49);

            return;
        end;

        if v43 >= u38 then
            if u42 then
                return;
            end;

            u42 = true;

            if u41 then
                u41:Disconnect();
            end;

            u40();
            workspace_CurrentCamera.FieldOfView = FieldOfView;
            workspace_CurrentCamera.CameraType = CameraType == Enum.CameraType.Scriptable and Enum.CameraType.Custom or CameraType;
            CinemaManager.FadeOut(LocalPlayer);

            return;
        end;

        local v50 = (v43 - u35 - u36) / u37;
        local v51;

        if v50 < 0.5 then
            v51 = 4 * v50 * v50 * v50;
        else
            local v52 = -2 * v50 + 2;
            v51 = 1 - v52 * v52 * v52 / 2;
        end;

        local v53 = Position + Vector3.new(0, 6 + 1 * v51, 0);
        local v54 = FieldOfView;
        workspace_CurrentCamera.FieldOfView = v54 + (FieldOfView * 1.25 - v54) * v51;
        workspace_CurrentCamera.CFrame = CFrame.lookAt(v53 + u39 * (32 + 2 * v51) + Vector3.new(0, -2 + 1 * v51, 0), v53);
    end);
    task.delay(u38 + 2, endCinematic);
end;

function v1.Roar(p55) -- Line: 384
    -- upvalues: GlobalFunctions (copy), Visuals (copy), Debris (copy)
    local Character = p55.Character;
    local u56 = Character:FindFirstChild("Head") or GlobalFunctions.FindFakeHead(Character);

    if not u56 then
        return;
    end;

    local function createLine() -- Line: 391
        -- upvalues: u56 (copy), Visuals (ref), Debris (ref), GlobalFunctions (ref)
        local v57 = u56.CFrame * CFrame.new(math.random(-5, 5), math.random(-5, 5), math.random(-5, 5));
        local Part = Instance.new("Part");
        Part.Parent = Visuals;
        Part.Size = Vector3.new(0.4, 0.4, 17);
        Part.CFrame = CFrame.lookAt(v57.Position, u56.Position);
        Part.Material = Enum.Material.Neon;
        Part.Anchored = true;
        Part.Color = Color3.fromRGB(0, 0, 0);
        Part.CanCollide = false;
        Debris:AddItem(Part, 1);
        GlobalFunctions.Tween({
            Duration = 1,
            Instance = Part
        }, {
            Size = Vector3.new(0.1, 0.1, 2),
            Transparency = 1,
            CFrame = Part.CFrame * CFrame.new(0, 0, 50)
        });
    end;

    for i = 1, 150 do
        createLine();
        local _ = i;
    end;
end;

function v1.Beam(p58) -- Line: 428
    -- upvalues: GlobalFunctions (copy), Visuals (copy), Debris (copy)
    local Character = p58.Character;
    local u59 = Character:FindFirstChild("Head") or GlobalFunctions.FindFakeHead(Character);

    if not u59 then
        return;
    end;

    local function v64() -- Line: 433
        -- upvalues: u59 (copy), Visuals (ref), Debris (ref), GlobalFunctions (ref)
        local v60 = u59.CFrame * CFrame.new(0, 0, -40);
        local v61 = math.random(10, 150) * (math.random(0, 1) == 1 and -1 or 1);
        local math_random_ret = math.random(-150, 150);
        local math_random_ret2 = math.random(10, 150);
        local v62 = math.random(0, 1) == 1 and -1 or 1;
        local v63 = v60 * CFrame.new(v61, math_random_ret, math_random_ret2 * v62);
        local Part = Instance.new("Part");
        Part.Parent = Visuals;
        Part.Size = Vector3.new(0.4, 0.4, 17);
        Part.CFrame = CFrame.lookAt(v63.Position, v60.Position);
        Part.Material = Enum.Material.Neon;
        Part.Anchored = true;
        Part.Color = Color3.fromRGB(255, 255, 255);
        Part.CanCollide = false;
        Debris:AddItem(Part, 2);
        GlobalFunctions.Tween({
            Duration = 2,
            Instance = Part
        }, {
            Size = Vector3.new(0.1, 0.1, 0.1),
            Transparency = 1,
            Position = v60.Position
        });
    end;

    for i = 1, 150 do
        v64();
        task.wait();
        local _ = i;
    end;
end;

v1["Moon Check"] = function(p65) -- Line: 474
    -- upvalues: SkillData (copy), Lighting (copy), StateManager (copy), workspace_CurrentCamera (copy), SoundManager (copy), ServerRemote (copy), LocalPlayer (copy)
    local Character = p65.Character;
    local _ = SkillData["Race Skills"].Saiyan["Ape Transformation"].Cooldown;
    local u66 = 0;

    local function moonFunction() -- Line: 479
        -- upvalues: Character (copy), Lighting (ref), StateManager (ref), workspace_CurrentCamera (ref), u66 (ref), SoundManager (ref), ServerRemote (ref)
        local HumanoidRootPart = Character:FindFirstChild("HumanoidRootPart");

        if not HumanoidRootPart then
            return;
        end;

        local ClockTime = Lighting.ClockTime;

        if ClockTime >= 6 and ClockTime <= 18 then
            return;
        end;

        if StateManager.IsInState(Character, "GreatApe") or Character:FindFirstChild("Ape Cooldown") then
            return;
        end;

        if not StateManager.CanPerformAction(Character, "Ape Transformation") then
            return;
        end;

        local MoonDirection = Lighting:GetMoonDirection();
        local v67 = workspace_CurrentCamera.CFrame.LookVector:Dot(MoonDirection);
        local math_acos_ret = math.acos(v67);

        if math.deg(math_acos_ret) < 15 then
            u66 = u66 + 1;
            SoundManager.AddSound("Heart Beat", {
                Parent = HumanoidRootPart,
                Volume = (u66 + 0.5) / 3
            }, "Client");

            if u66 >= 5 then
                u66 = 0;
                ServerRemote:FireServer(nil, {
                    Module = "Ape Transformation",
                    Action = "QuickFire"
                });
            end;
        else
            u66 = 0;
        end;
    end;

    task.spawn(function() -- Line: 518
        -- upvalues: LocalPlayer (ref), Character (copy), moonFunction (copy)
        while LocalPlayer and (Character and Character.Parent ~= nil) do
            task.wait(1.5);
            moonFunction();
        end;
    end);
end;

return v1;