-- Decompiled with Potassium's decompiler.

local TweenService = game:GetService("TweenService");

return {
    Invis = function(p1, p2, p3, p4, p5, p6, p7) -- Line: 5, Name: Invis
        -- upvalues: TweenService (copy)
        local TweenInfo_new_ret = TweenInfo.new(p3 or 0.001, Enum.EasingStyle[p5 or "Linear"], Enum.EasingDirection[p6 or "Out"], 0, p7 or false);
        local u8 = p4 or 1;
        local u9 = p2 or 1;

        for _, descendant in pairs(p1:GetDescendants()) do
            if (descendant:IsA("Part") or (descendant:IsA("MeshPart") or (descendant:IsA("Decal") or descendant:IsA("UnionOperation")))) and descendant.Transparency ~= 1 then
                local Transparency = descendant.Transparency;
                coroutine.wrap(function() -- Line: 20
                    -- upvalues: TweenService (ref), descendant (copy), TweenInfo_new_ret (copy), u8 (copy), u9 (copy), Transparency (copy)
                    TweenService:Create(descendant, TweenInfo_new_ret, {
                        Transparency = u8
                    }):Play();
                    task.wait(u9);

                    if descendant then
                        TweenService:Create(descendant, TweenInfo_new_ret, {
                            Transparency = Transparency
                        }):Play();
                    end;
                end)();
            end;
        end;
    end
};