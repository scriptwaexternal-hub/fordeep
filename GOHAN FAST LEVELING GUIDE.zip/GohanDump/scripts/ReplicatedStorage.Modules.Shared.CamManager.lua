-- Decompiled with Potassium's decompiler.

local Players = game:GetService("Players");
local Debris = game:GetService("Debris");
local ReplicatedStorage = game:GetService("ReplicatedStorage");
local RunService = game:GetService("RunService");
local _ = ReplicatedStorage.Assets;
local Modules = ReplicatedStorage:WaitForChild("Modules");
ReplicatedStorage:WaitForChild("Remotes");
local _ = Modules.Metadata;
local Shared = Modules.Shared;
local Utility = Modules.Utility;
require(Shared.SoundManager);
local GlobalFunctions = require(Modules.GlobalFunctions);
local CinemaManager = require(Shared.CinemaManager);
require(Utility.Create);
local workspace_CurrentCamera = workspace.CurrentCamera;
local Visuals = workspace.World.Visuals;
local LocalPlayer = Players.LocalPlayer;
local v1 = {};
v1.__index = v1;

function v1.ZoomOut(p2) -- Line: 34
    -- upvalues: Visuals (copy), Debris (copy), workspace_CurrentCamera (copy), CinemaManager (copy), LocalPlayer (copy), RunService (copy)
    local v3 = p2.Duration or 5;
    local Point = p2.Point;
    local Target = p2.Target;
    local u4 = p2.Speed or 1;
    local v5 = p2.StartDelay or 0;
    local u6 = p2.EndDelay or 2;
    local is_Cinematic = p2.is_Cinematic;
    local u7 = true;
    local u8 = false;
    local Part = Instance.new("Part");
    Part.Parent = Visuals;
    Part.Size = Vector3.new(2, 2, 2);
    Part.Anchored = true;
    Part.CFrame = Point;
    Part.CFrame = CFrame.lookAt(Part.Position, Target);
    Part.Transparency = 1;
    Debris:AddItem(Part, 100);
    workspace_CurrentCamera.CameraType = Enum.CameraType.Scriptable;
    workspace_CurrentCamera.CFrame = Part.CFrame;

    if is_Cinematic then
        CinemaManager.FadeIn(LocalPlayer);
    end;

    task.wait(v5);
    local u9 = nil;
    u9 = RunService.RenderStepped:Connect(function() -- Line: 65
        -- upvalues: u7 (ref), workspace_CurrentCamera (ref), Part (copy), u4 (copy), u8 (ref), u9 (ref)
        if u7 ~= true then
            if u8 == true then
                u9:Disconnect();
            end;

            return;
        end;

        workspace_CurrentCamera.CFrame = Part.CFrame;
        local v10 = Part;
        v10.CFrame = v10.CFrame * CFrame.new(0, 0, u4);
    end);
    task.delay(v3, function() -- Line: 75
        -- upvalues: u7 (ref), u6 (copy), u8 (ref), is_Cinematic (copy), CinemaManager (ref), LocalPlayer (ref), workspace_CurrentCamera (ref), u9 (ref)
        u7 = false;
        task.wait(u6);
        u8 = true;

        if is_Cinematic then
            CinemaManager.FadeOut(LocalPlayer);
        end;

        workspace_CurrentCamera.CameraType = Enum.CameraType.Custom;
        u9:Disconnect();
    end);
end;

function v1.Tween(p11) -- Line: 90
    -- upvalues: Visuals (copy), Debris (copy), workspace_CurrentCamera (copy), CinemaManager (copy), LocalPlayer (copy), GlobalFunctions (copy), RunService (copy)
    local v12 = p11.Duration or 5;
    local Startpoint = p11.Startpoint;
    local Target = p11.Target;
    local Endpoint = p11.Endpoint;
    local EndTarget = p11.EndTarget;
    local _ = p11.Speed or 1;
    local v13 = p11.StartDelay or 0;
    local u14 = p11.EndDelay or 2;
    local is_Cinematic = p11.is_Cinematic;
    local u15 = true;
    local u16 = false;
    local Part = Instance.new("Part");
    Part.Parent = Visuals;
    Part.Size = Vector3.new(2, 2, 2);
    Part.Anchored = true;
    Part.CFrame = Startpoint;
    Part.CFrame = CFrame.lookAt(Part.Position, Target);
    Part.Transparency = 1;
    Debris:AddItem(Part, 100);
    workspace_CurrentCamera.CameraType = Enum.CameraType.Scriptable;
    workspace_CurrentCamera.CFrame = Part.CFrame;

    if is_Cinematic then
        CinemaManager.FadeIn(LocalPlayer);
    end;

    task.wait(v13);
    GlobalFunctions.Tween({
        Instance = Part,
        Duration = v12
    }, {
        CFrame = Endpoint
    });
    local u17 = nil;
    u17 = RunService.RenderStepped:Connect(function() -- Line: 141
        -- upvalues: u15 (ref), workspace_CurrentCamera (ref), Part (copy), EndTarget (copy), u16 (ref), u17 (ref)
        if u15 ~= true then
            if u16 == true then
                u17:Disconnect();
            end;

            return;
        end;

        workspace_CurrentCamera.CFrame = Part.CFrame;
        workspace_CurrentCamera.CFrame = CFrame.lookAt(Part.Position, EndTarget);
    end);
    task.delay(v12, function() -- Line: 152
        -- upvalues: u15 (ref), u14 (copy), u16 (ref), is_Cinematic (copy), CinemaManager (ref), LocalPlayer (ref), workspace_CurrentCamera (ref), u17 (ref)
        u15 = false;
        task.wait(u14);
        u16 = true;

        if is_Cinematic then
            CinemaManager.FadeOut(LocalPlayer);
        end;

        workspace_CurrentCamera.CameraType = Enum.CameraType.Custom;
        u17:Disconnect();
    end);
end;

function v1.Clash(p18) -- Line: 167
    -- upvalues: Visuals (copy), Debris (copy), workspace_CurrentCamera (copy), RunService (copy)
    local u19 = p18.Duration or 5;
    local _ = p18.Distance_Away or 50;
    local Location = p18.Location;
    local Camera_Passes = p18.Camera_Passes;
    local Part = Instance.new("Part");
    Part.Parent = Visuals;
    Part.Size = Vector3.new(2, 2, 2);
    Part.Anchored = true;
    Part.CFrame = CFrame.lookAt(Part.Position, Location.Position);
    Part.Transparency = 1;
    Debris:AddItem(Part, u19 + 5);
    workspace_CurrentCamera.CameraType = Enum.CameraType.Scriptable;
    local u20 = RunService.RenderStepped:Connect(function() -- Line: 190
        -- upvalues: workspace_CurrentCamera (ref), Part (copy), Location (copy)
        workspace_CurrentCamera.CFrame = Part.CFrame;
        workspace_CurrentCamera.CFrame = CFrame.lookAt(workspace_CurrentCamera.CFrame.Position, Location.Position);
    end);
    task.spawn(function() -- Line: 196
        -- upvalues: Camera_Passes (copy), Part (copy), Location (copy), u19 (copy)
        local function randomExcludingRanges(p21, p22, p23, p24) -- Line: 197
            if math.random(1, 2) == 1 then
                return math.random(p21, p22);
            end;

            return math.random(p23, p24);
        end;

        for i = 1, Camera_Passes do
            local v25;

            if math.random(1, 2) == 1 then
                v25 = math.random(-50, -15);
            else
                v25 = math.random(15, 50);
            end;

            local v26;

            if math.random(1, 2) == 1 then
                v26 = math.random(-50, -15);
            else
                v26 = math.random(15, 50);
            end;

            local v27;

            if math.random(1, 2) == 1 then
                v27 = math.random(-50, -15);
            else
                v27 = math.random(15, 50);
            end;

            Part.CFrame = Location * CFrame.new(v25, v26, v27);
            task.wait(u19 / Camera_Passes);
            local _ = i;
        end;
    end);
    task.delay(u19, function() -- Line: 214
        -- upvalues: Part (copy), Location (copy), workspace_CurrentCamera (ref), u20 (ref)
        Part.CFrame = Location * CFrame.Angles(0, 0, 0) * CFrame.new(50, 0, -10);
        workspace_CurrentCamera.CameraType = Enum.CameraType.Custom;
        task.delay(1, function() -- Line: 217
            -- upvalues: u20 (ref)
            u20:Disconnect();
        end);
    end);
end;

function v1.Reset(p28) -- Line: 223
end;

return v1;