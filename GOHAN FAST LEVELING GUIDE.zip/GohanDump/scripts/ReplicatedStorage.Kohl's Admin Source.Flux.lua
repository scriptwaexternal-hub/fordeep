-- Decompiled with Potassium's decompiler.

local script_Color = require(script.Color);
local script_Interpolate = require(script.Interpolate);
local script_State = require(script.State);
local script_Spring = require(script.Spring);
local script_Tween = require(script.Tween);
local script_Type = require(script.Type);
local u2 = {
    Clean = table.freeze({
        type = "Symbol"
    }),
    Attribute = table.freeze({
        type = "Symbol"
    }),
    Event = table.freeze({
        type = "Symbol"
    }),
    Color = script_Color,
    Interpolate = script_Interpolate,
    State = script_State,
    Type = script_Type,
    isState = script_State.isState,
    raw = script_State.raw,
    rawVariadic = script_State.rawVariadic,
    compute = script_State.compute,
    state = script_State.new,
    spring = script_Spring.new,
    tween = script_Tween.new,

    deferUpdates = function(p1: boolean?) -- Line: 36, Name: deferUpdates
        -- upvalues: script_State (copy)
        script_State.deferUpdates = p1;
    end
};
u2.__index = u2;

function u2.cleanup(p3) -- Line: 42
    -- upvalues: u2 (copy)
    local v4 = typeof(p3);

    if v4 == "Instance" then
        pcall(game.Destroy, p3);

        return;
    end;

    if v4 == "RBXScriptConnection" then
        if p3.Connected then
            p3:Disconnect();
        end;
    else
        if v4 == "function" then
            p3();

            return;
        end;

        if v4 == "thread" then
            pcall(task.cancel, p3);

            return;
        end;

        if v4 == "table" then
            if typeof(p3.destroy) == "function" then
                p3:destroy();

                return;
            end;

            if typeof(p3.Destroy) == "function" then
                p3:Destroy();

                return;
            end;

            if p3[1] ~= nil then
                for _, v in p3 do
                    u2.cleanup(v);
                end;

                return;
            end;

            if typeof(p3[u2.Clean]) == "table" then
                for _, v in p3[u2.Clean] do
                    u2.cleanup(v);
                end;
            end;
        end;
    end;
end;

local table_freeze_ret = table.freeze({});

local function isAction(p5) -- Line: 77
    -- upvalues: table_freeze_ret (copy)
    return getmetatable(p5) == table_freeze_ret;
end;

function u2.action(p6: function) -- Line: 82
    -- upvalues: table_freeze_ret (copy)
    local v7 = setmetatable({
        callback = p6
    }, table_freeze_ret);

    return table.freeze(v7);
end;

local u8 = {
    u2.Attribute,
    u2.Clean,
    u2.Event,
    "Parent"
};

local function processProperties(u9: userdata, p10: any) -- Line: 89
    -- upvalues: u8 (copy), table_freeze_ret (copy), u2 (copy), script_State (copy)
    local v11 = {
        Parent = nil,
        actions = {},
        signals = {}
    };

    for _, v in u8 do
        v11[v] = p10[v];
        p10[v] = nil;
    end;

    for i, v in p10 do
        if type(i) == "number" and i == math.floor(i) then
            if typeof(v) == "Instance" then
                if v:IsA("GuiObject") and v.LayoutOrder == 0 then
                    v.LayoutOrder = i;
                end;

                v.Parent = u9;
            elseif type(v) == "table" and getmetatable(v) == table_freeze_ret then
                table.insert(v11.actions, v);
            else
                local v12;

                if type(v) == "function" then
                    v12 = u2.compute(v);
                else
                    v12 = v;
                end;

                if u2.isState(v12) then
                    if not v12._boundChildren then
                        v12._boundChildren = {};
                    end;

                    v12._boundChildrenLayoutOrder = i;
                    v12._boundParent = u9;
                    v12:_updateBoundChildren();
                end;
            end;
        else
            local v13;

            if type(v) == "function" then
                if typeof(u9[i]) ~= "RBXScriptSignal" then
                    v13 = u2.compute(v);
                    script_State._bindProperty(v13, u9, i);
                    u9[i] = u2.raw(v13);
                end;

                v11.signals[u9[i]] = v;
            else
                v13 = v;
                script_State._bindProperty(v13, u9, i);
                u9[i] = u2.raw(v13);
            end;
        end;
    end;

    if v11[u2.Attribute] then
        for i, v in v11[u2.Attribute] do
            script_State._bindProperty(v, u9, "Attribute." .. i);
            u9:SetAttribute(i, u2.raw(v));
        end;
    end;

    if v11[u2.Event] then
        local v14 = v11[u2.Event];
        local v15 = v14[u2.Attribute];
        v14[u2.Attribute] = nil;

        for i, v in v14 do
            if typeof(u9[i]) == "RBXScriptSignal" then
                v11.signals[u9[i]] = v;
            else
                u9:GetPropertyChangedSignal(i):Connect(function() -- Line: 154
                    -- upvalues: v (copy), u9 (copy), i (copy)
                    v(u9[i]);
                end);
            end;
        end;

        if v15 then
            for i, v in v15 do
                u9:GetAttributeChangedSignal(i):Connect(function() -- Line: 162
                    -- upvalues: v (copy), u9 (copy), i (copy)
                    v(u9:GetAttribute(i));
                end);
            end;
        end;
    end;

    for i, v in v11.signals do
        i:Connect(v);
    end;

    local u16 = v11[u2.Clean] or {};

    for _, v in v11.actions do
        table.insert(u16, task.spawn(v.callback, u9));
    end;

    if u16 and (next(u16) and not u16[u2.Clean]) then
        u9.Destroying:Once(function() -- Line: 181
            -- upvalues: u2 (ref), u16 (copy)
            u2.cleanup(u16);
        end);
    end;

    local Parent = v11.Parent;

    if Parent then
        if type(Parent) == "function" then
            Parent = u2.compute(Parent);
        end;

        script_State._bindProperty(Parent, u9, "Parent");
        u9.Parent = u2.raw(Parent);
    end;
end;

function u2.edit(p17, p18) -- Line: 198
    -- upvalues: processProperties (copy)
    processProperties(p17, p18);

    return p17;
end;

local u19 = {};
setmetatable(u19, {
    __index = function(p20: any, u21: string) -- Line: 205, Name: __index
        -- upvalues: u2 (copy)
        local function new(p22) -- Line: 206
            -- upvalues: u2 (ref), u21 (copy)
            return u2.edit(Instance.new(u21), p22);
        end;

        p20[u21] = new;

        return new;
    end
});

function u2.new(u23) -- Line: 216
    -- upvalues: u2 (copy), u19 (copy)
    return typeof(u23) == "Instance" and function(p24) -- Line: 218
        -- upvalues: u23 (copy), u2 (ref)
        local v25 = u23:Clone();

        if not v25 then
            error("Attempt to clone non-archivable instance");
        end;

        return u2.edit(v25, p24);
    end or u19[u23];
end;

return u2;