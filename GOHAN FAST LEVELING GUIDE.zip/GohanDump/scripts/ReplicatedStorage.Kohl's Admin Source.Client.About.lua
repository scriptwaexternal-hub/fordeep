-- Decompiled with Potassium's decompiler.

local UI = require(script.Parent:WaitForChild("UI"));
local Credits = require(script.Parent:WaitForChild("Credits"));
local UserFrame = require(script.Parent:WaitForChild("UserFrame"));
local v1 = {};
v1.__index = v1;

function v1.new(u2) -- Line: 8
    -- upvalues: UI (copy), Credits (copy), UserFrame (copy)
    local u3 = UI.new("Scroller")({
        Name = "About"
    });
    local u4 = u2.DEBUG and u2.IsStudio;
    u2.client.AllowThirdPartySales = not u4;
    u2.client.lastAttemptedPurchase = false;
    local v5 = UI.new("Link")({
        LayoutOrder = 10,
        Text = "create.roblox.com/store/asset/" .. 172732271
    });
    local u6 = nil;
    u6 = UI.new("Dialog")({
        Parent = UI.LayerTop,
        Title = "Get Kohl\'s Admin",
        Text = "Copy the link below to continue.",
        Visible = false,
        Draggable = true,
        ExitButton = true,
        BackgroundTransparency = 0,
        AnchorPoint = Vector2.new(0.5, 0.5),
        Position = UDim2.new(0.5, 0, 0.5, 0),
        Size = UDim2.new(0, 320, 0, 0),
        Modal = true,
        ZIndex = 1000,

        Close = function() -- Line: 39, Name: Close
            -- upvalues: u2 (copy), u6 (ref)
            u2.client.lastAttemptedPurchase = false;
            u6.Visible(false);
        end,

        v5
    });
    u2.client.purchaseKADialog = u6;
    local u7 = nil;
    u7 = u2.Service.Log.MessageOut:Connect(function(p8, p9) -- Line: 50
        -- upvalues: u7 (ref), u2 (copy), u6 (ref)
        if p9 == Enum.MessageType.MessageWarning and string.find(p8, "AllowThirdPartySales") then
            u7:Disconnect();
            u2.client.AllowThirdPartySales = false;

            if u2.client.lastAttemptedPurchase then
                u6.Visible(true);
            end;
        end;
    end);
    task.defer(function() -- Line: 60
        -- upvalues: UI (ref), u2 (copy), u6 (ref), u4 (copy), u3 (copy), Credits (ref), UserFrame (ref)
        local u10 = UI.new("TextLabel")({
            AutoLocalize = false,
            AutomaticSize = Enum.AutomaticSize.Y,
            BackgroundTransparency = 1,
            FontFace = UI.Theme.Font,
            TextSize = UI.Theme.FontSize,
            TextColor3 = UI.Theme.PrimaryText,
            TextStrokeColor3 = UI.Theme.Primary,
            TextStrokeTransparency = UI.Theme.TextStrokeTransparency,
            TextWrapped = true,
            Size = UDim2.new(1, 0, 0, 0),
            Text = "<font transparency=\'0.5\'><b>Stop playing. Take command.</b> Get the same powerful tools used here for your own games. Total control, advanced security, and professional moderation are yours for <b>free</b>.</font>",
            RichText = true,
            UI.new("UISizeConstraint")({
                MaxSize = Vector2.new(420, (1 / 0))
            })
        });
        local u11 = UI.new("Button")({
            Name = "adminModelButton",
            AutomaticSize = Enum.AutomaticSize.X,
            Icon = "rbxasset://textures/ui/common/robux.png",
            IconProperties = {
                ImageColor3 = UI.Theme.PrimaryText
            },
            IconRightAlign = true,
            Label = "<b>Get Kohl\'s Admin</b>",
            TextXAlignment = Enum.TextXAlignment.Left,
            UI.new("TextLabel")({
                LayoutOrder = 2,
                Name = "Price",
                AutoLocalize = false,
                BackgroundTransparency = 1,
                TextWrapped = true,
                Text = "<b>FREE</b>",
                RichText = true,
                AutomaticSize = Enum.AutomaticSize.XY,
                FontFace = UI.Theme.FontMono,
                TextSize = UI.Theme.FontSizeLarge,
                TextColor3 = UI.Theme.PrimaryText,
                TextStrokeColor3 = UI.Theme.Primary,
                TextStrokeTransparency = UI.Theme.TextStrokeTransparency,

                Size = function() -- Line: 101, Name: Size
                    -- upvalues: UI (ref)
                    return UDim2.new(0, UI.Theme.FontSizeLarge(), 0, 32);
                end
            }),

            Activated = function() -- Line: 108, Name: Activated
                -- upvalues: u2 (ref), u6 (ref)
                u2.client.lastAttemptedPurchase = 172732271;

                if not u2.client.AllowThirdPartySales then
                    u6.Visible(true);

                    return;
                end;

                u6.Visible(false);
                u2.Service.Marketplace:PromptPurchase(u2.LocalPlayer, 172732271);
            end
        });
        UI.new("Tooltip")({
            Text = "Used by <b>32M+</b> developers since 2011, Kohl\'s Admin is the longest-running and most reliable admin solution on Roblox.",
            Parent = u11,
            Hovering = u11._hovering
        });
        local u12 = UI.new("Frame")({
            AutomaticSize = Enum.AutomaticSize.XY,
            BackgroundTransparency = 1,
            UI.new("UIListLayout")({
                FillDirection = Enum.FillDirection.Horizontal,
                Padding = UI.Theme.PaddingWithStroke,
                SortOrder = Enum.SortOrder.LayoutOrder,
                VerticalAlignment = Enum.VerticalAlignment.Center
            }),
            UI.new("Frame")({
                BackgroundTransparency = 1,
                AnchorPoint = Vector2.new(0, 0.5),
                Position = UDim2.new(0, 0, 0.5, 0),
                Size = UDim2.new(0, 28, 0, 28),
                UI.new("ImageLabel")({
                    BackgroundTransparency = 1,
                    Image = "rbxasset://textures/ui/InspectMenu/ico_favorite@2x.png",
                    ImageTransparency = 0.875,
                    Size = UDim2.new(0, 28, 0, 28),
                    ImageColor3 = Color3.new(0, 0, 0)
                }),
                UI.new("ImageButton")({
                    BackgroundTransparency = 1,
                    Position = UDim2.new(0, 2, 0, 2),
                    Size = UDim2.new(0, 24, 0, 24),
                    Image = "rbxasset://textures/ui/InspectMenu/ico_favorite@2x.png",
                    ImageColor3 = Color3.new(1, 0.8, 0),

                    Activated = function() -- Line: 153, Name: Activated
                        -- upvalues: u2 (ref)
                        pcall(function() -- Line: 154
                            -- upvalues: u2 (ref)
                            u2.Service.AvatarEditor:PromptSetFavorite(172732271, 1, true);
                        end);
                    end,

                    UI.new("Tooltip")({
                        Text = "Add to Favorites"
                    })
                })
            }),
            u11
        });
        task.defer(function() -- Line: 167
            -- upvalues: u2 (ref), u4 (ref), u11 (copy), UI (ref), u12 (copy), u10 (copy)
            local v13, v14 = u2.Util.Retry(function() -- Line: 168
                -- upvalues: u2 (ref)
                return u2.Service.Marketplace:PlayerOwnsAssetAsync(u2.LocalPlayer, 172732271);
            end);

            if v13 and (v14 and not u4) then
                u11._instance.Visible = false;
                UI.new("Link")({
                    LayoutOrder = 3,
                    Name = "CatalogLink",
                    Parent = u12,
                    Text = "create.roblox.com/store/asset/" .. 172732271
                });
                u10.Text = "<b>Love the Power?</b>\nDrop a Like 👍 and Favorite ⭐ to support us!";
            end;
        end);
        local u15 = UI.new("Link")({
            Name = "CatalogLink",
            Text = "roblox.com/communities/3403354",
            Visible = false
        });
        local u16 = nil;
        local u17 = nil;
        u16 = UI.new("Button")({
            Label = "Join Community",
            BackgroundTransparency = 0.25,
            HoverTransparency = 0,
            BackgroundColor3 = Color3.fromRGB(51, 95, 255),
            AutomaticSize = Enum.AutomaticSize.X,

            Activated = function() -- Line: 201, Name: Activated
                -- upvalues: u2 (ref), u16 (ref), u15 (copy), u17 (ref)
                local success, result = pcall(u2.Service.Group.PromptJoinAsync, u2.Service.Group, 3403354);

                if not success then
                    u16._instance.Visible = false;
                    u15._instance.Visible = true;
                    u15:Select();

                    return;
                end;

                if result == Enum.GroupMembershipStatus.None then
                    return;
                end;

                u16._instance.Visible = false;
                u15._instance.Visible = true;
                u17.TextLabel.Text = "<b>Need help or have a suggestion?</b>";
            end
        });
        u17 = UI.new("Frame")({
            BackgroundTransparency = 1,
            AutomaticSize = Enum.AutomaticSize.XY,
            Visible = true,
            UI.new("UIListLayout")({
                FillDirection = Enum.FillDirection.Vertical,
                HorizontalAlignment = Enum.HorizontalAlignment.Center,
                Padding = UI.Theme.Padding,
                SortOrder = Enum.SortOrder.LayoutOrder
            }),
            UI.new("TextLabel")({
                AutoLocalize = false,
                AutomaticSize = Enum.AutomaticSize.XY,
                BackgroundTransparency = 1,
                FontFace = UI.Theme.Font,
                TextSize = UI.Theme.FontSize,
                TextColor3 = UI.Theme.PrimaryText,
                TextStrokeColor3 = UI.Theme.Primary,
                TextStrokeTransparency = UI.Theme.TextStrokeTransparency,
                TextWrapped = true,
                Size = UDim2.new(0, 0, 0, 0),
                Text = "<b>Join our community for help and cool perks!</b>",
                RichText = true,
                UI.new("Tooltip")({
                    Text = "Find games using Kohl\'s Admin!\n\n<font transparency=\'0.5\'>Check the Kohl\'s Admin <b>Settings</b> script in Studio to add your game to the charts.</font>\n\n<b>Game Creators</b> get up to <font color=\'#0f0\'><b>40%</b></font> when <font transparency=\'0.5\'><b>Third Party Purchases</b></font> are enabled in their Roblox Game Settings!"
                })
            }),
            u16,
            u15
        });
        task.spawn(function() -- Line: 252
            -- upvalues: u2 (ref), u16 (ref), u15 (copy), u17 (ref)
            local v18, v19 = u2.Util.Retry(u2.LocalPlayer.IsInGroup, (1 / 0), nil, u2.LocalPlayer, 3403354);

            if v18 and v19 then
                u16._instance.Visible = false;
                u15._instance.Visible = true;
                u17.TextLabel.Text = "<b>Need help or have a suggestion?</b>";
            end;
        end);
        UI.edit(u3._instance, {
            UI.new("TextLabel")({
                AutoLocalize = false,
                BackgroundTransparency = 1,
                TextWrapped = true,
                Text = "<b>Kohl\'s Admin</b>\n<font transparency=\'0.5\'><i>Embrace creativity, not chaos.</i></font>",
                RichText = true,
                AutomaticSize = Enum.AutomaticSize.Y,
                FontFace = UI.Theme.Font,
                TextSize = UI.Theme.FontSize,
                TextColor3 = UI.Theme.PrimaryText,
                TextStrokeColor3 = UI.Theme.Primary,
                TextStrokeTransparency = UI.Theme.TextStrokeTransparency,
                Size = UDim2.new(1, 0, 0, 0)
            }),
            u10,
            u12,
            u17,
            UI.new("Frame")({
                AutomaticSize = Enum.AutomaticSize.XY,
                BackgroundTransparency = 1,
                UI.new("UIListLayout")({
                    FillDirection = Enum.FillDirection.Vertical,
                    HorizontalAlignment = Enum.HorizontalAlignment.Center,
                    Padding = UI.Theme.Padding,
                    SortOrder = Enum.SortOrder.LayoutOrder
                }),
                UI.new("TextLabel")({
                    AutoLocalize = false,
                    AutomaticSize = Enum.AutomaticSize.XY,
                    BackgroundTransparency = 1,
                    FontFace = UI.Theme.Font,
                    TextSize = UI.Theme.FontSize,
                    TextColor3 = UI.Theme.PrimaryText,
                    TextStrokeColor3 = UI.Theme.Primary,
                    TextStrokeTransparency = UI.Theme.TextStrokeTransparency,
                    TextWrapped = true,
                    Size = UDim2.new(0, 0, 0, 0),
                    Text = "<b>Looking for more games with Kohl\'s Admin?</b>",
                    RichText = true,
                    UI.new("Tooltip")({
                        Text = "Find games using Kohl\'s Admin!\n\n<font transparency=\'0.5\'>Check the Kohl\'s Admin <b>Settings</b> script in Studio to add your game to the charts.</font>\n\n<b>Game Creators</b> get up to <font color=\'#0f0\'><b>40%</b></font> when <font transparency=\'0.5\'><b>Third Party Purchases</b></font> are enabled in their Roblox Game Settings!"
                    })
                }),
                UI.new("Frame")({
                    AutomaticSize = Enum.AutomaticSize.XY,
                    BackgroundTransparency = 1,
                    UI.new("UIListLayout")({
                        FillDirection = Enum.FillDirection.Horizontal,
                        Padding = UI.Theme.PaddingWithStroke,
                        SortOrder = Enum.SortOrder.LayoutOrder,
                        VerticalAlignment = Enum.VerticalAlignment.Center
                    }),
                    UI.new("ImageButton")({
                        BackgroundTransparency = 1,
                        Size = UDim2.new(0, 24, 0, 24),
                        Image = "rbxasset://textures/ui/InspectMenu/ico_favorite@2x.png",
                        ImageColor3 = Color3.new(1, 0.8, 0),

                        Activated = function() -- Line: 328, Name: Activated
                            -- upvalues: u2 (ref)
                            pcall(function() -- Line: 329
                                -- upvalues: u2 (ref)
                                u2.Service.AvatarEditor:PromptSetFavorite(17873329124, 1, true);
                            end);
                        end,

                        UI.new("Tooltip")({
                            Text = "Add to Favorites"
                        })
                    }),
                    UI.new("Link")({
                        Name = "CatalogLink",
                        Text = "roblox.com/games/17873329124",
                        Tooltip = "<b>Copy:</b> Ctrl + C\n\nFind games using Kohl\'s Admin!\n\n<font transparency=\'0.5\'>Check the Kohl\'s Admin <b>Settings</b> script in Studio to add your game to the charts.</font>\n\n<b>Game Creators</b> get up to <font color=\'#0f0\'><b>40%</b></font> when <font transparency=\'0.5\'><b>Third Party Purchases</b></font> are enabled in their Roblox Game Settings!"
                    })
                })
            })
        });
        UI.edit(u3._instance.UIListLayout, {
            Padding = UI.Theme.PaddingDouble,
            HorizontalAlignment = Enum.HorizontalAlignment.Center
        });
        task.defer(function() -- Line: 351
            -- upvalues: UI (ref), u3 (ref), Credits (ref), UserFrame (ref), u2 (ref)
            local v20 = UI.new("Frame")({
                Name = "Credits",
                Parent = u3,
                LayoutOrder = 1000000,
                AutomaticSize = Enum.AutomaticSize.Y,
                Size = UDim2.new(1, 0, 0, 0),
                BackgroundTransparency = 1,
                UI.new("UIListLayout")({
                    SortOrder = Enum.SortOrder.LayoutOrder,
                    Padding = UI.Theme.PaddingDouble,
                    HorizontalAlignment = Enum.HorizontalAlignment.Center
                })
            });
            local v21 = 1;

            for _, v in Credits do
                UI.new("TextLabel")({
                    AutoLocalize = false,
                    BackgroundTransparency = 1,
                    TextTransparency = 0.5,
                    Parent = v20,
                    LayoutOrder = v21,
                    Name = v.Title,
                    FontFace = UI.Theme.FontHeavy,
                    TextTruncate = Enum.TextTruncate.SplitWord,
                    TextSize = UI.Theme.FontSizeLargest,
                    TextColor3 = UI.Theme.PrimaryText,
                    TextStrokeColor3 = UI.Theme.Primary,
                    TextStrokeTransparency = UI.Theme.TextStrokeTransparency,
                    Size = UDim2.new(1, 0, 0, 24),
                    Text = string.upper(v.Title)
                });
                local v22 = v21 + 1;
                local u23 = UI.new("Frame")({
                    Parent = v20,
                    LayoutOrder = v22,
                    BackgroundTransparency = 1,
                    AutomaticSize = Enum.AutomaticSize.Y,
                    Size = UDim2.fromScale(1, 0),
                    UI.new("UIListLayout")({
                        Wraps = true,
                        SortOrder = Enum.SortOrder.LayoutOrder,
                        FillDirection = Enum.FillDirection.Horizontal,
                        HorizontalFlex = Enum.UIFlexAlignment.SpaceEvenly,
                        HorizontalAlignment = Enum.HorizontalAlignment.Center,
                        Padding = UI.Theme.PaddingDouble
                    })
                });
                v21 = v22 + 1;
                task.defer(function() -- Line: 403
                    -- upvalues: v (copy), UserFrame (ref), u2 (ref), u23 (copy), UI (ref)
                    if string.lower(v.Title) == "special thanks" then
                        local v24 = UserFrame(u2.LocalPlayer.UserId, "You", nil, false);
                        v24.LayoutOrder = 0;
                        v24.Parent = u23;
                        UI.new("Tooltip")({
                            Text = "Thanks for using the admin!",
                            Parent = v24
                        });
                    end;

                    for i, v2 in v.Users do
                        local v25 = type(v2);

                        if v25 == "number" then
                            local v26 = UserFrame(v2, nil, nil, false);
                            v26.LayoutOrder = i;
                            v26.Parent = u23;
                        elseif v25 == "table" then
                            local v27 = UserFrame(v2.Id, nil, nil, false);
                            v27.LayoutOrder = i;
                            v27.Parent = u23;

                            if v2.Tooltip then
                                UI.new("Tooltip")({
                                    Parent = v27,
                                    Text = v2.Tooltip
                                });
                            end;
                        end;
                    end;
                end);
            end;
        end);
    end);

    return u3;
end;

return v1;