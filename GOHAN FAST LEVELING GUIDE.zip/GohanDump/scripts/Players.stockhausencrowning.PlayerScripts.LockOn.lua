-- Decompiled with Potassium's decompiler.

local Players = game:GetService("Players");
local UserInputService = game:GetService("UserInputService");
local RunService = game:GetService("RunService");
local ReplicatedStorage = game:GetService("ReplicatedStorage");
game:GetService("TweenService");
local LocalPlayer = Players.LocalPlayer;
local workspace_CurrentCamera = workspace.CurrentCamera;
local Modules = ReplicatedStorage:WaitForChild("Modules");
local Platform = require(Modules:WaitForChild("Shared"):WaitForChild("Platform"));
local Mouse = require(Modules.Shared:WaitForChild("Mouse"));
require(Modules:WaitForChild("Metadata"):WaitForChild("ControlData"):WaitForChild("ControlData"));
local TouchActionRemote = ReplicatedStorage:WaitForChild("Remotes"):WaitForChild("TouchActionRemote");
local ServerRemote = ReplicatedStorage.Remotes:WaitForChild("ServerRemote");
local ObjectValue = Instance.new("ObjectValue");
ObjectValue.Name = "LockOnTarget";
ObjectValue.Parent = LocalPlayer;

local function mirror(p1) -- Line: 67
    -- upvalues: ObjectValue (copy), ServerRemote (copy)
    ObjectValue.Value = p1;

    if p1 then
        ServerRemote:FireServer(nil, {
            Module = "LockOnHandler",
            Action = "Set",
            Target = p1
        });

        return;
    end;

    ServerRemote:FireServer(nil, {
        Module = "LockOnHandler",
        Action = "Clear"
    });
end;

local u2 = { "Flying", "Climbing", "Dashing", "ForwardDashing", "Clashing", "Knocked", "Stunned", "KO", "GettingGripped", "GettingCarried", "WallSlammed", "Stuck", "Transforming", "BerserkApe" };
local Live = workspace:WaitForChild("World"):WaitForChild("Live");

local function liveModels() -- Line: 108
    -- upvalues: Live (copy)
    local v3 = {};

    for _, descendant in ipairs(Live:GetDescendants()) do
        if descendant:IsA("Model") and descendant:FindFirstChildOfClass("Humanoid") then
            local Parent = descendant.Parent;

            if not Parent or Parent.Name ~= "Attackable Items" then
                v3[#v3 + 1] = descendant;
            end;
        end;
    end;

    return v3;
end;

local u4 = nil;
local u5 = nil;
local u6 = nil;
local u7 = {};
local u8 = 14;

local function myParts() -- Line: 132
    -- upvalues: LocalPlayer (copy)
    local Character = LocalPlayer.Character;
    local v9;

    if Character then
        v9 = Character:FindFirstChildOfClass("Humanoid");
    else
        v9 = Character;
    end;

    local v10;

    if Character then
        v10 = Character:FindFirstChild("HumanoidRootPart");
    else
        v10 = Character;
    end;

    if v9 and (v10 and v9.Health > 0) then
        return Character, v9, v10;
    end;

    return nil;
end;

local function rotationBlocked(p11, p12) -- Line: 140
    -- upvalues: u2 (copy)
    if p12.Sit then
        return true;
    end;

    for _, v in ipairs(u2) do
        if p11:GetAttribute("State_" .. v) ~= nil then
            return true;
        end;
    end;

    return false;
end;

local function isTargetable(p13, p14) -- Line: 148
    -- upvalues: Live (copy)
    if not (p13 and (p13:IsA("Model") and p13 ~= p14)) then
        return false;
    end;

    if not p13:IsDescendantOf(Live) then
        return false;
    end;

    if p13.Parent and p13.Parent.Name == "Attackable Items" then
        return false;
    end;

    if p13:FindFirstChild("No Body") then
        return false;
    end;

    local v15 = p13:FindFirstChildOfClass("Humanoid");
    local HumanoidRootPart = p13:FindFirstChild("HumanoidRootPart");
    local v16;

    if v15 == nil or HumanoidRootPart == nil then
        v16 = false;
    else
        v16 = v15.Health > 0;
    end;

    return v16;
end;

local function characterOf(p17, p18) -- Line: 158
    -- upvalues: isTargetable (copy)
    while p17 and p17 ~= workspace do
        if p17:IsA("Model") and p17:FindFirstChildOfClass("Humanoid") then
            return isTargetable(p17, p18) and p17 and p17 or nil;
        end;

        p17 = p17.Parent;
    end;

    return nil;
end;

local function candidates(p19, p20) -- Line: 169
    -- upvalues: liveModels (copy), isTargetable (copy)
    local v21 = {};

    for _, v in ipairs((liveModels())) do
        if isTargetable(v, p19) then
            local Magnitude = (v.HumanoidRootPart.Position - p20.Position).Magnitude;

            if Magnitude <= 150 then
                v21[#v21 + 1] = {
                    model = v,
                    dist = Magnitude
                };
            end;
        end;
    end;

    return v21;
end;

local function underCursor(p22) -- Line: 181
    -- upvalues: Platform (copy), UserInputService (copy), workspace_CurrentCamera (copy), characterOf (copy), liveModels (copy), isTargetable (copy)
    if Platform.IsTouch() or Platform.PreferGamepadGlyphs() then
        return nil;
    end;

    local MouseLocation = UserInputService:GetMouseLocation();
    local v23 = workspace_CurrentCamera:ScreenPointToRay(MouseLocation.X, MouseLocation.Y);
    local RaycastParams_new_ret = RaycastParams.new();
    RaycastParams_new_ret.FilterType = Enum.RaycastFilterType.Exclude;
    RaycastParams_new_ret.FilterDescendantsInstances = { p22, workspace.World:FindFirstChild("Visuals") };
    local v24 = workspace:Raycast(v23.Origin, v23.Direction * 600, RaycastParams_new_ret);

    if v24 then
        v24 = characterOf(v24.Instance, p22);
    end;

    if v24 then
        return v24;
    end;

    local v25 = 48;
    local v26 = nil;

    for _, v in ipairs((liveModels())) do
        if isTargetable(v, p22) then
            local v27, v28 = workspace_CurrentCamera:WorldToScreenPoint(v.HumanoidRootPart.Position);

            if v28 then
                local Magnitude = (Vector2.new(v27.X, v27.Y) - MouseLocation).Magnitude;

                if Magnitude < v25 then
                    v26 = v;
                    v25 = Magnitude;
                end;
            end;
        end;
    end;

    return v26;
end;

local function scoreOf(p29, p30) -- Line: 209
    -- upvalues: workspace_CurrentCamera (copy)
    local v31, v32 = workspace_CurrentCamera:WorldToViewportPoint(p29.model.HumanoidRootPart.Position);
    local dist = p29.dist;

    if v32 then
        return dist + (Vector2.new(v31.X, v31.Y) - p30).Magnitude / 40;
    end;

    return dist + 40;
end;

local function bestTarget(p33, p34, p35) -- Line: 222
    -- upvalues: candidates (copy), workspace_CurrentCamera (copy)
    local v36 = candidates(p33, p34);

    if #v36 == 0 then
        return nil;
    end;

    local ViewportSize = workspace_CurrentCamera.ViewportSize;
    local Vector2_new_ret = Vector2.new(ViewportSize.X / 2, ViewportSize.Y / 2);
    local v37 = (1 / 0);
    local v38 = nil;

    for _, v in ipairs(v36) do
        if not (p35 and p35[v.model]) then
            local v39, v40 = workspace_CurrentCamera:WorldToViewportPoint(v.model.HumanoidRootPart.Position);
            local dist = v.dist;
            local v41;

            if v40 then
                v41 = dist + (Vector2.new(v39.X, v39.Y) - Vector2_new_ret).Magnitude / 40;
            else
                v41 = dist + 40;
            end;

            if v41 < v37 then
                v38 = v.model;
                v37 = v41;
            end;
        end;
    end;

    return v38;
end;

local function nearestTarget(p42, p43) -- Line: 237
    -- upvalues: bestTarget (copy)
    return bestTarget(p42, p43, nil);
end;

local function clearConns() -- Line: 244
    -- upvalues: u7 (ref)
    for _, v in ipairs(u7) do
        v:Disconnect();
    end;

    u7 = {};
end;

local u44 = {};

local function release() -- Line: 253
    -- upvalues: u4 (ref), u5 (ref), clearConns (copy), u44 (ref), Mouse (copy), ObjectValue (copy), ServerRemote (copy), LocalPlayer (copy), u6 (ref), rotationBlocked (copy)
    if not u4 then
        return;
    end;

    u4 = nil;
    u5 = nil;
    clearConns();
    u44 = {};
    Mouse.SetAimOverride(nil);
    ObjectValue.Value = nil;
    ServerRemote:FireServer(nil, {
        Module = "LockOnHandler",
        Action = "Clear"
    });
    LocalPlayer:SetAttribute("LockOnActive", nil);
    local Character = LocalPlayer.Character;
    local v45;

    if Character then
        v45 = Character:FindFirstChildOfClass("Humanoid");
    else
        v45 = Character;
    end;

    local v46;

    if Character then
        v46 = Character:FindFirstChild("HumanoidRootPart");
    else
        v46 = Character;
    end;

    if not (v45 and (v46 and v45.Health > 0)) then
        v45 = nil;
        Character = nil;
    end;

    if v45 and u6 ~= nil then
        local v47 = u6;
        v45.AutoRotate = v47 == false and not (LocalPlayer:GetAttribute("ShiftLockOn") or rotationBlocked(Character, v45)) and true or v47;
    end;

    u6 = nil;
end;

local function lock(u48) -- Line: 275
    -- upvalues: LocalPlayer (copy), u6 (ref), u44 (ref), u4 (ref), release (copy), u5 (ref), mirror (copy), u8 (ref), workspace_CurrentCamera (copy), Mouse (copy), u7 (ref), Live (copy)
    local Character = LocalPlayer.Character;
    local v49;

    if Character then
        v49 = Character:FindFirstChildOfClass("Humanoid");
    else
        v49 = Character;
    end;

    local v50;

    if Character then
        v50 = Character:FindFirstChild("HumanoidRootPart");
    else
        v50 = Character;
    end;

    if not (v49 and (v50 and v49.Health > 0)) then
        Character = nil;
        v49 = nil;
    end;

    if not (Character and u48) then
        return;
    end;

    local v51 = u6;
    local v52 = u44;
    local v53 = u4 ~= nil;
    release();
    u4 = u48;
    u5 = u48.HumanoidRootPart;
    u6 = v53 and v51 and v51 or v49.AutoRotate;
    u44 = v53 and v52 and v52 or {};
    u44[u48] = true;
    LocalPlayer:SetAttribute("LockOnActive", true);
    mirror(u48);
    local HumanoidRootPart = Character:FindFirstChild("HumanoidRootPart");

    if HumanoidRootPart then
        u8 = math.clamp((workspace_CurrentCamera.CFrame.Position - HumanoidRootPart.Position).Magnitude, 8, 40);
    end;

    Mouse.SetAimOverride(function() -- Line: 294
        -- upvalues: u5 (ref), workspace_CurrentCamera (ref)
        if not u5 then
            return nil;
        end;

        local v54, v55 = workspace_CurrentCamera:WorldToViewportPoint(u5.Position);

        if v55 then
            return Vector2.new(v54.X, v54.Y);
        end;

        return nil;
    end);
    local v56 = u48:FindFirstChildOfClass("Humanoid");
    u7[#u7 + 1] = v56.Died:Connect(release);
    u7[#u7 + 1] = u48.AncestryChanged:Connect(function() -- Line: 303
        -- upvalues: u48 (copy), Live (ref), release (ref)
        if not u48:IsDescendantOf(Live) then
            release();
        end;
    end);
end;

local u57 = 0;

local function press() -- Line: 320
    -- upvalues: u57 (ref), LocalPlayer (copy), underCursor (copy), u4 (ref), release (copy), lock (copy), bestTarget (copy), u44 (ref)
    local os_clock_ret = os.clock();
    local v58 = os_clock_ret - u57;

    if v58 < 0.12 then
        return;
    end;

    u57 = os_clock_ret;
    local Character = LocalPlayer.Character;
    local v59;

    if Character then
        v59 = Character:FindFirstChildOfClass("Humanoid");
    else
        v59 = Character;
    end;

    local v60;

    if Character then
        v60 = Character:FindFirstChild("HumanoidRootPart");
    else
        v60 = Character;
    end;

    if not (v59 and (v60 and v59.Health > 0)) then
        Character = nil;
        v60 = nil;
    end;

    if not Character then
        return;
    end;

    local v61 = underCursor(Character);

    if not u4 then
        lock(v61 or bestTarget(Character, v60, nil));

        return;
    end;

    if v58 < 0.35 then
        release();

        return;
    end;

    if v61 and v61 ~= u4 then
        lock(v61);

        return;
    end;

    local v62 = bestTarget(Character, v60, u44);

    if not v62 then
        v62 = bestTarget(Character, v60, {
            [u4] = true
        });

        if v62 then
            u44 = {
                [u4] = true
            };
        end;
    end;

    if v62 then
        lock(v62);

        return;
    end;

    release();
end;

RunService:BindToRenderStep("LockOnCamera", Enum.RenderPriority.Camera.Value + 1, function() -- Line: 346
    -- upvalues: u4 (ref), LocalPlayer (copy), release (copy), isTargetable (copy), u5 (ref), rotationBlocked (copy), u6 (ref), u8 (ref), workspace_CurrentCamera (copy)
    if not u4 then
        return;
    end;

    local Character = LocalPlayer.Character;
    local v63;

    if Character then
        v63 = Character:FindFirstChildOfClass("Humanoid");
    else
        v63 = Character;
    end;

    local v64;

    if Character then
        v64 = Character:FindFirstChild("HumanoidRootPart");
    else
        v64 = Character;
    end;

    if not (v63 and (v64 and v63.Health > 0)) then
        Character = nil;
        v64 = nil;
        v63 = nil;
    end;

    if not Character then
        release();

        return;
    end;

    if not isTargetable(u4, Character) then
        release();

        return;
    end;

    local Position = u5.Position;

    if (Position - v64.Position).Magnitude > 220 then
        release();

        return;
    end;

    if rotationBlocked(Character, v63) then
        if v63.AutoRotate == false and u6 ~= false then
            v63.AutoRotate = u6;
        end;
    else
        v63.AutoRotate = false;
        local Vector3_new_ret = Vector3.new(Position.X - v64.Position.X, 0, Position.Z - v64.Position.Z);

        if Vector3_new_ret.Magnitude > 0.5 then
            v64.CFrame = v64.CFrame:Lerp(CFrame.lookAt(v64.Position, v64.Position + Vector3_new_ret.Unit), 0.35);
        end;
    end;

    local v65 = v64.Position + Vector3.new(0, 1.5, 0);
    local v66 = Position + Vector3.new(0, 1.5, 0);
    local v67 = u8;
    local v68 = v65 - v66;
    local Vector3_new_ret = Vector3.new(v68.X, 0, v68.Z);
    local Magnitude = Vector3_new_ret.Magnitude;

    if Magnitude < 0.5 then
        Vector3_new_ret = -v64.CFrame.LookVector;
    end;

    local Unit = Vector3_new_ret.Unit;
    local v69 = (-Unit):Cross(Vector3.new(0, 1, 0));
    local v70 = (1 - math.clamp(Magnitude / 28, 0, 1)) * 48 + 14;
    local math_rad_ret = math.rad(v70);
    local v71 = v65 + Unit * (v67 * math.cos(math_rad_ret));
    local v72 = v67 * math.sin(math_rad_ret);
    local v73 = v71 + Vector3.new(0, v72, 0) + v69 * 3.6;
    local RaycastParams_new_ret = RaycastParams.new();
    RaycastParams_new_ret.FilterType = Enum.RaycastFilterType.Exclude;
    RaycastParams_new_ret.FilterDescendantsInstances = { Character, u4, workspace.World:FindFirstChild("Visuals") };
    RaycastParams_new_ret.RespectCanCollide = true;
    local v74 = workspace:Raycast(v73 + Vector3.new(0, 3, 0), Vector3.new(0, -6, 0), RaycastParams_new_ret);

    if v74 and v73.Y < v74.Position.Y + 2 then
        v73 = Vector3.new(v73.X, v74.Position.Y + 2, v73.Z);
    end;

    local v75 = workspace:Raycast(v65, v73 - v65, RaycastParams_new_ret);

    if v75 then
        v73 = v75.Position + (v65 - v73).Unit * 1;
    end;

    local v76 = v65:Lerp(v66, 0.35);
    local CFrame_lookAt_ret = CFrame.lookAt(v73, v76);
    workspace_CurrentCamera.CFrame = workspace_CurrentCamera.CFrame:Lerp(CFrame_lookAt_ret, 0.18);
end);

local function lockOnAllowed() -- Line: 410
    -- upvalues: UserInputService (copy), Platform (copy)
    return UserInputService.TouchEnabled or (Platform.IsTouch() or Platform.PreferGamepadGlyphs());
end;

local function _() -- Line: 415
    -- upvalues: UserInputService (copy), Platform (copy), press (copy)
    if not (UserInputService.TouchEnabled or (Platform.IsTouch() or Platform.PreferGamepadGlyphs())) then
        return;
    end;

    press();
end;

UserInputService.LastInputTypeChanged:Connect(function() -- Line: 420
    -- upvalues: u4 (ref), UserInputService (copy), Platform (copy), release (copy)
    if u4 and not (UserInputService.TouchEnabled or (Platform.IsTouch() or Platform.PreferGamepadGlyphs())) then
        release();
    end;
end);
UserInputService.InputChanged:Connect(function(p77, p78) -- Line: 426
    -- upvalues: u4 (ref), u8 (ref)
    if not u4 then
        return;
    end;

    if p77.UserInputType == Enum.UserInputType.MouseWheel then
        u8 = math.clamp(u8 - p77.Position.Z * 2, 8, 40);

        return;
    end;

    if p77.UserInputType == Enum.UserInputType.Gamepad1 and (p77.KeyCode == Enum.KeyCode.Thumbstick2 and math.abs(p77.Position.Y) > 0.6) then
        u8 = math.clamp(u8 - p77.Position.Y * 0.35, 8, 40);
    end;
end);
TouchActionRemote.Event:Connect(function(p79, p80) -- Line: 437
    -- upvalues: press (copy)
    if p79 == "CoreControls" and p80 == "Lock On" then
        press();
    end;
end);
LocalPlayer.CharacterAdded:Connect(release);
LocalPlayer.CharacterRemoving:Connect(release);