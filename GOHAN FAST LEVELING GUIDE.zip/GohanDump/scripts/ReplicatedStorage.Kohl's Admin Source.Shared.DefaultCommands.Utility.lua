-- Decompiled with Potassium's decompiler.

return {
    {
        name = "version",
        description = "Displays the version of Kohl\'s Admin in this game.",
        optionalPrefix = true,

        runClient = function(p1) -- Line: 8, Name: runClient
            p1._K.Notify({
                From = "_K",
                Text = `<sc>version</sc>:\t<b>{p1._K.VERSION}</b>`
            });
        end
    },
    {
        name = "prefix",
        description = "Displays the prefix and hotkeys.",
        optionalPrefix = true,
        aliases = { "hotkeys" },

        runClient = function(p2) -- Line: 17, Name: runClient
            local commandBar = p2._K.client.hotkeys.commandBar;
            local StringForKeyCode = p2._K.UI.UserInputService:GetStringForKeyCode(commandBar.key._value);
            local v3 = `{commandBar.mods.Shift and "Shift+" or ""}{commandBar.mods.Alt and "Alt+" or ""}{commandBar.key._value.Name}`;
            local dashboard = p2._K.client.hotkeys.dashboard;
            local StringForKeyCode2 = p2._K.UI.UserInputService:GetStringForKeyCode(dashboard.key._value);
            local v4 = `{dashboard.mods.Shift and "Shift+" or ""}{dashboard.mods.Alt and "Alt+" or ""}{dashboard.key._value.Name}`;
            local v5 = p2._K.UI.raw(p2._K.client.settings.prefix)[1];
            local string_byte_ret = string.byte(v5);

            for _, v in Enum.KeyCode:GetEnumItems() do
                if v.Value == string_byte_ret then
                    string_byte_ret = v.Name;
                    break;
                end;
            end;

            p2._K.Notify({
                From = "_K",
                Text = table.concat({ `<font family="{p2._K.UI.Theme.FontMono._value.Family}"><b>Prefix</b>     <font color="#0f0">{string_byte_ret} {v5}</font>`, `<b>Commands</b>   <font color="#0f0">{v3} {StringForKeyCode}</font>`, (`<b>Dashboard</b>  <font color="#0f0">{v4} {StringForKeyCode2}</font></font>`) }, "\n")
            });
        end
    },
    {
        name = "cmdbar2",
        description = "Shows a floating command bar window.",
        optionalPrefix = true,
        aliases = { "cmdbarfloating", "cmdbarwindow" },

        envClient = function(u6) -- Line: 52, Name: envClient
            local UI = u6.UI;
            local v7 = {};
            local u8 = UI.new("Input")({
                ClearTextButton = true,
                Fill = true,
                Placeholder = ";command",
                Value = "",
                FontFace = UI.Theme.FontMono,
                FontSize = UI.Theme.FontSize
            });
            u8._input:GetPropertyChangedSignal("Text"):Connect(function() -- Line: 65
                -- upvalues: u6 (copy), u8 (copy)
                u6.client.updateCommandInput(u8);
            end);
            u8._input.FocusLost:Connect(function(p9) -- Line: 74
                -- upvalues: u6 (copy), u8 (copy)
                if p9 then
                    local v10 = u6.Util.String.trimEnd(u8._input.Text);
                    task.spawn(u6.Process.runCommands, u6, u6.LocalPlayer.UserId, v10);
                end;
            end);
            v7.window = UI.new("Window")({
                Parent = UI.LayerTopInset,
                Icon = "rbxassetid://71961243872230",
                Name = "Cmdbar2",
                Title = "Command Bar",
                AutomaticSize = Enum.AutomaticSize.Y,
                Size = UDim2.fromOffset(420, 0),
                UI.new("UIListLayout")({
                    SortOrder = Enum.SortOrder.LayoutOrder,
                    Padding = UI.Theme.Padding
                }),
                u8,
                UI.new("Button")({
                    Label = "Run Command",

                    Activated = function() -- Line: 69, Name: executeCommand
                        -- upvalues: u6 (copy), u8 (copy)
                        local v11 = u6.Util.String.trimEnd(u8._input.Text);
                        task.spawn(u6.Process.runCommands, u6, u6.LocalPlayer.UserId, v11);
                    end
                })
            });

            return v7;
        end,

        runClient = function(p12) -- Line: 103, Name: runClient
            p12.env.window._instance.Visible = not p12.env.window._instance.Visible;
        end
    },
    {
        name = "about",
        description = "Shows the about tab in a separate window.",
        optionalPrefix = true,
        aliases = { "credit", "credits", "info" },

        envClient = function(u13) -- Line: 112, Name: envClient
            local u14 = {};
            task.defer(function() -- Line: 114
                -- upvalues: u13 (copy), u14 (copy)
                while not u13.client do
                    task.wait();
                end;

                local u15 = u13.UI.new("Window")({
                    Icon = "rbxassetid://71961243872230",
                    Title = "About",
                    Parent = u13.UI.LayerTopInset
                });
                u13.UI.edit(u15, {
                    [u13.UI.Event] = {
                        Visible = function() -- Line: 125, Name: Visible
                            -- upvalues: u15 (copy), u13 (ref)
                            if not u15._instance.Visible then
                                u13.UI.edit(u13.client.dashboard.Tabs, { u13.client.dashboard.About });
                            end;
                        end
                    }
                });
                u14.window = u15;
            end);

            return u14;
        end,

        runClient = function(p16) -- Line: 139, Name: runClient
            p16._K.client.dashboard.About._instance.Parent = p16.env.window._content;
            p16._K.client.dashboard.About._instance.Visible = true;
            p16.env.window._instance.Visible = true;
        end
    },
    {
        name = "commands",
        description = "Shows the commands in a separate window.",
        optionalPrefix = true,
        aliases = { "cmds" },

        envClient = function(u17) -- Line: 150, Name: envClient
            local u18 = {};
            task.defer(function() -- Line: 152
                -- upvalues: u17 (copy), u18 (copy)
                while not u17.client do
                    task.wait();
                end;

                local u19 = u17.UI.new("Window")({
                    Icon = "rbxassetid://71961243872230",
                    Title = "Commands",
                    Parent = u17.UI.LayerTopInset
                });
                u17.UI.edit(u19, {
                    [u17.UI.Event] = {
                        Visible = function() -- Line: 163, Name: Visible
                            -- upvalues: u19 (copy), u17 (ref)
                            if not u19._instance.Visible then
                                u17.UI.edit(u17.client.dashboard.Tabs, { u17.client.dashboard.Commands });
                            end;
                        end
                    }
                });
                u18.window = u19;
            end);

            return u18;
        end,

        runClient = function(p20) -- Line: 177, Name: runClient
            p20._K.UI.edit(p20.env.window, {
                Visible = true,
                p20._K.client.dashboard.Commands
            });
            p20._K.client.dashboard.Commands._instance.Visible = true;
        end
    },
    {
        name = "commandbar",
        description = "Shows the command bar.",
        optionalPrefix = true,
        aliases = { "cmdbar" },

        runClient = function(p21) -- Line: 190, Name: runClient
            if p21._K.Data.settings.commandBarRank == false then
                return "Command bar has been disabled.";
            end;

            if p21._K.Data.settings.commandBarRank > p21.fromRank then
                return `Command bar has been restricted to {p21._K.Auth.getRoleFromRank(p21._K.Data.settings.dashboardRank).name}+.`;
            end;

            task.defer(p21._K.client.CommandBar.show);
        end
    },
    {
        name = "dashboard",
        description = "Shows the admin dashboard.",
        optionalPrefix = true,

        runClient = function(p22) -- Line: 206, Name: runClient
            if p22._K.Data.settings.dashboardRank == false then
                return "Dashboard has been disabled.";
            end;

            if p22._K.Data.settings.dashboardRank > p22.fromRank then
                return `Dashboard has been restricted to {p22._K.Auth.getRoleFromRank(p22._K.Data.settings.dashboardRank).name}+.`;
            end;

            if not p22._K.client.dashboard.Window.Visible then
                p22._K.client.hotkeys.dashboard.callback();
            end;
        end
    },
    {
        name = "donate",
        description = "Shows the market tab in a separate window.",
        optionalPrefix = true,
        aliases = { "market", "support" },

        envClient = function(u23) -- Line: 225, Name: envClient
            local u24 = {};
            task.defer(function() -- Line: 227
                -- upvalues: u23 (copy), u24 (copy)
                while not u23.client do
                    task.wait();
                end;

                local u25 = u23.UI.new("Window")({
                    Icon = "rbxassetid://71961243872230",
                    Title = "Market",
                    Parent = u23.UI.LayerTopInset
                });
                u23.UI.edit(u25, {
                    [u23.UI.Event] = {
                        Visible = function() -- Line: 238, Name: Visible
                            -- upvalues: u25 (copy), u23 (ref)
                            if not u25._instance.Visible then
                                u23.UI.edit(u23.client.dashboard.Tabs, { u23.client.dashboard.Market });
                            end;
                        end
                    }
                });
                u24.window = u25;
            end);

            return u24;
        end,

        runClient = function(p26) -- Line: 252, Name: runClient
            p26._K.client.dashboard.Market._instance.Parent = p26.env.window._content;
            p26._K.client.dashboard.Market._instance.Visible = true;
            p26.env.window._instance.Visible = true;
        end
    },
    {
        name = "log",
        description = "Shows the logs in a separate window.",
        optionalPrefix = true,
        aliases = { "logs", "debuglogs", "errorlogs", "chatlogs", "commandlogs", "joinlogs", "damagelogs", "killlogs", "purchaselogs", "clogs", "cmdlogs", "dmglogs", "buylogs" },

        envClient = function(u27) -- Line: 277, Name: envClient
            local u28 = {
                originalFilter = nil,
                aliasMap = {
                    clogs = "chatlogs",
                    cmdlogs = "commandlogs",
                    dmglogs = "damagelogs",
                    buylogs = "purchaselogs"
                },
                typeMap = {
                    DEBUG = { "DEBUG", "INFO", "WARN", "ERROR" },
                    ERROR = { "WARN", "ERROR" },
                    CHAT = { "CHAT" },
                    COMMAND = { "COMMAND" },
                    JOIN = { "JOIN", "LEAVE" },
                    KILL = { "KILL", "DEATH", "DAMAGE" },
                    DAMAGE = { "KILL", "DEATH", "DAMAGE" },
                    PURCHASE = { "PURCHASE" }
                }
            };
            task.defer(function() -- Line: 298
                -- upvalues: u27 (copy), u28 (copy)
                while not u27.client do
                    task.wait();
                end;

                local u29 = u27.UI.new("Window")({
                    Icon = "rbxassetid://71961243872230",
                    Title = "Logs",
                    Parent = u27.UI.LayerTopInset
                });
                u27.UI.edit(u29, {
                    [u27.UI.Event] = {
                        Visible = function() -- Line: 309, Name: Visible
                            -- upvalues: u29 (copy), u27 (ref), u28 (ref)
                            if not u29._instance.Visible then
                                u27.UI.edit(u27.client.dashboard.Tabs, { u27.client.dashboard.Logs });

                                if u28.originalFilter then
                                    for i, v in u28.originalFilter do
                                        u27.client.dashboard.Logs.logTypeFilter[i](v);
                                    end;

                                    u28.originalFilter = nil;
                                end;
                            end;
                        end
                    }
                });
                u28.window = u29;
            end);

            return u28;
        end,

        runClient = function(p30) -- Line: 329, Name: runClient
            p30._K.UI.edit(p30.env.window, {
                Visible = true,
                p30._K.client.dashboard.Logs
            });
            p30._K.client.dashboard.Logs._instance.Visible = true;

            if not p30.env.originalFilter then
                p30.env.originalFilter = {};

                for i, v in p30._K.client.dashboard.Logs.logTypeFilter do
                    p30.env.originalFilter[i] = v._value;
                end;
            end;

            if p30.alias == "log" or p30.alias == "logs" then
                for _, v in p30._K.client.dashboard.Logs.logTypeFilter do
                    v(true);
                end;

                return;
            end;

            for _, v in p30._K.client.dashboard.Logs.logTypeFilter do
                v(false);
            end;

            local string_lower_ret = string.lower(p30.alias);
            local string_upper_ret = string.upper((string.match(p30.env.aliasMap[string_lower_ret] or string_lower_ret, "(%w+)logs?$")));

            for _, v in p30.env.typeMap[string_upper_ret] do
                p30._K.client.dashboard.Logs.logTypeFilter[v](true);
            end;
        end
    },
    {
        name = "settings",
        description = "Shows the settings in a separate window.",
        optionalPrefix = true,
        aliases = { "set" },

        envClient = function(u31) -- Line: 365, Name: envClient
            local u32 = {};
            task.defer(function() -- Line: 367
                -- upvalues: u31 (copy), u32 (copy)
                while not u31.client do
                    task.wait();
                end;

                local u33 = u31.UI.new("Window")({
                    Icon = "rbxassetid://71961243872230",
                    Title = "Settings",
                    Parent = u31.UI.LayerTopInset
                });
                u31.UI.edit(u33, {
                    [u31.UI.Event] = {
                        Visible = function() -- Line: 378, Name: Visible
                            -- upvalues: u33 (copy), u31 (ref)
                            if not u33._instance.Visible then
                                u31.UI.edit(u31.client.dashboard.Tabs, { u31.client.dashboard.Settings });
                            end;
                        end
                    }
                });
                u32.window = u33;
            end);

            return u32;
        end,

        runClient = function(p34) -- Line: 392, Name: runClient
            p34._K.UI.edit(p34.env.window, {
                Visible = true,
                p34._K.client.dashboard.Settings
            });
            p34._K.client.dashboard.Settings._instance.Visible = true;
        end
    },
    {
        name = "emote",
        description = "Plays an animation on one or more player(s).",
        aliases = { "animation", "anim", "stopemote", "stopanim" },
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) to play the animation on."
            }, {
                type = "emote",
                name = "Animation",
                description = "The emote or animation id to play.",
                optional = true
            }, {
                type = "boolean",
                name = "Looping",
                description = "If the animation should loop.",
                optional = true
            }, {
                type = "number",
                name = "Speed",
                description = "The speed of the animation.",
                optional = true
            } },

        envClient = function(u35) -- Line: 429, Name: envClient
            local UI = u35.UI;
            local u36 = {
                playing = nil,
                looped = nil,
                speed = nil,
                window = nil,
                preview = nil
            };
            local u37 = UI.state();
            local u38 = UI.state(false);
            u36.emoteId = u37;
            task.defer(function() -- Line: 444
                -- upvalues: u35 (copy), UI (copy), u36 (copy), u37 (copy), u38 (copy)
                while not u35.client do
                    task.wait();
                end;

                local u39 = 0;
                local u40 = 180;
                local u41 = 9;
                local WorldModel = Instance.new("WorldModel");
                local u42 = UI.new("Camera")({});
                local u43 = CFrame.new(0, 3, 0) * CFrame.fromOrientation(math.rad(u39), math.rad(u40), 0) * CFrame.new(0, 0, u41);
                local u44 = game:GetService("TweenService"):Create(u42, TweenInfo.new(1, Enum.EasingStyle.Cubic), {
                    CFrame = u43
                });
                local u45 = u35.Util.Function.debounce(4, function() -- Line: 464
                    -- upvalues: u44 (copy)
                    u44:Play();
                end);

                local function updatePreviewCamera() -- Line: 468
                    -- upvalues: u42 (copy), u39 (ref), u40 (ref), u41 (ref), u43 (copy), u45 (copy)
                    u42.CFrame = CFrame.new(0, 3, 0) * CFrame.fromOrientation(math.rad(u39), math.rad(u40), 0) * CFrame.new(0, 0, u41);

                    if not u42.CFrame:FuzzyEq(u43) then
                        u45();
                    end;
                end;

                updatePreviewCamera();
                local u46 = nil;
                local u47 = nil;
                local u48 = nil;
                local u49 = nil;
                u36.preview = UI.new("Frame")({
                    Name = "Preview",
                    Parent = UI.LayerTopInset,
                    BackgroundColor3 = Color3.new(1, 1, 1),
                    Size = UDim2.new(0, 300, 0, 360),
                    Position = UDim2.new(0.5, -150, 0.5, -180),
                    Visible = false,
                    ZIndex = 900000000,
                    UI.new("UICorner")({
                        CornerRadius = UDim.new(0, 12)
                    }),
                    UI.new("UIGradient")({
                        Rotation = 90,
                        Color = ColorSequence.new({
                            ColorSequenceKeypoint.new(0, Color3.fromRGB(18, 18, 21)),
                            ColorSequenceKeypoint.new(0.3333333333333333, Color3.fromRGB(36, 36, 42)),
                            ColorSequenceKeypoint.new(0.6666666666666666, Color3.fromRGB(36, 36, 42)),
                            ColorSequenceKeypoint.new(1, Color3.fromRGB(18, 18, 21))
                        })
                    }),
                    UI.new("ViewportFrame")({
                        BackgroundTransparency = 1,
                        Size = UDim2.new(1, 0, 1, 0),
                        Ambient = Color3.fromRGB(127, 127, 127),
                        LightColor = Color3.fromRGB(200, 200, 200),
                        LightDirection = Vector3.new(0, -1, 1),
                        CurrentCamera = u42,
                        u42,
                        WorldModel,

                        MouseWheelBackward = function() -- Line: 514, Name: MouseWheelBackward
                            -- upvalues: u41 (ref), updatePreviewCamera (copy)
                            u41 = math.clamp(u41 + 1, 3, 15);
                            updatePreviewCamera();
                        end,

                        MouseWheelForward = function() -- Line: 518, Name: MouseWheelForward
                            -- upvalues: u41 (ref), updatePreviewCamera (copy)
                            u41 = math.clamp(u41 - 1, 3, 15);
                            updatePreviewCamera();
                        end,

                        TouchPinch = function(p50, p51, p52, p53) -- Line: 522, Name: TouchPinch
                            -- upvalues: u41 (ref), updatePreviewCamera (copy)
                            if p53 == Enum.UserInputState.Change then
                                u41 = math.clamp(p51 * 15, 3, 15);
                                updatePreviewCamera();
                            end;
                        end,

                        InputBegan = function(p54) -- Line: 528, Name: InputBegan
                            -- upvalues: u46 (ref), u47 (ref), u39 (ref), u48 (ref), u40 (ref)
                            if p54.UserInputType == Enum.UserInputType.MouseButton1 or p54.UserInputType == Enum.UserInputType.Touch then
                                u46 = p54.Position;
                                u47 = u39;
                                u48 = u40;
                            end;
                        end,

                        InputChanged = function(p55, p56) -- Line: 538, Name: InputChanged
                            -- upvalues: u46 (ref), u39 (ref), u47 (ref), u40 (ref), u48 (ref), updatePreviewCamera (copy)
                            if p56 or not u46 then
                                return;
                            end;

                            if p55.UserInputType == Enum.UserInputType.MouseMovement or p55.UserInputType == Enum.UserInputType.Touch then
                                local v57 = u46 - p55.Position;
                                u39 = (u47 + v57.Y) % 360;
                                u40 = (u48 + v57.X) % 360;
                                updatePreviewCamera();
                            end;
                        end,

                        InputEnded = function(p58) -- Line: 552, Name: InputEnded
                            -- upvalues: u46 (ref)
                            if p58.UserInputType == Enum.UserInputType.MouseButton1 or p58.UserInputType == Enum.UserInputType.Touch then
                                u46 = nil;
                            end;
                        end
                    }),
                    UI.new("ImageButton")({
                        Name = "Close",
                        BackgroundTransparency = 1,
                        Image = "rbxasset://textures/ui/ScreenshotHud/Close.png",
                        AnchorPoint = Vector2.new(1, 0),
                        Position = UDim2.new(1, -4, 0, 4),
                        Size = UDim2.fromOffset(32, 32),

                        Activated = function() -- Line: 569, Name: Activated
                            -- upvalues: u36 (ref)
                            u36.preview.Visible = false;
                        end
                    }),
                    UI.new("TextLabel")({
                        Name = "Title",
                        BackgroundTransparency = 1,
                        FontFace = Font.new("rbxassetid://12187365364", Enum.FontWeight.Bold, Enum.FontStyle.Normal),
                        Position = UDim2.fromOffset(0, 16),
                        Size = UDim2.new(1, 0, 0, 28),
                        Text = "Loading",
                        TextColor3 = Color3.new(1, 1, 1),
                        TextSize = 28,
                        UI.new("TextLabel")({
                            Name = "Category",
                            BackgroundTransparency = 1,
                            Text = "Emote",
                            TextSize = 16,
                            AutomaticSize = Enum.AutomaticSize.Y,
                            FontFace = Font.new("rbxassetid://12187365364"),
                            Position = UDim2.fromScale(0, 1),
                            Size = UDim2.fromScale(1, 0),
                            TextColor3 = Color3.new(1, 1, 1)
                        })
                    }),
                    UI.new("TextButton")({
                        Name = "Unlock",
                        AnchorPoint = Vector2.new(0.5, 1),
                        AutomaticSize = Enum.AutomaticSize.XY,
                        BackgroundColor3 = Color3.fromRGB(51, 95, 255),
                        FontFace = Font.new("rbxassetid://12187365364", Enum.FontWeight.Bold, Enum.FontStyle.Normal),
                        Position = UDim2.new(0.5, 0, 1, -38),
                        Text = "UNLOCK",
                        TextColor3 = Color3.new(1, 1, 1),
                        TextSize = 28,
                        UI.new("UICorner")({
                            Name = "UICorner",
                            CornerRadius = UDim.new(0, 12)
                        }),
                        UI.new("UIPadding")({
                            Name = "UIPadding",
                            PaddingBottom = UDim.new(0, 12),
                            PaddingLeft = UDim.new(0, 34),
                            PaddingRight = UDim.new(0, 34),
                            PaddingTop = UDim.new(0, 12)
                        }),

                        Activated = function() -- Line: 621, Name: Activated
                            -- upvalues: u49 (ref), u35 (ref)
                            if u49 then
                                u35.PromptBulkPurchase(u49);
                            end;
                        end
                    }),
                    UI.new("TextLabel")({
                        Name = "Tip",
                        BackgroundTransparency = 1,
                        RichText = true,
                        Text = "Use in <b>every</b> Roblox game",
                        TextSize = 16,
                        AnchorPoint = Vector2.new(0, 1),
                        AutomaticSize = Enum.AutomaticSize.Y,
                        FontFace = Font.new("rbxassetid://12187365364", Enum.FontWeight.Light, Enum.FontStyle.Normal),
                        Position = UDim2.new(0, 0, 1, -16),
                        Size = UDim2.fromScale(1, 0),
                        TextColor3 = Color3.new(1, 1, 1)
                    })
                });
                task.spawn(function() -- Line: 643
                    -- upvalues: u35 (ref), WorldModel (copy), u49 (ref), u39 (ref), u40 (ref), u41 (ref), updatePreviewCamera (copy), u36 (ref)
                    local v59, u60 = u35.Util.Retry(function() -- Line: 644
                        -- upvalues: u35 (ref)
                        return u35.Service.Players:CreateHumanoidModelFromUserId((math.max(1, u35.LocalPlayer.UserId)));
                    end);

                    if not v59 then
                        u60 = u35.Flux.new("Model")({ u35.Flux.new("Humanoid")({ u35.Flux.new("Animator")({}) }) });
                    end;

                    u60:PivotTo(CFrame.new(0, 3, 0));
                    task.spawn(function() -- Line: 656
                        -- upvalues: u60 (ref), WorldModel (ref)
                        local Animate = u60:WaitForChild("Animate", 5);

                        if typeof(Animate) == "Instance" and Animate:IsA("LocalScript") then
                            Animate:Destroy();
                        end;

                        u60.Parent = WorldModel;
                    end);
                    local Animator = u60:WaitForChild("Humanoid"):WaitForChild("Animator");
                    local Animation = Instance.new("Animation");
                    local u61 = nil;

                    function u36.updatePreview(p62) -- Line: 670
                        -- upvalues: u61 (ref), u49 (ref), u39 (ref), u40 (ref), u41 (ref), updatePreviewCamera (ref), u35 (ref), u36 (ref), Animation (copy), Animator (copy)
                        if u61 then
                            u61:Stop();
                            u61:Destroy();
                        end;

                        u49 = p62;

                        if p62 then
                            u39 = 0;
                            u40 = 180;
                            u41 = 9;
                            updatePreviewCamera();
                            local v63 = u35.Data.emoteItemFromId[p62];
                            u36.preview.Title.Text = v63.name;
                            Animation.AnimationId = "rbxassetid://" .. v63.animationId;
                            u61 = Animator:LoadAnimation(Animation);
                            u61.Looped = true;
                            u61:Play();
                        end;
                    end;
                end);
                local v65 = UI.new("Switch")({
                    [UI.Hook] = {
                        Value = function(p64: boolean) -- Line: 694, Name: Value
                            -- upvalues: u36 (ref)
                            if u36.playing then
                                u36.playing.Looped = p64;

                                if not u36.playing.IsPlaying then
                                    u36.playing:Play(0.1, 99, u36.speed.Value._value * 2);
                                end;
                            end;
                        end
                    }
                });
                local v67 = UI.new("Slider")({
                    [UI.Hook] = {
                        Value = function(p66: number) -- Line: 706, Name: Value
                            -- upvalues: u36 (ref)
                            if u36.playing then
                                u36.playing:AdjustSpeed(p66 * 2);
                            end;
                        end
                    }
                });
                u36.looped = v65;
                u36.speed = v67;
                local v68 = UI.new("Window")({
                    Parent = UI.LayerTopInset,
                    Title = "Emote",
                    Resizable = false,
                    Size = UDim2.new(0, 256, 0, 32),
                    Position = UDim2.new(1, -262, 0.5, -16),
                    UI.new("List")({ UI.new("ListItem")({
                            Text = "Looped",
                            v65
                        }), UI.new("ListItem")({
                            Text = "Speed",
                            v67
                        }) })
                });
                v68._content.Size = UDim2.fromScale(1, 0);
                v68._content.AutomaticSize = Enum.AutomaticSize.Y;
                v68._instance.Frame.AutomaticSize = Enum.AutomaticSize.Y;
                v68._instance.AutomaticSize = Enum.AutomaticSize.Y;
                local u69 = UI.compute(function() -- Line: 733
                    -- upvalues: UI (ref)
                    return UI.Theme.FontSize() + UI.Theme.Padding().Offset * 2;
                end);

                local function v70() -- Line: 736
                    -- upvalues: u69 (copy)
                    return UDim2.fromOffset(u69(), u69());
                end;

                local function v71() -- Line: 739
                    -- upvalues: u37 (ref)
                    return u37() ~= nil;
                end;

                UI.new("Button")({
                    LayoutOrder = 3,
                    Label = "🔓",
                    Parent = v68._instance.Frame.TitleBar,
                    Size = v70,

                    Visible = function() -- Line: 748, Name: Visible
                        -- upvalues: u37 (ref), u38 (ref)
                        local v72 = u37() ~= nil and not u38();

                        return v72;
                    end,

                    Activated = function() -- Line: 751, Name: Activated
                        -- upvalues: u36 (ref), u37 (ref)
                        if u36.updatePreview and u36.preview then
                            u36.updatePreview(u37._value);
                            u36.preview.Visible = true;
                        end;
                    end
                });
                UI.new("Button")({
                    LayoutOrder = 3,
                    Label = "⭐",
                    Parent = v68._instance.Frame.TitleBar,
                    Size = v70,
                    Visible = v71,

                    Activated = function() -- Line: 765, Name: Activated
                        -- upvalues: u35 (ref), u37 (ref)
                        pcall(function() -- Line: 766
                            -- upvalues: u35 (ref), u37 (ref)
                            u35.Service.AvatarEditor:PromptSetFavorite(u37._value, 1, true);
                        end);
                    end
                });
                u36.window = v68;
            end);

            local function playEmote(p73: number, p74: boolean?, p75: number?) -- Line: 775
                -- upvalues: u36 (copy), u37 (copy), u38 (copy), u35 (copy)
                if u36.playing then
                    u36.playing:Stop();
                    u36.playing:Destroy();
                    u36.playing = nil;
                    u37(nil);
                    u38(false);
                end;

                if p73 then
                    local LocalPlayer = u35.LocalPlayer;
                    local Animator = (LocalPlayer.Character or LocalPlayer.CharacterAdded:Wait()):WaitForChild("Humanoid"):WaitForChild("Animator");
                    local v76 = u35.Flux.new("Animation")({
                        AnimationId = `rbxassetid://{p73}`
                    });
                    local u77 = Animator:LoadAnimation(v76);
                    u77.Priority = Enum.AnimationPriority.Action;
                    v76.Parent = u77;

                    if p74 == nil then
                        task.spawn(function() -- Line: 802
                            -- upvalues: u77 (copy), u36 (ref)
                            local v78 = tick();

                            repeat
                                task.wait();
                            until u77.Looped == true or tick() - v78 > 1;

                            u36.looped.Value(true);
                        end);
                    else
                        u77.Looped = p74;
                        u36.looped.Value(u77.Looped);
                    end;

                    u36.speed.Value(math.clamp(p75 or 1, 0, 2) / 2);

                    if not u77.Looped then
                        u77.Stopped:Once(function() -- Line: 814
                            -- upvalues: u77 (copy)
                            u77:Destroy();
                        end);
                    end;

                    local u79 = u35.Data.animationToEmoteId[p73];
                    local v80 = u37 and u35.Data.emoteItemFromId[u79];
                    u36.window.Title(not v80 and "Emote" or v80.name);
                    u37(u79);
                    u38(false);
                    task.spawn(function() -- Line: 824
                        -- upvalues: u35 (ref), u79 (copy), u38 (ref)
                        local v81, v82 = u35.Util.Retry(function() -- Line: 825
                            -- upvalues: u35 (ref), u79 (ref)
                            return u35.Service.Marketplace:PlayerOwnsAssetAsync(u35.LocalPlayer, u79);
                        end);

                        if v81 then
                            u38(v82);
                        end;
                    end);
                    u77:Play(0.1, 99, p75);
                    u36.playing = u77;
                    u36.window._instance.Visible = true;

                    return u77;
                end;
            end;

            u36.playEmote = playEmote;
            u35.Remote.Emote:Connect(playEmote);

            return u36;
        end,

        env = function(p83) -- Line: 845, Name: env
            return {
                remote = p83.Remote.Emote
            };
        end,

        run = function(u84: any, p85: any, u86: number, p87: boolean?, p88: number?) -- Line: 850, Name: run
            if u84._K.Auth.hasPermission(u84.from, "targetOthers") ~= true and not u84._K.Auth.hasPermission(u84.from, "admin") then
                local v89, v90 = u84._K.Util.Retry(function() -- Line: 855
                    -- upvalues: u84 (copy), u86 (copy)
                    return u84._K.Service.Marketplace:PlayerOwnsAssetAsync(u84._K.LocalPlayer, u86);
                end);

                if v89 and not v90 then
                    local v91 = tostring(u86);
                    u84._K.Service.Marketplace:PromptBulkPurchase(u84._K.LocalPlayer, {
                        {
                            Type = Enum.MarketplaceProductType.AvatarAsset,
                            Id = not u84._K.VIP.allowedBulkPurchaseIds[u86] and "115444443724463" or v91
                        }
                    }, {});

                    return;
                end;
            end;

            for _, v in p85 do
                u84.env.remote:Fire(v, u86, p87, p88);
            end;
        end
    },
    {
        name = "emotes",
        description = "Shows the emotes list.",
        optionalPrefix = true,

        envClient = function(u92) -- Line: 877, Name: envClient
            local UI = u92.UI;
            local u93 = {};
            task.spawn(function() -- Line: 882
                -- upvalues: u92 (copy), UI (copy), u93 (copy)
                repeat
                    task.wait();
                until u92.Registry.commands.emote and u92.Registry.commands.emote.env;

                local env = u92.Registry.commands.emote.env;
                local v103 = UI.new("ScrollerFast")({
                    Enabled = true,
                    Visible = true,
                    List = u92.Data.emotes,

                    CreateItem = function(p94, p95) -- Line: 893, Name: CreateItem
                        -- upvalues: UI (ref), env (copy), u92 (ref)
                        local u96 = {
                            lineData = p95
                        };
                        u96._instance = UI.new("Frame")({
                            BackgroundTransparency = 1,
                            Size = p94.ItemSize,
                            UI.new("UIPadding")({
                                PaddingTop = UI.Theme.PaddingHalf,
                                PaddingBottom = UI.Theme.PaddingHalf
                            }),
                            UI.new("UIListLayout")({
                                VerticalAlignment = Enum.VerticalAlignment.Center,
                                FillDirection = Enum.FillDirection.Horizontal,
                                SortOrder = Enum.SortOrder.LayoutOrder,
                                Padding = UI.Theme.Padding
                            }),
                            UI.new("ImageButton")({
                                BackgroundTransparency = 1,
                                BackgroundColor3 = UI.Theme.PrimaryText,
                                Size = UDim2.new(1, 0, 1, 0),
                                SizeConstraint = Enum.SizeConstraint.RelativeYY,
                                ImageTransparency = 0.25,

                                ImageColor3 = function() -- Line: 920, Name: ImageColor3
                                    -- upvalues: env (ref), u96 (copy)
                                    if env.emoteId() == u96.lineData.emoteId then
                                        return Color3.new(1, 0, 0);
                                    end;

                                    return Color3.new(1, 1, 1);
                                end,

                                Image = function() -- Line: 925, Name: Image
                                    -- upvalues: env (ref), u96 (copy), UI (ref)
                                    if env.emoteId() == u96.lineData.emoteId then
                                        return UI.Theme.Image.Stop;
                                    end;

                                    return UI.Theme.Image.Play;
                                end,

                                UI.action(function(u97) -- Line: 931
                                    -- upvalues: u96 (copy), u92 (ref), env (ref)
                                    u97.Activated:Connect(function() -- Line: 932
                                        -- upvalues: u96 (ref), u92 (ref), env (ref)
                                        if not u96.lineData.owned or u92.LocalPlayer:GetAttribute("_KDonationLevel") < 4 then
                                            env.updatePreview(u96.lineData.emoteId);
                                            env.preview.Visible = true;

                                            return;
                                        end;

                                        if env.emoteId._value == u96.lineData.emoteId then
                                            u92.UI.Sound.Hover01:Play();
                                            env.playEmote();

                                            return;
                                        end;

                                        u92.UI.Sound.Hover03:Play();

                                        if u92.forceChat then
                                            local name = u96.lineData.name;

                                            if string.find(name, u92.Data.settings.splitKey, 1, true) then
                                                name = `"{name}"`;
                                            end;

                                            u92.forceChat((`{u92.getCommandPrefix()}emote me {name}`));
                                        end;
                                    end);
                                    u97.MouseEnter:Connect(function() -- Line: 955
                                        -- upvalues: u97 (copy)
                                        u97.ImageTransparency = 0;
                                    end);
                                    u97.MouseLeave:Connect(function() -- Line: 958
                                        -- upvalues: u97 (copy)
                                        u97.ImageTransparency = 0.25;
                                    end);
                                end)
                            }),
                            UI.new("TextLabel")({
                                AutoLocalize = false,
                                AutomaticSize = Enum.AutomaticSize.X,
                                BackgroundTransparency = 1,
                                Size = UDim2.new(0, 0, 1, 0),
                                RichText = true,
                                FontFace = UI.Theme.FontMono,
                                TextSize = UI.Theme.FontSize,
                                TextColor3 = UI.Theme.PrimaryText,
                                TextStrokeColor3 = UI.Theme.Primary,
                                TextStrokeTransparency = UI.Theme.TextStrokeTransparency,
                                TextTruncate = Enum.TextTruncate.SplitWord,
                                TextXAlignment = Enum.TextXAlignment.Left,
                                UI.new("UIFlexItem")({
                                    FlexMode = Enum.UIFlexMode.Fill
                                })
                            }),
                            UI.new("Spacer")({}),
                            UI.new("Button")({
                                Name = "Unlock",
                                Label = "🔓",
                                Padding = UI.Theme.PaddingHalf,
                                Size = UDim2.new(1, 0, 1, 0),
                                SizeConstraint = Enum.SizeConstraint.RelativeYY,

                                Activated = function() -- Line: 989, Name: Activated
                                    -- upvalues: env (ref), u96 (copy)
                                    env.updatePreview(u96.lineData.emoteId);
                                    env.preview.Visible = true;
                                end
                            }),
                            UI.new("Button")({
                                Label = "⭐",
                                Padding = UI.Theme.PaddingHalf,
                                Size = UDim2.new(1, 0, 1, 0),
                                SizeConstraint = Enum.SizeConstraint.RelativeYY,

                                Activated = function() -- Line: 1000, Name: Activated
                                    -- upvalues: u92 (ref), u96 (copy)
                                    pcall(function() -- Line: 1001
                                        -- upvalues: u92 (ref), u96 (ref)
                                        u92.Service.AvatarEditor:PromptSetFavorite(u96.lineData.emoteId, 1, true);
                                    end);
                                end
                            })
                        });

                        return u96;
                    end,

                    RenderItem = function(u98, p99, u100) -- Line: 1011, Name: RenderItem
                        -- upvalues: u92 (ref)
                        p99.lineData = u100;
                        local _instance = p99._instance;
                        _instance.TextLabel.Text = u100.name;

                        if u100.owned == nil then
                            u100.owned = false;
                            task.spawn(function() -- Line: 1017
                                -- upvalues: u92 (ref), u100 (copy), u98 (copy)
                                local v101, v102 = u92.Util.Retry(function() -- Line: 1018
                                    -- upvalues: u92 (ref), u100 (ref)
                                    return u92.Service.Marketplace:PlayerOwnsAssetAsync(u92.LocalPlayer, u100.emoteId);
                                end);

                                if v101 then
                                    u100.owned = v102;
                                    u98:render(true);
                                end;
                            end);
                        end;

                        _instance.Unlock.Visible = not u100.owned;
                    end
                });
                UI.edit(v103._instance, { UI.new("UIPadding")({
                        PaddingTop = UI.Theme.PaddingStroke,
                        PaddingBottom = UI.Theme.PaddingStroke,
                        PaddingLeft = UI.Theme.PaddingStroke,
                        PaddingRight = UI.Theme.PaddingStroke
                    }) });
                UI.edit(v103._scroller.UIPadding, {
                    PaddingTop = UDim.new(),
                    PaddingBottom = UDim.new()
                });
                u93.scroller = v103;
                u93.window = UI.new("Window")({
                    Parent = UI.LayerTopInset,
                    Name = "Emotes",
                    Title = "Emotes",
                    Exitable = true,
                    Position = UDim2.new(0.5, -128, 0.5, -128),
                    Size = UDim2.new(0, 256, 0, 256),
                    v103
                });
            end);

            return u93;
        end,

        runClient = function(p104, p105) -- Line: 1059, Name: runClient
            p104.env.window._instance.Visible = true;
        end
    },
    {
        name = "age",
        description = "Displays the account age of a player.",
        aliases = { "accountage" },
        args = { {
                type = "player",
                name = "Player",
                description = "The player whose account age to display.",
                lowerRank = true
            } },

        runClient = function(p106: any, p107: userdata) -- Line: 1077, Name: runClient
            p106._K.Notify({
                From = p107.UserId,
                Text = `<b>Account Age:</b> {p106._K.Util.Time.readable(p107.AccountAge * 86400)}`
            });
        end
    },
    {
        name = "serverage",
        description = "Displays the age of the server.",
        aliases = { "uptime" },

        runClient = function(p108, p109) -- Line: 1088, Name: runClient
            p108._K.Notify({
                From = "_K",
                Text = `<b>Server Age:</b> {p108._K.Util.Time.readable(workspace:GetServerTimeNow() - p108._K.script:GetAttribute("ServerStartTime"))}`
            });
        end
    },
    {
        name = "gameid",
        description = "Displays the current GameId.",
        aliases = {},

        runClient = function(p110, p111) -- Line: 1101, Name: runClient
            p110._K.Notify({
                From = "GameId",
                Selectable = true,
                Text = tostring(game.GameId)
            });
        end
    },
    {
        name = "jobid",
        description = "Displays the current JobId.",
        aliases = {},

        runClient = function(p112, p113) -- Line: 1109, Name: runClient
            p112._K.Notify({
                From = "JobId",
                Selectable = true,
                Text = tostring(game.JobId)
            });
        end
    },
    {
        name = "placeid",
        description = "Displays the current PlaceId.",
        aliases = {},

        runClient = function(p114, p115) -- Line: 1117, Name: runClient
            p114._K.Notify({
                From = "PlaceId",
                Selectable = true,
                Text = tostring(game.PlaceId)
            });
        end
    },
    {
        name = "showfps",
        description = "Displays the frames per second of a player.",
        aliases = { "getfps", "checkfps", "playerfps" },
        args = { {
                type = "player",
                name = "Player",
                description = "The player whose frames per second to display.",
                lowerRank = true
            } },

        env = function(p116) -- Line: 1134, Name: env
            return {
                remote = p116.Remote.ShowFPS
            };
        end,

        envClient = function(p117) -- Line: 1137, Name: envClient
            local u118 = {
                fps = 60
            };

            function p117.Remote.ShowFPS.OnInvoke() -- Line: 1141
                -- upvalues: u118 (copy)
                return u118.fps;
            end;

            local u119 = 0;
            local u120 = tick();
            p117.Service.Run.Heartbeat:Connect(function() -- Line: 1145
                -- upvalues: u119 (ref), u120 (ref), u118 (copy)
                u119 = u119 + 1;
                local v121 = tick() - u120;

                if v121 >= 1 then
                    u118.fps = u119 / v121;
                    local v122 = tick();
                    u119 = 0;
                    u120 = v122;
                end;
            end);

            return u118;
        end,

        run = function(p123: any, p124: userdata) -- Line: 1155, Name: run
            local Notify = p123._K.Remote.Notify;
            local fromPlayer = p123.fromPlayer;
            local v125 = {};
            local v126 = p123.env.remote:Invoke(p124) or 0;
            v125.Text = `<b>FPS:</b> {math.round(v126)}`;
            v125.From = p124.UserId;
            Notify:Fire(fromPlayer, v125);
        end
    },
    {
        name = "ping",
        description = "Displays the ping of a player.",
        aliases = { "getping", "checkping", "latency" },
        args = { {
                type = "player",
                name = "Player",
                description = "The player to ping.",
                lowerRank = true
            } },

        run = function(p127: any, p128: userdata) -- Line: 1175, Name: run
            local Notify = p127._K.Remote.Notify;
            local fromPlayer = p127.fromPlayer;
            local v129 = {};
            local v130 = p128:GetNetworkPing() * 1000;
            v129.Text = `<b>Ping:</b> {math.round(v130)} ms`;
            v129.From = p128.UserId;
            Notify:Fire(fromPlayer, v129);
        end
    },
    {
        name = "wait",
        description = "Delays command execution for a period of time.",
        aliases = { "delay" },
        args = { {
                type = "number",
                name = "Seconds",
                description = "How long to wait in seconds."
            } },

        run = function(p131: any, p132: number) -- Line: 1194, Name: run
            task.wait(p132);
        end
    },
    {
        name = "rejoin",
        description = "Rejoins the server.",
        aliases = { "rj" },

        run = function(p133) -- Line: 1203, Name: run
            local TeleportOptions = Instance.new("TeleportOptions");
            TeleportOptions.ServerInstanceId = game.JobId;
            p133._K.Util.SafeTeleport(game.PlaceId, { p133.fromPlayer }, TeleportOptions);
        end
    },
    {
        name = "viewas",
        description = "Views the admin system as one or more role(s).",
        aliases = { "unviewas" },
        args = { {
                type = "roles",
                name = "Roles(s)",
                description = "The roles(s) to test.",
                optional = true
            } },

        envClient = function(p134) -- Line: 1223, Name: envClient
            return {
                originalCreatorId = nil,
                originalMember = nil
            };
        end,

        runClient = function(p135, p136) -- Line: 1229, Name: runClient
            local v137 = tostring(p135.from);

            if p135.undo then
                if not p135.env.originalMember then
                    return;
                end;

                p135._K.Data.members[v137] = p135.env.originalMember;

                if p135.env.originalCreatorId then
                    p135._K.creatorId = p135.env.originalCreatorId;
                    p135._K.Data.creatorId = p135._K.creatorId;
                end;

                p135.env.originalMember = nil;
                p135.env.originalCreatorId = nil;
                p135._K.Notify({
                    From = "_K",
                    Text = "View returned to original permissions."
                });
            else
                if not p135.env.originalMember then
                    p135.env.originalMember = p135._K.Data.members[v137];

                    if p135.from == p135._K.creatorId then
                        p135.env.originalCreatorId = p135._K.creatorId;
                        p135._K.creatorId = 0;
                        p135._K.Data.creatorId = 0;
                    end;
                end;

                p135._K.Data.members[v137] = {
                    name = p135.fromPlayer.Name,
                    roles = p136 or {},
                    persist = {}
                };
                local v138 = {};

                if p136 then
                    for _, v in p136 do
                        local v139 = p135._K.Data.roles[v];

                        if v139 then
                            local v140 = `<font color="{v139.color}">{v139.name}</font>`;
                            table.insert(v138, v140);
                        end;
                    end;
                end;

                local everyone = p135._K.Data.roles.everyone;
                local v141 = `<font color="{everyone.color}">{everyone.name}</font>`;
                table.insert(v138, v141);
                local table_concat_ret = table.concat(v138, ", ");
                p135._K.Notify({
                    From = "_K",
                    Text = `Viewing the system as <sc>{table_concat_ret}</sc>` .. `\n\nUse <b>{p135._K.getCommandPrefix(p135.from)}unviewas</b> to return to normal.`
                });
            end;

            p135._K.client.members(p135._K.Data.members);
            p135._K.client.updateInterfaceAuth();
        end
    }
};