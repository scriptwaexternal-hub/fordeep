-- Decompiled with Potassium's decompiler.

return {
    Idle = {
        priority = 0,
        category = "baseline",
        allowedActions = { "*" },
        interruptedBy = { "*" }
    },
    Attacking = {
        priority = 20,
        category = "combat",
        allowedActions = { "Light", "Evade", "Dash", "Ki Sense", "DeCharge", "Swing" },
        interruptedBy = { "Stunned", "Knocked", "Dead", "Grabbed", "GettingGripped", "Clashing" }
    },
    LightAttacking = {
        priority = 20,
        category = "combat",
        duration = 0.5,
        allowedActions = { "Evade", "Ki Sense", "Light", "Run", "Dash", "Swing", "Skill" },
        interruptedBy = { "Stunned", "Knocked", "Dead", "Grabbed" }
    },
    HeavyAttacking = {
        priority = 25,
        category = "combat",
        duration = 0.7,
        allowedActions = { "Evade", "Ki Sense", "Run", "Heavy", "Dash", "Swing", "Skill" },
        interruptedBy = { "Stunned", "Knocked", "Dead", "Grabbed" },

        onExit = function(p1) -- Line: 86, Name: onExit
            local Server = game:GetService("ServerScriptService"):FindFirstChild("Server");

            if Server then
                require(Server.Managers.SpeedManager).Apply(p1);

                return;
            end;

            warn("Server Not Found!");
        end
    },
    Blocking = {
        priority = 30,
        category = "combat",
        allowedActions = { "Evade", "Ki Sense", "DeCharge", "Parry" },
        interruptedBy = { "Stunned", "Knocked", "Dead", "Grabbed", "GettingGripped" },

        onEnter = function(p2, p3) -- Line: 111, Name: onEnter
        end,

        onExit = function(p4, p5) -- Line: 114, Name: onExit
        end
    },
    PerfectBlocking = {
        priority = 35,
        category = "combat",
        duration = 0.2,
        allowedActions = { "Evade", "Ki Sense", "Parry" },
        interruptedBy = { "Stunned", "Knocked", "Dead" }
    },
    Evade = {
        priority = 66,
        category = "combat",
        allowedActions = { "*" },
        interruptedBy = { "Dead", "Knocked", "Grabbed" }
    },
    DamageDeb = {
        priority = 5,
        category = "combat",
        duration = 0.5,
        allowedActions = { "*" },
        interruptedBy = { "*" }
    },
    Dodging = {
        priority = 25,
        category = "combat",
        duration = 0.5,
        allowedActions = { "*" },
        interruptedBy = { "*" }
    },
    Dashing = {
        priority = 35,
        category = "combat",
        allowedActions = { "Ki Sense", "Dash Light", "Dash Swing", "Dash Suspend", "Run" },
        interruptedBy = { "Stunned", "Knocked", "Dead", "Grabbed" }
    },
    WeaponBlocking = {
        priority = 30,
        category = "combat",
        allowedActions = { "Evade", "Ki Sense", "DeCharge" },
        interruptedBy = { "Stunned", "Knocked", "Dead", "Grabbed" }
    },
    HoldingWeapon = {
        priority = 15,
        category = "combat",
        allowedActions = { "*" },
        interruptedBy = { "*" }
    },
    HoldingObject = {
        priority = 15,
        category = "combat",
        allowedActions = { "Dash", "Evade", "Ki Sense", "Run" },
        interruptedBy = { "Stunned", "Knocked", "Dead" }
    },
    ChargingBeam = {
        priority = 40,
        category = "combat",
        allowedActions = { "DeCharge", "Ki Sense" },
        interruptedBy = { "Stunned", "Knocked", "KO", "Dead", "GettingGripped", "GettingCarried", "WallSlammed", "TempKnock" }
    },
    GrabLocked = {
        priority = 85,
        category = "combat",
        allowedActions = { "Ki Sense" },
        interruptedBy = { "*" }
    },
    Gripping = {
        priority = 45,
        category = "combat",
        allowedActions = { "Grip" },
        interruptedBy = { "Stunned", "Dead" }
    },
    Charging = {
        priority = 25,
        category = "combat",
        allowedActions = { "DeCharge", "Ki Sense", "Dash" },
        interruptedBy = { "Stunned", "Knocked", "Dead", "Grabbed" }
    },
    DeCharge = {
        priority = 25,
        category = "combat",
        allowedActions = {},
        interruptedBy = { "Stunned", "Knocked", "Dead" }
    },
    UsingSkill = {
        priority = 45,
        category = "combat",
        allowedActions = { "Ki Sense" },
        interruptedBy = { "Stunned", "Knocked", "Dead", "Grabbed" }
    },
    UsedSkill = {
        priority = 20,
        category = "combat",
        allowedActions = { "Ki Sense", "Evade" },
        interruptedBy = { "Stunned", "Knocked", "Dead", "Grabbed" }
    },
    UsingMove = {
        priority = 45,
        category = "combat",
        allowedActions = { "Ki Sense" },
        interruptedBy = { "Stunned", "Knocked", "Dead", "Grabbed" }
    },
    HoldingMove = {
        priority = 35,
        category = "combat",
        allowedActions = { "Ki Sense", "DeCharge" },
        interruptedBy = { "Stunned", "Knocked", "Dead", "Grabbed" }
    },
    Stunned = {
        priority = 60,
        category = "disabled",
        allowedActions = { "Evade" },
        interruptedBy = { "Knocked", "Dead", "Grabbed" }
    },
    TempKnock = {
        priority = 65,
        category = "disabled",
        allowedActions = {},
        interruptedBy = { "Knocked", "Dead" }
    },
    Knocked = {
        priority = 70,
        category = "disabled",
        allowedActions = { "Evade", "Ragdoll Cancel" },
        interruptedBy = { "Dead", "KO", "Knockback" }
    },
    InAir = {
        priority = 65,
        category = "disabled",
        allowedActions = { "Evade", "Light", "Heavy", "Dash", "Ki Blast", "Swing", "Dash Light", "Dash Swing", "Dash Suspend", "Follow Up", "Skill" },
        interruptedBy = { "Dead", "UsingSkill", "IFrame", "FlyBoost" }
    },
    EvadeCancel = {
        priority = 60,
        category = "disabled",
        allowedActions = {},
        interruptedBy = { "Dead" }
    },
    GettingGripped = {
        priority = 72,
        category = "disabled",
        allowedActions = {},
        interruptedBy = { "Dead" }
    },
    GettingCarried = {
        priority = 72,
        category = "disabled",
        allowedActions = {},
        interruptedBy = { "Dead" }
    },
    Absorbed = {
        priority = 72,
        category = "disabled",
        allowedActions = {},
        interruptedBy = { "Dead" }
    },
    Barrier = {
        priority = 6,
        category = "combat",
        allowedActions = { "*" },
        blockedActions = { "Light", "Heavy", "Swing", "Dash Swing", "Dash Light", "Ki Blast", "Grip", "Carry", "Follow Up", "Skill" },
        interruptedBy = { "*" }
    },
    Stuck = {
        priority = 65,
        category = "disabled",
        allowedActions = {},
        interruptedBy = { "Dead", "Knocked", "Stunned" }
    },
    WallSlammed = {
        priority = 70,
        category = "disabled",
        allowedActions = {},
        interruptedBy = { "Dead" }
    },
    Knockback = {
        priority = 68,
        category = "disabled",
        allowedActions = { "Ragdoll Cancel" },
        interruptedBy = { "Dead", "Knocked", "KO", "WallSlammed", "GettingGripped", "GettingCarried" }
    },
    Swimming = {
        priority = 5,
        category = "movement",
        allowedActions = { "*" },
        blockedActions = { "Fly", "Flight/Climb", "Run" },
        interruptedBy = { "*" }
    },
    Clashing = {
        priority = 80,
        category = "disabled",
        allowedActions = {},
        interruptedBy = { "Dead" }
    },
    BeamClashing = {
        priority = 80,
        category = "disabled",
        allowedActions = {},
        interruptedBy = { "Dead" }
    },
    Running = {
        priority = 5,
        category = "movement",
        allowedActions = { "*" },
        interruptedBy = { "Stunned", "Knocked", "KnockedBack", "Dead", "Grabbed", "GettingCarried", "GettingGripped", "WallSlammed", "Clashing", "Transforming", "KO" }
    },
    ForwardDashing = {
        priority = 66,
        category = "passive",
        duration = 1,
        allowedActions = { "*" },
        blockedActions = { "Ki Blast", "Run" },
        interruptedBy = { "*" }
    },
    Flying = {
        priority = 10,
        category = "movement",
        allowedActions = { "*" },
        interruptedBy = { "*" }
    },
    Climbing = {
        priority = 20,
        category = "movement",
        allowedActions = { "Jump", "Evade" },
        interruptedBy = { "Stunned", "Knocked", "Dead" }
    },
    Ascending = {
        priority = 30,
        category = "movement",
        allowedActions = { "Ki Sense" },
        interruptedBy = { "Stunned", "Knocked", "Dead" }
    },
    IFrame = {
        priority = 10,
        category = "passive",
        allowedActions = { "*" },
        interruptedBy = { "*" }
    },
    Punching = {
        priority = 10,
        category = "passive",
        allowedActions = { "*" },
        interruptedBy = { "*" }
    },
    HeavySwing = {
        priority = 10,
        category = "passive",
        allowedActions = { "*" },
        interruptedBy = { "*" }
    },
    UI = {
        priority = 10,
        category = "passive",
        allowedActions = { "*" },
        interruptedBy = { "*" }
    },
    LightSwing = {
        priority = 10,
        category = "passive",
        allowedActions = { "*" },
        interruptedBy = { "*" }
    },
    ChainAttacking = {
        priority = 40,
        category = "action",
        allowedActions = { "Follow Up", "Evade" },
        interruptedBy = { "Stunned", "Knocked", "Dead" }
    },
    SuperArmor = {
        priority = 10,
        category = "passive",
        allowedActions = { "*" },
        interruptedBy = { "*" }
    },
    HyperArmor = {
        priority = 10,
        category = "passive",
        allowedActions = { "*" },
        interruptedBy = { "*" }
    },
    Emoting = {
        priority = 15,
        category = "passive",
        allowedActions = { "Ki Sense" },
        interruptedBy = { "Stunned", "Knocked", "Dead", "Attacking" }
    },
    Meditating = {
        priority = 20,
        category = "passive",
        allowedActions = { "Ki Sense", "Meditate" },
        interruptedBy = { "Stunned", "Knocked", "Dead", "Attacking" }
    },
    Sleeping = {
        priority = 20,
        category = "passive",
        allowedActions = { "Sleep" },
        interruptedBy = { "Stunned", "Knocked", "Dead", "Attacking" }
    },
    DeepSleep = {
        priority = 20,
        category = "passive",
        allowedActions = { "Sleep" },
        interruptedBy = { "Stunned", "Knocked", "Dead", "Attacking" }
    },
    KO = {
        priority = 70,
        category = "disabled",
        allowedActions = {},
        interruptedBy = { "Dead", "Knocked" }
    },
    Training = {
        priority = 15,
        category = "passive",
        allowedActions = { "Ki Sense" },
        interruptedBy = { "Stunned", "Knocked", "Dead" }
    },
    Eating = {
        priority = 20,
        category = "passive",
        allowedActions = {},
        interruptedBy = { "Stunned", "Knocked", "Dead", "Attacking" }
    },
    UsingItem = {
        priority = 20,
        category = "passive",
        allowedActions = { "Evade" },
        interruptedBy = { "Stunned", "Knocked", "Dead", "Attacking" }
    },
    KiSensing = {
        priority = 20,
        category = "passive",
        allowedActions = { "*" },
        interruptedBy = { "*" }
    },
    FlyBoost = {
        priority = 20,
        category = "passive",
        allowedActions = { "*" },
        interruptedBy = { "*" },

        onExit = function(p6) -- Line: 783, Name: onExit
            if not game:GetService("RunService"):IsServer() then
                return;
            end;

            if p6 then
                p6 = p6:FindFirstChild("FlyBoost");
            end;

            if p6 then
                p6:Destroy();
            end;
        end
    },
    InCombat = {
        priority = 20,
        category = "passive",
        allowedActions = { "*" },
        interruptedBy = { "*" }
    },
    GankBuff = {
        priority = 10,
        category = "passive",
        duration = 20,
        allowedActions = { "*" },
        interruptedBy = { "Dead" }
    },
    IndomitableSpirit = {
        priority = 10,
        category = "passive",
        allowedActions = { "*" },
        interruptedBy = { "*" }
    },
    Transforming = {
        priority = 55,
        category = "form",
        allowedActions = {},
        interruptedBy = { "Dead" }
    },
    Kaioken = {
        priority = 10,
        category = "subForm",
        allowedActions = { "*" },
        interruptedBy = { "*" }
    },
    KiBurst = {
        priority = 10,
        category = "subForm",
        allowedActions = { "*" },
        interruptedBy = { "*" }
    },
    UltraInstinct = {
        priority = 10,
        category = "mainForm",
        allowedActions = { "*" },
        interruptedBy = { "*" }
    },
    SSJ = {
        priority = 10,
        category = "mainForm",
        allowedActions = { "*" },
        interruptedBy = { "*" }
    },
    SSJ2 = {
        priority = 10,
        category = "mainForm",
        allowedActions = { "*" },
        interruptedBy = { "*" }
    },
    SSJ3 = {
        priority = 10,
        category = "mainForm",
        allowedActions = { "*" },
        interruptedBy = { "*" }
    },
    SSJ4 = {
        priority = 10,
        category = "mainForm",
        allowedActions = { "*" },
        interruptedBy = { "*" }
    },
    Ikari = {
        priority = 10,
        category = "mainForm",
        allowedActions = { "*" },
        interruptedBy = { "*" }
    },
    LSSJ = {
        priority = 10,
        category = "mainForm",
        allowedActions = { "*" },
        interruptedBy = { "*" }
    },
    BerserkApe = {
        priority = 45,
        category = "form",
        allowedActions = {},
        interruptedBy = { "Dead" }
    },
    GreatApe = {
        priority = 10,
        category = "mainForm",
        allowedActions = { "*" },
        blockedActions = { "Transform", "DeTransform" },
        interruptedBy = { "*" }
    },
    SecondForm = {
        priority = 10,
        category = "mainForm",
        allowedActions = { "*" },
        interruptedBy = { "*" }
    },
    ThirdForm = {
        priority = 10,
        category = "mainForm",
        allowedActions = { "*" },
        interruptedBy = { "*" }
    },
    FourthForm = {
        priority = 10,
        category = "mainForm",
        allowedActions = { "*" },
        interruptedBy = { "*" }
    },
    FifthForm = {
        priority = 10,
        category = "mainForm",
        allowedActions = { "*" },
        interruptedBy = { "*" }
    },
    BuffBody = {
        priority = 10,
        category = "mainForm",
        allowedActions = { "*" },
        interruptedBy = { "*" }
    },
    Mystic = {
        priority = 10,
        category = "mainForm",
        allowedActions = { "*" },
        interruptedBy = { "*" }
    },
    V16 = {
        priority = 10,
        category = "mainForm",
        allowedActions = { "*" },
        interruptedBy = { "*" }
    },
    GiantNamekian = {
        priority = 10,
        category = "mainForm",
        allowedActions = { "*" },
        interruptedBy = { "*" }
    },
    SuperNamekian = {
        priority = 10,
        category = "mainForm",
        allowedActions = { "*" },
        interruptedBy = { "*" }
    },
    MajinRage = {
        priority = 10,
        category = "mainForm",
        allowedActions = { "*" },
        interruptedBy = { "*" }
    },
    SuperBuu = {
        priority = 10,
        category = "mainForm",
        allowedActions = { "*" },
        interruptedBy = { "*" }
    },
    Janemba = {
        priority = 10,
        category = "mainForm",
        allowedActions = { "*" },
        blockedActions = { "Heavy", "Grab", "Evade", "Dash", "Ki Blast", "Charge", "DeCharge", "Block", "Fly", "Flight/Climb", "Grip", "Carry", "Follow Up", "Skill", "Eat", "Read", "Training" },
        interruptedBy = { "*" }
    },
    HeraFullPower = {
        priority = 10,
        category = "mainForm",
        allowedActions = { "*" },
        interruptedBy = { "*" }
    },
    DemonicWill = {
        priority = 10,
        category = "mainForm",
        allowedActions = { "*" },
        interruptedBy = { "*" }
    },
    SuperJanemba = {
        priority = 10,
        category = "mainForm",
        allowedActions = { "*" },
        interruptedBy = { "*" }
    },
    SemiPerfect = {
        priority = 10,
        category = "mainForm",
        allowedActions = { "*" },
        interruptedBy = { "*" }
    },
    PerfectForm = {
        priority = 10,
        category = "mainForm",
        allowedActions = { "*" },
        interruptedBy = { "*" }
    },
    SuperPerfect = {
        priority = 10,
        category = "subForm",
        allowedActions = { "*" },
        interruptedBy = { "*" }
    },
    Dead = {
        priority = 100,
        category = "terminal",
        allowedActions = {},
        interruptedBy = {}
    }
};