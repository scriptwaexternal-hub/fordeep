-- Decompiled with Potassium's decompiler.

local UserInputService = game:GetService("UserInputService");
local ContentProvider = game:GetService("ContentProvider");
local StarterGui = game:GetService("StarterGui");
local Players = game:GetService("Players");
require(script.Types);
local u1 = script;
local Reference = require(u1.Reference);
local Object = Reference.getObject();
local v2;

if Object then
    v2 = Object.Value;
else
    v2 = Object;
end;

if v2 and v2 ~= u1 then
    return require(v2);
end;

if not Object then
    Reference.addToReplicatedStorage();
end;

local GoodSignal = require(u1.Packages.GoodSignal);
local Janitor = require(u1.Packages.Janitor);
local Utility = require(u1.Utility);
local Themes = require(u1.Features.Themes);
local Gamepad = require(u1.Features.Gamepad);
local Overflow = require(u1.Features.Overflow);
local u3 = {};
u3.__index = u3;
local LocalPlayer = Players.LocalPlayer;
local Themes2 = u1.Features.Themes;
local u4 = {};
local u5 = GoodSignal.new();
local Elements = u1.Elements;
local u6 = 0;
u3.baseDisplayOrderChanged = GoodSignal.new();
u3.baseDisplayOrder = 10;
u3.baseTheme = require(Themes2.Default);
u3.isOldTopbar = false;
u3.iconsDictionary = u4;
u3.insetHeightChanged = GoodSignal.new();
u3.container = require(Elements.Container)(u3);
u3.topbarEnabled = true;
u3.iconAdded = GoodSignal.new();
u3.iconRemoved = GoodSignal.new();
u3.iconChanged = GoodSignal.new();

function u3.getIcons() -- Line: 105
    -- upvalues: u3 (copy)
    return u3.iconsDictionary;
end;

function u3.getIconByUID(p7) -- Line: 109
    -- upvalues: u3 (copy)
    return u3.iconsDictionary[p7] or nil;
end;

function u3.getIcon(p8) -- Line: 117
    -- upvalues: u3 (copy), u4 (copy)
    local IconByUID = u3.getIconByUID(p8);

    if IconByUID then
        return IconByUID;
    end;

    for _, v in pairs(u4) do
        if v.name == p8 then
            return v;
        end;
    end;

    return nil;
end;

function u3.setTopbarEnabled(p9, p10) -- Line: 130
    -- upvalues: u3 (copy)
    if typeof(p9) ~= "boolean" then
        p9 = u3.topbarEnabled;
    end;

    if not p10 then
        u3.topbarEnabled = p9;
    end;

    for _, v in pairs(u3.container) do
        v.Enabled = p9;
    end;
end;

function u3.modifyBaseTheme(p11) -- Line: 142
    -- upvalues: Themes (copy), u3 (copy), u4 (copy)
    local Modifications = Themes.getModifications(p11);

    for _, v in pairs(Modifications) do
        local v12 = v;

        for _, v3 in pairs(u3.baseTheme) do
            Themes.merge(v3, v12);
        end;
    end;

    for _, v in pairs(u4) do
        v:setTheme(u3.baseTheme);
    end;
end;

function u3.setDisplayOrder(p13) -- Line: 154
    -- upvalues: u3 (copy)
    u3.baseDisplayOrder = p13;
    u3.baseDisplayOrderChanged:Fire(p13);
end;

task.defer(Gamepad.start, u3);
task.defer(Overflow.start, u3);
task.defer(function() -- Line: 164
    -- upvalues: LocalPlayer (copy), u3 (copy), u1 (copy)
    local PlayerGui = LocalPlayer:WaitForChild("PlayerGui");

    for _, v in pairs(u3.container) do
        v.Parent = PlayerGui;
    end;

    require(u1.Attribute);
end);

function u3.new() -- Line: 175
    -- upvalues: u3 (copy), Janitor (copy), Utility (copy), u4 (copy), GoodSignal (copy), u1 (copy), Elements (copy), u6 (ref), UserInputService (copy), u5 (copy), StarterGui (copy)
    local u14 = {};
    setmetatable(u14, u3);
    local v15 = Janitor.new();
    u14.janitor = v15;
    u14.themesJanitor = v15:add(Janitor.new());
    u14.singleClickJanitor = v15:add(Janitor.new());
    u14.captionJanitor = v15:add(Janitor.new());
    u14.joinJanitor = v15:add(Janitor.new());
    u14.menuJanitor = v15:add(Janitor.new());
    u14.dropdownJanitor = v15:add(Janitor.new());
    local u16 = Utility.generateUID();
    u4[u16] = u14;
    v15:add(function() -- Line: 192
        -- upvalues: u4 (ref), u16 (copy)
        u4[u16] = nil;
    end);
    u14.selected = v15:add(GoodSignal.new());
    u14.deselected = v15:add(GoodSignal.new());
    u14.toggled = v15:add(GoodSignal.new());
    u14.viewingStarted = v15:add(GoodSignal.new());
    u14.viewingEnded = v15:add(GoodSignal.new());
    u14.stateChanged = v15:add(GoodSignal.new());
    u14.notified = v15:add(GoodSignal.new());
    u14.noticeStarted = v15:add(GoodSignal.new());
    u14.noticeChanged = v15:add(GoodSignal.new());
    u14.endNotices = v15:add(GoodSignal.new());
    u14.toggleKeyAdded = v15:add(GoodSignal.new());
    u14.fakeToggleKeyChanged = v15:add(GoodSignal.new());
    u14.alignmentChanged = v15:add(GoodSignal.new());
    u14.updateSize = v15:add(GoodSignal.new());
    u14.resizingComplete = v15:add(GoodSignal.new());
    u14.joinedParent = v15:add(GoodSignal.new());
    u14.menuSet = v15:add(GoodSignal.new());
    u14.dropdownSet = v15:add(GoodSignal.new());
    u14.updateMenu = v15:add(GoodSignal.new());
    u14.startMenuUpdate = v15:add(GoodSignal.new());
    u14.childThemeModified = v15:add(GoodSignal.new());
    u14.indicatorSet = v15:add(GoodSignal.new());
    u14.dropdownChildAdded = v15:add(GoodSignal.new());
    u14.menuChildAdded = v15:add(GoodSignal.new());
    u14.iconModule = u1;
    u14.UID = u16;
    u14.isEnabled = true;
    u14.enabled = u14.isEnabled;
    u14.isSelected = false;
    u14.isViewing = false;
    u14.joinedFrame = false;
    u14.parentIconUID = false;
    u14.deselectWhenOtherIconSelected = true;
    u14.totalNotices = 0;
    u14.activeState = "Deselected";
    u14.alignment = "";
    u14.originalAlignment = "";
    u14.appliedTheme = {};
    u14.appearance = {};
    u14.cachedInstances = {};
    u14.cachedNamesToInstances = {};
    u14.cachedCollectives = {};
    u14.bindedToggleKeys = {};
    u14.customBehaviours = {};
    u14.toggleItems = {};
    u14.bindedEvents = {};
    u14.notices = {};
    u14.menuIcons = {};
    u14.dropdownIcons = {};
    u14.childIconsDict = {};
    u14.creationTime = os.clock();
    u14.widget = v15:add(require(Elements.Widget)(u14, u3));
    u14:setAlignment();
    u6 = u6 + 1;
    local v17 = u6 * 0.01 + 1;
    u14:setOrder(v17, "deselected");
    u14:setOrder(v17, "selected");
    u14:setTheme(u3.baseTheme);
    local Instance = u14:getInstance("ClickRegion");

    local function handleToggle() -- Line: 268
        -- upvalues: u14 (copy)
        if u14.locked then
            return;
        end;

        if u14.isSelected then
            u14:deselect("User", u14);

            return;
        end;

        u14:select("User", u14);
    end;

    local u18 = false;
    local u19 = false;
    Instance.MouseButton1Click:Connect(function() -- Line: 280
        -- upvalues: u18 (ref), u19 (ref), u14 (copy)
        if u18 then
            return;
        end;

        u19 = true;
        task.delay(0.01, function() -- Line: 285
            -- upvalues: u19 (ref)
            u19 = false;
        end);

        if u14.locked then
            return;
        end;

        if u14.isSelected then
            u14:deselect("User", u14);

            return;
        end;

        u14:select("User", u14);
    end);
    Instance.TouchTap:Connect(function() -- Line: 290
        -- upvalues: u19 (ref), u18 (ref), u14 (copy)
        if u19 then
            return;
        end;

        u18 = true;
        task.delay(0.01, function() -- Line: 297
            -- upvalues: u18 (ref)
            u18 = false;
        end);

        if u14.locked then
            return;
        end;

        if u14.isSelected then
            u14:deselect("User", u14);

            return;
        end;

        u14:select("User", u14);
    end);
    v15:add(UserInputService.InputBegan:Connect(function(p20, p21) -- Line: 304
        -- upvalues: u14 (copy)
        if u14.locked then
            return;
        end;

        if u14.bindedToggleKeys[p20.KeyCode] and not p21 then
            if u14.locked then
                return;
            end;

            if u14.isSelected then
                u14:deselect("User", u14);

                return;
            end;

            u14:select("User", u14);
        end;
    end));

    local function viewingEnded() -- Line: 326
        -- upvalues: u14 (copy)
        if u14.locked then
            return;
        end;

        u14.isViewing = false;
        u14.viewingEnded:Fire(true);
        u14:setState(nil, "User", u14);
    end;

    u14.joinedParent:Connect(function() -- Line: 334
        -- upvalues: u14 (copy)
        if u14.isViewing then
            if u14.locked then
                return;
            end;

            u14.isViewing = false;
            u14.viewingEnded:Fire(true);
            u14:setState(nil, "User", u14);
        end;
    end);
    Instance.MouseEnter:Connect(function() -- Line: 339
        -- upvalues: UserInputService (ref), u14 (copy)
        local v22 = not UserInputService.KeyboardEnabled;

        if u14.locked then
            return;
        end;

        u14.isViewing = true;
        u14.viewingStarted:Fire(true);

        if not v22 then
            u14:setState("Viewing", "User", u14);
        end;
    end);
    local u23 = 0;
    v15:add(UserInputService.TouchEnded:Connect(viewingEnded));
    Instance.MouseLeave:Connect(viewingEnded);
    Instance.SelectionGained:Connect(function(p24) -- Line: 316, Name: viewingStarted
        -- upvalues: u14 (copy)
        if u14.locked then
            return;
        end;

        u14.isViewing = true;
        u14.viewingStarted:Fire(true);

        if not p24 then
            u14:setState("Viewing", "User", u14);
        end;
    end);
    Instance.SelectionLost:Connect(viewingEnded);
    Instance.MouseButton1Down:Connect(function() -- Line: 348
        -- upvalues: u14 (copy), UserInputService (ref), u23 (ref)
        if not u14.locked and UserInputService.TouchEnabled then
            u23 = u23 + 1;
            local u25 = u23;
            task.delay(0.2, function() -- Line: 352
                -- upvalues: u25 (copy), u23 (ref), u14 (ref)
                if u25 == u23 then
                    if u14.locked then
                        return;
                    end;

                    u14.isViewing = true;
                    u14.viewingStarted:Fire(true);
                    u14:setState("Viewing", "User", u14);
                end;
            end);
        end;
    end);
    Instance.MouseButton1Up:Connect(function() -- Line: 359
        -- upvalues: u23 (ref)
        u23 = u23 + 1;
    end);
    local Instance2 = u14:getInstance("IconOverlay");
    u14.viewingStarted:Connect(function() -- Line: 365
        -- upvalues: Instance2 (copy), u14 (copy)
        Instance2.Visible = not u14.overlayDisabled;
    end);
    u14.viewingEnded:Connect(function() -- Line: 368
        -- upvalues: Instance2 (copy)
        Instance2.Visible = false;
    end);
    v15:add(u5:Connect(function(p26) -- Line: 373
        -- upvalues: u14 (copy)
        if p26 ~= u14 and (u14.deselectWhenOtherIconSelected and p26.deselectWhenOtherIconSelected) then
            u14:deselect("AutoDeselect", p26);
        end;
    end));
    local debug_info_ret = debug.info(2, "s");
    local string_split_ret = string.split(debug_info_ret, ".");
    local v27 = game;
    local v28 = nil;

    for _, v in pairs(string_split_ret) do
        v27 = v27:FindFirstChild(v);

        if not v27 then
            break;
        end;

        if v27:IsA("ScreenGui") then
            v28 = v27;
        end;
    end;

    if v27 and (v28 and v28.ResetOnSpawn == true) then
        u14.originsScreenGui = v28;
        Utility.localPlayerRespawned(function() -- Line: 399
            -- upvalues: u14 (copy)
            u14:destroy();
        end);
    end;

    u14.toggled:Connect(function(p29) -- Line: 405
        -- upvalues: u14 (copy), u3 (ref)
        u14.noticeChanged:Fire(u14.totalNotices);

        for i, _ in pairs(u14.childIconsDict) do
            local IconByUID = u3.getIconByUID(i);
            IconByUID.noticeChanged:Fire(IconByUID.totalNotices);

            if not p29 and IconByUID.isSelected then
                for _, _ in pairs(IconByUID.childIconsDict) do
                    IconByUID:deselect("HideParentFeature", u14);
                end;
            end;
        end;
    end);
    u14.selected:Connect(function() -- Line: 428
        -- upvalues: u14 (copy), StarterGui (ref)
        if #u14.dropdownIcons > 0 then
            if StarterGui:GetCore("ChatActive") and u14.alignment ~= "Right" then
                u14.chatWasPreviouslyActive = true;
                StarterGui:SetCore("ChatActive", false);
            end;

            if StarterGui:GetCoreGuiEnabled("PlayerList") and u14.alignment ~= "Left" then
                u14.playerlistWasPreviouslyActive = true;
                StarterGui:SetCoreGuiEnabled(Enum.CoreGuiType.PlayerList, false);
            end;
        end;
    end);
    u14.deselected:Connect(function() -- Line: 441
        -- upvalues: u14 (copy), StarterGui (ref)
        if u14.chatWasPreviouslyActive then
            u14.chatWasPreviouslyActive = nil;
            StarterGui:SetCore("ChatActive", true);
        end;

        if u14.playerlistWasPreviouslyActive then
            u14.playerlistWasPreviouslyActive = nil;
            StarterGui:SetCoreGuiEnabled(Enum.CoreGuiType.PlayerList, true);
        end;
    end);
    task.delay(0.1, function() -- Line: 455
        -- upvalues: u14 (copy)
        if u14.activeState == "Deselected" then
            u14.stateChanged:Fire("Deselected");
            u14:refresh();
        end;
    end);
    u3.iconAdded:Fire(u14);

    return u14;
end;

function u3.setName(p30, p31) -- Line: 471
    p30.widget.Name = p31;
    p30.name = p31;

    return p30;
end;

function u3.setState(p32, p33, p34, p35) -- Line: 477
    -- upvalues: Utility (copy), u5 (copy)
    local v36 = Utility.formatStateName(p33 or (p32.isSelected and "Selected" or "Deselected"));

    if p32.activeState == v36 then
        return;
    end;

    local isSelected = p32.isSelected;
    p32.activeState = v36;

    if v36 == "Deselected" then
        p32.isSelected = false;

        if isSelected then
            p32.toggled:Fire(false, p34, p35);
            p32.deselected:Fire(p34, p35);
        end;

        p32:_setToggleItemsVisible(false, p34, p35);
    elseif v36 == "Selected" then
        p32.isSelected = true;

        if not isSelected then
            p32.toggled:Fire(true, p34, p35);
            p32.selected:Fire(p34, p35);
            u5:Fire(p32, p34, p35);
        end;

        p32:_setToggleItemsVisible(true, p34, p35);
    end;

    p32.stateChanged:Fire(v36, p34, p35);
end;

function u3.getInstance(u37, u38) -- Line: 510
    -- upvalues: Themes (copy)
    local v39 = u37.cachedNamesToInstances[u38];

    if v39 then
        return v39;
    end;

    local function cacheInstance(u40, u41) -- Line: 518
        -- upvalues: u37 (copy)
        if not u37.cachedInstances[u41] then
            local Attribute = u41:GetAttribute("Collective");

            if Attribute then
                Attribute = u37.cachedCollectives[Attribute];
            end;

            if Attribute then
                table.insert(Attribute, u41);
            end;

            u37.cachedNamesToInstances[u40] = u41;
            u37.cachedInstances[u41] = true;
            u41.Destroying:Once(function() -- Line: 528
                -- upvalues: u37 (ref), u40 (copy), u41 (copy)
                u37.cachedNamesToInstances[u40] = nil;
                u37.cachedInstances[u41] = nil;
            end);
        end;
    end;

    local widget = u37.widget;
    cacheInstance("Widget", widget);

    if u38 == "Widget" then
        return widget;
    end;

    local u42 = nil;

    local function scanChildren(p43) -- Line: 541
        -- upvalues: u37 (copy), Themes (ref), scanChildren (copy), cacheInstance (copy), u38 (copy), u42 (ref)
        for _, child in pairs(p43:GetChildren()) do
            local Attribute = child:GetAttribute("WidgetUID");

            if not Attribute or Attribute == u37.UID then
                local v44 = Themes.getRealInstance(child) or child;
                scanChildren(v44);

                if v44:IsA("GuiBase") or (v44:IsA("UIBase") or v44:IsA("ValueBase")) then
                    local Name = v44.Name;
                    cacheInstance(Name, v44);

                    if Name == u38 then
                        u42 = v44;
                    end;
                end;
            end;
        end;
    end;

    scanChildren(widget);

    return u42;
end;

function u3.getCollective(p45, p46) -- Line: 570
    local v47 = p45.cachedCollectives[p46];

    if v47 then
        return v47;
    end;

    local v48 = {};

    for i, _ in pairs(p45.cachedInstances) do
        if i:GetAttribute("Collective") == p46 then
            table.insert(v48, i);
        end;
    end;

    p45.cachedCollectives[p46] = v48;

    return v48;
end;

function u3.getInstanceOrCollective(p49, p50) -- Line: 591
    local v51 = {};
    local Instance = p49:getInstance(p50);

    if Instance then
        table.insert(v51, Instance);
    end;

    if #v51 == 0 then
        v51 = p49:getCollective(p50);
    end;

    return v51;
end;

function u3.getStateGroup(p52, p53) -- Line: 605
    local v54 = p53 or p52.activeState;
    local v55 = p52.appearance[v54];

    if not v55 then
        v55 = {};
        p52.appearance[v54] = v55;
    end;

    return v55;
end;

function u3.refreshAppearance(p56, p57, p58) -- Line: 615
    -- upvalues: Themes (copy)
    Themes.refresh(p56, p57, p58);

    return p56;
end;

function u3.refresh(p59) -- Line: 620
    p59:refreshAppearance(p59.widget);
    p59.updateSize:Fire();

    return p59;
end;

function u3.updateParent(p60) -- Line: 626
    -- upvalues: u3 (copy)
    local IconByUID = u3.getIconByUID(p60.parentIconUID);

    if IconByUID then
        IconByUID.updateSize:Fire();
    end;
end;

function u3.setBehaviour(p61, p62, p63, p64, p65) -- Line: 633
    p61.customBehaviours[p62 .. "-" .. p63] = p64;

    if p65 then
        local InstanceOrCollective = p61:getInstanceOrCollective(p62);

        for _, v in pairs(InstanceOrCollective) do
            p61:refreshAppearance(v, p63);
        end;
    end;
end;

function u3.modifyTheme(p66, p67, p68) -- Line: 646
    -- upvalues: Themes (copy)
    return p66, Themes.modify(p66, p67, p68);
end;

function u3.modifyChildTheme(p69, p70, p71) -- Line: 651
    -- upvalues: u3 (copy)
    p69.childModifications = p70;
    p69.childModificationsUID = p71;

    for i, _ in pairs(p69.childIconsDict) do
        u3.getIconByUID(i):modifyTheme(p70, p71);
    end;

    p69.childThemeModified:Fire();

    return p69;
end;

function u3.removeModification(p72, p73) -- Line: 664
    -- upvalues: Themes (copy)
    Themes.remove(p72, p73);

    return p72;
end;

function u3.removeModificationWith(p74, p75, p76, p77) -- Line: 669
    -- upvalues: Themes (copy)
    Themes.removeWith(p74, p75, p76, p77);

    return p74;
end;

function u3.setTheme(p78, p79) -- Line: 674
    -- upvalues: Themes (copy)
    Themes.set(p78, p79);

    return p78;
end;

function u3.setEnabled(p80, p81) -- Line: 679
    p80.isEnabled = p81;
    p80.enabled = p80.isEnabled;
    p80.widget.Visible = p81;
    p80:updateParent();

    return p80;
end;

function u3.select(p82, p83, p84) -- Line: 687
    p82:setState("Selected", p83, p84);

    return p82;
end;

function u3.deselect(p85, p86, p87) -- Line: 692
    p85:setState("Deselected", p86, p87);

    return p85;
end;

function u3.notify(p88, p89, p90) -- Line: 697
    -- upvalues: Elements (copy), u3 (copy)
    if not p88.notice then
        p88.notice = require(Elements.Notice)(p88, u3);
    end;

    p88.noticeStarted:Fire(p89, p90);

    return p88;
end;

function u3.clearNotices(p91) -- Line: 711
    p91.endNotices:Fire();

    return p91;
end;

function u3.disableOverlay(p92, p93) -- Line: 716
    p92.overlayDisabled = p93;

    return p92;
end;

u3.disableStateOverlay = u3.disableOverlay;

function u3.setImage(p94, u95, p96) -- Line: 722
    -- upvalues: ContentProvider (copy)
    p94:modifyTheme({
        "IconImage",
        "Image",
        u95,
        p96
    });
    task.spawn(function() -- Line: 726
        -- upvalues: u95 (copy), ContentProvider (ref)
        local v97;

        if tonumber(u95) then
            v97 = `rbxassetid://{u95}`;
        else
            v97 = u95;
        end;

        if ContentProvider:GetAssetFetchStatus(v97) ~= Enum.AssetFetchStatus.Success then
            pcall(ContentProvider.PreloadAsync, ContentProvider, { v97 });
        end;
    end);

    return p94;
end;

function u3.setLabel(p98, p99, p100) -- Line: 738
    p98:modifyTheme({
        "IconLabel",
        "Text",
        p99,
        p100
    });

    return p98;
end;

function u3.setOrder(p101, p102, p103) -- Line: 743
    local v104 = p102 * 100;
    p101:modifyTheme({
        "IconSpot",
        "LayoutOrder",
        v104,
        p103
    });
    p101:modifyTheme({
        "Widget",
        "LayoutOrder",
        v104,
        p103
    });

    return p101;
end;

function u3.setCornerRadius(p105, p106, p107) -- Line: 752
    p105:modifyTheme({
        "IconCorners",
        "CornerRadius",
        p106,
        p107
    });

    return p105;
end;

function u3.align(p108, p109, p110) -- Line: 757
    -- upvalues: u3 (copy)
    local v111 = tostring(p109):lower();
    local v112 = (v111 == "mid" or v111 == "centre") and "center" or v111;
    local v113 = v112 ~= "left" and (v112 ~= "center" and v112 ~= "right") and "left" or v112;
    local v114 = v113 == "center" and u3.container.TopbarCentered or u3.container.TopbarStandard;
    local Holders = v114.Holders;
    local v115 = string.upper((string.sub(v113, 1, 1))) .. string.sub(v113, 2);

    if not p110 then
        p108.originalAlignment = v115;
    end;

    local joinedFrame = p108.joinedFrame;
    local v116 = Holders[v115];
    p108.screenGui = v114;
    p108.alignmentHolder = v116;

    if not p108.isDestroyed then
        p108.widget.Parent = joinedFrame or v116;
    end;

    p108.alignment = v115;
    p108.alignmentChanged:Fire(v115);
    u3.iconChanged:Fire(p108);

    return p108;
end;

u3.setAlignment = u3.align;

function u3.setLeft(p117) -- Line: 786
    p117:setAlignment("Left");

    return p117;
end;

function u3.setMid(p118) -- Line: 791
    p118:setAlignment("Center");

    return p118;
end;

function u3.setRight(p119) -- Line: 796
    p119:setAlignment("Right");

    return p119;
end;

function u3.setWidth(p120, p121, p122) -- Line: 801
    p120:modifyTheme({
        "Widget",
        "DesiredWidth",
        p121,
        p122
    });

    return p120;
end;

function u3.setImageScale(p123, p124, p125) -- Line: 809
    p123:modifyTheme({
        "IconImageScale",
        "Value",
        p124,
        p125
    });

    return p123;
end;

function u3.setImageRatio(p126, p127, p128) -- Line: 814
    p126:modifyTheme({
        "IconImageRatio",
        "AspectRatio",
        p127,
        p128
    });

    return p126;
end;

function u3.setTextSize(p129, p130, p131) -- Line: 819
    p129:modifyTheme({
        "IconLabel",
        "TextSize",
        p130,
        p131
    });

    return p129;
end;

function u3.setTextFont(p132, p133, p134, p135, p136) -- Line: 824
    local v137 = p134 or Enum.FontWeight.Regular;
    local v138 = p135 or Enum.FontStyle.Normal;
    local v139 = nil;
    local v140 = typeof(p133);

    if v140 == "number" then
        v139 = Font.fromId(p133, v137, v138);
    elseif v140 == "EnumItem" then
        v139 = Font.fromEnum(p133);
    elseif v140 == "string" and not p133:match("rbxasset") then
        v139 = Font.fromName(p133, v137, v138);
    end;

    p132:modifyTheme({
        "IconLabel",
        "FontFace",
        v139 or Font.new(p133, v137, v138),
        p136
    });

    return p132;
end;

function u3.bindToggleItem(p141, p142) -- Line: 845
    if not (p142:IsA("GuiObject") or p142:IsA("LayerCollector")) then
        error("Toggle item must be a GuiObject or LayerCollector!");
    end;

    p141.toggleItems[p142] = true;
    p141:_updateSelectionInstances();

    return p141;
end;

function u3.unbindToggleItem(p143, p144) -- Line: 854
    p143.toggleItems[p144] = nil;
    p143:_updateSelectionInstances();

    return p143;
end;

function u3._updateSelectionInstances(p145) -- Line: 860
    for i, _ in pairs(p145.toggleItems) do
        local v146 = {};

        for _, descendant in pairs(i:GetDescendants()) do
            if (descendant:IsA("TextButton") or descendant:IsA("ImageButton")) and descendant.Active then
                table.insert(v146, descendant);
            end;
        end;

        p145.toggleItems[i] = v146;
    end;
end;

function u3._setToggleItemsVisible(p147, p148, p149, p150) -- Line: 874
    for i, _ in pairs(p147.toggleItems) do
        if not (p150 and (p150 ~= p147 and p150.toggleItems[i] ~= nil)) then
            i[i:IsA("LayerCollector") and "Enabled" or "Visible"] = p148;
        end;
    end;
end;

function u3.bindEvent(u151, p152, u153) -- Line: 886
    local v154 = u151[p152];
    local v155;

    if v154 then
        if typeof(v154) == "table" then
            v155 = v154.Connect;
        else
            v155 = false;
        end;
    else
        v155 = v154;
    end;

    assert(v155, "argument[1] must be a valid topbarplus icon event name!");
    local v156 = typeof(u153) == "function";
    assert(v156, "argument[2] must be a function!");
    u151.bindedEvents[p152] = v154:Connect(function(...) -- Line: 890
        -- upvalues: u153 (copy), u151 (copy)
        u153(u151, ...);
    end);

    return u151;
end;

function u3.unbindEvent(p157, p158) -- Line: 896
    local v159 = p157.bindedEvents[p158];

    if v159 then
        v159:Disconnect();
        p157.bindedEvents[p158] = nil;
    end;

    return p157;
end;

function u3.bindToggleKey(p160, p161) -- Line: 905
    local v162 = typeof(p161) == "EnumItem";
    assert(v162, "argument[1] must be a KeyCode EnumItem!");
    p160.bindedToggleKeys[p161] = true;
    p160.toggleKeyAdded:Fire(p161);
    p160:setCaption("_hotkey_");

    return p160;
end;

function u3.unbindToggleKey(p163, p164) -- Line: 913
    local v165 = typeof(p164) == "EnumItem";
    assert(v165, "argument[1] must be a KeyCode EnumItem!");
    p163.bindedToggleKeys[p164] = nil;

    return p163;
end;

function u3.call(u166, u167, ...) -- Line: 919
    local table_pack_ret = table.pack(...);
    task.spawn(function() -- Line: 921
        -- upvalues: u167 (copy), u166 (copy), table_pack_ret (copy)
        u167(u166, table.unpack(table_pack_ret));
    end);

    return u166;
end;

function u3.addToJanitor(p168, p169, p170, p171) -- Line: 927
    p168.janitor:add(p169, p170, p171);

    return p168;
end;

function u3.lock(p172) -- Line: 932
    p172:getInstance("ClickRegion").Visible = false;
    p172.locked = true;

    return p172;
end;

function u3.unlock(p173) -- Line: 940
    p173:getInstance("ClickRegion").Visible = true;
    p173.locked = false;

    return p173;
end;

function u3.debounce(p174, p175) -- Line: 947
    p174:lock();
    task.wait(p175);
    p174:unlock();

    return p174;
end;

function u3.autoDeselect(p176, p177) -- Line: 954
    p176.deselectWhenOtherIconSelected = p177 == nil and true or p177;

    return p176;
end;

function u3.oneClick(u178, p179) -- Line: 964
    local singleClickJanitor = u178.singleClickJanitor;
    singleClickJanitor:clean();

    if p179 or p179 == nil then
        singleClickJanitor:add(u178.selected:Connect(function() -- Line: 970
            -- upvalues: u178 (copy)
            u178:deselect("OneClick", u178);
        end));
    end;

    u178.oneClickEnabled = true;

    return u178;
end;

function u3.setCaption(p180, p181) -- Line: 978
    -- upvalues: Elements (copy)
    if p181 == "_hotkey_" and p180.captionText then
        return p180;
    end;

    local captionJanitor = p180.captionJanitor;
    p180.captionJanitor:clean();

    if not p181 or p181 == "" then
        p180.caption = nil;
        p180.captionText = nil;

        return p180;
    end;

    local v182 = captionJanitor:add(require(Elements.Caption)(p180));
    v182:SetAttribute("CaptionText", p181);
    p180.caption = v182;
    p180.captionText = p181;

    return p180;
end;

function u3.setCaptionHint(p183, p184) -- Line: 996
    local v185 = typeof(p184) == "EnumItem";
    assert(v185, "argument[1] must be a KeyCode EnumItem!");
    p183.fakeToggleKey = p184;
    p183.fakeToggleKeyChanged:Fire(p184);
    p183:setCaption("_hotkey_");

    return p183;
end;

function u3.leave(p186) -- Line: 1004
    p186.joinJanitor:clean();

    return p186;
end;

function u3.joinMenu(p187, p188) -- Line: 1010
    -- upvalues: Utility (copy)
    Utility.joinFeature(p187, p188, p188.menuIcons, p188:getInstance("Menu"));
    p188.menuChildAdded:Fire(p187);

    return p187;
end;

function u3.setMenu(p189, p190) -- Line: 1016
    p189.menuSet:Fire(p190);

    return p189;
end;

function u3.setFrozenMenu(p191, p192) -- Line: 1021
    p191:freezeMenu(p192);
    p191:setMenu(p192);
end;

function u3.freezeMenu(u193) -- Line: 1026
    u193:select("FrozenMenu", u193);
    u193:bindEvent("deselected", function(p194) -- Line: 1030
        -- upvalues: u193 (copy)
        p194:select("FrozenMenu", u193);
    end);
    u193:modifyTheme({ "IconSpot", "Visible", false });
end;

function u3.joinDropdown(p195, p196) -- Line: 1036
    -- upvalues: Utility (copy)
    p196:getDropdown();
    Utility.joinFeature(p195, p196, p196.dropdownIcons, p196:getInstance("DropdownScroller"));
    p196.dropdownChildAdded:Fire(p195);

    return p195;
end;

function u3.getDropdown(p197) -- Line: 1043
    -- upvalues: Elements (copy)
    local dropdown = p197.dropdown;

    if not dropdown then
        dropdown = require(Elements.Dropdown)(p197);
        p197.dropdown = dropdown;
        p197:clipOutside(dropdown);
    end;

    return dropdown;
end;

function u3.setDropdown(p198, p199) -- Line: 1053
    p198:getDropdown();
    p198.dropdownSet:Fire(p199);

    return p198;
end;

function u3.clipOutside(p200, p201) -- Line: 1059
    -- upvalues: Utility (copy)
    local v202 = Utility.clipOutside(p200, p201);
    p200:refreshAppearance(p201);

    return p200, v202;
end;

function u3.setIndicator(p203, p204) -- Line: 1070
    -- upvalues: Elements (copy), u3 (copy)
    if not p203.indicator then
        p203.indicator = p203.janitor:add(require(Elements.Indicator)(p203, u3));
    end;

    p203.indicatorSet:Fire(p204);
end;

function u3.convertLabelToNumberSpinner(u205, u206, u207) -- Line: 1082
    task.defer(function() -- Line: 1083
        -- upvalues: u205 (copy), u206 (copy), u207 (copy)
        local Instance = u205:getInstance("IconLabel");
        Instance.Transparency = 1;
        u206.Parent = Instance.Parent;
        u206.Size = UDim2.fromScale(1, 1);
        u206.AnchorPoint = Vector2.new(0.5, 0.5);
        u206.Position = UDim2.new(0.5, 0, 0.5, 0);
        u206.TextXAlignment = Enum.TextXAlignment.Center;
        u206.ClipsDescendants = false;

        for _, v in ipairs({ "FontFace", "BorderSizePixel", "BorderColor3", "Rotation", "TextStrokeTransparency", "TextStrokeColor3", "TextStrokeTransparency", "TextColor3" }) do
            u206[v] = Instance[v];
            u205:addToJanitor(Instance:GetPropertyChangedSignal(v):Connect(function() -- Line: 1106
                -- upvalues: u206 (ref), v (copy), Instance (copy)
                u206[v] = Instance[v];
            end));
        end;

        local function getSpinnerSizeAndDigitCount() -- Line: 1113
            -- upvalues: u206 (ref)
            local v208 = 0;
            local v209 = 0;

            for _, child in u206.Frame:GetChildren() do
                local string_lower_ret = string.lower(child.Name);

                if string_lower_ret == "digit" then
                    v208 = v208 + child.AbsoluteSize.X;
                    v209 = v209 + 1;
                elseif (string_lower_ret == "prefix" or (string_lower_ret == "suffix" or string_lower_ret == "comma")) and child.Text ~= "" then
                    v208 = v208 + child.AbsoluteSize.X;
                    v209 = v209 + 1;
                end;
            end;

            return v208, v209;
        end;

        local function getLabelParentContainerXSize() -- Line: 1131
            -- upvalues: Instance (copy), u206 (ref)
            local Parent = Instance.Parent;

            if Parent then
                Parent = Parent.Parent;
            end;

            if Parent == nil then
                return 0;
            end;

            if Parent.IconImage.Visible == true then
                return u206.Frame.AbsoluteSize.X + Instance.Parent.Parent.IconImage.AbsoluteSize.X;
            end;

            return Parent.AbsoluteSize.X;
        end;

        local function getNumberSpinnerXSize() -- Line: 1143
            -- upvalues: u206 (ref)
            return u206.Frame.AbsoluteSize.X;
        end;

        local function adjustSize() -- Line: 1147
            -- upvalues: getSpinnerSizeAndDigitCount (copy), u205 (ref), u206 (ref), Instance (copy)
            local v210, v211 = getSpinnerSizeAndDigitCount();

            if v211 < 18 then
                u205:setLabel(u206.Value);
            end;

            local X = u206.Frame.AbsoluteSize.X;

            while v210 < X and u205.isDestroyed ~= true do
                task.wait(0.05);

                if v211 > 0 and v211 < 8 then
                    u206.TextSize = Instance.TextSize;
                    break;
                end;

                local v212 = u206;
                v212.TextSize = v212.TextSize + 1;
                X = u206.Frame.AbsoluteSize.X;
                v210, v211 = getSpinnerSizeAndDigitCount();
            end;

            local Parent = Instance.Parent;

            if Parent then
                Parent = Parent.Parent;
            end;

            local v213;

            if Parent == nil then
                v213 = 0;
            elseif Parent.IconImage.Visible == true then
                v213 = u206.Frame.AbsoluteSize.X + Instance.Parent.Parent.IconImage.AbsoluteSize.X;
            else
                v213 = Parent.AbsoluteSize.X;
            end;

            while v213 < v210 and u205.isDestroyed ~= true do
                task.wait(0.05);

                if v211 < 8 and v211 > 0 then
                    u206.TextSize = Instance.TextSize;

                    return;
                end;

                local v214 = u206;
                v214.TextSize = v214.TextSize - 1;
                local Parent2 = Instance.Parent;

                if Parent2 then
                    Parent2 = Parent2.Parent;
                end;

                if Parent2 == nil then
                    v213 = 0;
                elseif Parent2.IconImage.Visible == true then
                    v213 = u206.Frame.AbsoluteSize.X + Instance.Parent.Parent.IconImage.AbsoluteSize.X;
                else
                    v213 = Parent2.AbsoluteSize.X;
                end;

                v210, v211 = getSpinnerSizeAndDigitCount();
            end;
        end;

        u205:addToJanitor(u206.Frame.ChildAdded:Connect(adjustSize));
        u205:addToJanitor(u206.Frame.ChildRemoved:Connect(adjustSize));
        u205:addToJanitor(u205.iconAdded:Connect(function() -- Line: 1185
            -- upvalues: adjustSize (copy)
            task.wait(1);
            adjustSize();
        end));
        u205:updateParent();
        u206.Name = "LabelSpinner";
        u206.Prefix = "$";
        u206.Commas = true;
        u206.Decimals = 0;
        u206.Duration = 0.25;
        u206.Value = 10;
        task.wait(0.2);

        if typeof(u207) == "function" then
            u207();
        end;
    end);

    return u205;
end;

function u3.destroy(p215) -- Line: 1212
    -- upvalues: u3 (copy)
    if p215.isDestroyed then
        return;
    end;

    p215:clearNotices();

    if p215.parentIconUID then
        p215:leave();
    end;

    p215.isDestroyed = true;
    p215.janitor:clean();
    u3.iconRemoved:Fire(p215);
end;

u3.Destroy = u3.destroy;

return u3;