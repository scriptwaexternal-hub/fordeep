-- Decompiled with Potassium's decompiler.

local Parent = require(script.Parent.Parent);
local BaseClass = require(script.Parent:WaitForChild("BaseClass"));
local u1 = {
    Text = "ListItem",
    ContentAutomaticSize = true,
    ContentListLayout = true,
    Tooltip = Parent.Nil
};
local u2 = {};
u2.__index = u2;
setmetatable(u2, BaseClass);

function u2.new(p3) -- Line: 17
    -- upvalues: u1 (copy), Parent (copy), u2 (copy)
    local table_clone_ret = table.clone(u1);
    Parent.makeStatefulDefaults(table_clone_ret, p3);
    local v4 = {};
    table_clone_ret._label = Parent.new("TextLabel")({
        AutoLocalize = false,
        BackgroundTransparency = 1,
        RichText = true,
        AutomaticSize = Enum.AutomaticSize.XY,
        AnchorPoint = Vector2.new(0, 0.5),
        Position = UDim2.fromScale(0, 0.5),
        Size = UDim2.new(0, 0, 0, 0),
        FontFace = Parent.Theme.Font,
        Text = table_clone_ret.Text,
        TextColor3 = Parent.Theme.PrimaryText,
        TextSize = Parent.Theme.FontSize,
        TextStrokeColor3 = Parent.Theme.Primary,
        TextStrokeTransparency = Parent.Theme.TextStrokeTransparency,
        TextXAlignment = Enum.TextXAlignment.Left
    });
    local u5 = Parent.state(table_clone_ret._label, "AbsoluteSize");
    local v6 = Parent.compute(function() -- Line: 41
        -- upvalues: table_clone_ret (copy)
        return table_clone_ret.ContentAutomaticSize() and Enum.AutomaticSize.Y or Enum.AutomaticSize.None;
    end);
    table.insert(v4, u5);
    table.insert(v4, v6);
    table_clone_ret._content = Parent.new("Frame")({
        Name = "UIContent",
        AnchorPoint = Vector2.new(1, 0),
        AutomaticSize = v6,

        Size = function() -- Line: 51, Name: Size
            -- upvalues: u5 (copy), Parent (ref), table_clone_ret (copy)
            return UDim2.new(1, -u5().X - Parent.Theme.Padding().Offset, table_clone_ret.ContentAutomaticSize() and 0 or 1, 0);
        end,

        Position = UDim2.new(1, 0, 0, 0),
        BackgroundTransparency = 1,
        Parent.new("UIPadding")({
            PaddingRight = UDim.new(0, 1)
        })
    });
    local u7 = Parent.new("UIListLayout")({
        Parent = table_clone_ret._content,
        HorizontalAlignment = Enum.HorizontalAlignment.Right,
        VerticalAlignment = Enum.VerticalAlignment.Center,
        FillDirection = Enum.FillDirection.Horizontal,
        SortOrder = Enum.SortOrder.LayoutOrder,
        Padding = Parent.Theme.Padding
    });
    table_clone_ret._layoutParentCompute = Parent.compute(function() -- Line: 71
        -- upvalues: u7 (copy), table_clone_ret (copy)
        local v8;

        if table_clone_ret.ContentListLayout() then
            v8 = table_clone_ret._content;
        else
            v8 = nil;
        end;

        u7.Parent = v8;
    end);
    local Frame = Parent.new("Frame");
    local v9 = {
        Name = table_clone_ret.Text._value,
        AutomaticSize = v6,
        BackgroundTransparency = 1,

        Size = function() -- Line: 79, Name: Size
            -- upvalues: table_clone_ret (copy), u5 (copy), Parent (ref)
            return UDim2.new(1, 0, 0, table_clone_ret.ContentAutomaticSize() and 0 or u5().Y + Parent.Theme.Padding().Offset);
        end
    };
    local _label = table_clone_ret._label;
    local _content = table_clone_ret._content;
    local v10;

    if table_clone_ret.Tooltip then
        v10 = Parent.new("Tooltip")({
            Text = table_clone_ret.Tooltip
        });
    else
        v10 = nil;
    end;

    v9[1], v9[2], v9[3] = _label, _content, v10;
    v9[Parent.Clean] = v4;
    table_clone_ret._instance = Frame(v9);

    return setmetatable(table_clone_ret, u2);
end;

return u2;