-- Decompiled with Potassium's decompiler.

local TweenService = game:GetService("TweenService");
local Color3_fromRGB_ret = Color3.fromRGB(44, 44, 45);
local Color3_fromRGB_ret2 = Color3.fromRGB(28, 28, 30);
local Color3_fromRGB_ret3 = Color3.fromRGB(0, 0, 0);
local Color3_fromRGB_ret4 = Color3.fromRGB(255, 255, 255);
local Color3_fromRGB_ret5 = Color3.fromRGB(216, 213, 205);
local Color3_fromRGB_ret6 = Color3.fromRGB(90, 200, 120);
local Color3_fromRGB_ret7 = Color3.fromRGB(226, 62, 48);
local u1 = setmetatable({}, {
    __mode = "k"
});

local function stroked(p2) -- Line: 25
    -- upvalues: Color3_fromRGB_ret3 (copy)
    p2.TextStrokeColor3 = Color3_fromRGB_ret3;
    p2.TextStrokeTransparency = 1;

    return p2;
end;

local function outline(p3, p4) -- Line: 26
    -- upvalues: Color3_fromRGB_ret3 (copy)
    local UIStroke = Instance.new("UIStroke");
    UIStroke.Color = Color3_fromRGB_ret3;
    UIStroke.Thickness = p4;
    UIStroke.Parent = p3;

    return UIStroke;
end;

local function build(p5) -- Line: 28
    -- upvalues: Color3_fromRGB_ret (copy), Color3_fromRGB_ret3 (copy), Color3_fromRGB_ret4 (copy), Color3_fromRGB_ret5 (copy), Color3_fromRGB_ret2 (copy), Color3_fromRGB_ret6 (copy)
    local v6 = p5:FindFirstChild("Handle") or (p5.PrimaryPart or p5:FindFirstChildWhichIsA("BasePart"));

    if not v6 then
        return nil;
    end;

    local BillboardGui = Instance.new("BillboardGui");
    BillboardGui.Name = "MachineBar";
    BillboardGui.Adornee = v6;
    BillboardGui.Size = UDim2.fromOffset(180, 46);
    BillboardGui.StudsOffsetWorldSpace = Vector3.new(0, 6, 0);
    BillboardGui.AlwaysOnTop = true;
    BillboardGui.MaxDistance = 200;
    BillboardGui.ResetOnSpawn = false;
    local Frame = Instance.new("Frame");
    Frame.Size = UDim2.new(1, 0, 1, 0);
    Frame.BackgroundColor3 = Color3_fromRGB_ret;
    Frame.BorderSizePixel = 0;
    Frame.BackgroundTransparency = 1;
    Frame.Parent = BillboardGui;
    local UIStroke = Instance.new("UIStroke");
    UIStroke.Color = Color3_fromRGB_ret3;
    UIStroke.Thickness = 1.5;
    UIStroke.Parent = Frame;
    UIStroke.Transparency = 1;
    local TextLabel = Instance.new("TextLabel");
    TextLabel.BackgroundTransparency = 1;
    TextLabel.Position = UDim2.new(0, 8, 0, 4);
    TextLabel.Size = UDim2.new(0.5, -8, 0, 16);
    TextLabel.Font = Enum.Font.Arcade;
    TextLabel.TextSize = 14;
    TextLabel.TextColor3 = Color3_fromRGB_ret4;
    TextLabel.TextXAlignment = Enum.TextXAlignment.Left;
    TextLabel.Text = "MACHINE";
    TextLabel.TextTransparency = 1;
    TextLabel.TextStrokeColor3 = Color3_fromRGB_ret3;
    TextLabel.TextStrokeTransparency = 1;
    TextLabel.Parent = Frame;
    local TextLabel2 = Instance.new("TextLabel");
    TextLabel2.BackgroundTransparency = 1;
    TextLabel2.Position = UDim2.new(0.5, 0, 0, 4);
    TextLabel2.Size = UDim2.new(0.5, -8, 0, 16);
    TextLabel2.Font = Enum.Font.Bangers;
    TextLabel2.TextSize = 16;
    TextLabel2.TextColor3 = Color3_fromRGB_ret5;
    TextLabel2.TextXAlignment = Enum.TextXAlignment.Right;
    TextLabel2.Text = "";
    TextLabel2.TextTransparency = 1;
    TextLabel2.TextStrokeColor3 = Color3_fromRGB_ret3;
    TextLabel2.TextStrokeTransparency = 1;
    TextLabel2.Parent = Frame;
    local Frame2 = Instance.new("Frame");
    Frame2.Position = UDim2.new(0, 8, 0, 26);
    Frame2.Size = UDim2.new(1, -16, 0, 12);
    Frame2.BackgroundColor3 = Color3_fromRGB_ret2;
    Frame2.BorderSizePixel = 0;
    Frame2.BackgroundTransparency = 1;
    Frame2.Parent = Frame;
    local UIStroke2 = Instance.new("UIStroke");
    UIStroke2.Color = Color3_fromRGB_ret3;
    UIStroke2.Thickness = 1.5;
    UIStroke2.Parent = Frame2;
    UIStroke2.Transparency = 1;
    local Frame3 = Instance.new("Frame");
    Frame3.Size = UDim2.new(1, 0, 1, 0);
    Frame3.BackgroundColor3 = Color3_fromRGB_ret6;
    Frame3.BorderSizePixel = 0;
    Frame3.BackgroundTransparency = 1;
    Frame3.Parent = Frame2;
    BillboardGui.Parent = v6;

    return {
        Visible = false,
        Gui = BillboardGui,
        Fill = Frame3,
        Value = TextLabel2,
        Fades = { Frame, Frame2, Frame3 },
        Strokes = { UIStroke, UIStroke2 },
        Texts = { TextLabel, TextLabel2 }
    };
end;

local function setVisible(p7, p8) -- Line: 59
    -- upvalues: TweenService (copy)
    if p7.Visible == p8 then
        return;
    end;

    p7.Visible = p8;
    local TweenInfo_new_ret = TweenInfo.new(0.4);
    local v9 = p8 and 0 or 1;

    for _, v in ipairs(p7.Fades) do
        TweenService:Create(v, TweenInfo_new_ret, {
            BackgroundTransparency = v9
        }):Play();
    end;

    for _, v in ipairs(p7.Strokes) do
        TweenService:Create(v, TweenInfo_new_ret, {
            Transparency = v9
        }):Play();
    end;

    for _, v in ipairs(p7.Texts) do
        TweenService:Create(v, TweenInfo_new_ret, {
            TextTransparency = v9,
            TextStrokeTransparency = p8 and 0.5 or 1
        }):Play();
    end;
end;

local function refresh(p10) -- Line: 69
    -- upvalues: u1 (copy), TweenService (copy), Color3_fromRGB_ret7 (copy), Color3_fromRGB_ret6 (copy), setVisible (copy)
    local v11 = u1[p10];

    if not (v11 and v11.Gui.Parent) then
        return;
    end;

    local v12 = tonumber(p10:GetAttribute("MaxHealth")) or 1;
    local v13 = tonumber(p10:GetAttribute("Health")) or v12;
    local v14 = v13 / math.max(1, v12);
    local math_clamp_ret = math.clamp(v14, 0, 1);
    TweenService:Create(v11.Fill, TweenInfo.new(0.18), {
        Size = UDim2.new(math_clamp_ret, 0, 1, 0)
    }):Play();
    v11.Fill.BackgroundColor3 = math_clamp_ret <= 0.3 and Color3_fromRGB_ret7 or Color3_fromRGB_ret6;
    v11.Value.Text = string.format("%d / %d", math.floor(v13), (math.floor(v12)));
    setVisible(v11, v13 < v12);
end;

local Live = workspace:WaitForChild("World"):WaitForChild("Live");

local function watch(u15) -- Line: 82
    -- upvalues: u1 (copy), build (copy), refresh (copy)
    if u1[u15] or (not u15:IsA("Model") or u15:GetAttribute("MaxHealth") == nil) then
        return;
    end;

    if u15:GetAttribute("Interact") ~= "GravityMachine" and u15.Name ~= "Gravity Machine" then
        return;
    end;

    local v16 = build(u15);

    if not v16 then
        return;
    end;

    u1[u15] = v16;
    v16.Conns = { u15:GetAttributeChangedSignal("Health"):Connect(function() -- Line: 89
            -- upvalues: refresh (ref), u15 (copy)
            refresh(u15);
        end), u15:GetAttributeChangedSignal("MaxHealth"):Connect(function() -- Line: 90
            -- upvalues: refresh (ref), u15 (copy)
            refresh(u15);
        end) };
    refresh(u15);
end;

local function unwatch(p17) -- Line: 95
    -- upvalues: u1 (copy)
    local v18 = u1[p17];

    if not v18 then
        return;
    end;

    u1[p17] = nil;

    for _, v in ipairs(v18.Conns or {}) do
        v:Disconnect();
    end;

    if v18.Gui then
        v18.Gui:Destroy();
    end;
end;

for _, child in ipairs(Live:GetChildren()) do
    watch(child);
end;

Live.ChildAdded:Connect(function(u19) -- Line: 105
    -- upvalues: watch (copy), u1 (copy)
    if u19:IsA("Model") then
        local u20 = nil;
        u20 = u19.AttributeChanged:Connect(function() -- Line: 109
            -- upvalues: u19 (copy), watch (ref), u1 (ref), u20 (ref)
            if u19:GetAttribute("MaxHealth") then
                watch(u19);

                if u1[u19] then
                    u20:Disconnect();
                end;
            end;
        end);
        watch(u19);
    end;
end);
Live.ChildRemoved:Connect(unwatch);

return {};