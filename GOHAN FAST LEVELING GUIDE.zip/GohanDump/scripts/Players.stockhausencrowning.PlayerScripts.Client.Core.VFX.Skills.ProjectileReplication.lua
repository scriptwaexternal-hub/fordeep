-- Decompiled with Potassium's decompiler.

game:GetService("Players");
game:GetService("Debris");
local ReplicatedStorage = game:GetService("ReplicatedStorage");
game:GetService("RunService");
game:GetService("UserInputService");
local Assets = ReplicatedStorage.Assets;
local Modules = ReplicatedStorage:WaitForChild("Modules");
ReplicatedStorage:WaitForChild("Remotes");
local _ = Modules.Metadata;
local Shared = Modules.Shared;
local _ = Modules.Utility;
local _ = Assets.Gui;
require(Shared.SoundManager);
require(Modules.GlobalFunctions);
require(Modules.Effects.VfxHandler);
require(Shared.CamManager);
require(Shared.CinemaManager);
local ProjectileHandler = require(Shared.ProjectileHandler);

return {
    Execute = function(p1) -- Line: 33
        -- upvalues: ProjectileHandler (copy)
        ProjectileHandler.Fire({
            Character = p1.Character,
            Is_Weapon = p1.Is_Weapon,
            Origin = p1.Origin,
            Goal = p1.Goal,
            Projectile = p1.Projectile,
            Duration = p1.Duration,
            SentProjectile = p1.SentProjectile,
            LookAtGoal = p1.LookAtGoal,
            Size = p1.Size,
            Sound = p1.Sound,
            Speed = p1.Speed,
            Color = p1.Color,
            ProjectileSize = p1.ProjectileSize,
            HasHandle = p1.HasHandle,
            IgnoreInstances = p1.IgnoreInstances,
            Bezier = p1.Bezier,
            ControlPoint = p1.ControlPoint,
            CutsBreakables = p1.CutsBreakables,
            CutSize = p1.CutSize,
            Voxelize = p1.Voxelize
        });
    end
};