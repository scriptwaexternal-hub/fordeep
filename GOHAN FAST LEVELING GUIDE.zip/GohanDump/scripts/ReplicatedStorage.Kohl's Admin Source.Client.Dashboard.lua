-- Decompiled with Potassium's decompiler.

local Parent = require(script.Parent.Parent);
local UI = require(script.Parent:WaitForChild("UI"));
local About = require(script.Parent:WaitForChild("About"));
local Bans = require(script.Parent:WaitForChild("Bans"));
local Commands = require(script.Parent:WaitForChild("Commands"));
local Logs = require(script.Parent:WaitForChild("Logs"));
local Members = require(script.Parent:WaitForChild("Members"));
local Servers = require(script.Parent:WaitForChild("Servers"));
local Settings = require(script.Parent:WaitForChild("Settings"));
local Market = require(script.Parent:WaitForChild("Market"));
local os_clock_ret = os.clock();
Parent.client.dashboard = {};
Parent.client.dashboard.About = About.new(Parent);
Parent.client.dashboard.Bans = Bans.new(Parent);
Parent.client.dashboard.Commands = Commands.new(Parent);
Parent.client.dashboard.Members = Members.new(Parent);
Parent.client.dashboard.Servers = Servers.new(Parent);
Parent.client.dashboard.Logs = Logs.new(Parent);
Parent.client.dashboard.Settings = Settings.new(Parent);
Parent.client.dashboard.Market = Market.new(Parent);
local u1 = UI.new("Tabs")({
    CurrentPage = Parent.client.dashboard.About,
    Tabs = {
        { Parent.client.dashboard.Commands },
        { Parent.client.dashboard.Bans },
        { Parent.client.dashboard.Members },
        { Parent.client.dashboard.Servers },
        { Parent.client.dashboard.Logs },
        { Parent.client.dashboard.Settings },
        { Parent.client.dashboard.About },
        { Parent.client.dashboard.Market }
    },
    Vertical = true,
    [UI.Event] = {
        AbsoluteSize = function() -- Line: 40, Name: AbsoluteSize
            -- upvalues: Parent (copy)
            local AbsoluteSize = Parent.client.dashboard.Window._instance.AbsoluteSize;
            Parent.client.dashboard.Tabs.Vertical(AbsoluteSize.x > AbsoluteSize.y);
        end
    }
});
Parent.client.dashboard.Tabs = u1;
local v2 = UI.compute(function() -- Line: 48
    -- upvalues: u1 (copy), UI (copy)
    if u1.Vertical() then
        return UDim.new();
    end;

    return UI.Theme.Padding;
end);
local v3 = UI.compute(function() -- Line: 52
    -- upvalues: u1 (copy), UI (copy)
    if u1.Vertical() then
        return UI.Theme.Padding;
    end;

    return UDim.new();
end);
local v4 = UI.compute(function() -- Line: 56
    -- upvalues: u1 (copy), UI (copy)
    if u1.Vertical() then
        return UI.Theme.PaddingWithStroke;
    end;

    return UI.Theme.PaddingStroke;
end);
UI.edit(u1._content, {
    BackgroundColor3 = UI.Theme.Secondary,

    BackgroundTransparency = function() -- Line: 62, Name: BackgroundTransparency
        -- upvalues: u1 (copy), UI (copy)
        return not u1.Vertical() and 1 or UI.Theme.TransparencyMax;
    end,

    UI.new("UICorner")({
        CornerRadius = UI.Theme.CornerPadded
    }),
    UI.new("UIPadding")({
        PaddingRight = v3,
        PaddingLeft = v3
    })
});
UI.new("UIPadding")({
    Parent = u1._instance,
    PaddingRight = v3
});
local u5 = UI.new("Window")({
    Parent = UI.LayerTopInset,
    Icon = "rbxassetid://71961243872230",
    IconProperties = {
        Size = function() -- Line: 81, Name: Size
            -- upvalues: UI (copy)
            return UDim2.fromOffset(UI.Theme.FontSize(), UI.Theme.FontSize());
        end,

        UI.new("Tooltip")({
            Text = "Kohl\'s Admin"
        })
    },
    Position = UDim2.new(0.5, -320, 0.5, -240),
    Size = UDim2.fromOffset(648, 492),
    SizeBounds = Rect.new(128, 128, 9000000000, 9000000000),
    Title = "",
    Visible = false,
    u1
});
Parent.client.dashboard.Window = u5;
u5._exitButton.ActiveSound(false);
u5._content.UIPadding:Destroy();
task.spawn(function() -- Line: 99
    -- upvalues: u5 (copy)
    while true do
        task.wait(1);
        u5.Title(DateTime.now():FormatLocalTime("LT", "en-us"));
    end;
end);
local TitleBar = u5._instance.Frame.TitleBar;
UI.edit(TitleBar.UIPadding, {
    PaddingLeft = UI.Theme.PaddingDouble
});
UI.edit(TitleBar.Left.Title, {
    TextTransparency = 0.5,
    TextSize = UI.Theme.FontSize
});
local u6 = UI.new("Tooltip")({
    Parent = TitleBar.Left.Title
});
task.spawn(function() -- Line: 120
    -- upvalues: u6 (copy), UI (copy)
    while true do
        task.wait(1);
        u6.Text(DateTime.now():FormatLocalTime("dddd, LL", UI.LocalPlayer.LocaleId));
    end;
end);
local u7 = {};

for _, v in {
    Parent.client.dashboard.Bans,
    Parent.client.dashboard.Commands,
    Parent.client.dashboard.Logs,
    Parent.client.dashboard.Members,
    Parent.client.dashboard.Settings
} do
    local u8;

    if type(v) == "table" then
        u8 = v._instance;
    else
        u8 = v;
    end;

    local u9 = UI.state(false);

    local function update() -- Line: 140
        -- upvalues: u8 (copy), u5 (copy), u1 (copy), u9 (copy)
        local Parent2 = u8.Parent;
        local v10 = Parent2 and Parent2:IsDescendantOf(u5._instance);

        if v10 then
            if u1._pages.CurrentPage == Parent2 then
                v10 = u1.Vertical();
            else
                v10 = false;
            end;
        end;

        u9(v10, true);
    end;

    u8:GetPropertyChangedSignal("Parent"):Connect(update);
    u1._pages:GetPropertyChangedSignal("CurrentPage"):Connect(function() -- Line: 151
        -- upvalues: u1 (copy), u8 (copy), u5 (copy), u9 (copy)
        if u1._pageCache[u1._pages.CurrentPage] == u8 then
            local Parent2 = u8.Parent;
            local v11 = Parent2 and Parent2:IsDescendantOf(u5._instance);

            if v11 then
                if u1._pages.CurrentPage == Parent2 then
                    v11 = u1.Vertical();
                else
                    v11 = false;
                end;
            end;

            u9(v11, true);
        end;
    end);
    u1.Vertical:Connect(update);

    if u1._pageCache[u1._pages.CurrentPage] == u8 then
        local Parent2 = u8.Parent;
        local v12 = Parent2 and Parent2:IsDescendantOf(u5._instance);

        if v12 then
            if u1._pages.CurrentPage == Parent2 then
                v12 = u1.Vertical();
            else
                v12 = false;
            end;
        end;

        u9(v12, true);
    end;

    UI.new("UIFlexItem")({
        Parent = v._input._instance,

        FlexMode = function() -- Line: 164, Name: FlexMode
            -- upvalues: u9 (copy)
            if u9() then
                return Enum.UIFlexMode.Fill;
            end;

            return Enum.UIFlexMode.None;
        end
    });
    UI.edit(v._input, {
        Size = function() -- Line: 169, Name: Size
            -- upvalues: u9 (copy), UI (copy)
            local v13 = u9() and 0 or 1;

            return UDim2.new(v13, 0, 0, UI.Theme.FontSize() + UI.Theme.Padding().Offset * 2);
        end,

        LayoutOrder = function() -- Line: 173, Name: LayoutOrder
            -- upvalues: u9 (copy)
            return u9() and 4 or -1;
        end,

        Parent = function() -- Line: 176, Name: Parent
            -- upvalues: u9 (copy), u7 (copy), v (copy), TitleBar (copy), u8 (copy)
            local v14 = u9();
            u7[v] = v14 and true or nil;
            local Spacer = TitleBar:FindFirstChild("Spacer");

            if Spacer then
                Spacer.Visible = next(u7) == nil;
            end;

            if v14 then
                return TitleBar;
            end;

            return u8;
        end
    });
    UI.edit(v._scroller.UIPadding, {
        PaddingTop = v4,
        PaddingBottom = v4
    });
end;

UI.edit(Parent.client.dashboard.Logs._scroller.UIPadding, {
    PaddingTop = UDim.new()
});
UI.edit(u1._instance.Bar.UIPadding, {
    PaddingBottom = v2
});
UI.edit(u1._instance.Bar.Tabs, { UI.new("Spacer")({
        LayoutOrder = 899999999,
        Visible = u1.Vertical
    }) });
UI.edit(u1._instance.Bar.Tabs.Market, {
    LayoutOrder = 900000000
});
UI.edit(u1._instance.Bar.Tabs.Market.UIContent.Label, {
    Name = "Title",
    UI.new("UIGradient")({})
});
u1._instance.Bar.Tabs.Market.UIContent:AddTag("_Keternal");
local u15 = UI.state(u1._instance.Bar, "AbsoluteSize");
UI.edit(TitleBar.Left, {
    Size = function() -- Line: 221, Name: Size
        -- upvalues: u1 (copy), u15 (copy), UI (copy)
        if u1.Vertical() then
            return UDim2.fromOffset(u15().X - UI.Theme.Padding().Offset * 3, 0);
        end;

        return UDim2.new();
    end
});
local u16 = UI.compute(function() -- Line: 228
    -- upvalues: UI (copy)
    return UDim2.fromOffset(UI.Theme.FontSize() + UI.Theme.PaddingHalf().Offset, 0);
end);

local function statusIconLabel(p17, p18, p19, p20) -- Line: 232
    -- upvalues: UI (copy), u16 (copy)
    return UI.new("Frame")({
        AutomaticSize = Enum.AutomaticSize.X,
        BackgroundTransparency = 1,
        Name = p17,
        Size = UDim2.new(0, 0, 1, 0),
        UI.edit(UI.new("ImageLabel")({
            BackgroundTransparency = 1,
            ImageTransparency = 0.5,
            Image = UI.Theme.Image.Signal,
            ImageColor3 = UI.Theme.PrimaryText,
            Size = UDim2.new(1, 0, 1, 0),
            SizeConstraint = Enum.SizeConstraint.RelativeYY
        }), p18 or {}),
        UI.edit(UI.new("TextLabel")({
            Name = "Label",
            BackgroundTransparency = 1,
            Text = "?",
            TextTransparency = 0.5,
            AutomaticSize = Enum.AutomaticSize.X,
            Position = u16,
            Size = UDim2.fromScale(0, 1),
            FontFace = UI.Theme.FontMono,
            TextColor3 = UI.Theme.PrimaryText,
            TextSize = UI.Theme.FontSize
        }), p19 or {}),
        UI.edit(UI.new("Tooltip")({
            FontFace = UI.Theme.FontMono,
            Text = p17
        }), p20 or {})
    });
end;

local function getAvgLow(p21, p22, p23, p24, p25) -- Line: 268
    local v26 = tick();

    if p25 < v26 then
        p25 = v26 + 2;
        table.sort(p21);
        p22 = math.round(p24 / #p21) * 2;
        local math_ceil_ret = math.ceil(#p21 / 100);
        local v27 = 0;

        for i = 1, math_ceil_ret do
            v27 = v27 + p21[i];
            local _ = i;
        end;

        p23 = v27 // math_ceil_ret;
        table.clear(p21);
    end;

    return p22, p23, 0, p25;
end;

local u28 = UI.compute(function() -- Line: 286
    -- upvalues: UI (copy)
    return UI.Color.Oklab.toHCL(UI.Color.Oklab.fromLinear(UI.Theme.Valid())).X;
end);
local u29 = UI.compute(function() -- Line: 289
    -- upvalues: UI (copy)
    return UI.Color.Oklab.toHCL(UI.Color.Oklab.fromLinear(UI.Theme.Invalid())).X;
end);

local function u33(p30: number) -- Line: 292
    -- upvalues: u28 (copy), u29 (copy), UI (copy)
    local v31 = u28();
    local v32 = u29();
    local math_lerp_ret = math.lerp(v31, v32, p30);
    local Vector3_new_ret = Vector3.new(math_lerp_ret, 1, 1);

    return UI.Color.Oklab.toLinear(UI.Color.Oklab.fromHCL(Vector3_new_ret));
end;

UI.new("Frame")({
    Name = "StatusBar",
    Parent = u5._instance.Frame,
    LayoutOrder = 2147483647,
    AnchorPoint = Vector2.new(0, 1),
    BackgroundTransparency = 1,
    ClipsDescendants = true,
    Position = UDim2.fromScale(0, 1),

    Size = function() -- Line: 306, Name: Size
        -- upvalues: UI (copy)
        return UDim2.new(1, 0, 0, UI.Theme.FontSizeSmall + UI.Theme.PaddingDouble().Offset);
    end,

    UI.new("Frame")({
        Name = "Content",
        BackgroundTransparency = 1,
        Size = UDim2.fromScale(1, 1),
        UI.new("UIListLayout")({
            SortOrder = Enum.SortOrder.LayoutOrder,
            FillDirection = Enum.FillDirection.Horizontal,
            VerticalAlignment = Enum.VerticalAlignment.Center,
            Padding = UI.Theme.PaddingDouble
        }),
        UI.new("UIPadding")({
            PaddingLeft = UI.Theme.Padding,
            PaddingRight = UI.Theme.Padding,
            PaddingTop = UI.Theme.Padding,
            PaddingBottom = UI.Theme.Padding
        }),
        statusIconLabel("Ping", {
            Image = UI.Theme.Image.SignalSheet,
            ImageRectSize = Vector2.new(86, 86)
        }, { UI.action(function(p34) -- Line: 330
                -- upvalues: Parent (copy), u33 (ref), UI (copy)
                local u35 = 0;
                local u36 = 0;
                local v37 = 0;
                local u38 = 0;
                local u39 = 0;
                local v40 = tick();
                Parent.Service.Run.Heartbeat:Connect(function() -- Line: 333
                    -- upvalues: u35 (ref), Parent (ref), u36 (ref), u38 (ref), u39 (ref)
                    local v41 = Parent.Service.Players.LocalPlayer:GetNetworkPing() * 1000;
                    u35 = math.round(v41);
                    local math_max_ret = math.max(u36, u35);
                    u36 = math.min(math_max_ret, 30000);
                    u38 = u38 + 1;
                    u39 = u39 + u35;
                end);

                while true do
                    task.wait(1);

                    if v40 < tick() then
                        v40 = tick() + 2;
                        v37 = u39 // u38;
                        u39 = 0;
                        u38 = 0;
                    end;

                    local math_clamp_ret = math.clamp(u35 / 350, 0, 1);
                    local v42 = u33(math_clamp_ret);
                    p34.Parent.ImageLabel.ImageRectOffset = Vector2.new(math.round((1 - math_clamp_ret) * 4) * 90 + math.ceil(math_clamp_ret), 0);
                    p34.Parent.ImageLabel.ImageColor3 = v42;
                    p34.TextColor3 = v42;
                    p34.Text = `{v37}ms`;
                    local v43 = UI.Class.Tooltip.Cache[p34.Parent];

                    if v43 then
                        v43.Text((`Ping\n\n<b>Avg:</b>     {v37}ms\n<b>Max:</b>     {u36}ms`));
                    end;
                end;
            end) }),
        statusIconLabel("FPS", {
            Image = UI.Theme.Image.Pace
        }, { UI.action(function(p44) -- Line: 365
                -- upvalues: Parent (copy), getAvgLow (copy), u33 (ref), UI (copy)
                local u45 = 0;
                local u46 = 0;
                local v47 = 0;
                local v48 = 0;
                local u49 = 0;
                local u50 = {};
                local v51 = tick();
                Parent.Service.Run.Heartbeat:Connect(function() -- Line: 368
                    -- upvalues: u45 (ref), Parent (ref), u46 (ref), u49 (ref), u50 (copy)
                    u45 = math.round(1 / Parent.Service.Stats.FrameTime);
                    u46 = math.clamp(u45, u46, 240);
                    u49 = u49 + u45;
                    table.insert(u50, u45);
                end);

                while true do
                    local v52;

                    repeat
                        task.wait(1);
                        local v53, v54;
                        v53, v48, v54, v51 = getAvgLow(u50, v47, v48, u49, v51);
                        u49 = v54;
                        v47 = math.clamp(v53, 0, 240);
                        local v55 = u33(1 - math.clamp(u45 / u46, 0, 1));
                        p44.Parent.ImageLabel.ImageColor3 = v55;
                        p44.TextColor3 = v55;
                        p44.Text = `{v47} fps`;
                        v52 = UI.Class.Tooltip.Cache[p44.Parent];
                    until v52;

                    v52.Text((`Frames Per Second\n\n<b>1% Low:</b>  {v48} fps\n<b>Avg:</b>     {v47} fps\n<b>Max:</b>     {u46} fps`));
                end;
            end) }),
        UI.new("Spacer")({}),
        statusIconLabel("Uptime", {
            Image = UI.Theme.Image.Hourglass_Bottom
        }, { UI.action(function(p56) -- Line: 398
                -- upvalues: Parent (copy), UI (copy)
                while true do
                    local v57;

                    repeat
                        task.wait(1);
                        local v58 = workspace:GetServerTimeNow() - Parent.script:GetAttribute("ServerStartTime");
                        local math_round_ret = math.round(v58);
                        p56.Text = Parent.Util.Time.clock(math_round_ret);
                        v57 = UI.Class.Tooltip.Cache[p56.Parent];
                    until v57;

                    v57.Text((`Uptime\n\n<b>Server:</b>  {p56.Text}\n<b>Client:</b>  {Parent.Util.Time.clock(time())}`));
                end;
            end) }),
        statusIconLabel("Kohl\'s Admin Version", {
            Image = UI.Theme.Image.Graph1,
            ImageTransparency = UI.Theme.TransparencyStrong
        }, {
            Text = `{Parent.VERSION}`,
            TextTransparency = UI.Theme.TransparencyStrong
        })
    })
});
Parent.client.commandBarVisible = UI.state(Parent.client.CommandBar.Bar, "Visible");
local v60 = UI.compute(function() -- Line: 425
    -- upvalues: UI (copy)
    local v59 = UI.Theme.FontSizeLargest();

    return UDim2.fromOffset(v59, v59);
end);
Parent.client.toggleCommandBar = UI.new("Button")({
    BackgroundTransparency = 1,
    HoverTransparency = 1,
    Text = "",
    LayoutOrder = 8,
    Size = v60,
    Icon = UI.Theme.Image.Terminal,
    IconProperties = {
        ImageColor3 = UI.Theme.PrimaryText,
        Size = UDim2.new(0.75, 0, 0.75, 0)
    },
    Parent = u5._instance.Frame.TitleBar,

    Activated = function() -- Line: 430, Name: toggleCommandBar
        -- upvalues: Parent (copy)
        if Parent.client.CommandBar.Bar.Visible then
            Parent.client.CommandBar.hide();

            return;
        end;

        Parent.client.CommandBar.show();
    end
});
Parent.client.toggleCommandBar._instance:FindFirstChildOfClass("UIStroke"):Destroy();
UI.edit(Parent.client.toggleCommandBar._content.IconFrame.Icon, {
    ImageTransparency = function() -- Line: 456, Name: ImageTransparency
        -- upvalues: Parent (copy)
        return Parent.client.commandBarVisible() and 0 or (Parent.client.toggleCommandBar._hovering() and 0.5 or 0.75);
    end
});
UI.new("Tooltip")({
    Text = "Command Bar",
    Parent = Parent.client.toggleCommandBar,
    Hovering = Parent.client.toggleCommandBar._hovering
});
local u61 = UI.state(false);

local function dashboardToggle(p62) -- Line: 468
    -- upvalues: Parent (copy), u61 (copy), UI (copy), u1 (copy), u5 (copy)
    if not Parent.client.dashboardEnabled then
        return;
    end;

    u61(p62.isSelected);

    if p62.isSelected then
        UI.Sound.Hover03:Play();
    else
        UI.Sound.Hover01:Play();
        UI.clearActiveStates();
    end;

    local CurrentPage = u1._pages.CurrentPage;

    if CurrentPage then
        CurrentPage = CurrentPage:FindFirstChildWhichIsA("GuiObject");
    end;

    if CurrentPage then
        CurrentPage.Visible = p62.isSelected;
    end;

    u5._instance.Visible = p62.isSelected;
    task.delay(4, Parent.client.VIPNotification);
end;

local function toggleCommandBarWithSound() -- Line: 488
    -- upvalues: Parent (copy), UI (copy)
    if Parent.client.CommandBar.Bar.Visible then
        UI.Sound.Hover03:Play();
        Parent.client.CommandBar.hide();

        return;
    end;

    UI.Sound.Hover01:Play();
    Parent.client.CommandBar.show();
    UI.Haptic.Hover:Play();
end;

local u63 = UI.spring(function() -- Line: 499
    -- upvalues: u61 (copy)
    if u61() then
        return UDim.new(0, 10);
    end;

    return UDim.new(0, 12);
end, 16, 0.5);
local u64 = {
    isSelected = false
};
local u65 = UI.new("TextButton")({
    Parent = UI.TopbarFrame,
    Name = "KADashboardButton",
    BackgroundColor3 = Color3.fromRGB(18, 18, 21),
    BackgroundTransparency = 0.08,
    Size = UDim2.fromScale(1, 1),
    SizeConstraint = Enum.SizeConstraint.RelativeYY,
    Text = "",
    Visible = false,
    UI.new("UICorner")({
        CornerRadius = UDim.new(1, 0)
    }),
    UI.new("UIPadding")({
        PaddingLeft = u63,
        PaddingRight = u63,
        PaddingTop = u63,
        PaddingBottom = u63
    }),
    UI.new("ImageLabel")({
        BackgroundTransparency = 1,
        Image = "rbxassetid://71961243872230",
        Size = UDim2.fromScale(1, 1)
    }),

    Activated = function() -- Line: 528, Name: Activated
        -- upvalues: u64 (copy), dashboardToggle (copy)
        u64.isSelected = not u64.isSelected;
        dashboardToggle(u64);
    end,

    MouseButton2Click = toggleCommandBarWithSound,
    TouchLongPress = toggleCommandBarWithSound
});
Parent.client.dashboardButton = u65;

local function commandsWindow(p66: boolean) -- Line: 538
    -- upvalues: Parent (copy), UI (copy)
    local cmds = Parent.Registry.commands.cmds;

    if p66 then
        UI.edit(cmds.env.window, {
            Visible = true,
            Parent.client.dashboard.Commands
        });
        Parent.client.dashboard.Commands._instance.Visible = true;

        return;
    end;

    cmds.env.window._instance.Visible = false;
    Parent.UI.edit(Parent.client.dashboard.Tabs, { Parent.client.dashboard.Commands });
end;

Parent.client.commandsWindowVisible = commandsWindow;

local function toggleCommandsWindow() -- Line: 556
    -- upvalues: commandsWindow (copy), Parent (copy)
    commandsWindow(Parent.client.dashboard.Commands._instance.Parent ~= Parent.Registry.commands.cmds.env.window._content);
end;

local u67 = UI.new("TextButton")({
    Parent = UI.TopbarFrame,
    Name = "KACommandsButton",
    BackgroundColor3 = Color3.fromRGB(18, 18, 21),
    BackgroundTransparency = 0.08,
    Size = UDim2.fromScale(1, 1),
    SizeConstraint = Enum.SizeConstraint.RelativeYY,
    Text = "",
    Visible = true,
    UI.new("UICorner")({
        CornerRadius = UDim.new(1, 0)
    }),
    UI.new("UIPadding")({
        PaddingLeft = UDim.new(0, 12),
        PaddingRight = UDim.new(0, 12),
        PaddingTop = UDim.new(0, 12),
        PaddingBottom = UDim.new(0, 12)
    }),
    UI.new("ImageLabel")({
        BackgroundTransparency = 1,
        Image = UI.Theme.Image.Terminal,
        Size = UDim2.fromScale(1, 1)
    }),
    Activated = toggleCommandsWindow,
    MouseButton2Click = toggleCommandBarWithSound,
    TouchLongPress = toggleCommandBarWithSound
});
Parent.client.commandsButton = u67;
task.spawn(function() -- Line: 591
    -- upvalues: Parent (copy), u65 (ref), dashboardToggle (copy), UI (copy), u63 (copy), u67 (ref), toggleCommandsWindow (copy), toggleCommandBarWithSound (copy)
    repeat
        task.wait();
    until Parent.client.TopbarPlus;

    u65:Destroy();
    u65 = Parent.client.TopbarPlus.new():setName("KADashboardButton"):setImage(71961243872230):setImageScale(1):setOrder(-1):setEnabled(Parent.client.dashboardButtonEnabled):bindEvent("toggled", dashboardToggle);
    local Instance = u65:getInstance("IconImage");

    if Instance then
        UI.new("UIPadding")({
            Parent = Instance.Parent,
            PaddingLeft = u63,
            PaddingRight = u63,
            PaddingTop = u63,
            PaddingBottom = u63
        });
    end;

    Parent.client.dashboardButton = u65;
    u67:Destroy();
    u67 = Parent.client.TopbarPlus.new():setName("KACommandsButton"):setImage(string.match(UI.Theme.Image.Terminal._value, "%d+$")):setImageScale(1):setOrder(-1):setEnabled(Parent.client.commandsButtonEnabled):bindEvent("toggled", toggleCommandsWindow);
    Parent.client.commandsButton = u67;
    local Instance2 = u67:getInstance("IconImage");

    if Instance2 then
        UI.new("UIPadding")({
            Parent = Instance2.Parent,
            PaddingLeft = UDim.new(0, 12),
            PaddingRight = UDim.new(0, 12),
            PaddingTop = UDim.new(0, 12),
            PaddingBottom = UDim.new(0, 12)
        });
    end;

    for _, v in { u67, u65 } do
        if v.modifyTheme then
            v:modifyTheme({ "Widget", "BorderSize", 0 });
        end;

        local Instance3 = v:getInstance("ClickRegion");

        if Instance3 then
            Instance3.MouseButton2Click:Connect(toggleCommandBarWithSound);
            Instance3.TouchLongPress:Connect(toggleCommandBarWithSound);
        end;

        local Instance4 = v:getInstance("IconSpot");

        if Instance4 then
            Instance4.Size = UDim2.fromOffset(44, 44);
        end;
    end;
end);

function Parent.client.hotkeys.dashboard.callback() -- Line: 660
    -- upvalues: Parent (copy), u65 (ref), u64 (copy), dashboardToggle (copy)
    if not Parent.client.dashboardEnabled then
        return;
    end;

    if Parent.client.dashboardButtonEnabled and Parent.client.TopbarPlus then
        if u65.isSelected then
            u65:deselect();

            return;
        end;

        u65:select();

        return;
    end;

    u64.isSelected = not u64.isSelected;
    dashboardToggle(u64);
end;

u5._exitButton._instance.Activated:Connect(function() -- Line: 676
    -- upvalues: u64 (copy), Parent (copy), u65 (ref), dashboardToggle (copy)
    u64.isSelected = false;

    if Parent.client.TopbarPlus then
        u65:deselect();

        return;
    end;

    dashboardToggle(u64);
end);
local task_spawn = task.spawn;
local log = Parent.log;
local v68 = (os.clock() - os_clock_ret) * 1000;
task_spawn(log, `Dashboard loaded in {math.round(v68)} ms`, "DEBUG");

return Parent.client.dashboard;