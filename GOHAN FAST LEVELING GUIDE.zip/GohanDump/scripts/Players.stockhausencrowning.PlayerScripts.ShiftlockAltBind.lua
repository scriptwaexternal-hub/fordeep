-- Decompiled with Potassium's decompiler.

local ReplicatedStorage = game:GetService("ReplicatedStorage");
local ControlData = require(ReplicatedStorage:WaitForChild("Modules").Metadata.ControlData.ControlData);

local function BOUND_KEY() -- Line: 22
    -- upvalues: ControlData (copy)
    local v1 = ControlData.Controls.CoreControls["Shift Lock"];

    return v1 and v1[1] or "LeftAlt";
end;

local v2 = ControlData.Controls.CoreControls["Shift Lock"];
local u3 = v2 and v2[1] or "LeftAlt";
local LocalPlayer = game:GetService("Players").LocalPlayer;

local function rebind() -- Line: 31
    -- upvalues: LocalPlayer (copy), u3 (ref)
    if not pcall(function() -- Line: 32
        -- upvalues: LocalPlayer (ref), u3 (ref)
        local PlayerModule = LocalPlayer:WaitForChild("PlayerScripts"):WaitForChild("PlayerModule", 10);

        if not PlayerModule then
            return;
        end;

        local CameraModule = PlayerModule:WaitForChild("CameraModule", 10);

        if not CameraModule then
            return;
        end;

        local MouseLockController = CameraModule:WaitForChild("MouseLockController", 10);

        if not MouseLockController then
            return;
        end;

        local v4 = MouseLockController:FindFirstChild("BoundKeys") or MouseLockController:WaitForChild("BoundKeys", 3);

        if v4 then
            v4.Value = u3;

            return;
        end;

        local StringValue = Instance.new("StringValue");
        StringValue.Name = "BoundKeys";
        StringValue.Value = u3;
        StringValue.Parent = MouseLockController;
    end) then
        warn("[ShiftlockAltBind] could not rebind shift lock keys");
    end;
end;

if not pcall(function() -- Line: 32
    -- upvalues: LocalPlayer (copy), u3 (ref)
    local PlayerModule = LocalPlayer:WaitForChild("PlayerScripts"):WaitForChild("PlayerModule", 10);

    if not PlayerModule then
        return;
    end;

    local CameraModule = PlayerModule:WaitForChild("CameraModule", 10);

    if not CameraModule then
        return;
    end;

    local MouseLockController = CameraModule:WaitForChild("MouseLockController", 10);

    if not MouseLockController then
        return;
    end;

    local v5 = MouseLockController:FindFirstChild("BoundKeys") or MouseLockController:WaitForChild("BoundKeys", 3);

    if v5 then
        v5.Value = u3;

        return;
    end;

    local StringValue = Instance.new("StringValue");
    StringValue.Name = "BoundKeys";
    StringValue.Value = u3;
    StringValue.Parent = MouseLockController;
end) then
    warn("[ShiftlockAltBind] could not rebind shift lock keys");
end;

task.delay(5, function() -- Line: 64
    -- upvalues: ControlData (copy), u3 (ref), LocalPlayer (copy)
    local v6 = ControlData.Controls.CoreControls["Shift Lock"];
    local v7 = v6 and v6[1] or "LeftAlt";

    if v7 ~= u3 then
        u3 = v7;

        if not pcall(function() -- Line: 32
            -- upvalues: LocalPlayer (ref), u3 (ref)
            local PlayerModule = LocalPlayer:WaitForChild("PlayerScripts"):WaitForChild("PlayerModule", 10);

            if not PlayerModule then
                return;
            end;

            local CameraModule = PlayerModule:WaitForChild("CameraModule", 10);

            if not CameraModule then
                return;
            end;

            local MouseLockController = CameraModule:WaitForChild("MouseLockController", 10);

            if not MouseLockController then
                return;
            end;

            local v8 = MouseLockController:FindFirstChild("BoundKeys") or MouseLockController:WaitForChild("BoundKeys", 3);

            if v8 then
                v8.Value = u3;

                return;
            end;

            local StringValue = Instance.new("StringValue");
            StringValue.Name = "BoundKeys";
            StringValue.Value = u3;
            StringValue.Parent = MouseLockController;
        end) then
            warn("[ShiftlockAltBind] could not rebind shift lock keys");
        end;
    end;
end);
LocalPlayer:GetAttributeChangedSignal("ShiftLockKey"):Connect(function() -- Line: 70
    -- upvalues: LocalPlayer (copy), u3 (ref)
    local Attribute = LocalPlayer:GetAttribute("ShiftLockKey");

    if type(Attribute) == "string" and #Attribute > 0 then
        u3 = Attribute;

        if not pcall(function() -- Line: 32
            -- upvalues: LocalPlayer (ref), u3 (ref)
            local PlayerModule = LocalPlayer:WaitForChild("PlayerScripts"):WaitForChild("PlayerModule", 10);

            if not PlayerModule then
                return;
            end;

            local CameraModule = PlayerModule:WaitForChild("CameraModule", 10);

            if not CameraModule then
                return;
            end;

            local MouseLockController = CameraModule:WaitForChild("MouseLockController", 10);

            if not MouseLockController then
                return;
            end;

            local v9 = MouseLockController:FindFirstChild("BoundKeys") or MouseLockController:WaitForChild("BoundKeys", 3);

            if v9 then
                v9.Value = u3;

                return;
            end;

            local StringValue = Instance.new("StringValue");
            StringValue.Name = "BoundKeys";
            StringValue.Value = u3;
            StringValue.Parent = MouseLockController;
        end) then
            warn("[ShiftlockAltBind] could not rebind shift lock keys");
        end;
    end;
end);