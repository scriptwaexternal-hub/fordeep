-- Decompiled with Potassium's decompiler.

local Players = game:GetService("Players");
local ReplicatedStorage = game:GetService("ReplicatedStorage");
local Lighting = game:GetService("Lighting");
local SoundService = game:GetService("SoundService");
local TweenService = game:GetService("TweenService");
local RunService = game:GetService("RunService");
local Color3_fromRGB_ret = Color3.fromRGB(188, 224, 235);
local LocalPlayer = Players.LocalPlayer;
local u1 = Lighting:FindFirstChild("UnderwaterBlur") or Instance.new("BlurEffect");
u1.Name = "UnderwaterBlur";
u1.Size = 0;
u1.Enabled = false;
u1.Parent = Lighting;
local u2 = Lighting:FindFirstChild("UnderwaterTint") or Instance.new("ColorCorrectionEffect");
u2.Name = "UnderwaterTint";
u2.TintColor = Color3.new(1, 1, 1);
u2.Saturation = 0;
u2.Enabled = false;
u2.Parent = Lighting;
local v3 = ReplicatedStorage:WaitForChild("Assets"):WaitForChild("Sounds"):WaitForChild("Effects"):WaitForChild("Enviormental"):WaitForChild("Underwater Loop", 10);
local u4;

if v3 then
    u4 = v3:Clone();
    u4.Name = "UnderwaterAmbience";
    u4.Looped = true;
    u4.Volume = 0;
    u4.Parent = SoundService;
else
    u4 = nil;
end;

local u5 = false;
local u6 = {};

local function killTweens() -- Line: 73
    -- upvalues: u6 (copy)
    for _, v in ipairs(u6) do
        v:Cancel();
    end;

    table.clear(u6);
end;

local function fade(p7) -- Line: 78
    -- upvalues: u6 (copy), u1 (copy), u2 (copy), TweenService (copy), Color3_fromRGB_ret (copy), u5 (ref), u4 (ref)
    for _, v in ipairs(u6) do
        v:Cancel();
    end;

    table.clear(u6);
    local TweenInfo_new_ret = TweenInfo.new(p7 and 0.35 or 0.45, Enum.EasingStyle.Quad, Enum.EasingDirection.Out);
    u1.Enabled = true;
    u2.Enabled = true;
    local v8 = TweenService:Create(u1, TweenInfo_new_ret, {
        Size = p7 and 14 or 0
    });
    local v9 = TweenService:Create(u2, TweenInfo_new_ret, {
        TintColor = p7 and Color3_fromRGB_ret or Color3.new(1, 1, 1),
        Saturation = p7 and -0.08 or 0
    });
    table.insert(u6, v8);
    table.insert(u6, v9);
    v8:Play();
    v9:Play();

    if not p7 then
        v8.Completed:Once(function() -- Line: 98
            -- upvalues: u5 (ref), u1 (ref), u2 (ref)
            if not u5 then
                u1.Enabled = false;
                u2.Enabled = false;
            end;
        end);
    end;

    if u4 then
        if p7 and not u4.IsPlaying then
            u4:Play();
        end;

        local v10 = TweenService:Create(u4, TweenInfo_new_ret, {
            Volume = p7 and 0.5 or 0
        });
        table.insert(u6, v10);
        v10:Play();

        if not p7 then
            v10.Completed:Once(function() -- Line: 115
                -- upvalues: u5 (ref), u4 (ref)
                if not u5 then
                    u4:Stop();
                end;
            end);
        end;
    end;
end;

local function setUnderwater(p11) -- Line: 122
    -- upvalues: u5 (ref), fade (copy)
    if u5 == p11 then
        return;
    end;

    u5 = p11;
    fade(p11);
end;

local u12 = 0;
RunService.Heartbeat:Connect(function(p13) -- Line: 131
    -- upvalues: u12 (ref), LocalPlayer (copy), u5 (ref), fade (copy)
    u12 = u12 + p13;

    if u12 < 0.08 then
        return;
    end;

    u12 = 0;
    local Character = LocalPlayer.Character;
    local workspace_CurrentCamera = workspace.CurrentCamera;

    if not (Character and workspace_CurrentCamera) then
        if u5 == false then
            return;
        end;

        u5 = false;
        fade(false);

        return;
    end;

    local Attribute = Character:GetAttribute("SwimSurfaceY");

    if typeof(Attribute) ~= "number" then
        if u5 == false then
            return;
        end;

        u5 = false;
        fade(false);

        return;
    end;

    local v14 = workspace_CurrentCamera.CFrame.Position.Y < Attribute - 0.15;

    if u5 == v14 then
        return;
    end;

    u5 = v14;
    fade(v14);
end);
LocalPlayer.CharacterRemoving:Connect(function() -- Line: 153
    -- upvalues: u5 (ref), fade (copy)
    if u5 == false then
        return;
    end;

    u5 = false;
    fade(false);
end);