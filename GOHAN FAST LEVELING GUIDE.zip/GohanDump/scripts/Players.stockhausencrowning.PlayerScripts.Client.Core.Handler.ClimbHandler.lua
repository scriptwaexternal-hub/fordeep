-- Decompiled with Potassium's decompiler.

local ReplicatedStorage = game:GetService("ReplicatedStorage");
local RunService = game:GetService("RunService");
local UserInputService = game:GetService("UserInputService");
local Debris = game:GetService("Debris");
local Players = game:GetService("Players");
local Assets = ReplicatedStorage.Assets;
local Modules = ReplicatedStorage:WaitForChild("Modules");
local Shared = Modules.Shared;
local GlobalFunctions = require(Modules.GlobalFunctions);
local AnimationManager = require(Shared.AnimationManager);
local Platform = require(Shared.Platform);
local ServerRemote = ReplicatedStorage.Remotes.ServerRemote;
local workspace_World = workspace.World;
local u1 = { workspace_World.Visuals, workspace_World.Live };
local LocalPlayer = Players.LocalPlayer;
local u2 = { 0, 1.5, -1.5 };
local u3 = {
    W = 1,
    A = 2,
    S = 3,
    D = 4
};
local u4 = nil;

local function getClimbEnergy() -- Line: 153
    -- upvalues: LocalPlayer (copy)
    return LocalPlayer:FindFirstChild("Climb Energy", true);
end;

local function raycastForWall(p5) -- Line: 165
    -- upvalues: u2 (copy), GlobalFunctions (copy), u1 (copy)
    local Unit = p5.CFrame.LookVector.Unit;

    for _, v in ipairs(u2) do
        local v6 = p5.Position + Vector3.new(0, v, 0);
        local v7 = GlobalFunctions.CastRay(v6, Unit * 3.5, u1);

        if v7 then
            return v7;
        end;
    end;

    return nil;
end;

local function stopClimb(p8, p9) -- Line: 179
    -- upvalues: GlobalFunctions (copy), Debris (copy), AnimationManager (copy), ServerRemote (copy), u4 (ref)
    if not (p8 and p8.active) then
        return;
    end;

    p8.active = false;

    for _, v in ipairs(p8.connections) do
        if v.Connected then
            v:Disconnect();
        end;
    end;

    if p8.humanoid and p8.humanoid.Parent then
        p8.humanoid.AutoRotate = true;
    end;

    if p8.attachment and p8.attachment.Parent then
        p8.attachment:Destroy();
    end;

    if not p9 and (p8.root and p8.root.Parent) then
        p8.root.AssemblyLinearVelocity = Vector3.new(0, 0, 0);
    end;

    if p8.gui and p8.gui.Parent then
        for _, descendant in ipairs(p8.gui:GetDescendants()) do
            if descendant:IsA("Frame") then
                GlobalFunctions.Tween({
                    Instance = descendant
                }, {
                    BackgroundTransparency = 1
                });
            end;
        end;

        Debris:AddItem(p8.gui, 1);
    end;

    AnimationManager.StopAnimation(p8.character, "Climb Idle", {
        Looped = true
    });
    AnimationManager.StopAnimation(p8.character, "Climb Move", {
        Looped = true
    });
    ServerRemote:FireServer("Climb", {
        Action = "Terminate"
    });

    if u4 == p8 then
        u4 = nil;
    end;
end;

local function updateMoveAnimation(p10) -- Line: 231
    -- upvalues: AnimationManager (copy)
    local directions = p10.directions;
    local v11 = (directions[1] ~= 0 or (directions[2] ~= 0 or (directions[3] ~= 0 or (directions[4] ~= 0 or p10.padX ~= 0)))) and true or p10.padY ~= 0;

    if not v11 or p10.isMoving then
        if not v11 and p10.isMoving then
            p10.isMoving = false;
            AnimationManager.StopAnimation(p10.character, "Climb Move");
        end;

        return;
    end;

    p10.isMoving = true;
    AnimationManager.PlayAnimation(p10.character, "Climb Move", {
        Looped = true
    });
end;

local function wallFaceCFrame(p12) -- Line: 268
    return CFrame.lookAt(Vector3.new(0, 0, 0), -p12);
end;

local function beginCornerTransition(u13, p14) -- Line: 272
    u13.normal = p14.Normal;
    u13.position = p14.Position;
    local root = u13.root;
    root.CFrame = CFrame.new(p14.Position + p14.Normal / 2) * root.CFrame.Rotation;
    u13.transitioning = true;
    task.delay(0.15, function() -- Line: 290
        -- upvalues: u13 (copy)
        u13.transitioning = false;
    end);
end;

local function scanSurface(p15) -- Line: 295
    -- upvalues: GlobalFunctions (copy), u1 (copy), stopClimb (copy), beginCornerTransition (copy)
    if p15.transitioning then
        return;
    end;

    local root = p15.root;
    local v16 = CFrame.new(root.Position) * CFrame.lookAt(Vector3.new(0, 0, 0), -p15.normal).Rotation;
    local v17 = GlobalFunctions.CastRay(root.Position, v16.LookVector.Unit * 2, u1);
    local Position = (v16 * CFrame.new(0.5, 0, 1)).Position;
    local v18 = GlobalFunctions.CastRay(Position, v16.RightVector.Unit * 2, u1);
    local Position2 = (v16 * CFrame.new(-0.5, 0, 1)).Position;
    local v19 = GlobalFunctions.CastRay(Position2, v16.RightVector.Unit * -2, u1);
    local Position3 = (v16 * CFrame.new(0.5, 0, -1)).Position;
    local v20 = GlobalFunctions.CastRay(Position3, v16.RightVector.Unit * -2, u1);
    local Position4 = (v16 * CFrame.new(-0.5, 0, -1)).Position;
    local v21 = GlobalFunctions.CastRay(Position4, v16.RightVector.Unit * 2, u1);

    if (p15.directions[1] > 0 and true or p15.padY > 0.25) and os.clock() - p15.startedAt >= 0.35 then
        local Position5 = (v16 * CFrame.new(0, 2, -1.5)).Position;
        local v22 = GlobalFunctions.CastRay(Position5, Vector3.new(0, -2, 0), u1);

        if v22 then
            local Position6 = v22.Position;
            stopClimb(p15, true);
            root.AssemblyLinearVelocity = Vector3.new(0, 0, 0);
            GlobalFunctions.Tween({
                Duration = 0.2,
                Instance = root
            }, {
                CFrame = CFrame.new(Position6) * CFrame.new(0, 4, 0)
            });

            return;
        end;
    end;

    if v18 or (v19 or (v17 or (v20 or v21))) then
        p15.surfaceMisses = 0;
    end;

    if v18 then
        beginCornerTransition(p15, v18);

        return;
    end;

    if v19 then
        beginCornerTransition(p15, v19);

        return;
    end;

    if v17 then
        p15.normal = v17.Normal;
        p15.position = v17.Position;
        local v23 = v17.Normal:Dot(v17.Position + v17.Normal / 2 - root.Position);
        root.CFrame = root.CFrame + v17.Normal * v23;

        return;
    end;

    if v20 and not v21 then
        beginCornerTransition(p15, v20);

        return;
    end;

    if v21 and not v20 then
        beginCornerTransition(p15, v21);

        return;
    end;

    p15.surfaceMisses = p15.surfaceMisses + 1;

    if p15.surfaceMisses >= 6 then
        stopClimb(p15);
    end;
end;

local function bindInput(u24) -- Line: 392
    -- upvalues: UserInputService (copy), stopClimb (copy), u3 (copy)
    local v28 = UserInputService.InputBegan:Connect(function(p25, p26) -- Line: 393
        -- upvalues: u24 (copy), stopClimb (ref), u3 (ref)
        if p26 or not u24.active then
            return;
        end;

        local Name = p25.KeyCode.Name;

        if Name == "Space" or Name == "ButtonA" then
            if os.clock() - u24.startedAt < 0.25 then
                return;
            end;

            stopClimb(u24);

            return;
        end;

        local v27 = u3[Name];

        if v27 then
            u24.directions[v27] = (Name == "A" or Name == "S") and -1 or 1;
        end;
    end);
    local v31 = UserInputService.InputEnded:Connect(function(p29) -- Line: 413
        -- upvalues: u24 (copy), u3 (ref)
        if not u24.active then
            return;
        end;

        local v30 = u3[p29.KeyCode.Name];

        if v30 then
            u24.directions[v30] = 0;
        end;
    end);
    local v34 = UserInputService.InputChanged:Connect(function(p32, p33) -- Line: 427
        -- upvalues: u24 (copy)
        if p33 or not u24.active then
            return;
        end;

        if p32.KeyCode ~= Enum.KeyCode.Thumbstick1 then
            return;
        end;

        local X = p32.Position.X;
        local Y = p32.Position.Y;
        u24.padX = math.abs(X) >= 0.25 and X and X or 0;
        u24.padY = math.abs(Y) >= 0.25 and Y and Y or 0;
    end);
    table.insert(u24.connections, v28);
    table.insert(u24.connections, v31);
    table.insert(u24.connections, v34);
end;

local function bindHeartbeat(u35) -- Line: 444
    -- upvalues: RunService (copy), stopClimb (copy), updateMoveAnimation (copy), scanSurface (copy)
    local v39 = RunService.Heartbeat:Connect(function(p36) -- Line: 446
        -- upvalues: u35 (copy), stopClimb (ref), updateMoveAnimation (ref), scanSurface (ref)
        if not (u35.active and u35.character.Parent) then
            stopClimb(u35);

            return;
        end;

        local root = u35.root;
        local directions = u35.directions;
        local CFrame_lookAt_ret = CFrame.lookAt(Vector3.new(0, 0, 0), -u35.normal);
        local v37 = CFrame_lookAt_ret.UpVector * (directions[1] + directions[3] + u35.padY) + CFrame_lookAt_ret.RightVector * (directions[2] + directions[4] + u35.padX);

        if v37.Magnitude > 1 then
            v37 = v37.Unit;
        end;

        u35.linearVelocity.VectorVelocity = v37 * 16;
        updateMoveAnimation(u35);
        scanSurface(u35);

        if u35.active then
            local CFrame_lookAt_ret2 = CFrame.lookAt(Vector3.new(0, 0, 0), -u35.normal);
            local v38 = 1 - math.exp(-10 * p36);
            u35.facing = u35.facing:Lerp(CFrame_lookAt_ret2, v38);
            root.CFrame = CFrame.new(root.Position) * u35.facing.Rotation;
        end;
    end);
    table.insert(u35.connections, v39);
end;

return {
    Execute = function(p40) -- Line: 496, Name: Execute
        -- upvalues: u4 (ref), stopClimb (copy), GlobalFunctions (copy), raycastForWall (copy), ServerRemote (copy), Platform (copy), UserInputService (copy), AnimationManager (copy), Assets (copy), LocalPlayer (copy), bindInput (copy), RunService (copy), updateMoveAnimation (copy), scanSurface (copy)
        local Character = p40.Character;

        if not Character then
            return;
        end;

        if u4 then
            stopClimb(u4);
        end;

        local RootAndHumanoid, v41 = GlobalFunctions.GetRootAndHumanoid(Character);

        if not (RootAndHumanoid and v41) then
            return;
        end;

        local v42 = raycastForWall(RootAndHumanoid);

        if not v42 then
            return;
        end;

        v41.AutoRotate = false;
        ServerRemote:FireServer("Run", {
            Action = "Terminate"
        });
        ServerRemote:FireServer("Climb", {
            Action = "Execute"
        });
        local u43 = {
            active = true,
            padX = 0,
            padY = 0,
            isMoving = false,
            transitioning = false,
            surfaceMisses = 0,
            character = Character,
            root = RootAndHumanoid,
            humanoid = v41,
            normal = v42.Normal,
            position = v42.Position,
            facing = CFrame.lookAt(Vector3.new(0, 0, 0), -v42.Normal),
            directions = { 0, 0, 0, 0 },
            startedAt = os.clock(),
            connections = {}
        };
        u4 = u43;
        local u44 = Platform.ActiveGamepad();

        if u44 then
            pcall(function() -- Line: 553
                -- upvalues: UserInputService (ref), u44 (copy), u43 (copy)
                for _, v in ipairs(UserInputService:GetGamepadState(u44)) do
                    if v.KeyCode == Enum.KeyCode.Thumbstick1 then
                        local X = v.Position.X;
                        local Y = v.Position.Y;
                        u43.padX = math.abs(X) >= 0.25 and X and X or 0;
                        u43.padY = math.abs(Y) >= 0.25 and Y and Y or 0;

                        return;
                    end;
                end;
            end);
        end;

        RootAndHumanoid.CFrame = CFrame.lookAt(v42.Position + v42.Normal / 2, v42.Position);
        local Attachment = Instance.new("Attachment");
        Attachment.Name = "ClimbAttachment";
        Attachment.Parent = RootAndHumanoid;
        u43.attachment = Attachment;
        local LinearVelocity = Instance.new("LinearVelocity");
        LinearVelocity.Attachment0 = Attachment;
        LinearVelocity.MaxForce = math.max(RootAndHumanoid.AssemblyMass, 1) * 12000;
        LinearVelocity.VectorVelocity = Vector3.new(0, 0, 0);
        LinearVelocity.Parent = Attachment;
        u43.linearVelocity = LinearVelocity;
        AnimationManager.PlayAnimation(Character, "Climb Idle", {
            Looping = true
        });
        local u45 = Assets.Gui.Climb.ClimbGui:Clone();
        u45.Name = "NewClimbGui";
        u45.Parent = Character;
        u45.Adornee = RootAndHumanoid;
        u43.gui = u45;
        local v46 = LocalPlayer:FindFirstChild("Climb Energy", true);

        if v46 then
            u45.Meter.Bar.Size = UDim2.new(math.clamp(v46.Value / 100, 0, 1), 0, 1, 0);
            local v48 = v46.Changed:Connect(function(p47) -- Line: 594
                -- upvalues: u45 (copy)
                local math_clamp_ret = math.clamp(p47 / 100, 0, 1);
                u45.Meter.Bar:TweenSize(UDim2.new(math_clamp_ret, 0, 1, 0), "Out", "Sine", 0.1, true);
            end);
            table.insert(u43.connections, v48);
        end;

        local v49 = Character.AncestryChanged:Connect(function() -- Line: 603
            -- upvalues: Character (copy), stopClimb (ref), u43 (copy)
            if not Character.Parent then
                stopClimb(u43);
            end;
        end);
        table.insert(u43.connections, v49);
        local v50 = Character:GetAttributeChangedSignal("State_Climbing"):Connect(function() -- Line: 622
            -- upvalues: Character (copy), stopClimb (ref), u43 (copy)
            if not Character:GetAttribute("State_Climbing") then
                stopClimb(u43);
            end;
        end);
        table.insert(u43.connections, v50);
        local v51 = v41.Died:Connect(function() -- Line: 632
            -- upvalues: stopClimb (ref), u43 (copy)
            stopClimb(u43);
        end);
        table.insert(u43.connections, v51);
        bindInput(u43);
        local v55 = RunService.Heartbeat:Connect(function(p52) -- Line: 446
            -- upvalues: u43 (copy), stopClimb (ref), updateMoveAnimation (ref), scanSurface (ref)
            if not (u43.active and u43.character.Parent) then
                stopClimb(u43);

                return;
            end;

            local root = u43.root;
            local directions = u43.directions;
            local CFrame_lookAt_ret = CFrame.lookAt(Vector3.new(0, 0, 0), -u43.normal);
            local v53 = CFrame_lookAt_ret.UpVector * (directions[1] + directions[3] + u43.padY) + CFrame_lookAt_ret.RightVector * (directions[2] + directions[4] + u43.padX);

            if v53.Magnitude > 1 then
                v53 = v53.Unit;
            end;

            u43.linearVelocity.VectorVelocity = v53 * 16;
            updateMoveAnimation(u43);
            scanSurface(u43);

            if u43.active then
                local CFrame_lookAt_ret2 = CFrame.lookAt(Vector3.new(0, 0, 0), -u43.normal);
                local v54 = 1 - math.exp(-10 * p52);
                u43.facing = u43.facing:Lerp(CFrame_lookAt_ret2, v54);
                root.CFrame = CFrame.new(root.Position) * u43.facing.Rotation;
            end;
        end);
        table.insert(u43.connections, v55);
    end
};