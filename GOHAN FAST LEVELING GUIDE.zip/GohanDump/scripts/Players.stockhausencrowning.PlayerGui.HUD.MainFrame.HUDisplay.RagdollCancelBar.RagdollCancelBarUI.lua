-- Decompiled with Potassium's decompiler.

local Players = game:GetService("Players");
local RunService = game:GetService("RunService");
local LocalPlayer = Players.LocalPlayer;
local script_Parent = script.Parent;
local Meter = script_Parent.Meter;
local HoverLabel = script_Parent.HoverLabel;
local u1 = nil;
script_Parent.MouseEnter:Connect(function() -- Line: 19
    -- upvalues: HoverLabel (copy)
    HoverLabel.Visible = true;
end);
script_Parent.MouseLeave:Connect(function() -- Line: 20
    -- upvalues: HoverLabel (copy)
    HoverLabel.Visible = false;
end);

local function watch(u2) -- Line: 22
    -- upvalues: u1 (ref), Meter (copy), RunService (copy)
    local function update() -- Line: 23
        -- upvalues: u2 (copy), u1 (ref), Meter (ref), RunService (ref)
        local u3 = u2:GetAttribute("RagdollCancelCDUntil") or 0;

        if u1 then
            u1:Disconnect();
            u1 = nil;
        end;

        if u3 - workspace:GetServerTimeNow() <= 0 then
            Meter.Size = UDim2.fromScale(1, 1);

            return;
        end;

        u1 = RunService.Heartbeat:Connect(function() -- Line: 32
            -- upvalues: u3 (copy), u1 (ref), Meter (ref)
            local v4 = u3 - workspace:GetServerTimeNow();

            if v4 > 0 then
                Meter.Size = UDim2.fromScale(math.clamp(1 - v4 / 15, 0, 1), 1);

                return;
            end;

            if u1 then
                u1:Disconnect();
                u1 = nil;
            end;

            Meter.Size = UDim2.fromScale(1, 1);
        end);
    end;

    u2:GetAttributeChangedSignal("RagdollCancelCDUntil"):Connect(update);
    update();
end;

Meter.Size = UDim2.fromScale(1, 1);

if LocalPlayer.Character then
    local Character = LocalPlayer.Character;

    local function v7() -- Line: 23
        -- upvalues: Character (copy), u1 (ref), Meter (copy), RunService (copy)
        local u5 = Character:GetAttribute("RagdollCancelCDUntil") or 0;

        if u1 then
            u1:Disconnect();
            u1 = nil;
        end;

        if u5 - workspace:GetServerTimeNow() <= 0 then
            Meter.Size = UDim2.fromScale(1, 1);

            return;
        end;

        u1 = RunService.Heartbeat:Connect(function() -- Line: 32
            -- upvalues: u5 (copy), u1 (ref), Meter (ref)
            local v6 = u5 - workspace:GetServerTimeNow();

            if v6 > 0 then
                Meter.Size = UDim2.fromScale(math.clamp(1 - v6 / 15, 0, 1), 1);

                return;
            end;

            if u1 then
                u1:Disconnect();
                u1 = nil;
            end;

            Meter.Size = UDim2.fromScale(1, 1);
        end);
    end;

    Character:GetAttributeChangedSignal("RagdollCancelCDUntil"):Connect(v7);
    v7();
end;

LocalPlayer.CharacterAdded:Connect(watch);