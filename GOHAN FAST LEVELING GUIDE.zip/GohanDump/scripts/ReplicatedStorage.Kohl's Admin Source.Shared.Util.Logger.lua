-- Decompiled with Potassium's decompiler.

local u1 = {
    limit = 100000
};
u1.__index = u1;
local u2 = { "INFO", "WARN", "ERROR", "DEBUG", "CHAT", "COMMAND", "PURCHASE", "DAMAGE", "DEATH", "KILL", "JOIN", "LEAVE" };

function u1.new(p3: boolean?) -- Line: 49
    -- upvalues: u1 (copy)
    return setmetatable({
        logs = {},
        debug = p3
    }, u1);
end;

function u1.sortTime(p4, p5) -- Line: 53
    return p4[3] < p5[3];
end;

function u1.encode(p6: table, p7: string) -- Line: 57
    -- upvalues: u2 (copy)
    local v8 = table.find(u2, p7) or 1;

    return string.char(v8);
end;

function u1.decode(p9: table, p10: string) -- Line: 61
    -- upvalues: u2 (copy)
    return u2[string.byte(p10)] or "UNKNOWN";
end;

function u1.log(p11: table, p12: string, p13: string, p14: number?, p15: boolean?) -- Line: 65
    -- upvalues: u1 (copy)
    if p13 ~= "DEBUG" or p11.debug then
        local v16 = {};
        local v17 = u1:encode(p13);
        local ServerTimeNow = workspace:GetServerTimeNow();
        local v18;

        if p14 then
            v18 = math.abs(p14);
        else
            v18 = nil;
        end;

        v16[1], v16[2], v16[3], v16[4] = p12, v17, ServerTimeNow, v18;

        if not p15 then
            table.insert(p11.logs, v16);
        end;

        return v16;
    end;
end;

return u1;