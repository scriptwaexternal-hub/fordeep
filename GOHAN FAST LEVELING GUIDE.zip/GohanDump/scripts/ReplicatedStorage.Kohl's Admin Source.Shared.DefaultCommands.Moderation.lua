-- Decompiled with Potassium's decompiler.

return {
    {
        name = "bans",
        description = "Shows the bans in a separate window.",
        aliases = {},
        args = {},

        envClient = function(u1) -- Line: 9, Name: envClient
            local u2 = {};
            task.defer(function() -- Line: 11
                -- upvalues: u1 (copy), u2 (copy)
                while not u1.client do
                    task.wait();
                end;

                local u3 = u1.UI.new("Window")({
                    Icon = "rbxassetid://71961243872230",
                    Title = "Bans",
                    Parent = u1.UI.LayerTopInset
                });
                u1.UI.edit(u3, {
                    [u1.UI.Event] = {
                        Visible = function() -- Line: 22, Name: Visible
                            -- upvalues: u3 (copy), u1 (ref)
                            if not u3._instance.Visible then
                                u1.UI.edit(u1.client.dashboard.Tabs, { u1.client.dashboard.Bans });
                            end;
                        end
                    }
                });
                u2.window = u3;
            end);

            return u2;
        end,

        runClient = function(p4) -- Line: 36, Name: runClient
            p4._K.UI.edit(p4.env.window, {
                Visible = true,
                p4._K.client.dashboard.Bans
            });
            p4._K.client.dashboard.Bans._instance.Visible = true;
        end
    },
    {
        name = "members",
        description = "Shows the roled members in a separate window.",
        aliases = { "admins", "roles" },
        args = {},

        envClient = function(u5) -- Line: 49, Name: envClient
            local u6 = {};
            task.defer(function() -- Line: 51
                -- upvalues: u5 (copy), u6 (copy)
                while not u5.client do
                    task.wait();
                end;

                local u7 = u5.UI.new("Window")({
                    Icon = "rbxassetid://71961243872230",
                    Title = "Members",
                    Parent = u5.UI.LayerTopInset
                });
                u5.UI.edit(u7, {
                    [u5.UI.Event] = {
                        Visible = function() -- Line: 62, Name: Visible
                            -- upvalues: u7 (copy), u5 (ref)
                            if not u7._instance.Visible then
                                u5.UI.edit(u5.client.dashboard.Tabs, { u5.client.dashboard.Members });
                            end;
                        end
                    }
                });
                u6.window = u7;
            end);

            return u6;
        end,

        runClient = function(p8) -- Line: 76, Name: runClient
            p8._K.UI.edit(p8.env.window, {
                Visible = true,
                p8._K.client.dashboard.Members
            });
            p8._K.client.dashboard.Members._instance.Visible = true;
        end
    },
    {
        name = "servers",
        description = "Shows the live game servers in a separate window.",
        args = {},

        envClient = function(u9) -- Line: 88, Name: envClient
            local u10 = {};
            task.defer(function() -- Line: 90
                -- upvalues: u9 (copy), u10 (copy)
                while not u9.client do
                    task.wait();
                end;

                local u11 = u9.UI.new("Window")({
                    Icon = "rbxassetid://71961243872230",
                    Title = "Servers",
                    Parent = u9.UI.LayerTopInset
                });
                u9.UI.edit(u11, {
                    [u9.UI.Event] = {
                        Visible = function() -- Line: 101, Name: Visible
                            -- upvalues: u11 (copy), u9 (ref)
                            if not u11._instance.Visible then
                                u9.UI.edit(u9.client.dashboard.Tabs, { u9.client.dashboard.Servers });
                            end;
                        end
                    }
                });
                u10.window = u11;
            end);

            return u10;
        end,

        runClient = function(p12) -- Line: 115, Name: runClient
            p12._K.UI.edit(p12.env.window, {
                Visible = true,
                p12._K.client.dashboard.Servers
            });
            p12._K.client.dashboard.Servers._instance.Visible = true;
        end
    },
    {
        name = "ban",
        description = "Bans one or more user(s) by UserId.",
        args = { {
                type = "userIds",
                name = "User(s)",
                description = "The Player(s) or UserId(s) to ban.",
                lowerRank = true,
                ignoreSelf = true
            }, {
                type = "timeSimple",
                name = "Duration",
                description = "The duration for the ban.",
                optional = true
            }, {
                type = "string",
                name = "Reason",
                description = "The reason for the ban.",
                optional = true
            } },

        run = function(u13: any, p14: any, p15: number?, p16: string?) -- Line: 149, Name: run
            local v17 = not u13._K.Auth.hasRestrictedRole(u13.from) and 0 or p15;

            if type(p16) == "string" then
                p16 = string.sub(p16, 1, 400);
            end;

            local v18 = not u13._K.Auth.hasPermission(u13.from, "banasync") and 0 or v17;
            local v19 = (not v18 or v18 == 0) and "Server" or (v18 == -1 and "Permanently" or u13._K.Util.Time.readable(v18));
            local Players = u13._K.Service.Players:GetPlayers();
            local u20 = {};
            local v21 = {};

            for _, v in p14 do
                local v22 = v;
                local v23 = nil;

                for _, v2 in Players do
                    if v2.UserId == tonumber(v22) then
                        v2:Kick(p16 or "No reason.");
                        table.insert(u20, v2.Name);
                        v23 = true;
                        break;
                    end;
                end;

                if not v23 then
                    table.insert(v21, v22);
                end;
            end;

            u13._K.Auth.banUsers(p14, p16, v18, u13.from);
            local v24 = u13._K.Util.Tasks.new();

            for _, v in v21 do
                v24:add(function() -- Line: 189
                    -- upvalues: u20 (copy), u13 (copy), v (copy)
                    local Username = u13._K.Util.getUserInfo(v).Username;
                    table.insert(u20, Username);
                end);
            end;

            v24:wait();
            u13._K.Remote.Notify:Fire(u13.fromPlayer, {
                Text = `Banned <b>{table.concat(u20, ", ")}</b> for <b>{p16 or "no reason"}</b>.\nDuration: <b>{v19}</b>`
            });
        end
    },
    {
        name = "unban",
        description = "Unbans one or more player(s).",
        args = { {
                type = "bans",
                name = "Player(s)",
                description = "The player(s) to unban."
            } },

        run = function(p25, p26) -- Line: 213, Name: run
            local v27 = {};

            for _, v in p26 do
                local v28 = p25._K.Data.bans[v];

                if v28 then
                    table.insert(v27, v28[1] or v);
                end;
            end;

            p25._K.Auth.unbanUsers(p26, p25.from, true);
            p25._K.Remote.Notify:Fire(p25.fromPlayer, {
                Text = `<b>Unbanned:</b> <i>{table.concat(v27, ", ")}</i>`
            });
        end
    },
    {
        name = "kick",
        description = "Kicks one or more player(s).",
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) to kick.",
                ignoreSelf = true,
                lowerRank = true
            }, {
                type = "string",
                name = "Reason",
                description = "The reason for the kick.",
                optional = true
            } },

        run = function(p29: any, p30: any, p31: string?) -- Line: 246, Name: run
            for _, v in p30 do
                v:Kick(p31);
            end;

            local Names = p29._K.Util.Suggest.getNames(p30);
            p29._K.Remote.Notify:Fire(p29.fromPlayer, {
                Text = `<b>Kicked:</b> <i>{table.concat(Names, ", ")}</i>`
            });
        end
    },
    {
        name = "crash",
        description = "Crashes one or more player(s).",
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) to crash.",
                ignoreSelf = true,
                lowerRank = true
            } },

        envClient = function(p32) -- Line: 269, Name: envClient
            p32.Remote.Crash:Connect(function() -- Line: 270
                while true do

                end;
            end);
        end,

        env = function(p33) -- Line: 275, Name: env
            return {
                remote = p33.Remote.Crash
            };
        end,

        run = function(p34: any, p35: any, p36: string?) -- Line: 278, Name: run
            for _, v in p35 do
                p34.env.remote:Fire(v);
            end;
        end
    },
    {
        name = "mute",
        description = "Mutes one or more player(s).",
        aliases = { "silence", "shush", "shh" },
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) to mute.",
                lowerRank = true
            } },

        envClient = function(u37) -- Line: 296, Name: envClient
            u37.Remote.Mute:Connect(function(p38) -- Line: 297
                -- upvalues: u37 (copy)
                local v39 = p38 and "muted" or "unmuted";

                if u37.Service.TextChat.ChatVersion ~= Enum.ChatVersion.LegacyChatService then
                    local v40 = u37.Service.TextChat:FindFirstChildOfClass("ChatInputBarConfiguration");

                    if v40 then
                        v40.Enabled = not p38;
                    end;

                    local TextChannels = u37.Service.TextChat:FindFirstChild("TextChannels");

                    if not TextChannels then
                        return;
                    end;

                    TextChannels:FindFirstChild("RBXSystem"):DisplaySystemMessage((`<font color="#{u37.UI.Theme[p38 and "Invalid" or "Valid"]._value:ToHex()}"><b>You have been {v39}!</b></font>`));

                    return;
                end;

                u37.Service.StarterGui:SetCore("ChatBarDisabled", p38);
                local StarterGui = u37.Service.StarterGui;
                local v41 = {
                    Text = `You have been {v39}!`
                };
                local v42;

                if p38 then
                    v42 = Color3.new(1, 0, 0);
                else
                    v42 = Color3.new(0, 1, 0);
                end;

                v41.Color = v42;
                StarterGui:SetCore("ChatMakeSystemMessage", v41);
            end);
        end,

        env = function(p43) -- Line: 321, Name: env
            local u44 = {};
            p43.Service.TextChat.DescendantAdded:Connect(function(p45) -- Line: 323
                -- upvalues: u44 (copy)
                if p45:IsA("TextSource") and u44[p45.UserId] then
                    p45.CanSend = false;
                end;
            end);
            p43.Data.muted = u44;

            return {
                muted = u44,
                remote = p43.Remote.Mute
            };
        end,

        run = function(p46, p47) -- Line: 334, Name: run
            for _, v in p47 do
                local v48 = p46._K.Data.muted[v.UserId];

                if v48 then
                    v48:Disconnect();
                end;

                p46.env.remote:Fire(v, true);
                p46.env.muted[v.UserId] = p46._K.Service.TextChat.DescendantAdded:Connect(function(p49) -- Line: 344
                    -- upvalues: v (copy)
                    if p49:IsA("TextSource") and (p49.UserId == v.UserId and p49.CanSend) then
                        p49:SetAttribute("_KCouldSend", true);
                        p49.CanSend = false;
                    end;
                end);
                local v50 = v;

                for _, descendant in p46._K.Service.TextChat:GetDescendants() do
                    if descendant:IsA("TextSource") and (descendant.UserId == v50.UserId and descendant.CanSend) then
                        descendant:SetAttribute("_KCouldSend", true);
                        descendant.CanSend = false;
                    end;
                end;
            end;

            local Names = p46._K.Util.Suggest.getNames(p47);
            p46._K.Remote.Notify:Fire(p46.fromPlayer, {
                Text = `<b>Muted:</b> <i>{table.concat(Names, ", ")}</i>`
            });
        end
    },
    {
        name = "unmute",
        description = "Unmutes one or more player(s).",
        aliases = { "unsilence", "unshush", "unshh" },
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) to unmute.",
                lowerRank = true
            } },

        run = function(p51, p52) -- Line: 383, Name: run
            for _, v in p52 do
                local v53 = p51._K.Data.muted[v.UserId];

                if v53 then
                    v53:Disconnect();
                end;

                p51._K.Data.muted[v.UserId] = nil;
                local v54 = v;

                for _, descendant in p51._K.Service.TextChat:GetDescendants() do
                    if descendant:IsA("TextSource") and (descendant.UserId == v54.UserId and descendant:GetAttribute("_KCouldSend")) then
                        descendant:SetAttribute("_KCouldSend", nil);
                        descendant.CanSend = true;
                    end;
                end;

                p51._K.Remote.Mute:Fire(v54);
            end;

            local Names = p51._K.Util.Suggest.getNames(p52);
            p51._K.Remote.Notify:Fire(p51.fromPlayer, {
                Text = `<b>Unmuted:</b> <i>{table.concat(Names, ", ")}</i>`
            });
        end
    },
    {
        name = "punish",
        description = "Punishes one or more player(s) to the void.",
        aliases = {},
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) to punish.",
                shouldRequest = true
            } },

        env = function(p55) -- Line: 423, Name: env
            local u56 = {};
            p55.Service.Players.PlayerRemoving:Connect(function(p57) -- Line: 425
                -- upvalues: u56 (copy)
                local v58 = u56[p57];

                if v58 then
                    v58:Destroy();
                    u56[p57] = nil;
                end;
            end);

            return {
                punished = u56
            };
        end,

        run = function(p59, p60) -- Line: 435, Name: run
            for _, v in p60 do
                if v.Character then
                    pcall(game.Destroy, p59.env.punished[v]);
                    p59.env.punished[v] = v.Character;
                    v.Character.Parent = nil;
                    v.Character = nil;
                end;
            end;
        end
    },
    {
        name = "unpunish",
        description = "Unpunishes one or more player(s) from the void.",
        aliases = {},
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) to forgive."
            } },

        envClient = function(p61) -- Line: 457, Name: envClient
            local function reactivate(p62) -- Line: 458
                p62.Enabled = true;
            end;

            p61.Remote.RefreshLocalScripts:Connect(function(p63: userdata) -- Line: 461
                -- upvalues: reactivate (copy)
                for _, descendant in p63:GetDescendants() do
                    if descendant:IsA("LocalScript") and descendant.Enabled then
                        descendant.Enabled = false;
                        task.defer(reactivate, descendant);
                    end;
                end;
            end);
        end,

        env = function(p64) -- Line: 470, Name: env
            return {
                remote = p64.Remote.RefreshLocalScripts,

                reparent = function(p65) -- Line: 473, Name: reparent
                    p65.Parent = workspace;
                end
            };
        end,

        run = function(p66, p67) -- Line: 479, Name: run
            local punished = p66._K.Registry.commands.punish.env.punished;

            for _, v in p67 do
                local v68 = punished[v];

                if v68 then
                    punished[v] = nil;

                    if v.Character then
                        v68:Destroy();

                        return;
                    end;

                    if pcall(p66.env.reparent, v68) then
                        v.Character = v68;
                        p66.env.remote:Fire(v, v68);
                    else
                        local Pivot = v68:GetPivot();
                        v:LoadCharacterAsync();
                        v.Character:PivotTo(Pivot);
                        p66._K.Remote.Refresh:Fire(v);
                        v68:Destroy();
                    end;
                end;
            end;
        end
    },
    {
        name = "name",
        description = "Changes the DisplayName of one or more player(s).",
        aliases = { "nickname", "displayname", "unname" },
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) whose DisplayName to change."
            }, {
                type = "string",
                name = "DisplayName",
                description = "The DisplayName string to use.",
                optional = true
            } },

        envClient = function(u69) -- Line: 522, Name: envClient
            local u70 = nil;
            u69.Remote.DisplayName:Connect(function(p71) -- Line: 524
                -- upvalues: u69 (copy), u70 (ref)
                local Character = u69.LocalPlayer.Character;
                local v72;

                if Character then
                    v72 = Character:FindFirstChild("Head");
                else
                    v72 = Character;
                end;

                if v72 then
                    if not p71 then
                        if u70 then
                            u70:Destroy();
                        end;

                        return;
                    end;

                    if not u70 then
                        u70 = Instance.new("Model");
                        Instance.new("Humanoid").Parent = u70;
                        local Part = Instance.new("Part");
                        Part.Name = "Head";
                        Part.CanQuery = false;
                        Part.CanTouch = false;
                        Part.Massless = true;
                        Part.Size = Vector3.new(0, 0, 0);
                        Part.Parent = u70;
                        local SpecialMesh = Instance.new("SpecialMesh");
                        SpecialMesh.MeshType = Enum.MeshType.Brick;
                        SpecialMesh.Scale = Vector3.new(0, 0, 0);
                        SpecialMesh.Parent = Part;
                        local Weld = Instance.new("Weld");
                        Weld.Part0 = v72;
                        Weld.Part1 = Part;
                        Weld.Parent = Part;
                        u70.Parent = Character;
                    end;

                    u70.Name = p71;
                end;
            end);
        end,

        env = function(u73) -- Line: 559, Name: env
            local u74 = {};
            local u75 = {};
            u73.Util.SafePlayerAdded(function(u76) -- Line: 563
                -- upvalues: u74 (copy), u75 (copy), u73 (copy)
                u74[u76] = { u76.CharacterAdded:Connect(function(p77) -- Line: 565
                        -- upvalues: u75 (ref), u76 (copy), u73 (ref)
                        local v78 = u75[u76.UserId];

                        if not v78 then
                            return;
                        end;

                        p77:FindFirstChildOfClass("Humanoid").DisplayName = v78;
                        u73.Remote.DisplayName:Fire(u76, v78);
                    end) };
            end);
            u73.Service.Players.PlayerRemoving:Connect(function(p79) -- Line: 576
                -- upvalues: u74 (copy), u73 (copy)
                if u74[p79] then
                    u73.Flux.cleanup(u74[p79]);
                    u74[p79] = nil;
                end;
            end);

            return {
                displayNames = u75,
                remote = u73.Remote.DisplayName
            };
        end,

        run = function(p80, p81, p82) -- Line: 589, Name: run
            if p80.undo then
                p82 = nil;
            end;

            for _, v in p81 do
                p80.env[v.UserId] = p82;
                v:SetAttribute("_KDisplayName", p82);
                local v83 = v.Character and v.Character:FindFirstChildOfClass("Humanoid");

                if v83 then
                    v83.DisplayName = p82 or v.DisplayName;
                    p80._K.Remote.DisplayName:Fire(v, p82);
                end;
            end;
        end
    },
    {
        name = "hidename",
        description = "Hides the character name of one or more player(s).",
        aliases = {},
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) whose name to hide."
            } },

        run = function(p84, p85) -- Line: 617, Name: run
            for _, v in p85 do
                local v86 = v.Character and v.Character:FindFirstChildOfClass("Humanoid");

                if v86 then
                    v86.DisplayDistanceType = Enum.HumanoidDisplayDistanceType.None;
                end;
            end;
        end
    },
    {
        name = "showname",
        description = "Shows the character name of one or more player(s).",
        aliases = {},
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) whose name to show.",
                shouldRequest = true
            } },

        run = function(p87, p88) -- Line: 639, Name: run
            for _, v in p88 do
                local v89 = v.Character and v.Character:FindFirstChildOfClass("Humanoid");

                if v89 then
                    v89.DisplayDistanceType = Enum.HumanoidDisplayDistanceType.Viewer;
                end;
            end;
        end
    },
    {
        name = "setcoregui",
        description = "Enables/disables a CoreGui for one or more player(s)",
        aliases = { "coregui" },
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) to affect.",
                shouldRequest = true
            }, {
                type = "Enum.CoreGuiType",
                name = "CoreGui",
                description = "The CoreGui to enable/disable."
            }, {
                type = "boolean",
                name = "Enabled",
                description = "If the CoreGui is enabled.",
                optional = true
            } },

        envClient = function(u90) -- Line: 671, Name: envClient
            u90.Remote.SetCoreGuiEnabled:Connect(function(p91: any, p92: boolean) -- Line: 672
                -- upvalues: u90 (copy)
                u90.Service.StarterGui:SetCoreGuiEnabled(p91, p92 and true or false);
            end);
        end,

        env = function(p93) -- Line: 676, Name: env
            return {
                remote = p93.Remote.SetCoreGuiEnabled
            };
        end,

        run = function(p94: any, p95: any, p96: any, p97: boolean?) -- Line: 679, Name: run
            for _, v in p95 do
                p94.env.remote:Fire(v, p96, p97);
            end;
        end
    },
    {
        name = "toolban",
        description = "Bans one or more player(s) from using tools.",
        aliases = { "bantools" },
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) to ban from using tools.",
                lowerRank = true
            } },

        env = function(p98) -- Line: 697, Name: env
            return {
                bans = {},

                removeTool = function(p99: userdata) -- Line: 700, Name: removeTool
                    if p99:IsA("Tool") or p99:IsA("HopperBin") then
                        task.defer(p99.Destroy, p99);
                    end;
                end,

                removeTools = function(p100: userdata) -- Line: 705, Name: removeTools
                    if not p100 then
                        return;
                    end;

                    for _, child in p100:GetChildren() do
                        if child:IsA("Tool") or child:IsA("HopperBin") then
                            task.spawn(child.Destroy, child);
                        end;
                    end;
                end
            };
        end,

        run = function(p101, p102) -- Line: 718, Name: run
            for _, v in p102 do
                if p101.env.bans[v] then
                    return;
                end;

                local v103 = v:FindFirstChildOfClass("Backpack");

                if v103 then
                    p101.env.bans[v] = v103.ChildAdded:Connect(p101.env.removeTool);
                    p101.env.removeTools(v103);
                end;

                p101.env.removeTools(v.Character);
            end;
        end
    },
    {
        name = "untoolban",
        description = "Unbans one or more player(s) from using tools.",
        aliases = { "unbantools" },
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) to unban from using tools.",
                lowerRank = true
            } },

        run = function(p104, p105) -- Line: 745, Name: run
            local bans = p104._K.Registry.commands.toolban.env.bans;

            for _, v in p105 do
                local v106 = bans[v];

                if v106 then
                    v106:Disconnect();
                    bans[v] = nil;
                end;
            end;
        end
    },
    {
        name = "give",
        description = "Gives a tool to one or more player(s).\nTools must be a descendant of <b>Lighting</b> or <b>ServerStorage</b>.",
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) to give the tools."
            }, {
                type = "tools",
                name = "Tools",
                description = "The tools to give."
            } },

        run = function(p107, p108, p109) -- Line: 772, Name: run
            for _, v in p108 do
                local v110 = v:FindFirstChildOfClass("Backpack");

                if v110 then
                    for _, v2 in p109 do
                        v2:Clone().Parent = v110;
                    end;
                end;
            end;
        end
    },
    {
        name = "startergive",
        description = "Permanently gives a tool to one or more player(s).\nTools must be a descendant of <b>Lighting</b> or <b>ServerStorage</b>.",
        aliases = { "sgive" },
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) to give the tools."
            }, {
                type = "tools",
                name = "Tools",
                description = "The tools to give."
            } },

        run = function(p111, p112, p113) -- Line: 800, Name: run
            for _, v in p112 do
                for _, v2 in { v:FindFirstChildOfClass("Backpack"), v:FindFirstChildOfClass("StarterGear") } do
                    local v114 = v2;

                    for _, v3 in p113 do
                        v3:Clone().Parent = v114;
                    end;
                end;
            end;
        end
    },
    {
        name = "starterremove",
        description = "Permanently removes a tool from one or more player(s).",
        aliases = { "sremove", "unstartergive", "unsgive" },
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) to remove the tools from."
            }, {
                type = "tools",
                name = "Tools",
                description = "The tools to remove."
            } },

        run = function(p115, p116, p117) -- Line: 829, Name: run
            for _, v in p116 do
                for _, v2 in { v:FindFirstChildOfClass("Backpack"), v:FindFirstChildOfClass("StarterGear"), v.Character } do
                    local v118 = v2;

                    for _, v3 in p117 do
                        local v119 = v118:FindFirstChild(v3.Name);

                        if v119 and (v119:IsA("Tool") or v119:IsA("Hopperbin")) then
                            task.spawn(game.Destroy, v119);
                        end;
                    end;
                end;
            end;
        end
    },
    {
        name = "copytools",
        description = "Copies tools from one or more player(s) to one or more player(s).",
        aliases = { "ctools" },
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) whose tools to copy."
            }, {
                type = "players",
                name = "Player(s)",
                description = "The player(s) to give the copied tools."
            } },

        run = function(p120, p121, p122) -- Line: 864, Name: run
            for _, v in p121 do
                local v123 = {};

                for _, v2 in { v:FindFirstChildOfClass("Backpack"), v.Character } do
                    for _, child in v2:GetChildren() do
                        if (child:IsA("Tool") or child:IsA("HopperBin")) and not child:HasTag("_K_Ignore") then
                            table.insert(v123, child);
                        end;
                    end;
                end;

                if #v123 ~= 0 then
                    for _, v2 in p122 do
                        local v124 = v2:FindFirstChildOfClass("Backpack");

                        if v124 then
                            for _, v3 in v123 do
                                v3:Clone().Parent = v124;
                            end;
                        end;
                    end;
                end;
            end;
        end
    },
    {
        name = "removetools",
        description = "Removes all tools from one or more player(s).",
        aliases = { "rtools" },
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) to remove tools from."
            } },

        env = function(p125) -- Line: 900, Name: env
            return {
                removeTools = function(p126: userdata) -- Line: 902, Name: removeTools
                    if not p126 then
                        return;
                    end;

                    for _, child in p126:GetChildren() do
                        if child:IsA("Tool") or child:IsA("HopperBin") then
                            task.spawn(child.Destroy, child);
                        end;
                    end;
                end
            };
        end,

        run = function(p127, p128) -- Line: 915, Name: run
            for _, v in p128 do
                p127.env.removeTools(v:FindFirstChildOfClass("Backpack"));
                p127.env.removeTools(v.Character);
            end;
        end
    },
    {
        name = "tools",
        description = "Views all tools usable with the give command.\nThe default tool location is <b>game.ServerStorage</b>",
        aliases = { "toollist" },

        envClient = function(u129) -- Line: 927, Name: envClient
            local UI = u129.UI;
            local u130 = {
                command = UI.state("give"),
                removeCommand = UI.state("removetools"),
                target = UI.state(nil)
            };

            local function hasCommand() -- Line: 936
                -- upvalues: u129 (copy), u130 (copy)
                u129.client.rank();
                local v131 = u129.Registry.commands[u130.command()];

                if v131 then
                    v131 = v131.LocalPlayerAuthorized;
                end;

                return v131;
            end;

            local function hasTarget() -- Line: 942
                -- upvalues: u130 (copy)
                return u130.target() ~= nil;
            end;

            local function itemSize() -- Line: 946
                -- upvalues: UI (copy)
                return UDim2.new(1, 0, 0, UI.Theme.FontSize() + UI.Theme.Padding().Offset);
            end;

            local function scrollerItemSize() -- Line: 950
                -- upvalues: UI (copy)
                return UDim2.new(1, 0, 0, UI.Theme.FontSize() + UI.Theme.PaddingDouble().Offset);
            end;

            local u138 = UI.new("ScrollerFast")({
                Enabled = true,
                FilterInput = true,
                Visible = true,
                List = {},

                CreateItem = function(p132) -- Line: 959, Name: CreateItem
                    -- upvalues: UI (copy), itemSize (copy), hasCommand (copy), u129 (copy), u130 (copy), hasTarget (copy)
                    local u133 = nil;
                    u133 = UI.new("ListItem")({
                        ContentAutomaticSize = false,
                        Size = itemSize,
                        UI.new("Button")({
                            IconRightAlign = true,
                            AnchorPoint = Vector2.new(1, 0),
                            Icon = UI.Theme.Image.Add,
                            IconProperties = {
                                Size = UDim2.fromScale(0.625, 0.625)
                            },
                            Position = UDim2.new(1, 0),
                            Size = UDim2.new(1, 0, 1, 0),
                            SizeConstraint = Enum.SizeConstraint.RelativeYY,
                            Visible = hasCommand,

                            Activated = function() -- Line: 977, Name: Activated
                                -- upvalues: u129 (ref), u130 (ref), u133 (ref)
                                local v134 = `{u129.getCommandPrefix()}{u130.command._value} me {u133.tool}`;
                                u129.Process.runCommands(u129, u129.LocalPlayer.UserId, v134);
                            end
                        }),
                        UI.new("Button")({
                            IconRightAlign = true,
                            AnchorPoint = Vector2.new(1, 0),
                            Icon = UI.Theme.Image.Close_Bold,
                            IconProperties = {
                                Size = UDim2.fromScale(0.5, 0.5)
                            },
                            Position = UDim2.new(1, 0),
                            Size = UDim2.new(1, 0, 1, 0),
                            SizeConstraint = Enum.SizeConstraint.RelativeYY,
                            Visible = hasTarget,

                            Activated = function() -- Line: 995, Name: Activated
                                -- upvalues: u130 (ref), u129 (ref), u133 (ref)
                                if u130.target._value then
                                    u129.Remote.RemoveTool:Fire(u130.target._value, u133.tool);
                                end;
                            end
                        })
                    });
                    u133._content.AutomaticSize = Enum.AutomaticSize.None;
                    u133._content.Size = UDim2.new();

                    return u133;
                end,

                RenderItem = function(p135, p136, p137) -- Line: 1008, Name: RenderItem
                    p136.tool = p137;
                    p136.Text(p137 == "all" and "all (Everything)" or p137);
                end,

                ItemSize = scrollerItemSize
            });
            UI.edit(u138._scroller, { UI.new("UIFlexItem")({
                    FlexMode = Enum.UIFlexMode.Fill
                }) });
            UI.edit(u138._instance, { UI.new("UIPadding")({
                    PaddingTop = UDim.new(0, 1),
                    PaddingBottom = UDim.new(0, 1),
                    PaddingLeft = UDim.new(0, 1),
                    PaddingRight = UDim.new(0, 1)
                }) });
            task.defer(function() -- Line: 1030
                -- upvalues: u129 (copy), UI (copy), u138 (copy), scrollerItemSize (copy), u130 (copy)
                while not u129.client do
                    task.wait();
                end;

                UI.new("Button")({
                    Label = "<b>Remove all tools</b>",
                    LayoutOrder = 9,
                    IconRightAlign = true,
                    Parent = u138,
                    Icon = UI.Theme.Image.Close_Bold,
                    IconProperties = {
                        ImageColor3 = UI.Theme.PrimaryText,
                        Size = UDim2.fromScale(0.5, 0.5)
                    },
                    Size = scrollerItemSize,
                    TextXAlignment = Enum.TextXAlignment.Left,

                    Visible = function() -- Line: 1046, Name: Visible
                        -- upvalues: u129 (ref), u130 (ref)
                        u129.client.rank();
                        local v139 = u129.Registry.commands[u130.removeCommand()];

                        if v139 then
                            v139 = v139.LocalPlayerAuthorized;
                        end;

                        return v139;
                    end,

                    Activated = function() -- Line: 1052, Name: Activated
                        -- upvalues: u129 (ref), u130 (ref)
                        local v140 = `{u129.getCommandPrefix()}{u130.removeCommand._value} {u130.target._value and u130.target._value.Name or "me"}`;
                        u129.Process.runCommands(u129, u129.LocalPlayer.UserId, v140);
                    end
                });
            end);
            u130.scroller = u138;
            u130.window = UI.new("Window")({
                Parent = UI.LayerTopInset,
                Icon = "rbxassetid://71961243872230",
                Title = "Tools",
                Exitable = true,
                Position = UDim2.new(0.5, -128, 0.5, -128),
                Size = UDim2.new(0, 256, 0, 256),
                u138
            });

            return u130;
        end,

        env = function(u141) -- Line: 1074, Name: env
            local RemoveTool = u141.Remote.RemoveTool;
            RemoveTool:Connect(function(p142: userdata, p143: userdata, p144: string) -- Line: 1076
                -- upvalues: u141 (copy)
                if u141.Auth.hasCommand(p142.UserId, "removetools") and (typeof(p143) == "Player" and type(p144) == "string") then
                    local v145 = nil;

                    for _, v in { p143.Character, p143:FindFirstChildOfClass("Backpack") } do
                        if v then
                            for _, child in v:GetChildren() do
                                if (child:IsA("Tool") or child:IsA("HopperBin")) and child.Name == p144 then
                                    task.spawn(game.Destroy, child);
                                    v145 = true;
                                    break;
                                end;
                            end;
                        end;
                    end;

                    if v145 then
                        u141.log(`Removed "{p144}" tool from {p143.Name}`, "COMMAND", p142.UserId);
                    end;
                end;
            end);

            return {
                remote = RemoveTool
            };
        end,

        runClient = function(p146, p147) -- Line: 1105, Name: runClient
            if not p146._K.tools or #p146._K.tools <= 1 then
                p146._K.Notify({
                    Text = "No tools found!"
                });

                return;
            end;

            local v148 = {};

            for _, v in p146._K.tools do
                if not table.find(v148, v.Name) then
                    table.insert(v148, v.Name);
                end;
            end;

            p146.env.command("give");
            p146.env.removeCommand("removetools");
            p146.env.target(nil);
            p146.env.scroller.List(v148);
            p146.env.window.Title("Tools");
            p146.env.window._instance.Visible = true;
        end
    },
    {
        name = "startertools",
        description = "Views all tools in the StarterPack.",
        aliases = { "starttools", "stools" },

        runClient = function(p149, p150) -- Line: 1132, Name: runClient
            local Children = p149._K.Service.StarterPack:GetChildren();

            if #Children == 0 then
                p149._K.Notify({
                    Text = "No starter tools found!"
                });

                return;
            end;

            local v151 = {};

            for _, v in Children do
                if v:IsA("Tool") or v:IsA("HopperBin") then
                    table.insert(v151, v.Name);
                end;
            end;

            table.sort(v151);
            local env = p149._K.Registry.commands.tools.env;
            env.command("startergive");
            env.removeCommand("starterremove");
            env.env.target(nil);
            env.scroller.List(v151);
            env.window.Title("Starter Tools");
            env.window._instance.Visible = true;
        end
    },
    {
        name = "viewtools",
        description = "Views all tools from a player.",
        aliases = { "vtools" },
        args = { {
                type = "player",
                name = "Player",
                description = "The player whose tools to view."
            } },

        envClient = function(u152) -- Line: 1167, Name: envClient
            local u153 = {
                target = nil,
                connections = {}
            };

            function u153.createConnections(p154) -- Line: 1173
                -- upvalues: u153 (copy), u152 (copy)
                u153.removeConnections();
                u153.target = p154;
                u153.updateTools(p154);

                for _, v in { p154.Character, p154:FindFirstChildOfClass("Backpack") } do
                    table.insert(u153.connections, v.ChildAdded:Connect(u153.childChanged));
                    table.insert(u153.connections, v.ChildRemoved:Connect(u153.childChanged));
                    table.insert(u153.connections, p154.Destroying:Once(u153.removeConnections));
                    table.insert(u153.connections, p154.CharacterAdded:Once(function(p155) -- Line: 1183
                        -- upvalues: u153 (ref), u152 (ref)
                        u153.createConnections(u152.Service.Players:GetPlayerFromCharacter(p155));
                    end));
                    table.insert(u153.connections, u152.Registry.commands.tools.env.window.Title:Connect(u153.removeConnections));
                end;
            end;

            function u153.removeConnections() -- Line: 1194
                -- upvalues: u152 (copy), u153 (copy)
                u152.Flux.cleanup(u153.connections);
                u153.target = nil;
            end;

            function u153.updateTools(p156) -- Line: 1199
                -- upvalues: u152 (copy)
                local v157 = {};

                for _, v in { p156.Character, p156:FindFirstChildOfClass("Backpack") } do
                    for _, child in v:GetChildren() do
                        if (child:IsA("Tool") or child:IsA("HopperBin")) and not table.find(v157, child.Name) then
                            table.insert(v157, child.Name);
                        end;
                    end;
                end;

                if #v157 > 0 then
                    table.sort(v157);
                end;

                u152.Registry.commands.tools.env.scroller.List(v157);

                return #v157 > 0;
            end;

            function u153.childChanged(p158) -- Line: 1218
                -- upvalues: u153 (copy)
                if p158:IsA("Tool") or p158:IsA("HopperBin") then
                    u153.updateTools(u153.target);
                end;
            end;

            return u153;
        end,

        runClient = function(p159: any, p160: userdata) -- Line: 1227, Name: runClient
            if not p159.env.updateTools(p160) then
                p159._K.Notify({
                    Text = `No tools found for <b>{p160.Name}</b>!`
                });

                return;
            end;

            local env = p159._K.Registry.commands.tools.env;
            env.command("give");
            env.removeCommand("removetools");
            env.target(p160);
            env.window.Title(p160.Name .. "\'s Tools", true);
            env.window._instance.Visible = true;
            p159.env.createConnections(p160);
        end
    },
    {
        name = "sword",
        description = "Gives a sword to one or more player(s).",
        credit = { "Luckymaxer", "EUROCOW", "StarWars", "TakeoHonorable", "Kohl @Scripth" },
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) to give a sword."
            } },

        env = function(u161) -- Line: 1253, Name: env
            local u162 = {};
            task.defer(function() -- Line: 1256
                -- upvalues: u161 (copy), u162 (copy)
                local v163 = u161.Service.Insert:LoadAsset(47433):FindFirstChildOfClass("Tool");

                if not v163 then
                    warn("Sword failed to load, sword command won\'t work!");
                end;

                v163.Parent = u161.Service.ServerStorage;
                u162.sword = v163;
            end);

            return u162;
        end,

        run = function(p164, p165) -- Line: 1268, Name: run
            for _, v in p165 do
                local v166 = v:FindFirstChildOfClass("Backpack");

                if v166 then
                    p164.env.sword:Clone().Parent = v166;
                end;
            end;
        end
    },
    {
        name = "kill",
        description = "Kills one or more player(s).",
        aliases = { "slay", "unalive", "💀" },
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) to kill.",
                shouldRequest = true
            } },

        run = function(p167, p168) -- Line: 1289, Name: run
            for _, v in p168 do
                if v.Character then
                    local v169 = v.Character:FindFirstChildOfClass("Humanoid");

                    if v169 then
                        v169.MaxHealth = math.max(1, v169.MaxHealth);
                        v169.Health = 0;
                    end;
                end;
            end;
        end
    },
    {
        name = "loopkill",
        description = "Kills one or more player(s) repeatedly.",
        credit = { "SkellyLua" },
        aliases = { "loopslay", "loopunalive", "loop💀", "unloopkill", "unloopslay", "unloopunalive", "unloop💀" },
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) to kill repeatedly.",
                shouldRequest = true
            } },

        env = function(u170) -- Line: 1315, Name: env
            local u171 = {};
            task.spawn(function() -- Line: 1317
                -- upvalues: u171 (copy), u170 (copy)
                while true do
                    for i in u171 do
                        local PlayerByUserId = u170.Service.Players:GetPlayerByUserId(i);

                        if PlayerByUserId and PlayerByUserId.Character then
                            local v172 = PlayerByUserId.Character:FindFirstChildOfClass("Humanoid");

                            if v172 then
                                v172.MaxHealth = math.max(1, v172.MaxHealth);
                                v172.Health = 0;
                            end;
                        end;
                    end;

                    task.wait(1);

                    if u170.Data.gameClosing then
                        return;
                    end;
                end;
            end);

            return {
                killing = u171
            };
        end,

        run = function(p173, p174) -- Line: 1336, Name: run
            for _, v in p174 do
                p173.env.killing[v.UserId] = not p173.undo and true or nil;
            end;
        end
    },
    {
        name = "hurt",
        description = "Damages one or more player(s).",
        aliases = { "damage" },
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) to hurt.",
                shouldRequest = true
            }, {
                type = "number",
                name = "Damage",
                description = "The damage to deal to their health."
            } },

        run = function(p175, p176, p177) -- Line: 1360, Name: run
            for _, v in p176 do
                local v178 = v.Character and v.Character:FindFirstChildOfClass("Humanoid");

                if v178 then
                    v178:TakeDamage(p177);
                end;
            end;
        end
    },
    {
        name = "health",
        description = "Changes the maximum health one or more player(s).",
        aliases = { "maxhealth" },
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) whose health to change."
            }, {
                type = "number",
                name = "Max Health",
                description = "The new maximum health."
            } },

        run = function(p179, p180, p181) -- Line: 1386, Name: run
            local math_max_ret = math.max(1, p181);

            for _, v in p180 do
                local v182 = v.Character and v.Character:FindFirstChildOfClass("Humanoid");

                if v182 then
                    v182.MaxHealth = math_max_ret;
                    v182.Health = math_max_ret;
                end;
            end;
        end
    },
    {
        name = "heal",
        description = "Heals one or more player(s).",
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) to heal."
            } },

        run = function(p183, p184) -- Line: 1408, Name: run
            for _, v in p184 do
                local v185 = v.Character and v.Character:FindFirstChildOfClass("Humanoid");

                if v185 then
                    v185.Health = v185.MaxHealth;
                end;
            end;
        end
    },
    {
        name = "immortal",
        description = "Makes one or more player(s) invincible.",
        aliases = { "god" },
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) to make invincible."
            } },

        run = function(p186, p187) -- Line: 1429, Name: run
            for _, v in p187 do
                if v.Character then
                    local _Kff = v.Character:FindFirstChild("_Kff");

                    if _Kff then
                        _Kff.Visible = false;
                    else
                        local ForceField = Instance.new("ForceField");
                        ForceField.Name = "_Kff";
                        ForceField.Visible = false;
                        ForceField.Parent = v.Character;
                    end;

                    local v188 = v.Character:FindFirstChildOfClass("Humanoid");

                    if v188 then
                        p186._K.Util.Property.override(v188, "MaxHealth", (1 / 0));
                        v188.Health = (1 / 0);
                    end;
                end;
            end;
        end
    },
    {
        name = "forcefield",
        description = "Gives a ForceField to one or more player(s).",
        aliases = { "ff" },
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) to protect."
            } },

        run = function(p189, p190) -- Line: 1465, Name: run
            for _, v in p190 do
                if v.Character then
                    local _Kff = v.Character:FindFirstChild("_Kff");

                    if _Kff then
                        _Kff.Visible = true;
                    else
                        local ForceField = Instance.new("ForceField");
                        ForceField.Name = "_Kff";
                        ForceField.Parent = v.Character;
                    end;
                end;
            end;
        end
    },
    {
        name = "unforcefield",
        description = "Removes a ForceField from one or more player(s).",
        aliases = { "unff", "ungod", "mortal" },
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) to remove a ForceField from.",
                shouldRequest = true
            } },

        run = function(p191, p192) -- Line: 1494, Name: run
            for _, v in p192 do
                if v.Character then
                    for _, child in v.Character:GetChildren() do
                        if child:IsA("ForceField") then
                            child:Destroy();
                        end;
                    end;

                    local v193 = v.Character:FindFirstChildOfClass("Humanoid");

                    if v193 then
                        p191._K.Util.Property.reset(v193, "MaxHealth");
                        v193.Health = math.min(v193.Health, v193.MaxHealth);
                    end;
                end;
            end;
        end
    },
    {
        name = "invisible",
        description = "Makes one or more player(s) invisible.",
        aliases = { "inv", "invis", "hide" },
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) to make invisible."
            } },

        run = function(p194, p195) -- Line: 1524, Name: run
            for _, v in p195 do
                if v.Character then
                    for _, descendant in v.Character:GetDescendants() do
                        if (descendant:IsA("BasePart") or (descendant:IsA("Decal") or descendant:IsA("Texture"))) and not descendant:GetAttribute("kTransparency") then
                            descendant:SetAttribute("kTransparency", descendant.Transparency);
                            descendant.Transparency = 1;
                        elseif (descendant:IsA("Light") or (descendant:IsA("Beam") or (descendant:IsA("Trail") or (descendant:IsA("ParticleEmitter") or (descendant:IsA("Fire") or (descendant:IsA("Smoke") or (descendant:IsA("Sparkles") or descendant:IsA("SurfaceGui")))))))) and not descendant:GetAttribute("kEnabled") then
                            descendant:SetAttribute("kEnabled", descendant.Enabled);
                            descendant.Enabled = false;
                        end;
                    end;
                end;
            end;
        end
    },
    {
        name = "visible",
        description = "Makes one or more player(s) visible.",
        aliases = { "vis", "show", "unhide" },
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) to make visible.",
                shouldRequest = true
            } },

        run = function(p196, p197) -- Line: 1568, Name: run
            for _, v in p197 do
                if v.Character then
                    for _, descendant in v.Character:GetDescendants() do
                        local Attribute = descendant:GetAttribute("kTransparency");
                        local Attribute2 = descendant:GetAttribute("kEnabled");

                        if Attribute then
                            descendant:SetAttribute("kTransparency", nil);
                            descendant.Transparency = Attribute;
                        elseif Attribute2 then
                            descendant:SetAttribute("kEnabled", nil);
                            descendant.Enabled = Attribute2;
                        end;
                    end;
                end;
            end;
        end
    },
    {
        name = "blind",
        description = "Blinds one or more player(s).",
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) to blind.",
                shouldRequest = true
            } },

        env = function(p198) -- Line: 1599, Name: env
            return {
                remote = p198.Remote.Blind
            };
        end,

        envClient = function(p199) -- Line: 1602, Name: envClient
            local u200 = p199.UI.new("Frame")({
                ZIndex = 900000000,
                Visible = false,
                Parent = p199.UI.LayerTop,
                BackgroundColor3 = Color3.new(),
                Size = UDim2.fromScale(1, 1)
            });
            p199.Remote.Blind:Connect(function(p201) -- Line: 1610
                -- upvalues: u200 (copy)
                u200.Visible = p201 and true or false;
            end);

            return {
                frame = u200
            };
        end,

        run = function(p202, p203) -- Line: 1616, Name: run
            for _, v in p203 do
                p202._K.Remote.Blind:Fire(v, true);
            end;
        end
    },
    {
        name = "unblind",
        description = "Unblinds one or more player(s).",
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) to unblind.",
                lowerRank = true
            } },

        run = function(p204, p205) -- Line: 1634, Name: run
            for _, v in p205 do
                p204._K.Remote.Blind:Fire(v);
            end;
        end
    },
    {
        name = "freeze",
        description = "Freezes one or more player(s).",
        aliases = { "anchor", "ice" },
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) to freeze.",
                shouldRequest = true
            } },

        env = function(u206) -- Line: 1653, Name: env
            local u207 = {
                anchorPos = {},
                frozen = {}
            };

            function u207.anchor(p208: userdata) -- Line: 1659
                -- upvalues: u207 (copy)
                if not p208.Character then
                    return;
                end;

                for _, descendant in p208.Character:GetDescendants() do
                    if descendant:IsA("BasePart") then
                        descendant.Anchored = true;
                    end;
                end;

                u207.anchorPos[p208.UserId] = p208.Character:GetBoundingBox();
            end;

            function u207.freeze(p209: userdata) -- Line: 1671
                -- upvalues: u207 (copy)
                if not p209.Character then
                    return;
                end;

                local BoundingBox, v210 = p209.Character:GetBoundingBox();
                local Part = Instance.new("Part");
                Part.Name = "kFreeze";
                Part.Anchored = true;
                Part.CFrame = BoundingBox;
                Part.Reflectance = 1;
                Part.Transparency = 0.3;
                Part.Size = v210 + Vector3.new(2, 2, 2);
                Part.Color = Color3.fromHex("#8bf");
                Part.Material = Enum.Material.Ice;
                Part.TopSurface = Enum.SurfaceType.Smooth;
                Part.BottomSurface = Enum.SurfaceType.Smooth;
                Part.Parent = p209.Character;
                u207.frozen[p209.UserId] = true;
            end;

            local function reapply(p211: userdata) -- Line: 1692
                -- upvalues: u207 (copy)
                if not p211 then
                    return;
                end;

                local v212 = u207.anchorPos[p211.UserId];

                if v212 then
                    if not p211.Character then
                        p211.CharacterAppearanceLoaded:Wait();
                    end;

                    task.wait();

                    if p211.Character then
                        p211.Character:PivotTo(v212);
                    end;

                    u207.anchor(p211);

                    if u207.frozen[p211.UserId] then
                        u207.freeze(p211);
                    end;
                end;
            end;

            local function reapplyCharacter(p213: userdata) -- Line: 1712
                -- upvalues: reapply (copy), u206 (copy)
                reapply(u206.Service.Players:GetPlayerFromCharacter(p213));
            end;

            local u214 = {};
            u206.Util.SafePlayerAdded(function(p215: userdata) -- Line: 1718
                -- upvalues: u214 (copy), reapplyCharacter (copy), reapply (copy)
                u214[p215] = p215.CharacterAppearanceLoaded:Connect(reapplyCharacter);
                reapply(p215);
            end);
            u206.Service.Players.PlayerRemoving:Connect(function(p216) -- Line: 1723
                -- upvalues: u206 (copy), u214 (copy)
                u206.Flux.cleanup(u214[p216]);
                u214[p216] = nil;
            end);

            return u207;
        end,

        run = function(p217, p218) -- Line: 1730, Name: run
            for _, v in p218 do
                p217.env.anchor(v);

                if p217.alias ~= "anchor" and not p217.env.frozen[v.UserId] then
                    p217.env.freeze(v);
                end;
            end;
        end
    },
    {
        name = "thaw",
        description = "Thaws one or more player(s).",
        aliases = { "unfreeze", "unanchor", "unice" },
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) to thaw."
            } },

        run = function(p219, p220) -- Line: 1752, Name: run
            for _, v in p220 do
                if v.Character then
                    local kFreeze = v.Character:FindFirstChild("kFreeze");

                    if kFreeze then
                        kFreeze:Destroy();
                    end;

                    local v221 = v;

                    for _, descendant in v.Character:GetDescendants() do
                        if descendant:IsA("BasePart") then
                            descendant.Anchored = false;
                        end;
                    end;

                    local env = p219._K.Registry.commands.freeze.env;
                    env.anchorPos[v221.UserId] = nil;
                    env.frozen[v221.UserId] = nil;
                end;
            end;
        end
    },
    {
        name = "jail",
        description = "Jails one or more player(s).",
        aliases = {},
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) to jail.",
                shouldRequest = true
            } },

        envClient = function(p222) -- Line: 1784, Name: envClient
            p222.Remote.JailCollide:Connect(function(p223: userdata) -- Line: 1785
                if p223 then
                    for _, child in p223:GetChildren() do
                        if child:IsA("BasePart") then
                            child.CanCollide = true;
                        end;
                    end;
                end;
            end);
        end,

        env = function(u224) -- Line: 1795, Name: env
            local JailCollide = u224.Remote.JailCollide;
            local u225 = {
                parts = {},
                users = {}
            };

            local function pointInBounds(p226, p227, p228) -- Line: 1802
                return p226.X >= p227.X and (p226.Y >= p227.Y and (p226.Z >= p227.Z and (p226.X <= p228.X and p226.Y <= p228.Y))) and p226.Z <= p228.Z;
            end;

            function u225.recapture(p229) -- Line: 1813
                -- upvalues: u225 (copy)
                if not (p229 and (p229.Character and p229.Character.PrimaryPart)) then
                    return true;
                end;

                local v230 = u225.parts[p229.UserId];

                if v230 then
                    task.defer(p229.Character.PivotTo, p229.Character, v230.CFrame);

                    return true;
                end;
            end;

            function u225.recaptureCharacter(p231) -- Line: 1825
                -- upvalues: u225 (copy), u224 (copy)
                return u225.recapture(u224.Service.Players:GetPlayerFromCharacter(p231));
            end;

            function u225.new(u232: userdata, p233: vector?) -- Line: 1829
                -- upvalues: u225 (copy), JailCollide (copy)
                if u225.recapture(u232) then
                    return;
                end;

                local Character = u232.Character;
                local Head = Character:FindFirstChild("Head");
                local v234 = Character:FindFirstChildOfClass("Humanoid");
                local HumanoidRootPart = Character:FindFirstChild("HumanoidRootPart");

                if u232 and (Head and (v234 and HumanoidRootPart)) then
                    local CFrame2 = HumanoidRootPart.CFrame;
                    local v235;

                    if v234.RigType == Enum.HumanoidRigType.R15 then
                        v235 = v234.HipHeight + HumanoidRootPart.Size.Y / 2;
                    else
                        v235 = HumanoidRootPart.Size.Y * 1.5;
                    end;

                    local v236 = p233 or CFrame2.Position - Vector3.new(0, v235, 0);
                    local v237 = math.max(HumanoidRootPart.Size.X, HumanoidRootPart.Size.Z) + 4;
                    local Vector3_new_ret = Vector3.new(v237, v235 + HumanoidRootPart.Size.Y / 2 + Head.Size.Y + 3, v237);
                    local v238 = v236 + Vector3.new(0, Vector3_new_ret.Y / 2, 0);
                    local v239 = (Vector3_new_ret - Vector3.new(1, 1, 1)) / 2;
                    local Part = Instance.new("Part");
                    Part.Name = "kJail";
                    Part.Anchored = true;
                    Part.Size = Vector3_new_ret;
                    Part.CanCollide = false;
                    Part.CFrame = CFrame.new(v238);
                    Part.Color = Color3.new(0, 0, 0);
                    Part.Transparency = 0.3;
                    Part.Material = Enum.Material.Neon;
                    Part.TopSurface = Enum.SurfaceType.Smooth;
                    Part.BottomSurface = Enum.SurfaceType.Smooth;
                    u225.parts[u232.UserId] = Part;

                    if not u225.users[u232.UserId] then
                        u225.users[u232.UserId] = v236;
                    end;

                    local v240 = Part:Clone();
                    v240.Parent = Part;
                    v240.Transparency = 1;
                    v240.Size = Vector3.new(v237, 1, v237);
                    v240.Position = v238 + Vector3.new(0, v239.Y, 0);
                    local v241 = v240:Clone();
                    v241.Parent = Part;
                    v241.Position = v238 - Vector3.new(0, v239.Y, 0);
                    local v242 = v240:Clone();
                    v242.Parent = Part;
                    v242.Size = Vector3.new(1, Vector3_new_ret.Y, v237);
                    v242.Position = v238 - Vector3.new(v239.X, 0, 0);
                    local v243 = v242:Clone();
                    v243.Parent = Part;
                    v243.Position = v238 + Vector3.new(v239.X, 0, 0);
                    local v244 = v240:Clone();
                    v244.Parent = Part;
                    v244.Size = Vector3.new(v237, Vector3_new_ret.Y, 1);
                    v244.Position = v238 - Vector3.new(0, 0, v239.Z);
                    local v245 = v244:Clone();
                    v245.Parent = Part;
                    v245.Position = v238 + Vector3.new(0, 0, v239.Z);
                    Part.Parent = workspace;
                    HumanoidRootPart.CFrame = CFrame2;
                    local u246 = v238 - Vector3_new_ret / 2;
                    local u247 = v238 + Vector3_new_ret / 2;
                    task.defer(function() -- Line: 1904
                        -- upvalues: u232 (copy), u246 (copy), u247 (copy), u225 (ref)
                        while true do
                            task.wait();

                            if u232 and u232.Character then
                                local Position = u232.Character:GetPivot().Position;
                                local v248 = u246;
                                local v249 = u247;

                                if (Position.X < v248.X or (Position.Y < v248.Y or (Position.Z < v248.Z or (Position.X > v249.X or Position.Y > v249.Y)))) and true or Position.Z > v249.Z then
                                    u225.recapture(u232);
                                end;
                            end;

                            if not u232 or u225.parts[u232.UserId] == nil then
                                return;
                            end;
                        end;
                    end);
                    task.delay(0, JailCollide.Fire, JailCollide, u232, Part);

                    return Part;
                end;
            end;

            local u250 = {};
            u224.Util.SafePlayerAdded(function(p251) -- Line: 1924
                -- upvalues: u250 (copy), u225 (copy)
                u250[p251] = p251.CharacterAdded:Connect(u225.recaptureCharacter);
                local v252 = u225.users[p251.UserId];

                if v252 then
                    if not p251.Character then
                        p251.CharacterAppearanceLoaded:Wait();
                    end;

                    u225.new(p251, v252);
                    u225.recapture(p251);
                end;
            end);
            u224.Service.Players.PlayerRemoving:Connect(function(p253) -- Line: 1936
                -- upvalues: u224 (copy), u250 (copy), u225 (copy)
                u224.Flux.cleanup(u250[p253]);
                u250[p253] = nil;
                u224.Flux.cleanup(u225.parts[p253.UserId]);
                u225.parts[p253.UserId] = nil;
            end);

            return u225;
        end,

        run = function(p254, p255) -- Line: 1947, Name: run
            for _, v in p255 do
                if not p254.env.parts[v.UserId] and v.Character then
                    p254.env.new(v);
                end;
            end;
        end
    },
    {
        name = "unjail",
        description = "Frees one or more player(s) from jail.",
        aliases = {},
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) to release."
            } },

        run = function(p256, p257) -- Line: 1970, Name: run
            local env = p256._K.Registry.commands.jail.env;

            for _, v in p257 do
                env.users[v.UserId] = nil;
                local v258 = env.parts[v.UserId];

                if v258 then
                    env.parts[v.UserId] = nil;
                    v258:Destroy();
                end;
            end;
        end
    },
    {
        name = "cameraoffset",
        description = "Changes the CameraOffset of one or more player(s).",
        aliases = { "camoffset" },
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) whose CameraOffset to change."
            }, {
                type = "vector3",
                name = "Offset",
                description = "The Vector3 CameraOffset to set."
            } },

        env = function(p259) -- Line: 1998, Name: env
            return {
                remote = p259.Remote.CameraOffset
            };
        end,

        envClient = function(p260) -- Line: 2001, Name: envClient
            p260.Remote.CameraOffset:Connect(function(p261: vector) -- Line: 2002
                local LocalPlayer = game.Players.LocalPlayer;
                local v262 = LocalPlayer.Character and LocalPlayer.Character:FindFirstChildOfClass("Humanoid");

                if v262 then
                    v262.CameraOffset = p261;
                end;
            end);
        end,

        run = function(p263: any, p264: table, p265: vector) -- Line: 2010, Name: run
            for _, v in p264 do
                p263._K.Remote.CameraOffset:Fire(v, p265);
            end;
        end
    },
    {
        name = "antilag",
        description = "Improves the game performance for one or more player(s).",
        aliases = { "unantilag" },
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) whose performance to improve.",
                shouldRequest = true
            } },

        envClient = function(u266) -- Line: 2028, Name: envClient
            local u267 = {};
            u266.Remote.AntiLag:Connect(function(p268: boolean?) -- Line: 2030
                -- upvalues: u266 (copy), u267 (copy)
                if not p268 then
                    for _, descendant in game:GetDescendants() do
                        local Parent = descendant.Parent;
                        local v269 = descendant:FindFirstAncestorOfClass("Model");

                        if v269 then
                            v269 = v269:FindFirstChildOfClass("Humanoid");
                        end;

                        if not (v269 or descendant:HasTag("_K_Ignore")) then
                            if descendant:IsA("Decal") or descendant:IsA("Texture") then
                                u267[descendant] = Parent;
                                descendant.Parent = nil;
                            elseif descendant:IsA("BasePart") then
                                u266.Util.Property.override(descendant, "Material", Enum.Material.SmoothPlastic);
                            elseif descendant:IsA("MeshPart") then
                                u266.Util.Property.override(descendant, "Material", Enum.Material.SmoothPlastic);
                                u266.Util.Property.override(descendant, "TextureID", "");
                            end;

                            u266.Util.Defer.wait();
                        end;
                    end;

                    return;
                end;

                for _, descendant in game:GetDescendants() do
                    if not descendant:HasTag("_K_Ignore") then
                        if descendant:IsA("BasePart") then
                            u266.Util.Property.reset(descendant, "Material");
                        end;

                        u266.Util.Defer.wait();
                    end;
                end;

                for i, v in u267 do
                    i.Parent = v;
                end;

                table.clear(u267);
            end);
        end,

        env = function(p270) -- Line: 2072, Name: env
            return {
                remote = p270.Remote.AntiLag
            };
        end,

        run = function(p271, p272) -- Line: 2075, Name: run
            for _, v in p272 do
                p271.env.remote:Fire(v, p271.undo);
            end;
        end
    },
    {
        name = "fps",
        description = "Limits the frames per second of one or more player(s).",
        aliases = { "lag", "unlag", "unfps" },
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) whose frames per second to limit.",
                shouldRequest = true
            }, {
                type = "number",
                name = "FPS",
                description = "The frames per second limit.",
                optional = true
            } },

        envClient = function(u273) -- Line: 2099, Name: envClient
            local u274 = nil;
            local u275 = 0;
            local u276 = 0;
            u273.Service.Run.PreRender:Connect(function() -- Line: 2104
                -- upvalues: u276 (ref)
                u276 = tick();
            end);

            local function lag() -- Line: 2108
                -- upvalues: u273 (copy), u274 (ref), u276 (ref), u275 (ref)
                if not u273.LocalPlayer:GetAttribute("_KFPSLimit") then
                    u274:Disconnect();

                    return;
                end;

                local v277 = tick();

                while v277 + 1 / u275 - (v277 - u276) * 2 > tick() do

                end;
            end;

            u273.Remote.FPS:Connect(function(p278: number?) -- Line: 2121
                -- upvalues: u275 (ref), u274 (ref), u273 (copy), lag (copy)
                u275 = p278 or 32;

                if u274 then
                    u274:Disconnect();
                end;

                u274 = u273.Service.Run.Heartbeat:Connect(lag);
            end);
        end,

        env = function(p279) -- Line: 2129, Name: env
            return {
                remote = p279.Remote.FPS
            };
        end,

        run = function(p280, p281, p282) -- Line: 2133, Name: run
            local v283 = p280.undo or not p282 and p280.alias == "fps";

            for _, v in p281 do
                if v283 then
                    v:SetAttribute("_KFPSLimit", nil);
                else
                    v:SetAttribute("_KFPSLimit", true);
                    p280.env.remote:Fire(v, p282);
                end;
            end;
        end
    },
    {
        name = "lock",
        description = "Locks the character of one or more player(s).",
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) to lock."
            } },

        run = function(p284, p285) -- Line: 2156, Name: run
            for _, v in p285 do
                for _, descendant in v.Character:GetDescendants() do
                    if descendant:IsA("BasePart") then
                        descendant.Locked = true;
                    end;
                end;
            end;
        end
    },
    {
        name = "unlock",
        description = "Unlocks the character of one or more player(s).",
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) to unlock.",
                shouldRequest = true
            } },

        run = function(p286, p287) -- Line: 2178, Name: run
            for _, v in p287 do
                if v.Character then
                    for _, descendant in v.Character:GetDescendants() do
                        if descendant:IsA("BasePart") then
                            descendant.Locked = false;
                        end;
                    end;
                end;
            end;
        end
    },
    {
        name = "stun",
        description = "Stuns one or more player(s).",
        aliases = { "disable" },
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) to stun.",
                shouldRequest = true
            } },

        run = function(p288, p289) -- Line: 2205, Name: run
            for _, v in p289 do
                if v.Character and v.Character:FindFirstChildOfClass("Humanoid") then
                    v.Character:FindFirstChildOfClass("Humanoid").PlatformStand = true;
                end;
            end;
        end
    },
    {
        name = "unstun",
        description = "Removes stun from one or more player(s).",
        aliases = { "undisable", "enable" },
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) to remove the stun from."
            } },

        run = function(p290, p291) -- Line: 2225, Name: run
            for _, v in p291 do
                if v.Character and v.Character:FindFirstChildOfClass("Humanoid") then
                    v.Character:FindFirstChildOfClass("Humanoid").PlatformStand = false;
                end;
            end;
        end
    },
    {
        name = "bring",
        description = "Teleports one or more player(s) to you.",
        aliases = {},
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) to bring.",
                shouldRequest = true
            } },

        run = function(p292, p293) -- Line: 2247, Name: run
            for _, v in p293 do
                if v ~= p292.fromPlayer then
                    p292._K.Registry.commands.teleport.env.teleport(v.Character, p292.fromPlayer.Character);
                end;
            end;
        end
    },
    {
        name = "to",
        description = "Teleports to a player.",
        aliases = { "goto" },
        args = { {
                type = "player # vector3",
                name = "Destination",
                description = "The player or position to teleport to."
            } },

        run = function(p294, p295) -- Line: 2268, Name: run
            if typeof(p295) ~= "Vector3" then
                p295 = p295.Character;
            end;

            p294._K.Registry.commands.teleport.env.teleport(p294.fromPlayer.Character, p295);
        end
    },
    {
        name = "tp",
        description = "Teleports one or more player(s) to another player.",
        aliases = { "teleport" },
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) to teleport.",
                shouldRequest = true
            }, {
                type = "player # vector3",
                name = "Destination",
                description = "The player or position to teleport to."
            } },

        envClient = function(u296) -- Line: 2290, Name: envClient
            u296.Remote.Teleport:Connect(function(p297) -- Line: 2291
                -- upvalues: u296 (copy)
                local Character = u296.LocalPlayer.Character;

                if Character then
                    Character:PivotTo(p297);
                end;
            end);
        end,

        env = function(u298) -- Line: 2298, Name: env
            local Teleport = u298.Remote.Teleport;

            return {
                remote = Teleport,

                teleport = function(p299, p300) -- Line: 2302, Name: teleport
                    -- upvalues: u298 (copy), Teleport (copy)
                    if not (p299 and p300) then
                        return;
                    end;

                    local v301 = p299:FindFirstChildOfClass("Humanoid");

                    if v301 then
                        local v302 = v301.SeatPart and v301.SeatPart:FindFirstChild("SeatWeld");

                        if v302 then
                            v302:Destroy();
                        end;

                        v301.Sit = false;
                    end;

                    for _, descendant in p299:GetDescendants() do
                        if descendant:IsA("BasePart") then
                            descendant.AssemblyLinearVelocity = Vector3.new(0, 0, 0);
                            descendant.AssemblyAngularVelocity = Vector3.new(0, 0, 0);
                        end;
                    end;

                    local v303;

                    if typeof(p300) == "Vector3" then
                        v303 = CFrame.new(p300) * p299:GetPivot().Rotation;
                    else
                        local v304 = (math.random(1, 2) - 1) * math.random(2, 4);
                        local v305 = (math.random(1, 2) - 1) * math.random(2, 4);
                        local Vector3_new_ret = Vector3.new(v304, 0, v305);
                        v303 = p300:GetPivot() + Vector3_new_ret;
                    end;

                    p299:PivotTo(v303);
                    local PlayerFromCharacter = u298.Service.Players:GetPlayerFromCharacter(p299);

                    if PlayerFromCharacter then
                        Teleport:Fire(PlayerFromCharacter, v303);
                    end;
                end
            };
        end,

        run = function(p306, p307, p308) -- Line: 2348, Name: run
            if typeof(p308) ~= "Vector3" then
                p308 = p308.Character;
            end;

            for _, v in p307 do
                p306.env.teleport(v.Character, p308);
            end;
        end
    },
    {
        name = "join",
        description = "Join a player in the same game.",
        args = { {
                type = "userId",
                name = "UserId",
                description = "The UserId of the player to join."
            } },

        run = function(p309, p310) -- Line: 2366, Name: run
            local v311, v312, v313, v314, v315 = pcall(p309._K.Service.Teleport.GetPlayerPlaceInstanceAsync, p309._K.Service.Teleport, p310);

            if not v311 then
                return v313 or v312;
            end;

            if v312 then
                return "You\'re already in the same server!";
            end;

            if v314 and v315 then
                local TeleportOptions = Instance.new("TeleportOptions");
                TeleportOptions.ServerInstanceId = v315;
                p309._K.Util.SafeTeleport(v314, { p309.fromPlayer }, TeleportOptions);
            end;
        end
    },
    {
        name = "fov",
        description = "Changes the field of view of one or more player(s).",
        aliases = { "unfov", "resetfov" },
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) whose field of view to change.",
                shouldRequest = true
            }, {
                type = "number",
                name = "Degrees",
                description = "The field of view in degrees.",
                optional = true
            } },

        envClient = function(p316) -- Line: 2403, Name: envClient
            local u317 = nil;
            p316.Remote.FOV:Connect(function(p318) -- Line: 2405
                -- upvalues: u317 (ref)
                if p318 and not u317 then
                    u317 = workspace.CurrentCamera.FieldOfView;
                end;

                if p318 or u317 then
                    workspace.CurrentCamera.FieldOfView = math.clamp(p318 or u317, 1, 120);

                    if not p318 then
                        u317 = nil;
                    end;
                end;
            end);

            return true;
        end,

        env = function(p319) -- Line: 2418, Name: env
            return {
                remote = p319.Remote.FOV
            };
        end,

        run = function(p320, p321, p322) -- Line: 2424, Name: run
            for _, v in p321 do
                local v323;

                if p322 == nil then
                    v323 = nil;
                else
                    v323 = p322;
                end;

                p320.env.remote:Fire(v, v323);
            end;
        end
    },
    {
        name = "jump",
        description = "Makes one or more player(s) jump.",
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) who will jump.",
                shouldRequest = true
            } },

        run = function(p324, p325) -- Line: 2442, Name: run
            for _, v in p325 do
                if v.Character and v.Character:FindFirstChildOfClass("Humanoid") then
                    v.Character:FindFirstChildOfClass("Humanoid").Jump = true;
                end;
            end;
        end
    },
    {
        name = "jumppower",
        description = "Changes the jump power of one or more player(s).",
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) whose jump power to change.",
                shouldRequest = true
            }, {
                type = "number",
                name = "JumpPower",
                description = "The jump power to use."
            } },

        run = function(p326, p327, p328) -- Line: 2467, Name: run
            for _, v in p327 do
                if v.Character and v.Character:FindFirstChildOfClass("Humanoid") then
                    v.Character:FindFirstChildOfClass("Humanoid").JumpPower = p328;
                end;
            end;
        end
    },
    {
        name = "starterjumppower",
        description = "Changes the jump power of one or more player(s) when they spawn.",
        args = { {
                type = "number",
                name = "JumpPower",
                description = "The jump power to use.",
                shouldRequest = true
            } },

        run = function(p329: any, p330: number) -- Line: 2487, Name: run
            p329._K.Service.StarterPlayer.CharacterJumpPower = p330;
        end
    },
    {
        name = "sit",
        description = "Makes one or more player(s) sit.",
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) who will sit.",
                shouldRequest = true
            } },

        run = function(p331, p332) -- Line: 2503, Name: run
            for _, v in p332 do
                if v.Character and v.Character:FindFirstChildOfClass("Humanoid") then
                    v.Character:FindFirstChildOfClass("Humanoid").Sit = true;
                end;
            end;
        end
    },
    {
        name = "unsit",
        description = "Makes one or more player(s) stop sitting.",
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) who will stop sitting.",
                shouldRequest = true
            } },

        run = function(p333, p334) -- Line: 2523, Name: run
            for _, v in p334 do
                if v.Character and v.Character:FindFirstChildOfClass("Humanoid") then
                    v.Character:FindFirstChildOfClass("Humanoid").Sit = false;
                end;
            end;
        end
    },
    {
        name = "speed",
        description = "Changes the walkspeed of one or more player(s).",
        aliases = { "walkspeed" },
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) whose walkspeed to change.",
                shouldRequest = true
            }, {
                type = "number",
                name = "Speed",
                description = "The walkspeed to use."
            } },

        run = function(p335: any, p336: any, p337: number) -- Line: 2549, Name: run
            for _, v in p336 do
                if v.Character and v.Character:FindFirstChildOfClass("Humanoid") then
                    v.Character:FindFirstChildOfClass("Humanoid").WalkSpeed = p337;
                end;
            end;
        end
    },
    {
        name = "starterspeed",
        description = "Changes the walkspeed of one or more player(s) when they spawn.",
        aliases = { "starterwalkspeed" },
        args = { {
                type = "number",
                name = "Speed",
                description = "The walkspeed to use.",
                shouldRequest = true
            } },

        run = function(p338: any, p339: number) -- Line: 2570, Name: run
            p338._K.Service.StarterPlayer.CharacterWalkSpeed = p339;
        end
    },
    {
        name = "vehiclespeed",
        description = "Changes the vehicle speed of one or more player(s).",
        aliases = {},
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) whose vehicle speed to change.",
                shouldRequest = true
            }, {
                type = "number",
                name = "Speed",
                description = "The vehicle speed to use."
            } },

        run = function(p340: any, p341: any, p342: number) -- Line: 2592, Name: run
            for _, v in p341 do
                if v.Character then
                    local v343 = v.Character:FindFirstChildOfClass("Humanoid");

                    if v343 and v343.SeatPart then
                        v343.SeatPart.MaxSpeed = p342;
                    end;
                end;
            end;
        end
    },
    {
        name = "vehicletorque",
        description = "Changes the vehicle torque of one or more player(s).",
        aliases = {},
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) whose vehicle torque to change.",
                shouldRequest = true
            }, {
                type = "number",
                name = "Torque",
                description = "The vehicle torque to use."
            } },

        run = function(p344: any, p345: any, p346: number) -- Line: 2623, Name: run
            for _, v in p345 do
                if v.Character then
                    local v347 = v.Character:FindFirstChildOfClass("Humanoid");

                    if v347 and v347.SeatPart then
                        v347.SeatPart.Torque = p346;
                    end;
                end;
            end;
        end
    },
    {
        name = "slopeangle",
        description = "Changes the max slope angle of one or more player(s).",
        aliases = { "maxslopeangle" },
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) whose max slope angle to change."
            }, {
                type = "number",
                name = "MaxSlopeAngle",
                description = "The max slope angle to use."
            } },

        run = function(p348, p349, p350) -- Line: 2653, Name: run
            for _, v in p349 do
                if v.Character and v.Character:FindFirstChildOfClass("Humanoid") then
                    v.Character:FindFirstChildOfClass("Humanoid").MaxSlopeAngle = math.clamp(p350, 0, 89);
                end;
            end;
        end
    },
    {
        name = "starterslopeangle",
        description = "Changes the starting max slope angle of one or more player(s) when they spawn.",
        aliases = { "startermaxslopeangle" },
        args = { {
                type = "number",
                name = "MaxSlopeAngle",
                description = "The max slope angle to use."
            } },

        run = function(p351: any, p352: number) -- Line: 2673, Name: run
            p351._K.Service.StarterPlayer.CharacterMaxSlopeAngle = math.clamp(p352, 0, 89);
        end
    },
    {
        name = "r6",
        description = "Changes the rig type of one or more player(s).",
        aliases = { "r15" },
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) whose rig type to change.",
                shouldRequest = true
            } },

        env = function(u353) -- Line: 2690, Name: env
            return {
                apply = function(p354: userdata, p355: any) -- Line: 2692, Name: apply
                    -- upvalues: u353 (copy)
                    local Character = p354.Character;
                    local v356;

                    if Character then
                        v356 = Character:FindFirstChildOfClass("Humanoid");
                    else
                        v356 = Character;
                    end;

                    local v357;

                    if v356 then
                        v357 = v356:FindFirstChildOfClass("HumanoidDescription");
                    else
                        v357 = v356;
                    end;

                    if v357 then
                        local v358 = u353.Service.Players:CreateHumanoidModelFromDescription(v357, p355);
                        v358:PivotTo(Character:GetPivot());
                        v358.Name = Character.Name;
                        local v359 = v358:FindFirstChildOfClass("Humanoid");

                        if v359 then
                            for _, v in { "CameraOffset", "DisplayName", "HealthDisplayDistance", "NameDisplayDistance", "UseJumpPower", "JumpPower", "WalkSpeed", "MaxSlopeAngle", "Health", "MaxHealth" } do
                                v359[v] = v356[v];
                            end;
                        end;

                        local StarterCharacterScripts = u353.Service.StarterPlayer:FindFirstChild("StarterCharacterScripts");

                        if StarterCharacterScripts then
                            for _, child in StarterCharacterScripts:GetChildren() do
                                child:Clone().Parent = v358;
                            end;
                        end;

                        p354.Character = v358;
                        u353.VIP.EffectHandler(v358);
                        v358.Parent = workspace;
                        u353.Remote.Refresh:Fire(p354);

                        return v358;
                    end;
                end
            };
        end,

        run = function(p360, p361) -- Line: 2741, Name: run
            local v362;

            if p360.alias == "r6" then
                v362 = Enum.HumanoidRigType.R6;
            else
                v362 = Enum.HumanoidRigType.R15;
            end;

            for _, v in p361 do
                p360.env.apply(v, v362);
            end;
        end
    },
    {
        name = "respawn",
        description = "Respawns the character of one or more player(s).",
        aliases = { "spawn" },
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) to respawn.",
                shouldRequest = true
            } },

        run = function(p363, p364) -- Line: 2761, Name: run
            for _, v in p364 do
                v:LoadCharacterAsync();
            end;
        end
    },
    {
        name = "refresh",
        description = "Refreshes the character of one or more player(s).",
        aliases = { "re" },
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) to refresh.",
                shouldRequest = true
            } },

        env = function(p365) -- Line: 2780, Name: env
            return {
                remote = p365.Remote.Refresh
            };
        end,

        envClient = function(p366) -- Line: 2784, Name: envClient
            local u367 = nil;
            p366.Remote.Refresh:Connect(function() -- Line: 2786
                -- upvalues: u367 (ref)
                if u367 then
                    workspace.CurrentCamera:GetPropertyChangedSignal("CFrame"):Wait();
                    workspace.CurrentCamera.CFrame = u367;
                end;
            end);
            p366.Service.Players.LocalPlayer.CharacterRemoving:Connect(function() -- Line: 2793
                -- upvalues: u367 (ref)
                u367 = workspace.CurrentCamera.CFrame;
            end);
        end,

        run = function(p368, p369) -- Line: 2798, Name: run
            for _, v in p369 do
                if v and v.Character then
                    local Pivot = v.Character:GetPivot();
                    v:LoadCharacterAsync();
                    v.Character:PivotTo(Pivot);
                    p368.env.remote:Fire(v);
                end;
            end;
        end
    },
    {
        name = "removelimbs",
        description = "Removes the limbs of one or more player(s).",
        aliases = { "rlimbs" },
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) whose limbs to remove.",
                shouldRequest = true
            } },

        run = function(p370, p371) -- Line: 2822, Name: run
            for _, v in p371 do
                if v.Character then
                    for _, child in v.Character:GetChildren() do
                        if string.find(child.Name, "Arm$") or string.find(child.Name, "Leg$") then
                            child:Destroy();
                        end;
                    end;
                end;
            end;
        end
    },
    {
        name = "removearms",
        description = "Removes the arms of one or more player(s).",
        aliases = { "rarms" },
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) whose arms to remove.",
                shouldRequest = true
            } },

        run = function(p372, p373) -- Line: 2848, Name: run
            for _, v in p373 do
                if v.Character then
                    for _, child in v.Character:GetChildren() do
                        if string.find(child.Name, "Arm$") then
                            child:Destroy();
                        end;
                    end;
                end;
            end;
        end
    },
    {
        name = "removelegs",
        description = "Removes the legs of one or more player(s).",
        aliases = { "rlegs" },
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) whose legs to remove.",
                shouldRequest = true
            } },

        run = function(p374, p375) -- Line: 2874, Name: run
            for _, v in p375 do
                if v.Character then
                    for _, child in v.Character:GetChildren() do
                        if string.find(child.Name, "Leg$") then
                            child:Destroy();
                        end;
                    end;
                end;
            end;
        end
    },
    {
        name = "buy",
        description = "Prompts a purchase for one or more player(s).",
        aliases = { "purchase" },
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) to prompt."
            }, {
                type = "Enum.InfoType",
                name = "InfoType",
                description = "The Enum.InfoType of the purchase.",
                optional = true
            }, {
                type = "integer",
                name = "Identifier",
                description = "The identifier of the item to purchase."
            } },

        env = function(p376) -- Line: 2911, Name: env
            local MarketplaceService = game:GetService("MarketplaceService");

            return {
                market = MarketplaceService,
                method = {
                    [Enum.InfoType.Asset] = MarketplaceService.PromptPurchase,
                    [Enum.InfoType.Bundle] = MarketplaceService.PromptBundlePurchase,
                    [Enum.InfoType.GamePass] = MarketplaceService.PromptGamePassPurchase,
                    [Enum.InfoType.Product] = MarketplaceService.PromptProductPurchase,
                    [Enum.InfoType.Subscription] = MarketplaceService.PromptSubscriptionPurchase
                }
            };
        end,

        run = function(p377, p378, p379, p380) -- Line: 2925, Name: run
            if p379 == nil then
                p379 = Enum.InfoType.Asset;
            end;

            local v381 = p377.env.method[p379];

            if not v381 then
                return;
            end;

            if p379 == Enum.InfoType.Subscription then
                p380 = "EXP-" .. p380;
            end;

            for _, v in p378 do
                pcall(v381, p377.env.market, v, p380);
            end;
        end
    },
    {
        name = "has",
        description = "Checks if a player(s) owns an item.",
        aliases = { "owns" },
        args = { {
                type = "player",
                name = "Player",
                description = "The player to check ownership."
            }, {
                type = "Enum.InfoType",
                name = "InfoType",
                description = "The Enum.InfoType of the purchase.",
                optional = true
            }, {
                type = "integer",
                name = "Identifier",
                description = "The identifier of the item to purchase."
            } },

        env = function(p382) -- Line: 2964, Name: env
            local MarketplaceService = game:GetService("MarketplaceService");

            return {
                market = MarketplaceService,
                method = {
                    [Enum.InfoType.Asset] = MarketplaceService.PlayerOwnsAssetAsync,
                    [Enum.InfoType.Bundle] = MarketplaceService.PlayerOwnsBundleAsync,
                    [Enum.InfoType.GamePass] = MarketplaceService.UserOwnsGamePassAsync,
                    [Enum.InfoType.Subscription] = MarketplaceService.GetUserSubscriptionStatusAsync
                }
            };
        end,

        run = function(p383, p384, p385, p386) -- Line: 2977, Name: run
            if p385 == nil then
                p385 = Enum.InfoType.Asset;
            end;

            local v387 = p383.env.method[p385];

            if not v387 then
                return;
            end;

            if p385 == Enum.InfoType.Subscription then
                p386 = "EXP-" .. p386;
            end;

            local v388;

            if p385 == Enum.InfoType.GamePass then
                v388 = p384.UserId;
            else
                v388 = p384;
            end;

            local success, result = pcall(v387, p383.env.market, v388, p386);

            if p385 == Enum.InfoType.Subscription and result then
                result = result.IsSubscribed;
            end;

            if success then
                local Notify = p383._K.Remote.Notify;
                local fromPlayer = p383.fromPlayer;
                local v389 = {
                    From = p384.UserId
                };
                local v390;

                if result then
                    v390 = `<font color="#{p383._K.Data.settings.themeValid:ToHex()}">Owns`;
                else
                    v390 = `<font color="#{p383._K.Data.settings.themeInvalid:ToHex()}">DOES NOT own`;
                end;

                v389.Text = `<b>{v390}</font></b> {p385.Name} {p386}`;
                Notify:Fire(fromPlayer, v389);
            end;
        end
    },
    {
        name = "promptgroup",
        description = "Prompts one or more player(s) to join a group.",
        aliases = { "joingroup" },
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) to prompt."
            }, {
                type = "integer",
                name = "Identifier",
                description = "The identifier of the group."
            } },

        envClient = function(u391) -- Line: 3024, Name: envClient
            u391.Remote.PromptJoinAsync:Connect(function(p392: number) -- Line: 3025
                -- upvalues: u391 (copy)
                pcall(u391.Service.Group.PromptJoinAsync, u391.Service.Group, p392);
            end);
        end,

        env = function(p393) -- Line: 3029, Name: env
            return {
                remote = p393.Remote.PromptJoinAsync
            };
        end,

        run = function(p394: any, p395: table, p396: number) -- Line: 3033, Name: run
            for _, v in p395 do
                p394.env.remote:Fire(v, p396);
            end;
        end
    },
    {
        name = "change",
        description = "Changes a leaderstat of one or more player(s).",
        aliases = {},
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) whose leaderstat to change."
            }, {
                type = "rawString",
                name = "Stat",
                description = "The stat to change."
            }, {
                type = "rawString",
                name = "Value",
                description = "The value of the stat."
            } },

        run = function(p397, p398, p399, p400) -- Line: 3060, Name: run
            local string_lower_ret = string.lower(p399);

            for _, v in p398 do
                local leaderstats = v:FindFirstChild("leaderstats");

                if leaderstats then
                    for _, child in leaderstats:GetChildren() do
                        if string.find(string.lower(child.Name), string_lower_ret, 1, true) == 1 then
                            if child:IsA("IntValue") or child:IsA("NumberValue") then
                                child.Value = tonumber(p400);
                            elseif child:IsA("BoolValue") then
                                local string_lower_ret2 = string.lower(p400);
                                local v401;

                                if string_lower_ret2 == "false" or (string_lower_ret2 == "nil" or string_lower_ret2 == "0") then
                                    v401 = false;
                                else
                                    v401 = string_lower_ret2 ~= "off";
                                end;

                                child.Value = v401;
                            elseif child:IsA("StringValue") then
                                child.Value = p397._K.Util.String.filterForBroadcast(p400, p397.from);
                            end;
                        end;
                    end;
                end;
            end;
        end
    },
    {
        name = "resetstats",
        description = "Resets the stats of one or more player(s).",
        aliases = { "rs" },
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) whose stats to reset.",
                shouldRequest = true
            } },

        run = function(p402, p403) -- Line: 3094, Name: run
            for _, v in p403 do
                local leaderstats = v:FindFirstChild("leaderstats");

                if leaderstats then
                    for _, child in leaderstats:GetChildren() do
                        if child:IsA("IntValue") or child:IsA("NumberValue") then
                            child.Value = 0;
                        end;
                    end;
                end;
            end;
        end
    },
    {
        name = "team",
        description = "Changes the team of one or more player(s).",
        aliases = { "tm" },
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) whose teams to change."
            }, {
                type = "team",
                name = "Team",
                description = "The team to assign.",
                optional = true
            } },

        run = function(p404, p405, p406) -- Line: 3125, Name: run
            for _, v in p405 do
                v.Team = p406;
            end;
        end
    },
    {
        name = "teamrespawn",
        description = "Changes the team of one or more player(s) and spawns them.",
        aliases = { "tmrs", "trs", "teamrs" },
        credit = { "Rie @Rietria" },
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) whose teams to change and spawn."
            }, {
                type = "team",
                name = "Team",
                description = "The team to assign.",
                optional = true
            } },

        run = function(p407, p408, p409) -- Line: 3149, Name: run
            for _, v in p408 do
                v.Team = p409;
                v:LoadCharacterAsync();
            end;
        end
    },
    {
        name = "substitute",
        description = "Switches the teams of 2 players and spawns them.",
        aliases = { "sub", "subteams", "switch", "switchteams" },
        credit = { "Rie @Rietria" },
        args = { {
                type = "player",
                name = "Player1",
                description = "The first player to switch"
            }, {
                type = "player",
                name = "Player2",
                description = "The second player to switch"
            } },

        run = function(p410, p411, p412) -- Line: 3173, Name: run
            local Team = p411.Team;
            p411.Team = p412.Team;
            p412.Team = Team;
            p411:LoadCharacterAsync();
            p412:LoadCharacterAsync();
        end
    },
    {
        name = "randomizeteams",
        description = "Randomizes the team of one or more player(s) from a list of teams.",
        aliases = { "randomiseteams", "randomteams", "rteams", "rteam", "rt" },
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) whose teams to randomize."
            }, {
                type = "teams",
                name = "Random Teams",
                description = "The teams to randomly assign.",
                optional = true
            } },

        run = function(p413, p414, p415) -- Line: 3196, Name: run
            local v416 = p413._K.Util.Table.shuffle(p415 or p413._K.Service.Teams:GetTeams());

            for i, v in p413._K.Util.Table.shuffle(p414) do
                v.Team = v416[(i - 1) % #v416 + 1];
            end;
        end
    },
    {
        name = "createteam",
        description = "Creates a new team with the given name and color.",
        aliases = { "cteam", "newteam" },
        credit = { "Realistic @iiRealistic_Dev" },
        args = { {
                type = "string",
                name = "Name",
                description = "The name of the new team."
            }, {
                type = "color",
                name = "Color",
                optional = true,
                description = "The color of the new team."
            }, {
                type = "boolean",
                name = "AutoAssignable",
                optional = true,
                description = "If the new team is AutoAssignable."
            } },

        run = function(p417, p418, p419, p420) -- Line: 3229, Name: run
            local Team = Instance.new("Team");
            local v421 = p419 or BrickColor.random().Color;
            Team.Name = p418;
            Team.TeamColor = BrickColor.new(v421);
            Team.AutoAssignable = p420;
            Team.Parent = p417._K.Service.Teams;
            p417._K.Remote.Notify:Fire(p417.fromPlayer, {
                From = "_K",
                Text = `<b>Created team:</b> <font color="#{v421:ToHex()}">{p418}</font>`
            });
        end
    },
    {
        name = "editteam",
        description = "Edits a team with the given name and color.",
        aliases = { "eteam" },
        credit = { "Realistic @iiRealistic_Dev", "Kohl @Scripth" },
        args = { {
                type = "team",
                name = "Team",
                description = "The team to edit."
            }, {
                type = "string",
                name = "Name",
                description = "The new name of the team."
            }, {
                type = "color",
                name = "Color",
                optional = true,
                description = "The new color of the team."
            }, {
                type = "boolean",
                name = "AutoAssignable",
                optional = true,
                description = "If the team is AutoAssignable."
            } },

        run = function(p422, p423, p424, p425, p426) -- Line: 3278, Name: run
            if not (p423 and p422._K.Service.Teams:FindFirstChild(p423.Name)) then
                p422._K.Remote.Notify:Fire(p422.fromPlayer, {
                    From = "_K",
                    Text = `<b>Failed to edit team:</b> <font color="#{p423.TeamColor.Color:ToHex()}">{p423.Name}</font>`
                });

                return;
            end;

            local Color = p423.TeamColor.Color;
            local Name = p423.Name;
            local v427 = p425 or BrickColor.random().Color;
            p423.Name = p424;
            p423.TeamColor = BrickColor.new(v427);
            p423.AutoAssignable = p426;
            p422._K.Remote.Notify:Fire(p422.fromPlayer, {
                From = "_K",
                Text = `<b>Edited team:</b> <font color="#{Color:ToHex()}">{Name}</font> to <font color="#{v427:ToHex()}">{p424}</font>`
            });
        end
    },
    {
        name = "removeteam",
        description = "Removes a team with the given name.",
        aliases = { "delteam", "deleteteam" },
        credit = { "Realistic @iiRealistic_Dev" },
        args = { {
                type = "team",
                name = "Team",
                description = "The team to remove."
            } },

        run = function(p428, p429) -- Line: 3315, Name: run
            if not (p429 and p428._K.Service.Teams:FindFirstChild(p429.Name)) then
                p428._K.Remote.Notify:Fire(p428.fromPlayer, {
                    From = "_K",
                    Text = `<b>Failed to remove team:</b> <font color="#{p429.TeamColor.Color:ToHex()}">{p429.Name}</font>`
                });

                return;
            end;

            p429:Destroy();
            p428._K.Remote.Notify:Fire(p428.fromPlayer, {
                From = "_K",
                Text = `<b>Removed team:</b> <font color="#{p429.TeamColor.Color:ToHex()}">{p429.Name}</font>`
            });
        end
    },
    {
        name = "clearteams",
        description = "Clears all teams.",
        aliases = { "ctm", "cleartm" },
        credit = { "Realistic @iiRealistic_Dev" },

        run = function(p430) -- Line: 3337, Name: run
            for _, v in p430._K.Service.Teams:GetTeams() do
                v:Destroy();
            end;

            p430._K.Remote.Notify:Fire(p430.fromPlayer, {
                From = "_K",
                Text = "<b>Cleared all teams.</b>"
            });
        end
    },
    {
        name = "collide",
        description = "Toggles collisions for one or more player(s) against other player(s).",
        aliases = { "nocollide", "uncollide" },
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) whose collisions to toggle."
            } },

        env = function(p431) -- Line: 3358, Name: env
            p431.Service.PhysicsService:RegisterCollisionGroup("_KNoCollide");
            p431.Service.PhysicsService:CollisionGroupSetCollidable("_KNoCollide", "_KNoCollide", false);

            return {
                setCollision = function(p432: userdata, p433: boolean) -- Line: 3364, Name: setCollision
                    for _, descendant in p432:GetDescendants() do
                        if descendant:IsA("BasePart") then
                            if not descendant:GetAttribute("_KCollisionGroup") then
                                descendant:SetAttribute("_KCollisionGroup", descendant.CollisionGroup);
                            end;

                            descendant.CollisionGroup = not p433 and "_KNoCollide" or descendant:GetAttribute("_KCollisionGroup");

                            if p433 then
                                descendant:SetAttribute("_KCollisionGroup", nil);
                            end;
                        end;
                    end;
                end
            };
        end,

        run = function(p434: any, p435: table) -- Line: 3381, Name: run
            local v436 = p434.alias == "collide";

            for _, v in p435 do
                if v.Character then
                    p434.env.setCollision(v.Character, v436);
                end;
            end;

            p434._K.Remote.Notify:Fire(p434.fromPlayer, {
                From = "_K",
                Text = `<b>Collisions {v436 and "enabled" or "disabled"} for the given player(s) or team(s).</b>`
            });
        end
    }
};