-- Decompiled with Potassium's decompiler.

local Players = game:GetService("Players");
local ReplicatedStorage = game:GetService("ReplicatedStorage");
local UserInputService = game:GetService("UserInputService");
local Modules = ReplicatedStorage:WaitForChild("Modules");
local Remotes = ReplicatedStorage:WaitForChild("Remotes");
local DroppableData = require(Modules.Metadata.ItemData.DroppableData);
local ServerRemote = Remotes.ServerRemote;
local LocalPlayer = Players.LocalPlayer;
local Backspace = Enum.KeyCode.Backspace;
local u1 = 0;
UserInputService.InputBegan:Connect(function(p2, p3) -- Line: 38
    -- upvalues: Backspace (copy), LocalPlayer (copy), DroppableData (copy), u1 (ref), ServerRemote (copy)
    if p3 then
        return;
    end;

    if p2.KeyCode ~= Backspace then
        return;
    end;

    local Character = LocalPlayer.Character;

    if Character then
        Character = Character:FindFirstChildOfClass("Tool");
    end;

    if not Character then
        return;
    end;

    if not DroppableData.Get(Character.Name) then
        return;
    end;

    local os_clock_ret = os.clock();

    if os_clock_ret - u1 < 0.5 then
        return;
    end;

    u1 = os_clock_ret;
    ServerRemote:FireServer(nil, {
        Module = "DropHandler",
        Action = "Drop"
    });
end);

return {};