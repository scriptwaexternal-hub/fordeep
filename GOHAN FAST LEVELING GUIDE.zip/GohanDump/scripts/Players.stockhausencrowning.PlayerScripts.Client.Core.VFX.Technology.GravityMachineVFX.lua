-- Decompiled with Potassium's decompiler.

local Players = game:GetService("Players");
local ReplicatedStorage = game:GetService("ReplicatedStorage");
local RunService = game:GetService("RunService");
local ServerRemote = ReplicatedStorage:WaitForChild("Remotes"):WaitForChild("ServerRemote");
local LocalPlayer = Players.LocalPlayer;
local Color3_fromRGB_ret = Color3.fromRGB(44, 44, 45);
local Color3_fromRGB_ret2 = Color3.fromRGB(28, 28, 30);
local Color3_fromRGB_ret3 = Color3.fromRGB(0, 0, 0);
local Color3_fromRGB_ret4 = Color3.fromRGB(255, 255, 255);
local Color3_fromRGB_ret5 = Color3.fromRGB(216, 213, 205);
local Color3_fromRGB_ret6 = Color3.fromRGB(88, 214, 106);
local Color3_fromRGB_ret7 = Color3.fromRGB(72, 160, 255);
local Color3_fromRGB_ret8 = Color3.fromRGB(225, 70, 60);
local u1 = nil;
local u2 = nil;
local u3 = nil;

local function outline(p4, p5) -- Line: 20
    -- upvalues: Color3_fromRGB_ret3 (copy)
    local UIStroke = Instance.new("UIStroke");
    UIStroke.Color = Color3_fromRGB_ret3;
    UIStroke.Thickness = p5 or 1.5;
    UIStroke.Parent = p4;
end;

local function label(p6, p7, p8, p9, p10, p11, p12) -- Line: 21
    -- upvalues: Color3_fromRGB_ret3 (copy)
    local TextLabel = Instance.new("TextLabel");
    TextLabel.BackgroundTransparency = 1;
    TextLabel.Font = p8;
    TextLabel.TextSize = p9;
    TextLabel.TextColor3 = p10;
    TextLabel.TextStrokeColor3 = Color3_fromRGB_ret3;
    TextLabel.TextStrokeTransparency = 0.5;
    TextLabel.Position = p11;
    TextLabel.Size = p12;
    TextLabel.Text = p7;
    TextLabel.TextXAlignment = Enum.TextXAlignment.Left;
    TextLabel.Parent = p6;

    return TextLabel;
end;

local function button(p13, p14, p15, p16, p17) -- Line: 28
    -- upvalues: Color3_fromRGB_ret2 (copy), Color3_fromRGB_ret4 (copy), Color3_fromRGB_ret3 (copy)
    local TextButton = Instance.new("TextButton");
    TextButton.BackgroundColor3 = p17 or Color3_fromRGB_ret2;
    TextButton.BorderSizePixel = 0;
    TextButton.Font = Enum.Font.Arcade;
    TextButton.TextSize = 13;
    TextButton.TextColor3 = Color3_fromRGB_ret4;
    TextButton.TextStrokeColor3 = Color3_fromRGB_ret3;
    TextButton.TextStrokeTransparency = 0.5;
    TextButton.Position = p15;
    TextButton.Size = p16;
    TextButton.Text = p14;
    TextButton.AutoButtonColor = true;
    TextButton.Parent = p13;
    local UIStroke = Instance.new("UIStroke");
    UIStroke.Color = Color3_fromRGB_ret3;
    UIStroke.Thickness = 1.5;
    UIStroke.Parent = TextButton;

    return TextButton;
end;

local function close() -- Line: 37
    -- upvalues: u3 (ref), u1 (ref), u2 (ref)
    if u3 then
        u3:Disconnect();
        u3 = nil;
    end;

    if u1 then
        u1:Destroy();
        u1 = nil;
    end;

    u2 = nil;
end;

local function fire(p18, p19) -- Line: 43
    -- upvalues: ServerRemote (copy)
    local v20 = {
        Module = "GravityMachineHandler",
        Action = p18
    };

    for i, v in pairs(p19 or {}) do
        v20[i] = v;
    end;

    ServerRemote:FireServer(nil, v20);
end;

local function open(p21) -- Line: 49
    -- upvalues: u3 (ref), u1 (ref), u2 (ref), LocalPlayer (copy), Color3_fromRGB_ret (copy), Color3_fromRGB_ret3 (copy), Color3_fromRGB_ret8 (copy), Color3_fromRGB_ret4 (copy), Color3_fromRGB_ret5 (copy), Color3_fromRGB_ret7 (copy), Color3_fromRGB_ret2 (copy), Color3_fromRGB_ret6 (copy), fire (copy), close (copy), RunService (copy)
    if u3 then
        u3:Disconnect();
        u3 = nil;
    end;

    if u1 then
        u1:Destroy();
        u1 = nil;
    end;

    u2 = nil;
    u2 = p21;
    u1 = Instance.new("ScreenGui");
    u1.Name = "GravityMachineGui";
    u1.ResetOnSpawn = false;
    u1.IgnoreGuiInset = true;
    u1.DisplayOrder = 40;
    u1.Parent = LocalPlayer:WaitForChild("PlayerGui");
    local Frame = Instance.new("Frame");
    Frame.AnchorPoint = Vector2.new(0.5, 1);
    Frame.Position = UDim2.new(0.5, 0, 1, -140);
    Frame.Size = UDim2.fromOffset(300, 238);
    Frame.BackgroundColor3 = Color3_fromRGB_ret;
    Frame.BorderSizePixel = 0;
    Frame.Parent = u1;
    local UIStroke = Instance.new("UIStroke");
    UIStroke.Color = Color3_fromRGB_ret3;
    UIStroke.Thickness = 2;
    UIStroke.Parent = Frame;
    local Frame2 = Instance.new("Frame");
    Frame2.Size = UDim2.new(1, 0, 0, 4);
    Frame2.BackgroundColor3 = Color3_fromRGB_ret8;
    Frame2.BorderSizePixel = 0;
    Frame2.Parent = Frame;
    local Arcade = Enum.Font.Arcade;
    local UDim2_fromOffset_ret = UDim2.fromOffset(12, 12);
    local UDim2_new_ret = UDim2.new(1, -24, 0, 18);
    local TextLabel = Instance.new("TextLabel");
    TextLabel.BackgroundTransparency = 1;
    TextLabel.Font = Arcade;
    TextLabel.TextSize = 14;
    TextLabel.TextColor3 = Color3_fromRGB_ret4;
    TextLabel.TextStrokeColor3 = Color3_fromRGB_ret3;
    TextLabel.TextStrokeTransparency = 0.5;
    TextLabel.Position = UDim2_fromOffset_ret;
    TextLabel.Size = UDim2_new_ret;
    TextLabel.Text = "GRAVITY MACHINE";
    TextLabel.TextXAlignment = Enum.TextXAlignment.Left;
    TextLabel.Parent = Frame;
    local Arcade2 = Enum.Font.Arcade;
    local UDim2_fromOffset_ret2 = UDim2.fromOffset(12, 34);
    local UDim2_new_ret2 = UDim2.new(0.5, -12, 0, 16);
    local TextLabel2 = Instance.new("TextLabel");
    TextLabel2.BackgroundTransparency = 1;
    TextLabel2.Font = Arcade2;
    TextLabel2.TextSize = 12;
    TextLabel2.TextColor3 = Color3_fromRGB_ret5;
    TextLabel2.TextStrokeColor3 = Color3_fromRGB_ret3;
    TextLabel2.TextStrokeTransparency = 0.5;
    TextLabel2.Position = UDim2_fromOffset_ret2;
    TextLabel2.Size = UDim2_new_ret2;
    TextLabel2.Text = "OFF";
    TextLabel2.TextXAlignment = Enum.TextXAlignment.Left;
    TextLabel2.Parent = Frame;
    local Bangers = Enum.Font.Bangers;
    local UDim2_fromOffset_ret3 = UDim2.fromOffset(110, 44);
    local UDim2_fromOffset_ret4 = UDim2.fromOffset(80, 36);
    local TextLabel3 = Instance.new("TextLabel");
    TextLabel3.BackgroundTransparency = 1;
    TextLabel3.Font = Bangers;
    TextLabel3.TextSize = 30;
    TextLabel3.TextColor3 = Color3_fromRGB_ret7;
    TextLabel3.TextStrokeColor3 = Color3_fromRGB_ret3;
    TextLabel3.TextStrokeTransparency = 0.5;
    TextLabel3.Position = UDim2_fromOffset_ret3;
    TextLabel3.Size = UDim2_fromOffset_ret4;
    TextLabel3.Text = "10 G";
    TextLabel3.TextXAlignment = Enum.TextXAlignment.Left;
    TextLabel3.Parent = Frame;
    TextLabel3.TextXAlignment = Enum.TextXAlignment.Center;
    local UDim2_fromOffset_ret5 = UDim2.fromOffset(12, 50);
    local UDim2_fromOffset_ret6, v22 = UDim2.fromOffset(60, 34);
    local TextButton = Instance.new("TextButton");
    TextButton.BackgroundColor3 = v22 or Color3_fromRGB_ret2;
    TextButton.BorderSizePixel = 0;
    TextButton.Font = Enum.Font.Arcade;
    TextButton.TextSize = 13;
    TextButton.TextColor3 = Color3_fromRGB_ret4;
    TextButton.TextStrokeColor3 = Color3_fromRGB_ret3;
    TextButton.TextStrokeTransparency = 0.5;
    TextButton.Position = UDim2_fromOffset_ret5;
    TextButton.Size = UDim2_fromOffset_ret6;
    TextButton.Text = "-";
    TextButton.AutoButtonColor = true;
    TextButton.Parent = Frame;
    local UIStroke2 = Instance.new("UIStroke");
    UIStroke2.Color = Color3_fromRGB_ret3;
    UIStroke2.Thickness = 1.5;
    UIStroke2.Parent = TextButton;
    local UDim2_fromOffset_ret7 = UDim2.fromOffset(228, 50);
    local UDim2_fromOffset_ret8, v23 = UDim2.fromOffset(60, 34);
    local TextButton2 = Instance.new("TextButton");
    TextButton2.BackgroundColor3 = v23 or Color3_fromRGB_ret2;
    TextButton2.BorderSizePixel = 0;
    TextButton2.Font = Enum.Font.Arcade;
    TextButton2.TextSize = 13;
    TextButton2.TextColor3 = Color3_fromRGB_ret4;
    TextButton2.TextStrokeColor3 = Color3_fromRGB_ret3;
    TextButton2.TextStrokeTransparency = 0.5;
    TextButton2.Position = UDim2_fromOffset_ret7;
    TextButton2.Size = UDim2_fromOffset_ret8;
    TextButton2.Text = "+";
    TextButton2.AutoButtonColor = true;
    TextButton2.Parent = Frame;
    local UIStroke3 = Instance.new("UIStroke");
    UIStroke3.Color = Color3_fromRGB_ret3;
    UIStroke3.Thickness = 1.5;
    UIStroke3.Parent = TextButton2;
    local Arcade3 = Enum.Font.Arcade;
    local UDim2_fromOffset_ret9 = UDim2.fromOffset(12, 92);
    local UDim2_new_ret3 = UDim2.new(0.5, -12, 0, 14);
    local TextLabel4 = Instance.new("TextLabel");
    TextLabel4.BackgroundTransparency = 1;
    TextLabel4.Font = Arcade3;
    TextLabel4.TextSize = 11;
    TextLabel4.TextColor3 = Color3_fromRGB_ret5;
    TextLabel4.TextStrokeColor3 = Color3_fromRGB_ret3;
    TextLabel4.TextStrokeTransparency = 0.5;
    TextLabel4.Position = UDim2_fromOffset_ret9;
    TextLabel4.Size = UDim2_new_ret3;
    TextLabel4.Text = "RANGE";
    TextLabel4.TextXAlignment = Enum.TextXAlignment.Left;
    TextLabel4.Parent = Frame;
    local Bangers2 = Enum.Font.Bangers;
    local UDim2_fromOffset_ret10 = UDim2.fromOffset(110, 100);
    local UDim2_fromOffset_ret11 = UDim2.fromOffset(80, 26);
    local TextLabel5 = Instance.new("TextLabel");
    TextLabel5.BackgroundTransparency = 1;
    TextLabel5.Font = Bangers2;
    TextLabel5.TextSize = 20;
    TextLabel5.TextColor3 = Color3_fromRGB_ret7;
    TextLabel5.TextStrokeColor3 = Color3_fromRGB_ret3;
    TextLabel5.TextStrokeTransparency = 0.5;
    TextLabel5.Position = UDim2_fromOffset_ret10;
    TextLabel5.Size = UDim2_fromOffset_ret11;
    TextLabel5.Text = "60 ST";
    TextLabel5.TextXAlignment = Enum.TextXAlignment.Left;
    TextLabel5.Parent = Frame;
    TextLabel5.TextXAlignment = Enum.TextXAlignment.Center;
    local UDim2_fromOffset_ret12 = UDim2.fromOffset(12, 108);
    local UDim2_fromOffset_ret13, v24 = UDim2.fromOffset(60, 26);
    local TextButton3 = Instance.new("TextButton");
    TextButton3.BackgroundColor3 = v24 or Color3_fromRGB_ret2;
    TextButton3.BorderSizePixel = 0;
    TextButton3.Font = Enum.Font.Arcade;
    TextButton3.TextSize = 13;
    TextButton3.TextColor3 = Color3_fromRGB_ret4;
    TextButton3.TextStrokeColor3 = Color3_fromRGB_ret3;
    TextButton3.TextStrokeTransparency = 0.5;
    TextButton3.Position = UDim2_fromOffset_ret12;
    TextButton3.Size = UDim2_fromOffset_ret13;
    TextButton3.Text = "-";
    TextButton3.AutoButtonColor = true;
    TextButton3.Parent = Frame;
    local UIStroke4 = Instance.new("UIStroke");
    UIStroke4.Color = Color3_fromRGB_ret3;
    UIStroke4.Thickness = 1.5;
    UIStroke4.Parent = TextButton3;
    local UDim2_fromOffset_ret14 = UDim2.fromOffset(228, 108);
    local UDim2_fromOffset_ret15, v25 = UDim2.fromOffset(60, 26);
    local TextButton4 = Instance.new("TextButton");
    TextButton4.BackgroundColor3 = v25 or Color3_fromRGB_ret2;
    TextButton4.BorderSizePixel = 0;
    TextButton4.Font = Enum.Font.Arcade;
    TextButton4.TextSize = 13;
    TextButton4.TextColor3 = Color3_fromRGB_ret4;
    TextButton4.TextStrokeColor3 = Color3_fromRGB_ret3;
    TextButton4.TextStrokeTransparency = 0.5;
    TextButton4.Position = UDim2_fromOffset_ret14;
    TextButton4.Size = UDim2_fromOffset_ret15;
    TextButton4.Text = "+";
    TextButton4.AutoButtonColor = true;
    TextButton4.Parent = Frame;
    local UIStroke5 = Instance.new("UIStroke");
    UIStroke5.Color = Color3_fromRGB_ret3;
    UIStroke5.Thickness = 1.5;
    UIStroke5.Parent = TextButton4;
    local UDim2_fromOffset_ret16 = UDim2.fromOffset(12, 146);
    local UDim2_fromOffset_ret17 = UDim2.fromOffset(160, 36);
    local TextButton5 = Instance.new("TextButton");
    TextButton5.BackgroundColor3 = Color3_fromRGB_ret6 or Color3_fromRGB_ret2;
    TextButton5.BorderSizePixel = 0;
    TextButton5.Font = Enum.Font.Arcade;
    TextButton5.TextSize = 13;
    TextButton5.TextColor3 = Color3_fromRGB_ret4;
    TextButton5.TextStrokeColor3 = Color3_fromRGB_ret3;
    TextButton5.TextStrokeTransparency = 0.5;
    TextButton5.Position = UDim2_fromOffset_ret16;
    TextButton5.Size = UDim2_fromOffset_ret17;
    TextButton5.Text = "TURN ON";
    TextButton5.AutoButtonColor = true;
    TextButton5.Parent = Frame;
    local UIStroke6 = Instance.new("UIStroke");
    UIStroke6.Color = Color3_fromRGB_ret3;
    UIStroke6.Thickness = 1.5;
    UIStroke6.Parent = TextButton5;
    TextButton5.TextColor3 = Color3_fromRGB_ret4;
    local UDim2_fromOffset_ret18 = UDim2.fromOffset(180, 146);
    local UDim2_fromOffset_ret19, v26 = UDim2.fromOffset(108, 36);
    local TextButton6 = Instance.new("TextButton");
    TextButton6.BackgroundColor3 = v26 or Color3_fromRGB_ret2;
    TextButton6.BorderSizePixel = 0;
    TextButton6.Font = Enum.Font.Arcade;
    TextButton6.TextSize = 13;
    TextButton6.TextColor3 = Color3_fromRGB_ret4;
    TextButton6.TextStrokeColor3 = Color3_fromRGB_ret3;
    TextButton6.TextStrokeTransparency = 0.5;
    TextButton6.Position = UDim2_fromOffset_ret18;
    TextButton6.Size = UDim2_fromOffset_ret19;
    TextButton6.Text = "PICK UP";
    TextButton6.AutoButtonColor = true;
    TextButton6.Parent = Frame;
    local UIStroke7 = Instance.new("UIStroke");
    UIStroke7.Color = Color3_fromRGB_ret3;
    UIStroke7.Thickness = 1.5;
    UIStroke7.Parent = TextButton6;
    local UDim2_fromOffset_ret20 = UDim2.fromOffset(12, 190);
    local UDim2_fromOffset_ret21, v27 = UDim2.fromOffset(276, 34);
    local TextButton7 = Instance.new("TextButton");
    TextButton7.BackgroundColor3 = v27 or Color3_fromRGB_ret2;
    TextButton7.BorderSizePixel = 0;
    TextButton7.Font = Enum.Font.Arcade;
    TextButton7.TextSize = 13;
    TextButton7.TextColor3 = Color3_fromRGB_ret4;
    TextButton7.TextStrokeColor3 = Color3_fromRGB_ret3;
    TextButton7.TextStrokeTransparency = 0.5;
    TextButton7.Position = UDim2_fromOffset_ret20;
    TextButton7.Size = UDim2_fromOffset_ret21;
    TextButton7.Text = "REPAIR  (10 GEARS)";
    TextButton7.AutoButtonColor = true;
    TextButton7.Parent = Frame;
    local UIStroke8 = Instance.new("UIStroke");
    UIStroke8.Color = Color3_fromRGB_ret3;
    UIStroke8.Thickness = 1.5;
    UIStroke8.Parent = TextButton7;

    local function refresh() -- Line: 81
        -- upvalues: u2 (ref), u3 (ref), u1 (ref), TextLabel2 (copy), Color3_fromRGB_ret6 (ref), Color3_fromRGB_ret5 (ref), TextLabel3 (copy), TextLabel5 (copy), TextButton7 (copy), Color3_fromRGB_ret4 (ref), TextButton5 (copy), Color3_fromRGB_ret8 (ref), Frame2 (copy), Color3_fromRGB_ret7 (ref)
        if not (u2 and u2.Parent) then
            if u3 then
                u3:Disconnect();
                u3 = nil;
            end;

            if u1 then
                u1:Destroy();
                u1 = nil;
            end;

            u2 = nil;

            return;
        end;

        local v28 = u2:GetAttribute("On") == true;
        local v29 = u2:GetAttribute("Gravity") or 10;
        TextLabel2.Text = v28 and "FIELD ACTIVE" or "OFF";
        TextLabel2.TextColor3 = v28 and Color3_fromRGB_ret6 or Color3_fromRGB_ret5;
        TextLabel3.Text = tostring(v29) .. " G";
        local v30 = u2:GetAttribute("Range") or 60;
        TextLabel5.Text = tostring(v30) .. " ST";
        local v31 = tonumber(u2:GetAttribute("Health"));
        local v32 = tonumber(u2:GetAttribute("MaxHealth"));
        local v33;

        if v31 then
            if v32 then
                v33 = v31 < v32;
            else
                v33 = v32;
            end;
        else
            v33 = v31;
        end;

        TextButton7.Text = v33 and ("REPAIR  (10 GEARS)   %d / %d"):format(v31, v32) or "NO DAMAGE";
        TextButton7.TextColor3 = v33 and Color3_fromRGB_ret4 or Color3_fromRGB_ret5;
        TextButton7.AutoButtonColor = v33 == true;
        TextButton5.Text = v28 and "TURN OFF" or "TURN ON";
        TextButton5.BackgroundColor3 = v28 and Color3_fromRGB_ret8 or Color3_fromRGB_ret6;
        Frame2.BackgroundColor3 = v28 and Color3_fromRGB_ret8 or Color3_fromRGB_ret7;
    end;

    TextButton.Activated:Connect(function() -- Line: 98
        -- upvalues: fire (ref)
        fire("Gravity", {
            Delta = -10
        });
    end);
    TextButton2.Activated:Connect(function() -- Line: 99
        -- upvalues: fire (ref)
        fire("Gravity", {
            Delta = 10
        });
    end);
    TextButton3.Activated:Connect(function() -- Line: 100
        -- upvalues: fire (ref)
        fire("Range", {
            Delta = -10
        });
    end);
    TextButton4.Activated:Connect(function() -- Line: 101
        -- upvalues: fire (ref)
        fire("Range", {
            Delta = 10
        });
    end);
    TextButton5.Activated:Connect(function() -- Line: 102
        -- upvalues: fire (ref)
        fire("Toggle");
    end);
    TextButton7.Activated:Connect(function() -- Line: 103
        -- upvalues: fire (ref)
        fire("Repair");
    end);
    TextButton6.Activated:Connect(function() -- Line: 104
        -- upvalues: fire (ref), close (ref)
        fire("PickUp");
        task.delay(0.2, close);
    end);
    p21.AttributeChanged:Connect(refresh);
    refresh();
    u3 = RunService.Heartbeat:Connect(function() -- Line: 108
        -- upvalues: LocalPlayer (ref), u2 (ref), u3 (ref), u1 (ref)
        local Character = LocalPlayer.Character;

        if Character then
            Character = Character:FindFirstChild("HumanoidRootPart");
        end;

        if Character and (u2 and u2.Parent) then
            if (u2:GetPivot().Position - Character.Position).Magnitude > 16 then
                if u3 then
                    u3:Disconnect();
                    u3 = nil;
                end;

                if u1 then
                    u1:Destroy();
                    u1 = nil;
                end;

                u2 = nil;
            end;

            return;
        end;

        if u3 then
            u3:Disconnect();
            u3 = nil;
        end;

        if u1 then
            u1:Destroy();
            u1 = nil;
        end;

        u2 = nil;
    end);
end;

return {
    Open = function(p34) -- Line: 117
        -- upvalues: open (copy)
        local Machine = p34.Machine;

        if Machine and Machine:IsA("Model") then
            open(Machine);
        end;
    end,

    Close = function() -- Line: 121
        -- upvalues: u3 (ref), u1 (ref), u2 (ref)
        if u3 then
            u3:Disconnect();
            u3 = nil;
        end;

        if u1 then
            u1:Destroy();
            u1 = nil;
        end;

        u2 = nil;
    end
};