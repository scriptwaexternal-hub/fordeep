-- Decompiled with Potassium's decompiler.

local Players = game:GetService("Players");
local ReplicatedStorage = game:GetService("ReplicatedStorage");
local UserInputService = game:GetService("UserInputService");
local RunService = game:GetService("RunService");
local Modules = ReplicatedStorage:WaitForChild("Modules");
local Remotes = ReplicatedStorage:WaitForChild("Remotes");
local Metadata = Modules.Metadata;
local ControlData = require(Metadata.ControlData.ControlData);
local Platform = require(Modules.Shared.Platform);
local ZoneData = require(Metadata.ZoneData.ZoneData);

local function isPlaceZone(p1) -- Line: 33
    -- upvalues: ZoneData (copy)
    local v2 = ZoneData[p1.Name];

    if type(v2) == "table" and v2["Quest Location"] then
        return false;
    end;

    return not p1.Name:find("Delivery");
end;

local Bangers = Enum.Font.Bangers;
local Color3_fromRGB_ret = Color3.fromRGB(255, 253, 247);
local Color3_fromRGB_ret2 = Color3.fromRGB(255, 196, 68);
Color3.fromRGB(196, 156, 74);
local Color3_fromRGB_ret3 = Color3.fromRGB(122, 220, 122);
local Color3_fromRGB_ret4 = Color3.fromRGB(8, 7, 6);
local LocalPlayer = Players.LocalPlayer;
local World = workspace:WaitForChild("World");
local TouchActionRemote = Remotes:WaitForChild("TouchActionRemote");
local u3 = ReplicatedStorage:WaitForChild("Assets"):WaitForChild("Gui"):WaitForChild("FastTravel"):WaitForChild("Bus Marker");
local u4 = false;
local u5 = nil;
local u6 = nil;
local u7 = {};
local u8 = nil;
local u9 = nil;
local u10 = nil;

local function keyName() -- Line: 66
    -- upvalues: ControlData (copy)
    local v11 = ControlData.Controls.Overlay and ControlData.Controls.Overlay["Zone Map"];

    return v11 and v11[1] or "U";
end;

local function zonesFolder() -- Line: 72
    -- upvalues: World (copy)
    local Map = World:FindFirstChild("Map");

    if Map then
        Map = Map:FindFirstChild("Zones");
    end;

    return Map;
end;

local function busStops() -- Line: 77
    -- upvalues: World (copy)
    local Map = World:FindFirstChild("Map");

    if Map then
        Map = Map:FindFirstChild("Fast Travel");
    end;

    local v12 = {};

    if Map then
        for _, child in ipairs(Map:GetChildren()) do
            local Location = child:FindFirstChild("Location");

            if Location and Location:IsA("BasePart") then
                table.insert(v12, {
                    Name = child.Name,
                    Part = Location
                });
            end;
        end;
    end;

    return v12;
end;

local function findStoryNpc() -- Line: 92
    -- upvalues: World (copy)
    local NPC = World:FindFirstChild("NPC");

    if not NPC then
        return nil;
    end;

    for _, descendant in ipairs(NPC:GetDescendants()) do
        if (descendant.Name == "StoryMarker" or descendant.Name == "Marker") and (descendant:IsA("BillboardGui") and (descendant.Parent and descendant.Parent:IsA("Model"))) then
            return descendant.Parent;
        end;
    end;

    local Map = World:FindFirstChild("Map");

    if Map then
        Map = Map:FindFirstChild("Indicators");
    end;

    if Map then
        for _, descendant in ipairs(Map:GetDescendants()) do
            if descendant:IsA("BillboardGui") and descendant.Enabled then
                local Parent = descendant.Parent;

                if Parent then
                    Parent = Parent.Name;
                end;

                for _, descendant2 in ipairs(NPC:GetDescendants()) do
                    if descendant2:IsA("Model") and descendant2.Name == Parent then
                        return descendant2;
                    end;
                end;
            end;
        end;
    end;

    return nil;
end;

local function label(p13, p14, p15, p16, p17) -- Line: 118
    -- upvalues: Bangers (copy), Color3_fromRGB_ret4 (copy)
    local TextLabel = Instance.new("TextLabel");
    TextLabel.BackgroundTransparency = 1;
    TextLabel.Size = UDim2.new(1, 0, 0, p15 + 4);
    TextLabel.Font = Bangers;
    TextLabel.TextSize = p15;
    TextLabel.TextColor3 = p16;
    TextLabel.TextStrokeColor3 = Color3_fromRGB_ret4;
    TextLabel.TextStrokeTransparency = 0;
    TextLabel.Text = p14;
    TextLabel.LayoutOrder = p17 or 0;
    TextLabel.Parent = p13;

    return TextLabel;
end;

local function makeBillboard(p18, p19, p20) -- Line: 133
    local BillboardGui = Instance.new("BillboardGui");
    BillboardGui.Name = "ZoneSenseTag";
    BillboardGui.AlwaysOnTop = true;
    BillboardGui.Size = UDim2.fromOffset(p20 or 220, 60);
    BillboardGui.StudsOffsetWorldSpace = Vector3.new(0, p19 or 0, 0);
    BillboardGui.MaxDistance = (1 / 0);
    BillboardGui.LightInfluence = 0;
    BillboardGui.Adornee = p18;
    local UIListLayout = Instance.new("UIListLayout");
    UIListLayout.HorizontalAlignment = Enum.HorizontalAlignment.Center;
    UIListLayout.SortOrder = Enum.SortOrder.LayoutOrder;
    UIListLayout.Parent = BillboardGui;

    return BillboardGui;
end;

local function ensureGui() -- Line: 149
    -- upvalues: u5 (ref), LocalPlayer (copy), u6 (ref)
    if u5 and u5.Parent then
        return;
    end;

    u5 = Instance.new("ScreenGui");
    u5.Name = "ZoneSenseGui";
    u5.ResetOnSpawn = false;
    u5.IgnoreGuiInset = true;
    u5.DisplayOrder = 12;
    u5.Enabled = false;
    u5.Parent = LocalPlayer:WaitForChild("PlayerGui");
    u6 = Instance.new("Frame");
    u6.Name = "Overlay";
    u6.Size = UDim2.fromScale(1, 1);
    u6.BackgroundColor3 = Color3.new(0, 0, 0);
    u6.BackgroundTransparency = 0.45;
    u6.BorderSizePixel = 0;
    u6.Parent = u5;
end;

local function clearTags() -- Line: 169
    -- upvalues: u7 (copy), u8 (ref), u9 (ref)
    for _, v in pairs(u7) do
        v:Destroy();
    end;

    table.clear(u7);

    if u8 then
        u8:Destroy();
        u8 = nil;
    end;

    if u9 then
        u9:Destroy();
        u9 = nil;
    end;
end;

local function refresh() -- Line: 176
    -- upvalues: LocalPlayer (copy), u7 (copy), u3 (copy), Bangers (copy), Color3_fromRGB_ret2 (copy), Color3_fromRGB_ret4 (copy), makeBillboard (copy), Color3_fromRGB_ret (copy), u5 (ref), World (copy), ZoneData (copy), busStops (copy), findStoryNpc (copy), u9 (ref), Color3_fromRGB_ret3 (copy), u8 (ref)
    local Character = LocalPlayer.Character;

    if Character then
        Character = Character:FindFirstChild("HumanoidRootPart");
    end;

    if not Character then
        return;
    end;

    local Position = Character.Position;

    local function tag(p21, p22, p23, p24) -- Line: 184
        -- upvalues: Position (copy), u7 (ref), u3 (ref), Bangers (ref), Color3_fromRGB_ret2 (ref), Color3_fromRGB_ret4 (ref), makeBillboard (ref), Color3_fromRGB_ret (ref), u5 (ref)
        local Magnitude = (p22.Position - Position).Magnitude;

        if Magnitude > 2500 then
            if u7[p21] then
                u7[p21]:Destroy();
                u7[p21] = nil;
            end;

            return;
        end;

        local v25 = u7[p21];

        if not v25 then
            if p24 then
                v25 = u3:Clone();
                v25.Name = "ZoneSenseBus";
                v25.Adornee = p22;
                v25.MaxDistance = (1 / 0);
                local TextLabel = Instance.new("TextLabel");
                TextLabel.Name = "Dist";
                TextLabel.AnchorPoint = Vector2.new(0.5, 0);
                TextLabel.Position = UDim2.new(0.5, 0, 1, 2);
                TextLabel.Size = UDim2.new(3, 0, 0, 22);
                TextLabel.BackgroundTransparency = 1;
                TextLabel.Font = Bangers;
                TextLabel.TextSize = 18;
                TextLabel.TextColor3 = Color3_fromRGB_ret2;
                TextLabel.TextStrokeColor3 = Color3_fromRGB_ret4;
                TextLabel.TextStrokeTransparency = 0;
                TextLabel.Parent = v25;
            else
                v25 = makeBillboard(p22, 0, 240);
                local v26 = p23:upper();
                local TextLabel = Instance.new("TextLabel");
                TextLabel.BackgroundTransparency = 1;
                TextLabel.Size = UDim2.new(1, 0, 0, 30);
                TextLabel.Font = Bangers;
                TextLabel.TextSize = 26;
                TextLabel.TextColor3 = Color3_fromRGB_ret;
                TextLabel.TextStrokeColor3 = Color3_fromRGB_ret4;
                TextLabel.TextStrokeTransparency = 0;
                TextLabel.Text = v26;
                TextLabel.LayoutOrder = 2;
                TextLabel.Parent = v25;
                TextLabel.Name = "Name";
                local TextLabel2 = Instance.new("TextLabel");
                TextLabel2.BackgroundTransparency = 1;
                TextLabel2.Size = UDim2.new(1, 0, 0, 22);
                TextLabel2.Font = Bangers;
                TextLabel2.TextSize = 18;
                TextLabel2.TextColor3 = Color3_fromRGB_ret2;
                TextLabel2.TextStrokeColor3 = Color3_fromRGB_ret4;
                TextLabel2.TextStrokeTransparency = 0;
                TextLabel2.Text = "";
                TextLabel2.LayoutOrder = 3;
                TextLabel2.Parent = v25;
                TextLabel2.Name = "Dist";
            end;

            v25.Parent = u5;
            u7[p21] = v25;
        end;

        v25.Dist.Text = ("%d studs"):format(Magnitude);
    end;

    local Map = World:FindFirstChild("Map");

    if Map then
        Map = Map:FindFirstChild("Zones");
    end;

    if Map then
        for _, child in ipairs(Map:GetChildren()) do
            local v27 = ZoneData[child.Name];
            local v28;

            if type(v27) == "table" and v27["Quest Location"] then
                v28 = false;
            else
                v28 = not child.Name:find("Delivery");
            end;

            if v28 then
                local v29 = child:IsA("BasePart") and child and child or child:FindFirstChildWhichIsA("BasePart", true);

                if v29 then
                    tag(child, v29, child.Name, false);
                end;
            end;
        end;
    end;

    for _, v in ipairs((busStops())) do
        tag(v.Part, v.Part, v.Name, true);
    end;

    local v30 = findStoryNpc();

    if v30 then
        if not u9 or u9.Adornee ~= v30 then
            if u9 then
                u9:Destroy();
            end;

            u9 = Instance.new("Highlight");
            u9.Name = "ZoneSenseStory";
            u9.Adornee = v30;
            u9.FillColor = Color3_fromRGB_ret3;
            u9.OutlineColor = Color3_fromRGB_ret3;
            u9.FillTransparency = 0.6;
            u9.OutlineTransparency = 0;
            u9.DepthMode = Enum.HighlightDepthMode.AlwaysOnTop;
            u9.Parent = v30;

            if u8 then
                u8:Destroy();
            end;

            local v31 = v30:FindFirstChild("HumanoidRootPart") or (v30.PrimaryPart or v30:FindFirstChildWhichIsA("BasePart"));

            if v31 then
                u8 = makeBillboard(v31, 6, 260);
                local TextLabel = Instance.new("TextLabel");
                TextLabel.BackgroundTransparency = 1;
                TextLabel.Size = UDim2.new(1, 0, 0, 20);
                TextLabel.Font = Bangers;
                TextLabel.TextSize = 16;
                TextLabel.TextColor3 = Color3_fromRGB_ret3;
                TextLabel.TextStrokeColor3 = Color3_fromRGB_ret4;
                TextLabel.TextStrokeTransparency = 0;
                TextLabel.Text = "STORY: TALK TO";
                TextLabel.LayoutOrder = 1;
                TextLabel.Parent = u8;
                local v32 = v30.Name:upper();
                local TextLabel2 = Instance.new("TextLabel");
                TextLabel2.BackgroundTransparency = 1;
                TextLabel2.Size = UDim2.new(1, 0, 0, 30);
                TextLabel2.Font = Bangers;
                TextLabel2.TextSize = 26;
                TextLabel2.TextColor3 = Color3_fromRGB_ret;
                TextLabel2.TextStrokeColor3 = Color3_fromRGB_ret4;
                TextLabel2.TextStrokeTransparency = 0;
                TextLabel2.Text = v32;
                TextLabel2.LayoutOrder = 2;
                TextLabel2.Parent = u8;
                TextLabel2.Name = "Name";
                local TextLabel3 = Instance.new("TextLabel");
                TextLabel3.BackgroundTransparency = 1;
                TextLabel3.Size = UDim2.new(1, 0, 0, 22);
                TextLabel3.Font = Bangers;
                TextLabel3.TextSize = 18;
                TextLabel3.TextColor3 = Color3_fromRGB_ret2;
                TextLabel3.TextStrokeColor3 = Color3_fromRGB_ret4;
                TextLabel3.TextStrokeTransparency = 0;
                TextLabel3.Text = "";
                TextLabel3.LayoutOrder = 3;
                TextLabel3.Parent = u8;
                TextLabel3.Name = "Dist";
                u8.Parent = u5;
            end;
        end;

        local v33 = u8 and (v30:FindFirstChild("HumanoidRootPart") or v30.PrimaryPart);

        if v33 then
            u8.Dist.Text = ("%d studs"):format((v33.Position - Position).Magnitude);
        end;
    else
        if u9 then
            u9:Destroy();
            u9 = nil;
        end;

        if u8 then
            u8:Destroy();
            u8 = nil;
        end;
    end;
end;

local function show() -- Line: 267
    -- upvalues: u4 (ref), ensureGui (copy), u5 (ref), refresh (copy), u10 (ref), RunService (copy)
    if u4 then
        return;
    end;

    u4 = true;
    ensureGui();
    u5.Enabled = true;
    refresh();
    local u34 = 0;
    u10 = RunService.RenderStepped:Connect(function(p35) -- Line: 274
        -- upvalues: u34 (ref), refresh (ref)
        u34 = u34 + p35;

        if u34 >= 0.2 then
            u34 = 0;
            refresh();
        end;
    end);
end;

local function hide() -- Line: 280
    -- upvalues: u4 (ref), u10 (ref), clearTags (copy), u5 (ref)
    if not u4 then
        return;
    end;

    u4 = false;

    if u10 then
        u10:Disconnect();
        u10 = nil;
    end;

    clearTags();

    if u5 then
        u5.Enabled = false;
    end;
end;

UserInputService.InputBegan:Connect(function(p36, p37) -- Line: 290
    -- upvalues: ControlData (copy), u4 (ref), ensureGui (copy), u5 (ref), refresh (copy), u10 (ref), RunService (copy)
    if p37 then
        return;
    end;

    if p36.UserInputType ~= Enum.UserInputType.Keyboard then
        return;
    end;

    local v38 = ControlData.Controls.Overlay and ControlData.Controls.Overlay["Zone Map"];

    if p36.KeyCode.Name == (v38 and v38[1] or "U") then
        if u4 then
            return;
        end;

        u4 = true;
        ensureGui();
        u5.Enabled = true;
        refresh();
        local u39 = 0;
        u10 = RunService.RenderStepped:Connect(function(p40) -- Line: 274
            -- upvalues: u39 (ref), refresh (ref)
            u39 = u39 + p40;

            if u39 >= 0.2 then
                u39 = 0;
                refresh();
            end;
        end);
    end;
end);
UserInputService.InputEnded:Connect(function(p41) -- Line: 295
    -- upvalues: ControlData (copy), u4 (ref), u10 (ref), clearTags (copy), u5 (ref)
    if p41.UserInputType ~= Enum.UserInputType.Keyboard then
        return;
    end;

    local v42 = ControlData.Controls.Overlay and ControlData.Controls.Overlay["Zone Map"];

    if p41.KeyCode.Name == (v42 and v42[1] or "U") then
        if not u4 then
            return;
        end;

        u4 = false;

        if u10 then
            u10:Disconnect();
            u10 = nil;
        end;

        clearTags();

        if u5 then
            u5.Enabled = false;
        end;
    end;
end);
TouchActionRemote.Event:Connect(function(p43, p44, p45, p46) -- Line: 301
    -- upvalues: u4 (ref), u10 (ref), clearTags (copy), u5 (ref), Platform (copy), ensureGui (copy), refresh (copy), RunService (copy)
    if p43 ~= "Overlay" or p44 ~= "Zone Map" then
        return;
    end;

    if p46 == "End" then
        if not u4 then
            return;
        end;

        u4 = false;

        if u10 then
            u10:Disconnect();
            u10 = nil;
        end;

        clearTags();

        if u5 then
            u5.Enabled = false;
        end;

        return;
    end;

    if not Platform.IsTouch() then
        if u4 then
            if not u4 then
                return;
            end;

            u4 = false;

            if u10 then
                u10:Disconnect();
                u10 = nil;
            end;

            clearTags();

            if u5 then
                u5.Enabled = false;

                return;
            end;
        else
            if u4 then
                return;
            end;

            u4 = true;
            ensureGui();
            u5.Enabled = true;
            refresh();
            local u47 = 0;
            u10 = RunService.RenderStepped:Connect(function(p48) -- Line: 274
                -- upvalues: u47 (ref), refresh (ref)
                u47 = u47 + p48;

                if u47 >= 0.2 then
                    u47 = 0;
                    refresh();
                end;
            end);
        end;

        return;
    end;

    if u4 then
        return;
    end;

    u4 = true;
    ensureGui();
    u5.Enabled = true;
    refresh();
    local u49 = 0;
    u10 = RunService.RenderStepped:Connect(function(p50) -- Line: 274
        -- upvalues: u49 (ref), refresh (ref)
        u49 = u49 + p50;

        if u49 >= 0.2 then
            u49 = 0;
            refresh();
        end;
    end);
end);
LocalPlayer.CharacterAdded:Connect(hide);
UserInputService.WindowFocusReleased:Connect(hide);