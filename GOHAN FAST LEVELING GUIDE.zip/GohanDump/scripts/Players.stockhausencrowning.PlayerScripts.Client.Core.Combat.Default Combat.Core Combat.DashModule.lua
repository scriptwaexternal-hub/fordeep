-- Decompiled with Potassium's decompiler.

local ReplicatedStorage = game:GetService("ReplicatedStorage");
local UserInputService = game:GetService("UserInputService");
local RunService = game:GetService("RunService");
local Players = game:GetService("Players");
game:GetService("Debris");
local Modules = ReplicatedStorage:WaitForChild("Modules");
local Utility = Modules.Utility;
local Shared = Modules.Shared;
local AnimationManager = require(Shared.AnimationManager);
local GlobalFunctions = require(Modules.GlobalFunctions);
local HitboxHandler = require(Utility.HitboxHandler);
local FindCharacters = require(Shared.FindCharacters);
local UtilityHandler = require(Utility.UtilityHandler);
local StateManager = require(Modules.Metadata.ControlData.StateManager);
local StateDefinitions = require(Modules.Metadata.StateData.StateDefinitions);
local ControlData = require(Modules.Metadata.ControlData.ControlData);
local Platform = require(Shared.Platform);
local ServerRemote = ReplicatedStorage.Remotes.ServerRemote;
local StatRetrieveRemote = ReplicatedStorage.Remotes.StatRetrieveRemote;
local StateSyncRemote = ReplicatedStorage.Remotes.StateSyncRemote;
local LocalPlayer = Players.LocalPlayer;
local workspace_CurrentCamera = workspace.CurrentCamera;
local u1 = require(Shared:WaitForChild("Mouse")).new();

local function isRunKeyHeld() -- Line: 59
    -- upvalues: ControlData (copy), Platform (copy), UserInputService (copy)
    local v2 = ControlData.Controls and ControlData.Controls.Combat and ControlData.Controls.Combat.Run;

    if type(v2) ~= "table" then
        return false;
    end;

    for _, v in ipairs(v2) do
        if type(v) == "string" then
            local v3 = Enum.KeyCode[v];

            if v3 then
                if v:sub(1, 6) == "Button" or (v:sub(1, 4) == "DPad" or v:sub(1, 10) == "Thumbstick") then
                    if Platform.IsButtonDown(v3) then
                        return true;
                    end;
                elseif UserInputService:IsKeyDown(v3) then
                    return true;
                end;
            end;
        end;
    end;

    return false;
end;

local function resumeSprintIfHeld(u4) -- Line: 85
    -- upvalues: StateManager (copy), isRunKeyHeld (copy), ServerRemote (copy)
    task.spawn(function() -- Line: 86
        -- upvalues: u4 (copy), StateManager (ref), isRunKeyHeld (ref), ServerRemote (ref)
        local v5 = os.clock() + 2;

        while os.clock() < v5 and (u4.Parent and StateManager.IsInState(u4, "ForwardDashing")) do
            task.wait();
        end;

        if not u4.Parent then
            return;
        end;

        if not isRunKeyHeld() then
            return;
        end;

        if StateManager.IsInState(u4, "Running") then
            return;
        end;

        if not StateManager.CanPerformAction(u4, "Run") then
            return;
        end;

        ServerRemote:FireServer("Run", {
            Action = "Execute"
        });
    end);
end;

local u6 = ControlData.Controls.Dash.Forward_Time or 0.7;
local u7 = ControlData.Controls.Dash.Side_Time or 0.4;
local u8 = {
    {
        bias = "forward",
        key = Enum.KeyCode.W
    },
    {
        bias = "backward",
        key = Enum.KeyCode.S
    },
    {
        bias = "left",
        key = Enum.KeyCode.A
    },
    {
        bias = "right",
        key = Enum.KeyCode.D
    }
};
local u9 = true;
local u10 = true;
local u11 = nil;
local PlayerStats = LocalPlayer:WaitForChild("PlayerStats");
local Hitbox = PlayerStats:FindFirstChild("Hitbox", true);
local v12 = script:FindFirstAncestor("Core");
local CombatVFX = require(v12:FindFirstChild("CombatVFX", true));
local u13 = false;

local function refreshSnapVanish() -- Line: 160
    -- upvalues: StatRetrieveRemote (copy), u13 (ref)
    local success, result = pcall(function() -- Line: 161
        -- upvalues: StatRetrieveRemote (ref)
        return StatRetrieveRemote:InvokeServer("Snap Vanish", "Skill Stat");
    end);

    if success and result then
        u13 = result.Unlocked == true;
    end;
end;

local success, result = pcall(function() -- Line: 161
    -- upvalues: StatRetrieveRemote (copy)
    return StatRetrieveRemote:InvokeServer("Snap Vanish", "Skill Stat");
end);

if success and result then
    if result.Unlocked == true then
        u13 = true;
    else
        u13 = false;
    end;
end;

local function snapVanishReady(p14) -- Line: 181
    -- upvalues: u13 (ref), UserInputService (copy), PlayerStats (copy)
    if not u13 then
        return false;
    end;

    if not (UserInputService:IsKeyDown(Enum.KeyCode.LeftShift) or UserInputService:IsGamepadButtonDown(Enum.UserInputType.Gamepad1, Enum.KeyCode.ButtonL3)) then
        return false;
    end;

    if p14:FindFirstChild("Snap Vanish CD") then
        return false;
    end;

    local Ki = PlayerStats:FindFirstChild("Ki", true);

    return (not Ki or Ki.Value >= 0.1) and true or false;
end;

local function getMaxForce() -- Line: 198
    -- upvalues: Hitbox (copy)
    local v15 = Hitbox and math.clamp(Hitbox.Value, 0.5, 3) * 5 * 100000 or 100000;

    return math.clamp(v15, 100000, 3000000);
end;

local function isMovementDisabled(p16) -- Line: 227
    -- upvalues: StateManager (copy), StateDefinitions (copy)
    for i in pairs(StateManager.GetAllStates(p16)) do
        local v17 = StateDefinitions[i];

        if v17 and v17.category == "disabled" then
            local v18 = false;
            local allowedActions = v17.allowedActions;

            if allowedActions then
                for _, v in ipairs(allowedActions) do
                    if v == "Dash" or v == "*" then
                        v18 = true;
                        break;
                    end;
                end;
            end;

            if not v18 then
                return true;
            end;
        end;
    end;

    return false;
end;

local function getDistScale(p19) -- Line: 272
    -- upvalues: Hitbox (copy)
    local v20 = p19 and p19:GetAttribute("State_GreatApe") and 3.5 or 3;

    return math.clamp(Hitbox and Hitbox.Value or 1, 0.5, v20);
end;

local function dashSpeedMult(p21) -- Line: 281
    if p21 then
        p21 = p21:GetAttribute("DashSpeedMult");
    end;

    return (type(p21) ~= "number" or (p21 <= 0 or not p21)) and 1 or p21;
end;

local function clearDashVelocity(p22) -- Line: 286
    for _, child in ipairs(p22:GetChildren()) do
        if child.Name == "DashVelocity" then
            child:Destroy();
        end;
    end;
end;

local function dashCD(p23) -- Line: 292
    -- upvalues: u9 (ref), u10 (ref)
    if p23 ~= "Side" then
        if p23 == "Front" then
            u10 = false;
            task.delay(6, function() -- Line: 298
                -- upvalues: u10 (ref)
                u10 = true;
            end);
        end;

        return;
    end;

    u9 = false;
    task.delay(2, function() -- Line: 295
        -- upvalues: u9 (ref)
        u9 = true;
    end);
end;

local function dashVFX(p24, p25) -- Line: 309
    -- upvalues: CombatVFX (copy), u6 (copy), GlobalFunctions (copy), workspace_CurrentCamera (copy)
    if not p25:FindFirstChild("HumanoidRootPart") then
        return;
    end;

    if p24 == "Foward" then
        CombatVFX.LockCameraFOV(u6 + 0.75);
        GlobalFunctions.Tween({
            Duration = 0.3,
            Instance = workspace_CurrentCamera,
            EasingStyle = Enum.EasingStyle.Circular,
            EasingDirection = Enum.EasingDirection.Out
        }, {
            FieldOfView = 90
        });
        task.delay(u6, function() -- Line: 321
            -- upvalues: GlobalFunctions (ref), workspace_CurrentCamera (ref)
            GlobalFunctions.Tween({
                Duration = 0.75,
                Instance = workspace_CurrentCamera,
                EasingStyle = Enum.EasingStyle.Circular,
                EasingDirection = Enum.EasingDirection.Out
            }, {
                FieldOfView = 70
            });
        end);
    end;
end;

local function getAimDirection(p26) -- Line: 329
    -- upvalues: workspace_CurrentCamera (copy), u8 (copy), UserInputService (copy)
    local HumanoidRootPart = p26:FindFirstChild("HumanoidRootPart");
    local Humanoid = p26:FindFirstChild("Humanoid");

    if not HumanoidRootPart then
        return Vector3.new(0, 0, -1), false;
    end;

    if Humanoid then
        Humanoid = Humanoid:GetState() == Enum.HumanoidStateType.Freefall;
    end;

    local CFrame2 = workspace_CurrentCamera.CFrame;
    local v27 = {
        forward = CFrame2.LookVector,
        backward = -CFrame2.LookVector,
        left = -CFrame2.RightVector,
        right = CFrame2.RightVector
    };
    local v28 = Vector3.new(0, 0, 0);

    for _, v in ipairs(u8) do
        if UserInputService:IsKeyDown(v.key) then
            v28 = v28 + v27[v.bias];
        end;
    end;

    if v28.Magnitude < 0.01 then
        v28 = CFrame2.LookVector;
    end;

    return v28.Unit, Humanoid;
end;

local function runHitboxScan(u29, u30, u31, u32, u33) -- Line: 358
    -- upvalues: u6 (copy), HitboxHandler (copy), FindCharacters (copy), UtilityHandler (copy), ServerRemote (copy)
    local u34 = {
        Size = Vector3.new(6, 5, 7) * u31,
        Location = u30.CFrame * CFrame.new(0, 0, -3.68421052631579 * u31)
    };
    task.spawn(function() -- Line: 363
        -- upvalues: u6 (ref), u32 (copy), u34 (copy), u30 (copy), u31 (copy), HitboxHandler (ref), FindCharacters (ref), u29 (copy), UtilityHandler (ref), ServerRemote (ref), u33 (copy)
        local v35 = tick() + u6;

        while tick() < v35 and not (u32 and u32.cancelled) do
            u34.Location = u30.CFrame * CFrame.new(0, 0, -3.68421052631579 * u31);
            local _, v36 = HitboxHandler.New(u34);
            local v37 = FindCharacters.Find(u29, v36);

            if UtilityHandler:Length(v37) >= 1 and not u29:FindFirstChild("Carrying") then
                ServerRemote:FireServer("Dash Swing");
                ServerRemote:FireServer("Dash Light", {
                    Combo = 1,
                    Dash = true,
                    Victims = v37,
                    RegionHitbox = {
                        Location = u34.Location,
                        Size = u34.Size
                    }
                });
                u33.landed = true;

                return;
            end;

            task.wait(0.03);
        end;
    end);
end;

local function fireDash(u38, p39, p40, u41, u42, p43) -- Line: 412
    -- upvalues: Hitbox (copy), LocalPlayer (copy), clearDashVelocity (copy), AnimationManager (copy), ServerRemote (copy), RunService (copy), u6 (copy), isMovementDisabled (copy), workspace_CurrentCamera (copy), u1 (copy), StatRetrieveRemote (copy), u13 (ref), GlobalFunctions (copy), StateManager (copy), isRunKeyHeld (copy), runHitboxScan (copy), dashVFX (copy)
    local HumanoidRootPart = u38:FindFirstChild("HumanoidRootPart");
    local Humanoid = u38:FindFirstChild("Humanoid");

    if not HumanoidRootPart then
        return;
    end;

    local v44 = Hitbox and math.clamp(Hitbox.Value, 0.5, 3) * 5 * 100000 or 100000;
    local math_clamp_ret = math.clamp(v44, 100000, 3000000);
    local v45 = u38 and u38:GetAttribute("State_GreatApe") and 3.5 or 3;
    local math_clamp_ret2 = math.clamp(Hitbox and Hitbox.Value or 1, 0.5, v45);
    local v46 = LocalPlayer:GetAttribute("OverallAgility") or 0;
    local u47 = (p43 and 1.5 or 1) * (1 + 0.3 * v46 / (v46 + 300));
    clearDashVelocity(HumanoidRootPart);
    local u48 = AnimationManager.PlayAnimation(u38, "Fly Charge", {
        AdjustSpeed = 2
    });
    local u49;

    if u48 then
        u49 = u48:GetMarkerReachedSignal("Boost"):Once(function() -- Line: 432
            -- upvalues: u48 (copy)
            u48:AdjustSpeed(0);
        end);
    else
        u49 = nil;
    end;

    ServerRemote:FireServer("Dash", {
        Direction = "Foward",
        ShiftPressed = p43 or false,
        is_Freefalling = p40
    });
    local Attachment = Instance.new("Attachment");
    Attachment.Name = "DashVelocity";
    Attachment.Parent = HumanoidRootPart;
    local AlignOrientation = Instance.new("AlignOrientation");
    AlignOrientation.Attachment0 = Attachment;
    AlignOrientation.Mode = Enum.OrientationAlignmentMode.OneAttachment;
    AlignOrientation.RigidityEnabled = false;
    AlignOrientation.Responsiveness = 30;
    AlignOrientation.MaxTorque = (1 / 0);
    AlignOrientation.Parent = HumanoidRootPart;
    local LinearVelocity = Instance.new("LinearVelocity");
    LinearVelocity.Attachment0 = Attachment;
    LinearVelocity.MaxForce = math_clamp_ret;
    LinearVelocity.VectorVelocity = Vector3.new(0, 0, 0);
    LinearVelocity.Name = "DashVelocity";
    LinearVelocity.Parent = Attachment;

    if Humanoid then
        Humanoid.AutoRotate = false;
    end;

    local u50 = tick();
    local u51 = {};
    local u52 = u38:GetAttribute("DashBlockTick") or 0;
    local u53 = nil;
    u53 = RunService.Heartbeat:Connect(function() -- Line: 473
        -- upvalues: HumanoidRootPart (copy), u53 (ref), u50 (copy), u6 (ref), u41 (copy), isMovementDisabled (ref), u38 (copy), u52 (copy), u47 (copy), workspace_CurrentCamera (ref), LinearVelocity (copy), math_clamp_ret2 (copy), AlignOrientation (copy), u1 (ref), Attachment (copy), u49 (ref), u48 (copy), Humanoid (copy), StatRetrieveRemote (ref), u13 (ref), GlobalFunctions (ref), u51 (copy), ServerRemote (ref), StateManager (ref), isRunKeyHeld (ref), u42 (copy)
        if not HumanoidRootPart.Parent then
            u53:Disconnect();

            return;
        end;

        local v54 = tick() - u50;
        local math_clamp_ret3 = math.clamp(v54 / u6, 0, 1);
        local v55 = u41 and u41.cancelled or (isMovementDisabled(u38) or (u38:GetAttribute("DashBlockTick") or 0) ~= u52);
        local v56 = (math_clamp_ret3 * -70 + 100) * u47;
        local LookVector = workspace_CurrentCamera.CFrame.LookVector;
        local v57;

        if v55 then
            v57 = Vector3.new(0, 0, 0);
        else
            local v58 = u38;

            if v58 then
                v58 = v58:GetAttribute("DashSpeedMult");
            end;

            v57 = LookVector * v56 * math_clamp_ret2 * ((type(v58) ~= "number" or (v58 <= 0 or not v58)) and 1 or v58);
        end;

        LinearVelocity.VectorVelocity = v57;
        AlignOrientation.CFrame = CFrame.lookAt(Vector3.new(0, 0, 0), (u1.Hit.Position - HumanoidRootPart.Position).Unit);

        if u6 <= v54 or v55 then
            u53:Disconnect();
            Attachment:Destroy();
            AlignOrientation:Destroy();

            if v55 then
                HumanoidRootPart.AssemblyLinearVelocity = Vector3.new(0, 0, 0);
            end;

            if u49 and u49.Connected then
                u49:Disconnect();
            end;

            if u48 and u48.IsPlaying then
                u48:AdjustSpeed(1);
            end;

            if Humanoid and Humanoid.Parent then
                Humanoid.AutoRotate = true;
            end;

            local success2, result2 = pcall(function() -- Line: 161
                -- upvalues: StatRetrieveRemote (ref)
                return StatRetrieveRemote:InvokeServer("Snap Vanish", "Skill Stat");
            end);

            if success2 and result2 then
                u13 = result2.Unlocked == true;
            end;

            if v55 then
                GlobalFunctions.Tween({
                    Duration = 0.3,
                    Instance = workspace_CurrentCamera,
                    EasingStyle = Enum.EasingStyle.Quad,
                    EasingDirection = Enum.EasingDirection.Out
                }, {
                    FieldOfView = 70
                });
            elseif u51.landed then
                ServerRemote:FireServer("Dash Suspend", {});
            end;

            if not v55 then
                local u59 = u38;
                task.spawn(function() -- Line: 86
                    -- upvalues: u59 (copy), StateManager (ref), isRunKeyHeld (ref), ServerRemote (ref)
                    local v60 = os.clock() + 2;

                    while os.clock() < v60 and (u59.Parent and StateManager.IsInState(u59, "ForwardDashing")) do
                        task.wait();
                    end;

                    if not u59.Parent then
                        return;
                    end;

                    if not isRunKeyHeld() then
                        return;
                    end;

                    if StateManager.IsInState(u59, "Running") then
                        return;
                    end;

                    if not StateManager.CanPerformAction(u59, "Run") then
                        return;
                    end;

                    ServerRemote:FireServer("Run", {
                        Action = "Execute"
                    });
                end);
            end;

            if u42 then
                u42();
            end;
        end;
    end);
    runHitboxScan(u38, HumanoidRootPart, math_clamp_ret2, u41, u51);
    dashVFX("Foward", u38);
end;

local function enterAimMode(p61) -- Line: 548
    -- upvalues: RunService (copy), u1 (copy)
    local HumanoidRootPart = p61:FindFirstChild("HumanoidRootPart");
    local Humanoid = p61:FindFirstChild("Humanoid");

    if not (HumanoidRootPart and Humanoid) then
        return nil, nil;
    end;

    Humanoid.AutoRotate = false;
    local Attachment = Instance.new("Attachment");
    Attachment.Name = "AimHold";
    Attachment.Parent = HumanoidRootPart;
    local LinearVelocity = Instance.new("LinearVelocity");
    LinearVelocity.Attachment0 = Attachment;
    LinearVelocity.MaxForce = math.max(HumanoidRootPart.AssemblyMass, 1) * 12000;
    LinearVelocity.VectorVelocity = Vector3.new(0, 0, 0);
    LinearVelocity.Parent = Attachment;
    local AlignOrientation = Instance.new("AlignOrientation");
    AlignOrientation.Attachment0 = Attachment;
    AlignOrientation.Mode = Enum.OrientationAlignmentMode.OneAttachment;
    AlignOrientation.RigidityEnabled = false;
    AlignOrientation.Responsiveness = 30;
    AlignOrientation.MaxTorque = (1 / 0);
    AlignOrientation.Parent = HumanoidRootPart;
    local u62 = nil;
    u62 = RunService.Heartbeat:Connect(function() -- Line: 578
        -- upvalues: Attachment (copy), u62 (ref), AlignOrientation (copy), u1 (ref), HumanoidRootPart (copy)
        if Attachment.Parent then
            AlignOrientation.CFrame = CFrame.lookAt(Vector3.new(0, 0, 0), (u1.Hit.Position - HumanoidRootPart.Position).Unit);

            return;
        end;

        u62:Disconnect();
    end);

    return Attachment, u62;
end;

local function exitAimMode(p63, p64, p65) -- Line: 586
    if p64 then
        p64:Disconnect();
    end;

    if p63 and p63.Parent then
        p63:Destroy();
    end;

    if p65 and p65.Parent then
        p65.AutoRotate = true;
    end;
end;

local v93 = {
    Foward = function(u66) -- Line: 598, Name: Foward
        -- upvalues: u10 (ref), isMovementDisabled (copy), snapVanishReady (copy), enterAimMode (copy), u11 (ref), AnimationManager (copy), GlobalFunctions (copy), workspace_CurrentCamera (copy), CombatVFX (copy), StateSyncRemote (copy), StateDefinitions (copy), getAimDirection (copy), fireDash (copy), UserInputService (copy), ControlData (copy)
        if not u10 then
            return;
        end;

        if isMovementDisabled(u66) then
            return;
        end;

        local Humanoid = u66:FindFirstChild("Humanoid");

        if not Humanoid then
            return;
        end;

        local u67 = false;
        local u68 = snapVanishReady(u66);
        local u69, u70 = enterAimMode(u66);
        u11 = AnimationManager.PlayAnimation(u66, "DBZ CHARGE");
        local u71 = false;

        local function resetChargeZoom() -- Line: 629
            -- upvalues: u67 (ref), u71 (ref), GlobalFunctions (ref), workspace_CurrentCamera (ref)
            if u67 or u71 then
                return;
            end;

            u71 = true;
            GlobalFunctions.Tween({
                Duration = 0.3,
                Instance = workspace_CurrentCamera,
                EasingStyle = Enum.EasingStyle.Quad,
                EasingDirection = Enum.EasingDirection.Out
            }, {
                FieldOfView = 70
            });
        end;

        local u72 = nil;
        local u73, u74;

        if u11 then
            CombatVFX.LockCameraFOV(1.5);
            GlobalFunctions.Tween({
                Duration = 0.25,
                Instance = workspace_CurrentCamera,
                EasingStyle = Enum.EasingStyle.Quad,
                EasingDirection = Enum.EasingDirection.Out
            }, {
                FieldOfView = 50
            });
            u73 = u11:GetMarkerReachedSignal("Charge"):Once(function() -- Line: 650
                -- upvalues: u11 (ref)
                if u11 and u11.IsPlaying then
                    u11.Looped = true;
                    u11:AdjustSpeed(0);
                end;
            end);
            local os_clock_ret = os.clock();
            u74 = u11.Stopped:Connect(function() -- Line: 678
                -- upvalues: os_clock_ret (copy), resetChargeZoom (copy)
                if os.clock() - os_clock_ret < 0.15 then
                    return;
                end;

                resetChargeZoom();
            end);
        else
            u73 = nil;
            u74 = nil;
        end;

        if Humanoid then
            u72 = Humanoid.Died:Once(resetChargeZoom);
        end;

        local u75 = {
            cancelled = false
        };
        local u76 = nil;

        local function abortCharge() -- Line: 696
            -- upvalues: u67 (ref), resetChargeZoom (copy), u73 (ref), u74 (ref), u72 (ref), u11 (ref), u69 (copy), u70 (copy), Humanoid (copy), u76 (ref)
            if u67 then
                return;
            end;

            resetChargeZoom();
            u67 = true;

            if u73 and u73.Connected then
                u73:Disconnect();
            end;

            if u74 and u74.Connected then
                u74:Disconnect();
            end;

            if u72 and u72.Connected then
                u72:Disconnect();
            end;

            if u11 then
                u11:Stop();
                u11 = nil;
            end;

            local v77 = u69;
            local v78 = u70;
            local v79 = Humanoid;

            if v78 then
                v78:Disconnect();
            end;

            if v77 and v77.Parent then
                v77:Destroy();
            end;

            if v79 and v79.Parent then
                v79.AutoRotate = true;
            end;

            if u76 and u76.Connected then
                u76:Disconnect();
            end;
        end;

        u76 = StateSyncRemote.OnClientEvent:Connect(function(p80, p81) -- Line: 711
            -- upvalues: StateDefinitions (ref), u67 (ref), abortCharge (copy), u75 (copy)
            if p80 ~= "Set" then
                return;
            end;

            local v82 = StateDefinitions[p81];

            if not v82 or v82.category ~= "disabled" then
                return;
            end;

            local allowedActions = v82.allowedActions;

            if allowedActions then
                for _, v in ipairs(allowedActions) do
                    if v == "Dash" or v == "*" then
                        return;
                    end;
                end;
            end;

            if u67 then
                u75.cancelled = true;

                return;
            end;

            abortCharge();
        end);

        local function fire() -- Line: 735
            -- upvalues: u67 (ref), isMovementDisabled (ref), u66 (copy), abortCharge (copy), u73 (ref), u74 (ref), u72 (ref), u11 (ref), u69 (copy), u70 (copy), Humanoid (copy), getAimDirection (ref), fireDash (ref), u75 (copy), u76 (ref), u68 (copy), u10 (ref)
            if u67 then
                return;
            end;

            if isMovementDisabled(u66) then
                abortCharge();

                return;
            end;

            u67 = true;

            if u73 and u73.Connected then
                u73:Disconnect();
            end;

            if u74 and u74.Connected then
                u74:Disconnect();
            end;

            if u72 and u72.Connected then
                u72:Disconnect();
            end;

            if u11 then
                u11:Stop();
                u11 = nil;
            end;

            local v83 = u69;
            local v84 = u70;
            local v85 = Humanoid;

            if v84 then
                v84:Disconnect();
            end;

            if v83 and v83.Parent then
                v83:Destroy();
            end;

            if v85 and v85.Parent then
                v85.AutoRotate = true;
            end;

            local v86, v87 = getAimDirection(u66);
            fireDash(u66, v86, v87, u75, function() -- Line: 754
                -- upvalues: u76 (ref)
                if u76 and u76.Connected then
                    u76:Disconnect();
                end;
            end, u68);
            u10 = false;
            task.delay(6, function() -- Line: 298
                -- upvalues: u10 (ref)
                u10 = true;
            end);
        end;

        if UserInputService.TouchEnabled and not UserInputService.KeyboardEnabled then
            task.defer(fire);

            return;
        end;

        local u88 = {};
        local u89 = {};
        local v90 = ControlData.Controls and ControlData.Controls.Combat and ControlData.Controls.Combat.Dash;

        if type(v90) == "table" then
            for _, v in ipairs(v90) do
                if v == "MouseButton1" or v == "MouseButton2" then
                    u89[Enum.UserInputType[v]] = true;
                elseif type(v) == "string" then
                    local success2, result2 = pcall(function() -- Line: 794
                        -- upvalues: v (copy)
                        return Enum.KeyCode[v];
                    end);

                    if success2 and result2 then
                        u88[result2] = true;
                    end;
                end;
            end;
        end;

        if next(u88) == nil and next(u89) == nil then
            u88[Enum.KeyCode.Q] = true;
            u88[Enum.KeyCode.ButtonB] = true;
        end;

        local u91 = nil;
        u91 = UserInputService.InputEnded:Connect(function(p92) -- Line: 804
            -- upvalues: u88 (copy), u89 (copy), u91 (ref), fire (copy)
            if u88[p92.KeyCode] or u89[p92.UserInputType] then
                u91:Disconnect();
                fire();
            end;
        end);
    end
};

local function sideDash(u94, p95, p96, u97) -- Line: 814
    -- upvalues: u9 (ref), isMovementDisabled (copy), clearDashVelocity (copy), AnimationManager (copy), snapVanishReady (copy), CombatVFX (copy), u7 (copy), GlobalFunctions (copy), workspace_CurrentCamera (copy), RunService (copy), Hitbox (copy), ServerRemote (copy), StatRetrieveRemote (copy), u13 (ref)
    if not u9 then
        return;
    end;

    if isMovementDisabled(u94) then
        return;
    end;

    local HumanoidRootPart = u94:FindFirstChild("HumanoidRootPart");
    u94:FindFirstChild("Humanoid");

    if not HumanoidRootPart then
        return;
    end;

    clearDashVelocity(HumanoidRootPart);
    AnimationManager.PlayAnimation(u94, p96, {
        AdjustSpeed = 1.8
    });
    local v98 = snapVanishReady(u94);
    local u99 = v98 and 1.5 or 1;

    if v98 then
        CombatVFX.LockCameraFOV(u7 + 0.75);
        GlobalFunctions.Tween({
            Duration = 0.15,
            Instance = workspace_CurrentCamera,
            EasingStyle = Enum.EasingStyle.Quad,
            EasingDirection = Enum.EasingDirection.Out
        }, {
            FieldOfView = 90
        });
        task.delay(u7, function() -- Line: 833
            -- upvalues: GlobalFunctions (ref), workspace_CurrentCamera (ref)
            GlobalFunctions.Tween({
                Duration = 0.4,
                Instance = workspace_CurrentCamera,
                EasingStyle = Enum.EasingStyle.Quad,
                EasingDirection = Enum.EasingDirection.Out
            }, {
                FieldOfView = 70
            });
        end);
    end;

    local Attachment = Instance.new("Attachment");
    Attachment.Name = "DashVelocity";
    Attachment.Parent = HumanoidRootPart;
    local u100 = tick();
    local u101 = nil;
    u101 = RunService.Heartbeat:Connect(function() -- Line: 844
        -- upvalues: HumanoidRootPart (copy), u101 (ref), isMovementDisabled (ref), u94 (copy), Attachment (copy), u100 (copy), u7 (ref), u99 (copy), u97 (copy), Hitbox (ref)
        if not HumanoidRootPart.Parent then
            u101:Disconnect();

            return;
        end;

        if isMovementDisabled(u94) then
            u101:Disconnect();

            if Attachment.Parent then
                Attachment:Destroy();
            end;

            return;
        end;

        local v102 = tick() - u100;
        local v103 = (math.clamp(v102 / u7, 0, 1) * -72 + 78) * u99;
        local v104 = u97(HumanoidRootPart);

        if v104.Magnitude > 0.01 then
            local v105 = v104.Unit * math.abs(v103);
            local v106 = u94;
            local v107 = v106 and v106:GetAttribute("State_GreatApe") and 3.5 or 3;
            local v108 = v105 * math.clamp(Hitbox and Hitbox.Value or 1, 0.5, v107);
            local v109 = u94;

            if v109 then
                v109 = v109:GetAttribute("DashSpeedMult");
            end;

            v104 = v108 * ((type(v109) ~= "number" or (v109 <= 0 or not v109)) and 1 or v109);
        end;

        local v110 = Attachment.Parent and Attachment:FindFirstChildOfClass("LinearVelocity");

        if v110 then
            v110.VectorVelocity = v104;
        end;

        if u7 <= v102 then
            u101:Disconnect();
            Attachment:Destroy();
        end;
    end);
    local LinearVelocity = Instance.new("LinearVelocity");
    LinearVelocity.Attachment0 = Attachment;
    local v111 = Hitbox and math.clamp(Hitbox.Value, 0.5, 3) * 5 * 100000 or 100000;
    LinearVelocity.MaxForce = math.clamp(v111, 100000, 3000000);
    local v112 = u97(HumanoidRootPart) * u99;

    if u94 then
        u94 = u94:GetAttribute("DashSpeedMult");
    end;

    LinearVelocity.VectorVelocity = v112 * ((type(u94) ~= "number" or (u94 <= 0 or not u94)) and 1 or u94);
    LinearVelocity.Parent = Attachment;
    ServerRemote:FireServer("Dash", {
        is_Freefalling = false,
        Direction = p95,
        ShiftPressed = v98
    });

    if v98 then
        local success2, result2 = pcall(function() -- Line: 161
            -- upvalues: StatRetrieveRemote (ref)
            return StatRetrieveRemote:InvokeServer("Snap Vanish", "Skill Stat");
        end);

        if success2 and result2 then
            u13 = result2.Unlocked == true;
        end;
    end;

    u9 = false;
    task.delay(2, function() -- Line: 295
        -- upvalues: u9 (ref)
        u9 = true;
    end);
end;

function v93.Backward(p113) -- Line: 883
    -- upvalues: Hitbox (copy), sideDash (copy)
    local v114 = p113 and p113:GetAttribute("State_GreatApe") and 3.5 or 3;
    local math_clamp_ret = math.clamp(Hitbox and Hitbox.Value or 1, 0.5, v114);
    sideDash(p113, "Backward", "BackDash", function(p115) -- Line: 885
        -- upvalues: math_clamp_ret (copy)
        return -p115.CFrame.LookVector * (90 * math_clamp_ret);
    end);
end;

function v93.Left(p116) -- Line: 888
    -- upvalues: Hitbox (copy), sideDash (copy)
    local v117 = p116 and p116:GetAttribute("State_GreatApe") and 3.5 or 3;
    local math_clamp_ret = math.clamp(Hitbox and Hitbox.Value or 1, 0.5, v117);
    sideDash(p116, "Left", "LeftDash", function(p118) -- Line: 890
        -- upvalues: math_clamp_ret (copy)
        return -p118.CFrame.RightVector * (90 * math_clamp_ret);
    end);
end;

function v93.Right(p119) -- Line: 893
    -- upvalues: Hitbox (copy), sideDash (copy)
    local v120 = p119 and p119:GetAttribute("State_GreatApe") and 3.5 or 3;
    local math_clamp_ret = math.clamp(Hitbox and Hitbox.Value or 1, 0.5, v120);
    sideDash(p119, "Right", "RightDash", function(p121) -- Line: 895
        -- upvalues: math_clamp_ret (copy)
        return p121.CFrame.RightVector * (90 * math_clamp_ret);
    end);
end;

v93.Foward = v93.Foward;
v93.Backward = v93.Backward;
v93.Left = v93.Left;
v93.Right = v93.Right;

return v93;