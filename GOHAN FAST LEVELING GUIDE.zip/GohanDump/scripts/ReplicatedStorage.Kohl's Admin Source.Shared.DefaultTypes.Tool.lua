-- Decompiled with Potassium's decompiler.

local u1 = nil;
local u2 = {};
local u9 = {
    validate = function(p3: string, p4: number) -- Line: 5, Name: validate
        -- upvalues: u2 (ref)
        local string_lower_ret = string.lower(p3);

        for _, v in u2 do
            if string.find(string.lower(v.Name), string_lower_ret, 1, true) == 1 then
                return true;
            end;
        end;

        return false, "Invalid tool";
    end,

    parse = function(p5: string, p6: number) -- Line: 14, Name: parse
        -- upvalues: u2 (ref)
        local string_lower_ret = string.lower(p5);

        for _, v in u2 do
            if string.lower(v.Name) == string_lower_ret then
                return v;
            end;
        end;

        for _, v in u2 do
            if string.find(string.lower(v.Name), string_lower_ret, 1, true) == 1 then
                return v;
            end;
        end;

        error("Invalid tool value");
    end,

    suggestions = function(p7: string, p8: number) -- Line: 28, Name: suggestions
        -- upvalues: u1 (ref), u2 (ref)
        return u1.Util.Suggest.new(u2);
    end,

    prefixes = {
        ["^all$"] = "allTools"
    }
};

local function allParse() -- Line: 34
    -- upvalues: u2 (ref)
    local v10;

    if #u2 > 0 then
        v10 = u2;
    else
        v10 = false;
    end;

    return v10, "No valid tool found";
end;

local u11 = {
    listable = true,
    transform = string.lower,
    validate = allParse,
    parse = allParse
};

return function(p12) -- Line: 45
    -- upvalues: u1 (ref), u2 (ref), u9 (copy), u11 (copy)
    u1 = p12;

    if u1.IsServer then
        local function sortName(p13, p14) -- Line: 49
            return p13.Name < p14.Name;
        end;

        local u15 = u1.Util.Function.debounce(0.2, table.sort);

        local function shouldIgnore(p16) -- Line: 55
            -- upvalues: shouldIgnore (copy)
            if p16 ~= nil then
                return p16:HasTag("_K_Ignore") and true or shouldIgnore(p16.Parent);
            end;
        end;

        local function addTool(p17) -- Line: 65
            -- upvalues: shouldIgnore (copy), u2 (ref), u15 (copy), sortName (copy)
            if p17:IsA("Tool") or p17:IsA("HopperBin") then
                local v18;

                if p17 == nil then
                    v18 = nil;
                else
                    v18 = p17:HasTag("_K_Ignore") and true or shouldIgnore(p17.Parent);
                end;

                if not v18 then
                    for _, v in u2 do
                        if v.Name == p17.Name then
                            return;
                        end;
                    end;

                    table.insert(u2, p17);
                    u15(u2, sortName);
                end;
            end;
        end;

        local function registerSource(p19) -- Line: 78
            -- upvalues: addTool (copy)
            for _, descendant in p19:GetDescendants() do
                addTool(descendant);
            end;

            p19.DescendantAdded:Connect(addTool);
        end;

        local Lighting = u1.Service.Lighting;

        for _, descendant in Lighting:GetDescendants() do
            addTool(descendant);
        end;

        Lighting.DescendantAdded:Connect(addTool);
        local ReplicatedStorage = u1.Service.ReplicatedStorage;

        for _, descendant in ReplicatedStorage:GetDescendants() do
            addTool(descendant);
        end;

        ReplicatedStorage.DescendantAdded:Connect(addTool);
        local ServerStorage = u1.Service.ServerStorage;

        for _, descendant in ServerStorage:GetDescendants() do
            addTool(descendant);
        end;

        ServerStorage.DescendantAdded:Connect(addTool);
        local StarterPack = u1.Service.StarterPack;

        for _, descendant in StarterPack:GetDescendants() do
            addTool(descendant);
        end;

        StarterPack.DescendantAdded:Connect(addTool);
        u1.Remote.Tools:Connect(function(p20) -- Line: 90
            -- upvalues: u1 (ref), u2 (ref)
            if u1.Auth.hasCommand(p20.UserId, "tools") then
                local table_create_ret = table.create(#u2);

                for i, v in u2 do
                    table_create_ret[i] = {
                        Name = v.Name
                    };
                end;

                u1.Remote.Tools:Fire(p20, table_create_ret);
            end;
        end);
        local table_create_ret = table.create(#u2);

        for i, v in u2 do
            table_create_ret[i] = {
                Name = v.Name
            };
        end;

        task.spawn(function() -- Line: 105
            -- upvalues: u1 (ref), table_create_ret (copy)
            if not u1.ready then
                u1.Hook.init:Wait();
            end;

            for _, v in u1.Service.Players:GetPlayers() do
                if u1.Auth.hasCommand(v.UserId, "tools") then
                    u1.Remote.Tools:Fire(v, table_create_ret);
                end;
            end;
        end);
    else
        u1.Remote.Tools:Connect(function(p21) -- Line: 116
            -- upvalues: u2 (ref), u1 (ref)
            u2 = p21;
            u1.tools = u2;
            table.insert(u2, 1, {
                Name = "all"
            });
        end);
        u1.Remote.Tools:Fire();
    end;

    u1.Registry.registerType("tool", u9);
    u1.Registry.registerType("tools", {
        listable = true
    }, u9);
    u1.Registry.registerType("allTools", u11);
end;