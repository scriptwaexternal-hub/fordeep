-- Decompiled with Potassium's decompiler.

local Players = game:GetService("Players");
local ReplicatedStorage = game:GetService("ReplicatedStorage");
local HttpService = game:GetService("HttpService");
game:GetService("TweenService");
local LocalPlayer = Players.LocalPlayer;
local Remotes = ReplicatedStorage:WaitForChild("Remotes");
local FamilyRemote = Remotes:WaitForChild("FamilyRemote");
local SetGenderRemote = Remotes:WaitForChild("SetGenderRemote");
local u1 = {};

local function fdprint(...) -- Line: 38
end;

local Color3_fromRGB_ret = Color3.fromRGB(255, 209, 106);

local function ensureTag(p2, p3, p4) -- Line: 60
    -- upvalues: Color3_fromRGB_ret (copy), fdprint (copy)
    local Head = p3:FindFirstChild("Head");

    if not Head then
        return;
    end;

    local FamilyTagGui = Head:FindFirstChild("FamilyTagGui");

    if not FamilyTagGui then
        FamilyTagGui = Instance.new("BillboardGui");
        FamilyTagGui.Name = "FamilyTagGui";
        FamilyTagGui.Adornee = Head;
        FamilyTagGui.Size = UDim2.fromOffset(200, 22);
        FamilyTagGui.StudsOffset = Vector3.new(0, 3.4, 0);
        FamilyTagGui.MaxDistance = 90;
        FamilyTagGui.AlwaysOnTop = false;
        FamilyTagGui.ResetOnSpawn = false;
        local TextLabel = Instance.new("TextLabel");
        TextLabel.Name = "Relation";
        TextLabel.Size = UDim2.fromScale(1, 1);
        TextLabel.BackgroundTransparency = 1;
        TextLabel.Font = Enum.Font.GothamBold;
        TextLabel.TextSize = 16;
        TextLabel.TextColor3 = Color3_fromRGB_ret;
        TextLabel.TextStrokeTransparency = 0.35;
        TextLabel.TextStrokeColor3 = Color3.new(0, 0, 0);
        TextLabel.Parent = FamilyTagGui;
        FamilyTagGui.Parent = Head;
    end;

    local Relation = FamilyTagGui:FindFirstChild("Relation");

    if Relation and Relation.Text ~= p4 then
        Relation.Text = p4;
        fdprint(("Tag applied: %s = %q"):format(p2.Name, p4));
    end;
end;

local function removeTag(p5, p6) -- Line: 94
    -- upvalues: fdprint (copy)
    if p6 then
        p6 = p6:FindFirstChild("Head");
    end;

    if p6 then
        p6 = p6:FindFirstChild("FamilyTagGui");
    end;

    if p6 then
        p6:Destroy();
        fdprint("Tag removed:", p5.Name);
    end;
end;

local function applyLabel(p7, p8) -- Line: 103
    -- upvalues: u1 (ref), ensureTag (copy), fdprint (copy)
    local v9 = p8 or p7.Character;

    if not v9 then
        return;
    end;

    local v10 = u1[tostring(p7.UserId)];

    if v10 then
        ensureTag(p7, v9, v10);

        return;
    end;

    if v9 then
        v9 = v9:FindFirstChild("Head");
    end;

    if v9 then
        v9 = v9:FindFirstChild("FamilyTagGui");
    end;

    if v9 then
        v9:Destroy();
        fdprint("Tag removed:", p7.Name);
    end;
end;

local function watchCharacter(u11, u12) -- Line: 114
    -- upvalues: LocalPlayer (copy), u1 (ref), ensureTag (copy), fdprint (copy)
    if u11 == LocalPlayer then
        return;
    end;

    task.spawn(function() -- Line: 117
        -- upvalues: u12 (copy), u11 (copy), u1 (ref), ensureTag (ref), fdprint (ref)
        u12:WaitForChild("Head", 10);
        local v13 = u11;
        local v14 = u12 or v13.Character;

        if not v14 then
            return;
        end;

        local v15 = u1[tostring(v13.UserId)];

        if v15 then
            ensureTag(v13, v14, v15);

            return;
        end;

        if v14 then
            v14 = v14:FindFirstChild("Head");
        end;

        if v14 then
            v14 = v14:FindFirstChild("FamilyTagGui");
        end;

        if v14 then
            v14:Destroy();
            fdprint("Tag removed:", v13.Name);
        end;
    end);
end;

local function refreshAllLabels() -- Line: 123
    -- upvalues: Players (copy), LocalPlayer (copy), u1 (ref), ensureTag (copy), fdprint (copy)
    for _, v in ipairs(Players:GetPlayers()) do
        if v ~= LocalPlayer and v.Character then
            local Character = v.Character;

            if Character then
                local v16 = u1[tostring(v.UserId)];

                if v16 then
                    ensureTag(v, Character, v16);
                else
                    if Character then
                        Character = Character:FindFirstChild("Head");
                    end;

                    if Character then
                        Character = Character:FindFirstChild("FamilyTagGui");
                    end;

                    if Character then
                        Character:Destroy();
                        fdprint("Tag removed:", v.Name);
                    end;
                end;
            end;
        end;
    end;
end;

Players.PlayerAdded:Connect(function(u17) -- Line: 131
    -- upvalues: LocalPlayer (copy), u1 (ref), ensureTag (copy), fdprint (copy)
    u17.CharacterAdded:Connect(function(u18) -- Line: 132
        -- upvalues: u17 (copy), LocalPlayer (ref), u1 (ref), ensureTag (ref), fdprint (ref)
        local u19 = u17;

        if u19 == LocalPlayer then
            return;
        end;

        task.spawn(function() -- Line: 117
            -- upvalues: u18 (copy), u19 (copy), u1 (ref), ensureTag (ref), fdprint (ref)
            u18:WaitForChild("Head", 10);
            local v20 = u19;
            local v21 = u18 or v20.Character;

            if not v21 then
                return;
            end;

            local v22 = u1[tostring(v20.UserId)];

            if v22 then
                ensureTag(v20, v21, v22);

                return;
            end;

            if v21 then
                v21 = v21:FindFirstChild("Head");
            end;

            if v21 then
                v21 = v21:FindFirstChild("FamilyTagGui");
            end;

            if v21 then
                v21:Destroy();
                fdprint("Tag removed:", v20.Name);
            end;
        end);
    end);
end);

for _, v in ipairs(Players:GetPlayers()) do
    v.CharacterAdded:Connect(function(u23) -- Line: 135
        -- upvalues: v (copy), LocalPlayer (copy), u1 (ref), ensureTag (copy), fdprint (copy)
        local u24 = v;

        if u24 == LocalPlayer then
            return;
        end;

        task.spawn(function() -- Line: 117
            -- upvalues: u23 (copy), u24 (copy), u1 (ref), ensureTag (ref), fdprint (ref)
            u23:WaitForChild("Head", 10);
            local v25 = u24;
            local v26 = u23 or v25.Character;

            if not v26 then
                return;
            end;

            local v27 = u1[tostring(v25.UserId)];

            if v27 then
                ensureTag(v25, v26, v27);

                return;
            end;

            if v26 then
                v26 = v26:FindFirstChild("Head");
            end;

            if v26 then
                v26 = v26:FindFirstChild("FamilyTagGui");
            end;

            if v26 then
                v26:Destroy();
                fdprint("Tag removed:", v25.Name);
            end;
        end);
    end);

    if v.Character then
        task.spawn(watchCharacter, v, v.Character);
    end;
end;

task.spawn(function() -- Line: 143
    -- upvalues: refreshAllLabels (copy)
    while true do
        task.wait(5);
        refreshAllLabels();
    end;
end);

local function loadMapFromAttribute() -- Line: 152
    -- upvalues: LocalPlayer (copy), HttpService (copy), u1 (ref), fdprint (copy), refreshAllLabels (copy)
    local Attribute = LocalPlayer:GetAttribute("FamilyMap");

    if not Attribute then
        return false;
    end;

    local success, result = pcall(HttpService.JSONDecode, HttpService, Attribute);

    if not success or type(result) ~= "table" then
        return false;
    end;

    u1 = result;
    fdprint("Map loaded from attribute:", Attribute);
    refreshAllLabels();

    return true;
end;

loadMapFromAttribute();
LocalPlayer:GetAttributeChangedSignal("FamilyMap"):Connect(function() -- Line: 171
    -- upvalues: fdprint (copy), loadMapFromAttribute (copy)
    fdprint("FamilyMap attribute changed");
    loadMapFromAttribute();
end);
local u28 = nil;

local function getKamiCard() -- Line: 185
    -- upvalues: u28 (ref), ReplicatedStorage (copy)
    if not u28 then
        u28 = require(ReplicatedStorage:WaitForChild("Modules"):WaitForChild("Shared"):WaitForChild("KamiCard"));
    end;

    return u28;
end;

local u29 = nil;

local function closeGenderGui() -- Line: 194
    -- upvalues: u29 (ref)
    if u29 then
        u29:Dismiss();
        u29 = nil;
    end;
end;

local function showGenderGui() -- Line: 210
    -- upvalues: u29 (ref), u28 (ref), ReplicatedStorage (copy), SetGenderRemote (copy), closeGenderGui (copy)
    if u29 then
        return;
    end;

    if game.PlaceId == 89366025586253 then
        return;
    end;

    if not u28 then
        u28 = require(ReplicatedStorage:WaitForChild("Modules"):WaitForChild("Shared"):WaitForChild("KamiCard"));
    end;

    local u30 = u28.new({
        Name = "GenderSelectCard",
        Width = 540,
        Height = 216,
        DisplayOrder = 70
    });
    u29 = u30;
    u30:Render({
        Counter = "FAMILY",
        Title = "CHOOSE YOUR GENDER",
        Objective = "Pick for this character",
        Detail = "Permanent for this character. The family system uses it for roles like Father, Mother, Brother and Sister.",
        Footnote = "Choose carefully.",
        Button = false
    });
    u30.Detail.Size = UDim2.new(1, -36, 0, 44);
    u30.Footnote.Position = UDim2.new(0, 18, 0, 134);
    u30.Footnote.Size = UDim2.new(1, -36, 0, 22);
    local Footnote = u30.Footnote;

    local function makeChoice(u31, p32, p33) -- Line: 235
        -- upvalues: u30 (copy), SetGenderRemote (ref), u29 (ref), Footnote (copy), closeGenderGui (ref)
        local TextButton = Instance.new("TextButton");
        TextButton.Name = u31;
        TextButton.AnchorPoint = Vector2.new(p32, 1);
        TextButton.Position = UDim2.new(0.5, p32 == 1 and -8 or 8, 1, -14);
        TextButton.Size = UDim2.fromOffset(180, 34);
        TextButton.BackgroundColor3 = p33;
        TextButton.BorderSizePixel = 0;
        TextButton.TextColor3 = Color3.new(1, 1, 1);
        TextButton.TextStrokeColor3 = Color3.new(0, 0, 0);
        TextButton.TextStrokeTransparency = 0.5;
        TextButton.Font = Enum.Font.Arcade;
        TextButton.TextSize = 18;
        TextButton.Text = string.upper(u31);
        TextButton.AutoButtonColor = true;
        TextButton.Parent = u30.Card;
        local UIStroke = Instance.new("UIStroke");
        UIStroke.Color = Color3.new(0, 0, 0);
        UIStroke.Thickness = 1.5;
        UIStroke.Parent = TextButton;
        TextButton.MouseButton1Click:Connect(function() -- Line: 256
            -- upvalues: TextButton (copy), SetGenderRemote (ref), u31 (copy), u29 (ref), Footnote (ref), closeGenderGui (ref)
            TextButton.AutoButtonColor = false;
            local v34, v35, v36 = pcall(function() -- Line: 260
                -- upvalues: SetGenderRemote (ref), u31 (ref)
                return SetGenderRemote:InvokeServer(u31);
            end);
            TextButton.AutoButtonColor = true;

            if v34 and v35 then
                if u29 then
                    u29:Dismiss();
                    u29 = nil;
                end;

                return;
            end;

            if v34 then
                v35 = v36 or v35;
            end;

            local v37 = (type(v35) ~= "string" or v35 == "") and "Couldn\'t reach the server -- try again" or v35;
            Footnote.Text = v37;
            Footnote.TextColor3 = Color3.fromRGB(235, 87, 87);

            if v34 and v37:lower():find("already chosen") then
                task.delay(1.2, closeGenderGui);
            end;
        end);

        return TextButton;
    end;

    makeChoice("Male", 1, Color3.fromRGB(52, 96, 160));
    makeChoice("Female", 0, Color3.fromRGB(150, 62, 110));
    u30:SlideIn();
end;

FamilyRemote.OnClientEvent:Connect(function(p38) -- Line: 295
    -- upvalues: fdprint (copy), u1 (ref), refreshAllLabels (copy), showGenderGui (copy)
    if type(p38) ~= "table" then
        return;
    end;

    if p38.Action ~= "FamilyMap" or type(p38.Map) ~= "table" then
        if p38.Action == "PromptGender" then
            showGenderGui();
        end;

        return;
    end;

    fdprint("Map received via remote");
    u1 = p38.Map;
    refreshAllLabels();
end);
LocalPlayer:GetAttributeChangedSignal("NeedsGender"):Connect(function() -- Line: 314
    -- upvalues: LocalPlayer (copy), showGenderGui (copy), u29 (ref)
    if LocalPlayer:GetAttribute("NeedsGender") then
        showGenderGui();

        return;
    end;

    if u29 then
        u29:Dismiss();
        u29 = nil;
    end;
end);

if LocalPlayer:GetAttribute("NeedsGender") then
    showGenderGui();
end;