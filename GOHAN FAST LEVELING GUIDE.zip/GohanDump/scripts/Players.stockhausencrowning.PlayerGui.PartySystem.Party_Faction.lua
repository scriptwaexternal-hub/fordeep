-- Decompiled with Potassium's decompiler.

game.StarterGui:SetCoreGuiEnabled(Enum.CoreGuiType.Backpack, false);
local ReplicatedStorage = game:GetService("ReplicatedStorage");
game:GetService("UserInputService");
local Players = game:GetService("Players");
local Modules = ReplicatedStorage:WaitForChild("Modules");
local Remotes = ReplicatedStorage:WaitForChild("Remotes");
local _ = Modules.Metadata;
local Shared = Modules.Shared;
local Party = ReplicatedStorage.Assets.Gui.Party;
local Create = require(Modules.Utility.Create);
local GlobalFunctions = require(Modules.GlobalFunctions);
local SoundManager = require(Shared.SoundManager);
local LocalPlayer = Players.LocalPlayer;
local PartySystem = LocalPlayer.PlayerGui:WaitForChild("PartySystem");
local Inventory = LocalPlayer.PlayerGui:WaitForChild("HUD").Inventory;
local PartyFrame = Inventory.PartyFrame;
local InviteBox = PartyFrame.InviteBox;
local v1 = PartyFrame.Invite["Invite Button"];
local NameGuess = InviteBox.NameGuess;
local MainFrame = PartySystem.MainFrame;
local HoldingFrame = MainFrame.HoldingFrame;
local v2 = MainFrame.Leave["Leave Button"];
local v3 = MainFrame.Hide["Hide Button"];
local ServerRemote = Remotes.ServerRemote;
local PartyRemote = Remotes.PartyRemote;
local PartyInviteRemote = Remotes.PartyInviteRemote;
local FactionInviteRemote = Remotes.FactionInviteRemote;
local RelationRemote = Remotes.RelationRemote;
local Party2 = workspace.World.Party;
local u4 = false;

if not LocalPlayer.Character then
    LocalPlayer.CharacterAdded:Wait();
end;

function getPlrs(p5)
    -- upvalues: LocalPlayer (copy)
    local v6 = {};

    if p5 == "" then
        return v6;
    end;

    for _, v in ipairs(game.Players:GetPlayers()) do
        if v ~= LocalPlayer and v.Name:sub(1, #p5):lower() == p5:lower() then
            table.insert(v6, v.Name);
        end;
    end;

    table.sort(v6);

    return v6;
end;

local Frame = Instance.new("Frame");
Frame.Name = "SuggestionDropdown";
Frame.BackgroundColor3 = Color3.fromRGB(24, 24, 28);
Frame.BackgroundTransparency = 0.05;
Frame.BorderSizePixel = 0;
Frame.Position = UDim2.new(0, 0, 1, 2);
Frame.Size = UDim2.new(1, 0, 0, 0);
Frame.AutomaticSize = Enum.AutomaticSize.Y;
Frame.Visible = false;
Frame.ZIndex = 50;
Frame.Parent = InviteBox;
local UICorner = Instance.new("UICorner");
UICorner.CornerRadius = UDim.new(0, 6);
UICorner.Parent = Frame;
local UIListLayout = Instance.new("UIListLayout");
UIListLayout.SortOrder = Enum.SortOrder.LayoutOrder;
UIListLayout.Parent = Frame;

local function hideSuggestions() -- Line: 97
    -- upvalues: Frame (copy)
    Frame.Visible = false;

    for _, child in ipairs(Frame:GetChildren()) do
        if child:IsA("TextButton") then
            child:Destroy();
        end;
    end;
end;

local function selectSuggestion(p7) -- Line: 104
    -- upvalues: InviteBox (copy), NameGuess (copy), hideSuggestions (copy)
    InviteBox.Text = p7;
    NameGuess.Text = p7;
    hideSuggestions();
end;

local function refreshSuggestions(p8) -- Line: 110
    -- upvalues: hideSuggestions (copy), InviteBox (copy), Frame (copy), NameGuess (copy)
    hideSuggestions();

    if InviteBox.Text == "" or #p8 == 0 then
        return;
    end;

    if #p8 == 1 and p8[1] == InviteBox.Text then
        return;
    end;

    for i, v in ipairs(p8) do
        if i > 5 then
            break;
        end;

        local TextButton = Instance.new("TextButton");
        TextButton.Name = v;
        TextButton.Text = v;
        TextButton.LayoutOrder = i;
        TextButton.Size = UDim2.new(1, 0, 0, 22);
        TextButton.BackgroundColor3 = Color3.fromRGB(36, 36, 44);
        TextButton.TextColor3 = Color3.fromRGB(230, 230, 230);
        TextButton.Font = Enum.Font.Gotham;
        TextButton.TextSize = 14;
        TextButton.BorderSizePixel = 0;
        TextButton.ZIndex = 51;
        TextButton.AutoButtonColor = true;
        TextButton.Parent = Frame;
        TextButton.Activated:Connect(function() -- Line: 130
            -- upvalues: v (copy), InviteBox (ref), NameGuess (ref), hideSuggestions (ref)
            local v9 = v;
            InviteBox.Text = v9;
            NameGuess.Text = v9;
            hideSuggestions();
        end);
    end;

    Frame.Visible = true;
end;

InviteBox:GetPropertyChangedSignal("Text"):Connect(function() -- Line: 137
    -- upvalues: InviteBox (copy), NameGuess (copy), refreshSuggestions (copy)
    local v10 = getPlrs(InviteBox.Text);

    if #v10 > 0 and InviteBox.Text ~= "" then
        NameGuess.Text = v10[1];
    else
        NameGuess.Text = "";
    end;

    refreshSuggestions(v10);
end);
InviteBox.FocusLost:Connect(function(p11) -- Line: 147
    -- upvalues: NameGuess (copy), InviteBox (copy), hideSuggestions (copy)
    if p11 and NameGuess.Text ~= "" then
        InviteBox.Text = NameGuess.Text;
    end;

    task.delay(0.25, function() -- Line: 153
        -- upvalues: InviteBox (ref), hideSuggestions (ref)
        if not InviteBox:IsFocused() then
            hideSuggestions();
        end;
    end);
end);
v1.MouseButton1Up:Connect(function() -- Line: 158
    -- upvalues: u4 (ref), InviteBox (copy), NameGuess (copy), ServerRemote (copy), hideSuggestions (copy)
    if u4 then
        return;
    end;

    if InviteBox.Visible == false then
        InviteBox.Visible = true;

        return;
    end;

    if InviteBox.Visible == true and InviteBox.Text == "" then
        InviteBox.Visible = false;

        return;
    end;

    local Text = NameGuess.Text;

    if NameGuess.Text ~= "" and InviteBox.Text == NameGuess.Text then
        ServerRemote:FireServer(nil, {
            Module = "PartyManager",
            Action = "AddMember",
            Name = Text
        });
        hideSuggestions();
        u4 = true;
        task.wait(5);
        u4 = false;
    end;
end);
v2.MouseButton1Up:Connect(function() -- Line: 177
    -- upvalues: LocalPlayer (copy), GlobalFunctions (copy), SoundManager (copy), ServerRemote (copy)
    local RootAndHumanoid = GlobalFunctions.GetRootAndHumanoid(LocalPlayer.Character);
    SoundManager.AddSound("Leave SFX", {
        Parent = RootAndHumanoid
    }, "Client");
    ServerRemote:FireServer(nil, {
        Module = "PartyManager",
        Action = "RemoveMember",
        Name = LocalPlayer.Name
    });
end);
v3.MouseButton1Up:Connect(function() -- Line: 184
    -- upvalues: HoldingFrame (copy)
    HoldingFrame.Visible = not HoldingFrame.Visible;
end);
local Y = PartyFrame.Position.Y;

local function layoutInviteRow() -- Line: 199
    -- upvalues: MainFrame (copy), PartyFrame (copy), Y (copy), Inventory (copy)
    if not MainFrame.Visible then
        PartyFrame.Position = UDim2.new(PartyFrame.Position.X, Y);

        return;
    end;

    local AbsoluteSize = Inventory.AbsoluteSize;

    if AbsoluteSize.Y <= 0 then
        return;
    end;

    PartyFrame.Position = UDim2.new(PartyFrame.Position.X, UDim.new((MainFrame.Leave.AbsolutePosition.Y - 8 - PartyFrame.AbsoluteSize.Y - Inventory.AbsolutePosition.Y) / AbsoluteSize.Y, 0));
end;

MainFrame:GetPropertyChangedSignal("Visible"):Connect(function() -- Line: 215
    -- upvalues: layoutInviteRow (copy)
    task.defer(layoutInviteRow);
end);
MainFrame:GetPropertyChangedSignal("AbsolutePosition"):Connect(layoutInviteRow);
Inventory:GetPropertyChangedSignal("AbsoluteSize"):Connect(layoutInviteRow);
task.defer(layoutInviteRow);

local function Add_Party_Member(p12) -- Line: 221
    -- upvalues: MainFrame (copy), HoldingFrame (copy), Party (copy), LocalPlayer (copy), RelationRemote (copy), ServerRemote (copy), GlobalFunctions (copy), SoundManager (copy), Create (copy)
    MainFrame.Visible = true;
    local PartyLeader = p12.PartyLeader;
    local MemberColorTable = p12.MemberColorTable;

    for _, v in pairs(p12.MemberAddTable) do
        if v and v:IsA("Player") then
            local u13 = v.Character or v.CharacterAdded:Wait();
            u13.Archivable = true;
            local u14 = u13:FindFirstChildOfClass("Humanoid") or u13:WaitForChild("Humanoid", 5);
            u13:FindFirstChild("HumanoidRootPart");

            if u14 then
                local v15 = HoldingFrame:FindFirstChild(v.Name);

                if v15 then
                    v15:Destroy();
                end;

                local u16 = Party.PlayerFrame:Clone();
                u16.Parent = HoldingFrame;
                u16.NameLabel.Text = u14.DisplayName;
                u16.Name = v.Name;
                local ViewportFrame = u16.ViewportFrame;
                local v17 = u13:Clone();

                if v17 then
                    v17.Parent = ViewportFrame;
                    local Camera = Instance.new("Camera");
                    Camera.Parent = ViewportFrame;
                    ViewportFrame.CurrentCamera = Camera;
                    Camera.CFrame = v17:FindFirstChild("Head").CFrame * CFrame.new(0, 0, -2);
                    Camera.CFrame = CFrame.lookAt(Camera.CFrame.Position, v17:FindFirstChild("Head").Position);
                end;

                if v == LocalPlayer then
                    u16.RelationLabel.Text = "Self";
                    u16["Send Energy"].Visible = false;
                    local Help = u16:FindFirstChild("Help");

                    if Help then
                        Help.Visible = false;
                    end;
                else
                    u16.RelationLabel.Text = tostring(RelationRemote:InvokeServer(v));
                end;

                if v == PartyLeader then
                    u16.LeaderFrame.Visible = true;
                end;

                local v18 = LocalPlayer == PartyLeader and v ~= LocalPlayer and u16:FindFirstChild("Kick");

                if v18 then
                    v18.Visible = true;
                    v18.MouseButton1Click:Connect(function() -- Line: 286
                        -- upvalues: ServerRemote (ref), v (copy)
                        ServerRemote:FireServer(nil, {
                            Module = "PartyManager",
                            Action = "Kick",
                            Name = v.Name
                        });
                    end);
                end;

                local function Send_Energy() -- Line: 376
                    -- upvalues: u16 (copy), v (copy), LocalPlayer (ref), GlobalFunctions (ref), SoundManager (ref), ServerRemote (ref), Create (ref)
                    local u19 = u16["Send Energy"]["Send Button"];
                    local v20 = v:FindFirstChild("Send Energy CD");

                    if v20 then
                        local Value = v20.Value;
                        u19["CD Frame"].Size = UDim2.new(1, 0, Value / 100, 0);
                        u19["CD Frame"]:TweenSize(UDim2.new(1, 0, 0, 0), "Out", "Sine", Value);
                    else
                        u19["CD Frame"]:TweenSize(UDim2.new(1, 0, 0, 0));
                    end;

                    local u21 = u19.MouseButton1Up:Connect(function() -- Line: 391
                        -- upvalues: v (ref), LocalPlayer (ref), GlobalFunctions (ref), SoundManager (ref), ServerRemote (ref), u19 (copy), Create (ref)
                        if v:FindFirstChild("Send Energy CD") then
                            return;
                        end;

                        local Name = v.Name;
                        local RootAndHumanoid = GlobalFunctions.GetRootAndHumanoid(LocalPlayer.Character);
                        SoundManager.AddSound("Lend Energy SFX", {
                            Parent = RootAndHumanoid
                        }, "Client");
                        ServerRemote:FireServer(nil, {
                            Module = "PartyManager",
                            Action = "SendEnergy",
                            CD_Time = 100,
                            Name = Name
                        });
                        u19["CD Frame"].Size = UDim2.new(1, 0, 1, 0);
                        u19["CD Frame"]:TweenSize(UDim2.new(1, 0, 0, 0), "Out", "Sine", 100);
                        Create.new(v, "Send Energy CD", 100);
                    end);
                    local u22 = nil;
                    u22 = u16.Destroying:Connect(function() -- Line: 408
                        -- upvalues: u21 (ref), u22 (ref)
                        u21:Disconnect();
                        u22:Disconnect();
                    end);
                end;

                local function Relation_Check() -- Line: 418
                    -- upvalues: v (copy), LocalPlayer (ref), u16 (copy), RelationRemote (ref)
                    if v == LocalPlayer then
                        return;
                    end;

                    while u16.Parent ~= nil do
                        u16.RelationLabel.Text = tostring(RelationRemote:InvokeServer(v));
                        task.wait(5);
                    end;
                end;

                local function Party_Marker() -- Line: 426
                    -- upvalues: MemberColorTable (copy), v (copy), u16 (copy), LocalPlayer (ref), Party (ref), u13 (ref)
                    for _, v4 in pairs(MemberColorTable) do
                        if v4[1].Name == v.Name then
                            local v23 = v4[2];
                            u16.ColorFrame.BackgroundColor3 = v23;

                            if v ~= LocalPlayer then
                                local u24 = Party["Party Marker"]:Clone();
                                u24.Parent = u16;
                                u24.Adornee = u13;
                                u24.Frame.BackgroundColor3 = v23;
                                local u26 = v.CharacterAdded:Connect(function(p25) -- Line: 444
                                    -- upvalues: u13 (ref), u24 (copy)
                                    u13 = p25;
                                    u24.Adornee = p25;
                                end);
                                u16.Destroying:Once(function() -- Line: 448
                                    -- upvalues: u26 (ref)
                                    u26:Disconnect();
                                end);
                            end;
                        end;
                    end;
                end;

                (function() -- Line: 292, Name: Health_Change
                    -- upvalues: u16 (copy), u14 (copy), v (copy), u13 (ref)
                    local u27 = {};
                    local Meter = u16.HealthBar.Meter;
                    local Health = u14.Health;
                    local MaxHealth = u14.MaxHealth;
                    local u28 = Health / MaxHealth;
                    local v29 = u14.HealthChanged:Connect(function() -- Line: 302
                        -- upvalues: Health (ref), u14 (ref), MaxHealth (ref), u28 (ref), Meter (copy)
                        Health = u14.Health;
                        MaxHealth = u14.MaxHealth;
                        u28 = Health / MaxHealth;
                        Meter:TweenSize(UDim2.new(u28, 0, 1, 0), "Out", "Sine", 0.1, true);
                    end);
                    Meter:TweenSize(UDim2.new(u28, 0, 1, 0), "Out", "Sine", 0.1, true);
                    local v31 = v.CharacterAdded:Connect(function() -- Line: 313
                        -- upvalues: u13 (ref), v (ref), Health (ref), MaxHealth (ref), u28 (ref), Meter (copy), u27 (copy)
                        u13 = v.Character or v.CharacterAdded:Wait();
                        local Humanoid = u13:WaitForChild("Humanoid");
                        Health = Humanoid.Health;
                        MaxHealth = Humanoid.MaxHealth;
                        u28 = Health / MaxHealth;
                        Meter:TweenSize(UDim2.new(u28, 0, 1, 0), "Out", "Sine", 0.1, true);
                        local v30 = Humanoid.HealthChanged:Connect(function() -- Line: 326
                            -- upvalues: Health (ref), Humanoid (copy), MaxHealth (ref), u28 (ref), Meter (ref)
                            Health = Humanoid.Health;
                            MaxHealth = Humanoid.MaxHealth;
                            u28 = Health / MaxHealth;
                            Meter:TweenSize(UDim2.new(u28, 0, 1, 0), "Out", "Sine", 0.1, true);
                        end);
                        table.insert(u27, v30);
                    end);
                    table.insert(u27, v31);
                    table.insert(u27, v29);
                    table.insert(u27, nil);
                    u16.Destroying:Connect(function() -- Line: 343
                        -- upvalues: u27 (copy)
                        for _, v4 in pairs(u27) do
                            v4:Disconnect();
                        end;
                    end);
                end)();
                (function() -- Line: 350, Name: Ki_Change
                    -- upvalues: u16 (copy), v (copy)
                    local Meter = u16.KiBar.Meter;
                    local PlayerStats = v:FindFirstChild("PlayerStats");
                    local Ki = PlayerStats:FindFirstChild("Ki", true);
                    local MaxKi = PlayerStats:FindFirstChild("MaxKi", true);
                    local u32 = Ki.Value / MaxKi.Value;
                    local u34 = Ki.Changed:Connect(function(p33) -- Line: 362
                        -- upvalues: u32 (ref), MaxKi (copy), Meter (copy)
                        u32 = p33 / MaxKi.Value;
                        Meter:TweenSize(UDim2.new(u32, 0, 1, 0), "Out", "Sine", 0.1, true);
                    end);
                    Meter:TweenSize(UDim2.new(u32, 0, 1, 0), "Out", "Sine", 0.1, true);
                    local u35 = nil;
                    u35 = u16.Destroying:Connect(function() -- Line: 370
                        -- upvalues: u34 (ref), u35 (ref)
                        u34:Disconnect();
                        u35:Disconnect();
                    end);
                end)();
                Send_Energy();
                (function() -- Line: 468, Name: Help_Button
                    -- upvalues: u16 (copy), LocalPlayer (ref), ServerRemote (ref), v (copy), Create (ref), HoldingFrame (ref)
                    local Help = u16:FindFirstChild("Help");

                    if Help then
                        Help = Help:FindFirstChild("Help Button");
                    end;

                    if not Help then
                        return;
                    end;

                    local v36 = LocalPlayer:FindFirstChild("Help CD");

                    if v36 then
                        Help["CD Frame"].Size = UDim2.new(1, 0, v36.Value / 60, 0);
                        Help["CD Frame"]:TweenSize(UDim2.new(1, 0, 0, 0), "Out", "Sine", v36.Value);
                    else
                        Help["CD Frame"].Size = UDim2.new(1, 0, 0, 0);
                    end;

                    local v38 = Help.MouseButton1Up:Connect(function() -- Line: 480
                        -- upvalues: LocalPlayer (ref), ServerRemote (ref), v (ref), Create (ref), HoldingFrame (ref)
                        if LocalPlayer:FindFirstChild("Help CD") then
                            return;
                        end;

                        ServerRemote:FireServer(nil, {
                            Module = "PartyManager",
                            Action = "Help",
                            Name = v.Name
                        });
                        Create.new(LocalPlayer, "Help CD", 60);

                        for _, child in ipairs(HoldingFrame:GetChildren()) do
                            local v37 = child:FindFirstChild("Help") and child.Help:FindFirstChild("Help Button");

                            if v37 then
                                v37["CD Frame"].Size = UDim2.new(1, 0, 1, 0);
                                v37["CD Frame"]:TweenSize(UDim2.new(1, 0, 0, 0), "Out", "Sine", 60);
                            end;
                        end;
                    end);
                    table.insert(Connections, v38);
                end)();
                Party_Marker();
                task.spawn(Relation_Check);
            end;
        end;
    end;
end;

local function clearMemberFrames() -- Line: 504
    -- upvalues: HoldingFrame (copy)
    for _, child in pairs(HoldingFrame:GetChildren()) do
        if child:IsA("Frame") then
            child:Destroy();
        end;
    end;
end;

PartyRemote.OnClientEvent:Connect(function(u39) -- Line: 512
    -- upvalues: Add_Party_Member (copy), HoldingFrame (copy), MainFrame (copy), clearMemberFrames (copy)
    ({
        Add = function() -- Line: 515
            -- upvalues: Add_Party_Member (ref), u39 (copy)
            Add_Party_Member(u39);
        end,

        Remove = function() -- Line: 520
            -- upvalues: u39 (copy), HoldingFrame (ref)
            local v40 = HoldingFrame:FindFirstChild(u39.Member.Name);

            if v40 then
                v40:Destroy();
            end;
        end,

        Leave = function() -- Line: 531
            -- upvalues: MainFrame (ref), clearMemberFrames (ref)
            MainFrame.Visible = false;
            clearMemberFrames();
        end
    })[u39.Action]();
end);

function PartyInviteRemote.OnClientInvoke(p41) -- Line: 540
    -- upvalues: Party (copy), PartySystem (copy)
    local _ = p41.Action;
    local Inviter = p41.Inviter;
    local v42 = Party.TextPrompt:Clone();
    v42.Parent = PartySystem;
    v42.TimeLabel.Text = 15;
    v42.Text = "Join <font color=\'rgb(244, 255, 192)\'>" .. Inviter .. "</font> Party?";
    local Yes = v42.Yes;
    local u43 = nil;
    local v44 = v42.No.MouseButton1Up:Connect(function() -- Line: 558
        -- upvalues: u43 (ref)
        u43 = false;
    end);
    local v45 = Yes.MouseButton1Up:Connect(function() -- Line: 563
        -- upvalues: u43 (ref)
        u43 = true;
    end);
    local v46 = 0;

    while u43 == nil and v46 < 15 do
        task.wait(1);
        v46 = v46 + 1;
        v42.TimeLabel.Text = 15 - v46;
    end;

    v45:Disconnect();
    v44:Disconnect();
    v42:Destroy();

    if u43 == nil then
        u43 = false;
    end;

    return u43;
end;

function FactionInviteRemote.OnClientInvoke(p47) -- Line: 587
    -- upvalues: Party (copy), PartySystem (copy)
    local _ = p47.Action;
    local Inviter = p47.Inviter;
    local v48 = Party.TextPrompt:Clone();
    v48.Parent = PartySystem;
    v48.TimeLabel.Text = 15;
    v48.Text = "Join <font color=\'rgb(244, 255, 192)\'>" .. Inviter .. "</font> Faction?";
    local Yes = v48.Yes;
    local u49 = nil;
    local v50 = v48.No.MouseButton1Up:Connect(function() -- Line: 605
        -- upvalues: u49 (ref)
        u49 = false;
    end);
    local v51 = Yes.MouseButton1Up:Connect(function() -- Line: 610
        -- upvalues: u49 (ref)
        u49 = true;
    end);
    local v52 = 0;

    while u49 == nil and v52 < 15 do
        task.wait(1);
        v52 = v52 + 1;
        v48.TimeLabel.Text = 15 - v52;
    end;

    v51:Disconnect();
    v50:Disconnect();
    v48:Destroy();

    if u49 == nil then
        u49 = false;
    end;

    return u49;
end;

local u53 = false;

local function awaitChild(p54, p55, p56) -- Line: 661
    local v57 = p54:FindFirstChild(p55, p56 or false);
    local v58 = 0;

    while not v57 and v58 < 10 do
        task.wait(0.1);
        v58 = v58 + 0.1;
        v57 = p54:FindFirstChild(p55, p56 or false);
    end;

    return v57;
end;

local function PartySetup() -- Line: 672
    -- upvalues: u53 (ref), LocalPlayer (copy), awaitChild (copy), clearMemberFrames (copy), MainFrame (copy), Party2 (copy), Players (copy), Add_Party_Member (copy)
    if u53 then
        return;
    end;

    u53 = true;
    local success, result = pcall(function() -- Line: 676
        -- upvalues: LocalPlayer (ref), awaitChild (ref), clearMemberFrames (ref), MainFrame (ref), Party2 (ref), Players (ref), Add_Party_Member (ref)
        local PlayerStats = LocalPlayer:WaitForChild("PlayerStats", 10);

        if not PlayerStats then
            return;
        end;

        local v59 = awaitChild(PlayerStats, "CurrentParty", true);

        if not v59 then
            return;
        end;

        local Value = v59.Value;

        if Value == "" then
            clearMemberFrames();
            MainFrame.Visible = false;

            return;
        end;

        local v60 = awaitChild(Party2, Value);

        if not v60 then
            return;
        end;

        local v61 = v60:FindFirstChild("Party Leader");

        if v61 then
            v61 = Players:FindFirstChild(v61.Value);
        end;

        local v62 = {};
        local v63 = {};

        if v61 then
            table.insert(v62, v61);
        end;

        for _, child in pairs(v60:GetChildren()) do
            if child:IsA("Folder") then
                local v64 = Players:FindFirstChild(child.Name);

                if v64 then
                    if not v61 or v64 ~= v61 then
                        table.insert(v62, v64);
                    end;

                    local Color = child:FindFirstChild("Color");

                    if Color then
                        table.insert(v63, { v64, Color.Value });
                    end;
                end;
            end;
        end;

        if #v62 == 0 then
            return;
        end;

        clearMemberFrames();
        Add_Party_Member({
            PartyLeader = v61,
            MemberAddTable = v62,
            MemberColorTable = v63
        });
    end);
    u53 = false;

    if not success then
        warn("[Party] PartySetup failed: " .. tostring(result));
    end;
end;

LocalPlayer.CharacterAppearanceLoaded:Connect(PartySetup);
task.spawn(PartySetup);