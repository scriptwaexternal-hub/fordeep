-- Decompiled with Potassium's decompiler.

local Debris = game:GetService("Debris");
local ReplicatedStorage = game:GetService("ReplicatedStorage");
local RunService = game:GetService("RunService");
local Assets = ReplicatedStorage.Assets;
local Modules = ReplicatedStorage:WaitForChild("Modules");
local Shared = Modules.Shared;
local SoundManager = require(Shared.SoundManager);
require(Modules.GlobalFunctions);
local Bezier = require(Shared.Bezier);
local Visuals = workspace.World.Visuals;
local Effects = Assets.Effects;
local Particles = Effects.Particles;
local Color3_fromRGB_ret = Color3.fromRGB(255, 255, 255);

local function flyBezier(p1, p2, u3, u4, u5, p6, u7) -- Line: 42
    -- upvalues: Effects (copy), Color3_fromRGB_ret (copy), Visuals (copy), Debris (copy), SoundManager (copy), RunService (copy), Bezier (copy)
    local u8 = Effects.Skills["Ki Blast"]:Clone();
    u8.Name = p1.Name .. ":Ki Blast";
    u8.Color = p2 or Color3_fromRGB_ret;
    u8.Anchored = true;
    u8.CFrame = CFrame.new(u3);
    u8.Parent = Visuals;
    Debris:AddItem(u8, p6);
    SoundManager.AddSound("Ki Blast", {
        Parent = u8
    }, "Client");
    local os_clock_ret = os.clock();
    local u9 = nil;
    u9 = RunService.Heartbeat:Connect(function() -- Line: 55
        -- upvalues: u8 (copy), u9 (ref), os_clock_ret (copy), Bezier (ref), u3 (copy), u4 (copy), u5 (copy), u7 (copy)
        if not u8.Parent then
            u9:Disconnect();

            return;
        end;

        local v10 = (os.clock() - os_clock_ret) / 0.8;
        local math_min_ret = math.min(v10, 1);
        u8.CFrame = CFrame.new(Bezier.quadBezier(math_min_ret, u3, u4, u5));

        if math_min_ret >= 1 then
            u9:Disconnect();

            if u7 then
                u8:Destroy();
            end;
        end;
    end);
end;

return {
    Effect = function(p11) -- Line: 68
        -- upvalues: Particles (copy), Color3_fromRGB_ret (copy), Visuals (copy), Debris (copy)
        local Character = p11.Character;
        local Color = p11.Color;

        if not Character then
            return;
        end;

        for _, v in ipairs({ "Right Arm", "Left Arm" }) do
            local v12 = Character:FindFirstChild(v);

            if v12 then
                local u13 = Particles.EffectBlock:Clone();
                u13.A1.Aura.Color = ColorSequence.new(Color or Color3_fromRGB_ret);
                u13.Parent = Visuals;
                u13.A1.Aura:Emit(10);
                u13.A1.Aura.Enabled = true;
                Debris:AddItem(u13, 2);
                task.delay(1, function() -- Line: 84
                    -- upvalues: u13 (copy)
                    if u13.Parent then
                        u13.A1.Aura.Enabled = false;
                    end;
                end);
                local Weld = Instance.new("Weld");
                Weld.Part0 = u13;
                Weld.Part1 = v12;
                Weld.C0 = CFrame.new(0, 2, 0);
                Weld.Parent = u13;
            end;
        end;
    end,

    Shoot = function(p14) -- Line: 99
        -- upvalues: flyBezier (copy)
        local Character = p14.Character;

        if not Character then
            return;
        end;

        flyBezier(Character, p14.Color, p14.P0, p14.P1, p14.P2, 3, false);
    end
};