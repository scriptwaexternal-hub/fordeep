-- Decompiled with Potassium's decompiler.

local Parent = require(script.Parent.Parent);
local BaseClass = require(script.Parent:WaitForChild("BaseClass"));
local u1 = {
    Enabled = Parent.Theme.BackgroundGradientEnabled,
    Start = Parent.Theme.BackgroundGradient,
    Stop = Parent.Theme.BackgroundGradientStop,
    Rotation = Parent.Theme.BackgroundGradientAngle
};
local u2 = {};
u2.__index = u2;
setmetatable(u2, BaseClass);

function u2.new(p3) -- Line: 17
    -- upvalues: u1 (copy), Parent (copy), u2 (copy)
    local table_clone_ret = table.clone(u1);
    Parent.makeStatefulDefaults(table_clone_ret, p3);
    table_clone_ret._instance = Parent.new("UIGradient")({
        Color = function() -- Line: 22, Name: Color
            -- upvalues: table_clone_ret (copy)
            return ColorSequence.new(table_clone_ret.Start(), table_clone_ret.Stop());
        end,

        Enabled = table_clone_ret.Enabled,
        Rotation = table_clone_ret.Rotation
    });

    return setmetatable(table_clone_ret, u2);
end;

return u2;