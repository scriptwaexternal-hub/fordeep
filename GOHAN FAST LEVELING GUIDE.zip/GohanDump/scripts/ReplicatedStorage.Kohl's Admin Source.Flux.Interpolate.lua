-- Decompiled with Potassium's decompiler.

local Oklab = require(script.Parent.Color).Oklab;

return function(p1: any, p2: any, p3: number) -- Line: 8, Name: Interpolate
    -- upvalues: Oklab (copy)
    if typeof(p1) == "number" then
        return math.lerp(p1, p2, p3);
    end;

    if typeof(p1) == "CFrame" then
        return p1:Lerp(p2, p3);
    end;

    if typeof(p1) == "Color3" then
        return Oklab.toRGB(Oklab.fromRGB(p1):Lerp(Oklab.fromRGB(p2), p3));
    end;

    if typeof(p1) == "ColorSequenceKeypoint" then
        return ColorSequenceKeypoint.new(math.lerp(p1.Time, p2.Time, p3), Oklab.toRGB(Oklab.fromRGB(p1.Value):Lerp(Oklab.fromRGB(p2.Value), p3)));
    end;

    if typeof(p1) == "DateTime" then
        return DateTime.fromUnixTimestampMillis((math.lerp(p1.UnixTimestampMillis, p2.UnixTimestampMillis, p3)));
    end;

    if typeof(p1) == "NumberRange" then
        return NumberRange.new(math.lerp(p1.Min, p2.Min, p3), (math.lerp(p1.Max, p2.Max, p3)));
    end;

    if typeof(p1) == "NumberSequenceKeypoint" then
        return NumberSequenceKeypoint.new(math.lerp(p1.Time, p2.Time, p3), (math.lerp(p1.Value, p2.Value, p3)));
    end;

    if typeof(p1) == "PhysicalProperties" then
        return PhysicalProperties.new(math.lerp(p1.Density, p2.Density, p3), math.lerp(p1.Friction, p2.Friction, p3), math.lerp(p1.Elasticity, p2.Elasticity, p3), math.lerp(p1.FrictionWeight, p2.FrictionWeight, p3), (math.lerp(p1.ElasticityWeight, p2.ElasticityWeight, p3)));
    end;

    if typeof(p1) == "Ray" then
        return Ray.new(p1.Origin:Lerp(p2.Origin, p3), p1.Direction:Lerp(p2.Direction, p3));
    end;

    if typeof(p1) == "Rect" then
        return Rect.new(p1.Min:Lerp(p2.Min, p3), p1.Max:Lerp(p2.Max, p3));
    end;

    if typeof(p1) == "Region3" then
        return Region3.new(p1.CFrame:Lerp(p2.CFrame, p3).Position, p1.Size:Lerp(p2.Size, p3));
    end;

    if typeof(p1) == "Region3int16" then
        return Region3int16.new(Vector3int16.new(math.lerp(p1.Min.X, p2.Min.X, p3), math.lerp(p1.Min.Y, p2.Min.Y, p3), (math.lerp(p1.Min.Z, p2.Min.Z, p3))), Vector3int16.new(math.lerp(p1.Max.X, p2.Max.X, p3), math.lerp(p1.Max.Y, p2.Max.Y, p3), (math.lerp(p1.Max.Z, p2.Max.Z, p3))));
    end;

    if typeof(p1) == "UDim" then
        return UDim.new(math.lerp(p1.Scale, p2.Scale, p3), (math.lerp(p1.Offset, p2.Offset, p3)));
    end;

    if typeof(p1) == "UDim2" then
        return UDim2.new(math.lerp(p1.X.Scale, p2.X.Scale, p3), math.lerp(p1.X.Offset, p2.X.Offset, p3), math.lerp(p1.Y.Scale, p2.Y.Scale, p3), (math.lerp(p1.Y.Offset, p2.Y.Offset, p3)));
    end;

    if typeof(p1) == "Vector2" then
        return p1:Lerp(p2, p3);
    end;

    if typeof(p1) == "Vector2int16" then
        return Vector2int16.new(math.lerp(p1.X, p2.X, p3), (math.lerp(p1.Y, p2.Y, p3)));
    end;

    if typeof(p1) == "Vector3" then
        return p1:Lerp(p2, p3);
    end;

    if typeof(p1) == "Vector3int16" then
        return Vector3int16.new(math.lerp(p1.X, p2.X, p3), math.lerp(p1.Y, p2.Y, p3), (math.lerp(p1.Z, p2.Z, p3)));
    end;

    if p3 < 0.5 then
        return p1;
    end;

    return p2;
end;