-- Decompiled with Potassium's decompiler.

local Players = game:GetService("Players");
local Parent = script.Parent.Parent;
local Auth = require(Parent:WaitForChild("Auth"));
local Argument = require(script.Parent:WaitForChild("Argument"));
local Util = require(Parent:WaitForChild("Util"));
require(Parent:WaitForChild("Type"));
local u1 = {
    Argument = Argument
};
u1.__index = u1;

function u1.new(p2, p3, p4, p5, p6, p7) -- Line: 15
    -- upvalues: Auth (copy), Players (copy), u1 (copy)
    local Rank, v8 = Auth.getRank(p6);
    local v9 = {
        global = false,
        validated = false,
        _K = p2,
        alias = p3,
        array = p5,
        definition = p4,
        env = p4.env,
        from = p6,
        fromPlayer = Players:GetPlayerByUserId(p6),
        fromRank = Rank,
        fromRole = v8,
        rank = Auth.hasCommand(p6, p4) or 0,
        text = p7,
        undo = string.find(p3, "un", 1, true) == 1,
        args = p4.args and (table.create(#p4.args) or {}) or {},
        preparedArgs = p4.args and table.create(#p4.args) or {}
    };

    return setmetatable(v9, u1);
end;

function u1.shouldRequest(p10: table, p11: userdata) -- Line: 38
    -- upvalues: Auth (copy)
    if p10._K.Data.settings.commandRequests == false then
        return false;
    end;

    if p10._K._shouldRequestOverride then
        return p10._K._shouldRequestOverride(p10, p11);
    end;

    local v12;

    if p10.from == p10._K.creatorId then
        v12 = false;
    else
        v12 = p10.rank <= Auth.getRank(p11.UserId);
    end;

    return v12;
end;

function u1.requestCommand(p13: table, p14: userdata, p15: any, p16: any) -- Line: 48
    if not p13.validated then
        return false, p13.Error or "Command must be validated before it is run!";
    end;

    local v17 = p14.Name == p14.DisplayName and "" or " @" .. p14.Name;
    p13._K.Remote.Notify:Fire(p13.fromPlayer, {
        Text = `Requesting <b>{p13.alias}</b> command on <b>{p14.DisplayName}<font transparency="0.5">{v17}</font></b>.`
    });
    local success, result = pcall(p13._K.Remote.RequestCommand.Invoke, p13._K.Remote.RequestCommand, p14, p13.fromPlayer, (`{p13._K.getCommandPrefix()}{p13.alias} {p14.Name}`));

    if not success then
        return false, `{v17} left during "{p13.alias}" command request!`;
    end;

    local v18 = p13._K.Data.settings.themeValid:ToHex();
    local v19 = p13._K.Data.settings.themeInvalid:ToHex();
    local v20;

    if result then
        v20 = `<font color='#{v18}'>accepted</font>`;
    else
        v20 = `<font color='#{v19}'>denied</font>`;
    end;

    p13._K.Remote.Notify:Fire(p13.fromPlayer, {
        Text = `Command request for <b>{p13.alias}</b> was <b>{v20}</b>.`,
        From = p14.UserId
    });

    if result then
        p13._K.Hook.preCommand:Fire(p13);
        local _, result2 = pcall(p16, p13, unpack(p15));

        if result2 then
            p13._K.Remote.Notify:Fire(p13.fromPlayer, {
                From = "_K",
                Sound = "Call_Leave",
                Text = `<b>"{p13.alias}" command failed:</b> {result2}`,
                TextColor3 = Color3.new(1, 0, 0)
            });
        end;

        p13._K.Hook.postCommand:Fire(p13);
    end;
end;

function u1.run(p21) -- Line: 99
    if not p21.validated then
        return false, p21.Error or "Command must be validated before it is run!";
    end;

    local v22 = p21.definition[p21._K.IsServer and "run" or "runClient"];

    if v22 then
        if p21._K.IsServer and p21._K.Data.settings.commandRequests ~= false then
            for i, v in p21.args do
                if v.definition.shouldRequest and string.find(string.lower(v.rawType.name), "player", 1, true) then
                    local v23 = p21.preparedArgs[i];

                    if v23 ~= nil then
                        if typeof(v23) == "Instance" then
                            if v23 ~= p21.fromPlayer and p21:shouldRequest(v23) then
                                task.spawn(p21.requestCommand, p21, v23, p21.preparedArgs, v22);

                                return true;
                            end;
                        else
                            local v24 = i;

                            for i2, v2 in v23 do
                                if v2 ~= p21.fromPlayer and p21:shouldRequest(v2) then
                                    v23[i2] = nil;
                                    local table_clone_ret = table.clone(p21.preparedArgs);
                                    table_clone_ret[v24] = { v2 };
                                    task.spawn(p21.requestCommand, p21, v2, table_clone_ret, v22);
                                end;
                            end;
                        end;
                    end;
                end;
            end;
        end;

        p21._K.Hook.preCommand:Fire(p21);
        local success, result = pcall(v22, p21, unpack(p21.preparedArgs));
        p21._K.Hook.postCommand:Fire(p21);

        if not success then
            warn(`Kohl's Admin "{p21.definition.name}" Command Error:`, result);
        end;

        return success, result;
    end;
end;

function u1.validate(p25) -- Line: 153
    -- upvalues: Util (copy), Argument (copy)
    if p25.validated then
        return true;
    end;

    if p25.definition.args[1] and (string.find(p25.definition.args[1].type, "player", 1, true) and #p25.array < 2) then
        local v26, v27 = unpack(p25.array[1]);
        p25.array[2] = { v26 + #v27, "" };
    end;

    local v28 = 2;
    local v29 = nil;

    for i, v in p25.definition.args do
        local v30 = p25.array[v28];
        local v31 = p25._K.Auth.hasArgument(p25.from, v);

        if v30 then
            if v31 then
                local v32, v33 = unpack(v30);
                local v34, v35;

                if i == #p25.definition.args then
                    local table_create_ret = table.create(#p25.array - v28);
                    v34 = v;
                    v35 = i;

                    for i2 = v28, #p25.array do
                        table.insert(table_create_ret, p25.array[i2][2]);
                        local _ = i2;
                    end;

                    v33 = table.concat(table_create_ret, " ");
                else
                    v34 = v;
                    v35 = i;
                end;

                local v36 = not v29;

                if v36 then
                    if v35 == #p25.definition.args then
                        v36 = false;
                    else
                        v36 = string.find(string.lower(v34.type), "player", 1, true);
                    end;
                end;

                if v36 and p25._K.IsClient then
                    local v37 = p25._K.Registry.types[v34.type];

                    if v37 and v37.suggestions then
                        local v38 = Util.Suggest.query(v33, v37.suggestions(v33, p25.from, v34));

                        if #v38 > 0 then
                            local string_lower_ret = string.lower(v33);
                            local v39, _, _, v40 = unpack(v38[1]);

                            if string.find(string.lower(v39), string_lower_ret, 1, true) or v40 and string.find(string.lower(v40), `[{string_lower_ret}`, 1, true) then
                                v36 = false;
                            end;
                        end;
                    end;
                end;

                if v36 and v28 == #p25.array then
                    local v41 = p25.definition.args[v35 + 1];

                    if v41 and string.find(string.lower(v41.type), "player", 1, true) then
                        v28 = v28 - 1;
                        v33 = "me";
                        v29 = true;
                    end;
                end;

                local v42 = Argument.new(p25, v34, v32, v33);
                local v43, v44 = v42:prepare();

                if v43 or (v29 or not v36) then
                    if v29 and v36 then
                        v42.skipped = v33;
                    end;
                else
                    v42 = Argument.new(p25, v34, v32, "me");
                    v43, v44 = v42:prepare();
                    v28 = v28 - 1;
                    v42.skipped = v33;
                    v29 = true;
                end;

                p25.args[v35] = v42;

                if v43 then
                    v28 = v28 + 1;
                    p25.preparedArgs[v35] = v44;
                else
                    if not v34.optional or v35 >= #p25.definition.args then
                        if v44 then
                            p25.invalidArg = v44.arg;
                            p25.invalidPos = v44.pos;
                            p25.invalidMessage = v44.message;
                        end;

                        return false, v44.message or "Argument failed to prepare";
                    end;

                    v42.skipped = v33;
                end;
            end;
        elseif not v.optional and v31 then
            local v45 = p25.array[1][1];
            p25.invalidPos = v45;
            p25.invalidArg = string.sub(p25.text, v45, v45 + #p25.text);
            p25.argMissing = `Command "{p25.definition.name}" failed, argument {i} missing: {v.name}`;

            return false, p25.argMissing;
        end;
    end;

    p25.validated = true;

    return true;
end;

return u1;