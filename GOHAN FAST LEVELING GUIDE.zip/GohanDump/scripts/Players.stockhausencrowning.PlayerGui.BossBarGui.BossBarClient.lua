-- Decompiled with Potassium's decompiler.

local Players = game:GetService("Players");
local ReplicatedStorage = game:GetService("ReplicatedStorage");
local RunService = game:GetService("RunService");
local TweenService = game:GetService("TweenService");
local UserInputService = game:GetService("UserInputService");
local SoundService = game:GetService("SoundService");
local LocalPlayer = Players.LocalPlayer;
local script_Parent = script.Parent;
local BossifyRemote = ReplicatedStorage:WaitForChild("Remotes"):WaitForChild("BossifyRemote");
local StateManager = require(ReplicatedStorage:WaitForChild("Modules").Metadata.ControlData.StateManager);
local u1 = {
    {
        base = Color3.fromRGB(158, 34, 30),
        hi = Color3.fromRGB(186, 48, 40),
        lo = Color3.fromRGB(96, 16, 16)
    },
    {
        base = Color3.fromRGB(126, 58, 170),
        hi = Color3.fromRGB(158, 86, 208),
        lo = Color3.fromRGB(74, 28, 110)
    },
    {
        base = Color3.fromRGB(238, 238, 242),
        hi = Color3.fromRGB(255, 255, 255),
        lo = Color3.fromRGB(188, 188, 198)
    }
};
local TweenInfo_new_ret = TweenInfo.new(0.6, Enum.EasingStyle.Quad, Enum.EasingDirection.Out);

local function applyStageColor(p2, p3, p4) -- Line: 65
    -- upvalues: u1 (copy), TweenService (copy), TweenInfo_new_ret (copy)
    if not (p2 and (p2.fill and p2.fill.Parent)) then
        return;
    end;

    local v5 = tonumber(p3) or 1;
    local math_floor_ret = math.floor(v5);
    local u6 = u1[math.clamp(math_floor_ret, 1, #u1)];
    local u7 = p2.fill:FindFirstChildOfClass("UIGradient");

    if p4 then
        p2.fill.BackgroundColor3 = u6.base;

        if u7 then
            u7.Color = ColorSequence.new(u6.hi, u6.lo);
        end;

        return;
    end;

    TweenService:Create(p2.fill, TweenInfo_new_ret, {
        BackgroundColor3 = u6.base
    }):Play();

    if u7 then
        task.delay(0.3, function() -- Line: 81
            -- upvalues: u7 (copy), u6 (copy)
            if u7.Parent then
                u7.Color = ColorSequence.new(u6.hi, u6.lo);
            end;
        end);
    end;
end;

local Color3_fromRGB_ret = Color3.fromRGB(122, 101, 62);
local Color3_fromRGB_ret2 = Color3.fromRGB(232, 226, 214);
local Color3_fromRGB_ret3 = Color3.fromRGB(18, 14, 12);
local Color3_fromRGB_ret4 = Color3.fromRGB(214, 178, 84);
local Color3_fromRGB_ret5 = Color3.fromRGB(120, 108, 92);
local u8 = {
    full = {
        entryH = 56,
        portrait = 48,
        nameSize = 20,
        nameY = 2,
        textX = 58,
        barY = 30,
        barH = 12
    },
    compact = {
        entryH = 38,
        portrait = 32,
        nameSize = 15,
        nameY = 1,
        textX = 40,
        barY = 19,
        barH = 8
    }
};
local u9 = {
    Color3.fromRGB(70, 150, 255),
    Color3.fromRGB(230, 80, 200),
    Color3.fromRGB(90, 230, 120),
    Color3.fromRGB(240, 200, 90),
    Color3.fromRGB(154, 120, 232)
};
local u10 = ReplicatedStorage:WaitForChild("Assets"):WaitForChild("Animations"):WaitForChild("Transformations"):WaitForChild("Saiyan"):WaitForChild("First SSJ");
local u11 = 0;
local u12 = ReplicatedStorage:WaitForChild("Assets"):WaitForChild("Sounds"):WaitForChild("UI"):WaitForChild("Alerts"):WaitForChild("Boss Siren");

local function playBossSiren() -- Line: 140
    -- upvalues: u12 (copy), SoundService (copy)
    local u13 = u12:Clone();
    u13.Parent = SoundService;
    u13:Play();
    u13.Ended:Once(function() -- Line: 144
        -- upvalues: u13 (copy)
        u13:Destroy();
    end);
    task.delay(15, function() -- Line: 148
        -- upvalues: u13 (copy)
        if u13.Parent then
            u13:Destroy();
        end;
    end);
end;

local function waitForClearScreen() -- Line: 156
    -- upvalues: u11 (ref)
    local v14 = u11 > os.clock();
    local v15 = os.clock() + 1.3;

    while os.clock() < v15 and not v14 do
        task.wait(0.1);
        v14 = u11 > os.clock();
    end;

    while os.clock() < u11 do
        task.wait(0.1);
    end;

    return v14;
end;

local Frame = Instance.new("Frame");
Frame.Name = "BossList";
Frame.AnchorPoint = Vector2.new(0.5, 1);
Frame.Position = UDim2.fromScale(0.5, 0.862);
Frame.Size = UDim2.fromScale(0.61, 0.34);
Frame.BackgroundTransparency = 1;
Frame.Parent = script_Parent;
local UIListLayout = Instance.new("UIListLayout");
UIListLayout.FillDirection = Enum.FillDirection.Vertical;
UIListLayout.HorizontalAlignment = Enum.HorizontalAlignment.Center;
UIListLayout.SortOrder = Enum.SortOrder.LayoutOrder;
UIListLayout.VerticalAlignment = Enum.VerticalAlignment.Bottom;
UIListLayout.Padding = UDim.new(0, 8);
UIListLayout.Parent = Frame;

local function makeClone(p16) -- Line: 193
    p16.Archivable = true;
    local v17 = p16:Clone();

    if not v17 then
        return nil;
    end;

    for _, descendant in ipairs(v17:GetDescendants()) do
        if descendant:IsA("BaseScript") or descendant:IsA("ModuleScript") then
            descendant:Destroy();
        end;
    end;

    return v17;
end;

local u18 = {};
local u19 = 0;
local u20 = ReplicatedStorage.Assets.Sounds:FindFirstChild("Boss Music 1", true);
local u21 = {
    sound = nil,
    owner = nil
};

local function stopBossMusic() -- Line: 227
    -- upvalues: u21 (copy)
    if u21.sound then
        u21.sound:Destroy();
    end;

    u21.sound = nil;
    u21.owner = nil;
end;

local function startBossMusic(p22) -- Line: 234
    -- upvalues: u18 (copy), u21 (copy), u20 (copy), SoundService (copy)
    local v23 = u18[p22];

    if not v23 then
        return;
    end;

    if u21.owner == p22 and u21.sound then
        return;
    end;

    if u21.sound then
        u21.sound:Destroy();
    end;

    u21.sound = nil;
    u21.owner = nil;
    local v24;

    if v23.musicId then
        v24 = Instance.new("Sound");
        v24.Name = "Boss Music (Custom)";
        v24.SoundId = "rbxassetid://" .. v23.musicId;
        v24.Volume = u20 and u20.Volume or 0.5;
    else
        if not u20 then
            return;
        end;

        v24 = u20:Clone();
    end;

    v24.Looped = true;
    v24.Parent = SoundService;
    v24:Play();
    u21.sound = v24;
    u21.owner = p22;
end;

local function applySizePreset(p25, p26) -- Line: 256
    p25.frame.Size = UDim2.new(1, 0, 0, p26.entryH);
    local Portrait = p25.frame:FindFirstChild("Portrait");

    if Portrait then
        Portrait.Size = UDim2.new(0, p26.portrait, 0, p26.portrait);
    end;

    local BossName = p25.frame:FindFirstChild("BossName");

    if BossName then
        BossName.Position = UDim2.new(0, p26.textX, 0, p26.nameY);
        BossName.Size = UDim2.new(1, -p26.textX, 0, p26.nameSize + 4);
        BossName.TextSize = p26.nameSize;
    end;

    local StageLabel = p25.frame:FindFirstChild("StageLabel");

    if StageLabel then
        StageLabel.Position = UDim2.new(1, 0, 0, p26.nameY + 2);
        StageLabel.TextSize = math.max(p26.nameSize - 4, 11);
    end;

    p25.bar.Position = UDim2.new(0, p26.textX, 0, p26.barY);
    p25.bar.Size = UDim2.new(1, -p26.textX, 0, p26.barH);
end;

local function u29() -- Line: 277
    -- upvalues: u18 (copy), u8 (copy), applySizePreset (copy)
    local v27 = 0;

    for _ in pairs(u18) do
        v27 = v27 + 1;
    end;

    local v28 = v27 >= 3 and u8.compact or u8.full;

    for _, v in pairs(u18) do
        applySizePreset(v, v28);
    end;
end;

local function buildPortraitIn(p30, p31) -- Line: 286
    -- upvalues: makeClone (copy)
    for _, child in ipairs(p30:GetChildren()) do
        if child:IsA("Model") or child:IsA("Camera") then
            child:Destroy();
        end;
    end;

    local v32 = makeClone(p31);

    if not v32 then
        return;
    end;

    v32.Parent = p30;
    local Head = v32:FindFirstChild("Head");
    local HumanoidRootPart = v32:FindFirstChild("HumanoidRootPart");

    if Head and HumanoidRootPart then
        local Camera = Instance.new("Camera");
        Camera.Parent = p30;
        p30.CurrentCamera = Camera;
        Camera.FieldOfView = 45;
        Camera.CFrame = CFrame.lookAt((HumanoidRootPart.CFrame * CFrame.new(0.3, 0.9, -4.2)).Position, Head.Position);
    end;
end;

local function buildEntry(p33, p34) -- Line: 306
    -- upvalues: u19 (ref), Frame (copy), Color3_fromRGB_ret3 (copy), Color3_fromRGB_ret (copy), Color3_fromRGB_ret2 (copy), Color3_fromRGB_ret4 (copy)
    u19 = u19 + 1;
    local Frame2 = Instance.new("Frame");
    Frame2.Name = "Entry_" .. p33.Name;
    Frame2.Size = UDim2.new(1, 0, 0, 56);
    Frame2.BackgroundTransparency = 1;
    Frame2.LayoutOrder = u19;
    Frame2.Parent = Frame;
    local Frame3 = Instance.new("Frame");
    Frame3.Name = "Portrait";
    Frame3.Size = UDim2.new(0, 48, 0, 48);
    Frame3.Position = UDim2.new(0, 0, 0.5, 0);
    Frame3.AnchorPoint = Vector2.new(0, 0.5);
    Frame3.BackgroundColor3 = Color3_fromRGB_ret3;
    Frame3.BackgroundTransparency = 0.1;
    Frame3.BorderSizePixel = 0;
    Frame3.Parent = Frame2;
    local UICorner = Instance.new("UICorner");
    UICorner.CornerRadius = UDim.new(0, 6);
    UICorner.Parent = Frame3;
    local UIStroke = Instance.new("UIStroke");
    UIStroke.Color = Color3_fromRGB_ret;
    UIStroke.Thickness = 2;
    UIStroke.Parent = Frame3;
    local ViewportFrame = Instance.new("ViewportFrame");
    ViewportFrame.Name = "ViewportFrame";
    ViewportFrame.Size = UDim2.fromScale(1, 1);
    ViewportFrame.BackgroundTransparency = 1;
    ViewportFrame.Ambient = Color3.fromRGB(72, 60, 82);
    ViewportFrame.LightColor = Color3.fromRGB(212, 188, 158);
    ViewportFrame.LightDirection = Vector3.new(-0.4, -1, -0.6);
    ViewportFrame.Parent = Frame3;
    local TextLabel = Instance.new("TextLabel");
    TextLabel.Name = "BossName";
    TextLabel.Position = UDim2.new(0, 58, 0, 2);
    TextLabel.Size = UDim2.new(1, -58, 0, 22);
    TextLabel.BackgroundTransparency = 1;
    TextLabel.Font = Enum.Font.Garamond;
    TextLabel.Text = p34;
    TextLabel.TextColor3 = Color3_fromRGB_ret2;
    TextLabel.TextSize = 20;
    TextLabel.TextXAlignment = Enum.TextXAlignment.Left;
    TextLabel.TextStrokeColor3 = Color3.fromRGB(0, 0, 0);
    TextLabel.TextStrokeTransparency = 0.35;
    TextLabel.Parent = Frame2;
    local TextLabel2 = Instance.new("TextLabel");
    TextLabel2.Name = "StageLabel";
    TextLabel2.AnchorPoint = Vector2.new(1, 0);
    TextLabel2.Position = UDim2.new(1, 0, 0, 4);
    TextLabel2.Size = UDim2.new(0, 96, 0, 20);
    TextLabel2.BackgroundTransparency = 1;
    TextLabel2.Font = Enum.Font.Garamond;
    TextLabel2.Text = "";
    TextLabel2.TextColor3 = Color3_fromRGB_ret4;
    TextLabel2.TextSize = 16;
    TextLabel2.TextXAlignment = Enum.TextXAlignment.Right;
    TextLabel2.TextStrokeColor3 = Color3.fromRGB(0, 0, 0);
    TextLabel2.TextStrokeTransparency = 0.35;
    TextLabel2.Parent = Frame2;
    local Frame4 = Instance.new("Frame");
    Frame4.Name = "Bar";
    Frame4.Position = UDim2.new(0, 58, 0, 30);
    Frame4.Size = UDim2.new(1, -58, 0, 12);
    Frame4.BackgroundColor3 = Color3_fromRGB_ret3;
    Frame4.BackgroundTransparency = 0.25;
    Frame4.BorderSizePixel = 0;
    Frame4.Parent = Frame2;
    local UIStroke2 = Instance.new("UIStroke");
    UIStroke2.Name = "BarStroke";
    UIStroke2.Color = Color3_fromRGB_ret;
    UIStroke2.Thickness = 2;
    UIStroke2.Transparency = 0.15;
    UIStroke2.Parent = Frame4;
    local Frame5 = Instance.new("Frame");
    Frame5.Name = "DamageChip";
    Frame5.Size = UDim2.fromScale(1, 1);
    Frame5.BackgroundColor3 = Color3.fromRGB(168, 132, 48);
    Frame5.BorderSizePixel = 0;
    Frame5.ZIndex = 2;
    Frame5.Parent = Frame4;
    local Frame6 = Instance.new("Frame");
    Frame6.Name = "Fill";
    Frame6.Size = UDim2.fromScale(1, 1);
    Frame6.BackgroundColor3 = Color3.fromRGB(158, 34, 30);
    Frame6.BorderSizePixel = 0;
    Frame6.ZIndex = 3;
    Frame6.Parent = Frame4;
    local UIGradient = Instance.new("UIGradient");
    UIGradient.Rotation = 90;
    UIGradient.Color = ColorSequence.new(Color3.fromRGB(186, 48, 40), Color3.fromRGB(96, 16, 16));
    UIGradient.Parent = Frame6;

    for i = 1, 9 do
        local Frame7 = Instance.new("Frame");
        Frame7.Name = "Cut" .. i;
        Frame7.AnchorPoint = Vector2.new(0.5, 0);
        Frame7.Position = UDim2.fromScale(i / 10, 0);
        Frame7.Size = UDim2.new(0, 1, 1, 0);
        Frame7.BackgroundColor3 = Color3.fromRGB(0, 0, 0);
        Frame7.BackgroundTransparency = 0.2;
        Frame7.BorderSizePixel = 0;
        Frame7.ZIndex = 4;
        Frame7.Parent = Frame4;
        local _ = i;
    end;

    return Frame2, ViewportFrame, Frame6, Frame5, Frame4;
end;

local function removeEntry(p35) -- Line: 416
    -- upvalues: u18 (copy), u29 (ref)
    local v36 = u18[p35];

    if not v36 then
        return;
    end;

    u18[p35] = nil;

    for _, v in ipairs(v36.conns) do
        pcall(function() -- Line: 421
            -- upvalues: v (copy)
            v:Disconnect();
        end);
    end;

    if v36.chipTween then
        v36.chipTween:Cancel();
    end;

    v36.frame:Destroy();
    u29();
end;

local function setEntryHealth(p37, p38, p39) -- Line: 428
    -- upvalues: TweenService (copy)
    local math_clamp_ret = math.clamp(p38, 0, 1);
    p37.fill.Size = UDim2.fromScale(math_clamp_ret, 1);

    if p37.chipTween then
        p37.chipTween:Cancel();
    end;

    if p39 or p37.chip.Size.X.Scale <= math_clamp_ret then
        p37.chip.Size = UDim2.fromScale(math_clamp_ret, 1);

        return;
    end;

    p37.chipTween = TweenService:Create(p37.chip, TweenInfo.new(0.6, Enum.EasingStyle.Quad, Enum.EasingDirection.Out, 0, false, 0.35), {
        Size = UDim2.fromScale(math_clamp_ret, 1)
    });
    p37.chipTween:Play();
end;

local function trackEntryCharacter(u40, u41) -- Line: 442
    -- upvalues: setEntryHealth (copy), u18 (copy), buildPortraitIn (copy)
    local Humanoid = u41:WaitForChild("Humanoid", 5);

    if not Humanoid then
        return;
    end;

    local v42 = Humanoid.Health / math.max(Humanoid.MaxHealth, 1);
    local math_clamp_ret = math.clamp(v42, 0, 1);
    u40.fill.Size = UDim2.fromScale(math_clamp_ret, 1);

    if u40.chipTween then
        u40.chipTween:Cancel();
    end;

    u40.chip.Size = UDim2.fromScale(math_clamp_ret, 1);
    table.insert(u40.conns, Humanoid.HealthChanged:Connect(function(p43) -- Line: 446
        -- upvalues: setEntryHealth (ref), u40 (copy), Humanoid (copy)
        setEntryHealth(u40, p43 / math.max(Humanoid.MaxHealth, 1));
    end));
    task.delay(0.5, function() -- Line: 449
        -- upvalues: u41 (copy), u18 (ref), u40 (copy), buildPortraitIn (ref)
        if u41.Parent and u18[u40.boss] == u40 then
            buildPortraitIn(u40.viewport, u41);
        end;
    end);
end;

local function hideEntryForMaterialize(p44) -- Line: 463
    local Portrait = p44.frame:FindFirstChild("Portrait");
    local BossName = p44.frame:FindFirstChild("BossName");
    local StageLabel = p44.frame:FindFirstChild("StageLabel");

    if Portrait then
        Portrait.BackgroundTransparency = 1;
        local v45 = Portrait:FindFirstChildOfClass("UIStroke");

        if v45 then
            v45.Transparency = 1;
        end;
    end;

    p44.viewport.ImageTransparency = 1;

    if BossName then
        BossName.TextTransparency = 1;
        BossName.TextStrokeTransparency = 1;
    end;

    if StageLabel then
        StageLabel.TextTransparency = 1;
        StageLabel.TextStrokeTransparency = 1;
    end;

    p44.bar.BackgroundTransparency = 1;
    local BarStroke = p44.bar:FindFirstChild("BarStroke");

    if BarStroke then
        BarStroke.Transparency = 1;
    end;

    p44.fill.BackgroundTransparency = 1;
    p44.chip.BackgroundTransparency = 1;

    for _, child in ipairs(p44.bar:GetChildren()) do
        if child.Name:find("^Cut") then
            child.BackgroundTransparency = 1;
        end;
    end;
end;

local function materializeEntry(p46) -- Line: 491
    -- upvalues: TweenService (copy)
    local Random_new_ret = Random.new();

    local function fade(p47, p48, p49, p50) -- Line: 493
        -- upvalues: TweenService (ref)
        if not (p47 and p47.Parent) then
            return;
        end;

        TweenService:Create(p47, TweenInfo.new(p50, Enum.EasingStyle.Quad, Enum.EasingDirection.Out, 0, false, p49), p48):Play();
    end;

    local Portrait = p46.frame:FindFirstChild("Portrait");
    local BossName = p46.frame:FindFirstChild("BossName");
    fade(p46.bar, {
        BackgroundTransparency = 0.25
    }, 0, 1);
    fade(Portrait, {
        BackgroundTransparency = 0.1
    }, 0.2, 1.2);
    fade(p46.fill, {
        BackgroundTransparency = 0
    }, 0.4, 1.6);
    fade(BossName, {
        TextTransparency = 0,
        TextStrokeTransparency = 0.35
    }, 0.5, 2.2);
    fade(p46.frame:FindFirstChild("StageLabel"), {
        TextTransparency = 0,
        TextStrokeTransparency = 0.35
    }, 0.7, 2);
    fade(p46.chip, {
        BackgroundTransparency = 0
    }, 0.6, 1.6);
    fade(p46.viewport, {
        ImageTransparency = 0
    }, 0.8, 1.7);
    fade(p46.bar:FindFirstChild("BarStroke"), {
        Transparency = 0.15
    }, 1.2, 1.8);

    if Portrait then
        fade(Portrait:FindFirstChildOfClass("UIStroke"), {
            Transparency = 0
        }, 1.5, 1.5);
    end;

    for _, child in ipairs(p46.bar:GetChildren()) do
        if child.Name:find("^Cut") then
            fade(child, {
                BackgroundTransparency = 0.2
            }, Random_new_ret:NextNumber(2, 3.5), Random_new_ret:NextNumber(0.5, 1));
        end;
    end;
end;

local function showBoss(u51, p52, p53, p54, p55, p56) -- Line: 522
    -- upvalues: removeEntry (copy), buildEntry (copy), u18 (copy), u29 (ref), u1 (copy), u21 (copy), startBossMusic (copy), trackEntryCharacter (copy), hideEntryForMaterialize (copy), waitForClearScreen (copy), playBossSiren (copy), materializeEntry (copy)
    removeEntry(u51);
    local v57, v58, v59, v60, v61 = buildEntry(u51, p52 or u51.DisplayName);
    local u62 = {
        boss = u51,
        frame = v57,
        viewport = v58,
        fill = v59,
        chip = v60,
        bar = v61,
        conns = {},
        musicId = p56
    };
    u18[u51] = u62;
    u29();
    local StageLabel = v57:FindFirstChild("StageLabel");

    if StageLabel and (p54 and p54 > 1) then
        StageLabel.Text = "Stage " .. tostring(p53 or 1);
    end;

    local v63 = p53 or 1;

    if u62 and (u62.fill and u62.fill.Parent) then
        local v64 = tonumber(v63) or 1;
        local math_floor_ret = math.floor(v64);
        local v65 = u1[math.clamp(math_floor_ret, 1, #u1)];
        local v66 = u62.fill:FindFirstChildOfClass("UIGradient");
        u62.fill.BackgroundColor3 = v65.base;

        if v66 then
            v66.Color = ColorSequence.new(v65.hi, v65.lo);
        end;
    end;

    if p55 then
        if not u21.sound then
            startBossMusic(u51);
        end;

        if u51.Character then
            trackEntryCharacter(u62, u51.Character);
        end;

        table.insert(u62.conns, u51.CharacterAdded:Connect(function(p67) -- Line: 552
            -- upvalues: trackEntryCharacter (ref), u62 (copy)
            trackEntryCharacter(u62, p67);
        end));

        return u62;
    end;

    hideEntryForMaterialize(u62);
    task.spawn(function() -- Line: 562
        -- upvalues: waitForClearScreen (ref), u18 (ref), u51 (copy), u62 (copy), playBossSiren (ref), u21 (ref), startBossMusic (ref), materializeEntry (ref)
        local v68 = waitForClearScreen();

        if u18[u51] ~= u62 or not u62.frame.Parent then
            return;
        end;

        if not v68 then
            playBossSiren();

            if not u21.sound then
                startBossMusic(u51);
            end;
        end;

        materializeEntry(u62);
    end);

    if u51.Character then
        trackEntryCharacter(u62, u51.Character);
    end;

    table.insert(u62.conns, u51.CharacterAdded:Connect(function(p69) -- Line: 578
        -- upvalues: trackEntryCharacter (ref), u62 (copy)
        trackEntryCharacter(u62, p69);
    end));

    return u62;
end;

local u70 = false;
local u71 = false;
local u72 = nil;
local u73 = nil;

local function buildAbilityIcon() -- Line: 593
    -- upvalues: u73 (ref), Frame (copy), Color3_fromRGB_ret3 (copy), Color3_fromRGB_ret (copy), Color3_fromRGB_ret2 (copy), Color3_fromRGB_ret4 (copy), waitForClearScreen (copy), TweenService (copy)
    if u73 and u73.icon.Parent then
        u73.icon:Destroy();
    end;

    local Frame2 = Instance.new("Frame");
    Frame2.Name = "AbilityIcon";
    Frame2.Size = UDim2.new(0, 150, 0, 68);
    Frame2.BackgroundTransparency = 1;
    Frame2.LayoutOrder = 0;
    Frame2.Parent = Frame;
    local Frame3 = Instance.new("Frame");
    Frame3.Name = "Plate";
    Frame3.Size = UDim2.new(1, 0, 0, 46);
    Frame3.BackgroundColor3 = Color3_fromRGB_ret3;
    Frame3.BackgroundTransparency = 0.15;
    Frame3.BorderSizePixel = 0;
    Frame3.Parent = Frame2;
    local UICorner = Instance.new("UICorner");
    UICorner.CornerRadius = UDim.new(0, 6);
    UICorner.Parent = Frame3;
    local UIStroke = Instance.new("UIStroke");
    UIStroke.Color = Color3_fromRGB_ret;
    UIStroke.Thickness = 2;
    UIStroke.Parent = Frame3;
    local TextLabel = Instance.new("TextLabel");
    TextLabel.Name = "AbilityName";
    TextLabel.Size = UDim2.new(1, -8, 0, 24);
    TextLabel.Position = UDim2.new(0, 4, 0, 2);
    TextLabel.BackgroundTransparency = 1;
    TextLabel.Font = Enum.Font.Garamond;
    TextLabel.Text = "Super Push";
    TextLabel.TextSize = 22;
    TextLabel.TextColor3 = Color3_fromRGB_ret2;
    TextLabel.Parent = Frame3;
    local TextLabel2 = Instance.new("TextLabel");
    TextLabel2.Name = "CooldownLabel";
    TextLabel2.Size = UDim2.new(1, -8, 0, 16);
    TextLabel2.Position = UDim2.new(0, 4, 0, 26);
    TextLabel2.BackgroundTransparency = 1;
    TextLabel2.Font = Enum.Font.Garamond;
    TextLabel2.Text = "READY";
    TextLabel2.TextSize = 14;
    TextLabel2.TextColor3 = Color3_fromRGB_ret4;
    TextLabel2.Parent = Frame3;
    local TextLabel3 = Instance.new("TextLabel");
    TextLabel3.Name = "Controls";
    TextLabel3.Size = UDim2.new(1, 0, 0, 16);
    TextLabel3.Position = UDim2.new(0, 0, 0, 50);
    TextLabel3.BackgroundTransparency = 1;
    TextLabel3.Font = Enum.Font.Garamond;
    TextLabel3.Text = "F + Right Click";
    TextLabel3.TextSize = 13;
    TextLabel3.TextColor3 = Color3_fromRGB_ret2;
    TextLabel3.TextStrokeColor3 = Color3.fromRGB(0, 0, 0);
    TextLabel3.TextStrokeTransparency = 0.3;
    TextLabel3.Parent = Frame2;
    Frame3.BackgroundTransparency = 1;
    UIStroke.Transparency = 1;
    TextLabel.TextTransparency = 1;
    TextLabel2.TextTransparency = 1;
    TextLabel3.TextTransparency = 1;
    TextLabel3.TextStrokeTransparency = 1;
    task.spawn(function() -- Line: 661
        -- upvalues: waitForClearScreen (ref), Frame2 (copy), TweenService (ref), Frame3 (copy), TextLabel (copy), TextLabel2 (copy), UIStroke (copy), TextLabel3 (copy)
        waitForClearScreen();

        if not Frame2.Parent then
            return;
        end;

        local function _(p74, p75, p76, p77) -- Line: 664
            -- upvalues: TweenService (ref)
            TweenService:Create(p74, TweenInfo.new(p77, Enum.EasingStyle.Quad, Enum.EasingDirection.Out, 0, false, p76), p75):Play();
        end;

        TweenService:Create(Frame3, TweenInfo.new(1, Enum.EasingStyle.Quad, Enum.EasingDirection.Out, 0, false, 0), {
            BackgroundTransparency = 0.15
        }):Play();
        TweenService:Create(TextLabel, TweenInfo.new(1.4, Enum.EasingStyle.Quad, Enum.EasingDirection.Out, 0, false, 0.4), {
            TextTransparency = 0
        }):Play();
        TweenService:Create(TextLabel2, TweenInfo.new(1.6, Enum.EasingStyle.Quad, Enum.EasingDirection.Out, 0, false, 0.8), {
            TextTransparency = 0
        }):Play();
        TweenService:Create(UIStroke, TweenInfo.new(1.5, Enum.EasingStyle.Quad, Enum.EasingDirection.Out, 0, false, 1), {
            Transparency = 0
        }):Play();
        TweenService:Create(TextLabel3, TweenInfo.new(1.8, Enum.EasingStyle.Quad, Enum.EasingDirection.Out, 0, false, 1.4), {
            TextTransparency = 0,
            TextStrokeTransparency = 0.3
        }):Play();
    end);
    u73 = {
        icon = Frame2,
        cd = TextLabel2,
        key = TextLabel
    };
end;

local function setIconReady(p78) -- Line: 679
    -- upvalues: u71 (ref), u73 (ref), Color3_fromRGB_ret4 (copy), Color3_fromRGB_ret5 (copy), Color3_fromRGB_ret2 (copy)
    u71 = p78;

    if not u73 then
        return;
    end;

    u73.cd.TextColor3 = p78 and Color3_fromRGB_ret4 or Color3_fromRGB_ret5;
    u73.key.TextColor3 = p78 and Color3_fromRGB_ret2 or Color3_fromRGB_ret5;

    if p78 then
        u73.cd.Text = "READY";
    end;
end;

local function runCooldownDisplay(u79) -- Line: 687
    -- upvalues: u72 (ref), u73 (ref)
    if u72 then
        task.cancel(u72);
    end;

    u72 = task.spawn(function() -- Line: 689
        -- upvalues: u79 (copy), u73 (ref)
        local v80 = os.clock() + u79;

        while os.clock() < v80 do
            if u73 then
                local cd = u73.cd;
                local v81 = v80 - os.clock();
                local math_ceil_ret = math.ceil(v81);
                cd.Text = tostring(math_ceil_ret);
            end;

            task.wait(0.25);
        end;
    end);
end;

local u82 = false;
UserInputService.InputBegan:Connect(function(p83, p84) -- Line: 701
    -- upvalues: u82 (ref), LocalPlayer (copy), u70 (ref), u71 (ref), StateManager (copy), BossifyRemote (copy)
    if p84 then
        return;
    end;

    if p83.KeyCode == Enum.KeyCode.F then
        u82 = true;

        if LocalPlayer.Character then
            LocalPlayer.Character:SetAttribute("SuperPushCasting", nil);
        end;
    elseif p83.UserInputType == Enum.UserInputType.MouseButton2 and (u82 and (u70 and u71)) then
        local Character = LocalPlayer.Character;

        if Character then
            Character:SetAttribute("SuperPushCasting", true);
            StateManager.ClearState(Character, "Blocking");
        end;

        BossifyRemote:FireServer({
            Action = "Blast"
        });
    end;
end);
UserInputService.InputEnded:Connect(function(p85) -- Line: 730
    -- upvalues: u82 (ref), LocalPlayer (copy)
    if p85.KeyCode == Enum.KeyCode.F then
        u82 = false;

        if LocalPlayer.Character then
            LocalPlayer.Character:SetAttribute("SuperPushCasting", nil);
        end;
    end;
end);

local function runPanelCamera(p86, u87, u88) -- Line: 745
    -- upvalues: RunService (copy)
    local Head = u87:FindFirstChild("Head");
    local HumanoidRootPart = u87:FindFirstChild("HumanoidRootPart");

    if not (Head and HumanoidRootPart) then
        return nil;
    end;

    local Camera = Instance.new("Camera");
    Camera.Parent = p86;
    p86.CurrentCamera = Camera;
    Camera.FieldOfView = 45;
    local u89 = 1;
    pcall(function() -- Line: 762
        -- upvalues: u89 (ref), u87 (copy)
        local v90 = u87:GetExtentsSize().Y / 5.5;
        u89 = math.clamp(v90, 0.6, 6);
    end);
    local Position = HumanoidRootPart.Position;
    local u91 = u89 * 11;
    local u92 = u89 * 5;
    local LookVector = HumanoidRootPart.CFrame.LookVector;
    local u93 = (math.atan2(LookVector.X, LookVector.Z) - 0.2617993877991494) % 6.283185307179586;

    if u93 < 4.363323129985824 then
        u93 = u93 + 6.283185307179586;
    end;

    local u94 = Head.Position - Vector3.new(0, u89 * 0.2, 0);
    local u95 = nil;
    local os_clock_ret = os.clock();
    u95 = RunService.RenderStepped:Connect(function() -- Line: 788
        -- upvalues: u87 (copy), u95 (ref), os_clock_ret (copy), u88 (copy), u91 (copy), u93 (ref), u92 (copy), Position (copy), u94 (copy), u89 (ref), Camera (copy)
        if not u87.Parent then
            u95:Disconnect();

            return;
        end;

        local v96 = (os.clock() - os_clock_ret) / u88;
        local math_clamp_ret = math.clamp(v96, 0, 1);
        local v97, v98, v99;

        if math_clamp_ret < 0.27 then
            v97 = u91;
            v98 = 0;
            v99 = 0;
        elseif math_clamp_ret < 0.86 then
            v98 = 1 - (1 - (math_clamp_ret - 0.27) / 0.59) ^ 2;
            v99 = v98 * u93;
            v97 = u91 - v98 * (u91 - u92);
        else
            v99 = u93;
            v97 = u92;
            v98 = 1;
        end;

        local v100 = Position:Lerp(u94, v98) + Vector3.new(0, (1 - v98) * 1.5 * u89, 0);
        local v101 = 0.2617993877991494 + v99;
        local v102 = math.sin(v101) * v97;
        local v103 = math.cos(v101) * v97;
        local v104 = v100 + Vector3.new(v102, (1.2 - v98 * 1.1) * u89, v103);
        Camera.CFrame = CFrame.lookAt(v104, v100);
    end);

    return u95;
end;

local function playCinematic(u105) -- Line: 815
    -- upvalues: u11 (ref), playBossSiren (copy), script_Parent (copy), TweenService (copy), u9 (copy), Color3_fromRGB_ret2 (copy), makeClone (copy), u10 (copy), runPanelCamera (copy), u18 (copy), startBossMusic (copy)
    local math_min_ret = math.min(#u105, 5);

    if math_min_ret == 0 then
        return;
    end;

    u11 = os.clock() + 4.4 + 0.5;
    playBossSiren();
    local Frame2 = Instance.new("Frame");
    Frame2.Name = "BossCinematic";
    Frame2.Size = UDim2.fromScale(1, 1);
    Frame2.BackgroundColor3 = Color3.fromRGB(6, 4, 8);
    Frame2.BackgroundTransparency = 1;
    Frame2.ClipsDescendants = true;
    Frame2.ZIndex = 100;
    Frame2.Parent = script_Parent;
    TweenService:Create(Frame2, TweenInfo.new(0.3), {
        BackgroundTransparency = 0.05
    }):Play();
    local u106 = {};

    for i = 1, math_min_ret do
        local v107 = u105[i];
        local v108 = u9[i];
        local v109 = v107.Player and v107.Player.Character;
        local Frame3 = Instance.new("Frame");
        Frame3.Name = "Panel" .. i;
        Frame3.AnchorPoint = Vector2.new(0, 0);
        Frame3.Size = UDim2.fromScale(1 / math_min_ret, 1);
        Frame3.Position = UDim2.fromScale((i - 1) / math_min_ret, 0);
        Frame3.BackgroundColor3 = v108:Lerp(Color3.new(0, 0, 0), 0.45);
        Frame3.BackgroundTransparency = 1;
        Frame3.ClipsDescendants = true;
        Frame3.BorderSizePixel = 0;
        Frame3.ZIndex = 101;
        Frame3.Parent = Frame2;
        local UIGradient = Instance.new("UIGradient");
        UIGradient.Rotation = 90;
        UIGradient.Color = ColorSequence.new(v108, v108:Lerp(Color3.new(0, 0, 0), 0.6));
        UIGradient.Parent = Frame3;
        task.spawn(function() -- Line: 874
            -- upvalues: Frame3 (copy), script_Parent (ref), math_min_ret (copy), TweenService (ref)
            local Random_new_ret = Random.new();
            local os_clock_ret = os.clock();

            while Frame3.Parent and os.clock() - os_clock_ret < 4.4 do
                for i2 = 1, 4 do
                    local Frame4 = Instance.new("Frame");
                    Frame4.AnchorPoint = Vector2.new(0.5, 0.5);
                    local v110 = Random_new_ret:NextInteger(2, 5);
                    local v111 = Random_new_ret:NextInteger(120, 280);
                    local v112 = Random_new_ret:NextNumber();

                    if v112 < 0.1 then
                        v110 = Random_new_ret:NextInteger(6, 9);
                        v111 = Random_new_ret:NextInteger(300, 430);
                    elseif v112 < 0.28 then
                        v110 = Random_new_ret:NextInteger(6, 9);
                    elseif v112 < 0.46 then
                        v111 = Random_new_ret:NextInteger(300, 430);
                    end;

                    Frame4.Size = UDim2.new(0, v110, 0, v111);
                    local v113 = -22 + Random_new_ret:NextNumber(-3, 3);
                    Frame4.Rotation = v113;
                    Frame4.BackgroundColor3 = Color3.fromRGB(0, 0, 0);
                    Frame4.BackgroundTransparency = Random_new_ret:NextNumber(0.1, 0.35);
                    Frame4.BorderSizePixel = 0;
                    Frame4.ZIndex = 102;
                    local math_rad_ret = math.rad(v113);
                    local v114 = -math.sin(math_rad_ret);
                    local math_cos_ret = math.cos(math_rad_ret);
                    local X = Frame3.AbsoluteSize.X;
                    local Y = Frame3.AbsoluteSize.Y;

                    if X < 2 or Y < 2 then
                        X = math.max(script_Parent.AbsoluteSize.X / math_min_ret, 2);
                        Y = math.max(script_Parent.AbsoluteSize.Y, 2);
                    end;

                    local v115 = Y * 1.7;
                    local v116 = Random_new_ret:NextNumber(-0.2, 1);
                    Frame4.Position = UDim2.fromScale(v116, -0.25);
                    Frame4.Parent = Frame3;
                    local v117 = TweenService:Create(Frame4, TweenInfo.new(Random_new_ret:NextNumber(0.45, 0.8), Enum.EasingStyle.Linear), {
                        Position = UDim2.fromScale(v116 + v115 * v114 / X, -0.25 + v115 * math_cos_ret / Y)
                    });
                    v117.Completed:Once(function() -- Line: 920
                        -- upvalues: Frame4 (copy)
                        Frame4:Destroy();
                    end);
                    v117:Play();
                    local _ = i2;
                end;

                task.wait(Random_new_ret:NextNumber(0.03, 0.08));
            end;
        end);
        local v118;

        if i > 1 then
            v118 = Instance.new("Frame");
            v118.Size = UDim2.new(0, 3, 1, 0);
            v118.Position = UDim2.fromScale(0, 0);
            v118.BackgroundColor3 = Color3.fromRGB(240, 236, 228);
            v118.BackgroundTransparency = 1;
            v118.BorderSizePixel = 0;
            v118.ZIndex = 104;
            v118.Parent = Frame3;
        else
            v118 = nil;
        end;

        local ViewportFrame = Instance.new("ViewportFrame");
        ViewportFrame.Size = UDim2.fromScale(1, 1);
        ViewportFrame.BackgroundTransparency = 1;
        ViewportFrame.ImageTransparency = 1;
        ViewportFrame.Ambient = v108:Lerp(Color3.fromRGB(40, 36, 48), 0.55);
        ViewportFrame.LightColor = v108:Lerp(Color3.fromRGB(255, 244, 224), 0.5);
        ViewportFrame.LightDirection = Vector3.new(-0.3, -1, -0.5);
        ViewportFrame.ZIndex = 103;
        ViewportFrame.Parent = Frame3;
        local WorldModel = Instance.new("WorldModel");
        WorldModel.Parent = ViewportFrame;
        local TextLabel = Instance.new("TextLabel");
        TextLabel.AnchorPoint = Vector2.new(0.5, 1);
        TextLabel.Position = UDim2.fromScale(0.5, 0.94);
        TextLabel.Size = UDim2.fromScale(0.9, 0.07);
        TextLabel.BackgroundTransparency = 1;
        TextLabel.Font = Enum.Font.Garamond;
        TextLabel.Text = v107.Title or (v107.Player and v107.Player.DisplayName or "?");
        TextLabel.TextScaled = true;
        TextLabel.TextColor3 = Color3_fromRGB_ret2;
        TextLabel.TextTransparency = 1;
        TextLabel.TextStrokeColor3 = Color3.fromRGB(0, 0, 0);
        TextLabel.TextStrokeTransparency = 1;
        TextLabel.ZIndex = 104;
        TextLabel.Parent = Frame3;
        local v119 = v109 and makeClone(v109);

        if v119 then
            v119.Parent = WorldModel;
            local u120 = v119:FindFirstChildOfClass("Humanoid");

            if u120 then
                u120 = u120:FindFirstChildOfClass("Animator");
            end;

            if u120 then
                pcall(function() -- Line: 977
                    -- upvalues: u120 (copy), u10 (ref)
                    local v121 = u120:LoadAnimation(u10);
                    v121.Looped = true;
                    v121:Play();
                end);
            end;

            local v122 = runPanelCamera(ViewportFrame, v119, 4.4);

            if v122 then
                table.insert(u106, v122);
            end;
        end;

        local TweenInfo_new_ret2 = TweenInfo.new(0.45, Enum.EasingStyle.Quad, Enum.EasingDirection.Out, 0, false, (i - 1) * 0.09);
        TweenService:Create(Frame3, TweenInfo_new_ret2, {
            BackgroundTransparency = 0
        }):Play();
        TweenService:Create(ViewportFrame, TweenInfo_new_ret2, {
            ImageTransparency = 0
        }):Play();
        TweenService:Create(TextLabel, TweenInfo_new_ret2, {
            TextTransparency = 0,
            TextStrokeTransparency = 0.3
        }):Play();
        local v123;

        if v118 then
            TweenService:Create(v118, TweenInfo_new_ret2, {
                BackgroundTransparency = 0
            }):Play();
            v123 = i;
        else
            v123 = i;
        end;
    end;

    task.delay(4.4, function() -- Line: 999
        -- upvalues: u106 (copy), u105 (copy), u18 (ref), startBossMusic (ref), TweenService (ref), Frame2 (copy)
        for _, v in ipairs(u106) do
            pcall(function() -- Line: 1001
                -- upvalues: v (copy)
                v:Disconnect();
            end);
        end;

        for _, v in ipairs(u105) do
            if u18[v.Player] then
                startBossMusic(v.Player);
                break;
            end;
        end;

        local TweenInfo_new_ret2 = TweenInfo.new(0.5, Enum.EasingStyle.Quad, Enum.EasingDirection.Out);
        TweenService:Create(Frame2, TweenInfo_new_ret2, {
            BackgroundTransparency = 1
        }):Play();

        for _, descendant in ipairs(Frame2:GetDescendants()) do
            if descendant:IsA("Frame") then
                TweenService:Create(descendant, TweenInfo_new_ret2, {
                    BackgroundTransparency = 1
                }):Play();
            elseif descendant:IsA("ViewportFrame") then
                TweenService:Create(descendant, TweenInfo_new_ret2, {
                    ImageTransparency = 1
                }):Play();
            elseif descendant:IsA("TextLabel") then
                TweenService:Create(descendant, TweenInfo_new_ret2, {
                    TextTransparency = 1,
                    TextStrokeTransparency = 1
                }):Play();
            end;
        end;

        task.delay(0.55, function() -- Line: 1025
            -- upvalues: Frame2 (ref)
            Frame2:Destroy();
        end);
    end);
end;

local u124 = {
    CHARGE = 1,
    FREEZE = 1.6,
    RESUME = 0.9,
    FADE = 0.45,
    FOV = 40,
    HOLD_FALLBACK_FRAC = 0.55,
    HOLD_MARKERS = { "Hold", "Charge Hold", "Charge", "Shoot", "Fire" }
};
local Wave = ReplicatedStorage:WaitForChild("Assets"):WaitForChild("Animations"):WaitForChild("Skills"):WaitForChild("Wave");
local u125 = {};
local u126 = false;

local function spawnStageSpeedLines(u127, u128) -- Line: 1067
    -- upvalues: script_Parent (copy), TweenService (copy)
    task.spawn(function() -- Line: 1068
        -- upvalues: u127 (copy), u128 (copy), script_Parent (ref), TweenService (ref)
        local Random_new_ret = Random.new();
        local os_clock_ret = os.clock();

        while u127.Parent and os.clock() - os_clock_ret < u128 do
            for i = 1, 5 do
                local Frame2 = Instance.new("Frame");
                Frame2.AnchorPoint = Vector2.new(0.5, 0.5);
                local v129 = Random_new_ret:NextInteger(2, 5);
                local v130 = Random_new_ret:NextInteger(140, 300);
                local v131 = Random_new_ret:NextNumber();

                if v131 < 0.12 then
                    v129 = Random_new_ret:NextInteger(6, 9);
                    v130 = Random_new_ret:NextInteger(320, 460);
                elseif v131 < 0.3 then
                    v129 = Random_new_ret:NextInteger(6, 9);
                elseif v131 < 0.48 then
                    v130 = Random_new_ret:NextInteger(320, 460);
                end;

                Frame2.Size = UDim2.new(0, v129, 0, v130);
                local v132 = -22 + Random_new_ret:NextNumber(-3, 3);
                Frame2.Rotation = v132;
                Frame2.BackgroundColor3 = Color3.fromRGB(0, 0, 0);
                Frame2.BackgroundTransparency = Random_new_ret:NextNumber(0.1, 0.35);
                Frame2.BorderSizePixel = 0;
                Frame2.ZIndex = 102;
                local math_rad_ret = math.rad(v132);
                local v133 = -math.sin(math_rad_ret);
                local math_cos_ret = math.cos(math_rad_ret);
                local math_max_ret = math.max(u127.AbsoluteSize.X, 2);
                local math_max_ret2 = math.max(u127.AbsoluteSize.Y, 2);

                if math_max_ret < 3 or math_max_ret2 < 3 then
                    math_max_ret = math.max(script_Parent.AbsoluteSize.X, 2);
                    math_max_ret2 = math.max(script_Parent.AbsoluteSize.Y, 2);
                end;

                local v134 = math_max_ret2 * 1.7;
                local v135 = Random_new_ret:NextNumber(-0.2, 1);
                Frame2.Position = UDim2.fromScale(v135, -0.25);
                Frame2.Parent = u127;
                local v136 = TweenService:Create(Frame2, TweenInfo.new(Random_new_ret:NextNumber(0.45, 0.8), Enum.EasingStyle.Linear), {
                    Position = UDim2.fromScale(v135 + v134 * v133 / math_max_ret, v134 * math_cos_ret / math_max_ret2 + -0.25)
                });
                v136.Completed:Once(function() -- Line: 1108
                    -- upvalues: Frame2 (copy)
                    Frame2:Destroy();
                end);
                v136:Play();
                local _ = i;
            end;

            task.wait(Random_new_ret:NextNumber(0.03, 0.08));
        end;
    end);
end;

local function runStageCinematic(p137) -- Line: 1117
    -- upvalues: u124 (copy), u11 (ref), playBossSiren (copy), script_Parent (copy), Color3_fromRGB_ret4 (copy), TweenService (copy), Color3_fromRGB_ret2 (copy), Color3_fromRGB_ret5 (copy), makeClone (copy), Wave (copy), u10 (copy)
    local BossPlayer = p137.BossPlayer;
    local v138;

    if BossPlayer then
        v138 = BossPlayer.Character;
    else
        v138 = BossPlayer;
    end;

    local u139 = u124.CHARGE + u124.FREEZE + u124.RESUME;
    local v140 = os.clock() + u139 + u124.FADE;
    u11 = math.max(u11, v140);
    playBossSiren();
    local Frame2 = Instance.new("Frame");
    Frame2.Name = "StageCinematic";
    Frame2.Size = UDim2.fromScale(1, 1);
    Frame2.BackgroundColor3 = Color3.fromRGB(6, 4, 8);
    Frame2.BackgroundTransparency = 1;
    Frame2.ClipsDescendants = true;
    Frame2.ZIndex = 100;
    Frame2.Parent = script_Parent;
    local Frame3 = Instance.new("Frame");
    Frame3.Name = "Panel";
    Frame3.Size = UDim2.fromScale(1, 1);
    Frame3.BackgroundColor3 = Color3_fromRGB_ret4:Lerp(Color3.new(0, 0, 0), 0.55);
    Frame3.BackgroundTransparency = 1;
    Frame3.ClipsDescendants = true;
    Frame3.BorderSizePixel = 0;
    Frame3.ZIndex = 101;
    Frame3.Parent = Frame2;
    local UIGradient = Instance.new("UIGradient");
    UIGradient.Rotation = 90;
    UIGradient.Color = ColorSequence.new(Color3_fromRGB_ret4:Lerp(Color3.new(0, 0, 0), 0.25), Color3_fromRGB_ret4:Lerp(Color3.new(0, 0, 0), 0.75));
    UIGradient.Parent = Frame3;
    task.spawn(function() -- Line: 1068
        -- upvalues: Frame3 (copy), u139 (copy), script_Parent (ref), TweenService (ref)
        local Random_new_ret = Random.new();
        local os_clock_ret = os.clock();

        while Frame3.Parent and os.clock() - os_clock_ret < u139 do
            for i = 1, 5 do
                local Frame4 = Instance.new("Frame");
                Frame4.AnchorPoint = Vector2.new(0.5, 0.5);
                local v141 = Random_new_ret:NextInteger(2, 5);
                local v142 = Random_new_ret:NextInteger(140, 300);
                local v143 = Random_new_ret:NextNumber();

                if v143 < 0.12 then
                    v141 = Random_new_ret:NextInteger(6, 9);
                    v142 = Random_new_ret:NextInteger(320, 460);
                elseif v143 < 0.3 then
                    v141 = Random_new_ret:NextInteger(6, 9);
                elseif v143 < 0.48 then
                    v142 = Random_new_ret:NextInteger(320, 460);
                end;

                Frame4.Size = UDim2.new(0, v141, 0, v142);
                local v144 = -22 + Random_new_ret:NextNumber(-3, 3);
                Frame4.Rotation = v144;
                Frame4.BackgroundColor3 = Color3.fromRGB(0, 0, 0);
                Frame4.BackgroundTransparency = Random_new_ret:NextNumber(0.1, 0.35);
                Frame4.BorderSizePixel = 0;
                Frame4.ZIndex = 102;
                local math_rad_ret = math.rad(v144);
                local v145 = -math.sin(math_rad_ret);
                local math_cos_ret = math.cos(math_rad_ret);
                local math_max_ret = math.max(Frame3.AbsoluteSize.X, 2);
                local math_max_ret2 = math.max(Frame3.AbsoluteSize.Y, 2);

                if math_max_ret < 3 or math_max_ret2 < 3 then
                    math_max_ret = math.max(script_Parent.AbsoluteSize.X, 2);
                    math_max_ret2 = math.max(script_Parent.AbsoluteSize.Y, 2);
                end;

                local v146 = math_max_ret2 * 1.7;
                local v147 = Random_new_ret:NextNumber(-0.2, 1);
                Frame4.Position = UDim2.fromScale(v147, -0.25);
                Frame4.Parent = Frame3;
                local v148 = TweenService:Create(Frame4, TweenInfo.new(Random_new_ret:NextNumber(0.45, 0.8), Enum.EasingStyle.Linear), {
                    Position = UDim2.fromScale(v147 + v146 * v145 / math_max_ret, v146 * math_cos_ret / math_max_ret2 + -0.25)
                });
                v148.Completed:Once(function() -- Line: 1108
                    -- upvalues: Frame4 (copy)
                    Frame4:Destroy();
                end);
                v148:Play();
                local _ = i;
            end;

            task.wait(Random_new_ret:NextNumber(0.03, 0.08));
        end;
    end);
    local ViewportFrame = Instance.new("ViewportFrame");
    ViewportFrame.Size = UDim2.fromScale(1, 1);
    ViewportFrame.BackgroundTransparency = 1;
    ViewportFrame.ImageTransparency = 1;
    ViewportFrame.Ambient = Color3.fromRGB(64, 54, 40);
    ViewportFrame.LightColor = Color3.fromRGB(255, 236, 200);
    ViewportFrame.LightDirection = Vector3.new(-0.3, -1, -0.5);
    ViewportFrame.ZIndex = 103;
    ViewportFrame.Parent = Frame3;
    local WorldModel = Instance.new("WorldModel");
    WorldModel.Parent = ViewportFrame;

    local function makeText(p149, p150, p151, p152) -- Line: 1166
        -- upvalues: Frame3 (copy)
        local TextLabel = Instance.new("TextLabel");
        TextLabel.AnchorPoint = Vector2.new(0.5, 0);
        TextLabel.Position = UDim2.fromScale(0.5, p149);
        TextLabel.Size = UDim2.fromScale(0.9, p150);
        TextLabel.BackgroundTransparency = 1;
        TextLabel.Font = Enum.Font.Garamond;
        TextLabel.TextScaled = true;
        TextLabel.TextColor3 = p151;
        TextLabel.TextTransparency = 1;
        TextLabel.TextStrokeColor3 = Color3.fromRGB(0, 0, 0);
        TextLabel.TextStrokeTransparency = 1;
        TextLabel.ZIndex = 104;
        TextLabel.Parent = Frame3;

        return TextLabel;
    end;

    local v153 = makeText(0.06, 0.06, Color3_fromRGB_ret2);
    v153.Text = BossPlayer and BossPlayer.DisplayName or "?";
    local v154 = makeText(0.13, 0.045, Color3_fromRGB_ret5);
    v154.Text = p137.Title or "";
    v154.TextColor3 = Color3_fromRGB_ret2:Lerp(Color3.new(0, 0, 0), 0.25);
    local u155 = makeText(0.78, 0.11, Color3_fromRGB_ret4);
    u155.Text = "Stage " .. tostring(p137.Stage or "?");
    local u156 = nil;
    local u157 = v138 and makeClone(v138);

    if u157 then
        u157.Parent = WorldModel;
        local Camera = Instance.new("Camera");
        Camera.Parent = ViewportFrame;
        ViewportFrame.CurrentCamera = Camera;
        Camera.FieldOfView = u124.FOV;
        local HumanoidRootPart = u157:FindFirstChild("HumanoidRootPart");

        if HumanoidRootPart then
            local u158 = 6;
            pcall(function() -- Line: 1207
                -- upvalues: u158 (ref), u157 (copy)
                u158 = u157:GetExtentsSize().Y;
            end);
            local math_rad_ret = math.rad(u124.FOV / 2);
            local v159 = u158 * 0.62 / math.tan(math_rad_ret);
            local v160 = HumanoidRootPart.Position + Vector3.new(0, u158 * 0.08, 0);
            Camera.CFrame = CFrame.lookAt(v160 + HumanoidRootPart.CFrame.LookVector * v159, v160);
        end;

        local v161 = u157:FindFirstChildOfClass("Humanoid");
        local u162 = v161 and v161:FindFirstChildOfClass("Animator");
        local u163 = p137.AnimName and Wave:FindFirstChild(p137.AnimName) or u10;

        if u162 then
            pcall(function() -- Line: 1221
                -- upvalues: u156 (ref), u162 (copy), u163 (copy), u124 (ref)
                u156 = u162:LoadAnimation(u163);
                u156.Looped = false;
                u156:Play(0.1);
                local u164 = false;

                local function freeze() -- Line: 1229
                    -- upvalues: u164 (ref), u156 (ref)
                    if u164 then
                        return;
                    end;

                    u164 = true;

                    if u156.IsPlaying then
                        u156:AdjustSpeed(0);
                    end;
                end;

                for _, v in ipairs(u124.HOLD_MARKERS) do
                    u156:GetMarkerReachedSignal(v):Once(freeze);
                end;

                task.spawn(function() -- Line: 1237
                    -- upvalues: u156 (ref), u124 (ref), u164 (ref)
                    local os_clock_ret = os.clock();

                    while u156.Length == 0 and os.clock() - os_clock_ret < 1 do
                        task.wait();
                    end;

                    if u156.Length > 0 then
                        while not (u164 or (not u156.IsPlaying or u156.TimePosition >= u156.Length * u124.HOLD_FALLBACK_FRAC)) do
                            task.wait();
                        end;

                        if u164 then
                            return;
                        end;

                        u164 = true;

                        if u156.IsPlaying then
                            u156:AdjustSpeed(0);
                        end;
                    end;
                end);
            end);
        end;
    end;

    local TweenInfo_new_ret2 = TweenInfo.new(0.35, Enum.EasingStyle.Quad, Enum.EasingDirection.Out);
    TweenService:Create(Frame2, TweenInfo_new_ret2, {
        BackgroundTransparency = 0.05
    }):Play();
    TweenService:Create(Frame3, TweenInfo_new_ret2, {
        BackgroundTransparency = 0
    }):Play();
    TweenService:Create(ViewportFrame, TweenInfo_new_ret2, {
        ImageTransparency = 0
    }):Play();
    TweenService:Create(v153, TweenInfo_new_ret2, {
        TextTransparency = 0,
        TextStrokeTransparency = 0.3
    }):Play();
    TweenService:Create(v154, TweenInfo_new_ret2, {
        TextTransparency = 0,
        TextStrokeTransparency = 0.3
    }):Play();
    task.delay(u124.CHARGE, function() -- Line: 1267
        -- upvalues: u155 (copy), TweenService (ref)
        if not u155.Parent then
            return;
        end;

        u155.Size = UDim2.fromScale(1.5, 0.19);
        u155.Position = UDim2.fromScale(0.5, 0.74);
        TweenService:Create(u155, TweenInfo.new(0.3, Enum.EasingStyle.Back, Enum.EasingDirection.Out), {
            TextTransparency = 0,
            TextStrokeTransparency = 0.3,
            Size = UDim2.fromScale(0.9, 0.11),
            Position = UDim2.fromScale(0.5, 0.78)
        }):Play();
    end);
    task.delay(u124.CHARGE + u124.FREEZE, function() -- Line: 1279
        -- upvalues: u156 (ref)
        if u156 and u156.IsPlaying then
            u156:AdjustSpeed(1);
        end;
    end);
    task.wait(u139);
    local TweenInfo_new_ret3 = TweenInfo.new(u124.FADE, Enum.EasingStyle.Quad, Enum.EasingDirection.Out);
    TweenService:Create(Frame2, TweenInfo_new_ret3, {
        BackgroundTransparency = 1
    }):Play();

    for _, descendant in ipairs(Frame2:GetDescendants()) do
        if descendant:IsA("Frame") then
            TweenService:Create(descendant, TweenInfo_new_ret3, {
                BackgroundTransparency = 1
            }):Play();
        elseif descendant:IsA("ViewportFrame") then
            TweenService:Create(descendant, TweenInfo_new_ret3, {
                ImageTransparency = 1
            }):Play();
        elseif descendant:IsA("TextLabel") then
            TweenService:Create(descendant, TweenInfo_new_ret3, {
                TextTransparency = 1,
                TextStrokeTransparency = 1
            }):Play();
        end;
    end;

    task.wait(u124.FADE + 0.05);
    Frame2:Destroy();
end;

local function processStageQueue() -- Line: 1301
    -- upvalues: u126 (ref), u125 (copy), runStageCinematic (copy), processStageQueue (copy)
    if u126 then
        return;
    end;

    local table_remove_ret = table.remove(u125, 1);

    if not table_remove_ret then
        return;
    end;

    u126 = true;
    task.spawn(function() -- Line: 1306
        -- upvalues: runStageCinematic (ref), table_remove_ret (copy), u126 (ref), processStageQueue (ref)
        local success, result = pcall(runStageCinematic, table_remove_ret);

        if not success then
            warn("[BossBar] stage cinematic: " .. tostring(result));
        end;

        u126 = false;
        processStageQueue();
    end);
end;

local function queueStageCinematic(p165) -- Line: 1314
    -- upvalues: u125 (copy), u126 (ref), runStageCinematic (copy), processStageQueue (copy)
    table.insert(u125, p165);

    if u126 then
        return;
    end;

    local table_remove_ret = table.remove(u125, 1);

    if not table_remove_ret then
        return;
    end;

    u126 = true;
    task.spawn(function() -- Line: 1306
        -- upvalues: runStageCinematic (ref), table_remove_ret (copy), u126 (ref), processStageQueue (ref)
        local success, result = pcall(runStageCinematic, table_remove_ret);

        if not success then
            warn("[BossBar] stage cinematic: " .. tostring(result));
        end;

        u126 = false;
        processStageQueue();
    end);
end;

BossifyRemote.OnClientEvent:Connect(function(p166) -- Line: 1323
    -- upvalues: showBoss (copy), removeEntry (copy), u21 (copy), u18 (copy), startBossMusic (copy), LocalPlayer (copy), u70 (ref), u72 (ref), u73 (ref), TweenService (copy), applyStageColor (copy), u125 (copy), u126 (ref), runStageCinematic (copy), processStageQueue (copy), playCinematic (copy), buildAbilityIcon (copy), u71 (ref), Color3_fromRGB_ret4 (copy), Color3_fromRGB_ret5 (copy), Color3_fromRGB_ret2 (copy)
    if type(p166) ~= "table" then
        return;
    end;

    local Action = p166.Action;

    if Action == "Show" and p166.BossPlayer then
        showBoss(p166.BossPlayer, p166.Title, p166.Stage, p166.StageCount, p166.Silent, p166.MusicId);

        return;
    end;

    if Action == "Hide" and p166.BossPlayer then
        removeEntry(p166.BossPlayer);

        if u21.owner == p166.BossPlayer then
            if u21.sound then
                u21.sound:Destroy();
            end;

            u21.sound = nil;
            u21.owner = nil;

            for i in pairs(u18) do
                startBossMusic(i);
                break;
            end;
        end;

        if p166.BossPlayer == LocalPlayer then
            u70 = false;

            if u72 then
                task.cancel(u72);
            end;

            if u73 and u73.icon.Parent then
                u73.icon:Destroy();
            end;

            u73 = nil;
        end;
    elseif Action == "StagePowerUp" and p166.BossPlayer then
        local v167 = u18[p166.BossPlayer];

        if v167 then
            v167 = v167.bar:FindFirstChild("BarStroke");
        end;

        if v167 then
            local Color = v167.Color;
            v167.Color = Color3.fromRGB(255, 214, 108);
            TweenService:Create(v167, TweenInfo.new(2.2), {
                Color = Color
            }):Play();
        end;
    else
        if Action == "StageAdvance" and p166.BossPlayer then
            local v168 = u18[p166.BossPlayer];

            if v168 then
                local StageLabel = v168.frame:FindFirstChild("StageLabel");

                if StageLabel then
                    StageLabel.Text = "Stage " .. tostring(p166.Stage or "?");
                end;

                applyStageColor(v168, p166.Stage, false);
                local BarStroke = v168.bar:FindFirstChild("BarStroke");

                if BarStroke then
                    local Color = BarStroke.Color;
                    BarStroke.Color = Color3.fromRGB(255, 214, 108);
                    TweenService:Create(BarStroke, TweenInfo.new(2.2), {
                        Color = Color
                    }):Play();
                end;
            end;

            table.insert(u125, p166);

            if u126 then
                return;
            end;

            local table_remove_ret = table.remove(u125, 1);

            if not table_remove_ret then
                return;
            end;

            u126 = true;
            task.spawn(function() -- Line: 1306
                -- upvalues: runStageCinematic (ref), table_remove_ret (copy), u126 (ref), processStageQueue (ref)
                local success, result = pcall(runStageCinematic, table_remove_ret);

                if not success then
                    warn("[BossBar] stage cinematic: " .. tostring(result));
                end;

                u126 = false;
                processStageQueue();
            end);

            return;
        end;

        if Action == "Cinematic" and p166.Bosses then
            playCinematic(p166.Bosses);

            return;
        end;

        if Action == "GrantAbility" then
            u70 = true;
            buildAbilityIcon();
            u71 = true;

            if not u73 then
                return;
            end;

            u73.cd.TextColor3 = Color3_fromRGB_ret4 or Color3_fromRGB_ret5;
            u73.key.TextColor3 = Color3_fromRGB_ret2 or Color3_fromRGB_ret5;
            u73.cd.Text = "READY";

            return;
        end;

        if Action == "AbilityUsed" then
            u71 = false;

            if u73 then
                u73.cd.TextColor3 = Color3_fromRGB_ret5;
                u73.key.TextColor3 = Color3_fromRGB_ret5;
            end;

            local u169 = p166.Cooldown or 15;

            if u72 then
                task.cancel(u72);
            end;

            u72 = task.spawn(function() -- Line: 689
                -- upvalues: u169 (copy), u73 (ref)
                local v170 = os.clock() + u169;

                while os.clock() < v170 do
                    if u73 then
                        local cd = u73.cd;
                        local v171 = v170 - os.clock();
                        local math_ceil_ret = math.ceil(v171);
                        cd.Text = tostring(math_ceil_ret);
                    end;

                    task.wait(0.25);
                end;
            end);

            return;
        end;

        if Action == "AbilityReady" then
            if u72 then
                task.cancel(u72);
            end;

            u71 = true;

            if not u73 then
                return;
            end;

            u73.cd.TextColor3 = Color3_fromRGB_ret4 or Color3_fromRGB_ret5;
            u73.key.TextColor3 = Color3_fromRGB_ret2 or Color3_fromRGB_ret5;
            u73.cd.Text = "READY";
        end;
    end;
end);