-- Decompiled with Potassium's decompiler.

local ReplicatedStorage = game:GetService("ReplicatedStorage");
local Players = game:GetService("Players");
local Modules = ReplicatedStorage:WaitForChild("Modules");
local GlobalFunctions = require(Modules.GlobalFunctions);
local VfxHandler = require(Modules.Effects.VfxHandler);
local ScaleModel = require(Modules.Shared.ScaleModel);

return {
    Fire = function(p1) -- Line: 28
        -- upvalues: VfxHandler (copy), ScaleModel (copy), GlobalFunctions (copy)
        for _, v in ipairs({ p1.Character, p1.Victim }) do
            local v2 = VfxHandler.Afterimage.New(v, {
                Duration = 3
            });

            if v2 then
                ScaleModel.ScaleCharacter({
                    MaxScale = 2,
                    Speed = 1,
                    Character = v2
                });
                local v3 = v:FindFirstChild("HumanoidRootPart") or v.PrimaryPart;
                local v4 = v3 and -v3.CFrame.LookVector * 3 + Vector3.new(0, 3, 0) or Vector3.new(0, 3, -3);

                for _, descendant in ipairs(v2:GetDescendants()) do
                    if descendant:IsA("BasePart") then
                        GlobalFunctions.Tween({
                            Instance = descendant
                        }, {
                            CFrame = descendant.CFrame + v4
                        });
                    end;
                end;
            end;
        end;
    end,

    Rebind = function(p5) -- Line: 72
        -- upvalues: Players (copy)
        local LocalPlayer = Players.LocalPlayer;
        local workspace_CurrentCamera = workspace.CurrentCamera;

        if not workspace_CurrentCamera then
            return;
        end;

        local v6 = p5.Character or LocalPlayer.Character;
        local v7 = os.clock() + 5;

        while os.clock() < v7 do
            v6 = LocalPlayer.Character or v6;
            local v8;

            if v6 then
                v8 = v6:FindFirstChildOfClass("Humanoid");
            else
                v8 = v6;
            end;

            if v8 and v6.Parent then
                workspace_CurrentCamera.CameraSubject = v8;
                workspace_CurrentCamera.CameraType = Enum.CameraType.Custom;

                return;
            end;

            task.wait();
        end;
    end
};