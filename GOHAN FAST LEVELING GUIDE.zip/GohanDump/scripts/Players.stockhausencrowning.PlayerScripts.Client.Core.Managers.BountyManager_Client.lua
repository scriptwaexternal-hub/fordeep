-- Decompiled with Potassium's decompiler.

local Players = game:GetService("Players");
game:GetService("Debris");
local ReplicatedStorage = game:GetService("ReplicatedStorage");
game:GetService("RunService");
local Assets = ReplicatedStorage.Assets;
local Modules = ReplicatedStorage:WaitForChild("Modules");
ReplicatedStorage:WaitForChild("Remotes");
local _ = Modules.Metadata;
local _ = Modules.Utility;
require(Modules.Shared.SoundManager);
require(Modules.GlobalFunctions);
local Bounty = Assets.Gui.Bounty;
local ServerRemote = ReplicatedStorage.Remotes.ServerRemote;
local LocalPlayer = Players.LocalPlayer;

return {
    ["Show Bounties"] = function(p1) -- Line: 27
        -- upvalues: LocalPlayer (copy), Bounty (copy), ServerRemote (copy)
        if LocalPlayer.PlayerGui:FindFirstChild("BountyGui") then
            return;
        end;

        local Players2 = p1.Players;
        local u2 = Bounty.BountyGui:Clone();
        u2.Parent = LocalPlayer.PlayerGui;
        local MainFrame = u2.MainFrame;
        local Exit = MainFrame.Exit;
        local ScrollingFrame = MainFrame.ScrollingFrame;

        local function Exit_Gui() -- Line: 39
            -- upvalues: u2 (copy)
            u2:Destroy();
        end;

        for _, v in pairs(Players2) do
            local Name = v.Name;
            local Race = v.Race;
            local Bounty2 = v.Bounty;
            local Player = v.Player;

            if Player ~= LocalPlayer then
                local v3 = Bounty.PlayerTemplate:Clone();
                v3.Parent = ScrollingFrame;
                local v4 = v3["Bounty Cost"];
                local v5 = v3["Bounty Race"];
                local v6 = v3["Take Bounty"];
                v3["Bounty Name"].Text = Name;
                v4.Text = "Bounty: " .. Bounty2;
                v5.Text = "Race: " .. Race;
                v6.MouseButton1Up:Once(function() -- Line: 65
                    -- upvalues: ServerRemote (ref), Player (copy), u2 (copy)
                    ServerRemote:FireServer(nil, {
                        Module = "BountyManager",
                        Action = "SetBountyTarget",
                        Target = Player.Name
                    });
                    u2:Destroy();
                end);
            end;
        end;

        Exit.MouseButton1Up:Once(function() -- Line: 78
            -- upvalues: u2 (copy)
            u2:Destroy();
        end);
    end
};