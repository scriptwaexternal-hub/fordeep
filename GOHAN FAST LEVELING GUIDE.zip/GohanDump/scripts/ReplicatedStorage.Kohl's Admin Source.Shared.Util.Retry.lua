-- Decompiled with Potassium's decompiler.

return function(p1: function, p2: number?, p3: number?, ...) -- Line: 9, Name: Retry
    local v4 = p2 or 5;
    local v5 = p3 or 2;

    for i = 1, v4 do
        local v6 = { pcall(p1, ...) };

        if v6[1] or i == v4 then
            return unpack(v6);
        end;

        task.wait(v5 ^ i);
        local _ = i;
    end;

    return false;
end;