-- Decompiled with Potassium's decompiler.

local UserInputService = game:GetService("UserInputService");
local Players = game:GetService("Players");
local RunService = game:GetService("RunService");
local CurrentCamera = game:GetService("Workspace").CurrentCamera;
local Raycast = require(script:WaitForChild("Raycast"));
local Platform = require(script.Parent:WaitForChild("Platform"));
local u1 = nil;

local function aimPoint() -- Line: 114
    -- upvalues: u1 (ref), Platform (copy), CurrentCamera (copy), UserInputService (copy)
    if u1 then
        local success, result = pcall(u1);

        if success and typeof(result) == "Vector2" then
            return result;
        end;
    end;

    if not Platform.IsTouch() then
        return UserInputService:GetMouseLocation();
    end;

    local ViewportSize = CurrentCamera.ViewportSize;

    return Vector2.new(ViewportSize.X / 2, ViewportSize.Y / 2);
end;

local u3 = {
    SetAimOverride = function(p2) -- Line: 130, Name: SetAimOverride
        -- upvalues: u1 (ref)
        u1 = p2;
    end
};
local u4 = {};
local u5 = {};
local u6 = setmetatable({}, {
    __mode = "k"
});

local function copyArray(p7) -- Line: 139
    local v8 = #p7;
    local v9 = v8;
    local v10 = 1;
    local v11 = {};

    while v10 < v8 do
        local v12 = p7[v8];
        v11[v10] = p7[v10];
        v11[v8] = v12;
        v10 = v10 + 1;
        v8 = v8 - 1;
    end;

    if v9 % 2 == 1 then
        local math_ceil_ret = math.ceil(v9 / 2);
        v11[math_ceil_ret] = p7[math_ceil_ret];
    end;

    return v11;
end;

local function castMouseRay(u13) -- Line: 153
    -- upvalues: copyArray (copy), Players (copy), aimPoint (copy), CurrentCamera (copy), Raycast (copy)
    local u14 = type(u13.TargetFilter) == "table" and copyArray(u13.TargetFilter) or { u13.TargetFilter };
    local u15 = type(u13.TargetBlackList) == "table" and copyArray(u13.TargetBlackList) or { u13.TargetBlackList };

    if u13.IgnoreCharacter then
        table.insert(u15, Players.LocalPlayer.Character);
    end;

    local v16 = aimPoint();
    local v17 = CurrentCamera:ViewportPointToRay(v16.x, v16.y, 0);
    local Ray_new_ret = Ray.new(v17.Origin, v17.Direction * 10000);
    local u18 = #u14;

    if u18 > 0 and #u15 > 0 or u13.IgnoreCheck then
        return Raycast.FindPartOnRayWithCallbackWithIgnoreList(Ray_new_ret, u15, false, u13.IgnoreWater, function(p19, p20, p21, p22) -- Line: 168
            -- upvalues: u18 (copy), u14 (copy), u13 (copy), u15 (copy), Raycast (ref)
            if not p19 then
                return Raycast.CallBackResult.Finished;
            end;

            for i = 1, u18 do
                local v23 = u14[i];

                if v23 == p19 or p19:IsDescendantOf(v23) then
                    if not (u13.IgnoreCheck and u13:IgnoreCheck(p19, p20, p21, p22)) then
                        return Raycast.CallBackResult.Finished;
                    end;

                    table.insert(u15, p19);

                    return Raycast.CallBackResult.Continue;
                end;

                local _ = i;
            end;

            if u18 <= 0 then
                if not (u13.IgnoreCheck and u13:IgnoreCheck(p19, p20, p21, p22)) then
                    return Raycast.CallBackResult.Finished;
                end;

                table.insert(u15, p19);

                return Raycast.CallBackResult.Continue;
            end;
        end);
    end;

    if u18 > 0 then
        return Raycast.FindPartOnRayWithWhiteList(Ray_new_ret, u14, false, u13.IgnoreWater);
    end;

    return Raycast.FindPartOnRayWithIgnoreList(Ray_new_ret, u15, false, u13.IgnoreWater);
end;

local function planeIntersect(p24, p25, p26, p27) -- Line: 203
    local v28 = -(p24 - p26):Dot(p27) / p25:Dot(p27);

    return p24 + v28 * p25, v28;
end;

local function getMouseScreenPos() -- Line: 209
    -- upvalues: Players (copy), UserInputService (copy)
    if Players.LocalPlayer then
        return UserInputService:GetMouseLocation() - Vector2.new(0, 36);
    end;

    return UserInputService:GetMouseLocation();
end;

local function getScreenSize() -- Line: 216
    -- upvalues: Players (copy), CurrentCamera (copy)
    if Players.LocalPlayer then
        return CurrentCamera.ViewportSize - Vector2.new(0, 72);
    end;

    return CurrentCamera.ViewportSize;
end;

function u5.TargetSurface(p29) -- Line: 225
    -- upvalues: aimPoint (copy), CurrentCamera (copy), castMouseRay (copy)
    local v30 = aimPoint();
    local v31 = CurrentCamera:ViewportPointToRay(v30.x, v30.y, 0);
    local v32, _, _, _ = castMouseRay(p29);

    if v32 and v32.ClassName ~= "Terrain" then
        local CFrame2 = v32.CFrame;
        local v33 = v32.Size / 2;
        local v34 = CFrame2:PointToObjectSpace(v31.Origin);
        local v35 = CFrame2:VectorToObjectSpace(v31.Direction);
        local v36 = next;
        local EnumItems, v37 = Enum.NormalId:GetEnumItems();

        for i, v in v36, EnumItems, v37 do
            local Vector3_FromNormalId_ret = Vector3.FromNormalId(v);
            local v38 = v34 + -(v34 - Vector3_FromNormalId_ret * v33):Dot(Vector3_FromNormalId_ret) / v35:Dot(Vector3_FromNormalId_ret) * v35;

            if Vector3_FromNormalId_ret:Dot(v35) <= 0 then
                local v39 = next;
                local EnumItems2, v40 = Enum.NormalId:GetEnumItems();
                local v41 = v;
                local v42 = i;
                local v43 = true;

                for i2, v2 in v39, EnumItems2, v40 do
                    if v42 ~= i2 then
                        local Vector3_FromNormalId_ret2 = Vector3.FromNormalId(v2);

                        if (v38 - Vector3_FromNormalId_ret2 * v33):Dot(Vector3_FromNormalId_ret2) > 0 then
                            v43 = false;
                            break;
                        end;
                    end;
                end;

                if v43 then
                    return v41;
                end;
            end;
        end;
    end;
end;

function u5.UnitRay(p44) -- Line: 260
    -- upvalues: aimPoint (copy), CurrentCamera (copy)
    local v45 = aimPoint();

    return CurrentCamera:ViewportPointToRay(v45.x, v45.y, 0);
end;

function u5.ViewSizeX(p46) -- Line: 265
    -- upvalues: Players (copy), CurrentCamera (copy)
    local v47;

    if Players.LocalPlayer then
        v47 = CurrentCamera.ViewportSize - Vector2.new(0, 72);
    else
        v47 = CurrentCamera.ViewportSize;
    end;

    return v47.x;
end;

function u5.ViewSizeY(p48) -- Line: 269
    -- upvalues: Players (copy), CurrentCamera (copy)
    local v49;

    if Players.LocalPlayer then
        v49 = CurrentCamera.ViewportSize - Vector2.new(0, 72);
    else
        v49 = CurrentCamera.ViewportSize;
    end;

    return v49.y;
end;

function u5.X(p50) -- Line: 273
    -- upvalues: Players (copy), UserInputService (copy)
    local v51;

    if Players.LocalPlayer then
        v51 = UserInputService:GetMouseLocation() - Vector2.new(0, 36);
    else
        v51 = UserInputService:GetMouseLocation();
    end;

    return v51.x;
end;

function u5.Y(p52) -- Line: 277
    -- upvalues: Players (copy), UserInputService (copy)
    local v53;

    if Players.LocalPlayer then
        v53 = UserInputService:GetMouseLocation() - Vector2.new(0, 36);
    else
        v53 = UserInputService:GetMouseLocation();
    end;

    return v53.y;
end;

function u5.Target(p54) -- Line: 281
    -- upvalues: castMouseRay (copy)
    local v55, _, _, _, _ = castMouseRay(p54);

    return v55;
end;

function u5.Origin(p56) -- Line: 286
    -- upvalues: aimPoint (copy), CurrentCamera (copy)
    local v57 = aimPoint();
    local v58 = CurrentCamera:ViewportPointToRay(v57.x, v57.y, 0);

    return CFrame.new(v58.Origin, v58.Origin + v58.Direction);
end;

function u5.Hit(p59) -- Line: 292
    -- upvalues: aimPoint (copy), CurrentCamera (copy), castMouseRay (copy)
    local v60 = aimPoint();
    local v61 = CurrentCamera:ViewportPointToRay(v60.x, v60.y, 0);
    local _, v62, _, _ = castMouseRay(p59);

    return CFrame.new(v62, v62 + v61.Direction);
end;

function u5.ViewSize(p63) -- Line: 299
    -- upvalues: Players (copy), CurrentCamera (copy)
    if Players.LocalPlayer then
        return CurrentCamera.ViewportSize - Vector2.new(0, 72);
    end;

    return CurrentCamera.ViewportSize;
end;

function u5.Position(p64) -- Line: 303
    -- upvalues: getMouseScreenPos (copy)
    return getMouseScreenPos();
end;

function u5.TargetSurfaceNormal(p65) -- Line: 307
    -- upvalues: castMouseRay (copy)
    local _, _, v66, _, _ = castMouseRay(p65);

    return v66;
end;

function u5.TargetMaterial(p67) -- Line: 312
    -- upvalues: castMouseRay (copy)
    local _, _, _, v68, _ = castMouseRay(p67);

    return v68;
end;

function u4.__index(p69, p70) -- Line: 319
    -- upvalues: u3 (copy), u6 (copy), u5 (copy)
    local v71 = p70:sub(1, 1):upper() .. p70:sub(2);

    if u3[v71] then
        return u3[v71];
    end;

    if u6[p69].ReadOnly[v71] then
        return u6[p69].ReadOnly[v71];
    end;

    if u5[v71] then
        return u5[v71](p69);
    end;

    error(v71 .. " is not a valid member of Mouse");
end;

function u4.__tostring() -- Line: 333
    return "Mouse";
end;

u4.__metatable = false;

function u3.new() -- Line: 341
    -- upvalues: UserInputService (copy), RunService (copy), u6 (copy), u4 (copy)
    local v72 = {
        TargetFilter = {},
        TargetBlackList = {},
        IgnoreCharacter = true,
        IgnoreWater = false
    };
    local v73 = {};
    local BindableEvent = Instance.new("BindableEvent");
    local BindableEvent2 = Instance.new("BindableEvent");
    local BindableEvent3 = Instance.new("BindableEvent");
    local BindableEvent4 = Instance.new("BindableEvent");
    local BindableEvent5 = Instance.new("BindableEvent");
    local BindableEvent6 = Instance.new("BindableEvent");
    local BindableEvent7 = Instance.new("BindableEvent");
    local BindableEvent8 = Instance.new("BindableEvent");
    local BindableEvent9 = Instance.new("BindableEvent");
    local BindableEvent10 = Instance.new("BindableEvent");
    table.insert(v73, UserInputService.InputBegan:Connect(function(p74, p75) -- Line: 366
        -- upvalues: BindableEvent (copy), BindableEvent3 (copy), BindableEvent5 (copy)
        if p75 then
            return;
        end;

        if p74.UserInputType == Enum.UserInputType.MouseButton1 then
            BindableEvent:Fire();

            return;
        end;

        if p74.UserInputType == Enum.UserInputType.MouseButton2 then
            BindableEvent3:Fire();

            return;
        end;

        if p74.UserInputType == Enum.UserInputType.MouseButton3 then
            BindableEvent5:Fire();
        end;
    end));
    table.insert(v73, UserInputService.InputEnded:Connect(function(p76, p77) -- Line: 378
        -- upvalues: BindableEvent2 (copy), BindableEvent4 (copy), BindableEvent6 (copy)
        if p77 then
            return;
        end;

        if p76.UserInputType == Enum.UserInputType.MouseButton1 then
            BindableEvent2:Fire();

            return;
        end;

        if p76.UserInputType == Enum.UserInputType.MouseButton2 then
            BindableEvent4:Fire();

            return;
        end;

        if p76.UserInputType == Enum.UserInputType.MouseButton3 then
            BindableEvent6:Fire();
        end;
    end));
    table.insert(v73, UserInputService.InputChanged:Connect(function(p78, p79) -- Line: 390
        -- upvalues: BindableEvent8 (copy), BindableEvent10 (copy), BindableEvent9 (copy)
        if p79 then
            return;
        end;

        if p78.UserInputType == Enum.UserInputType.MouseMovement then
            BindableEvent8:Fire();

            return;
        end;

        if p78.UserInputType == Enum.UserInputType.MouseWheel then
            if p78.Position.z > 0 then
                BindableEvent10:Fire();

                return;
            end;

            BindableEvent9:Fire();
        end;
    end));
    local MouseLocation = UserInputService:GetMouseLocation();
    table.insert(v73, RunService.Heartbeat:Connect(function() -- Line: 405
        -- upvalues: UserInputService (ref), MouseLocation (ref), BindableEvent7 (copy)
        local MouseLocation2 = UserInputService:GetMouseLocation();

        if MouseLocation2 == MouseLocation then
            BindableEvent7:Fire();
        end;

        MouseLocation = MouseLocation2;
    end));
    u6[v72] = {
        MouseIgnoreCheck = nil,
        ReadOnly = {
            Button1Down = BindableEvent.Event,
            Button1Up = BindableEvent2.Event,
            Button2Down = BindableEvent3.Event,
            Button2Up = BindableEvent4.Event,
            Button3Down = BindableEvent5.Event,
            Button3Up = BindableEvent6.Event,
            Idle = BindableEvent7.Event,
            Move = BindableEvent8.Event,
            WheelBackward = BindableEvent9.Event,
            WheelForward = BindableEvent10.Event
        },
        MouseEvents = v73,
        BindableEvents = {
            BindableEvent,
            BindableEvent2,
            BindableEvent3,
            BindableEvent4,
            BindableEvent5,
            BindableEvent6,
            BindableEvent7,
            BindableEvent8,
            BindableEvent9,
            BindableEvent10
        }
    };

    return setmetatable(v72, u4);
end;

function u3.IgnoreCheck(p80, p81, p82, p83, p84) -- Line: 439
    return false;
end;

function u3.Destroy(p85) -- Line: 443
    -- upvalues: u6 (copy)
    local v86 = u6[p85];
    local MouseEvents = v86.MouseEvents;
    local BindableEvents = v86.BindableEvents;

    for i = 1, #MouseEvents do
        MouseEvents[i]:Disconnect();
        local _ = i;
    end;

    for i = 1, #BindableEvents do
        BindableEvents[i]:Destroy();
        local _ = i;
    end;
end;

return u3;