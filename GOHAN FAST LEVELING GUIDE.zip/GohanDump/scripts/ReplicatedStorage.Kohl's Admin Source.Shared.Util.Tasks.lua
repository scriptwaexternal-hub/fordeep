-- Decompiled with Potassium's decompiler.

local u1 = {};
u1.__index = u1;

function u1.new() -- Line: 17
    -- upvalues: u1 (copy)
    local v2 = {
        _numTasks = 0,
        _returnFirstResult = false,
        _waiting = false,
        _results = {},
        _running = coroutine.running()
    };

    return setmetatable(v2, u1);
end;

local function _run(p3: any, p4: function, ...) -- Line: 27
    local v5 = { pcall(p4, ...) };
    p3._numTasks = p3._numTasks - 1;

    if p3._waiting then
        if not v5[1] then
            warn("Tasks: Task failed with error:", v5[2]);
        end;

        table.insert(p3._results, v5);

        if p3._returnFirstResult or p3._numTasks == 0 then
            p3._waiting = false;

            if coroutine.status(p3._running) == "suspended" then
                if not p3._returnFirstResult then
                    v5 = p3._results;
                end;

                task.spawn(p3._running, v5);
            end;
        end;
    end;
end;

function u1.add(p6: any, p7: function, ...) -- Line: 46
    -- upvalues: _run (copy)
    local v8 = typeof(p7) == "function";
    assert(v8, "Callback must be a function");
    p6._numTasks = p6._numTasks + 1;
    task.defer(_run, p6, p7, ...);
end;

function u1.wait(p9) -- Line: 53
    if p9._numTasks > 0 then
        p9._waiting = true;

        return coroutine.yield();
    end;
end;

function u1.waitForFirst(p10) -- Line: 62
    p10._returnFirstResult = true;

    return unpack(p10:wait());
end;

return u1;