-- Decompiled with Potassium's decompiler.

local UI = require(script.Parent:WaitForChild("UI"));
local v1 = {
    _K = nil
};
v1.__index = v1;

function v1.new(u2) -- Line: 8
    -- upvalues: UI (copy)
    local u3 = nil;
    local u4 = {};
    local u5 = {};

    local function resetChanges() -- Line: 13
        -- upvalues: u4 (copy), u2 (copy), u5 (copy)
        for i, v in u4 do
            u2.Data.savedSettings[i] = v;

            if u2.client.settings[i] then
                u2.client.settings[i](v, true);
            end;
        end;

        table.clear(u4);
        table.clear(u5);
    end;

    local function confirmChanges() -- Line: 24
        -- upvalues: u2 (copy), u5 (copy), u4 (copy)
        u2.Remote.Settings:Fire(u5);

        for i, v in u5 do
            u2.Data.savedSettings[i] = v;

            if u2.client.settings[i] then
                u2.client.settings[i](v, true);
            end;
        end;

        table.clear(u4);
        table.clear(u5);
    end;

    local function change(p6, p7, p8, p9) -- Line: 36
        -- upvalues: UI (ref), u2 (copy), u4 (copy), u5 (copy), u3 (ref), change (copy)
        if p8 == nil and string.find(p6, "theme", 1, true) == 1 then
            p8 = UI.Theme[string.sub(p6, 6)];
        end;

        if not u2.ready or u2.Util.Table.deepCompare(p7, UI.raw(p8)) then
            return;
        end;

        if u4[p6] == p7 then
            u5[p6] = nil;
        elseif u2.Data.savedSettings[p6] ~= p7 then
            u5[p6] = p7;

            if not u4[p6] then
                local v10 = u2.Data.savedSettings[p6];

                if type(v10) == "table" then
                    v10 = table.clone(v10);
                end;

                u4[p6] = v10;
            end;
        end;

        if p8 then
            p8(p7);
        end;

        local theme = u2.Data.savedSettings.theme;
        local v11 = UI.Themes[theme];
        local v12 = false;
        local v13 = false;

        for i, v in u5 do
            v13 = v11 and (i ~= "theme" and (string.find(i, "theme", 1, true) == 1 and UI.raw(v11[string.sub(i, 6)]) ~= v)) and true or v13;

            if v ~= u4[i] then
                v12 = true;
            end;
        end;

        if u3 then
            u3._instance.Visible = v12;
        end;

        if p6 == "theme" or (string.find(p6, "theme", 1, true) ~= 1 or p9) then
            if p6 == "theme" then
                local v14 = UI.Themes[p7];

                if v14 then
                    u2.Data.savedSettings.theme = p7;

                    for i, v in v14 do
                        local v15 = "theme" .. i;
                        local v16 = u2.Data.savedSettings[v15];

                        if v16 ~= nil and v16 ~= UI.raw(v) then
                            change(v15, UI.raw(v), nil, true);
                        end;
                    end;
                end;

                u2.client.settings.theme(p7);
            end;
        else
            local v17 = v13 and "Custom (DataStore)" or theme;

            if u5.theme ~= v17 then
                change("theme", v17);
            end;
        end;
    end;

    local u18 = {
        announcement = true,
        announcements = true,
        notifications = true,
        freeAdmin = true,
        prefix = true
    };
    local u19 = UI.new("Scroller")({ UI.new("UIFlexItem")({
            FlexMode = Enum.UIFlexMode.Fill
        }), UI.new("Button")({
            LayoutOrder = 2147483647,
            Label = "Restore Default Settings",
            BackgroundColor3 = UI.Theme.Invalid,
            Visible = u2.client.settings.useSavedSettings,

            Activated = function() -- Line: 122, Name: Activated
                -- upvalues: u2 (copy), u18 (copy), change (copy)
                for i, v in u2.Data.defaultSettings do
                    if not u18[i] and u2.Data.savedSettings[i] ~= v then
                        change(i, v);

                        if u2.client.settings[i] then
                            u2.client.settings[i](v);
                        end;
                    end;
                end;
            end
        }) });
    local u20 = UI.compute(function() -- Line: 135
        -- upvalues: UI (ref)
        return UI.Theme.FontSize() + UI.Theme.Padding().Offset;
    end);
    local u21 = UI.compute(function() -- Line: 139
        -- upvalues: u20 (copy)
        return UDim2.new(0, 0, 0, u20());
    end);
    local u22 = {
        Name = "Appearance"
    };
    local table_clone_ret = table.clone(u2.Data.rolesList);
    local u23 = {
        _rank = false,
        name = "Disabled"
    };
    table.insert(table_clone_ret, u23);

    local function rankItem(u24: string, p25: string, p26: string, u27: any) -- Line: 149
        -- upvalues: UI (ref), u2 (copy), u23 (copy), table_clone_ret (copy), change (copy)
        return UI.new("ListItem")({
            Text = p25,
            Tooltip = p26,
            UI.new("Select")({
                Value = function() -- Line: 154, Name: Value
                    -- upvalues: u2 (ref), u24 (copy), u23 (ref)
                    local v28 = u2.client.settings[u24]();

                    if v28 then
                        return u2.Auth.getRoleFromRank(v28);
                    end;

                    return u23;
                end,

                Choices = table_clone_ret,
                [UI.Hook] = {
                    Value = function(p29) -- Line: 160, Name: Value
                        -- upvalues: change (ref), u24 (copy), u2 (ref), u27 (copy)
                        change(u24, p29._rank, u2.client.settings[u24]);

                        if u27 then
                            u27();
                        end;
                    end
                }
            })
        });
    end;

    local function switchItem(u30: string, p31: string, p32: string?) -- Line: 171
        -- upvalues: UI (ref), u2 (copy), change (copy)
        return UI.new("ListItem")({
            Text = p31,
            Tooltip = p32,
            UI.new("Switch")({
                Value = function() -- Line: 176, Name: Value
                    -- upvalues: u2 (ref), u30 (copy)
                    return u2.client.settings[u30]();
                end,

                [UI.Hook] = {
                    Value = function(p33) -- Line: 180, Name: Value
                        -- upvalues: change (ref), u30 (copy), u2 (ref)
                        change(u30, p33, u2.client.settings[u30]);
                    end
                }
            })
        });
    end;

    local function _sliderItem(u34: string, p35: string, p36: string?) -- Line: 188
        -- upvalues: UI (ref), u2 (copy), change (copy)
        return UI.new("ListItem")({
            Text = p35,
            Tooltip = p36,
            UI.new("Slider")({
                Value = function() -- Line: 193, Name: Value
                    -- upvalues: u2 (ref), u34 (copy)
                    return u2.client.settings[u34]();
                end,

                [UI.Hook] = {
                    Value = function(p37) -- Line: 197, Name: Value
                        -- upvalues: change (ref), u34 (copy), u2 (ref)
                        change(u34, p37, u2.client.settings[u34]);
                    end
                }
            })
        });
    end;

    local u38 = {};
    local u39 = { ",", " ", "`", "\"", "@", "$", "%", "*", "~" };
    local u49 = {
        {
            Name = "Admin",
            UI.new("ListItem")({
                Text = "Command Prefix",
                Tooltip = "The character to trigger a command.",
                UI.new("Input")({
                    FontFace = UI.Theme.FontMono,
                    FontSize = UI.Theme.FontSize,
                    Size = u21,
                    Placeholder = ";",
                    MaxChars = 1,

                    Value = function() -- Line: 219, Name: Value
                        -- upvalues: u2 (copy)
                        return u2.client.settings.prefix()[1];
                    end,

                    Validate = function(p40) -- Line: 222, Name: Validate
                        -- upvalues: u39 (copy)
                        return not (p40 == "" and true or table.find(u39, p40));
                    end,

                    [UI.Hook] = {
                        Value = function(p41) -- Line: 227, Name: Value
                            -- upvalues: u2 (copy), change (copy)
                            if p41 == u2.client.settings.prefix()[1] then
                                return;
                            end;

                            u2.client.settings.prefix._value[1] = p41;
                            change("prefix", { p41, unpack(u2.client.settings.prefix._value, 2) });
                        end
                    }
                })
            }),
            UI.new("ListItem")({
                Text = "Free Admin",
                Tooltip = "🚨 Role given to every player who joins",
                UI.new("Select")({
                    Value = function() -- Line: 241, Name: Value
                        -- upvalues: u2 (copy), u23 (copy)
                        local v42 = u2.client.settings.freeAdmin();

                        if type(v42) == "table" and v42[1] then
                            return u2.Data.roles[v42[1]];
                        end;

                        return u23;
                    end,

                    Choices = table_clone_ret,
                    [UI.Hook] = {
                        Value = function(p43) -- Line: 249, Name: Value
                            -- upvalues: u38 (copy), u2 (copy), u23 (copy), change (copy)
                            local _key = p43._key;
                            local v44 = u38[_key];

                            if not v44 then
                                v44 = { _key };

                                if _key ~= nil then
                                    u38[_key] = v44;
                                end;
                            end;

                            local v45 = u2.client.settings.freeAdmin();
                            local v46;

                            if type(v45) == "table" and v45[1] then
                                v46 = u2.Data.roles[v45[1]];
                            else
                                v46 = u23;
                            end;

                            if _key == v46._key then
                                return;
                            end;

                            change("freeAdmin", v44);
                            u2.client.settings.freeAdmin(u2.Util.Table.merge(table.clone(u2.Data.defaultSettings.freeAdmin), v44));
                        end
                    }
                })
            }),
            rankItem("commandBarRank", "Command Bar Rank", "Minimum role to use the Command Bar"),
            rankItem("dashboardRank", "Dashboard Rank", "Minimum role to use the Dashboard", function() -- Line: 277
                -- upvalues: u2 (copy)
                if u2.client.settings.dashboardRank() == false then
                    u2.Process.runCommands(u2, u2.LocalPlayer.UserId, ";settings");
                end;
            end),
            rankItem("commandsButtonRank", "Commands Button Rank", "Minimum role to show the Commands Button"),
            rankItem("dashboardButtonRank", "Dashboard Button Rank", "Minimum role to show the Dashboard Button"),
            rankItem(
                "joinNotificationRank",
                "Join Notification Rank",
                "Minimum role to show the default join notification"
            ),
            switchItem(
                "addToCharts",
                "Add Game to Charts",
                "Adds the game to a list of games using Kohl\'s Admin, check About for details."
            ),
            switchItem(
                "vip",
                "Global VIP Features",
                "Toggles VIP features for the admin.\n<b>Required if game is added to charts!</b>"
            ),
            switchItem("chatCommands", "Chat Commands", "Toggle commands via chat"),
            switchItem(
                "chatCommandsNotification",
                "Chat Commands Notification",
                "Shows users a notification to purchase VIP (non-abusable) chat commands on join, 40% of the purchase goes to the game creator."
            ),
            switchItem("commandRequests", "Command Requests", "Toggle commands requests on same or higher rank users"),
            switchItem("onlyShowUsableCommands", "Only Show Usable Commands", "Show only purchasable/usable commands"),
            switchItem(
                "getKohlsAdminPopup",
                "Get Kohl\'s Admin Popup",
                "Shows users a popup after using a few commands to get the Kohl\'s Admin model"
            ),
            switchItem("wrongPrefixWarning", "Wrong Prefix Warning", "Warns users when the wrong command prefix is used"),
            switchItem("saveLogs", "Save Logs", "Toggle the saving and syncing of logs across servers"),
            switchItem("saveChatLogs", "Save Chat Logs", "Toggle the saving and syncing of chat logs across servers"),
            switchItem(
                "saveLogsForAllRoles",
                "Save Logs For All Roles",
                "Toggle the saving and syncing of command logs for all roles, instead of only logging non-purchasable restricted roles"
            )
        },
        {
            Name = "Local",
            UI.new("ListItem")({
                Text = "Custom Command Prefix",
                Tooltip = "A custom character to trigger a command, only affects the client.",
                UI.new("Input")({
                    FontFace = UI.Theme.FontMono,
                    FontSize = UI.Theme.FontSize,
                    Size = u21,
                    Placeholder = ";",
                    MaxChars = 1,

                    Value = function() -- Line: 337, Name: Value
                        -- upvalues: u2 (copy)
                        return u2.client.playerPrefix() or u2.client.settings.prefix()[1];
                    end,

                    Validate = function(p47) -- Line: 340, Name: Validate
                        -- upvalues: u39 (copy)
                        return not (p47 == "" and true or table.find(u39, p47));
                    end,

                    [UI.Hook] = {
                        Value = function(p48) -- Line: 345, Name: Value
                            -- upvalues: u2 (copy)
                            if p48 == u2.client.playerPrefix() then
                                return;
                            end;

                            u2.client.playerPrefix(p48);
                            u2.Remote.PlayerPrefix:Fire(p48);
                        end
                    }
                })
            }),
            UI.new("ListItem")({
                Text = "Command Bar Hotkey",
                Tooltip = "The keyboard shortcut to open the command bar.",
                UI.new("Input")({
                    Placeholder = ";",
                    HotkeyInput = true,
                    FontFace = UI.Theme.FontMono,
                    FontSize = UI.Theme.FontSize,
                    Size = u21,
                    Value = UI.UserInputService:GetStringForKeyCode(u2.client.hotkeys.commandBar.key._value),
                    Hotkey = u2.client.hotkeys.commandBar.key,
                    Modifiers = u2.client.hotkeys.commandBar.mods
                })
            }),
            UI.new("ListItem")({
                Text = "Dashboard Hotkey",
                Tooltip = "The keyboard shortcut to open the dashboard.",
                UI.new("Input")({
                    Placeholder = "\'",
                    HotkeyInput = true,
                    FontFace = UI.Theme.FontMono,
                    FontSize = UI.Theme.FontSize,
                    Size = u21,
                    Value = UI.UserInputService:GetStringForKeyCode(u2.client.hotkeys.dashboard.key._value),
                    Hotkey = u2.client.hotkeys.dashboard.key,
                    Modifiers = u2.client.hotkeys.dashboard.mods
                })
            })
        },
        u22,
        {
            Name = "Sound",
            switchItem("themeSoundEnabled", "UI Sounds"),
            switchItem("themeTypingSounds", "Typing sounds"),
            switchItem("themeTypingSoundsOnEveryTextBox", "Typing sounds on every TextBox")
        }
    };
    task.defer(function() -- Line: 395
        -- upvalues: u2 (copy), UI (ref), u22 (copy), change (copy), u19 (copy), u21 (copy), switchItem (copy), u49 (copy)
        u2.Util.Defer.reset();
        local v51 = UI.compute(function() -- Line: 399
            -- upvalues: UI (ref)
            local v50 = {};

            for i in UI.Themes do
                table.insert(v50, i);
            end;

            table.sort(v50);
            table.insert(v50, "Custom (DataStore)");

            return v50;
        end);
        local ListItem = UI.new("ListItem");
        local v53 = {
            Text = "Theme",
            Tooltip = "Changes the theme of Kohl\'s Admin interfaces.",
            UI.new("Select")({
                Value = function() -- Line: 414, Name: Value
                    -- upvalues: u2 (ref)
                    return u2.client.settings.theme();
                end,

                Choices = v51,
                [UI.Hook] = {
                    Value = function(p52) -- Line: 419, Name: Value
                        -- upvalues: change (ref)
                        change("theme", p52);
                    end
                }
            })
        };
        table.insert(u22, ListItem(v53));
        local u54 = {
            Font = nil,
            FontMono = nil
        };

        for _, v in { "Font", "FontMono" } do
            u54[v] = UI.new("ListItem")({
                Text = v:gsub("(.)(%u)", "%1 %2"),
                UI.new("TextLabel")({
                    BackgroundTransparency = 1,
                    Text = "Loading Fonts...",
                    AutomaticSize = Enum.AutomaticSize.XY,
                    FontFace = UI.Theme[v],
                    TextColor3 = UI.Theme.PrimaryText,
                    TextSize = UI.Theme.FontSize,
                    TextTransparency = UI.Theme.TransparencyBalanced
                })
            });
            table.insert(u22, u54[v]);
        end;

        task.defer(function() -- Line: 446
            -- upvalues: u2 (ref), UI (ref), u54 (copy), change (ref)
            while true do
                local v55 = u2.client.dashboard.Tabs and u2.client.dashboard.Tabs.CurrentPage._value == u2.client.dashboard.Settings._instance;
                local v56 = u2.client.dashboard.Settings._instance.Parent and not u2.client.dashboard.Settings._instance:IsDescendantOf(u2.client.dashboard.Tabs._content);

                if v55 or v56 then
                    local u57 = {
                        16658246179,
                        Enum.Font.Code,
                        12187606783,
                        Enum.Font.Arcade,
                        Enum.Font.RobotoMono,
                        12187371840,
                        12187362578
                    };
                    local u58 = {};

                    for i in UI.Fonts do
                        local Font_fromId = Font.fromId;
                        local v59 = tonumber(i);
                        table.insert(u58, Font_fromId(v59));
                    end;

                    for i, v in u57 do
                        local v60;

                        if type(v) == "number" then
                            v60 = Font.fromId(v);
                        else
                            v60 = Font.fromEnum(v);
                        end;

                        u57[i] = v60;
                    end;

                    for _, v in Enum.Font:GetEnumItems() do
                        if v.Name ~= "Unknown" then
                            table.insert(u58, Font.fromEnum(v));
                        end;
                    end;

                    table.sort(u58, function(p61, p62) -- Line: 480
                        -- upvalues: UI (ref)
                        return UI.getFontName(p61) < UI.getFontName(p62);
                    end);
                    task.spawn(function() -- Line: 484
                        -- upvalues: UI (ref), u58 (copy), u57 (copy), u54 (ref), u2 (ref), change (ref)
                        local Frame = Instance.new("Frame");
                        Frame.BackgroundTransparency = 1;
                        Frame.Parent = UI.LayerTop;

                        for _, v in { "Font", "FontMono" } do
                            task.spawn(function() -- Line: 490
                                -- upvalues: v (copy), u58 (ref), u57 (ref), u54 (ref), Frame (copy), u2 (ref), UI (ref), change (ref)
                                local v63;

                                if v == "Font" then
                                    v63 = u58;
                                else
                                    v63 = u57;
                                end;

                                local v64;

                                if v == "Font" then
                                    v64 = u54.Font;
                                else
                                    v64 = u54.FontMono;
                                end;

                                local TextLabel = v64._content.TextLabel;
                                local v65 = {};

                                for i = 1, #v63, 8 do
                                    local v66 = i;

                                    for i2 = 1, 8 do
                                        local v67 = v63[v66 + i2];

                                        if not v67 then
                                            break;
                                        end;

                                        local TextLabel2 = Instance.new("TextLabel");
                                        TextLabel2.BackgroundTransparency = 1;
                                        TextLabel2.TextTransparency = 1;
                                        TextLabel2.FontFace = v67;
                                        TextLabel2.Parent = Frame;
                                        v65[i2] = TextLabel2;
                                        local _ = i2;
                                    end;

                                    TextLabel.Text = `Loading fonts... {v66}/{#v63}`;
                                    u2.Service.ContentProvider:PreloadAsync(v65);
                                end;

                                table.clear(v65);
                                UI.new("Select")({
                                    Parent = u54[v],
                                    FontFace = UI.Theme[v],

                                    Value = function() -- Line: 516, Name: Value
                                        -- upvalues: UI (ref), v (ref)
                                        return UI.Theme[v]();
                                    end,

                                    Choices = v63,
                                    [UI.Hook] = {
                                        Value = function(p68) -- Line: 521, Name: Value
                                            -- upvalues: change (ref), v (ref)
                                            change("theme" .. v, p68);
                                        end
                                    }
                                });
                                TextLabel:Destroy();

                                if v == "Font" then
                                    Frame:Destroy();
                                end;
                            end);
                        end;
                    end);

                    return;
                end;

                task.wait();
            end;
        end);
        u2.Util.Defer.wait();
        local u69 = nil;
        local u70 = 0;
        u19._instance:GetPropertyChangedSignal("AbsoluteCanvasSize"):Connect(function() -- Line: 540
            -- upvalues: u69 (ref), u19 (ref), u70 (ref)
            if not u69 then
                return;
            end;

            local v71 = u69.AbsolutePosition.Y + u69.AbsoluteSize.Y / 2;
            local v72;

            if u19._instance.CanvasPosition.Y > 0 then
                v72 = v71 - u70;
                local _instance = u19._instance;
                _instance.CanvasPosition = _instance.CanvasPosition + Vector2.new(0, v72);
            else
                v72 = 0;
            end;

            u70 = v71 - v72;
        end);
        local u73 = nil;
        u73 = UI.new("Slider")({
            Snap = 25,

            Value = function() -- Line: 556, Name: Value
                -- upvalues: UI (ref)
                local v74 = UI.Theme.FontSize() - 7;

                return math.clamp(v74, 1, 25);
            end,

            UI.new("UIFlexItem")({
                FlexMode = Enum.UIFlexMode.Fill
            }),
            [UI.Hook] = {
                Value = function(p75) -- Line: 563, Name: Value
                    -- upvalues: UI (ref), u69 (ref), u73 (ref), u70 (ref), change (ref)
                    if p75 + 7 ~= UI.Theme.FontSize() then
                        u69 = u73._instance;
                        u70 = u69.AbsolutePosition.Y + u69.AbsoluteSize.Y / 2;
                    end;

                    change("themeFontSize", p75 + 7);
                end
            }
        });
        local v78 = UI.new("ListItem")({
            Text = "Font Size",
            UI.new("Input")({
                FontFace = UI.Theme.FontMono,
                FontSize = UI.Theme.FontSize,
                Size = u21,
                NumberOnly = true,
                NumberRange = NumberRange.new(8, 32),
                Placeholder = "",

                Value = function() -- Line: 581, Name: Value
                    -- upvalues: UI (ref)
                    return UI.Theme.FontSize();
                end,

                [UI.Hook] = {
                    Value = function(p76) -- Line: 585, Name: Value
                        -- upvalues: change (ref)
                        local v77 = tonumber(p76);

                        if not v77 then
                            return;
                        end;

                        change("themeFontSize", v77);
                    end
                }
            }),
            u73
        });
        v78._label.Size = UDim2.new(0.5, 0, 0, 0);
        table.insert(u22, v78);
        u2.Util.Defer.wait();

        for _, v in { "CornerRadius", "Padding" } do
            local u79 = nil;
            u79 = UI.new("Slider")({
                Snap = 17,

                Value = function() -- Line: 606, Name: Value
                    -- upvalues: UI (ref), v (copy)
                    local v80 = UI.Theme[v]().Offset + 1;

                    return math.clamp(v80, 1, 17);
                end,

                UI.new("UIFlexItem")({
                    FlexMode = Enum.UIFlexMode.Fill
                }),
                [UI.Hook] = {
                    Value = function(p81) -- Line: 613, Name: Value
                        -- upvalues: UI (ref), v (copy), u69 (ref), u79 (ref), u70 (ref), change (ref)
                        local v82 = UI.Theme[v]().Offset + 1;

                        if p81 == math.clamp(v82, 1, 17) then
                            return;
                        end;

                        u69 = u79._instance;
                        u70 = u69.AbsolutePosition.Y + u69.AbsoluteSize.Y / 2;
                        local UDim_new_ret = UDim.new(0, p81 - 1);
                        change("theme" .. v, UDim_new_ret);
                    end
                }
            });
            local v85 = UI.new("ListItem")({
                Text = v:gsub("(.)(%u)", "%1 %2"),
                UI.new("Input")({
                    FontFace = UI.Theme.FontMono,
                    FontSize = UI.Theme.FontSize,
                    Size = u21,
                    NumberOnly = true,
                    NumberRange = NumberRange.new(0, 16),
                    Placeholder = "",

                    Value = function() -- Line: 633, Name: Value
                        -- upvalues: UI (ref), v (copy)
                        return UI.Theme[v]().Offset;
                    end,

                    [UI.Hook] = {
                        Value = function(p83) -- Line: 637, Name: Value
                            -- upvalues: change (ref), v (copy)
                            local v84 = tonumber(p83);

                            if not v84 then
                                return;
                            end;

                            local UDim_new_ret = UDim.new(0, v84);
                            change("theme" .. v, UDim_new_ret);
                        end
                    }
                }),
                u79
            });
            v85._label.Size = UDim2.new(0.5, 0, 0, 0);
            table.insert(u22, v85);
        end;

        u2.Util.Defer.wait();
        local ListItem2 = UI.new("ListItem");
        local v88 = {
            Text = "Background Image AssetId",
            Tooltip = "Changes the Background Image of windows and dialogs.",
            UI.new("Input")({
                FontFace = UI.Theme.FontMono,
                FontSize = UI.Theme.FontSize,
                Size = u21,
                NumberOnly = true,
                NumberRange = NumberRange.new(0, (1 / 0)),
                Placeholder = "12345",

                Value = function() -- Line: 667, Name: Value
                    -- upvalues: UI (ref)
                    local string_match = string.match;
                    local v86 = UI.Theme.BackgroundImage();

                    return tonumber(string_match(v86, "(%d+)$")) or 0;
                end,

                [UI.Hook] = {
                    Value = function(p87) -- Line: 671, Name: Value
                        -- upvalues: change (ref)
                        print(p87);

                        if not tonumber(p87) then
                            return;
                        end;

                        change("themeBackgroundImage", "rbxassetid://" .. p87);
                    end
                }
            })
        };
        table.insert(u22, ListItem2(v88));
        local v89 = { Enum.ScaleType.Crop, Enum.ScaleType.Fit, Enum.ScaleType.Stretch };
        local ListItem3 = UI.new("ListItem");
        local v91 = {
            Text = "Background Image ScaleType",
            Tooltip = "Changes the ScaleType of the Background Image.",
            UI.new("Select")({
                Value = function() -- Line: 692, Name: Value
                    -- upvalues: u2 (ref)
                    return u2.client.settings.themeBackgroundImageScaleType();
                end,

                Choices = v89,
                [UI.Hook] = {
                    Value = function(p90) -- Line: 697, Name: Value
                        -- upvalues: change (ref)
                        change("themeBackgroundImageScaleType", p90);
                    end
                }
            })
        };
        table.insert(u22, ListItem3(v91));

        for _, v in { {
                key = "BackgroundImageTransparency",
                text = "Background Image Transparency"
            }, {
                key = "Transparency",
                text = "Background Transparency"
            }, {
                key = "TextStrokeTransparency",
                text = "Text Stroke Transparency"
            } } do
            local v93 = UI.new("Slider")({
                Value = function() -- Line: 716, Name: Value
                    -- upvalues: UI (ref), v (copy)
                    return UI.Theme[v.key]();
                end,

                UI.new("UIFlexItem")({
                    FlexMode = Enum.UIFlexMode.Fill
                }),
                [UI.Hook] = {
                    Value = function(p92) -- Line: 723, Name: Value
                        -- upvalues: change (ref), v (copy)
                        change("theme" .. v.key, p92);
                    end
                }
            });
            local v98 = UI.new("ListItem")({
                Text = v.text,
                UI.new("Input")({
                    FontFace = UI.Theme.FontMono,
                    FontSize = UI.Theme.FontSize,
                    Size = u21,
                    MaxChars = 5,
                    NumberOnly = true,
                    NumberRange = NumberRange.new(0, 1),
                    Placeholder = "",

                    Value = function() -- Line: 738, Name: Value
                        -- upvalues: UI (ref), v (copy)
                        local v94 = UI.Theme[v.key]();

                        return string.sub(v94, 1, 5);
                    end,

                    [UI.Hook] = {
                        Value = function(p95) -- Line: 742, Name: Value
                            -- upvalues: UI (ref), v (copy), change (ref)
                            local v96 = tonumber(p95);

                            if tonumber(p95) then
                                local v97 = v96 - UI.Theme[v.key]();

                                if math.abs(v97) >= 0.001 then
                                    change("theme" .. v.key, v96);
                                end;
                            end;
                        end
                    }
                }),
                v93
            });
            v98._label.Size = UDim2.new(0.5, 0, 0, 0);
            table.insert(u22, v98);
        end;

        for _, v in { "Border", "BackgroundGradient", "Primary", "PrimaryText", "Secondary", "SecondaryText", "Valid", "Invalid" } do
            u2.Util.Defer.wait();
            local v100 = UI.new("Color")({
                Value = function() -- Line: 773, Name: Value
                    -- upvalues: UI (ref), v (copy)
                    return UI.Theme[v]();
                end,

                [UI.Hook] = {
                    Value = function(p99) -- Line: 777, Name: Value
                        -- upvalues: change (ref), v (copy)
                        change("theme" .. v, p99);
                    end
                }
            });
            local v101 = UI.new("ListItem")({
                Text = v:gsub("(.)(%u)", "%1 %2") .. " Color",
                v100
            });

            if v == "Border" then
                v101.Text("UI Borders");
                UI.new("Tooltip")({
                    Text = "Border Color Start",
                    Parent = v100
                });
                UI.new("Switch")({
                    Parent = v101,
                    LayoutOrder = -1,

                    Value = function() -- Line: 792, Name: Value
                        -- upvalues: u2 (ref)
                        return u2.client.settings.themeStrokeEnabled();
                    end,

                    UI.new("Tooltip")({
                        Text = "Toggle UI Borders"
                    }),
                    [UI.Hook] = {
                        Value = function(p102) -- Line: 797, Name: Value
                            -- upvalues: change (ref), u2 (ref)
                            change("themeStrokeEnabled", p102, u2.client.settings.themeStrokeEnabled);
                        end
                    }
                });
                local v106 = UI.new("Input")({
                    Parent = v101,
                    LayoutOrder = 0,
                    FontFace = UI.Theme.FontMono,
                    FontSize = UI.Theme.FontSize,
                    Size = u21,
                    MaxChars = 5,
                    NumberOnly = true,
                    NumberRange = NumberRange.new(-360, 360),
                    Placeholder = "",

                    Value = function() -- Line: 812, Name: Value
                        -- upvalues: UI (ref)
                        return UI.Theme.BorderAngle();
                    end,

                    [UI.Hook] = {
                        Value = function(p103) -- Line: 816, Name: Value
                            -- upvalues: UI (ref), change (ref)
                            local v104 = tonumber(p103);

                            if tonumber(p103) then
                                local v105 = v104 - UI.Theme.BorderAngle();

                                if math.abs(v105) >= 0.001 then
                                    change("themeBorderAngle", v104);
                                end;
                            end;
                        end
                    }
                });
                UI.new("Tooltip")({
                    Text = "Border Rotation",
                    Parent = v106._displayLabel
                });
                UI.new("Color")({
                    Parent = v101,
                    LayoutOrder = 2,

                    Value = function() -- Line: 829, Name: Value
                        -- upvalues: UI (ref), v (copy)
                        return UI.Theme[v .. "Stop"]();
                    end,

                    UI.new("Tooltip")({
                        Text = "Border Color Stop"
                    }),
                    [UI.Hook] = {
                        Value = function(p107) -- Line: 834, Name: Value
                            -- upvalues: change (ref), v (copy)
                            change("theme" .. v .. "Stop", p107);
                        end
                    }
                });
            elseif v == "BackgroundGradient" then
                v101.Text("Background Gradient");
                UI.new("Tooltip")({
                    Text = "Gradient Color Start",
                    Parent = v100
                });
                UI.new("Switch")({
                    Parent = v101,
                    LayoutOrder = -1,

                    Value = function() -- Line: 845, Name: Value
                        -- upvalues: u2 (ref)
                        return u2.client.settings.themeBackgroundGradientEnabled();
                    end,

                    UI.new("Tooltip")({
                        Text = "Toggle Background Gradients"
                    }),
                    [UI.Hook] = {
                        Value = function(p108) -- Line: 850, Name: Value
                            -- upvalues: change (ref), u2 (ref)
                            change("themeBackgroundGradientEnabled", p108, u2.client.settings.themeBackgroundGradientEnabled);
                        end
                    }
                });
                local v112 = UI.new("Input")({
                    Parent = v101,
                    LayoutOrder = 0,
                    FontFace = UI.Theme.FontMono,
                    FontSize = UI.Theme.FontSize,
                    Size = u21,
                    MaxChars = 5,
                    NumberOnly = true,
                    NumberRange = NumberRange.new(-360, 360),
                    Placeholder = "",

                    Value = function() -- Line: 869, Name: Value
                        -- upvalues: UI (ref)
                        return UI.Theme.BackgroundGradientAngle();
                    end,

                    [UI.Hook] = {
                        Value = function(p109) -- Line: 873, Name: Value
                            -- upvalues: UI (ref), change (ref)
                            local v110 = tonumber(p109);

                            if tonumber(p109) then
                                local v111 = v110 - UI.Theme.BackgroundGradientAngle();

                                if math.abs(v111) >= 0.001 then
                                    change("themeBackgroundGradientAngle", v110);
                                end;
                            end;
                        end
                    }
                });
                UI.new("Tooltip")({
                    Text = "Gradient Rotation",
                    Parent = v112._displayLabel
                });
                UI.new("Color")({
                    Parent = v101,
                    LayoutOrder = 2,

                    Value = function() -- Line: 886, Name: Value
                        -- upvalues: UI (ref), v (copy)
                        return UI.Theme[v .. "Stop"]();
                    end,

                    UI.new("Tooltip")({
                        Text = "Gradient Color Stop"
                    }),
                    [UI.Hook] = {
                        Value = function(p113) -- Line: 891, Name: Value
                            -- upvalues: change (ref), v (copy)
                            change("theme" .. v .. "Stop", p113);
                        end
                    }
                });
            else
                UI.new("Tooltip")({
                    Parent = v100,
                    Text = v101.Text()
                });
            end;

            table.insert(u22, v101);
        end;

        local u114 = switchItem("useSavedSettings", "Use Saved Settings", "Toggles using saved or studio-only settings.");
        UI.edit(u114._label, {
            FontFace = UI.Theme.FontBold
        });
        UI.edit(u114, {
            LayoutOrder = -1,
            Parent = u19
        });

        for i, v in ipairs(u49) do
            u49[v.Name] = UI.new("List")(u2.Util.Table.merge({
                Collapsible = true,
                Parent = u19,
                Label = v.Name,
                Padding = UI.Theme.PaddingDouble,
                LayoutOrder = i
            }, v));
        end;

        local function updateSettingsAuth() -- Line: 919
            -- upvalues: u2 (ref), u19 (ref), u114 (copy)
            local v115 = u2.Auth.hasPermission(u2.LocalPlayer.UserId, "settings");
            local changeThemeAuthority = u2.Data.settings.changeThemeAuthority;
            local v116;

            if changeThemeAuthority == "Client" then
                v116 = true;
            elseif changeThemeAuthority == "Server" then
                v116 = v115;
            else
                v116 = false;
            end;

            u19._instance.Appearance.Visible = v116;
            local v117;

            if v115 then
                v117 = u2.client.settings.useSavedSettings._value;
            else
                v117 = v115;
            end;

            u19._instance.Admin.Visible = v117;
            u114._instance.Visible = v115;
        end;

        u2.Hook.authChanged:Connect(updateSettingsAuth);
        u2.client.settings.useSavedSettings:Connect(updateSettingsAuth);
        updateSettingsAuth();
    end);

    local function close(p118) -- Line: 932
        p118.Activated(false);
    end;

    u3 = UI.new("Dialog")({
        BackgroundTransparency = UI.Theme.TransparencyHeavy,
        BackgroundColor3 = UI.Theme.Secondary,
        AutomaticSize = Enum.AutomaticSize.Y,

        Size = function() -- Line: 940, Name: Size
            -- upvalues: UI (ref)
            return UDim2.new(1, -UI.Theme.Padding().Offset - 8, 0, 0);
        end,

        ActionText = "Save changes" .. (u2.Data.settings.changeThemeAuthority == "Server" and " and update for everyone?" or "?"),
        Action = true,
        LeftAction = true,
        RightAction = true,
        Visible = false,

        Close = function(p119) -- Line: 949, Name: Close
            -- upvalues: close (copy)
            task.defer(close, p119);
        end,

        [UI.Hook] = {
            Action = function(p120) -- Line: 954, Name: Action
                -- upvalues: u3 (ref), confirmChanges (copy), resetChanges (copy)
                u3._instance.Visible = false;

                if p120 then
                    confirmChanges();

                    return;
                end;

                resetChanges();
            end
        }
    });
    u3._content:Destroy();
    local u121 = UI.new("Input")({
        ClearTextButton = true,
        Fill = true,
        Placeholder = "Search",
        Icon = UI.Theme.Image.Search,
        IconProperties = {
            ImageColor3 = UI.Theme.PrimaryText,
            Size = UDim2.fromOffset(18, 18)
        }
    });
    u121._input:GetPropertyChangedSignal("Text"):Connect(function() -- Line: 977, Name: filterSettings
        -- upvalues: u121 (copy), u49 (copy), u19 (copy), u2 (copy)
        local string_lower_ret = string.lower(u121._input.Text);

        for _, v in ipairs(u49) do
            local v122 = u19._instance[v.Name];

            if string_lower_ret == "" then
                v122.Visible = true;

                for _, v2 in ipairs(v) do
                    v2.Text(v2._instance.Name);
                    v2._instance.Visible = true;
                end;
            else
                local string_find_ret = string.find(string.lower(v.Name), string_lower_ret, 1, true);

                if string_find_ret then
                    v122.Visible = true;
                    u49[v.Name].Collapsed(false);
                else
                    v122.Visible = false;
                end;

                local v123 = v;

                for _, v2 in ipairs(v) do
                    local Name = v2._instance.Name;
                    local string_find_ret2 = string.find(string.lower(Name), string_lower_ret, 1, true);

                    if string_find_ret2 then
                        v122.Visible = true;
                        u49[v123.Name].Collapsed(false);
                    end;

                    local v124;

                    if string_find_ret2 then
                        v124 = string.format("<font transparency=\"0.5\">%s</font><b>%s</b><font transparency=\"0.5\">%s</font>", u2.Util.String.escapeRichText((string.sub(Name, 1, string_find_ret2 - 1))), u2.Util.String.escapeRichText((string.sub(Name, string_find_ret2, string_find_ret2 + #string_lower_ret - 1))), u2.Util.String.escapeRichText((string.sub(Name, string_find_ret2 + #string_lower_ret))));
                    else
                        v124 = `<font transparency="0.5">{Name}</font>`;
                    end;

                    v2.Text(v124);
                    v2._instance.Visible = string_find_ret2 or string_find_ret;
                end;
            end;
        end;
    end);

    return {
        _instance = UI.new("Frame")({
            Name = "Settings",
            BackgroundTransparency = 1,
            Size = UDim2.new(1, 0, 1, 0),
            UI.new("UIListLayout")({
                SortOrder = Enum.SortOrder.LayoutOrder,
                Padding = UI.Theme.Padding
            }),
            u121,
            u19,
            u3
        }),
        _input = u121,
        _scroller = u19._instance
    };
end;

return v1;