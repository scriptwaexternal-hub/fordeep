-- Decompiled with Potassium's decompiler.

local Players = game:GetService("Players");
local Debris = game:GetService("Debris");
local ReplicatedStorage = game:GetService("ReplicatedStorage");
local TweenService = game:GetService("TweenService");
game:GetService("RunService");
game:GetService("UserInputService");
local Assets = ReplicatedStorage.Assets;
local Modules = ReplicatedStorage:WaitForChild("Modules");
ReplicatedStorage:WaitForChild("Remotes");
local _ = Modules.Metadata;
local Shared = Modules.Shared;
local _ = Modules.Utility;
local _ = Assets.Gui;
local SoundManager = require(Shared.SoundManager);
local GlobalFunctions = require(Modules.GlobalFunctions);
require(Shared.CamManager);
local CamShakeHandler = require(Shared.CamShakeHandler);
local workspace_World = workspace.World;
local Visuals = workspace_World.Visuals;
local _ = Assets.Effects.Particles;
local Charging = Assets.Effects.Meshes.Charging;

function Create_Rock(u1)
    -- upvalues: GlobalFunctions (copy), Visuals (copy), workspace_World (copy), Debris (copy)
    local math_random_ret = math.random(-15, 15);
    local math_random_ret2 = math.random(1, 5);
    local math_random_ret3 = math.random(-15, 15);
    local v2 = math.random(1, 100) / 100;
    local u3 = true;
    local HumanoidRootPart = u1:FindFirstChild("HumanoidRootPart");
    u1:FindFirstChild("Humanoid");

    if not HumanoidRootPart then
        return;
    end;

    local v4 = HumanoidRootPart.CFrame * CFrame.new(math_random_ret, math_random_ret2, math_random_ret3).Position;
    local v5 = GlobalFunctions.CastRay(v4, Vector3.new(0, -15, 0), { Visuals, workspace_World.Live });

    if not v5 then
        return;
    end;

    local Part = Instance.new("Part", Visuals);
    Part.CFrame = CFrame.new(v5.Position) * CFrame.new(0, -1, 0);
    Part.Material = v5.Material;
    Part.Color = v5.Instance.Color;
    Part.Size = Vector3.new(1, 1, 1) * v2;
    Part.CanCollide = false;
    Part.Orientation = Vector3.new(1, 1, 1) * math.random(1, 290);
    local Attachment = Instance.new("Attachment", Part);
    local LinearVelocity = Instance.new("LinearVelocity");
    LinearVelocity.Parent = Attachment;
    LinearVelocity.MaxForce = 1000000;
    LinearVelocity.VectorVelocity = Vector3.new(0, 4, 0);
    LinearVelocity.Attachment0 = Attachment;
    local AngularVelocity = Instance.new("AngularVelocity", Attachment);
    AngularVelocity.MaxTorque = 10000;
    AngularVelocity.AngularVelocity = Vector3.new(1, 1, 1);
    AngularVelocity.Attachment0 = Attachment;
    AngularVelocity.RelativeTo = Enum.ActuatorRelativeTo.Attachment0;
    task.delay(5, function() -- Line: 83
        -- upvalues: u3 (ref), GlobalFunctions (ref), Part (copy)
        if not u3 then
            return;
        end;

        u3 = false;
        GlobalFunctions.TransparencyTween({
            Instance = Part
        });
        game.Debris:AddItem(Part, 1);
    end);
    task.spawn(function() -- Line: 90
        -- upvalues: u1 (copy), u3 (ref), Part (copy), Attachment (copy), GlobalFunctions (ref), Debris (ref)
        while u1:FindFirstChild("Charging") do
            task.wait();
        end;

        if u3 ~= true then
            return;
        end;

        Part.CanCollide = true;
        u3 = false;
        Attachment:Destroy();
        task.delay(5, function() -- Line: 99
            -- upvalues: GlobalFunctions (ref), Part (ref), Debris (ref)
            GlobalFunctions.TransparencyTween({
                Instance = Part
            });
            Debris:AddItem(Part, 1);
        end);
    end);
end;

function Rock_Rise(p6)
    -- upvalues: CamShakeHandler (copy), SoundManager (copy)
    while p6:FindFirstChild("Charging") do
        Create_Rock(p6);
        CamShakeHandler.Shake({
            Mag = 1,
            Rou = 5
        });
        task.wait(0.1);
    end;

    for i = 1, 4 do
        SoundManager.AddSound("Rock Fall", {
            Parent = p6:FindFirstChild("HumanoidRootPart"),
            PlaybackSpeed = math.random(100, 200) / 100
        }, "Client");
        local _ = i;
    end;
end;

return {
    ["Flash Effect"] = function(p7) -- Line: 124
        -- upvalues: Assets (copy), TweenService (copy), GlobalFunctions (copy)
        local BlurEffect = Instance.new("BlurEffect");
        BlurEffect.Parent = game.Lighting;
        BlurEffect.Size = 5;
        game.Debris:AddItem(BlurEffect, 0.2);
        local u8 = Assets.Lighting["Manga Effect"]:Clone();
        u8.Parent = game.Lighting;
        game.Debris:AddItem(u8, 2);
        local v9 = TweenService:Create(u8, TweenInfo.new(0.1, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out, 0, true), {
            Brightness = 2,
            Contrast = 40,
            Saturation = -1
        });
        v9:Play();
        v9.Completed:Connect(function() -- Line: 148
            -- upvalues: u8 (copy), BlurEffect (copy), GlobalFunctions (ref)
            local v10 = {
                Duration = 0.5,
                Instance = u8,
                EasingStyle = Enum.EasingStyle.Linear
            };
            local v11 = {
                Duration = 1,
                Instance = BlurEffect,
                EasingStyle = Enum.EasingStyle.Linear
            };
            GlobalFunctions.Tween(v10, {
                Brightness = 0,
                Contrast = 0,
                Saturation = 0
            });
            GlobalFunctions.Tween(v11, {
                Size = 0
            });
        end);
    end,

    ["Change Ki Gui"] = function(p12) -- Line: 173
        -- upvalues: Players (copy), GlobalFunctions (copy)
        local Action = p12.Action;
        local KiLabel = Players:GetPlayerFromCharacter(p12.Character).PlayerGui.HUD.MainFrame.HUDisplay.HUDMAIN.KiLabel;
        local Color3_fromRGB_ret = Color3.fromRGB(255, 47, 154);
        Color3.fromRGB(255, 255, 255);
        local Color3_fromRGB_ret2 = Color3.fromRGB(255, 255, 255);
        Color3.fromRGB(0, 0, 0);
        local u13 = { KiLabel };
        ({
            On = function() -- Line: 198
                -- upvalues: u13 (copy), Color3_fromRGB_ret (copy), GlobalFunctions (ref)
                for _, v in pairs(u13) do
                    GlobalFunctions.Tween({
                        Instance = v
                    }, {
                        BackgroundColor3 = Color3_fromRGB_ret
                    });
                end;
            end,

            Off = function() -- Line: 231
                -- upvalues: u13 (copy), Color3_fromRGB_ret2 (copy), GlobalFunctions (ref)
                for _, v in pairs(u13) do
                    GlobalFunctions.Tween({
                        Instance = v
                    }, {
                        BackgroundColor3 = Color3_fromRGB_ret2
                    });
                end;
            end
        })[Action]();
    end,

    Boost = function(p14) -- Line: 262
        -- upvalues: SoundManager (copy), Assets (copy), Charging (copy)
        local Character = p14.Character;
        local v15 = p14.Color or nil;
        local HumanoidRootPart = Character:FindFirstChild("HumanoidRootPart");
        Character:FindFirstChild("Humanoid");

        if not HumanoidRootPart then
            return;
        end;

        SoundManager.AddSound("Aura Burst", {
            Name = "KiBurstBurst",
            Parent = HumanoidRootPart
        }, "Client");
        SoundManager.AddSound("Ki Burst", {
            Name = "KiBurstSound",
            Parent = HumanoidRootPart
        }, "Client");
        local u16 = Assets.Sounds.Combat.Charging["Aura Loop"]:Clone();
        u16.Parent = HumanoidRootPart;
        u16.Name = "KiBurstLoop";
        u16:Play();
        task.spawn(function() -- Line: 299
            -- upvalues: u16 (copy), Character (copy), HumanoidRootPart (copy)
            local v17 = os.clock() + 150;

            while u16.Parent and (Character.Parent and (Character:GetAttribute("State_KiBurst") ~= nil and v17 >= os.clock())) do
                task.wait(0.25);
            end;

            for _, v in ipairs({ "KiBurstLoop", "KiBurstSound", "KiBurstBurst" }) do
                local v18 = HumanoidRootPart and HumanoidRootPart:FindFirstChild(v);

                if v18 then
                    if v18:IsA("Sound") then
                        v18:Stop();
                    end;

                    v18:Destroy();
                end;
            end;
        end);
        local v19 = Charging["Ki Burst"]:Clone();
        local Attachment = Instance.new("Attachment");
        Attachment.Parent = HumanoidRootPart;
        Attachment.Name = "BoostAttachment";
        v19.Parent = Attachment;
        v19.Color = ColorSequence.new({ ColorSequenceKeypoint.new(0, v15), ColorSequenceKeypoint.new(0.5, v15), ColorSequenceKeypoint.new(1, v15) });
    end,

    ["Boost End"] = function(p20) -- Line: 382
        local Character = p20.Character;

        if not Character then
            return;
        end;

        local HumanoidRootPart = Character:FindFirstChild("HumanoidRootPart");
        Character:FindFirstChild("Humanoid");

        if not HumanoidRootPart then
            return;
        end;

        for _, descendant in pairs(Character:GetDescendants()) do
            if descendant.Name == "BoostAttachment" then
                for _, descendant2 in pairs(descendant:GetDescendants()) do
                    if descendant2:IsA("ParticleEmitter") then
                        descendant2.Enabled = false;
                    end;
                end;

                game.Debris:AddItem(descendant, 5);
            elseif descendant.Name == "KiBurstLoop" or (descendant.Name == "KiBurstSound" or descendant.Name == "KiBurstBurst") then
                if descendant:IsA("Sound") then
                    descendant:Stop();
                end;

                descendant:Destroy();
            end;
        end;
    end,

    Start = function(p21) -- Line: 410
        -- upvalues: Players (copy), SoundManager (copy), Assets (copy), Charging (copy)
        local Character = p21.Character;
        local v22 = p21.Color or nil;
        local Output = Players:GetPlayerFromCharacter(Character):FindFirstChild("PlayerStats"):FindFirstChild("Output", true);
        local HumanoidRootPart = Character:FindFirstChild("HumanoidRootPart");
        Character:FindFirstChild("Humanoid");

        if not HumanoidRootPart then
            return;
        end;

        SoundManager.AddSound("Aura Burst", {
            Parent = HumanoidRootPart
        }, "Client");
        local u23 = Assets.Sounds.Combat.Charging["Aura Loop"]:Clone();
        u23.Parent = HumanoidRootPart;
        u23:Play();

        for _, child in pairs(Charging.KiCharge:GetChildren()) do
            if child.Name == "Box" then
                local v24 = child:Clone();
                v24.Parent = HumanoidRootPart;
                v24.Name = "ChargeAttachment";
                local WeldConstraint = Instance.new("WeldConstraint");
                WeldConstraint.Part0 = v24;
                WeldConstraint.Part1 = HumanoidRootPart;
                v24.CFrame = HumanoidRootPart.CFrame;
                WeldConstraint.Parent = v24;

                for _, child2 in pairs(v24:GetChildren()) do
                    if child2:IsA("ParticleEmitter") then
                        child2.Color = ColorSequence.new({ ColorSequenceKeypoint.new(0, v22), ColorSequenceKeypoint.new(0.5, v22), ColorSequenceKeypoint.new(1, v22) });
                        task.spawn(function() -- Line: 452
                            -- upvalues: child2 (copy), u23 (copy), Output (copy)
                            local Rate = child2.Rate;

                            while u23.Parent ~= nil do
                                child2.Rate = Rate * (Output.Value / 100);
                                task.wait(0.5);
                            end;
                        end);
                    end;
                end;
            elseif child.Name == "Ground" then
                local v25 = child:Clone();
                v25.Parent = HumanoidRootPart;
                v25.Name = "ChargeAttachment";
                local WeldConstraint = Instance.new("WeldConstraint");
                WeldConstraint.Part0 = v25;
                WeldConstraint.Part1 = HumanoidRootPart;
                v25.CFrame = HumanoidRootPart.CFrame * CFrame.new(0, -2, 0);
                WeldConstraint.Parent = v25;

                for _, child2 in pairs(v25:GetChildren()) do
                    if child2:IsA("ParticleEmitter") then
                        task.spawn(function() -- Line: 477
                            -- upvalues: child2 (copy), u23 (copy), Output (copy)
                            local Rate = child2.Rate;

                            while u23.Parent ~= nil do
                                child2.Rate = Rate * (Output.Value / 100);
                                task.wait(0.5);
                            end;
                        end);
                    end;
                end;
            elseif child.Name == "Torso" then
                for _, child2 in pairs(child:GetChildren()) do
                    local v26 = child2:Clone();
                    v26.Parent = HumanoidRootPart;
                    v26.Name = "ChargeAttachment";

                    for _, child3 in pairs(v26:GetChildren()) do
                        if child3:IsA("ParticleEmitter") then
                            child3.Color = ColorSequence.new({ ColorSequenceKeypoint.new(0, v22), ColorSequenceKeypoint.new(0.5, v22), ColorSequenceKeypoint.new(1, v22) });
                            task.spawn(function() -- Line: 501
                                -- upvalues: child3 (copy), u23 (copy), Output (copy)
                                local Rate = child3.Rate;

                                while u23.Parent ~= nil do
                                    child3.Rate = Rate * (Output.Value / 100);
                                    task.wait(0.5);
                                end;
                            end);
                        end;
                    end;
                end;
            end;
        end;

        task.spawn(function() -- Line: 570
            -- upvalues: Character (copy)
            Rock_Rise(Character);
        end);
    end,

    End = function(p27) -- Line: 574
        local Character = p27.Character;

        if not Character then
            return;
        end;

        local HumanoidRootPart = Character:FindFirstChild("HumanoidRootPart");
        Character:FindFirstChild("Humanoid");

        if not HumanoidRootPart then
            return;
        end;

        for _, child in pairs(HumanoidRootPart:GetChildren()) do
            if child.Name == "ChargeAttachment" then
                for _, child2 in pairs(child:GetChildren()) do
                    if child2:IsA("ParticleEmitter") then
                        child2.Enabled = false;
                    end;
                end;

                game.Debris:AddItem(child, 2);
            elseif child.Name == "Aura Loop" or child.Name == "Decharge" then
                child:Destroy();
            end;
        end;
    end,

    DeCharge = function(p28) -- Line: 594
        -- upvalues: Charging (copy), SoundManager (copy)
        local Character = p28.Character;

        if not Character then
            return;
        end;

        local HumanoidRootPart = Character:FindFirstChild("HumanoidRootPart");
        Character:FindFirstChild("Humanoid");

        if not HumanoidRootPart then
            return;
        end;

        local u29 = Charging["Power Down"].Off:Clone();
        u29.Parent = Character:FindFirstChild("Head");
        SoundManager.AddSound("BreathOut", {
            Parent = HumanoidRootPart
        }, "Client");
        task.spawn(function() -- Line: 605
            -- upvalues: Character (copy), u29 (copy)
            while Character:GetAttribute("State_DeCharge") do
                task.wait(0.1);
            end;

            u29.PFX.Enabled = false;
            game.Debris:AddItem(u29, 2);
        end);
    end
};