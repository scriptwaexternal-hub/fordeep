-- Decompiled with Potassium's decompiler.

local Players = game:GetService("Players");
local RunService = game:GetService("RunService");
local Hook = require(script.Parent:WaitForChild("Hook"));
local Util = require(script.Parent:WaitForChild("Util"));
require(script.Parent:WaitForChild("Type"));
local u7 = {
    types = {},
    commands = {},
    commandsList = {},
    commandNames = {},

    makeEnumType = function(u1: string, u2: table) -- Line: 26, Name: makeEnumType
        -- upvalues: Util (copy)
        local u3 = Util.Suggest.new(u2);

        return {
            displayName = u1,

            validate = function(p4) -- Line: 30, Name: validate
                -- upvalues: Util (ref), u3 (copy), u1 (copy)
                return Util.Suggest.query(p4, u3)[1] ~= nil, `Invalid {u1}`;
            end,

            parse = function(p5) -- Line: 33, Name: parse
                -- upvalues: Util (ref), u3 (copy), u2 (copy)
                return Util.Suggest.query(p5, u3, u2)[1][3];
            end,

            suggestions = function(p6) -- Line: 36, Name: suggestions
                -- upvalues: u3 (copy), u2 (copy)
                return u3, u2;
            end
        };
    end
};

local function commandSort(p8, p9) -- Line: 52
    if #p8 == #p9 then
        return p8 < p9;
    end;

    return #p8 < #p9;
end;

local u10 = Util.Function.debounce(0.2, table.sort);

local function cacheCommandNames(p11) -- Line: 61
    -- upvalues: u7 (copy), u10 (copy), commandSort (copy)
    local string_lower_ret = string.lower(p11.name);

    if table.find(u7.commandNames, string_lower_ret) then
        local v12 = u7.commands[string_lower_ret];

        if v12.aliases then
            for _, v in v12.aliases do
                table.remove(u7.commandNames, table.find(u7.commandNames, v));
            end;
        end;
    else
        table.insert(u7.commandNames, string_lower_ret);
    end;

    if p11.aliases then
        for _, v in p11.aliases do
            local string_lower_ret2 = string.lower(v);
            table.insert(u7.commandNames, string_lower_ret2);
        end;
    end;

    u10(u7.commandNames, commandSort);
end;

function u7.suggestCommandAlias(p13: string) -- Line: 85
    -- upvalues: u7 (copy), Util (copy)
    local v14 = (1 / 0);
    local v15 = "";

    for _, v in u7.commandNames do
        local v16 = Util.String.levenshteinDistance(p13, v);

        if v16 < v14 then
            v15 = v;
            v14 = v16;
        end;

        if v16 == 0 then
            break;
        end;
    end;

    return v15;
end;

function u7.makeSequenceType(p17: table?) -- Line: 103
    -- upvalues: Util (copy)
    local u18 = p17 or {};
    assert(u18.parse ~= nil and true or u18.constructor ~= nil, "Must provide one of: constructor, parse");
    u18.transform = u18.transform or function(...) -- Line: 107
        return ...;
    end;
    u18.validate = u18.validate or function() -- Line: 110
        return true;
    end;

    return {
        prefixes = u18.prefixes,

        transform = function(p19) -- Line: 116, Name: transform
            -- upvalues: Util (ref), u18 (copy)
            return Util.Table.map(string.split(p19, ","), function(p20) -- Line: 117
                -- upvalues: u18 (ref)
                return u18.transform(p20);
            end);
        end,

        validate = function(p21) -- Line: 121, Name: validate
            -- upvalues: u18 (copy)
            if u18.length and #p21 > u18.length then
                return false, `Maximum of {u18.length} values allowed in sequence`;
            end;

            for i = 1, u18.Length or #p21 do
                local v22, v23 = u18.validate(p21[i], i);

                if not v22 then
                    return false, v23;
                end;

                local _ = i;
            end;

            return true;
        end,

        parse = u18.parse or function(p24) -- Line: 133
            -- upvalues: u18 (copy)
            return u18.constructor(unpack(p24));
        end
    };
end;

function u7.registerType(p25: string, p26: any, p27: any) -- Line: 140
    -- upvalues: u7 (copy)
    local v28;

    if p25 then
        v28 = typeof(p25) == "string";
    else
        v28 = p25;
    end;

    local v29 = "Invalid type name: " .. typeof(p25);
    assert(v28, v29);
    assert(u7.types[p25] == nil, "Type \"" .. p25 .. "\" already exists!");

    if p27 then
        for i, v in p27 do
            p26[i] = v;
        end;
    end;

    p26.name = p25;
    p26.displayName = p26.displayName or p25;
    u7.types[p25] = p26;
end;

function u7.registerCommand(p30, p31) -- Line: 156
    -- upvalues: u7 (copy), RunService (copy), Hook (copy), cacheCommandNames (copy)
    local string_lower_ret = string.lower(p31.name);

    if not p31.name then
        return;
    end;

    local v32 = u7.commands[string_lower_ret];

    if v32 and string.lower(v32.name) == string_lower_ret then
        print("Overriding Kohl\'s Admin command: " .. string_lower_ret);
        local table_find_ret = table.find(u7.commandsList, v32);

        if table_find_ret then
            if not p31.group then
                p31.group = v32.group;
            end;

            u7.commandsList[table_find_ret] = p31;
        end;

        if v32.aliases then
            for _, v in v32.aliases do
                u7.commands[string.lower(v)] = nil;
            end;
        end;
    elseif not v32 then
        table.insert(u7.commandsList, p31);
    end;

    p31.args = p31.args or {};

    for _, v in p31.args do
        if not u7.types[v.type] then
            if string.find(v.type, "Enum.", 1, true) == 1 then
                local type2 = v.type;
                local success, result = pcall(function() -- Line: 187
                    -- upvalues: type2 (ref)
                    return Enum[string.sub(type2, 6)];
                end);

                if not success and string.find(type2, "s$") then
                    type2 = string.sub(type2, -2);
                    success, result = pcall(function() -- Line: 193
                        -- upvalues: type2 (ref)
                        return Enum[string.sub(type2, 6)];
                    end);
                end;

                local v33 = `Invalid Enum type: {v.type}`;
                assert(success, v33);
                local v34 = u7.makeEnumType(type2, result:GetEnumItems());
                u7.registerType(type2, v34);
                u7.registerType(type2 .. "s", {
                    listable = true
                }, v34);
            elseif string.find(v.type, "%S,%S") then
                local v35 = u7.makeEnumType(v.type, string.split(v.type));
                u7.registerType(v.type, v35);
                u7.registerType(v.type .. "s", {
                    listable = true
                }, v35);
            end;
        end;
    end;

    if RunService:IsServer() and type(p31.env) == "function" then
        p31.env = p31.env(p30);
    elseif not RunService:IsServer() and type(p31.envClient) == "function" then
        p31.env = p31.envClient(p30);
    end;

    u7.commands[string_lower_ret] = p31;
    Hook.commandRegistered:Fire(p31);
    task.defer(cacheCommandNames, p31);

    if p31.aliases then
        for _, v in p31.aliases do
            local string_lower_ret2 = string.lower(v);
            local v36 = u7.commands[string_lower_ret2];
            local v37 = `"{p31.name}" command alias "{string_lower_ret2}" conflicts with "{v36 and v36.name}" command`;
            assert(not v36, v37);
            u7.commands[string_lower_ret2] = p31;
        end;
    end;
end;

local u38 = {};

function u7.registerCommandAlias(p39: any, p40: string, u41: string) -- Line: 236
    -- upvalues: u38 (copy), u7 (copy), Players (copy)
    print("command alias", p40, u41);

    if not u38[p40] and u7.commands[string.lower(p40)] then
        warn("Command alias already exists");

        return;
    end;

    print("adding command alias", p40, u41);
    u7.registerCommand(p39, {
        group = "Utility",
        name = p40,
        aliases = {},
        description = `Alias of "{u41}"`,
        args = {},

        runClient = function(p42) -- Line: 252, Name: runClient
            -- upvalues: Players (ref), u41 (copy)
            p42.Process.runCommands(p42, Players.LocalPlayer, u41);
        end
    });
end;

function u7.registerCommandModule(p43: any, p44: userdata) -- Line: 259
    -- upvalues: u7 (copy)
    local v45 = require(p44);
    local v46;

    if #v45 > 0 then
        v46 = p44.Name;
    else
        v46 = false;
    end;

    for _, v in not v46 and { v45 } or v45 do
        if not v.group then
            v.group = p44.Name;
        end;

        u7.registerCommand(p43, v);
    end;
end;

return u7;