-- Decompiled with Potassium's decompiler.

local LocalPlayer = game:GetService("Players").LocalPlayer;
local u1 = nil;

local function getControls() -- Line: 42
    -- upvalues: u1 (ref), LocalPlayer (copy)
    if u1 then
        return u1;
    end;

    local success, result = pcall(function() -- Line: 44
        -- upvalues: LocalPlayer (ref)
        local v2 = LocalPlayer:FindFirstChild("PlayerScripts") or LocalPlayer:WaitForChild("PlayerScripts", 10);

        if not v2 then
            return nil;
        end;

        local v3 = v2:FindFirstChild("PlayerModule") or v2:WaitForChild("PlayerModule", 10);

        if v3 then
            return require(v3):GetControls();
        end;

        return nil;
    end);

    if success and result then
        u1 = result;
    end;

    return u1;
end;

local u4 = false;
local u5 = nil;

local function setAutoRotate(p6, p7) -- Line: 72
    -- upvalues: u5 (ref)
    if p6 then
        p6 = p6:FindFirstChildOfClass("Humanoid");
    end;

    if not p6 then
        return;
    end;

    if p7 then
        p6.AutoRotate = true;
        u5 = nil;

        return;
    end;

    if u5 == nil then
        u5 = p6.AutoRotate;
    end;

    p6.AutoRotate = false;
end;

local function setLocked(u8) -- Line: 88
    -- upvalues: u4 (ref), u1 (ref), LocalPlayer (copy)
    if u4 == u8 then
        return;
    end;

    u4 = u8;
    local u9;

    if u1 then
        u9 = u1;
    else
        local success, result = pcall(function() -- Line: 44
            -- upvalues: LocalPlayer (ref)
            local v10 = LocalPlayer:FindFirstChild("PlayerScripts") or LocalPlayer:WaitForChild("PlayerScripts", 10);

            if not v10 then
                return nil;
            end;

            local v11 = v10:FindFirstChild("PlayerModule") or v10:WaitForChild("PlayerModule", 10);

            if v11 then
                return require(v11):GetControls();
            end;

            return nil;
        end);

        if success and result then
            u1 = result;
        end;

        u9 = u1;
    end;

    if not u9 then
        if u8 then
            warn("[BerserkLock] PlayerModule controls unavailable -- movement NOT locked");
        end;

        return;
    end;

    local success, result = pcall(function() -- Line: 100
        -- upvalues: u8 (copy), u9 (copy)
        if u8 then
            u9:Disable();

            return;
        end;

        u9:Enable();
    end);

    if not success then
        warn("[BerserkLock] control toggle failed: " .. tostring(result));

        if u8 then
            u4 = false;
        end;
    end;
end;

local function watch(u12) -- Line: 111
    -- upvalues: setLocked (copy), u5 (ref)
    if not u12 then
        return;
    end;

    local function sync() -- Line: 114
        -- upvalues: u12 (copy), setLocked (ref), u5 (ref)
        local v13 = u12:GetAttribute("State_BerserkApe") == true;
        setLocked(v13);
        local v14 = u12;

        if v14 then
            v14 = v14:FindFirstChildOfClass("Humanoid");
        end;

        if not v14 then
            return;
        end;

        if not v13 then
            v14.AutoRotate = true;
            u5 = nil;

            return;
        end;

        if u5 == nil then
            u5 = v14.AutoRotate;
        end;

        v14.AutoRotate = false;
    end;

    u12:GetAttributeChangedSignal("State_BerserkApe"):Connect(sync);
    local v15 = u12:GetAttribute("State_BerserkApe") == true;
    setLocked(v15);

    if u12 then
        u12 = u12:FindFirstChildOfClass("Humanoid");
    end;

    if not u12 then
        return;
    end;

    if not v15 then
        u12.AutoRotate = true;
        u5 = nil;

        return;
    end;

    if u5 == nil then
        u5 = u12.AutoRotate;
    end;

    u12.AutoRotate = false;
end;

LocalPlayer.CharacterAdded:Connect(function(u16) -- Line: 131
    -- upvalues: u4 (ref), u5 (ref), u1 (ref), setLocked (copy)
    u4 = false;
    u5 = nil;
    u1 = nil;

    if not u16 then
        return;
    end;

    local function v19() -- Line: 114
        -- upvalues: u16 (copy), setLocked (ref), u5 (ref)
        local v17 = u16:GetAttribute("State_BerserkApe") == true;
        setLocked(v17);
        local v18 = u16;

        if v18 then
            v18 = v18:FindFirstChildOfClass("Humanoid");
        end;

        if not v18 then
            return;
        end;

        if not v17 then
            v18.AutoRotate = true;
            u5 = nil;

            return;
        end;

        if u5 == nil then
            u5 = v18.AutoRotate;
        end;

        v18.AutoRotate = false;
    end;

    u16:GetAttributeChangedSignal("State_BerserkApe"):Connect(v19);
    local v20 = u16:GetAttribute("State_BerserkApe") == true;
    setLocked(v20);

    if u16 then
        u16 = u16:FindFirstChildOfClass("Humanoid");
    end;

    if not u16 then
        return;
    end;

    if not v20 then
        u16.AutoRotate = true;
        u5 = nil;

        return;
    end;

    if u5 == nil then
        u5 = u16.AutoRotate;
    end;

    u16.AutoRotate = false;
end);
local u21 = LocalPlayer.Character and LocalPlayer.Character;

if u21 then
    local function v24() -- Line: 114
        -- upvalues: u21 (copy), setLocked (copy), u5 (ref)
        local v22 = u21:GetAttribute("State_BerserkApe") == true;
        setLocked(v22);
        local v23 = u21;

        if v23 then
            v23 = v23:FindFirstChildOfClass("Humanoid");
        end;

        if not v23 then
            return;
        end;

        if not v22 then
            v23.AutoRotate = true;
            u5 = nil;

            return;
        end;

        if u5 == nil then
            u5 = v23.AutoRotate;
        end;

        v23.AutoRotate = false;
    end;

    u21:GetAttributeChangedSignal("State_BerserkApe"):Connect(v24);
    local v25 = u21:GetAttribute("State_BerserkApe") == true;
    setLocked(v25);
    local v26 = not v25;

    if u21 then
        u21 = u21:FindFirstChildOfClass("Humanoid");
    end;

    if u21 then
        if v26 then
            u21.AutoRotate = true;
            u5 = nil;
        else
            if u5 == nil then
                u5 = u21.AutoRotate;
            end;

            u21.AutoRotate = false;
        end;
    end;
end;

return {};