-- Decompiled with Potassium's decompiler.

local Players = game:GetService("Players");
local MagicFitRemote = game:GetService("ReplicatedStorage"):WaitForChild("Remotes"):WaitForChild("MagicFitRemote");
local LocalPlayer = Players.LocalPlayer;
local Color3_fromRGB_ret = Color3.fromRGB(44, 44, 45);
local Color3_fromRGB_ret2 = Color3.fromRGB(28, 28, 30);
local Color3_fromRGB_ret3 = Color3.fromRGB(120, 235, 120);
local Color3_fromRGB_ret4 = Color3.fromRGB(255, 152, 48);
local Color3_fromRGB_ret5 = Color3.fromRGB(235, 235, 235);
local u1 = nil;

local function stroke(p2, p3) -- Line: 25
    local UIStroke = Instance.new("UIStroke");
    UIStroke.Color = Color3.new(0, 0, 0);
    UIStroke.Thickness = p3 or 2;
    UIStroke.Parent = p2;

    return UIStroke;
end;

function MagicFitRemote.OnClientInvoke(p4) -- Line: 33
    -- upvalues: u1 (ref), LocalPlayer (copy), Color3_fromRGB_ret (copy), Color3_fromRGB_ret2 (copy), Color3_fromRGB_ret4 (copy), Color3_fromRGB_ret3 (copy), Color3_fromRGB_ret5 (copy)
    if type(p4) ~= "table" or p4.Action ~= "FitOffer" then
        return false;
    end;

    if u1 then
        u1:Destroy();
        u1 = nil;
    end;

    local ScreenGui = Instance.new("ScreenGui");
    ScreenGui.Name = "MagicFitPrompt";
    ScreenGui.ResetOnSpawn = false;
    ScreenGui.DisplayOrder = 60;
    ScreenGui.IgnoreGuiInset = true;
    ScreenGui.Parent = LocalPlayer:WaitForChild("PlayerGui");
    u1 = ScreenGui;
    local Frame = Instance.new("Frame");
    Frame.Size = UDim2.fromOffset(320, 150);
    Frame.AnchorPoint = Vector2.new(0.5, 0);
    Frame.Position = UDim2.new(0.5, 0, 0.22, 0);
    Frame.BackgroundColor3 = Color3_fromRGB_ret;
    Frame.BorderSizePixel = 0;
    Frame.Parent = ScreenGui;
    local UIStroke = Instance.new("UIStroke");
    UIStroke.Color = Color3.new(0, 0, 0);
    UIStroke.Thickness = 3;
    UIStroke.Parent = Frame;
    local TextLabel = Instance.new("TextLabel");
    TextLabel.Size = UDim2.new(1, 0, 0, 30);
    TextLabel.BackgroundColor3 = Color3_fromRGB_ret2;
    TextLabel.BorderSizePixel = 0;
    TextLabel.Font = Enum.Font.Bangers;
    TextLabel.TextSize = 24;
    TextLabel.TextColor3 = Color3_fromRGB_ret4;
    TextLabel.Text = "MAGIC CREATION";
    TextLabel.Parent = Frame;
    local UIStroke2 = Instance.new("UIStroke");
    UIStroke2.Color = Color3.new(0, 0, 0);
    UIStroke2.Thickness = 2;
    UIStroke2.Parent = TextLabel;
    local Frame2 = Instance.new("Frame");
    Frame2.Size = UDim2.new(1, 0, 0, 2);
    Frame2.Position = UDim2.fromOffset(0, 30);
    Frame2.BackgroundColor3 = Color3_fromRGB_ret3;
    Frame2.BorderSizePixel = 0;
    Frame2.Parent = Frame;
    local TextLabel2 = Instance.new("TextLabel");
    TextLabel2.Size = UDim2.new(1, -16, 0, 52);
    TextLabel2.Position = UDim2.new(0, 8, 0, 36);
    TextLabel2.BackgroundTransparency = 1;
    TextLabel2.Font = Enum.Font.Gotham;
    TextLabel2.TextSize = 14;
    TextLabel2.TextColor3 = Color3_fromRGB_ret5;
    TextLabel2.TextWrapped = true;
    TextLabel2.Text = tostring(p4.Inviter or "A Namekian") .. " wants to conjure \"" .. tostring(p4.Fit or "a new fit") .. "\" onto you. Allow it?";
    TextLabel2.Parent = Frame;
    local TextLabel3 = Instance.new("TextLabel");
    TextLabel3.Size = UDim2.new(1, 0, 0, 14);
    TextLabel3.Position = UDim2.new(0, 0, 0, 88);
    TextLabel3.BackgroundTransparency = 1;
    TextLabel3.Font = Enum.Font.Arcade;
    TextLabel3.TextSize = 13;
    TextLabel3.TextColor3 = Color3_fromRGB_ret4;
    TextLabel3.Text = tostring(15);
    TextLabel3.Parent = Frame;
    local u5 = false;
    local u6 = false;

    local function makeButton(p7, p8, p9) -- Line: 99
        -- upvalues: Color3_fromRGB_ret2 (ref), Frame (copy)
        local TextButton = Instance.new("TextButton");
        TextButton.Size = UDim2.new(0.42, 0, 0, 32);
        TextButton.AnchorPoint = Vector2.new(0.5, 1);
        TextButton.Position = UDim2.new(p9, 0, 1, -8);
        TextButton.BackgroundColor3 = Color3_fromRGB_ret2;
        TextButton.BorderSizePixel = 0;
        TextButton.Font = Enum.Font.Arcade;
        TextButton.TextSize = 16;
        TextButton.TextColor3 = p8;
        TextButton.Text = p7;
        TextButton.AutoButtonColor = true;
        TextButton.Parent = Frame;
        local UIStroke3 = Instance.new("UIStroke");
        UIStroke3.Color = Color3.new(0, 0, 0);
        UIStroke3.Thickness = 2;
        UIStroke3.Parent = TextButton;

        return TextButton;
    end;

    makeButton("ACCEPT", Color3_fromRGB_ret3, 0.27).Activated:Connect(function() -- Line: 116
        -- upvalues: u6 (ref), u5 (ref)
        u6 = true;
        u5 = true;
    end);
    makeButton("DECLINE", Color3_fromRGB_ret4, 0.73).Activated:Connect(function() -- Line: 120
        -- upvalues: u5 (ref)
        u5 = true;
    end);
    local os_clock_ret = os.clock();

    while not u5 and ScreenGui.Parent do
        local v10 = 15 - (os.clock() - os_clock_ret);

        if v10 <= 0 then
            break;
        end;

        local math_ceil_ret = math.ceil(v10);
        TextLabel3.Text = tostring(math_ceil_ret);
        task.wait(0.1);
    end;

    if u1 == ScreenGui then
        u1 = nil;
    end;

    ScreenGui:Destroy();

    return u5 and u6 or false;
end;