-- Decompiled with Potassium's decompiler.

local ReplicatedStorage = game:GetService("ReplicatedStorage");
local Players = game:GetService("Players");
local Modules = ReplicatedStorage:WaitForChild("Modules");
local GlobalFunctions = require(Modules.GlobalFunctions);
local StateManager = require(Modules.Metadata.ControlData.StateManager);
local DangerFrame = script:FindFirstAncestor("HUD"):WaitForChild("MainFrame"):WaitForChild("DangerFrame");
local Dball = DangerFrame:WaitForChild("Dball");
local DangerStroke = DangerFrame:WaitForChild("DangerStroke");
local u1 = false;
local u2 = 0;
local LocalPlayer = Players.LocalPlayer;
local v3 = {};

local function stillInCombat() -- Line: 55
    -- upvalues: LocalPlayer (copy), u2 (ref), StateManager (copy)
    local Character = LocalPlayer.Character;

    if Character then
        return os.clock() - u2 < 2 and true or StateManager.IsInState(Character, "InCombat");
    end;

    return false;
end;

local function spinLoop() -- Line: 68
    -- upvalues: u1 (ref), DangerFrame (copy), DangerStroke (copy), LocalPlayer (copy), u2 (ref), StateManager (copy), Dball (copy), GlobalFunctions (copy)
    if u1 then
        return;
    end;

    u1 = true;
    DangerFrame.Visible = true;
    task.spawn(function() -- Line: 74
        -- upvalues: DangerStroke (ref), u1 (ref)
        local TweenService = game:GetService("TweenService");
        local v4 = TweenService:Create(DangerStroke, TweenInfo.new(0.8, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut), {
            Transparency = 0.65
        });
        local v5 = TweenService:Create(DangerStroke, TweenInfo.new(0.8, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut), {
            Transparency = 0.1
        });

        while u1 do
            v4:Play();
            v4.Completed:Wait();

            if not u1 then
                break;
            end;

            v5:Play();
            v5.Completed:Wait();
        end;

        DangerStroke.Transparency = 0.25;
    end);
    task.spawn(function() -- Line: 90
        -- upvalues: LocalPlayer (ref), u2 (ref), StateManager (ref), Dball (ref), GlobalFunctions (ref), DangerFrame (ref), u1 (ref)
        while true do
            local Character = LocalPlayer.Character;
            local v6;

            if Character then
                if os.clock() - u2 < 2 then
                    v6 = true;
                else
                    v6 = StateManager.IsInState(Character, "InCombat");
                end;
            else
                v6 = false;
            end;

            if not v6 then
                DangerFrame.Visible = false;
                u1 = false;

                return;
            end;

            Dball.Rotation = 0;
            GlobalFunctions.Tween({
                Instance = Dball
            }, {
                Rotation = 360
            }).Completed:Wait();
        end;
    end);
end;

function v3.Update(p7) -- Line: 111
    -- upvalues: u2 (ref), spinLoop (copy)
    u2 = os.clock();
    spinLoop();
end;

return v3;