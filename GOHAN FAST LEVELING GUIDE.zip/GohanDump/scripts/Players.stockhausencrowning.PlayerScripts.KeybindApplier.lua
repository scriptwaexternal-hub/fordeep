-- Decompiled with Potassium's decompiler.

local ReplicatedStorage = game:GetService("ReplicatedStorage");
local Modules = ReplicatedStorage:WaitForChild("Modules");
local Remotes = ReplicatedStorage:WaitForChild("Remotes");
local ControlData = require(Modules.Metadata.ControlData.ControlData);
local StatRetrieveRemote = Remotes:WaitForChild("StatRetrieveRemote");

local function snapshotBinds(p1) -- Line: 47
    -- upvalues: snapshotBinds (copy)
    local v2 = {};

    for i, v in pairs(p1) do
        if type(v) == "table" then
            if typeof(v[1]) == "string" then
                v2[i] = table.clone(v);
            else
                v2[i] = snapshotBinds(v);
            end;
        end;
    end;

    return v2;
end;

if not ControlData.Defaults then
    ControlData.Defaults = snapshotBinds(ControlData.Controls);
end;

local LocalPlayer = game:GetService("Players").LocalPlayer;

local function fetchProfileTable(u3) -- Line: 84
    -- upvalues: StatRetrieveRemote (copy)
    for i = 1, 40 do
        local success, result = pcall(function() -- Line: 86
            -- upvalues: StatRetrieveRemote (ref), u3 (copy)
            return StatRetrieveRemote:InvokeServer(u3, "TableStat");
        end);

        if success and type(result) == "table" then
            return result;
        end;

        task.wait(0.5);
        local _ = i;
    end;

    return nil;
end;

local function restoreDefaults(p4, p5) -- Line: 100
    -- upvalues: restoreDefaults (copy)
    for i, v in pairs(p4) do
        if type(v) == "table" then
            if typeof(v[1]) == "string" then
                local v6 = p5[i];

                if type(v6) == "table" then
                    for i2, v2 in ipairs(v) do
                        v6[i2] = v2;
                    end;
                end;
            elseif type(p5[i]) == "table" then
                restoreDefaults(v, p5[i]);
            end;
        end;
    end;
end;

local function applyOverrides(p7) -- Line: 115
    -- upvalues: ControlData (copy), LocalPlayer (copy)
    for i, v in pairs(p7) do
        local v8, v9;

        if string.sub(i, -4) == "|pad" then
            v8 = string.sub(i, 1, -5);
            v9 = true;
        else
            v8 = i;
            v9 = false;
        end;

        local string_match_ret, v10 = string.match(v8, "^([^/]+)/(.+)$");

        if string_match_ret and (v10 and type(v) == "string") then
            local v11 = ControlData.Controls[string_match_ret];

            if v11 then
                v11 = v11[v10];
            end;

            if type(v11) == "table" then
                v11[v9 and 2 or 1] = v;

                if not (v9 or (string_match_ret ~= "CoreControls" or v10 ~= "Shift Lock")) then
                    LocalPlayer:SetAttribute("ShiftLockKey", v);
                end;
            end;
        end;
    end;
end;

local u12 = false;

local function loadForCurrentSlot() -- Line: 141
    -- upvalues: u12 (ref), fetchProfileTable (copy), restoreDefaults (copy), ControlData (copy), LocalPlayer (copy), applyOverrides (copy), StatRetrieveRemote (copy)
    if u12 then
        return;
    end;

    u12 = true;
    local v13 = fetchProfileTable("Keybinds");

    if v13 == nil then
        warn("[KeybindApplier] profile never returned Keybinds after " .. 20 .. "s - saved rebinds are NOT applied for this session. Defaults are in effect.");
    else
        restoreDefaults(ControlData.Defaults, ControlData.Controls);
        local v14 = ControlData.Defaults.CoreControls and ControlData.Defaults.CoreControls["Shift Lock"];

        if v14 and typeof(v14[1]) == "string" then
            LocalPlayer:SetAttribute("ShiftLockKey", v14[1]);
        end;

        applyOverrides(v13);
        local success, result = pcall(function() -- Line: 162
            -- upvalues: StatRetrieveRemote (ref)
            return StatRetrieveRemote:InvokeServer("ToggleRun");
        end);

        if success then
            ControlData.Controls.Run.ToggleMode = result == true;
        end;
    end;

    u12 = false;
end;

task.spawn(function() -- Line: 175
    -- upvalues: LocalPlayer (copy), loadForCurrentSlot (copy)
    LocalPlayer:WaitForChild("PlayerStats");
    loadForCurrentSlot();
end);
LocalPlayer.CharacterAdded:Connect(function() -- Line: 180
    -- upvalues: LocalPlayer (copy), loadForCurrentSlot (copy)
    task.defer(function() -- Line: 182
        -- upvalues: LocalPlayer (ref), loadForCurrentSlot (ref)
        LocalPlayer:WaitForChild("PlayerStats", 30);
        loadForCurrentSlot();
    end);
end);