-- Decompiled with Potassium's decompiler.

local ReplicatedStorage = game:GetService("ReplicatedStorage");
local RunService = game:GetService("RunService");
local Players = game:GetService("Players");
local Modules = ReplicatedStorage:WaitForChild("Modules");
local Remotes = ReplicatedStorage:WaitForChild("Remotes");
local Shared = Modules.Shared;
local Utility = Modules.Utility;
local GlobalFunctions = require(Modules.GlobalFunctions);
local AnimationManager = require(Shared.AnimationManager);
local FindCharacters = require(Shared.FindCharacters);
local UtilityHandler = require(Utility.UtilityHandler);
local HitboxHandler = require(Utility.HitboxHandler);
local SoundManager = require(Shared.SoundManager);
local v1 = script:FindFirstAncestor("VFX");
local FlyVFX = require(v1:FindFirstChild("FlyVFX", true));
local _ = Players.LocalPlayer;
local u2 = require(Shared:WaitForChild("Mouse")).new();
local RushTargetEvent = Remotes.RushTargetEvent;

return {
    Execution = function(p3) -- Line: 52
        -- upvalues: GlobalFunctions (copy), AnimationManager (copy), SoundManager (copy), Players (copy), RunService (copy), HitboxHandler (copy), FindCharacters (copy), UtilityHandler (copy), u2 (copy), FlyVFX (copy), RushTargetEvent (copy)
        local u4 = nil;
        local u5 = false;
        local u6 = true;
        tick();
        local u7;

        if p3 then
            u7 = p3.Character;
        else
            u7 = p3;
        end;

        local v8;

        if p3 then
            v8 = p3.ExtraData;
        else
            v8 = p3;
        end;

        local u9 = v8 and v8.RushTime or (p3 and p3.RushTime or 0.75);
        local u10 = {};

        if not u7 then
            return;
        end;

        local RootAndHumanoid, v11 = GlobalFunctions.GetRootAndHumanoid(u7);

        if not (RootAndHumanoid and v11) then
            return;
        end;

        local u12 = AnimationManager.PlayAnimation(u7, "Fly Charge");
        local Attachment = Instance.new("Attachment");
        Attachment.Parent = RootAndHumanoid;
        local BindableEvent = Instance.new("BindableEvent");
        local LinearVelocity = Instance.new("LinearVelocity");
        LinearVelocity.Parent = Attachment;
        LinearVelocity.Attachment0 = Attachment;
        LinearVelocity.MaxForce = math.max(Attachment.Parent.AssemblyMass, 1) * 12000;
        LinearVelocity.VectorVelocity = Vector3.new(0, 0, 0);
        local AlignOrientation = Instance.new("AlignOrientation");
        AlignOrientation.Attachment0 = Attachment;
        AlignOrientation.Mode = Enum.OrientationAlignmentMode.OneAttachment;
        AlignOrientation.RigidityEnabled = true;
        AlignOrientation.MaxTorque = (1 / 0);
        AlignOrientation.Parent = RootAndHumanoid;
        SoundManager.AddSound("DBZ RUSH SFX", {
            Parent = RootAndHumanoid
        }, "Client");
        v11.AutoRotate = false;
        local v13 = nil;
        local u14 = nil;

        local function Rush_Hitbox() -- Line: 103
            -- upvalues: Players (ref), u7 (copy), u14 (ref), RunService (ref), RootAndHumanoid (copy), HitboxHandler (ref), u10 (ref), FindCharacters (ref), UtilityHandler (ref), u4 (ref), BindableEvent (copy)
            local PlayerFromCharacter = Players:GetPlayerFromCharacter(u7);
            local v15;

            if PlayerFromCharacter then
                v15 = PlayerFromCharacter:FindFirstChild("PlayerStats");

                if v15 then
                    v15 = v15:FindFirstChild("Hitbox", true);
                end;
            else
                v15 = nil;
            end;

            local u16 = v15 and v15.Value or 1;
            u14 = RunService.Stepped:Connect(function(p17, p18) -- Line: 114
                -- upvalues: RootAndHumanoid (ref), u16 (copy), HitboxHandler (ref), u10 (ref), FindCharacters (ref), u7 (ref), UtilityHandler (ref), u4 (ref), BindableEvent (ref), u14 (ref)
                local v19 = 10 * u16 + RootAndHumanoid.AssemblyLinearVelocity.Magnitude * p18 + 2;
                local v20 = {
                    Size = Vector3.new(10 * u16, 10 * u16, v19),
                    Location = RootAndHumanoid.CFrame * CFrame.new(0, 0, 2 - v19 / 2)
                };
                local _, v21 = HitboxHandler.New(v20);
                u10 = FindCharacters.Find(u7, v21);

                if UtilityHandler:Length(u10) >= 1 then
                    local _, v22 = next(u10);
                    u4 = v22;
                    BindableEvent:Fire(u4);
                    u14:Disconnect();
                end;
            end);
        end;

        local function Rush_alignment() -- Line: 142
            -- upvalues: AlignOrientation (copy), u6 (ref), u2 (ref)
            while AlignOrientation.Parent ~= nil and u6 == true do
                AlignOrientation.CFrame = u2.Hit;
                task.wait();
            end;
        end;

        local u23 = false;

        local function Start_Boost() -- Line: 155
            -- upvalues: u23 (ref), u5 (ref), u6 (ref), u12 (copy), FlyVFX (ref), u7 (copy), u9 (copy), BindableEvent (copy), Rush_Hitbox (copy), LinearVelocity (copy), RootAndHumanoid (copy)
            if u23 or u5 then
                return;
            end;

            u23 = true;
            u6 = false;

            if u12 then
                u12:AdjustSpeed(0);
            end;

            FlyVFX["Boost Start"]({
                Character = u7,
                Color = Color3.fromRGB(255, 255, 255)
            });
            task.delay(u9, function() -- Line: 169
                -- upvalues: u5 (ref), BindableEvent (ref), u12 (ref)
                if not u5 then
                    BindableEvent:Fire(nil);
                end;

                if u12 then
                    u12:AdjustSpeed(1);
                end;
            end);
            Rush_Hitbox();
            LinearVelocity.VectorVelocity = RootAndHumanoid.CFrame.lookVector * 130;
        end;

        if u12 then
            v13 = u12:GetMarkerReachedSignal("Boost"):Once(Start_Boost);
        end;

        task.delay(1.2, Start_Boost);
        task.delay(1.2 + u9 + 1, function() -- Line: 190
            -- upvalues: u5 (ref), BindableEvent (copy)
            if not u5 then
                BindableEvent:Fire(nil);
            end;
        end);
        task.spawn(Rush_alignment);
        u4 = BindableEvent.Event:Wait();
        u5 = true;
        v11.AutoRotate = true;
        BindableEvent:Destroy();

        if v13 then
            v13:Disconnect();
        end;

        if u14 then
            u14:Disconnect();
        end;

        Attachment:Destroy();
        AlignOrientation:Destroy();
        RushTargetEvent:FireServer(u4, v8);
    end
};