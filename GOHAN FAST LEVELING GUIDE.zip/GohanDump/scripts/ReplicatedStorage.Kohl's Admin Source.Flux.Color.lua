-- Decompiled with Potassium's decompiler.

local u1 = {};

local function fromLinear(p2: number) -- Line: 6
    if p2 < 0.0031308 then
        return p2 * 12.92;
    end;

    return p2 ^ 0.4166666666666667 * 1.055 - 0.055;
end;

local function toLinear(p3: number) -- Line: 14
    if p3 < 0.04045 then
        return p3 / 12.92;
    end;

    return ((p3 + 0.055) / 1.055) ^ 2.4;
end;

function u1.fromLinear(p4) -- Line: 23
    local R = p4.R;
    local v5;

    if R < 0.0031308 then
        v5 = R * 12.92;
    else
        v5 = R ^ 0.4166666666666667 * 1.055 - 0.055;
    end;

    local G = p4.G;
    local v6;

    if G < 0.0031308 then
        v6 = G * 12.92;
    else
        v6 = G ^ 0.4166666666666667 * 1.055 - 0.055;
    end;

    local B = p4.B;
    local v7;

    if B < 0.0031308 then
        v7 = B * 12.92;
    else
        v7 = B ^ 0.4166666666666667 * 1.055 - 0.055;
    end;

    return Color3.new(v5, v6, v7);
end;

function u1.toLinear(p8) -- Line: 28
    local R = p8.R;
    local v9;

    if R < 0.04045 then
        v9 = R / 12.92;
    else
        v9 = ((R + 0.055) / 1.055) ^ 2.4;
    end;

    local G = p8.G;
    local v10;

    if G < 0.04045 then
        v10 = G / 12.92;
    else
        v10 = ((G + 0.055) / 1.055) ^ 2.4;
    end;

    local B = p8.B;
    local v11;

    if B < 0.04045 then
        v11 = B / 12.92;
    else
        v11 = ((B + 0.055) / 1.055) ^ 2.4;
    end;

    return Color3.new(v9, v10, v11);
end;

local u30 = {
    fromLinear = function(p12) -- Line: 35, Name: fromLinear
        local v13 = (p12.R * 0.4122214708 + p12.G * 0.5363325363 + p12.B * 0.0514459929) ^ 0.3333333333333333;
        local v14 = (p12.R * 0.2119034982 + p12.G * 0.6806995451 + p12.B * 0.1073969566) ^ 0.3333333333333333;
        local v15 = (p12.R * 0.0883024619 + p12.G * 0.2817188376 + p12.B * 0.6299787005) ^ 0.3333333333333333;

        return Vector3.new(v13 * 0.2104542553 + v14 * 0.793617785 - v15 * 0.0040720468, v13 * 1.9779984951 - v14 * 2.428592205 + v15 * 0.4505937099, v13 * 0.0259040371 + v14 * 0.7827717662 - v15 * 0.808675766);
    end,

    toLinear = function(p16: vector, p17: boolean?) -- Line: 52, Name: toLinear
        local v18 = (p16.X + p16.Y * 0.3963377774 + p16.Z * 0.2158037573) ^ 3;
        local v19 = (p16.X - p16.Y * 0.1055613458 - p16.Z * 0.0638541728) ^ 3;
        local v20 = (p16.X - p16.Y * 0.0894841775 - p16.Z * 1.291485548) ^ 3;
        local v21 = v18 * 4.0767416621 - v19 * 3.3077115913 + v20 * 0.2309699292;
        local v22 = v18 * -1.2684380046 + v19 * 2.6097574011 - v20 * 0.3413193965;
        local v23 = v18 * -0.0041960863 - v19 * 0.7034186147 + v20 * 1.707614701;

        if p17 ~= false then
            v21 = math.clamp(v21, 0, 1);
            v22 = math.clamp(v22, 0, 1);
            v23 = math.clamp(v23, 0, 1);
        end;

        return Color3.new(v21, v22, v23);
    end,

    fromHCL = function(p24: vector) -- Line: 75, Name: fromHCL
        local v25 = p24.X * 2 * 3.141592653589793;
        local Y = p24.Y;
        local Z = p24.Z;
        local v26 = Y * math.cos(v25);
        local v27 = Y * math.sin(v25);

        return Vector3.new(Z, v26, v27);
    end,

    toHCL = function(p28: vector) -- Line: 87, Name: toHCL
        local v29 = math.atan2(p28.Z, p28.Y) / 6.283185307179586;
        local math_sqrt_ret = math.sqrt(p28.Y ^ 2 + p28.Z ^ 2);

        return Vector3.new(v29, math_sqrt_ret, p28.X);
    end
};

function u30.fromRGB(p31) -- Line: 96
    -- upvalues: u30 (copy), u1 (copy)
    return u30.fromLinear(u1.toLinear(p31));
end;

function u30.toRGB(p32: vector, p33: boolean?) -- Line: 101
    -- upvalues: u1 (copy), u30 (copy)
    return u1.fromLinear(u30.toLinear(p32, p33));
end;

return {
    Oklab = u30,
    sRGB = u1
};