-- Decompiled with Potassium's decompiler.

local Players = game:GetService("Players");
local ReplicatedStorage = game:GetService("ReplicatedStorage");
local RunService = game:GetService("RunService");
local ContextActionService = game:GetService("ContextActionService");
local UserInputService = game:GetService("UserInputService");
local TweenService = game:GetService("TweenService");
local LocalPlayer = Players.LocalPlayer;
local Platform = require(ReplicatedStorage:WaitForChild("Modules"):WaitForChild("Shared"):WaitForChild("Platform"));
local ShopData = require(ReplicatedStorage.Modules.Metadata.ShopData.ShopData);
local TransactionRemote = ReplicatedStorage:WaitForChild("Remotes"):WaitForChild("TransactionRemote");
local u1 = { Enum.KeyCode.E, Enum.KeyCode.ButtonX };
local Color3_fromRGB_ret = Color3.fromRGB(44, 44, 45);
local Color3_fromRGB_ret2 = Color3.fromRGB(28, 28, 30);
local Color3_fromRGB_ret3 = Color3.fromRGB(255, 255, 255);
local Color3_fromRGB_ret4 = Color3.fromRGB(216, 213, 205);
local Color3_fromRGB_ret5 = Color3.fromRGB(201, 198, 191);
local Color3_fromRGB_ret6 = Color3.fromRGB(0, 0, 0);
local Color3_fromRGB_ret7 = Color3.fromRGB(88, 214, 106);
local Color3_fromRGB_ret8 = Color3.fromRGB(72, 160, 255);
local Arcade = Enum.Font.Arcade;
local Bangers = Enum.Font.Bangers;
local v2 = {};
local u3 = {};
local u4 = nil;
local u5 = nil;
local u6 = nil;
local u7 = nil;
local u8 = nil;
local u9 = nil;
local u10 = nil;
local u11 = false;
local u12 = 0;
local u13 = 0;

local function outfitOf(p14) -- Line: 63
    local Attribute = p14:GetAttribute("Outfit");

    if type(Attribute) == "string" and Attribute ~= "" then
        return Attribute;
    end;

    return p14.Name;
end;

local function register(p15) -- Line: 69
    -- upvalues: ShopData (copy), u3 (copy)
    if not p15:IsA("Model") then
        return;
    end;

    if p15:GetAttribute("Buyable") ~= "Clothing" then
        return;
    end;

    local Attribute = p15:GetAttribute("Outfit");

    if type(Attribute) ~= "string" or Attribute == "" then
        Attribute = p15.Name;
    end;

    if not (ShopData.Clothing[Attribute] and ShopData.Clothing[Attribute].Price) then
        return;
    end;

    u3[p15] = Attribute;
end;

local function anchorOf(p16) -- Line: 77
    return p16.PrimaryPart or (p16:FindFirstChild("HumanoidRootPart") or p16:FindFirstChildWhichIsA("BasePart", true));
end;

local function reqText(p17) -- Line: 83
    if type(p17) ~= "table" or #p17 == 0 then
        return nil;
    end;

    local v18 = {};

    for _, v in ipairs(p17) do
        if v[1] == "Class_In_Training" then
            local v19 = tostring(v[2]) .. " school";
            table.insert(v18, v19);
        else
            local v20 = tostring(v[1]) .. " " .. tostring(v[2]);
            table.insert(v18, v20);
        end;
    end;

    return "Needs " .. table.concat(v18, ", ");
end;

local function buy() -- Line: 98
    -- upvalues: u10 (ref), u13 (ref), TransactionRemote (copy)
    if not u10 then
        return;
    end;

    local os_clock_ret = os.clock();

    if os_clock_ret - u13 < 0.5 then
        return;
    end;

    u13 = os_clock_ret;
    TransactionRemote:FireServer({
        Action = "Buy_Clothing",
        Outfit = u10
    });
end;

local function startHold() -- Line: 106
    -- upvalues: u4 (ref), u11 (ref), u12 (ref)
    if not u4 or u11 then
        return;
    end;

    local os_clock_ret = os.clock();
    u11 = true;
    u12 = os_clock_ret;
end;

local function stopHold() -- Line: 111
    -- upvalues: u11 (ref), u6 (ref)
    u11 = false;

    if u6 then
        u6.Size = UDim2.new(0, 0, 1, 0);
    end;
end;

local function bindKey() -- Line: 116
    -- upvalues: ContextActionService (copy), u4 (ref), u11 (ref), u12 (ref), u6 (ref), u1 (copy)
    ContextActionService:BindActionAtPriority("ClothingPromptBuy", function(p21, p22) -- Line: 117
        -- upvalues: u4 (ref), u11 (ref), u12 (ref), u6 (ref)
        if p22 == Enum.UserInputState.Begin then
            if u4 and not u11 then
                local os_clock_ret = os.clock();
                u11 = true;
                u12 = os_clock_ret;
            end;
        else
            u11 = false;

            if u6 then
                u6.Size = UDim2.new(0, 0, 1, 0);
            end;
        end;

        return Enum.ContextActionResult.Sink;
    end, false, Enum.ContextActionPriority.High.Value, table.unpack(u1));
end;

local function unbindKey() -- Line: 127
    -- upvalues: ContextActionService (copy)
    ContextActionService:UnbindAction("ClothingPromptBuy");
end;

local function stroked(p23) -- Line: 133
    -- upvalues: Color3_fromRGB_ret6 (copy)
    p23.TextStrokeColor3 = Color3_fromRGB_ret6;
    p23.TextStrokeTransparency = 0.5;

    return p23;
end;

local function outline(p24, p25) -- Line: 139
    -- upvalues: Color3_fromRGB_ret6 (copy)
    local UIStroke = Instance.new("UIStroke");
    UIStroke.Color = Color3_fromRGB_ret6;
    UIStroke.Thickness = p25 or 1.5;
    UIStroke.Parent = p24;

    return UIStroke;
end;

local function label(p26, p27, p28, p29, p30) -- Line: 145
    -- upvalues: Color3_fromRGB_ret6 (copy)
    local TextLabel = Instance.new("TextLabel");
    TextLabel.BackgroundTransparency = 1;
    TextLabel.Font = p27;
    TextLabel.TextSize = p28;
    TextLabel.TextColor3 = p29;
    TextLabel.TextXAlignment = p30 or Enum.TextXAlignment.Left;
    TextLabel.Text = "";
    TextLabel.Parent = p26;
    TextLabel.TextStrokeColor3 = Color3_fromRGB_ret6;
    TextLabel.TextStrokeTransparency = 0.5;

    return TextLabel;
end;

local function updateChip() -- Line: 155
    -- upvalues: u7 (ref), Platform (copy), u8 (ref)
    if not u7 then
        return;
    end;

    if Platform.IsTouch() and not Platform.PreferGamepadGlyphs() then
        u7.Text = "BUY";
        u8.Text = "HOLD";

        return;
    end;

    if Platform.PreferGamepadGlyphs() then
        u7.Text = "X";
        u8.Text = "HOLD";

        return;
    end;

    u7.Text = "E";
    u8.Text = "HOLD";
end;

local function build(p31, p32) -- Line: 166
    -- upvalues: ShopData (copy), u4 (ref), LocalPlayer (copy), u5 (ref), Color3_fromRGB_ret (copy), Color3_fromRGB_ret6 (copy), Arcade (copy), Color3_fromRGB_ret3 (copy), Bangers (copy), Color3_fromRGB_ret8 (copy), Color3_fromRGB_ret5 (copy), reqText (copy), u7 (ref), Color3_fromRGB_ret2 (copy), u8 (ref), Color3_fromRGB_ret4 (copy), u6 (ref), Color3_fromRGB_ret7 (copy), u11 (ref), u12 (ref), Platform (copy), TweenService (copy)
    local v33 = ShopData.Clothing[p32];
    local v34 = p31.PrimaryPart or (p31:FindFirstChild("HumanoidRootPart") or p31:FindFirstChildWhichIsA("BasePart", true));

    if not v34 then
        return false;
    end;

    local BoundingBox, v35 = p31:GetBoundingBox();
    local v36 = BoundingBox.Position.Y + v35.Y * 0.5;
    u4 = Instance.new("BillboardGui");
    u4.Name = "ClothingPrompt";
    u4.Adornee = v34;
    u4.AlwaysOnTop = true;
    u4.Active = true;
    u4.ResetOnSpawn = false;
    u4.Size = UDim2.fromOffset(138.60000000000002, 46.2);
    u4.StudsOffsetWorldSpace = Vector3.new(0, v36 - v34.Position.Y + 1.2, 0);
    u4.Parent = LocalPlayer:WaitForChild("PlayerGui");
    u5 = Instance.new("CanvasGroup");
    u5.AnchorPoint = Vector2.new(0.5, 0.5);
    u5.Position = UDim2.fromScale(0.5, 0.5);
    u5.Size = UDim2.fromOffset(252, 84);
    u5.BackgroundTransparency = 1;
    u5.GroupTransparency = 1;
    u5.Parent = u4;
    local UIScale = Instance.new("UIScale");
    UIScale.Scale = 0.4675;
    UIScale.Parent = u5;
    local Frame = Instance.new("Frame");
    Frame.Size = UDim2.fromScale(1, 1);
    Frame.BackgroundColor3 = Color3_fromRGB_ret;
    Frame.BorderSizePixel = 0;
    Frame.Parent = u5;
    local UIStroke = Instance.new("UIStroke");
    UIStroke.Color = Color3_fromRGB_ret6;
    UIStroke.Thickness = 2;
    UIStroke.Parent = Frame;
    local TextLabel = Instance.new("TextLabel");
    TextLabel.BackgroundTransparency = 1;
    TextLabel.Font = Arcade;
    TextLabel.TextSize = 16;
    TextLabel.TextColor3 = Color3_fromRGB_ret3;
    TextLabel.TextXAlignment = Enum.TextXAlignment.Left;
    TextLabel.Text = "";
    TextLabel.Parent = Frame;
    TextLabel.TextStrokeColor3 = Color3_fromRGB_ret6;
    TextLabel.TextStrokeTransparency = 0.5;
    TextLabel.Position = UDim2.fromOffset(12, 8);
    TextLabel.Size = UDim2.new(1, -92, 0, 20);
    TextLabel.TextTruncate = Enum.TextTruncate.AtEnd;
    TextLabel.Text = string.upper(p32);
    local TextLabel2 = Instance.new("TextLabel");
    TextLabel2.BackgroundTransparency = 1;
    TextLabel2.Font = Bangers;
    TextLabel2.TextSize = 20;
    TextLabel2.TextColor3 = Color3_fromRGB_ret8;
    TextLabel2.TextXAlignment = Enum.TextXAlignment.Left;
    TextLabel2.Text = "";
    TextLabel2.Parent = Frame;
    TextLabel2.TextStrokeColor3 = Color3_fromRGB_ret6;
    TextLabel2.TextStrokeTransparency = 0.5;
    TextLabel2.Position = UDim2.fromOffset(12, 30);
    TextLabel2.Size = UDim2.new(1, -92, 0, 22);
    TextLabel2.Text = tostring(v33.Price) .. " ZENI";
    local TextLabel3 = Instance.new("TextLabel");
    TextLabel3.BackgroundTransparency = 1;
    TextLabel3.Font = Bangers;
    TextLabel3.TextSize = 13;
    TextLabel3.TextColor3 = Color3_fromRGB_ret5;
    TextLabel3.TextXAlignment = Enum.TextXAlignment.Left;
    TextLabel3.Text = "";
    TextLabel3.Parent = Frame;
    TextLabel3.TextStrokeColor3 = Color3_fromRGB_ret6;
    TextLabel3.TextStrokeTransparency = 0.5;
    TextLabel3.Position = UDim2.fromOffset(12, 52);
    TextLabel3.Size = UDim2.new(1, -92, 0, 16);
    TextLabel3.TextTruncate = Enum.TextTruncate.AtEnd;
    TextLabel3.Text = reqText(v33.Requirements) or "Hold to buy and wear";
    u7 = Instance.new("TextButton");
    u7.AnchorPoint = Vector2.new(1, 0);
    u7.Position = UDim2.new(1, -12, 0, 12);
    u7.Size = UDim2.fromOffset(60, 38);
    u7.BackgroundColor3 = Color3_fromRGB_ret2;
    u7.BorderSizePixel = 0;
    u7.AutoButtonColor = false;
    u7.Font = Arcade;
    u7.TextSize = 20;
    u7.TextColor3 = Color3_fromRGB_ret3;
    u7.Text = "E";
    local v37 = u7;
    v37.TextStrokeColor3 = Color3_fromRGB_ret6;
    v37.TextStrokeTransparency = 0.5;
    v37.Parent = Frame;
    local UIStroke2 = Instance.new("UIStroke");
    UIStroke2.Color = Color3_fromRGB_ret6;
    UIStroke2.Thickness = 1.5;
    UIStroke2.Parent = u7;
    local Center = Enum.TextXAlignment.Center;
    local TextLabel4 = Instance.new("TextLabel");
    TextLabel4.BackgroundTransparency = 1;
    TextLabel4.Font = Bangers;
    TextLabel4.TextSize = 12;
    TextLabel4.TextColor3 = Color3_fromRGB_ret4;
    TextLabel4.TextXAlignment = Center or Enum.TextXAlignment.Left;
    TextLabel4.Text = "";
    TextLabel4.Parent = Frame;
    TextLabel4.TextStrokeColor3 = Color3_fromRGB_ret6;
    TextLabel4.TextStrokeTransparency = 0.5;
    u8 = TextLabel4;
    u8.AnchorPoint = Vector2.new(1, 0);
    u8.Position = UDim2.new(1, -12, 0, 52);
    u8.Size = UDim2.fromOffset(60, 14);
    u8.Text = "HOLD";
    local Frame2 = Instance.new("Frame");
    Frame2.AnchorPoint = Vector2.new(0, 1);
    Frame2.Position = UDim2.new(0, 0, 1, 0);
    Frame2.Size = UDim2.new(1, 0, 0, 5);
    Frame2.BackgroundColor3 = Color3_fromRGB_ret2;
    Frame2.BorderSizePixel = 0;
    Frame2.Parent = Frame;
    u6 = Instance.new("Frame");
    u6.Size = UDim2.new(0, 0, 1, 0);
    u6.BackgroundColor3 = Color3_fromRGB_ret7;
    u6.BorderSizePixel = 0;
    u6.Parent = Frame2;
    u7.InputBegan:Connect(function(p38) -- Line: 253
        -- upvalues: u4 (ref), u11 (ref), u12 (ref)
        if (p38.UserInputType == Enum.UserInputType.Touch or p38.UserInputType == Enum.UserInputType.MouseButton1) and u4 then
            if u11 then
                return;
            end;

            local os_clock_ret = os.clock();
            u11 = true;
            u12 = os_clock_ret;
        end;
    end);
    u7.InputEnded:Connect(function(p39) -- Line: 259
        -- upvalues: u11 (ref), u6 (ref)
        if p39.UserInputType == Enum.UserInputType.Touch or p39.UserInputType == Enum.UserInputType.MouseButton1 then
            u11 = false;

            if u6 then
                u6.Size = UDim2.new(0, 0, 1, 0);
            end;
        end;
    end);

    if u7 then
        if Platform.IsTouch() and not Platform.PreferGamepadGlyphs() then
            u7.Text = "BUY";
            u8.Text = "HOLD";
        elseif Platform.PreferGamepadGlyphs() then
            u7.Text = "X";
            u8.Text = "HOLD";
        else
            u7.Text = "E";
            u8.Text = "HOLD";
        end;
    end;

    TweenService:Create(u5, TweenInfo.new(0.15, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
        GroupTransparency = 0
    }):Play();
    TweenService:Create(UIScale, TweenInfo.new(0.18, Enum.EasingStyle.Back, Enum.EasingDirection.Out), {
        Scale = 0.55
    }):Play();

    return true;
end;

local function hide() -- Line: 274
    -- upvalues: ContextActionService (copy), u11 (ref), u6 (ref), u9 (ref), u10 (ref), u4 (ref), u5 (ref), u7 (ref), u8 (ref), TweenService (copy)
    ContextActionService:UnbindAction("ClothingPromptBuy");
    u11 = false;

    if u6 then
        u6.Size = UDim2.new(0, 0, 1, 0);
    end;

    u9 = nil;
    u10 = nil;

    if u4 then
        local u40 = u4;
        local v41 = u5;
        u4 = nil;
        u5 = nil;
        u6 = nil;
        u7 = nil;
        u8 = nil;
        local v42 = TweenService:Create(v41, TweenInfo.new(0.12), {
            GroupTransparency = 1
        });
        v42.Completed:Once(function() -- Line: 282
            -- upvalues: u40 (copy)
            u40:Destroy();
        end);
        v42:Play();
    end;
end;

local function show(p43, p44) -- Line: 287
    -- upvalues: u4 (ref), hide (copy), build (copy), u9 (ref), u10 (ref), ContextActionService (copy), u11 (ref), u12 (ref), u6 (ref), u1 (copy)
    if u4 then
        hide();
    end;

    if not build(p43, p44) then
        return;
    end;

    u9 = p43;
    u10 = p44;
    ContextActionService:BindActionAtPriority("ClothingPromptBuy", function(p45, p46) -- Line: 117
        -- upvalues: u4 (ref), u11 (ref), u12 (ref), u6 (ref)
        if p46 == Enum.UserInputState.Begin then
            if u4 and not u11 then
                local os_clock_ret = os.clock();
                u11 = true;
                u12 = os_clock_ret;
            end;
        else
            u11 = false;

            if u6 then
                u6.Size = UDim2.new(0, 0, 1, 0);
            end;
        end;

        return Enum.ContextActionResult.Sink;
    end, false, Enum.ContextActionPriority.High.Value, table.unpack(u1));
end;

local function nearest(p47) -- Line: 294
    -- upvalues: u3 (copy)
    local v48 = (1 / 0);
    local v49 = nil;
    local v50 = nil;

    for i, v in pairs(u3) do
        if i.Parent then
            local Magnitude = (i:GetPivot().Position - p47).Magnitude;

            if Magnitude < v48 then
                v50 = v;
                v49 = i;
                v48 = Magnitude;
            end;
        else
            u3[i] = nil;
        end;
    end;

    return v49, v50, v48;
end;

local u51 = 0;
RunService.Heartbeat:Connect(function(p52) -- Line: 310
    -- upvalues: u11 (ref), u6 (ref), u12 (ref), u10 (ref), u13 (ref), TransactionRemote (copy), u51 (ref), LocalPlayer (copy), u4 (ref), hide (copy), nearest (copy), u9 (ref), build (copy), ContextActionService (copy), u1 (copy)
    if u11 and u6 then
        local v53 = (os.clock() - u12) / 0.6;
        local math_clamp_ret = math.clamp(v53, 0, 1);
        u6.Size = UDim2.new(math_clamp_ret, 0, 1, 0);

        if math_clamp_ret >= 1 then
            u11 = false;

            if u6 then
                u6.Size = UDim2.new(0, 0, 1, 0);
            end;

            if u10 then
                local os_clock_ret = os.clock();

                if os_clock_ret - u13 >= 0.5 then
                    u13 = os_clock_ret;
                    TransactionRemote:FireServer({
                        Action = "Buy_Clothing",
                        Outfit = u10
                    });
                end;
            end;
        end;
    end;

    u51 = u51 + p52;

    if u51 < 0.15 then
        return;
    end;

    u51 = 0;
    local Character = LocalPlayer.Character;
    local v54;

    if Character then
        v54 = Character:FindFirstChild("HumanoidRootPart");
    else
        v54 = Character;
    end;

    if Character then
        Character = Character:FindFirstChildOfClass("Humanoid");
    end;

    if not (v54 and (Character and Character.Health > 0)) then
        if u4 then
            hide();
        end;

        return;
    end;

    local v55, v56, v57 = nearest(v54.Position);

    if u4 then
        if u9 and u9.Parent then
            local Magnitude = (u9:GetPivot().Position - v54.Position).Magnitude;

            if Magnitude <= 12 then
                if v55 ~= u9 and (v57 <= 10 and v57 < Magnitude - 2) then
                    if u4 then
                        hide();
                    end;

                    if not build(v55, v56) then
                        return;
                    end;

                    u9 = v55;
                    u10 = v56;
                    ContextActionService:BindActionAtPriority("ClothingPromptBuy", function(p58, p59) -- Line: 117
                        -- upvalues: u4 (ref), u11 (ref), u12 (ref), u6 (ref)
                        if p59 == Enum.UserInputState.Begin then
                            if u4 and not u11 then
                                local os_clock_ret = os.clock();
                                u11 = true;
                                u12 = os_clock_ret;
                            end;
                        else
                            u11 = false;

                            if u6 then
                                u6.Size = UDim2.new(0, 0, 1, 0);
                            end;
                        end;

                        return Enum.ContextActionResult.Sink;
                    end, false, Enum.ContextActionPriority.High.Value, table.unpack(u1));
                end;

                return;
            end;
        end;

        hide();
    end;

    if v55 and v57 <= 10 then
        if u4 then
            hide();
        end;

        if not build(v55, v56) then
            return;
        end;

        u9 = v55;
        u10 = v56;
        ContextActionService:BindActionAtPriority("ClothingPromptBuy", function(p60, p61) -- Line: 117
            -- upvalues: u4 (ref), u11 (ref), u12 (ref), u6 (ref)
            if p61 == Enum.UserInputState.Begin then
                if u4 and not u11 then
                    local os_clock_ret = os.clock();
                    u11 = true;
                    u12 = os_clock_ret;
                end;
            else
                u11 = false;

                if u6 then
                    u6.Size = UDim2.new(0, 0, 1, 0);
                end;
            end;

            return Enum.ContextActionResult.Sink;
        end, false, Enum.ContextActionPriority.High.Value, table.unpack(u1));
    end;
end);
UserInputService.LastInputTypeChanged:Connect(updateChip);

for _, descendant in ipairs(workspace:GetDescendants()) do
    if descendant:IsA("Model") then
        if descendant:GetAttribute("Buyable") == "Clothing" then
            local Attribute = descendant:GetAttribute("Outfit");

            if type(Attribute) ~= "string" or Attribute == "" then
                Attribute = descendant.Name;
            end;

            if ShopData.Clothing[Attribute] then
                if ShopData.Clothing[Attribute].Price then
                    u3[descendant] = Attribute;
                end;
            end;
        end;
    end;
end;

workspace.DescendantAdded:Connect(register);
workspace.DescendantRemoving:Connect(function(p62) -- Line: 356
    -- upvalues: u3 (copy), u9 (ref), hide (copy)
    if u3[p62] then
        u3[p62] = nil;

        if p62 == u9 then
            hide();
        end;
    end;
end);

return v2;