-- Decompiled with Potassium's decompiler.

game:GetService("Players");
local Debris = game:GetService("Debris");
local ReplicatedStorage = game:GetService("ReplicatedStorage");
game:GetService("RunService");
game:GetService("UserInputService");
local Assets = ReplicatedStorage.Assets;
local Modules = ReplicatedStorage:WaitForChild("Modules");
ReplicatedStorage:WaitForChild("Remotes");
local _ = Modules.Metadata;
local _ = Modules.Utility;
local SoundManager = require(Modules.Shared.SoundManager);
local GlobalFunctions = require(Modules.GlobalFunctions);
local Visuals = workspace.World.Visuals;
local Meshes = Assets.Effects.Meshes;
local u10 = {
    New = function(p1, p2, p3, p4) -- Line: 30, Name: New
        -- upvalues: Meshes (copy), Visuals (copy), Debris (copy), SoundManager (copy), GlobalFunctions (copy)
        local math_random_ret = math.random(2, p3);
        local v5 = p4 and (p4.MINWIDTH or 0.1) or 0.1;
        local u6 = not (p4 and p4.Points) and {} or p4.Points;

        for i = 0, #u6 > 0 and -1 or math_random_ret do
            local math_random_ret2 = math.random(-1, 1);
            local math_random_ret3 = math.random(-1, 1);
            local math_random_ret4 = math.random(-1, 1);
            local Vector3_new_ret = Vector3.new(math_random_ret2, math_random_ret3, math_random_ret4);
            u6[#u6 + 1] = p1 + (p2 - p1).Unit * i * (p2 - p1).magnitude / math_random_ret + ((i == 0 or i == math_random_ret) and Vector3.new(0, 0, 0) or Vector3_new_ret);
            local _ = i;
        end;

        for i = 1, #u6 do
            if u6[i + 1] ~= nil then
                local u7 = Meshes.LightningPart:Clone();
                u7.Parent = Visuals;
                u7.Size = Vector3.new(v5, v5, (u6[i] - u6[i + 1]).Magnitude);
                u7.CFrame = CFrame.new((u6[i] + u6[i + 1]) / 2, u6[i + 1]);

                if p4 and p4.Color then
                    u7.Color = p4.Color;
                end;

                Debris:AddItem(u7, 0.5);

                if not (p4 and p4.NoSound) then
                    SoundManager.AddSound("Sparks", {
                        Parent = u7
                    }, "Client", {
                        Duration = 0.5
                    });
                end;

                coroutine.wrap(function() -- Line: 80
                    -- upvalues: u7 (copy), u6 (ref), i (copy), GlobalFunctions (ref)
                    local v8 = {
                        Duration = 0.5,
                        Instance = u7,
                        EasingStyle = Enum.EasingStyle.Exponential
                    };
                    local v9 = {
                        Transparency = 1,
                        Size = Vector3.new(0, 0, (u6[i] - u6[i + 1]).Magnitude)
                    };
                    GlobalFunctions.Tween(v8, v9);
                end)();
            end;

            task.wait();
            local _ = i;
        end;
    end
};

function u10.Aura(p11, p12) -- Line: 99
    -- upvalues: GlobalFunctions (copy), SoundManager (copy), u10 (copy)
    local v13 = p12 and (p12.Amt or 3) or 3;
    local v14 = p12 and (p12.DelayTime or 0.1) or 0.1;
    local v15 = p12 and (p12.WidthScale or 1) or 1;
    local RootAndHumanoid = GlobalFunctions.GetRootAndHumanoid(p11);
    local v16 = p12 and (p12.MinSegments or 3) or 3;
    local v17 = p12 and p12.MaxSegments or 10;

    for i = 1, v13 do
        SoundManager.AddSound("Sparks", {
            Parent = RootAndHumanoid,
            PlaybackSpeed = math.random(75, 125) / 100
        }, "Client", {
            Duration = 1.5
        });
        local math_random_ret = math.random(-3, 3);
        local math_random_ret2 = math.random(-3, 3);
        local math_random_ret3 = math.random(-5, 5);
        local math_random_ret4 = math.random(-3, 3);
        local math_random_ret5 = math.random(-3, 3);
        local math_random_ret6 = math.random(-5, 5);
        local v18 = RootAndHumanoid.CFrame * CFrame.new(math_random_ret, math_random_ret2, math_random_ret3).Position;
        local v19 = RootAndHumanoid.CFrame * CFrame.new(math_random_ret4, math_random_ret5, math_random_ret6).Position;
        local math_random_ret7 = math.random(v16, v17);
        local v20 = {
            MINWIDTH = math.random(1, 10) / 10 * v15
        };
        u10.New(v18, v19, math_random_ret7, v20);
        wait(v14);
        local _ = i;
    end;
end;

return u10;