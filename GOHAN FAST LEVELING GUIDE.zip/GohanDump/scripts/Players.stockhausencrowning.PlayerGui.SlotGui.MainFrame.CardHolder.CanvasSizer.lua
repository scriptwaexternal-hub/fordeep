-- Decompiled with Potassium's decompiler.

local script_Parent = script.Parent;
local UIListLayout = script_Parent:WaitForChild("UIListLayout");
UIListLayout:GetPropertyChangedSignal("AbsoluteContentSize"):Connect(function() -- Line: 4, Name: sync
    -- upvalues: script_Parent (copy), UIListLayout (copy)
    script_Parent.CanvasSize = UDim2.fromOffset(math.ceil(UIListLayout.AbsoluteContentSize.X), 0);
end);
script_Parent.CanvasSize = UDim2.fromOffset(math.ceil(UIListLayout.AbsoluteContentSize.X), 0);