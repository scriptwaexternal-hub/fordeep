-- Decompiled with Potassium's decompiler.

local Parent = require(script.Parent.Parent);
local UI = Parent.UI;
task.defer(function() -- Line: 4
    -- upvalues: Parent (copy), UI (copy)
    local v1, v2 = Parent.Util.Retry(function() -- Line: 6
        -- upvalues: Parent (ref)
        return Parent.Service.Marketplace:PlayerOwnsAssetAsync(Parent.LocalPlayer, 172732271);
    end);
    local v3 = v1 and v2;

    if (Parent.LocalPlayer:GetAttribute("_KDonationLevel") or 0) > 3 then
        return;
    end;

    local v4 = UI.new("Button")({
        LayoutOrder = 10,
        Name = "adminModelButton",
        Icon = "rbxasset://textures/ui/common/robux.png",
        IconProperties = {
            ImageColor3 = UI.Theme.PrimaryText
        },
        IconRightAlign = true,
        Label = "<b>Get Kohl\'s Admin</b>",
        TextXAlignment = Enum.TextXAlignment.Left,
        Size = UDim2.new(0.75, 0, 0, 32),
        UI.new("Frame")({
            BackgroundTransparency = 1,
            AnchorPoint = Vector2.new(0, 0.5),
            Position = UDim2.new(0, 0, 0.5, 0),
            Size = UDim2.new(0, 28, 0, 28),
            UI.new("ImageLabel")({
                BackgroundTransparency = 1,
                Image = "rbxasset://textures/ui/InspectMenu/ico_favorite@2x.png",
                ImageTransparency = 0.875,
                Size = UDim2.new(0, 28, 0, 28),
                ImageColor3 = Color3.new(0, 0, 0)
            }),
            UI.new("ImageButton")({
                BackgroundTransparency = 1,
                Position = UDim2.new(0, 2, 0, 2),
                Size = UDim2.new(0, 24, 0, 24),
                Image = "rbxasset://textures/ui/InspectMenu/ico_favorite@2x.png",
                ImageColor3 = Color3.new(1, 0.8, 0),

                Activated = function() -- Line: 45, Name: Activated
                    -- upvalues: Parent (ref)
                    pcall(function() -- Line: 46
                        -- upvalues: Parent (ref)
                        Parent.Service.AvatarEditor:PromptSetFavorite(172732271, 1, true);
                    end);
                end,

                UI.new("Tooltip")({
                    Text = "Add to Favorites"
                })
            })
        }),
        UI.new("TextLabel")({
            Name = "Price",
            AutoLocalize = false,
            BackgroundTransparency = 1,
            TextWrapped = true,
            RichText = true,
            AutomaticSize = Enum.AutomaticSize.XY,
            FontFace = UI.Theme.FontMono,
            TextSize = UI.Theme.FontSizeLarge,
            TextColor3 = UI.Theme.PrimaryText,
            TextStrokeColor3 = UI.Theme.Primary,
            TextStrokeTransparency = UI.Theme.TextStrokeTransparency,

            Size = function() -- Line: 67, Name: Size
                -- upvalues: UI (ref)
                return UDim2.new(0, UI.Theme.FontSizeLarge(), 0, 32);
            end,

            Text = v3 and "<b>OWNED</b>" or "<b>FREE</b>"
        }),
        Activated = not v3 and function() -- Line: 76
            -- upvalues: Parent (ref)
            Parent.client.lastAttemptedPurchase = true;

            if Parent.client.AllowThirdPartySales then
                Parent.Service.Marketplace:PromptPurchase(Parent.LocalPlayer, 172732271);

                return;
            end;

            Parent.client.purchaseKADialog.Visible(true);
        end or nil
    });
    local v5 = UI.new("Frame")({
        Name = "Donations",
        AutomaticSize = Enum.AutomaticSize.Y,
        BackgroundTransparency = 1,
        Size = UDim2.new(1, -2, 0, 0),
        LayoutOrder = 11,
        UI.new("UIListLayout")({
            Wraps = true,
            SortOrder = Enum.SortOrder.LayoutOrder,
            FillDirection = Enum.FillDirection.Horizontal,
            HorizontalFlex = Enum.UIFlexAlignment.SpaceEvenly,
            HorizontalAlignment = Enum.HorizontalAlignment.Center,
            Padding = UI.Theme.PaddingWithStroke
        })
    });
    Parent.client.generateDonationButtons(v5);
    local u6 = UI.new("Dialog")({
        Parent = UI.LayerTop,
        Title = "❤️ Kohl\'s Admin?",
        Text = "<b>Stop playing. Take command.</b> Get the same powerful tools used here for your own games.\n<font transparency=\"0.5\">Total control, advanced security, and professional moderation are yours for <b>free</b>.</font>",
        Visible = false,
        Draggable = true,
        ExitButton = true,
        BackgroundTransparency = 0,
        AnchorPoint = Vector2.new(0.5, 0.5),
        Position = UDim2.new(0.5, 0, 0.5, 0),
        Size = UDim2.new(0, 480, 0, 0),
        Modal = true,
        ZIndex = 999,
        v4,
        v5
    });
    local u7 = 0;
    local u8 = nil;
    u8 = Parent.Hook.runPreparedCommands:Connect(function() -- Line: 124
        -- upvalues: Parent (ref), u8 (ref), u6 (ref), u7 (ref)
        if Parent.Data.settings.getKohlsAdminPopup == false or Parent.LocalPlayer:GetAttribute("_KDonationLevel") > 3 then
            u8:Disconnect();
            u6:Destroy();
        end;

        u7 = u7 + 1;

        if u7 == 4 then
            u8:Disconnect();
            u6.Visible(true);
        end;
    end);
end);

return true;