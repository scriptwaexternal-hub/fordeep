-- Decompiled with Potassium's decompiler.

local Debris = game:GetService("Debris");
local ReplicatedStorage = game:GetService("ReplicatedStorage");
local Modules = ReplicatedStorage:WaitForChild("Modules");
local SoundManager = require(Modules.Shared.SoundManager);
local GlobalFunctions = require(Modules.GlobalFunctions);
local Visuals = workspace.World.Visuals;
local Meshes = ReplicatedStorage.Assets.Effects.Meshes;

return {
    Start = function(p1) -- Line: 24
        -- upvalues: Meshes (copy), Visuals (copy), SoundManager (copy), GlobalFunctions (copy), Debris (copy)
        local Character = p1.Character;

        if not Character then
            return;
        end;

        local v2 = Character:FindFirstChild("Left Arm") or Character:FindFirstChild("HumanoidRootPart");

        if not v2 then
            return;
        end;

        local u3 = Meshes.Skills.Blasts:FindFirstChild("Energy Crash Ball", true):Clone();
        u3.Name = "EnergyCrash" .. Character.Name;
        u3.CFrame = v2.CFrame * CFrame.new(0, -2, -0.2);
        u3.Anchored = false;
        u3.Size = Vector3.new(0, 0, 0);
        u3.Transparency = 1;
        u3.Material = Enum.Material.Neon;
        u3.Color = p1.Color or Color3.fromRGB(255, 255, 255);
        u3.Parent = Visuals;
        local WeldConstraint = Instance.new("WeldConstraint");
        WeldConstraint.Part0 = u3;
        WeldConstraint.Part1 = v2;
        WeldConstraint.Parent = u3;
        SoundManager.AddSound("Beam Charge", {
            Parent = u3
        }, "Client");
        GlobalFunctions.Tween({
            Instance = u3,
            Duration = p1.Duration or 1
        }, {
            Size = Vector3.new(2, 2, 2),
            Transparency = 0
        }).Completed:Once(function() -- Line: 51
            -- upvalues: u3 (copy)
            for _, descendant in ipairs(u3:GetDescendants()) do
                if descendant:IsA("ParticleEmitter") then
                    descendant.Enabled = true;
                end;
            end;
        end);
        task.spawn(function() -- Line: 59
            -- upvalues: Character (copy), u3 (copy), WeldConstraint (copy), Debris (ref)
            while Character:FindFirstChild("Charging Beam") do
                if Character:FindFirstChild("Stun") then
                    u3:Destroy();

                    return;
                end;

                task.wait();
            end;

            WeldConstraint:Destroy();
            u3.Anchored = true;
            Debris:AddItem(u3, 10);
        end);
    end
};