-- Decompiled with Potassium's decompiler.

local RunService = game:GetService("RunService");
local TweenService = game:GetService("TweenService");
local Interpolate = require(script.Parent.Interpolate);
local State = require(script.Parent.State);
require(script.Parent.Type);
local u1 = {};
u1.__index = u1;
local u2 = setmetatable({}, {
    __mode = "_k"
});
u1._tweens = u2;

function u1.new(u3, p4) -- Line: 14
    -- upvalues: State (copy), u1 (copy)
    if type(u3) == "function" then
        u3 = State.compute(u3);
    elseif State.isState(u3) and u3._computation == nil then
        u3 = State.compute(function() -- Line: 19
            -- upvalues: u3 (ref)
            return u3();
        end);
    else
        u3 = State.new(u3);
    end;

    u3._tweenInfo = p4;
    u3._tweenStart = u3._value;
    u1._tweens[u3] = true;

    return u3;
end;

RunService.Heartbeat:Connect(function() -- Line: 34
    -- upvalues: u2 (copy), State (copy), TweenService (copy), Interpolate (copy)
    for i in u2 do
        if i._tweenInit then
            local os_clock_ret = os.clock();
            local v5 = os_clock_ret - i._tweenInit;

            if v5 >= 0 then
                local v6 = State.raw(i._tweenInfo);
                local v7 = v5 / v6.Time;

                if v7 < (v6.Reverses and 2 or 1) then
                    if v6.Reverses then
                        v7 = 1 - (v7 - 1);
                    end;

                    local Value = TweenService:GetValue(v7, v6.EasingStyle, v6.EasingDirection);
                    i._value = Interpolate(i._tweenStart, i._tweenGoal, Value);
                else
                    if (i._tweenRepeat or 0) > 0 then
                        i._tweenRepeat = i._tweenRepeat - 1;
                        i._tweenInit = os_clock_ret + v6.DelayTime;
                    else
                        i._tweenInit = nil;
                    end;

                    local v8;

                    if v6.Reverses then
                        v8 = i._tweenStart;
                    else
                        v8 = i._tweenGoal;
                    end;

                    i._value = v8;
                end;

                task.spawn(i._update, i, true, true, true);
            end;
        end;
    end;
end);

return u1;