-- Decompiled with Potassium's decompiler.

local Debris = game:GetService("Debris");
local ReplicatedStorage = game:GetService("ReplicatedStorage");
local RunService = game:GetService("RunService");
local Assets = ReplicatedStorage.Assets;
local Modules = ReplicatedStorage:WaitForChild("Modules");
local GlobalFunctions = require(Modules.GlobalFunctions);
local workspace_World = workspace.World;
local Visuals = workspace_World.Visuals;
local Live = workspace_World.Live;
local Meshes = Assets.Effects.Meshes;
local Color3_fromRGB_ret = Color3.fromRGB(117, 0, 0);
local v1 = {};

local function Blood_Splatter(p2, p3) -- Line: 68
    -- upvalues: Color3_fromRGB_ret (copy), Meshes (copy), Visuals (copy), Debris (copy), GlobalFunctions (copy)
    local v4 = p3 and p3.Color or Color3_fromRGB_ret;
    local v5 = p3 and p3.MAX_SIZE and math.random(1, p3.MAX_SIZE * 100) / 100 or math.random(1, 200) / 100;
    local v6 = p3 and p3.Duration or 10;
    local u7 = Meshes.Blood:Clone();
    local TrailTing = u7:FindFirstChild("TrailTing");

    if TrailTing then
        TrailTing:Destroy();
    end;

    local A1 = u7:FindFirstChild("A1");
    local A2 = u7:FindFirstChild("A2");

    if A1 then
        A1:Destroy();
    end;

    if A2 then
        A2:Destroy();
    end;

    u7.Anchored = true;
    u7.Color = v4;
    u7.Size = Vector3.new(0.05, 0.05, 0.1);
    local v8 = p2.Position + p2.Normal * 0.02;
    local CFrame_new_ret = CFrame.new(v8, v8 + p2.Normal);
    local CFrame_Angles = CFrame.Angles;
    local math_random_ret = math.random(0, 359);
    u7.CFrame = CFrame_new_ret * CFrame_Angles(0, 0, (math.rad(math_random_ret)));
    u7.Parent = Visuals;
    Debris:AddItem(u7, v6);
    GlobalFunctions.Tween({
        Duration = 1,
        Instance = u7,
        EasingStyle = Enum.EasingStyle.Exponential,
        EasingDirection = Enum.EasingDirection.Out
    }, {
        Size = Vector3.new(v5, v5, 0.1)
    });
    task.delay(v6 - 1, function() -- Line: 103
        -- upvalues: u7 (copy), GlobalFunctions (ref)
        if u7.Parent then
            GlobalFunctions.TransparencyTween({
                DURATION = 4,
                Instance = u7
            });
        end;
    end);
end;

local function launchDrop(p9, p10, p11, u12) -- Line: 111
    -- upvalues: Meshes (copy), Visuals (copy), Debris (copy), GlobalFunctions (copy), RunService (copy), Live (copy), Blood_Splatter (copy)
    local u13 = Meshes.Blood:Clone();
    u13.Anchored = false;
    u13.Size = Vector3.new(1, 1, 1) * (math.random(3, 8) / 100);
    u13.Color = p11;
    u13.TrailTing.Color = ColorSequence.new(p11);
    u13.CFrame = p9.CFrame * CFrame.new(0, p9.Size.Y / 2, 0);
    u13.Parent = Visuals;
    local math_random_ret = math.random(-30, 30);
    local math_random_ret2 = math.random(-30, 30);
    u13.AssemblyAngularVelocity = Vector3.new(math_random_ret, math_random_ret2, math.random(-30, 30));
    Debris:AddItem(u13, p10);
    local Attachment = Instance.new("Attachment");
    Attachment.Parent = u13;
    local LinearVelocity = Instance.new("LinearVelocity");
    LinearVelocity.MaxForce = math.max(u13.AssemblyMass, 1) * 12000;
    LinearVelocity.Visible = false;
    local math_random_ret3 = math.random(-20, 20);
    local math_random_ret4 = math.random(1, 10);
    LinearVelocity.VectorVelocity = Vector3.new(math_random_ret3, math_random_ret4, math.random(-20, 20));
    LinearVelocity.Attachment0 = Attachment;
    LinearVelocity.Parent = Attachment;
    Debris:AddItem(LinearVelocity, 0.2);
    Debris:AddItem(Attachment, 0.2);
    task.delay(p10 - 1, function() -- Line: 136
        -- upvalues: u13 (copy), GlobalFunctions (ref)
        if u13.Parent then
            GlobalFunctions.TransparencyTween({
                Instance = u13
            });
        end;
    end);
    local Position = u13.Position;
    local u14 = nil;
    u14 = RunService.Heartbeat:Connect(function() -- Line: 146
        -- upvalues: u13 (copy), u14 (ref), Position (ref), GlobalFunctions (ref), Visuals (ref), Live (ref), Blood_Splatter (ref), u12 (copy)
        if not u13.Parent then
            u14:Disconnect();

            return;
        end;

        local Position2 = u13.Position;
        local v15 = Position2 - Position;
        local v16 = v15.Magnitude > 0 and GlobalFunctions.CastRay(Position, v15, { Visuals, Live });

        if not v16 then
            Position = Position2;

            return;
        end;

        u14:Disconnect();
        Blood_Splatter({
            Position = v16.Position,
            Normal = v16.Normal
        }, u12);
        u13:Destroy();
    end);
end;

function v1.Splatter(p17, p18) -- Line: 167
    -- upvalues: Color3_fromRGB_ret (copy), launchDrop (copy)
    local v19 = p18 and (p18.MaxTime or 4) or 4;
    local v20 = p18 and p18.Amount or math.random(1, 5);
    local v21 = p18 and p18.Color or Color3_fromRGB_ret;

    for i = 1, v20 do
        launchDrop(p17, v19, v21, p18);
        local _ = i;
    end;
end;

return v1;