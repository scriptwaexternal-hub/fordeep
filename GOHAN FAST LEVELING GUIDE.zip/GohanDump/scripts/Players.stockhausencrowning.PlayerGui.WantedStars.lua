-- Decompiled with Potassium's decompiler.

local Players = game:GetService("Players");
local TweenService = game:GetService("TweenService");
local LocalPlayer = Players.LocalPlayer;
local Color3_fromRGB_ret = Color3.fromRGB(255, 208, 60);
local Color3_fromRGB_ret2 = Color3.fromRGB(70, 74, 84);
local Color3_fromRGB_ret3 = Color3.fromRGB(18, 20, 24);
local ScreenGui = Instance.new("ScreenGui");
ScreenGui.Name = "WantedStarsGui";
ScreenGui.ResetOnSpawn = false;
ScreenGui.DisplayOrder = 7;
ScreenGui.Parent = LocalPlayer:WaitForChild("PlayerGui");
local Frame = Instance.new("Frame");
Frame.Size = UDim2.new(0, 170, 0, 56);
Frame.Position = UDim2.new(0, 14, 1, -70);
Frame.BackgroundTransparency = 1;
Frame.Visible = false;
Frame.Parent = ScreenGui;
local u1 = {};

for i = 1, 5 do
    local TextLabel = Instance.new("TextLabel");
    TextLabel.Size = UDim2.new(0, 30, 0, 30);
    TextLabel.Position = UDim2.new(0, (i - 1) * 34, 0, 0);
    TextLabel.BackgroundTransparency = 1;
    TextLabel.Font = Enum.Font.Bangers;
    TextLabel.TextSize = 30;
    TextLabel.Text = utf8.char(9733);
    TextLabel.TextColor3 = Color3_fromRGB_ret2;
    TextLabel.TextTransparency = 0.35;
    TextLabel.Parent = Frame;
    local UIStroke = Instance.new("UIStroke");
    UIStroke.Color = Color3_fromRGB_ret3;
    UIStroke.Thickness = 2;
    UIStroke.Parent = TextLabel;
    u1[i] = TextLabel;
    local _ = i;
end;

local TextLabel = Instance.new("TextLabel");
TextLabel.Size = UDim2.new(1, 0, 0, 20);
TextLabel.Position = UDim2.new(0, 0, 0, 34);
TextLabel.BackgroundTransparency = 1;
TextLabel.Font = Enum.Font.Bangers;
TextLabel.TextSize = 20;
TextLabel.Text = "INFAMY";
TextLabel.TextColor3 = Color3_fromRGB_ret;
TextLabel.TextStrokeTransparency = 0.15;
TextLabel.TextStrokeColor3 = Color3_fromRGB_ret3;
TextLabel.TextXAlignment = Enum.TextXAlignment.Center;
TextLabel.Parent = Frame;
local u2 = 0;

local function render(p3) -- Line: 63
    -- upvalues: Frame (copy), u1 (copy), Color3_fromRGB_ret (copy), Color3_fromRGB_ret2 (copy), u2 (ref), TweenService (copy)
    Frame.Visible = p3 > 0;

    for i = 1, 5 do
        local v4 = i <= p3;
        u1[i].TextColor3 = v4 and Color3_fromRGB_ret or Color3_fromRGB_ret2;
        u1[i].TextTransparency = v4 and 0 or 0.35;
        local _ = i;
    end;

    if u2 < p3 then
        for i = u2 + 1, p3 do
            local v5 = u1[i];
            v5.TextSize = 44;
            TweenService:Create(v5, TweenInfo.new(0.25, Enum.EasingStyle.Back, Enum.EasingDirection.Out), {
                TextSize = 30
            }):Play();
            local _ = i;
        end;
    end;

    u2 = p3;
end;

render(LocalPlayer:GetAttribute("WantedStars") or 0);
LocalPlayer:GetAttributeChangedSignal("WantedStars"):Connect(function() -- Line: 82
    -- upvalues: render (copy), LocalPlayer (copy)
    render(LocalPlayer:GetAttribute("WantedStars") or 0);
end);