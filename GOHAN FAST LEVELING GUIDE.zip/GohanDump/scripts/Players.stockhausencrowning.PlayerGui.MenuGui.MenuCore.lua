-- Decompiled with Potassium's decompiler.

local ReplicatedStorage = game:GetService("ReplicatedStorage");
local UserInputService = game:GetService("UserInputService");
local Players = game:GetService("Players");
local Modules = ReplicatedStorage:WaitForChild("Modules");
local Remotes = ReplicatedStorage:WaitForChild("Remotes");
local Metadata = Modules.Metadata;
local _ = Modules.Shared;
local _ = Modules.Utility;
require(Modules.GlobalFunctions);
local ControlData = require(Metadata.ControlData.ControlData);
local StatRetrieveRemote = ReplicatedStorage.Remotes.StatRetrieveRemote;
local SettingsRemote = Remotes.SettingsRemote;
local LocalPlayer = Players.LocalPlayer;
local v1 = LocalPlayer.Character or LocalPlayer.CharacterAdded:Wait();
v1:FindFirstChild("HumanoidRootPart");
v1:WaitForChild("Humanoid");
local u2 = {};

for _, child in pairs(script:GetChildren()) do
    if child:IsA("ModuleScript") then
        u2[child.Name] = require(child);
    end;
end;

UserInputService.InputBegan:Connect(function(p3, p4) -- Line: 41
    -- upvalues: ControlData (copy), u2 (copy), LocalPlayer (copy)
    if p4 then
        return;
    end;

    local u5 = p3.KeyCode == Enum.KeyCode.Unknown and p3.UserInputType.Name or p3.KeyCode.Name;

    for i, v in pairs(ControlData.Controls.Menu_UI) do
        if typeof(v) == "table" then
            local u6 = i;

            for _, v2 in ipairs(v) do
                if u5 == v2 then
                    pcall(function() -- Line: 51
                        -- upvalues: u2 (ref), u6 (copy), LocalPlayer (ref), ControlData (ref), u5 (copy)
                        local v7 = u2.MenuHandler[u6];

                        if not LocalPlayer.Character then
                            LocalPlayer.CharacterAdded:Wait();
                        end;

                        if ControlData.Controls.Menu_UI.Enabled == false then
                            return;
                        end;

                        task.spawn(function() -- Line: 57
                            -- upvalues: ControlData (ref)
                            ControlData.Controls.Menu_UI.Enabled = false;
                            task.wait(ControlData.Controls.Menu_UI.Debounce_Time);
                            ControlData.Controls.Menu_UI.Enabled = true;
                        end);

                        if typeof(v7) == "table" then
                            v7.Execute(u6, u5);

                            return;
                        end;

                        v7(u6, u5);
                    end);
                    break;
                end;
            end;
        end;
    end;
end);
SettingsRemote.OnClientEvent:Connect(function() -- Line: 79
    -- upvalues: LocalPlayer (copy), StatRetrieveRemote (copy)
    local MusicManager = LocalPlayer.PlayerScripts:FindFirstChild("MusicManager", true);

    if MusicManager then
        local v8 = StatRetrieveRemote:InvokeServer("Music");
        MusicManager:WaitForChild("Volume").Value = v8;
    end;
end);
Remotes:WaitForChild("TouchActionRemote").Event:Connect(function(p9, p10, p11) -- Line: 91
    -- upvalues: ControlData (copy), u2 (copy)
    if p9 ~= "Menu_UI" then
        return;
    end;

    if ControlData.Controls.Menu_UI.Enabled == false then
        return;
    end;

    local v12 = u2.MenuHandler and u2.MenuHandler[p10];

    if not v12 then
        return;
    end;

    task.spawn(function() -- Line: 99
        -- upvalues: ControlData (ref)
        ControlData.Controls.Menu_UI.Enabled = false;
        task.wait(ControlData.Controls.Menu_UI.Debounce_Time);
        ControlData.Controls.Menu_UI.Enabled = true;
    end);

    if typeof(v12) == "table" then
        v12.Execute(p10, p11);

        return;
    end;

    v12(p10, p11);
end);