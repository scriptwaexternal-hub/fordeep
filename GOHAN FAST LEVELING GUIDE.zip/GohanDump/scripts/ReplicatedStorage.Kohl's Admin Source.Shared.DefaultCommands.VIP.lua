-- Decompiled with Potassium's decompiler.

local Util = require(script.Parent.Parent:WaitForChild("Util"));

if Util.Service.Run:IsServer() then
    local u1 = {};
    Util.SafePlayerAdded(function(u2) -- Line: 8
        -- upvalues: u1 (copy), Util (copy)
        u1[u2] = u2.CharacterAppearanceLoaded:Connect(function(p3) -- Line: 9
            -- upvalues: Util (ref), u2 (copy)
            task.defer(Util.Humanoid.reapplyDescription, u2);
        end);
    end);
    Util.Service.Players.PlayerRemoving:Connect(function(p4) -- Line: 14
        -- upvalues: u1 (copy)
        if u1[p4] and u1[p4].Connected then
            u1[p4]:Disconnect();
            u1[p4] = nil;
        end;
    end);
end;

return {
    {
        name = "normal",
        description = "Returns one or more player(s) to their normal appearance.",
        aliases = { "uninfect" },
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) to return to normal."
            } },

        run = function(p5, p6) -- Line: 35, Name: run
            -- upvalues: Util (copy)
            for _, v in p6 do
                p5._K.Remote.CameraOffset:Fire(v, Vector3.new(0, 0, 0));
                local Character = v.Character;
                local v7;

                if Character then
                    v7 = Character:FindFirstChild("_KCape");
                else
                    v7 = Character;
                end;

                if v7 then
                    v7:Destroy();
                end;

                local v8 = Character and Character:GetAttribute("_KCreeper") and p5._K.Registry.commands.uncreeper;

                if v8 then
                    v8.env.apply(v);
                end;

                local v9;

                if Character then
                    v9 = Character:FindFirstChild("_KDogSeat");
                else
                    v9 = Character;
                end;

                local v10, v11, v12, v13;

                if v9 then
                    v9:Destroy();
                    local undog = p5._K.Registry.commands.undog;

                    if not undog then
                        task.spawn(Util.Humanoid.resetDescription, v);
                        v10 = Character and p5._K.Registry.commands.crm;

                        if v10 then
                            task.spawn(v10.env.update, Character);
                        end;

                        v11 = p5._K.Registry.commands.infect;

                        if v11 then
                            v12 = v11.env.infected[Character];

                            if v12 then
                                v12:Disconnect();
                                v11.env.infected[Character] = nil;
                                v13 = Character and Character:FindFirstChild("Head") and Character.Head:FindFirstChild("face");

                                if v13 and v13:GetAttribute("_KInfectOriginal") then
                                    v13.Texture = v13:GetAttribute("_KInfectOriginal");
                                    v13:SetAttribute("_KInfectOriginal");
                                end;
                            end;
                        end;
                    end;

                    local Humanoid = Character:FindFirstChild("Humanoid");

                    if Humanoid then
                        if Humanoid.RigType == Enum.HumanoidRigType.R6 then
                            undog.env.R6(Character);
                        else
                            undog.env.R15(Character);
                        end;

                        task.spawn(Util.Humanoid.resetDescription, v);
                        v10 = Character and p5._K.Registry.commands.crm;

                        if v10 then
                            task.spawn(v10.env.update, Character);
                        end;

                        v11 = p5._K.Registry.commands.infect;

                        if v11 then
                            v12 = v11.env.infected[Character];

                            if v12 then
                                v12:Disconnect();
                                v11.env.infected[Character] = nil;
                                v13 = Character and Character:FindFirstChild("Head") and Character.Head:FindFirstChild("face");

                                if v13 and v13:GetAttribute("_KInfectOriginal") then
                                    v13.Texture = v13:GetAttribute("_KInfectOriginal");
                                    v13:SetAttribute("_KInfectOriginal");
                                end;
                            end;
                        end;
                    end;
                else
                    task.spawn(Util.Humanoid.resetDescription, v);
                    v10 = Character and p5._K.Registry.commands.crm;

                    if v10 then
                        task.spawn(v10.env.update, Character);
                    end;

                    v11 = p5._K.Registry.commands.infect;

                    if v11 then
                        v12 = v11.env.infected[Character];

                        if v12 then
                            v12:Disconnect();
                            v11.env.infected[Character] = nil;
                            v13 = Character and Character:FindFirstChild("Head") and Character.Head:FindFirstChild("face");

                            if v13 and v13:GetAttribute("_KInfectOriginal") then
                                v13.Texture = v13:GetAttribute("_KInfectOriginal");
                                v13:SetAttribute("_KInfectOriginal");
                            end;
                        end;
                    end;
                end;
            end;
        end
    },
    {
        name = "fire",
        description = "Adds fire to one or more player(s).",
        aliases = { "🔥" },
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) to add the fire to."
            }, {
                type = "number",
                name = "Size",
                description = "The size of the fire.",
                optional = true
            }, {
                type = "color",
                name = "Color",
                description = "The color of the fire.",
                optional = true
            }, {
                type = "color",
                name = "SecondaryColor",
                description = "The secondary color of the fire.",
                optional = true
            } },

        run = function(p14, p15, p16, p17, p18) -- Line: 126, Name: run
            local v19 = p14._K.Auth.getRank(p14.from) <= 1 and 5 or (1 / 0);
            local math_min_ret = math.min(p16 or 5, v19);

            for _, v in p15 do
                local v20 = v.Character and (v.Character:FindFirstChild("HumanoidRootPart") or v.Character.PrimaryPart);

                if v20 then
                    local _KFire = v20:FindFirstChild("_KFire");

                    if _KFire then
                        _KFire:Destroy();
                    end;

                    local v21 = p14._K.Flux.new("Fire")({
                        Name = "_KFire",
                        Parent = v20,
                        Size = math_min_ret
                    });

                    if p17 then
                        v21.Color = p17;
                        v21.SecondaryColor = p18 or p17;
                    end;
                end;
            end;
        end
    },
    {
        name = "unfire",
        description = "Removes fire from one or more player(s).",
        aliases = { "un🔥" },
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) to remove the fire from."
            } },

        run = function(p22, p23) -- Line: 162, Name: run
            for _, v in p23 do
                local v24 = v.Character and (v.Character:FindFirstChild("HumanoidRootPart") or v.Character.PrimaryPart);

                if v24 then
                    local _KFire = v24:FindFirstChild("_KFire");

                    if _KFire then
                        _KFire:Destroy();
                    end;
                end;
            end;
        end
    },
    {
        name = "smoke",
        description = "Adds smoke to one or more player(s).",
        aliases = { "💨" },
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) to add the smoke to."
            }, {
                type = "color",
                name = "Color",
                description = "The color of the smoke.",
                optional = true
            } },

        run = function(p25, p26, p27, p28) -- Line: 194, Name: run
            for _, v in p26 do
                local v29 = v.Character and (v.Character:FindFirstChild("HumanoidRootPart") or v.Character.PrimaryPart);

                if v29 then
                    local _KSmoke = v29:FindFirstChild("_KSmoke");

                    if _KSmoke then
                        _KSmoke:Destroy();
                    end;

                    local v30 = p25._K.Flux.new("Smoke")({
                        Name = "_KSmoke",
                        RiseVelocity = 0,
                        Parent = v29
                    });

                    if p27 then
                        v30.Color = p27;
                    end;
                end;
            end;
        end
    },
    {
        name = "unsmoke",
        description = "Removes smoke from one or more player(s).",
        aliases = { "un💨" },
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) to remove the smoke from."
            } },

        run = function(p31, p32) -- Line: 228, Name: run
            for _, v in p32 do
                local v33 = v.Character and (v.Character:FindFirstChild("HumanoidRootPart") or v.Character.PrimaryPart);

                if v33 then
                    local _KSmoke = v33:FindFirstChild("_KSmoke");

                    if _KSmoke then
                        _KSmoke:Destroy();
                    end;
                end;
            end;
        end
    },
    {
        name = "sparkles",
        description = "Adds sparkles to one or more player(s).",
        aliases = { "✨" },
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) to add the sparkles to."
            }, {
                type = "color",
                name = "Color",
                description = "The color of the sparkles.",
                optional = true
            } },

        run = function(p34, p35, p36, p37) -- Line: 260, Name: run
            for _, v in p35 do
                local v38 = v.Character and (v.Character:FindFirstChild("HumanoidRootPart") or v.Character.PrimaryPart);

                if v38 then
                    local _KSparkles = v38:FindFirstChild("_KSparkles");

                    if _KSparkles then
                        _KSparkles:Destroy();
                    end;

                    local v39 = p34._K.Flux.new("Sparkles")({
                        Name = "_KSparkles",
                        Parent = v38
                    });

                    if p36 then
                        v39.SparkleColor = p36;
                    end;
                end;
            end;
        end
    },
    {
        name = "unsparkles",
        description = "Removes sparkles from one or more player(s).",
        aliases = { "un✨" },
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) to remove the sparkles from."
            } },

        run = function(p40, p41) -- Line: 293, Name: run
            for _, v in p41 do
                local v42 = v.Character and (v.Character:FindFirstChild("HumanoidRootPart") or v.Character.PrimaryPart);

                if v42 then
                    local _KSparkles = v42:FindFirstChild("_KSparkles");

                    if _KSparkles then
                        _KSparkles:Destroy();
                    end;
                end;
            end;
        end
    },
    {
        name = "light",
        description = "Adds a light to one or more player(s).",
        aliases = { "💡", "lamp", "lite" },
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) to add the light to."
            }, {
                type = "number",
                name = "Range",
                description = "The range of the light.",
                optional = true
            }, {
                type = "color",
                name = "Color",
                description = "The color of the light.",
                optional = true
            } },

        run = function(p43, p44, p45, p46) -- Line: 331, Name: run
            local v47 = p43._K.Auth.getRank(p43.from) <= 1 and 10 or (1 / 0);
            local math_min_ret = math.min(p45 or 8, v47);

            for _, v in p44 do
                local v48 = v.Character and (v.Character:FindFirstChild("HumanoidRootPart") or v.Character.PrimaryPart);

                if v48 then
                    local _KLight = v48:FindFirstChild("_KLight");

                    if _KLight then
                        _KLight:Destroy();
                    end;

                    p43._K.Flux.new("PointLight")({
                        Name = "_KLight",
                        Parent = v48,
                        Range = math_min_ret,
                        Color = p46 or Color3.new(1, 1, 1)
                    });
                end;
            end;
        end
    },
    {
        name = "unlight",
        description = "Removes a light from one or more player(s).",
        aliases = { "un💡", "unlamp", "unlite" },
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) to remove the light from."
            } },

        run = function(p49, p50) -- Line: 364, Name: run
            for _, v in p50 do
                local v51 = v.Character and (v.Character:FindFirstChild("HumanoidRootPart") or v.Character.PrimaryPart);

                if v51 then
                    local _KLight = v51:FindFirstChild("_KLight");

                    if _KLight then
                        _KLight:Destroy();
                    end;
                end;
            end;
        end
    },
    {
        name = "highlight",
        description = "Highlights one or more player(s).",
        aliases = { "hl", "unhighlight", "unhl" },
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) to highlight."
            }, {
                type = "color",
                name = "FillColor",
                description = "The fill color of the highlight.",
                optional = true
            }, {
                type = "color",
                name = "OutlineColor",
                description = "The outline color of the highlight.",
                optional = true
            }, {
                type = "number",
                name = "FillTransparency",
                description = "The fill transparency of the highlight.",
                optional = true
            }, {
                type = "number",
                name = "OutlineTransparency",
                description = "The outline transparency of the highlight.",
                optional = true
            } },

        run = function(p52, p53, p54, p55, p56, p57) -- Line: 413, Name: run
            for _, v in p53 do
                if v.Character then
                    local _KHighlight = v.Character:FindFirstChild("_KHighlight");

                    if _KHighlight then
                        _KHighlight:Destroy();
                    end;

                    if not p52.undo then
                        p52._K.Flux.new("Highlight")({
                            Name = "_KHighlight",
                            Parent = v.Character,
                            FillColor = p54 or Color3.new(1, 1, 1),
                            FillTransparency = p56 or 0.5,
                            OutlineColor = p55 or Color3.new(1, 1, 1),
                            OutlineTransparency = p57 or 0,
                            DepthMode = Enum.HighlightDepthMode.Occluded
                        });
                    end;
                end;
            end;
        end
    },
    {
        name = "particle",
        description = "Adds a particle effect to one or more player(s).",
        aliases = { "💫", "pe" },
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) to add the particle effect to."
            }, {
                type = "image",
                name = "AssetId",
                description = "The image assetId of the particle.",
                optional = true
            }, {
                type = "color",
                name = "Color",
                description = "The color of the particle.",
                optional = true
            } },

        env = function(p58) -- Line: 460, Name: env
            local u59 = p58.Flux.new("ParticleEmitter")({
                Enabled = false,
                Name = "_KParticleEffect",
                Texture = "rbxassetid://73860257495735",
                Rate = 11,
                VelocitySpread = 180,
                Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(0.1, 0.25, 0.25), NumberSequenceKeypoint.new(1, 0.5) }),
                Transparency = NumberSequence.new({
                    NumberSequenceKeypoint.new(0, 1),
                    NumberSequenceKeypoint.new(0.1, 0.25, 0.25),
                    NumberSequenceKeypoint.new(0.9, 0.5, 0.25),
                    NumberSequenceKeypoint.new(1, 1)
                }),
                Color = ColorSequence.new({
                    ColorSequenceKeypoint.new(0, Color3.new(1, 0, 0)),
                    ColorSequenceKeypoint.new(0.16666666666666666, Color3.new(1, 0, 1)),
                    ColorSequenceKeypoint.new(0.3333333333333333, Color3.new(0, 0, 1)),
                    ColorSequenceKeypoint.new(0.5, Color3.new(0, 1, 1)),
                    ColorSequenceKeypoint.new(0.6666666666666666, Color3.new(0, 1, 0)),
                    ColorSequenceKeypoint.new(0.8333333333333334, Color3.new(1, 1, 0)),
                    ColorSequenceKeypoint.new(1, Color3.new(1, 0, 0))
                }),
                Lifetime = NumberRange.new(5),
                Speed = NumberRange.new(0.5, 1),
                Rotation = NumberRange.new(0, 359),
                RotSpeed = NumberRange.new(-90, 90)
            });

            local function apply(p60: userdata, p61: userdata, p62: string?, p63) -- Line: 493
                -- upvalues: u59 (copy)
                local v64 = p61.Character and (p61.Character:FindFirstChild("HumanoidRootPart") or p61.Character.PrimaryPart);

                if not v64 then
                    return;
                end;

                local _KParticleEffect = v64:FindFirstChild("_KParticleEffect");

                if _KParticleEffect then
                    _KParticleEffect:Destroy();
                end;

                local v65 = u59:Clone();

                if p60 and (p60:GetAttribute("_KDonationLevel") or 0) < 3 then
                    p63 = p63 or Color3.new();
                end;

                if p63 then
                    v65.Color = ColorSequence.new(p63);
                end;

                if p62 then
                    v65.Texture = p62;
                end;

                v65.Enabled = true;
                v65.Parent = v64;
            end;

            p58.Remote.DonorTrail:Connect(function(p66: any, p67: boolean?) -- Line: 517
                -- upvalues: apply (copy)
                if p67 then
                    apply(p66, p66, nil, nil);

                    return;
                end;

                local v68 = p66.Character and (p66.Character:FindFirstChild("HumanoidRootPart") or p66.Character.PrimaryPart);

                if not v68 then
                    return;
                end;

                local _KParticleEffect = v68:FindFirstChild("_KParticleEffect");

                if _KParticleEffect then
                    _KParticleEffect:Destroy();
                end;
            end);

            return {
                apply = apply
            };
        end,

        run = function(p69: any, p70: table, p71: string?, p72) -- Line: 536, Name: run
            for _, v in p70 do
                p69.env.apply(p69.fromPlayer, v, p71, p72);
            end;
        end
    },
    {
        name = "unparticle",
        description = "Removes a particle effect from one or more player(s).",
        aliases = { "un💫", "unpe" },
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) to remove the particle effect from."
            } },

        run = function(p73, p74) -- Line: 554, Name: run
            for _, v in p74 do
                local v75 = v.Character and (v.Character:FindFirstChild("HumanoidRootPart") or v.Character.PrimaryPart);

                if v75 then
                    local _KParticleEffect = v75:FindFirstChild("_KParticleEffect");

                    if _KParticleEffect then
                        _KParticleEffect:Destroy();
                    end;
                end;
            end;
        end
    },
    {
        name = "trail",
        description = "Adds a trail to one or more player(s).",
        aliases = { "☄️" },
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) to add the trail to."
            }, {
                type = "color",
                name = "Color",
                description = "The color of the trail.",
                optional = true
            } },

        run = function(p76: any, p77: table, p78) -- Line: 586, Name: run
            for _, v in p77 do
                local v79 = v.Character and (v.Character:FindFirstChild("Torso") or v.Character:FindFirstChild("UpperTorso"));

                if v79 then
                    local _KTrailEffect = v79:FindFirstChild("_KTrailEffect");

                    if _KTrailEffect then
                        _KTrailEffect:Destroy();
                    end;

                    local Trail = Instance.new("Trail");
                    Trail.Name = "_KTrailEffect";
                    Trail.Attachment0 = v79:FindFirstChild("WaistRigAttachment") or v79:FindFirstChild("WaistCenterAttachment");
                    Trail.Attachment1 = v79:FindFirstChild("NeckAttachment");
                    Trail.FaceCamera = true;
                    Trail.Lifetime = 0.5;
                    Trail.LightEmission = 1;
                    Trail.LightInfluence = 0;
                    Trail.WidthScale = NumberSequence.new(1, 0);
                    Trail.Transparency = NumberSequence.new(0, 1);
                    local v80;

                    if p78 then
                        v80 = ColorSequence.new(p78);
                    else
                        v80 = Trail.Color;
                    end;

                    Trail.Color = v80;
                    Trail.Parent = v79;
                end;
            end;
        end
    },
    {
        name = "untrail",
        description = "Removers a trail from one or more player(s).",
        aliases = { "un☄️" },
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) to remove the trail from."
            } },

        run = function(p81, p82) -- Line: 625, Name: run
            for _, v in p82 do
                local v83 = v.Character and (v.Character:FindFirstChild("Torso") or v.Character:FindFirstChild("UpperTorso"));

                if v83 then
                    local _KTrailEffect = v83:FindFirstChild("_KTrailEffect");

                    if _KTrailEffect then
                        _KTrailEffect:Destroy();
                    end;
                end;
            end;
        end
    },
    {
        name = "shine",
        description = "Adds a shine effect to one or more player(s).",
        aliases = { "🌟", "un🌟", "unshine" },
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) to add the shine effect to."
            } },

        env = function(p84) -- Line: 650, Name: env
            return {
                effect = p84.Flux.new("ParticleEmitter")({
                    Name = "_KShineEffect",
                    LockedToPart = true,
                    LightEmission = 1,
                    Texture = "rbxassetid://1085001473",
                    Rate = 2,
                    Lifetime = NumberRange.new(2),
                    Size = NumberSequence.new(5),
                    Speed = NumberRange.new(0),
                    Rotation = NumberRange.new(-180, 180),
                    RotSpeed = NumberRange.new(-10, 10),
                    Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 1, 0), NumberSequenceKeypoint.new(0.5, 0.75, 0), NumberSequenceKeypoint.new(1, 1, 0) })
                })
            };
        end,

        run = function(p85, p86) -- Line: 671, Name: run
            for _, v in p86 do
                local v87 = v.Character and (v.Character:FindFirstChild("HumanoidRootPart") or v.Character.PrimaryPart);

                if v87 then
                    local _KShineEffect = v87:FindFirstChild("_KShineEffect");

                    if _KShineEffect then
                        _KShineEffect:Destroy();
                    end;

                    if not p85.undo then
                        p85.env.effect:Clone().Parent = v87;
                    end;
                end;
            end;
        end
    },
    {
        name = "bundle",
        description = "Applies a bundle to one or more player(s).",
        aliases = { "📦", "un📦", "unbundle" },
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) whose appearance to change."
            }, {
                type = "integer",
                name = "AssetId",
                description = "The assetId of the bundle, or the original appearance if omitted.",
                optional = true
            } },

        env = function(u88) -- Line: 708, Name: env
            -- upvalues: Util (copy)
            local function getOutfitId(u89) -- Line: 709
                -- upvalues: u88 (copy)
                if u89 <= 0 then
                    return;
                end;

                local success, result = pcall(function() -- Line: 714
                    -- upvalues: u88 (ref), u89 (copy)
                    return u88.Service.Asset:GetBundleDetailsAsync(u89);
                end);

                if not (success and result) then
                    return;
                end;

                for _, v in pairs(result.Items) do
                    if v.Type == "UserOutfit" then
                        return v.Id;
                    end;
                end;
            end;

            return {
                getHumanoidDescriptionBundle = function(p90) -- Line: 730, Name: getHumanoidDescriptionBundle
                    -- upvalues: getOutfitId (copy), Util (ref)
                    local v91 = getOutfitId(p90);

                    if v91 and v91 > 0 then
                        return Util.Service.Players:GetHumanoidDescriptionFromOutfitIdAsync(v91);
                    end;

                    return nil;
                end
            };
        end,

        run = function(p92: any, p93: any, p94: number?) -- Line: 743, Name: run
            -- upvalues: Util (copy)
            local v95;

            if p94 then
                v95 = p92.env.getHumanoidDescriptionBundle(p94);
            else
                v95 = nil;
            end;

            if p94 and not v95 then
                return "Failed to load bundle.";
            end;

            for _, v in p93 do
                local v96 = v.Character and v.Character:FindFirstChildOfClass("Humanoid");

                if not v96 then
                    return;
                end;

                local v97 = v96:FindFirstChildOfClass("HumanoidDescription");

                if not v97 then
                    return;
                end;

                local _KHumanoidDescription = v:FindFirstChild("_KHumanoidDescription");

                if not _KHumanoidDescription then
                    _KHumanoidDescription = v97:Clone();
                    _KHumanoidDescription.Name = "_KHumanoidDescription";
                    _KHumanoidDescription.Parent = v;
                end;

                if v95 then
                    v96:ApplyDescription(v95);
                else
                    v96:ApplyDescription(_KHumanoidDescription);
                end;

                task.defer(Util.Humanoid.reapplyDescription, v);
            end;
        end
    },
    {
        name = "headless",
        description = "Apply headless head to one or more player(s)",
        aliases = { "nohead" },
        credit = { "emblazes", "Kohl @Scripth" },
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) to apply this to."
            }, {
                type = "boolean",
                name = "Full bundle",
                description = "Option to apply the full bundle.",
                optional = true
            } },

        run = function(p98, p99, p100) -- Line: 794, Name: run
            -- upvalues: Util (copy)
            for _, v in p99 do
                if p100 then
                    p98._K.Registry.commands.bundle:run(p99, 201);
                else
                    Util.Humanoid.attributeDescription(v, "Head", 15093053680);
                end;
            end;
        end
    },
    {
        name = "korblox",
        description = "Apply korblox bundle to one or more player(s)",
        aliases = { "korbloxleg" },
        credit = { "emblazes", "Kohl @Scripth" },
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) to apply this to."
            }, {
                type = "boolean",
                name = "Leg only",
                description = "Option to apply only the right leg.",
                optional = true
            } },

        run = function(p101, p102, p103) -- Line: 822, Name: run
            -- upvalues: Util (copy)
            for _, v in p102 do
                if p103 then
                    Util.Humanoid.attributeDescription(v, "RightLeg", 139607718);
                else
                    p101._K.Registry.commands.bundle:run(p102, 192);
                end;
            end;
        end
    },
    {
        name = "werewolf",
        description = "Apply werewolf bundle to one or more player(s)",
        aliases = { "🌕", "wolf" },
        credit = { "emblazes", "Kohl @Scripth" },
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) to apply this to."
            } },

        run = function(p104, p105) -- Line: 844, Name: run
            for _, _ in p105 do
                p104._K.Registry.commands.bundle:run(p105, 292);
            end;
        end
    },
    {
        name = "vampire",
        description = "Apply vampire bundle to one or more player(s)",
        aliases = { "🧛", "dracula" },
        credit = { "emblazes", "Kohl @Scripth" },
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) to apply this to."
            } },

        run = function(p106, p107) -- Line: 862, Name: run
            for _, _ in p107 do
                p106._K.Registry.commands.bundle:run(p107, 293);
            end;
        end
    },
    {
        name = "cape",
        description = "Gives a cape to one or more player(s)",
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) to give a cape."
            }, {
                type = "color",
                name = "Color",
                description = "The color to apply to the cape.",
                optional = true
            }, {
                type = "number",
                name = "Reflectance",
                description = "How much the cape reflects the skybox.",
                optional = true
            }, {
                type = "Enum.Material",
                name = "Material",
                description = "The material to apply to the cape.",
                optional = true
            }, {
                type = "image",
                name = "AssetId",
                description = "The assetId of the image to apply to the cape.",
                optional = true
            } },

        envClient = function(p108) -- Line: 902, Name: envClient
            local CollectionService = game:GetService("CollectionService");
            local u109 = {};
            game:GetService("RunService").Heartbeat:Connect(function(p110) -- Line: 906
                -- upvalues: u109 (copy)
                for i, v in u109 do
                    local Part0 = i.Part0;

                    if Part0 then
                        local v111 = (math.sin(v) + 1) / 10;
                        local v112 = Part0.AssemblyLinearVelocity - workspace.GlobalWind;
                        local math_max_ret = math.max(0, Part0.CFrame.LookVector:Dot(v112.Unit));
                        local v113 = v112.Magnitude + Part0.AssemblyAngularVelocity.Magnitude + math.abs(Part0.AssemblyLinearVelocity.Y);
                        i.MaxVelocity = math.clamp(v113 / 32, 0.02, 0.2);
                        i.DesiredAngle = math.clamp(math_max_ret * v113 / 32 + v111 + 0.1, 0.1, v112.Y < 0 and 2.5 or 2);
                        local v114 = u109;
                        v114[i] = v114[i] + p110 * math.clamp(math_max_ret * v113 / 4 + 1, 1, 8);
                    else
                        u109[i] = nil;
                    end;
                end;
            end);
            CollectionService:GetInstanceRemovedSignal("_KCapeMotor"):Connect(function(p115: userdata) -- Line: 932, Name: removeCapeMotor
                -- upvalues: u109 (copy)
                u109[p115] = nil;
            end);

            local function addCapeMotor(p116: userdata) -- Line: 928
                -- upvalues: u109 (copy)
                u109[p116] = math.random() * 2 * 3.141592653589793;
            end;

            for _, v in CollectionService:GetTagged("_KCapeMotor") do
                u109[v] = math.random() * 2 * 3.141592653589793;
            end;

            CollectionService:GetInstanceAddedSignal("_KCapeMotor"):Connect(addCapeMotor);
        end,

        env = function(p117) -- Line: 942, Name: env
            return {
                add = function(p118, p119, p120, p121, p122) -- Line: 944, Name: add
                    local v123;

                    if p118 then
                        v123 = p118:FindFirstChild("Torso") or p118:FindFirstChild("UpperTorso");
                    else
                        v123 = p118;
                    end;

                    if not v123 then
                        return;
                    end;

                    local _KCape = p118:FindFirstChild("_KCape");

                    if _KCape then
                        _KCape:Destroy();
                    end;

                    local Part = Instance.new("Part");
                    Part.Name = "_KCape";
                    Part.Color = p119 or Color3.new();
                    Part.Material = p121 or Enum.Material.SmoothPlastic;
                    Part.Reflectance = p120 or 0;
                    Part.CanCollide = false;
                    Part.CanQuery = false;
                    Part.CanTouch = false;
                    Part.Massless = true;
                    Part.TopSurface = 0;
                    Part.BottomSurface = 0;
                    Part.Size = Vector3.new(1.9, 3.8, 0.2);

                    if p122 then
                        Instance.new("Decal", Part).Texture = p122;
                    end;

                    local Motor6D = Instance.new("Motor6D");
                    Motor6D.Part0 = v123;
                    Motor6D.Part1 = Part;
                    Motor6D.C0 = CFrame.new(0, v123.Size.Y / 2, v123.Size.Z / 2) * CFrame.Angles(0, -1.5707963267948966, 0);
                    Motor6D.C1 = CFrame.new(0, Part.Size.Y / 2, 0) * CFrame.Angles(0, 1.5707963267948966, 0);
                    Motor6D.DesiredAngle = 0.1;
                    Motor6D.MaxVelocity = 0.1;
                    Motor6D:AddTag("_KCapeMotor");
                    Motor6D.Parent = Part;
                    Part.Parent = p118;
                end
            };
        end,

        run = function(p124, p125, p126, p127, p128, p129) -- Line: 987, Name: run
            for _, v in p125 do
                p124.env.add(v.Character, p126, p127, p128, p129);
            end;
        end
    },
    {
        name = "uncape",
        description = "Removes the cape from one or more player(s).",
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) whose cape to remove."
            } },

        run = function(p130, p131) -- Line: 1004, Name: run
            for _, v in p131 do
                local v132 = v.Character and v.Character:FindFirstChild("_KCape");

                if v132 then
                    v132:Destroy();
                end;
            end;
        end
    },
    {
        name = "hat",
        description = "Gives one or more hats to one or more player(s).",
        aliases = { "🎩", "crmhat" },
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) to give one or more hats."
            }, {
                type = "integers",
                name = "AssetIds",
                description = "The assetId of one or more hats."
            }, {
                type = "image",
                name = "Texture",
                description = "The assetId of the hat texture.",
                optional = true
            }, {
                type = "color",
                name = "Color",
                description = "The color to apply to the hat.",
                optional = true
            }, {
                type = "number",
                name = "Reflectance",
                description = "How much the hat reflects the skybox.",
                optional = true
            }, {
                type = "Enum.Material",
                name = "Material",
                description = "The material to apply to the hat.",
                optional = true
            } },

        env = function(u133) -- Line: 1053, Name: env
            local u136 = {
                allowed = { 24112667, 24114402, 33070696, 305888394 },
                cache = {},

                limit = function(p134) -- Line: 1059, Name: limit
                    local v135 = 0;

                    for _, child in p134:GetChildren() do
                        if child:IsA("Accoutrement") and string.find(child.Name, "_KHat") == 1 then
                            v135 = v135 + 1;

                            if v135 >= 16 then
                                child:Destroy();
                            end;
                        end;
                    end;
                end
            };

            function u136.loadHat(p137) -- Line: 1072
                -- upvalues: u133 (copy), u136 (copy)
                local v138 = u133.Service.Insert:LoadAsset(p137);

                if not table.find(u136.allowed, p137) then
                    for _, descendant in v138:GetDescendants() do
                        if descendant:IsA("BaseScript") or descendant:IsA("ModuleScript") then
                            descendant:Destroy();
                        end;
                    end;
                end;

                local v139 = v138:FindFirstChildWhichIsA("Accoutrement");

                if v139 then
                    v139.Parent = nil;
                end;

                v138:Destroy();

                if v139 then
                    local Handle = v139:FindFirstChild("Handle");

                    if Handle then
                        local u140 = Handle:FindFirstChildWhichIsA("FileMesh");

                        if u140 then
                            local v141, v142 = u133.Util.Retry(function() -- Line: 1097
                                -- upvalues: u133 (ref), u140 (copy)
                                return u133.Service.Insert:CreateMeshPartAsync(u140.MeshId, Enum.CollisionFidelity.Box, Enum.RenderFidelity.Precise);
                            end);

                            if not v141 then
                                return;
                            end;

                            v142.Name = "Handle";
                            v142.TextureID = u140.TextureId;
                            v142.Size = v142.Size * u140.Scale;
                            u140:Destroy();

                            for _, child in Handle:GetChildren() do
                                child.Parent = v142;
                            end;

                            v142.Parent = v139;
                            Handle:Destroy();
                        end;
                    end;

                    return v139;
                end;
            end;

            return u136;
        end,

        run = function(p143, p144, p145, p146, p147, p148, p149) -- Line: 1127, Name: run
            for i, v in p145 do
                if i >= 16 then
                    break;
                end;

                local v150 = p143.env.cache[v];

                if not v150 then
                    v150 = p143.env.loadHat(v);
                    p143.env.cache[v] = v150;
                end;

                if v150 then
                    local Handle = v150:FindFirstChild("Handle");

                    if p146 and Handle then
                        if Handle:IsA("MeshPart") then
                            Handle.TextureID = p146;
                        else
                            local v151 = v150.Handle:FindFirstChildWhichIsA("FileMesh");

                            if v151 then
                                v151.TextureId = p146;
                            end;
                        end;
                    end;

                    local v152;

                    if p147 then
                        v152 = v;

                        for _, descendant in v150:GetDescendants() do
                            if descendant:IsA("BasePart") then
                                p143._K.Registry.commands.crm.env.updatePart(descendant, p147, p148, p149);
                            end;
                        end;
                    else
                        v152 = v;
                    end;

                    local v153 = "_KHat" .. v152;
                    v150.Name = v153;

                    for _, v2 in p144 do
                        if v2.Character then
                            local v154 = v2.Character:FindFirstChild(v153);

                            if v154 then
                                v154:Destroy();
                            end;

                            p143.env.limit(v2.Character);
                            v150:Clone().Parent = v2.Character;
                        end;
                    end;
                end;
            end;
        end
    },
    {
        name = "removehats",
        description = "Removes the hats of one or more player(s).",
        aliases = { "remove🎩", "r🎩", "rhats" },
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) whose hats to remove."
            }, {
                type = "boolean",
                name = "AdminHats",
                description = "When true, only removes hats given via admin commands (defaults to false).",
                optional = true
            } },

        run = function(p155, p156, p157) -- Line: 1198, Name: run
            for _, v in p156 do
                if v.Character then
                    for _, child in v.Character:GetChildren() do
                        if child:IsA("Accoutrement") and (not p157 or string.find(child.Name, "_KHat") == 1) then
                            child:Destroy();
                        end;
                    end;
                end;
            end;
        end
    },
    {
        name = "head",
        description = "Changes the head of one or more player(s).",
        aliases = { "🗿", "unhead" },
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) whose head to change."
            }, {
                type = "integer",
                name = "AssetId",
                description = "The assetId of the head, or the original head if omitted.",
                optional = true
            } },

        run = function(p158, p159, p160) -- Line: 1229, Name: run
            -- upvalues: Util (copy)
            for _, v in p159 do
                Util.Humanoid.attributeDescription(v, "Head", p160);
            end;
        end
    },
    {
        name = "headsize",
        description = "Changes the head size of one or more player(s).",
        aliases = { "headscale", "bighead", "hugehead", "largehead", "tinyhead", "minihead", "smallhead", "normalhead" },
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) whose head size to change.",
                shouldRequest = true
            }, {
                type = "number",
                name = "Size",
                description = "The size of the head, or the original size if omitted.",
                optional = true
            } },

        env = function(u161) -- Line: 1253, Name: env
            return {
                scaleHead = function(p162, p163) -- Line: 1254, Name: scaleHead
                    -- upvalues: u161 (copy)
                    local v164;

                    if p162 then
                        v164 = p162:FindFirstChildOfClass("Humanoid");
                    else
                        v164 = p162;
                    end;

                    if not v164 then
                        return;
                    end;

                    if v164.RigType == Enum.HumanoidRigType.R15 then
                        local HeadScale = v164:FindFirstChild("HeadScale");

                        if HeadScale then
                            local v165 = u161.Util.Property.cache[HeadScale];
                            local v166;

                            if v165 and v165.Value then
                                v166 = v165.Value[1];
                            else
                                v166 = HeadScale.Value;
                            end;

                            u161.Util.Property.override(HeadScale, "Value", v166 * p163);
                        end;
                    elseif v164.RigType == Enum.HumanoidRigType.R6 and (p162:FindFirstChild("Head") and p162:FindFirstChild("Torso")) then
                        local Mesh = p162.Head:FindFirstChild("Mesh");

                        if Mesh then
                            local v167 = u161.Util.Property.cache[Mesh];
                            local v168;

                            if v167 and v167.Scale then
                                v168 = v167.Scale[1];
                            else
                                v168 = Mesh.Scale;
                            end;

                            u161.Util.Property.override(Mesh, "Scale", v168 * p163);
                        end;

                        local Y = p162.Head.Size.Y;
                        p162.Torso.Neck.C0 = CFrame.new(0, Y / 2 + Y * p163 / 2, 0) * CFrame.Angles(1.5707963267948966, 3.141592653589793, 0);
                    end;
                end,

                big = { "bighead", "largehead", "hugehead" },
                small = { "smallhead", "minihead", "tinyhead" }
            };
        end,

        run = function(p169, p170, p171) -- Line: 1289, Name: run
            local v172 = p169.alias == "normalhead" and 1 or (table.find(p169.env.big, p169.alias) and 3 or (table.find(p169.env.small, p169.alias) and 0.5 or p171)) or 1;

            if p169._K.Auth.getRank(p169.from) <= 1 then
                v172 = math.clamp(v172, 0.5, 3);
            end;

            for _, v in p170 do
                p169.env.scaleHead(v.Character, v172);
            end;
        end
    },
    {
        name = "face",
        description = "Changes the face of one or more player(s).",
        aliases = { "🙂", "un🙂", "unface" },
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) whose face to change."
            }, {
                type = "image",
                name = "AssetId",
                description = "The assetId of the face, or the original face if omitted.",
                optional = true
            } },

        run = function(p173, p174, p175) -- Line: 1325, Name: run
            for _, v in p174 do
                local v176 = v.Character and v.Character:FindFirstChild("Head");

                if v176 then
                    local face = v176:FindFirstChild("face");

                    if not face then
                        face = Instance.new("Decal");
                        face.Name = "face";
                        face.Parent = v176;
                    end;

                    if p173.undo then
                        p173._K.Util.Property.reset(face, "Texture");
                    else
                        p173._K.Util.Property.override(face, "Texture", p175);
                    end;
                end;
            end;
        end
    },
    {
        name = "shirt",
        description = "Changes the shirt of one or more player(s).",
        aliases = { "👕", "un👕", "unshirt" },
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) whose shirt to change."
            }, {
                type = "image",
                name = "AssetId",
                description = "The assetId of the shirt, or the original shirt if omitted.",
                optional = true
            } },

        run = function(p177, p178, p179) -- Line: 1363, Name: run
            for _, v in p178 do
                if v.Character then
                    local v180 = v.Character:FindFirstChildOfClass("Shirt");

                    if not v180 then
                        v180 = Instance.new("Shirt");
                        v180.Parent = v.Character;
                    end;

                    if p177.undo then
                        p177._K.Util.Property.reset(v180, "ShirtTemplate");
                    else
                        p177._K.Util.Property.override(v180, "ShirtTemplate", p179);
                    end;
                end;
            end;
        end
    },
    {
        name = "pants",
        description = "Changes the pants of one or more player(s).",
        aliases = { "👖", "un👖", "unpants" },
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) whose pants to change."
            }, {
                type = "image",
                name = "AssetId",
                description = "The assetId of the pants, or the original pants if omitted.",
                optional = true
            } },

        run = function(p181, p182, p183) -- Line: 1399, Name: run
            for _, v in p182 do
                if v.Character then
                    local v184 = v.Character:FindFirstChildOfClass("Pants");

                    if not v184 then
                        v184 = Instance.new("Pants");
                        v184.Parent = v.Character;
                    end;

                    if p181.undo then
                        p181._K.Util.Property.reset(v184, "PantsTemplate");
                    else
                        p181._K.Util.Property.override(v184, "PantsTemplate", p183);
                    end;
                end;
            end;
        end
    },
    {
        name = "tshirt",
        description = "Changes the t-shirt of one or more player(s).",
        aliases = { "untshirt" },
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) whose t-shirt to change."
            }, {
                type = "image",
                name = "AssetId",
                description = "The assetId of the t-shirt, or the original t-shirt if omitted.",
                optional = true
            } },

        run = function(p185, p186, p187) -- Line: 1435, Name: run
            for _, v in p186 do
                if v.Character then
                    local v188 = v.Character:FindFirstChildOfClass("ShirtGraphic");

                    if not v188 then
                        v188 = Instance.new("ShirtGraphic");
                        v188.Parent = v.Character;
                    end;

                    if p185.undo then
                        p185._K.Util.Property.reset(v188, "Graphic");
                    else
                        p185._K.Util.Property.override(v188, "Graphic", p187);
                    end;
                end;
            end;
        end
    },
    {
        name = "bodycolor",
        description = "Changes the body colors of one or more player(s).",
        aliases = { "bodycolors", "skincolor", "unbodycolor", "unbodycolors", "unskincolor" },
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) whose body colors to change."
            }, {
                type = "color",
                name = "Color",
                description = "The color, or the original if omitted.",
                optional = true
            } },

        run = function(p189: any, p190: table, p191) -- Line: 1471, Name: run
            for _, v in p190 do
                local Character = v.Character;

                if v.Character then
                    local v192 = Character:FindFirstChildOfClass("BodyColors");

                    if v192 then
                        for _, v2 in { "Head", "Torso", "LeftArm", "RightArm", "LeftLeg", "RightLeg" } do
                            if p191 then
                                p189._K.Util.Property.override(v192, v2 .. "Color3", p191);
                            else
                                p189._K.Util.Property.reset(v192, v2 .. "Color3");
                            end;
                        end;
                    end;
                end;
            end;
        end
    },
    {
        name = "crm",
        description = "Changes the color, reflectance, or material of one or more player(s).",
        aliases = { "color", "paint", "uncrm", "uncolor", "unpaint" },
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) whose character appearance will be changed"
            }, {
                type = "color",
                name = "Color",
                description = "The color to apply to the character.",
                optional = true
            }, {
                type = "number",
                name = "Reflectance",
                description = "How much a character reflects the skybox.",
                optional = true
            }, {
                type = "Enum.Material",
                name = "Material",
                description = "The material to apply to the character.",
                optional = true
            } },

        env = function(u193) -- Line: 1519, Name: env
            local u194 = {
                [Enum.Material.Water] = true
            };

            local function updatePart(p195: userdata, p196, p197: number?, p198: any) -- Line: 1524
                -- upvalues: u193 (copy)
                local v199 = p196 or (p197 or p198);

                if p195:IsA("MeshPart") and p198 ~= Enum.Material.ForceField then
                    if v199 then
                        u193.Util.Property.override(p195, "TextureID", "");
                    else
                        u193.Util.Property.reset(p195, "TextureID");
                    end;
                end;

                local v200 = p195:FindFirstChildOfClass("SpecialMesh");

                if v200 and p198 ~= Enum.Material.ForceField then
                    if v199 then
                        u193.Util.Property.override(v200, "TextureId", "");
                    else
                        u193.Util.Property.reset(v200, "TextureId");
                    end;
                end;

                if p196 then
                    u193.Util.Property.override(p195, "Color", p196);
                else
                    u193.Util.Property.reset(p195, "Color");
                end;

                if p197 then
                    u193.Util.Property.override(p195, "Reflectance", p197);
                else
                    u193.Util.Property.reset(p195, "Reflectance");
                end;

                if p198 then
                    u193.Util.Property.override(p195, "Material", p198);

                    return;
                end;

                u193.Util.Property.reset(p195, "Material");
            end;

            return {
                updatePart = updatePart,

                update = function(p201: userdata, p202, p203: number?, p204: any) -- Line: 1565, Name: update
                    -- upvalues: u194 (copy), u193 (copy), updatePart (copy)
                    if u194[p204] then
                        return;
                    end;

                    local v205 = p201:FindFirstChildOfClass("Humanoid");

                    if not v205 then
                        return;
                    end;

                    local v206 = p201:FindFirstChildOfClass("BodyColors");

                    if v206 then
                        for _, v in { "Head", "Torso", "LeftArm", "RightArm", "LeftLeg", "RightLeg" } do
                            if p202 then
                                u193.Util.Property.override(v206, v .. "Color3", p202);
                            else
                                u193.Util.Property.reset(v206, v .. "Color3");
                            end;
                        end;
                    end;

                    local v207 = p202 or (p203 or p204);

                    if p204 ~= Enum.Material.ForceField then
                        local v208 = p201:FindFirstChildOfClass("Shirt");

                        if v208 then
                            if v207 then
                                u193.Util.Property.override(v208, "ShirtTemplate", "");
                            else
                                u193.Util.Property.reset(v208, "ShirtTemplate");
                            end;
                        end;

                        local v209 = p201:FindFirstChildOfClass("Pants");

                        if v209 then
                            if v207 then
                                u193.Util.Property.override(v209, "PantsTemplate", "");
                            else
                                u193.Util.Property.reset(v209, "PantsTemplate");
                            end;
                        end;
                    end;

                    for _, descendant in p201:GetDescendants() do
                        if descendant:IsA("BasePart") and descendant.Name ~= "HumanoidRootPart" then
                            updatePart(descendant, p202, p203, p204);
                        elseif descendant:IsA("SurfaceAppearance") then
                            if v207 and not descendant:FindFirstChild("_KParent") then
                                local ObjectValue = Instance.new("ObjectValue");
                                ObjectValue.Name = "_KParent";
                                ObjectValue.Value = descendant.Parent;
                                ObjectValue.Parent = descendant;
                                descendant.Parent = v205;
                            elseif not v207 and descendant:FindFirstChild("_KParent") then
                                descendant.Parent = descendant._KParent.Value;
                                descendant._KParent:Destroy();
                            end;
                        end;
                    end;
                end
            };
        end,

        run = function(p210: any, p211: any, p212, p213: number?, p214: any) -- Line: 1627, Name: run
            for _, v in p211 do
                if v.Character and v.Character.PrimaryPart then
                    p210.env.update(v.Character, p212, p213, p214);
                end;
            end;
        end
    },
    {
        name = "goldify",
        description = "Glimmer like gold!",
        aliases = { "gold" },
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) to turn to gold."
            } },

        run = function(p215: any, p216: table) -- Line: 1646, Name: run
            for _, v in p216 do
                if v.Character and (v.Character.PrimaryPart and v.Character:FindFirstChildWhichIsA("Humanoid")) then
                    p215._K.Registry.commands.crm.env.update(v.Character, BrickColor.new("Gold").Color, 0.4, Enum.Material.Metal);
                end;
            end;
        end
    },
    {
        name = "shiny",
        description = "Shine like a diamond!",
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) to make shiny."
            } },

        run = function(p217: any, p218: table) -- Line: 1674, Name: run
            for _, v in p218 do
                if v.Character and v.Character.PrimaryPart then
                    p217._K.Registry.commands.crm.env.update(v.Character, Color3.new(1, 1, 1), 1, Enum.Material.SmoothPlastic);
                end;
            end;
        end
    },
    {
        name = "silverify",
        description = "Shine bright as a silver statue!",
        aliases = { "silver", "metalify", "metal" },
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) to turn to silver."
            } },

        run = function(p219: any, p220: table) -- Line: 1699, Name: run
            for _, v in p220 do
                if v.Character and v.Character.PrimaryPart then
                    p219._K.Registry.commands.crm.env.update(v.Character, BrickColor.new("Silver").Color, 0.4, Enum.Material.Metal);
                end;
            end;
        end
    },
    {
        name = "ungoldify",
        description = "Restores the character of one or more player(s).",
        aliases = { "ungold", "unsilverify", "unsilver", "unmetalify", "unmetal" },
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) to restore."
            } },

        run = function(p221: any, p222: table) -- Line: 1723, Name: run
            for _, v in p222 do
                if v.Character and v.Character.PrimaryPart then
                    p221._K.Registry.commands.crm.env.update(v.Character);
                end;
            end;
        end
    },
    {
        name = "swagify",
        description = "Makes one or more player(s) swaggy. 😎",
        aliases = { "swag" },
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) to swagify."
            } },

        run = function(p223: any, p224: table) -- Line: 1742, Name: run
            for _, v in p224 do
                if v.Character and v.Character.PrimaryPart then
                    local v225 = v.Character:FindFirstChildOfClass("Shirt");

                    if not v225 then
                        v225 = Instance.new("Shirt");
                        v225.Parent = v.Character;
                    end;

                    p223._K.Util.Property.override(v225, "ShirtTemplate", "rbxassetid://109163376");
                    local v226 = v.Character:FindFirstChildOfClass("Pants");

                    if not v226 then
                        v226 = Instance.new("Pants");
                        v226.Parent = v.Character;
                    end;

                    p223._K.Util.Property.override(v226, "PantsTemplate", "rbxassetid://109163376");
                    p223._K.Registry.commands.cape.env.add(v.Character, Color3.new(1, 0, 1), nil, nil, "rbxassetid://109301474");
                end;
            end;
        end
    },
    {
        name = "unswagify",
        description = "Removes swag from one or more player(s). 👎",
        aliases = { "unswag" },
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) to remove swag from."
            } },

        run = function(p227: any, p228: table) -- Line: 1781, Name: run
            for _, v in p228 do
                if v.Character and v.Character.PrimaryPart then
                    local v229 = v.Character and v.Character:FindFirstChild("_KCape");

                    if v229 then
                        v229:Destroy();
                    end;

                    local v230 = v.Character:FindFirstChildOfClass("Shirt");

                    if v230 then
                        p227._K.Util.Property.reset(v230, "ShirtTemplate", "rbxassetid://109163376");
                    end;

                    local v231 = v.Character:FindFirstChildOfClass("Pants");

                    if v231 then
                        p227._K.Util.Property.reset(v231, "PantsTemplate");
                    end;
                end;
            end;
        end
    },
    {
        name = "wingscolor",
        description = "Changes the VIP wings color.",
        args = { {
                type = "color",
                name = "Wings Color",
                description = "The color of the wings.",
                optional = true
            } },

        runClient = function(p232) -- Line: 1812, Name: runClient
            if (p232.fromPlayer:GetAttribute("_KDonationLevel") or 0) >= 3 or not p232._K.Data.settings.vip then
                return;
            end;

            p232._K.PromptPurchaseVIP();
        end,

        run = function(p233: any, p234) -- Line: 1818, Name: run
            if (p233.fromPlayer:GetAttribute("_KDonationLevel") or 0) < 3 then
                return;
            end;

            if not p233.fromPlayer.Character then
                return "You have no character!";
            end;

            local _KAlphaWings = p233.fromPlayer.Character:FindFirstChild("_KAlphaWings");

            if not _KAlphaWings then
                return "You don\'t have VIP wings equipped!";
            end;

            local u235 = p234 or _KAlphaWings:GetAttribute("_KWingsColor");
            task.defer(function() -- Line: 1830
                -- upvalues: _KAlphaWings (copy), u235 (ref)
                _KAlphaWings.Wings.Color = u235;
            end);
        end
    },
    {
        name = "rainbowwings",
        description = "Toggles the VIP wings rainbow.",
        aliases = { "wingsrainbow" },

        runClient = function(p236) -- Line: 1840, Name: runClient
            if (p236.fromPlayer:GetAttribute("_KDonationLevel") or 0) >= 3 or not p236._K.Data.settings.vip then
                return;
            end;

            p236._K.PromptPurchaseVIP();
        end,

        run = function(p237) -- Line: 1846, Name: run
            if (p237.fromPlayer:GetAttribute("_KDonationLevel") or 0) < 3 then
                return;
            end;

            if not p237.fromPlayer.Character then
                return "You have no character!";
            end;

            local _KAlphaWings = p237.fromPlayer.Character:FindFirstChild("_KAlphaWings");

            if not _KAlphaWings then
                return "You don\'t have VIP wings equipped!";
            end;

            if not _KAlphaWings:HasTag("_KAlphaWingsRainbow") then
                _KAlphaWings:AddTag("_KAlphaWingsRainbow");

                return;
            end;

            _KAlphaWings:RemoveTag("_KAlphaWingsRainbow");
            task.defer(function() -- Line: 1859
                -- upvalues: _KAlphaWings (copy)
                _KAlphaWings.Wings.Color = _KAlphaWings:GetAttribute("_KWingsColor") or Color3.new(1, 1, 1);
            end);
        end
    },
    {
        name = "crowncolor",
        description = "Changes the VIP crown color.",
        args = { {
                type = "color",
                name = "Crown Color",
                description = "The color of the crown.",
                optional = true
            }, {
                type = "color",
                name = "Fire Color",
                description = "The color of the crown\'s fire.",
                optional = true
            } },

        runClient = function(p238) -- Line: 1886, Name: runClient
            if (p238.fromPlayer:GetAttribute("_KDonationLevel") or 0) >= 2 or not p238._K.Data.settings.vip then
                return;
            end;

            p238._K.PromptPurchaseVIP();
        end,

        run = function(p239: any, p240, p241) -- Line: 1892, Name: run
            if (p239.fromPlayer:GetAttribute("_KDonationLevel") or 0) < 2 then
                return;
            end;

            if not p239.fromPlayer.Character then
                return "You have no character!";
            end;

            local SuperCrown = p239.fromPlayer.Character:FindFirstChild("SuperCrown");

            if not SuperCrown then
                return "You don\'t have a VIP crown equipped!";
            end;

            local u242 = p240 or SuperCrown:GetAttribute("_KCrownColor");
            local u243 = p241 or SuperCrown:GetAttribute("_KCrownFireColor");
            SuperCrown:RemoveTag("_KSuperCrownRainbow");
            task.defer(function() -- Line: 1906
                -- upvalues: SuperCrown (copy), u242 (ref), u243 (ref)
                SuperCrown.Handle.Color = u242;
                SuperCrown.Handle.Fire.Color = u243;
                SuperCrown.Handle.Fire.SecondaryColor = u242;
            end);
        end
    },
    {
        name = "rainbowcrown",
        description = "Toggles the VIP crown rainbow.",
        aliases = { "crownrainbow" },

        runClient = function(p244) -- Line: 1918, Name: runClient
            if (p244.fromPlayer:GetAttribute("_KDonationLevel") or 0) >= 3 or not p244._K.Data.settings.vip then
                return;
            end;

            p244._K.PromptPurchaseVIP();
        end,

        run = function(p245) -- Line: 1924, Name: run
            if (p245.fromPlayer:GetAttribute("_KDonationLevel") or 0) < 3 then
                return;
            end;

            if not p245.fromPlayer.Character then
                return "You have no character!";
            end;

            local SuperCrown = p245.fromPlayer.Character:FindFirstChild("SuperCrown");

            if not SuperCrown then
                return "You don\'t have a VIP crown equipped!";
            end;

            if not SuperCrown:HasTag("_KSuperCrownRainbow") then
                SuperCrown:AddTag("_KSuperCrownRainbow");

                return;
            end;

            SuperCrown:RemoveTag("_KSuperCrownRainbow");
            task.defer(function() -- Line: 1937
                -- upvalues: SuperCrown (copy)
                local v246 = SuperCrown:GetAttribute("_KCrownColor") or Color3.new(1, 1, 1);
                local v247 = SuperCrown:GetAttribute("_KCrownFireColor") or Color3.new();
                SuperCrown.Handle.Color = v246;
                SuperCrown.Handle.Fire.Color = v247;
                SuperCrown.Handle.Fire.SecondaryColor = v246;
            end);
        end
    }
};