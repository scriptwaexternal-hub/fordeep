-- Decompiled with Potassium's decompiler.

local Debris = game:GetService("Debris");
local ReplicatedStorage = game:GetService("ReplicatedStorage");
local UserInputService = game:GetService("UserInputService");
local Players = game:GetService("Players");
local RunService = game:GetService("RunService");
game:GetService("TweenService");
local Modules = ReplicatedStorage:WaitForChild("Modules");
local Remotes = ReplicatedStorage:WaitForChild("Remotes");
local Metadata = Modules.Metadata;
local Shared = Modules.Shared;
local _ = Modules.Utility;
local Assets = ReplicatedStorage.Assets;
local LocalPlayer = Players.LocalPlayer;
local SkillTreeData = require(Metadata.CharacterData.SkillTreeData);
local SoundManager = require(Shared.SoundManager);
require(Modules.GlobalFunctions);
local TransformData = require(Metadata.MiscData.TransformData.TransformData);
local CinemaManager = require(Shared.CinemaManager);
local u1 = script:FindFirstAncestor("HUD");
local _ = ReplicatedStorage.Remotes.StatRetrieveRemote;
local SkillTreeRemote = ReplicatedStorage.Remotes.SkillTreeRemote;
local _ = workspace.World.Visuals;
local u2 = {};
local _ = workspace.CurrentCamera;
local _ = Assets.SkillTrees;
local _ = Assets.Gui.SkillTree;
TweenInfo.new(1);
local u3 = false;
local u4 = false;
local Transformation = Assets.Gui.Transformation;
local u5 = "";
local GetTransformationsRemote = Remotes.GetTransformationsRemote;
local ServerRemote = Remotes.ServerRemote;
local StatRetrieveRemote = Remotes.StatRetrieveRemote;

function Kill_Connections()
    -- upvalues: u2 (copy)
    for _, v in pairs(u2) do
        v:Disconnect();
    end;

    table.clear(u2);
end;

function Transistion()
    -- upvalues: SoundManager (copy), LocalPlayer (copy), CinemaManager (copy)
    SoundManager.AddSound("Click Sound", {
        Parent = LocalPlayer
    }, "Client");
    CinemaManager.Transition(LocalPlayer);
    task.wait(1);
end;

local SkillTreeLayouts = require(Metadata.CharacterData.SkillTreeLayouts);
local ContextActionService = game:GetService("ContextActionService");
local TweenService = game:GetService("TweenService");
local TweenInfo_new_ret = TweenInfo.new(0.35, Enum.EasingStyle.Quad, Enum.EasingDirection.Out);
local Color3_fromRGB_ret = Color3.fromRGB(10, 9, 8);
local Color3_fromRGB_ret2 = Color3.fromRGB(17, 15, 12);
local Color3_fromRGB_ret3 = Color3.fromRGB(140, 109, 47);
local Color3_fromRGB_ret4 = Color3.fromRGB(222, 178, 76);
local Color3_fromRGB_ret5 = Color3.fromRGB(255, 214, 130);
local Color3_fromRGB_ret6 = Color3.fromRGB(150, 143, 130);
local Color3_fromRGB_ret7 = Color3.fromRGB(214, 205, 188);
local Color3_fromRGB_ret8 = Color3.fromRGB(52, 46, 36);
local Garamond = Enum.Font.Garamond;

local function souls_hairline(p6, p7, p8) -- Line: 136
    -- upvalues: Color3_fromRGB_ret3 (copy)
    local Frame = Instance.new("Frame");
    Frame.AnchorPoint = Vector2.new(0.5, 0.5);
    Frame.Position = p7;
    Frame.Size = UDim2.new(1, -40, 0, 1);
    Frame.BackgroundColor3 = Color3_fromRGB_ret3;
    Frame.BackgroundTransparency = p8 or 0.35;
    Frame.BorderSizePixel = 0;
    Frame.ZIndex = 62;
    Frame.Parent = p6;

    return Frame;
end;

local u9 = nil;
local u10 = false;
local u11 = "Race";

local function session_connect(p12) -- Line: 154
    -- upvalues: u9 (ref)
    if u9 then
        table.insert(u9.connections, p12);
    end;

    return p12;
end;

local function Begin_TreeSession() -- Line: 162
    -- upvalues: LocalPlayer (copy), u9 (ref), u3 (ref), SoundManager (copy)
    local PopupGui = LocalPlayer.PlayerGui:FindFirstChild("PopupGui");
    local HUD = LocalPlayer.PlayerGui:FindFirstChild("HUD");

    if not PopupGui then
        return false;
    end;

    u9 = {
        connections = {}
    };
    u3 = true;
    SoundManager.AddSound("Open Sound", {
        Parent = LocalPlayer
    }, "Client");
    local Character = LocalPlayer.Character;

    if Character then
        Character:SetAttribute("InUI", true);
    end;

    if HUD then
        HUD.Enabled = false;
    end;

    return true;
end;

function SkillTree_UIExists()
    -- upvalues: u9 (ref), LocalPlayer (copy)
    if u9 then
        return true;
    end;

    local PopupGui = LocalPlayer.PlayerGui:FindFirstChild("PopupGui");

    if PopupGui then
        return (PopupGui:FindFirstChild("SkillFrame") or PopupGui:FindFirstChild("SkillTreeBackdrop")) ~= nil;
    end;

    return false;
end;

function Close_SkillTree()
    -- upvalues: u3 (ref), u4 (ref), ContextActionService (copy), u9 (ref), LocalPlayer (copy)
    u3 = false;
    u4 = false;
    pcall(function() -- Line: 188
        -- upvalues: ContextActionService (ref)
        ContextActionService:UnbindAction("SkillTreePanSink");
    end);
    local u13 = u9;
    u9 = nil;

    if u13 then
        if u13.renderCon then
            pcall(function() -- Line: 194
                -- upvalues: u13 (copy)
                u13.renderCon:Disconnect();
            end);
        end;

        for _, v in ipairs(u13.connections) do
            pcall(function() -- Line: 197
                -- upvalues: v (copy)
                v:Disconnect();
            end);
        end;

        if u13.chooser then
            pcall(function() -- Line: 199
                -- upvalues: u13 (copy)
                u13.chooser:Destroy();
            end);
        end;

        if u13.backdrop then
            pcall(function() -- Line: 200
                -- upvalues: u13 (copy)
                u13.backdrop:Destroy();
            end);
        end;
    end;

    local PopupGui = LocalPlayer.PlayerGui:FindFirstChild("PopupGui");

    if PopupGui then
        local SkillFrame = PopupGui:FindFirstChild("SkillFrame");

        if SkillFrame then
            SkillFrame:Destroy();
        end;

        local SkillTreeBackdrop = PopupGui:FindFirstChild("SkillTreeBackdrop");

        if SkillTreeBackdrop then
            SkillTreeBackdrop:Destroy();
        end;
    end;

    local HUD = LocalPlayer.PlayerGui:FindFirstChild("HUD");

    if HUD then
        HUD.Enabled = true;
    end;

    local Character = LocalPlayer.Character;

    if Character and Character:GetAttribute("InUI") then
        Character:SetAttribute("InUI", nil);
    end;
end;

function Toggle_SkillTree()
    -- upvalues: u10 (ref), u3 (ref), u4 (ref), LocalPlayer (copy)
    if u10 then
        return;
    end;

    if SkillTree_UIExists() then
        Close_SkillTree();

        return;
    end;

    u3 = false;
    u4 = false;
    local Character = LocalPlayer.Character;

    if Character and Character:GetAttribute("InUI") then
        return;
    end;

    Open_SkillTreeMenu();
end;

function Open_SkillTree(p14, u15)
    -- upvalues: StatRetrieveRemote (copy), SkillTreeData (copy), LocalPlayer (copy), u9 (ref), u3 (ref), u4 (ref), Color3_fromRGB_ret (copy), TweenService (copy), SkillTreeLayouts (copy), Color3_fromRGB_ret8 (copy), Color3_fromRGB_ret4 (copy), Color3_fromRGB_ret5 (copy), Color3_fromRGB_ret2 (copy), Color3_fromRGB_ret3 (copy), Garamond (copy), Color3_fromRGB_ret7 (copy), souls_hairline (copy), Color3_fromRGB_ret6 (copy), Debris (copy), SoundManager (copy), TweenInfo_new_ret (copy), SkillTreeRemote (copy), ContextActionService (copy), RunService (copy), UserInputService (copy)
    local v16 = StatRetrieveRemote:InvokeServer("Race") or "Human";
    local v17, v18;

    if u15 == "RaceSkills" then
        v17 = v16 .. " Skill Tree";
        v18 = SkillTreeData.Race[v16];
    else
        v17 = p14 .. " Skill Tree";
        v18 = SkillTreeData[p14];
    end;

    if not v18 then
        warn("Skill Tree Not Found");
        Close_SkillTree();

        return;
    end;

    local PopupGui = LocalPlayer.PlayerGui:FindFirstChild("PopupGui");

    if not PopupGui then
        Close_SkillTree();

        return;
    end;

    local v19 = StatRetrieveRemote:InvokeServer("StatPoints");

    if not u9 then
        u9 = {
            connections = {}
        };
    end;

    u3 = true;
    u4 = true;
    local Frame = Instance.new("Frame");
    Frame.Name = "SkillTreeBackdrop";
    Frame.Size = UDim2.fromScale(1, 1);
    Frame.BackgroundColor3 = Color3_fromRGB_ret;
    Frame.BackgroundTransparency = 1;
    Frame.BorderSizePixel = 0;
    Frame.ZIndex = 40;
    Frame.ClipsDescendants = true;
    Frame.Parent = PopupGui;
    u9.backdrop = Frame;
    TweenService:Create(Frame, TweenInfo.new(0.12), {
        BackgroundTransparency = 0
    }):Play();
    local Frame2 = Instance.new("Frame");
    Frame2.Name = "Canvas";
    Frame2.Size = UDim2.fromOffset(6000, 6000);
    Frame2.BackgroundTransparency = 1;
    Frame2.ZIndex = 41;
    Frame2.Parent = Frame;

    for _, v in ipairs({ 0, 1 }) do
        local Frame3 = Instance.new("Frame");
        Frame3.AnchorPoint = Vector2.new(0.5, v);
        Frame3.Position = UDim2.fromScale(0.5, v);
        Frame3.Size = UDim2.new(1, 0, 0.22, 0);
        Frame3.BackgroundColor3 = Color3.new(0, 0, 0);
        Frame3.BorderSizePixel = 0;
        Frame3.ZIndex = 47;
        Frame3.Parent = Frame;
        local UIGradient = Instance.new("UIGradient");
        UIGradient.Rotation = v == 0 and 90 or -90;
        UIGradient.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.25), NumberSequenceKeypoint.new(1, 1) });
        UIGradient.Parent = Frame3;
    end;

    local v20 = SkillTreeLayouts[v17] or {};
    local u21 = {};
    local v22 = 0;
    local v23 = {};
    local v24 = 0;

    for i, v in pairs(v18) do
        local v25 = v20[i];

        if v25 then
            u21[i] = Vector2.new(v25[1], v25[2]);

            if v22 < v25[2] then
                v22 = v25[2];
            end;
        else
            local v26 = tostring(v.Set or "?");

            if not v23[v26] then
                v24 = v24 + 1;
                v23[v26] = v24;
            end;
        end;
    end;

    for i, v in pairs(v18) do
        if not u21[i] then
            local v27 = v23[tostring(v.Set or "?")] or 1;
            u21[i] = Vector2.new((v27 - 2) * 9, v22 + 9 + (v.Priority or 1) * 7);
        end;
    end;

    local function canvasPos(p28) -- Line: 326
        -- upvalues: u21 (copy)
        local v29 = u21[p28];

        return Vector2.new(3000 + v29.X * 24, 3000 + v29.Y * 24);
    end;

    local u30 = {};

    local function makeEdge(p31, p32) -- Line: 336
        -- upvalues: u21 (copy), Color3_fromRGB_ret8 (ref), Frame2 (copy), Color3_fromRGB_ret4 (ref), Color3_fromRGB_ret5 (ref), u30 (copy)
        local v33 = u21[p31];
        local Vector2_new_ret = Vector2.new(3000 + v33.X * 24, 3000 + v33.Y * 24);
        local v34 = u21[p32];
        local Vector2_new_ret2 = Vector2.new(3000 + v34.X * 24, 3000 + v34.Y * 24);
        local v35 = Vector2_new_ret2 - Vector2_new_ret;
        local Magnitude = v35.Magnitude;

        if Magnitude < 1 then
            return;
        end;

        local v36 = (Vector2_new_ret + Vector2_new_ret2) / 2;
        local Frame3 = Instance.new("Frame");
        Frame3.AnchorPoint = Vector2.new(0.5, 0.5);
        Frame3.Position = UDim2.fromOffset(v36.X, v36.Y);
        Frame3.Size = UDim2.fromOffset(Magnitude, 5);
        local math_atan2_ret = math.atan2(v35.Y, v35.X);
        Frame3.Rotation = math.deg(math_atan2_ret);
        Frame3.BackgroundColor3 = Color3_fromRGB_ret8;
        Frame3.BorderSizePixel = 0;
        Frame3.ZIndex = 42;
        Frame3.Parent = Frame2;
        local UICorner = Instance.new("UICorner");
        UICorner.CornerRadius = UDim.new(1, 0);
        UICorner.Parent = Frame3;
        local Frame4 = Instance.new("Frame");
        Frame4.AnchorPoint = Vector2.new(0, 0.5);
        Frame4.Position = UDim2.fromScale(0, 0.5);
        Frame4.Size = UDim2.fromScale(0, 1);
        Frame4.BackgroundColor3 = Color3_fromRGB_ret4;
        Frame4.BorderSizePixel = 0;
        Frame4.ZIndex = 43;
        Frame4.Parent = Frame3;
        local UICorner2 = Instance.new("UICorner");
        UICorner2.CornerRadius = UDim.new(1, 0);
        UICorner2.Parent = Frame4;
        local UIGradient = Instance.new("UIGradient");
        UIGradient.Color = ColorSequence.new(Color3_fromRGB_ret5, Color3_fromRGB_ret4);
        UIGradient.Parent = Frame4;
        u30[p32] = u30[p32] or {};
        table.insert(u30[p32], {
            fill = Frame4,
            base = Frame3
        });
    end;

    local u37 = {};
    local u38 = {};
    local u39 = {};

    for i, v in pairs(v18) do
        local v40 = i;

        for _, v2 in ipairs(v.SkillRequirements or {}) do
            if v2[3] == "SkillStat" and v18[v2[1]] then
                makeEdge(v2[1], v40);
            end;
        end;
    end;

    local Frame3 = Instance.new("Frame");
    Frame3.Name = "DescPanel";
    Frame3.AnchorPoint = Vector2.new(1, 0.5);
    Frame3.Position = UDim2.new(1, -16, 0.5, 0);
    Frame3.Size = UDim2.fromOffset(300, 312);
    Frame3.BackgroundColor3 = Color3_fromRGB_ret2;
    Frame3.BackgroundTransparency = 0.04;
    Frame3.BorderSizePixel = 0;
    Frame3.Visible = false;
    Frame3.ZIndex = 60;
    Frame3.Parent = Frame;
    local UIStroke = Instance.new("UIStroke");
    UIStroke.Color = Color3_fromRGB_ret3;
    UIStroke.Thickness = 1.5;
    UIStroke.Parent = Frame3;
    local TextLabel = Instance.new("TextLabel");
    TextLabel.Position = UDim2.new(0, 14, 0, 8);
    TextLabel.Size = UDim2.new(1, -28, 0, 30);
    TextLabel.BackgroundTransparency = 1;
    TextLabel.Font = Garamond;
    TextLabel.TextSize = 24;
    TextLabel.TextColor3 = Color3_fromRGB_ret7;
    TextLabel.TextXAlignment = Enum.TextXAlignment.Left;
    TextLabel.TextTruncate = Enum.TextTruncate.AtEnd;
    TextLabel.ZIndex = 61;
    TextLabel.Parent = Frame3;
    souls_hairline(Frame3, UDim2.new(0.5, 0, 0, 44));
    local TextLabel2 = Instance.new("TextLabel");
    TextLabel2.Position = UDim2.new(0, 14, 0, 52);
    TextLabel2.Size = UDim2.new(1, -28, 0, 84);
    TextLabel2.BackgroundTransparency = 1;
    TextLabel2.Font = Garamond;
    TextLabel2.TextSize = 16;
    TextLabel2.TextColor3 = Color3_fromRGB_ret6;
    TextLabel2.TextWrapped = true;
    TextLabel2.TextXAlignment = Enum.TextXAlignment.Left;
    TextLabel2.TextYAlignment = Enum.TextYAlignment.Top;
    TextLabel2.TextTruncate = Enum.TextTruncate.AtEnd;
    TextLabel2.ZIndex = 61;
    TextLabel2.Parent = Frame3;
    souls_hairline(Frame3, UDim2.new(0.5, 0, 0, 142));
    local TextLabel3 = Instance.new("TextLabel");
    TextLabel3.Position = UDim2.new(0, 14, 0, 148);
    TextLabel3.Size = UDim2.new(1, -28, 0, 20);
    TextLabel3.BackgroundTransparency = 1;
    TextLabel3.Font = Garamond;
    TextLabel3.TextSize = 18;
    TextLabel3.TextColor3 = Color3_fromRGB_ret4;
    TextLabel3.Text = "Requirements";
    TextLabel3.TextXAlignment = Enum.TextXAlignment.Left;
    TextLabel3.ZIndex = 61;
    TextLabel3.Parent = Frame3;
    local Frame4 = Instance.new("Frame");
    Frame4.Position = UDim2.new(0, 14, 0, 172);
    Frame4.Size = UDim2.new(1, -28, 0, 58);
    Frame4.BackgroundTransparency = 1;
    Frame4.ZIndex = 61;
    Frame4.Parent = Frame3;
    local UIListLayout = Instance.new("UIListLayout");
    UIListLayout.Padding = UDim.new(0, 3);
    UIListLayout.Parent = Frame4;
    local TextLabel4 = Instance.new("TextLabel");
    TextLabel4.Position = UDim2.new(0, 14, 1, -72);
    TextLabel4.Size = UDim2.new(1, -28, 0, 22);
    TextLabel4.BackgroundTransparency = 1;
    TextLabel4.Font = Garamond;
    TextLabel4.TextSize = 18;
    TextLabel4.TextColor3 = Color3_fromRGB_ret4;
    TextLabel4.TextXAlignment = Enum.TextXAlignment.Left;
    TextLabel4.ZIndex = 61;
    TextLabel4.Parent = Frame3;
    local TextButton = Instance.new("TextButton");
    TextButton.AnchorPoint = Vector2.new(0.5, 1);
    TextButton.Position = UDim2.new(0.5, 0, 1, -10);
    TextButton.Size = UDim2.new(1, -28, 0, 34);
    TextButton.BackgroundColor3 = Color3.fromRGB(26, 22, 16);
    TextButton.Font = Garamond;
    TextButton.TextSize = 20;
    TextButton.Text = "Unlock";
    TextButton.TextColor3 = Color3_fromRGB_ret5;
    TextButton.ZIndex = 61;
    TextButton.Parent = Frame3;
    local UIStroke2 = Instance.new("UIStroke");
    UIStroke2.Color = Color3_fromRGB_ret4;
    UIStroke2.Thickness = 1.5;
    UIStroke2.Parent = TextButton;

    local function addReqLine(p41) -- Line: 474
        -- upvalues: Garamond (ref), Color3_fromRGB_ret6 (ref), Frame4 (copy)
        local TextLabel5 = Instance.new("TextLabel");
        TextLabel5.Size = UDim2.new(1, 0, 0, 17);
        TextLabel5.BackgroundTransparency = 1;
        TextLabel5.Font = Garamond;
        TextLabel5.TextSize = 15;
        TextLabel5.TextColor3 = Color3_fromRGB_ret6;
        TextLabel5.Text = "•  " .. p41;
        TextLabel5.TextXAlignment = Enum.TextXAlignment.Left;
        TextLabel5.TextTruncate = Enum.TextTruncate.AtEnd;
        TextLabel5.ZIndex = 61;
        TextLabel5.Parent = Frame4;

        return TextLabel5;
    end;

    local function styleNode(p42, p43, p44) -- Line: 489
        -- upvalues: u38 (copy), u39 (copy), Color3_fromRGB_ret4 (ref), u30 (copy), TweenService (ref), Color3_fromRGB_ret5 (ref), Debris (ref), Color3_fromRGB_ret3 (ref)
        local v45 = u38[p42];

        if not v45 then
            return;
        end;

        local v46 = u39[p42];
        local Icon = v45:FindFirstChild("Icon");

        if p43 then
            v46.Color = Color3_fromRGB_ret4;
            v46.Thickness = 4;

            if Icon then
                Icon.ImageColor3 = Color3.fromRGB(255, 255, 255);
            end;

            for _, v in ipairs(u30[p42] or {}) do
                if p44 then
                    TweenService:Create(v.fill, TweenInfo.new(0.45, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
                        Size = UDim2.fromScale(1, 1)
                    }):Play();
                else
                    v.fill.Size = UDim2.fromScale(1, 1);
                end;
            end;

            if p44 then
                local Frame5 = Instance.new("Frame");
                Frame5.AnchorPoint = Vector2.new(0.5, 0.5);
                Frame5.Position = UDim2.fromScale(0.5, 0.5);
                Frame5.Size = UDim2.fromOffset(64, 64);
                Frame5.BackgroundTransparency = 1;
                Frame5.ZIndex = 46;
                Frame5.Parent = v45;
                local UIStroke3 = Instance.new("UIStroke");
                UIStroke3.Color = Color3_fromRGB_ret5;
                UIStroke3.Thickness = 5;
                UIStroke3.Parent = Frame5;
                local UICorner = Instance.new("UICorner");
                UICorner.CornerRadius = UDim.new(0, 10);
                UICorner.Parent = Frame5;
                TweenService:Create(Frame5, TweenInfo.new(0.55, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
                    Size = UDim2.fromOffset(153.6, 153.6)
                }):Play();
                TweenService:Create(UIStroke3, TweenInfo.new(0.55, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
                    Transparency = 1,
                    Thickness = 1
                }):Play();
                Debris:AddItem(Frame5, 0.6);
            end;
        else
            v46.Color = Color3_fromRGB_ret3;
            v46.Thickness = 2.5;

            if Icon then
                Icon.ImageColor3 = Color3.fromRGB(125, 118, 105);
            end;
        end;
    end;

    local TextLabel5 = Instance.new("TextLabel");
    TextLabel5.AnchorPoint = Vector2.new(1, 1);
    TextLabel5.Position = UDim2.new(1, -22, 1, -14);
    TextLabel5.Size = UDim2.fromOffset(280, 30);
    TextLabel5.BackgroundTransparency = 1;
    TextLabel5.Font = Garamond;
    TextLabel5.TextSize = 26;
    TextLabel5.TextColor3 = Color3_fromRGB_ret4;
    TextLabel5.TextXAlignment = Enum.TextXAlignment.Right;
    TextLabel5.Text = "Skill Points: " .. tostring(v19);
    TextLabel5.ZIndex = 60;
    TextLabel5.Parent = Frame;
    local TextLabel6 = Instance.new("TextLabel");
    TextLabel6.Position = UDim2.new(0, 24, 0, 12);
    TextLabel6.Size = UDim2.fromOffset(500, 42);
    TextLabel6.BackgroundTransparency = 1;
    TextLabel6.Font = Garamond;
    TextLabel6.TextSize = 36;
    TextLabel6.TextColor3 = Color3_fromRGB_ret7;
    TextLabel6.TextXAlignment = Enum.TextXAlignment.Left;
    TextLabel6.Text = string.upper(v17:gsub(" Skill Tree", "")) .. "  ARTS";
    TextLabel6.ZIndex = 60;
    TextLabel6.Parent = Frame;
    local u47 = nil;
    local u48 = nil;

    local function onClicked(p49, p50) -- Line: 563
        -- upvalues: SoundManager (ref), LocalPlayer (ref), u21 (copy), TweenService (ref), Frame2 (copy), TweenInfo_new_ret (ref), u47 (ref), Frame3 (copy), TextLabel (copy), TextLabel2 (copy), TextLabel4 (copy), Frame4 (copy), TextLabel3 (copy), addReqLine (copy), StatRetrieveRemote (ref), TextButton (copy), Color3_fromRGB_ret6 (ref), UIStroke2 (copy), Color3_fromRGB_ret3 (ref), Color3_fromRGB_ret5 (ref), Color3_fromRGB_ret4 (ref), u48 (ref), u15 (copy), SkillTreeRemote (ref), u37 (copy), styleNode (copy), TextLabel5 (copy)
        SoundManager.AddSound("Click Sound", {
            Parent = LocalPlayer
        }, "Client");
        local workspace_CurrentCamera = workspace.CurrentCamera;
        local v51 = workspace_CurrentCamera and workspace_CurrentCamera.ViewportSize or Vector2.new(1280, 720);
        local v52 = u21[p49];
        local Vector2_new_ret = Vector2.new(3000 + v52.X * 24, 3000 + v52.Y * 24);
        TweenService:Create(Frame2, TweenInfo_new_ret, {
            Position = UDim2.fromOffset(v51.X / 2 - Vector2_new_ret.X, v51.Y / 2 - Vector2_new_ret.Y)
        }):Play();
        local u53 = p50.Name or p49;
        local SkillPoints = p50.SkillPoints;
        local v54 = p50.Desc or "";
        local SkillRequirements = p50.SkillRequirements;
        local GivesSkill = p50.GivesSkill;
        local GivesPassive = p50.GivesPassive;
        local u55;

        if GivesPassive then
            u55 = p50.PassiveInfo;
        else
            u55 = GivesPassive;
        end;

        local Transformation2 = p50.Transformation;

        if u53 == u47 and Frame3.Visible then
            Frame3.Visible = false;
            u47 = nil;

            return;
        end;

        u47 = u53;
        Frame3.Visible = true;
        TextLabel.Text = u53;
        TextLabel2.Text = v54;
        TextLabel4.Text = "Cost: " .. tostring(SkillPoints) .. " Skill Points";

        for _, child in ipairs(Frame4:GetChildren()) do
            if child:IsA("TextLabel") then
                child:Destroy();
            end;
        end;

        if SkillRequirements and #SkillRequirements > 0 then
            TextLabel3.Visible = true;

            for _, v in ipairs(SkillRequirements) do
                if v[3] == "Tool" then
                    addReqLine(tostring(v[2]) .. "x " .. tostring(v[1]));
                elseif v[1] == "SubType" or v[3] == nil and typeof(v[2]) == "string" then
                    addReqLine((tostring(v[2])));
                elseif v[3] == "SkillStat" then
                    addReqLine(tostring(v[1]) .. " learned");
                else
                    addReqLine(tostring(v[1]) .. "  " .. tostring(v[2]));
                end;
            end;
        else
            TextLabel3.Visible = true;
            addReqLine("None");
        end;

        local v56;

        if Transformation2 then
            v56 = StatRetrieveRemote:InvokeServer(u53, "Transformation");
        else
            v56 = StatRetrieveRemote:InvokeServer(u53, "SkillStat");
        end;

        if v56 then
            v56 = v56.Unlocked;
        end;

        if v56 == true then
            TextButton.Text = "Learned";
            TextButton.Active = false;
            TextButton.AutoButtonColor = false;
            TextButton.TextColor3 = Color3_fromRGB_ret6;
            UIStroke2.Color = Color3_fromRGB_ret3;

            return;
        end;

        TextButton.Text = "Unlock";
        TextButton.Active = true;
        TextButton.AutoButtonColor = true;
        TextButton.TextColor3 = Color3_fromRGB_ret5;
        UIStroke2.Color = Color3_fromRGB_ret4;

        if u48 then
            u48:Disconnect();
        end;

        u48 = TextButton.MouseButton1Up:Connect(function() -- Line: 639
            -- upvalues: u53 (copy), SkillPoints (copy), SkillRequirements (copy), u15 (ref), GivesSkill (copy), GivesPassive (copy), u55 (copy), Transformation2 (copy), SkillTreeRemote (ref), u37 (ref), styleNode (ref), SoundManager (ref), LocalPlayer (ref), StatRetrieveRemote (ref), TextLabel5 (ref), TextButton (ref), Color3_fromRGB_ret6 (ref), UIStroke2 (ref), Color3_fromRGB_ret3 (ref), u48 (ref)
            if SkillTreeRemote:InvokeServer({
                Name = u53,
                SkillPoint_Req = SkillPoints,
                Requirements = SkillRequirements,
                SkillType = u15,
                GivesSkill = GivesSkill,
                GivesPassive = GivesPassive,
                PassiveInfo = u55,
                Transformation = Transformation2
            }) then
                u37[u53] = true;
                styleNode(u53, true, true);
                SoundManager.AddSound("Skill Unlock", {
                    Parent = LocalPlayer
                }, "Client");
                local v57 = StatRetrieveRemote:InvokeServer("StatPoints");
                TextLabel5.Text = "Skill Points: " .. tostring(v57);
                TextButton.Text = "Learned";
                TextButton.Active = false;
                TextButton.AutoButtonColor = false;
                TextButton.TextColor3 = Color3_fromRGB_ret6;
                UIStroke2.Color = Color3_fromRGB_ret3;
            end;

            u48:Disconnect();
        end);
    end;

    local function makeNode(u58, u59) -- Line: 671
        -- upvalues: u21 (copy), Frame2 (copy), Color3_fromRGB_ret3 (ref), Garamond (ref), Color3_fromRGB_ret7 (ref), u38 (copy), u39 (copy), onClicked (copy), u9 (ref), StatRetrieveRemote (ref), u37 (copy), styleNode (copy)
        local v60 = u21[u58];
        local Vector2_new_ret = Vector2.new(3000 + v60.X * 24, 3000 + v60.Y * 24);
        local ImageButton = Instance.new("ImageButton");
        ImageButton.Name = u58;
        ImageButton.AnchorPoint = Vector2.new(0.5, 0.5);
        ImageButton.Position = UDim2.fromOffset(Vector2_new_ret.X, Vector2_new_ret.Y);
        ImageButton.Size = UDim2.fromOffset(64, 64);
        ImageButton.BackgroundColor3 = Color3.fromRGB(22, 19, 15);
        ImageButton.ZIndex = 44;
        ImageButton.Parent = Frame2;
        local UICorner = Instance.new("UICorner");
        UICorner.CornerRadius = UDim.new(0, 8);
        UICorner.Parent = ImageButton;
        local UIStroke3 = Instance.new("UIStroke");
        UIStroke3.Color = Color3_fromRGB_ret3;
        UIStroke3.Thickness = 2.5;
        UIStroke3.Parent = ImageButton;
        local ImageLabel = Instance.new("ImageLabel");
        ImageLabel.Name = "Icon";
        ImageLabel.AnchorPoint = Vector2.new(0.5, 0.5);
        ImageLabel.Position = UDim2.fromScale(0.5, 0.5);
        ImageLabel.Size = UDim2.new(1, -8, 1, -8);
        ImageLabel.BackgroundTransparency = 1;
        ImageLabel.Image = u59.Image or "";
        ImageLabel.ImageColor3 = Color3.fromRGB(125, 118, 105);
        ImageLabel.ScaleType = Enum.ScaleType.Fit;
        ImageLabel.ZIndex = 45;
        ImageLabel.Parent = ImageButton;
        local UICorner2 = Instance.new("UICorner");
        UICorner2.CornerRadius = UDim.new(0, 6);
        UICorner2.Parent = ImageLabel;

        if not (u59.Image and u59.Image:match("%d")) then
            local TextLabel7 = Instance.new("TextLabel");
            TextLabel7.Name = "NoArtMark";
            TextLabel7.BackgroundTransparency = 1;
            TextLabel7.Size = UDim2.fromScale(1, 1);
            TextLabel7.Text = "?";
            TextLabel7.TextScaled = true;
            TextLabel7.Font = Enum.Font.Bangers;
            TextLabel7.TextColor3 = Color3.new(1, 1, 1);
            TextLabel7.ZIndex = 46;
            TextLabel7.Parent = ImageLabel;
            ImageLabel:GetPropertyChangedSignal("ImageColor3"):Connect(function() -- Line: 711
                -- upvalues: TextLabel7 (copy), ImageLabel (copy)
                TextLabel7.TextColor3 = ImageLabel.ImageColor3;
            end);
            TextLabel7.TextColor3 = ImageLabel.ImageColor3;
        end;

        local TextLabel7 = Instance.new("TextLabel");
        TextLabel7.AnchorPoint = Vector2.new(0.5, 0);
        TextLabel7.Position = UDim2.new(0.5, 0, 1, 4);
        TextLabel7.Size = UDim2.fromOffset(140.8, 20);
        TextLabel7.BackgroundTransparency = 1;
        TextLabel7.Font = Garamond;
        TextLabel7.Text = u58;
        TextLabel7.TextSize = 16;
        TextLabel7.TextColor3 = Color3_fromRGB_ret7;
        TextLabel7.TextStrokeTransparency = 0.5;
        TextLabel7.ZIndex = 45;
        TextLabel7.Parent = ImageButton;
        local TextLabel8 = Instance.new("TextLabel");
        TextLabel8.AnchorPoint = Vector2.new(0.5, 1);
        TextLabel8.Position = UDim2.new(0.5, 0, 0, -3);
        TextLabel8.Size = UDim2.fromOffset(70, 15);
        TextLabel8.BackgroundTransparency = 1;
        TextLabel8.Font = Garamond;
        TextLabel8.Text = u59.SkillPoints .. " SP";
        TextLabel8.TextSize = 13;
        TextLabel8.TextColor3 = Color3_fromRGB_ret3;
        TextLabel8.ZIndex = 45;
        TextLabel8.Parent = ImageButton;
        u38[u58] = ImageButton;
        u39[u58] = UIStroke3;
        local v61 = ImageButton.MouseButton1Up:Connect(function() -- Line: 745
            -- upvalues: onClicked (ref), u58 (copy), u59 (copy)
            onClicked(u58, u59);
        end);

        if u9 then
            table.insert(u9.connections, v61);
        end;

        task.spawn(function() -- Line: 749
            -- upvalues: u59 (copy), StatRetrieveRemote (ref), u58 (copy), u37 (ref), styleNode (ref)
            local v62;

            if u59.Transformation then
                v62 = StatRetrieveRemote:InvokeServer(u58, "Transformation");
            else
                v62 = StatRetrieveRemote:InvokeServer(u58, "SkillStat");
            end;

            if v62 and v62.Unlocked == true then
                u37[u58] = true;
                styleNode(u58, true, false);
            end;
        end);
    end;

    for i, v in pairs(v18) do
        makeNode(i, v);
    end;

    local v63 = 0;
    local v64 = 0;
    local v65 = 0;

    for i in pairs(v18) do
        local v66 = u21[i];
        local Vector2_new_ret = Vector2.new(3000 + v66.X * 24, 3000 + v66.Y * 24);
        v63 = v63 + Vector2_new_ret.X;
        v64 = v64 + Vector2_new_ret.Y;
        v65 = v65 + 1;
    end;

    if v65 > 0 then
        v63 = v63 / v65;
        v64 = v64 / v65;
    end;

    local workspace_CurrentCamera = workspace.CurrentCamera;
    local v67 = workspace_CurrentCamera and workspace_CurrentCamera.ViewportSize or Vector2.new(1280, 720);
    Frame2.Position = UDim2.fromOffset(v67.X / 2 - v63, v67.Y / 2 - v64);
    local TextButton2 = Instance.new("TextButton");
    TextButton2.Name = "CloseButton";
    TextButton2.AnchorPoint = Vector2.new(1, 0);
    TextButton2.Position = UDim2.new(1, -18, 0, 14);
    TextButton2.Size = UDim2.fromOffset(110, 36);
    TextButton2.BackgroundColor3 = Color3_fromRGB_ret2;
    TextButton2.Font = Garamond;
    TextButton2.Text = "Close  ✕";
    TextButton2.TextSize = 22;
    TextButton2.TextColor3 = Color3_fromRGB_ret7;
    TextButton2.ZIndex = 60;
    TextButton2.Parent = Frame;
    local UIStroke3 = Instance.new("UIStroke");
    UIStroke3.Color = Color3_fromRGB_ret3;
    UIStroke3.Thickness = 1.5;
    UIStroke3.Parent = TextButton2;
    local v68 = TextButton2.MouseButton1Up:Connect(function() -- Line: 790
        Close_SkillTree();
    end);

    if u9 then
        table.insert(u9.connections, v68);
    end;

    local TextButton3 = Instance.new("TextButton");
    TextButton3.Name = "TreesButton";
    TextButton3.AnchorPoint = Vector2.new(1, 0);
    TextButton3.Position = UDim2.new(1, -136, 0, 14);
    TextButton3.Size = UDim2.fromOffset(110, 36);
    TextButton3.BackgroundColor3 = Color3_fromRGB_ret2;
    TextButton3.Font = Garamond;
    TextButton3.Text = "Trees  ☰";
    TextButton3.TextSize = 22;
    TextButton3.TextColor3 = Color3_fromRGB_ret7;
    TextButton3.ZIndex = 60;
    TextButton3.Parent = Frame;
    local UIStroke4 = Instance.new("UIStroke");
    UIStroke4.Color = Color3_fromRGB_ret3;
    UIStroke4.Thickness = 1.5;
    UIStroke4.Parent = TextButton3;
    local v69 = TextButton3.MouseButton1Up:Connect(function() -- Line: 808
        Close_SkillTree();
        Open_SkillTreeMenu();
    end);

    if u9 then
        table.insert(u9.connections, v69);
    end;

    local TextLabel7 = Instance.new("TextLabel");
    TextLabel7.AnchorPoint = Vector2.new(0.5, 1);
    TextLabel7.Position = UDim2.new(0.5, 0, 1, -12);
    TextLabel7.Size = UDim2.fromOffset(500, 22);
    TextLabel7.BackgroundTransparency = 1;
    TextLabel7.Font = Garamond;
    TextLabel7.Text = "WASD to survey  •  Select a node to inspect";
    TextLabel7.TextSize = 18;
    TextLabel7.TextColor3 = Color3_fromRGB_ret6;
    TextLabel7.ZIndex = 60;
    TextLabel7.Parent = Frame;
    ContextActionService:BindActionAtPriority("SkillTreePanSink", function() -- Line: 825
        return Enum.ContextActionResult.Sink;
    end, false, Enum.ContextActionPriority.High.Value, Enum.KeyCode.W, Enum.KeyCode.A, Enum.KeyCode.S, Enum.KeyCode.D, Enum.PlayerActions.CharacterForward, Enum.PlayerActions.CharacterBackward, Enum.PlayerActions.CharacterLeft, Enum.PlayerActions.CharacterRight);
    u9.renderCon = RunService.RenderStepped:Connect(function(p70) -- Line: 833
        -- upvalues: Frame (copy), UserInputService (ref), Frame2 (copy)
        if not Frame.Parent then
            return;
        end;

        local v71 = 0;
        local v72 = 0;

        if UserInputService:IsKeyDown(Enum.KeyCode.W) then
            v72 = v72 + 1;
        end;

        if UserInputService:IsKeyDown(Enum.KeyCode.S) then
            v72 = v72 - 1;
        end;

        if UserInputService:IsKeyDown(Enum.KeyCode.A) then
            v71 = v71 + 1;
        end;

        if UserInputService:IsKeyDown(Enum.KeyCode.D) then
            v71 = v71 - 1;
        end;

        if v71 ~= 0 or v72 ~= 0 then
            local Position = Frame2.Position;
            local math_clamp_ret = math.clamp(Position.X.Offset + v71 * 750 * p70, -5800, 200);
            local math_clamp_ret2 = math.clamp(Position.Y.Offset + v72 * 750 * p70, -5800, 200);
            Frame2.Position = UDim2.fromOffset(math_clamp_ret, math_clamp_ret2);
        end;
    end);
end;

function Open_SkillTreeMenu()
    -- upvalues: u9 (ref), Begin_TreeSession (copy), LocalPlayer (copy), Color3_fromRGB_ret (copy), TweenService (copy), Garamond (copy), Color3_fromRGB_ret7 (copy), Color3_fromRGB_ret6 (copy), Color3_fromRGB_ret3 (copy), StatRetrieveRemote (copy), u10 (ref), u11 (ref), Color3_fromRGB_ret5 (copy), Color3_fromRGB_ret4 (copy)
    if u9 then
        return;
    end;

    if not Begin_TreeSession() then
        return;
    end;

    local PopupGui = LocalPlayer.PlayerGui:FindFirstChild("PopupGui");
    local Frame = Instance.new("Frame");
    Frame.Name = "SkillFrame";
    Frame.Size = UDim2.fromScale(1, 1);
    Frame.BackgroundColor3 = Color3_fromRGB_ret;
    Frame.BackgroundTransparency = 1;
    Frame.BorderSizePixel = 0;
    Frame.ZIndex = 55;
    Frame.Parent = PopupGui;
    u9.chooser = Frame;
    TweenService:Create(Frame, TweenInfo.new(0.12), {
        BackgroundTransparency = 0.06
    }):Play();
    local TextLabel = Instance.new("TextLabel");
    TextLabel.AnchorPoint = Vector2.new(0.5, 0);
    TextLabel.Position = UDim2.new(0.5, 0, 0.16, 0);
    TextLabel.Size = UDim2.fromOffset(700, 60);
    TextLabel.BackgroundTransparency = 1;
    TextLabel.Font = Garamond;
    TextLabel.Text = "S K I L L   T R E E S";
    TextLabel.TextSize = 52;
    TextLabel.TextColor3 = Color3_fromRGB_ret7;
    TextLabel.ZIndex = 56;
    TextLabel.Parent = Frame;
    local TextLabel2 = Instance.new("TextLabel");
    TextLabel2.AnchorPoint = Vector2.new(0.5, 0);
    TextLabel2.Position = UDim2.new(0.5, 0, 0.16, 58);
    TextLabel2.Size = UDim2.fromOffset(700, 26);
    TextLabel2.BackgroundTransparency = 1;
    TextLabel2.Font = Garamond;
    TextLabel2.Text = "Choose the path of your power";
    TextLabel2.TextSize = 22;
    TextLabel2.TextColor3 = Color3_fromRGB_ret6;
    TextLabel2.ZIndex = 56;
    TextLabel2.Parent = Frame;
    local Frame2 = Instance.new("Frame");
    Frame2.AnchorPoint = Vector2.new(0.5, 0);
    Frame2.Position = UDim2.new(0.5, 0, 0.16, 94);
    Frame2.Size = UDim2.fromOffset(460, 1);
    Frame2.BackgroundColor3 = Color3_fromRGB_ret3;
    Frame2.BackgroundTransparency = 0.3;
    Frame2.BorderSizePixel = 0;
    Frame2.ZIndex = 56;
    Frame2.Parent = Frame;
    task.spawn(function() -- Line: 905
        -- upvalues: StatRetrieveRemote (ref), Frame (copy)
        local v73 = StatRetrieveRemote:InvokeServer("Race");
        local v74 = Frame and Frame.Parent and Frame:FindFirstChild("Row_Race");
        local v75 = v73 and (v74 and v74:FindFirstChild("RowLabel"));

        if v75 then
            v75.Text = string.upper(v73) .. "  BLOODLINE";
        end;
    end);

    local function Open_Tree(p76) -- Line: 914
        -- upvalues: u10 (ref), u11 (ref), u9 (ref), Frame (copy)
        if u10 then
            return;
        end;

        u10 = true;
        u11 = p76;

        if u9 then
            u9.chooser = nil;
        end;

        Frame:Destroy();
        local success, result = pcall(Open_SkillTree, p76, p76 .. "Skills");
        u10 = false;

        if not success then
            warn("[SkillTree] open failed:", result);
            Close_SkillTree();
        end;
    end;

    for i, v in ipairs({ {
            name = "Basic",
            label = "BASIC ARTS",
            desc = "The fundamentals of a warrior"
        }, {
            name = "Ki",
            label = "KI ARTS",
            desc = "Mastery over inner energy"
        }, {
            name = "Race",
            label = "BLOODLINE ARTS",
            desc = "The legacy of your kind"
        } }) do
        local TextButton = Instance.new("TextButton");
        TextButton.Name = "Row_" .. v.name;
        TextButton.AnchorPoint = Vector2.new(0.5, 0);
        TextButton.Position = UDim2.new(0.5, 0, 0.36 + (i - 1) * 0.13, 0);
        TextButton.Size = UDim2.fromOffset(520, 74);
        TextButton.BackgroundTransparency = 1;
        TextButton.Text = "";
        TextButton.ZIndex = 56;
        TextButton.Parent = Frame;
        local TextLabel3 = Instance.new("TextLabel");
        TextLabel3.Name = "RowLabel";
        TextLabel3.AnchorPoint = Vector2.new(0.5, 0);
        TextLabel3.Position = UDim2.new(0.5, 0, 0, 8);
        TextLabel3.Size = UDim2.new(1, 0, 0, 34);
        TextLabel3.BackgroundTransparency = 1;
        TextLabel3.Font = Garamond;
        TextLabel3.Text = v.label;
        TextLabel3.TextSize = 32;
        TextLabel3.TextColor3 = Color3_fromRGB_ret7;
        TextLabel3.ZIndex = 57;
        TextLabel3.Parent = TextButton;
        local TextLabel4 = Instance.new("TextLabel");
        TextLabel4.AnchorPoint = Vector2.new(0.5, 0);
        TextLabel4.Position = UDim2.new(0.5, 0, 0, 42);
        TextLabel4.Size = UDim2.new(1, 0, 0, 20);
        TextLabel4.BackgroundTransparency = 1;
        TextLabel4.Font = Garamond;
        TextLabel4.Text = v.desc;
        TextLabel4.TextSize = 17;
        TextLabel4.TextColor3 = Color3_fromRGB_ret6;
        TextLabel4.TextTransparency = 0.35;
        TextLabel4.ZIndex = 57;
        TextLabel4.Parent = TextButton;
        local Frame3 = Instance.new("Frame");
        Frame3.AnchorPoint = Vector2.new(1, 0.5);
        Frame3.Position = UDim2.new(0, -14, 0, 25);
        Frame3.Size = UDim2.fromOffset(10, 10);
        Frame3.BackgroundColor3 = Color3_fromRGB_ret5;
        Frame3.BackgroundTransparency = 1;
        Frame3.BorderSizePixel = 0;
        Frame3.ZIndex = 57;
        Frame3.Parent = TextButton;
        local UICorner = Instance.new("UICorner");
        UICorner.CornerRadius = UDim.new(1, 0);
        UICorner.Parent = Frame3;
        local Frame4 = Instance.new("Frame");
        Frame4.AnchorPoint = Vector2.new(0.5, 0);
        Frame4.Position = UDim2.new(0.5, 0, 0, 66);
        Frame4.Size = UDim2.fromOffset(0, 1);
        Frame4.BackgroundColor3 = Color3_fromRGB_ret4;
        Frame4.BorderSizePixel = 0;
        Frame4.ZIndex = 57;
        Frame4.Parent = TextButton;
        local v77 = TextButton.MouseEnter:Connect(function() -- Line: 987
            -- upvalues: TextLabel3 (copy), Color3_fromRGB_ret5 (ref), Frame3 (copy), TweenService (ref), Frame4 (copy)
            TextLabel3.TextColor3 = Color3_fromRGB_ret5;
            Frame3.BackgroundTransparency = 0;
            TweenService:Create(Frame4, TweenInfo.new(0.18), {
                Size = UDim2.fromOffset(420, 1)
            }):Play();
        end);

        if u9 then
            table.insert(u9.connections, v77);
        end;

        local v78 = TextButton.MouseLeave:Connect(function() -- Line: 993
            -- upvalues: TextLabel3 (copy), Color3_fromRGB_ret7 (ref), Frame3 (copy), TweenService (ref), Frame4 (copy)
            TextLabel3.TextColor3 = Color3_fromRGB_ret7;
            Frame3.BackgroundTransparency = 1;
            TweenService:Create(Frame4, TweenInfo.new(0.18), {
                Size = UDim2.fromOffset(0, 1)
            }):Play();
        end);

        if u9 then
            table.insert(u9.connections, v78);
        end;

        local v79 = TextButton.MouseButton1Up:Connect(function() -- Line: 999
            -- upvalues: Open_Tree (copy), v (copy)
            Open_Tree(v.name);
        end);

        if u9 then
            table.insert(u9.connections, v79);
        end;
    end;

    local TextLabel3 = Instance.new("TextLabel");
    TextLabel3.AnchorPoint = Vector2.new(0.5, 1);
    TextLabel3.Position = UDim2.new(0.5, 0, 1, -18);
    TextLabel3.Size = UDim2.fromOffset(400, 22);
    TextLabel3.BackgroundTransparency = 1;
    TextLabel3.Font = Garamond;
    TextLabel3.Text = "Press L to return";
    TextLabel3.TextSize = 18;
    TextLabel3.TextColor3 = Color3_fromRGB_ret6;
    TextLabel3.ZIndex = 56;
    TextLabel3.Parent = Frame;
end;

local u80 = {};
local u81 = {};
local u82 = nil;
local u83 = nil;
local u84 = nil;
local u85 = nil;
local u86 = 0;
local u87 = false;
local u88 = nil;
local u89 = {};
local u90 = { 1, 2, 3, 4, 5, 10 };
local u91 = {
    [2] = 15,
    [3] = 30,
    [4] = 45,
    [5] = 60,
    [10] = 100
};

local function Stack_SlotPosition(p92) -- Line: 1053
    local v93 = 10 * (p92 - 1);

    return UDim2.new(1, -v93, 1, -v93);
end;

local function Stack_BuildRoot() -- Line: 1058
    -- upvalues: u82 (ref), u1 (copy), u83 (ref), u84 (ref), u85 (ref), u88 (ref), u90 (copy), u89 (copy), u86 (ref), ServerRemote (copy)
    if u82 then
        return;
    end;

    u82 = Instance.new("Frame");
    u82.Name = "TransformStack";
    u82.AnchorPoint = Vector2.new(0.5, 0.5);
    u82.Position = UDim2.new(0.5, 0, 0.5, 0);
    u82.Size = UDim2.new(0, 344, 0, 178);
    u82.BackgroundTransparency = 1;
    u82.Visible = false;
    u82.ZIndex = 50;
    u82.Parent = u1;
    u83 = Instance.new("Frame");
    u83.Name = "Stack";
    u83.Size = UDim2.new(0, 140, 0, 178);
    u83.BackgroundTransparency = 1;
    u83.ZIndex = 50;
    u83.Parent = u82;
    local Frame = Instance.new("Frame");
    Frame.Name = "DescPanel";
    Frame.AnchorPoint = Vector2.new(0, 1);
    Frame.Position = UDim2.new(0, 154, 1, 0);
    Frame.Size = UDim2.new(0, 190, 0, 148);
    Frame.BackgroundColor3 = Color3.fromRGB(26, 26, 26);
    Frame.BackgroundTransparency = 0.1;
    Frame.BorderSizePixel = 0;
    Frame.ZIndex = 50;
    Frame.Parent = u82;
    local UICorner = Instance.new("UICorner");
    UICorner.CornerRadius = UDim.new(0, 10);
    UICorner.Parent = Frame;
    local UIStroke = Instance.new("UIStroke");
    UIStroke.Color = Color3.fromRGB(58, 58, 58);
    UIStroke.Thickness = 1;
    UIStroke.Parent = Frame;
    local UIPadding = Instance.new("UIPadding");
    UIPadding.PaddingLeft = UDim.new(0, 12);
    UIPadding.PaddingRight = UDim.new(0, 12);
    UIPadding.PaddingTop = UDim.new(0, 10);
    UIPadding.PaddingBottom = UDim.new(0, 10);
    UIPadding.Parent = Frame;
    u84 = Instance.new("TextLabel");
    u84.Name = "Title";
    u84.Size = UDim2.new(1, 0, 0, 18);
    u84.BackgroundTransparency = 1;
    u84.TextSize = 15;
    u84.TextColor3 = Color3.fromRGB(255, 255, 255);
    u84.Font = Enum.Font.GothamBold;
    u84.TextXAlignment = Enum.TextXAlignment.Left;
    u84.ZIndex = 51;
    u84.Parent = Frame;
    local TextLabel = Instance.new("TextLabel");
    TextLabel.Name = "SelectedTag";
    TextLabel.Position = UDim2.new(0, 0, 0, 20);
    TextLabel.Size = UDim2.new(1, 0, 0, 12);
    TextLabel.BackgroundTransparency = 1;
    TextLabel.Text = "SELECTED";
    TextLabel.TextSize = 10;
    TextLabel.TextColor3 = Color3.fromRGB(255, 220, 78);
    TextLabel.Font = Enum.Font.GothamBold;
    TextLabel.TextXAlignment = Enum.TextXAlignment.Left;
    TextLabel.ZIndex = 51;
    TextLabel.Parent = Frame;
    u85 = Instance.new("TextLabel");
    u85.Name = "Body";
    u85.Position = UDim2.new(0, 0, 0, 38);
    u85.Size = UDim2.new(1, 0, 1, -78);
    u85.BackgroundTransparency = 1;
    u85.TextSize = 12;
    u85.TextColor3 = Color3.fromRGB(176, 176, 176);
    u85.Font = Enum.Font.Gotham;
    u85.TextWrapped = true;
    u85.TextXAlignment = Enum.TextXAlignment.Left;
    u85.TextYAlignment = Enum.TextYAlignment.Top;
    u85.ZIndex = 51;
    u85.Parent = Frame;
    local TextLabel2 = Instance.new("TextLabel");
    TextLabel2.Name = "ActivateHint";
    TextLabel2.AnchorPoint = Vector2.new(0, 1);
    TextLabel2.Position = UDim2.new(0, 0, 1, 0);
    TextLabel2.Size = UDim2.new(1, 0, 0, 14);
    TextLabel2.BackgroundTransparency = 1;
    TextLabel2.Text = "[X] / charge to transform";
    TextLabel2.TextSize = 11;
    TextLabel2.TextColor3 = Color3.fromRGB(136, 136, 136);
    TextLabel2.Font = Enum.Font.Gotham;
    TextLabel2.TextXAlignment = Enum.TextXAlignment.Left;
    TextLabel2.ZIndex = 51;
    TextLabel2.Parent = Frame;
    u88 = Instance.new("Frame");
    u88.Name = "KaioRow";
    u88.AnchorPoint = Vector2.new(0, 1);
    u88.Position = UDim2.new(0, 0, 1, -18);
    u88.Size = UDim2.new(1, 0, 0, 20);
    u88.BackgroundTransparency = 1;
    u88.Visible = false;
    u88.ZIndex = 51;
    u88.Parent = Frame;
    local UIListLayout = Instance.new("UIListLayout");
    UIListLayout.FillDirection = Enum.FillDirection.Horizontal;
    UIListLayout.Padding = UDim.new(0, 4);
    UIListLayout.SortOrder = Enum.SortOrder.LayoutOrder;
    UIListLayout.Parent = u88;

    for i, v in ipairs(u90) do
        local TextButton = Instance.new("TextButton");
        TextButton.Name = "Kaio" .. v;
        TextButton.LayoutOrder = i;
        TextButton.Size = UDim2.new(0, 23, 1, 0);
        TextButton.BackgroundColor3 = Color3.fromRGB(26, 26, 26);
        TextButton.BorderSizePixel = 0;
        TextButton.AutoButtonColor = true;
        TextButton.Font = Enum.Font.GothamBold;
        TextButton.TextSize = 11;
        TextButton.Text = "x" .. v;
        TextButton.TextColor3 = Color3.fromRGB(176, 176, 176);
        TextButton.ZIndex = 52;
        TextButton.Parent = u88;
        local UICorner2 = Instance.new("UICorner");
        UICorner2.CornerRadius = UDim.new(0, 5);
        UICorner2.Parent = TextButton;
        local UIStroke2 = Instance.new("UIStroke");
        UIStroke2.Name = "Stroke";
        UIStroke2.Color = Color3.fromRGB(58, 58, 58);
        UIStroke2.Thickness = 1;
        UIStroke2.Parent = TextButton;
        u89[v] = TextButton;
        TextButton.Activated:Connect(function() -- Line: 1204
            -- upvalues: u86 (ref), TextButton (copy), ServerRemote (ref), v (copy), u89 (ref)
            u86 = os.clock();

            if TextButton:GetAttribute("Locked") then
                return;
            end;

            ServerRemote:FireServer(nil, {
                Module = "TransformationHandler",
                Action = "SetKaiokenTarget",
                Level = v
            });

            for i2, v2 in pairs(u89) do
                v2.Stroke.Color = i2 == v and Color3.fromRGB(255, 220, 78) or Color3.fromRGB(58, 58, 58);
            end;
        end);
    end;

    local TextLabel3 = Instance.new("TextLabel");
    TextLabel3.Name = "Hint";
    TextLabel3.AnchorPoint = Vector2.new(0.5, 0);
    TextLabel3.Position = UDim2.new(0, 85, 1, 6);
    TextLabel3.Size = UDim2.new(0, 110, 0, 14);
    TextLabel3.BackgroundTransparency = 1;
    TextLabel3.Text = "[G] cycle";
    TextLabel3.TextSize = 11;
    TextLabel3.TextColor3 = Color3.fromRGB(136, 136, 136);
    TextLabel3.Font = Enum.Font.Gotham;
    TextLabel3.ZIndex = 51;
    TextLabel3.Parent = u82;
end;

local function Stack_BuildCard(p94) -- Line: 1234
    -- upvalues: Transformation (copy), u83 (ref)
    local Frame = Instance.new("Frame");
    Frame.Name = "Card_" .. p94.Name;
    Frame.Size = UDim2.new(0, 110, 0, 148);
    Frame.BackgroundColor3 = Color3.fromRGB(37, 37, 37);
    Frame.BorderSizePixel = 0;
    Frame.AnchorPoint = Vector2.new(1, 1);
    local UICorner = Instance.new("UICorner");
    UICorner.CornerRadius = UDim.new(0, 10);
    UICorner.Parent = Frame;
    local UIStroke = Instance.new("UIStroke");
    UIStroke.Name = "Stroke";
    UIStroke.Color = Color3.fromRGB(74, 74, 74);
    UIStroke.Thickness = 2;
    UIStroke.Parent = Frame;
    local ImageLabel = Instance.new("ImageLabel");
    ImageLabel.Name = "TransformImage";
    ImageLabel.AnchorPoint = Vector2.new(0.5, 0);
    ImageLabel.Position = UDim2.new(0.5, 0, 0, 8);
    ImageLabel.Size = UDim2.new(0, 90, 0, 90);
    ImageLabel.BackgroundColor3 = Color3.fromRGB(26, 26, 26);
    ImageLabel.BorderSizePixel = 0;
    ImageLabel.Image = p94.Image or "";
    ImageLabel.ScaleType = Enum.ScaleType.Fit;
    ImageLabel.Parent = Frame;

    if not (p94.Image and tostring(p94.Image):match("%d")) then
        local TextLabel = Instance.new("TextLabel");
        TextLabel.Name = "FormNoArt";
        TextLabel.BackgroundTransparency = 1;
        TextLabel.Size = UDim2.fromScale(1, 1);
        TextLabel.Text = "?";
        TextLabel.TextScaled = true;
        TextLabel.Font = Enum.Font.Bangers;
        TextLabel.TextColor3 = Color3.fromRGB(245, 240, 228);
        TextLabel.ZIndex = ImageLabel.ZIndex + 1;
        TextLabel.Parent = ImageLabel;
    end;

    local UICorner2 = Instance.new("UICorner");
    UICorner2.CornerRadius = UDim.new(0, 6);
    UICorner2.Parent = ImageLabel;
    local TextLabel = Instance.new("TextLabel");
    TextLabel.Name = "TransformName";
    TextLabel.AnchorPoint = Vector2.new(0.5, 0);
    TextLabel.Position = UDim2.new(0.5, 0, 0, 102);
    TextLabel.Size = UDim2.new(1, -10, 0, 16);
    TextLabel.BackgroundTransparency = 1;
    TextLabel.Text = p94.Name;
    TextLabel.TextSize = 13;
    TextLabel.TextColor3 = Color3.fromRGB(255, 255, 255);
    TextLabel.Font = Enum.Font.GothamBold;
    TextLabel.TextTruncate = Enum.TextTruncate.AtEnd;
    TextLabel.Parent = Frame;
    local Frame2 = Instance.new("Frame");
    Frame2.Name = "StarFrame";
    Frame2.AnchorPoint = Vector2.new(0.5, 1);
    Frame2.Position = UDim2.new(0.5, 0, 1, -6);
    Frame2.Size = UDim2.new(1, -16, 0, 14);
    Frame2.BackgroundTransparency = 1;
    Frame2.Parent = Frame;
    local UIListLayout = Instance.new("UIListLayout");
    UIListLayout.FillDirection = Enum.FillDirection.Horizontal;
    UIListLayout.HorizontalAlignment = Enum.HorizontalAlignment.Center;
    UIListLayout.Padding = UDim.new(0, 2);
    UIListLayout.Parent = Frame2;
    local math_floor_ret = math.floor((p94.Mastery or 0) / 20);
    local math_clamp_ret = math.clamp(math_floor_ret, 0, 5);
    local Image = Transformation.MasteryStar.Image;

    for i = 1, 5 do
        local ImageLabel2 = Instance.new("ImageLabel");
        ImageLabel2.Name = "Star" .. i;
        ImageLabel2.Size = UDim2.new(0, 13, 0, 13);
        ImageLabel2.BackgroundTransparency = 1;
        ImageLabel2.Image = Image;
        ImageLabel2.ScaleType = Enum.ScaleType.Fit;
        ImageLabel2.ImageTransparency = i <= math_clamp_ret and 0 or 0.82;
        ImageLabel2:SetAttribute("Earned", i <= math_clamp_ret);
        ImageLabel2.Parent = Frame2;
        local _ = i;
    end;

    Frame.Parent = u83;

    return Frame;
end;

local function Stack_UpdateKaioRow(p95) -- Line: 1328
    -- upvalues: u88 (ref), LocalPlayer (copy), u90 (copy), u89 (copy), u91 (copy)
    if not u88 then
        return;
    end;

    if not p95 or p95.Name ~= "Kaioken" then
        u88.Visible = false;

        return;
    end;

    local v96 = p95.Mastery or 0;
    local v97 = tonumber(LocalPlayer:GetAttribute("KaiokenTarget")) or 1;

    for _, v in ipairs(u90) do
        local v98 = u89[v];
        local v99 = u91[v];
        local v100;

        if v99 == nil then
            v100 = false;
        else
            v100 = v96 < v99;
        end;

        v98:SetAttribute("Locked", v100);
        v98.TextColor3 = v100 and Color3.fromRGB(90, 90, 90) or Color3.fromRGB(255, 255, 255);
        v98.Stroke.Color = v == v97 and not v100 and Color3.fromRGB(255, 220, 78) or Color3.fromRGB(58, 58, 58);
    end;

    u88.Visible = true;
end;

local function Stack_ApplyLayout(p101) -- Line: 1350
    -- upvalues: u80 (ref), u81 (copy), TweenService (copy), u84 (ref), u85 (ref), Stack_UpdateKaioRow (copy)
    for i, v in ipairs(u80) do
        local v102 = u81[v.Name];

        if v102 then
            local v103 = i <= 4;
            v102.Visible = v103;

            if v103 then
                v102.ZIndex = 50 + (4 - i + 1) * 2;
                local v104 = i;

                for _, descendant in ipairs(v102:GetDescendants()) do
                    if descendant:IsA("GuiObject") then
                        descendant.ZIndex = v102.ZIndex + 1;
                    end;
                end;

                local v105 = (v104 - 1) * 0.18;
                local v106 = {};
                local v107 = 10 * (v104 - 1);
                v106.Position = UDim2.new(1, -v107, 1, -v107);
                v106.BackgroundTransparency = math.min(v105, 0.6);

                if p101 then
                    TweenService:Create(v102, TweenInfo.new(0.12, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), v106):Play();
                else
                    v102.Position = v106.Position;
                    v102.BackgroundTransparency = v106.BackgroundTransparency;
                end;

                local math_min_ret = math.min(v105 * 1.6, 0.75);
                v102.TransformImage.ImageTransparency = math_min_ret;
                v102.TransformName.TextTransparency = math_min_ret;
                v102.Stroke.Transparency = math_min_ret;

                for _, child in ipairs(v102.StarFrame:GetChildren()) do
                    if child:IsA("ImageLabel") then
                        local v108 = child:GetAttribute("Earned") and 0 or 0.82;
                        child.ImageTransparency = math.max(v108, math_min_ret);
                    end;
                end;

                v102.Stroke.Color = v104 == 1 and Color3.fromRGB(255, 220, 78) or Color3.fromRGB(74, 74, 74);
            end;
        end;
    end;

    local v109 = u80[1];

    if v109 then
        u84.Text = v109.Name;
        u85.Text = v109.Desc or "";
    end;

    Stack_UpdateKaioRow(v109);
end;

local function Stack_FireSet(p110) -- Line: 1401
    -- upvalues: u5 (ref), ServerRemote (copy)
    u5 = p110;
    ServerRemote:FireServer(nil, {
        Module = "TransformationHandler",
        Action = "Set",
        NewValue = p110
    });
end;

local function Close_TransformStack() -- Line: 1410
    -- upvalues: u82 (ref)
    if u82 then
        u82.Visible = false;
    end;
end;

local function Open_TransformStack() -- Line: 1416
    -- upvalues: GetTransformationsRemote (copy), TransformData (copy), u80 (ref), LocalPlayer (copy), u5 (ref), ServerRemote (copy), Stack_BuildRoot (copy), u81 (copy), Stack_BuildCard (copy), Stack_ApplyLayout (copy), u82 (ref), u87 (ref), u86 (ref)
    local v111 = GetTransformationsRemote:InvokeServer();

    if type(v111) ~= "table" then
        return;
    end;

    local v112 = {};
    local v113 = {};

    for i, v in pairs(v111) do
        if type(v) == "table" then
            local v114 = i;

            for i2, v2 in pairs(v) do
                if type(v2) == "table" and (i2 ~= "Semi Perfect" and (i2 ~= "Perfect Form" and (v2.Unlocked == true and (v2.Can_Toggle == nil or v2.Can_Toggle ~= false)))) then
                    local v115 = TransformData[v114] and TransformData[v114][i2];

                    if type(v115) == "table" then
                        local v116 = {
                            Type = v114,
                            Name = i2,
                            Mastery = tonumber(v2.Mastery) or 0,
                            Image = v115.Image,
                            Desc = v115.Desc
                        };
                        v112[i2] = v116;
                        table.insert(v113, v116);
                    end;
                end;
            end;
        end;
    end;

    if #v113 == 0 then
        return;
    end;

    table.sort(v113, function(p117, p118) -- Line: 1444
        return p117.Name < p118.Name;
    end);
    local v119 = {};
    local v120 = {};

    for _, v in ipairs(u80) do
        local v121 = v112[v.Name];

        if v121 and not v119[v.Name] then
            table.insert(v120, v121);
            v119[v.Name] = true;
        end;
    end;

    for _, v in ipairs(v113) do
        if not v119[v.Name] then
            table.insert(v120, v);
            v119[v.Name] = true;
        end;
    end;

    u80 = v120;
    local PlayerStats = LocalPlayer:FindFirstChild("PlayerStats");

    if PlayerStats then
        PlayerStats = PlayerStats:FindFirstChild("Transformation", true);
    end;

    local v122 = PlayerStats and PlayerStats.Value or "";

    for i, v in ipairs(u80) do
        if v.Name == v122 and i ~= 1 then
            table.insert(u80, 1, table.remove(u80, i));
            break;
        end;
    end;

    if u80[1].Name == v122 then
        u5 = v122;
    else
        local Name = u80[1].Name;
        u5 = Name;
        ServerRemote:FireServer(nil, {
            Module = "TransformationHandler",
            Action = "Set",
            NewValue = Name
        });
    end;

    Stack_BuildRoot();

    for _, v in pairs(u81) do
        v:Destroy();
    end;

    table.clear(u81);

    for _, v in ipairs(u80) do
        u81[v.Name] = Stack_BuildCard(v);
    end;

    Stack_ApplyLayout(false);
    u82.Visible = true;

    if not u87 then
        u87 = true;
        task.spawn(function() -- Line: 1495
            -- upvalues: u82 (ref), u86 (ref)
            while true do
                repeat
                    task.wait(0.2);
                until u82 and (u82.Visible and (os.clock() - u86 > 2 and u82));

                u82.Visible = false;
            end;
        end);
    end;
end;

local function Rotate_TransformStack() -- Line: 1510
    -- upvalues: u80 (ref), u5 (ref), ServerRemote (copy), Stack_ApplyLayout (copy)
    if #u80 < 2 then
        return;
    end;

    table.insert(u80, table.remove(u80, 1));
    local Name = u80[1].Name;
    u5 = Name;
    ServerRemote:FireServer(nil, {
        Module = "TransformationHandler",
        Action = "Set",
        NewValue = Name
    });
    Stack_ApplyLayout(true);
end;

local v123 = {
    ["Skill Tree"] = function() -- Line: 1518
        Toggle_SkillTree();
    end,

    Transformations = function() -- Line: 1521
        -- upvalues: StatRetrieveRemote (copy), u86 (ref), u82 (ref), Open_TransformStack (copy), u80 (ref), u5 (ref), ServerRemote (copy), Stack_ApplyLayout (copy)
        if not StatRetrieveRemote:InvokeServer("KiUnlocked") then
            return;
        end;

        u86 = os.clock();

        if u82 == nil or u82.Visible == false then
            Open_TransformStack();

            return;
        end;

        if #u80 < 2 then
            return;
        end;

        table.insert(u80, table.remove(u80, 1));
        local Name = u80[1].Name;
        u5 = Name;
        ServerRemote:FireServer(nil, {
            Module = "TransformationHandler",
            Action = "Set",
            NewValue = Name
        });
        Stack_ApplyLayout(true);
    end
};
pcall(function() -- Line: 1543
    -- upvalues: ContextActionService (copy)
    ContextActionService:UnbindAction("SkillTreeToggleKey");
end);

return v123;