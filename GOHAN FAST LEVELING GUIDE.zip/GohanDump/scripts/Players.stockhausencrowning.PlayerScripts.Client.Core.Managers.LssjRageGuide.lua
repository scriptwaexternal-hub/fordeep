-- Decompiled with Potassium's decompiler.

local Players = game:GetService("Players");
local Modules = game:GetService("ReplicatedStorage"):WaitForChild("Modules");
local SkillData = require(Modules.Metadata.SkillData.SkillData);
local LocalPlayer = Players.LocalPlayer;
local u1 = { "HUD", "MissionGui", "LoreThoughtsGui", "QuestTrackerGui" };
local Color3_fromRGB_ret = Color3.fromRGB(44, 44, 45);
local Color3_fromRGB_ret2 = Color3.fromRGB(28, 28, 30);
local Color3_fromRGB_ret3 = Color3.fromRGB(255, 255, 255);
Color3.fromRGB(216, 213, 205);
local Color3_fromRGB_ret4 = Color3.fromRGB(0, 0, 0);
local Color3_fromRGB_ret5 = Color3.fromRGB(255, 196, 68);
local Color3_fromRGB_ret6 = Color3.fromRGB(140, 138, 132);
local Color3_fromRGB_ret7 = Color3.fromRGB(226, 62, 48);
Color3.fromRGB(120, 235, 120);
local Arcade = Enum.Font.Arcade;
local u2 = {
    {
        Attr = "LssjCD_Cannon",
        Name = "Eraser Cannon",
        Total = SkillData.Blasts and SkillData.Blasts["Eraser Cannon"] and (SkillData.Blasts["Eraser Cannon"].Cooldown or 60) or 60
    },
    {
        Attr = "LssjCD_Crusher",
        Name = "Bone Crusher",
        Total = SkillData.Melee and (SkillData.Melee["Bone Crusher"] and SkillData.Melee["Bone Crusher"].Cooldown) or 35
    }
};
local v3 = {};
local u4 = false;
local u5 = {};

local function setInterfaceHidden(p6) -- Line: 62
    -- upvalues: LocalPlayer (copy), u5 (copy), u1 (copy)
    local PlayerGui = LocalPlayer:FindFirstChild("PlayerGui");

    if not PlayerGui then
        return;
    end;

    if p6 then
        table.clear(u5);

        for _, v in ipairs(u1) do
            local v7 = PlayerGui:FindFirstChild(v);

            if v7 and v7:IsA("ScreenGui") then
                u5[v] = v7.Enabled;
                v7.Enabled = false;
            end;
        end;

        return;
    end;

    for _, v in ipairs(u1) do
        local v8 = PlayerGui:FindFirstChild(v);

        if v8 and v8:IsA("ScreenGui") then
            local v9 = u5[v];
            v8.Enabled = v9 == nil and true or v9;
        end;
    end;

    table.clear(u5);
end;

local function buildBar(p10, p11, p12, p13, p14, p15) -- Line: 87
    -- upvalues: Color3_fromRGB_ret2 (copy), Color3_fromRGB_ret4 (copy), Arcade (copy), Color3_fromRGB_ret3 (copy)
    local Frame = Instance.new("Frame");
    Frame.Name = p11;
    Frame.AnchorPoint = Vector2.new(0.5, 1);
    Frame.Position = UDim2.new(0.5, 0, 1, p12);
    Frame.Size = UDim2.fromOffset(420, p13);
    Frame.BackgroundColor3 = Color3_fromRGB_ret2;
    Frame.BorderSizePixel = 0;
    Frame.Parent = p10;
    local UIStroke = Instance.new("UIStroke");
    UIStroke.Color = Color3_fromRGB_ret4;
    UIStroke.Thickness = 2;
    UIStroke.Parent = Frame;
    local Frame2 = Instance.new("Frame");
    Frame2.Name = "Fill";
    Frame2.Size = UDim2.fromScale(1, 1);
    Frame2.BackgroundColor3 = p14;
    Frame2.BorderSizePixel = 0;
    Frame2.Parent = Frame;
    local TextLabel = Instance.new("TextLabel");
    TextLabel.Name = "Label";
    TextLabel.Size = UDim2.fromScale(1, 1);
    TextLabel.BackgroundTransparency = 1;
    TextLabel.Font = Arcade;
    TextLabel.TextSize = p15;
    TextLabel.TextColor3 = Color3_fromRGB_ret3;
    TextLabel.TextStrokeColor3 = Color3_fromRGB_ret4;
    TextLabel.TextStrokeTransparency = 0.5;
    TextLabel.Text = "";
    TextLabel.Parent = Frame;

    return Frame, Frame2, TextLabel;
end;

function v3.Fire(p16) -- Line: 125
    -- upvalues: u4 (ref), setInterfaceHidden (copy), LocalPlayer (copy), buildBar (copy), Color3_fromRGB_ret7 (copy), Color3_fromRGB_ret5 (copy), u2 (copy), Color3_fromRGB_ret (copy), Color3_fromRGB_ret4 (copy), Arcade (copy), Color3_fromRGB_ret6 (copy)
    if u4 then
        return;
    end;

    u4 = true;
    local v17;

    if p16 then
        v17 = p16.GateAt;
    else
        v17 = p16;
    end;

    local v18 = tonumber(v17) or 40;

    if p16 then
        p16 = p16.Mastery;
    end;

    local v19 = tonumber(p16) or 0;
    setInterfaceHidden(true);
    local PlayerGui = LocalPlayer:WaitForChild("PlayerGui");
    local LssjRagePanelGui = PlayerGui:FindFirstChild("LssjRagePanelGui");

    if LssjRagePanelGui then
        LssjRagePanelGui:Destroy();
    end;

    local ScreenGui = Instance.new("ScreenGui");
    ScreenGui.Name = "LssjRagePanelGui";
    ScreenGui.ResetOnSpawn = false;
    ScreenGui.DisplayOrder = 55;
    ScreenGui.IgnoreGuiInset = true;
    ScreenGui.Parent = PlayerGui;
    local Frame = Instance.new("Frame");
    Frame.Name = "Scaler";
    Frame.Size = UDim2.fromScale(1, 1);
    Frame.BackgroundTransparency = 1;
    Frame.Parent = ScreenGui;
    local UIScale = Instance.new("UIScale");
    UIScale.Parent = Frame;

    local function fitPanel() -- Line: 154
        -- upvalues: UIScale (copy)
        local workspace_CurrentCamera = workspace.CurrentCamera;

        if workspace_CurrentCamera then
            workspace_CurrentCamera = workspace_CurrentCamera.ViewportSize;
        end;

        if not workspace_CurrentCamera or workspace_CurrentCamera.X <= 0 then
            return;
        end;

        UIScale.Scale = math.clamp(workspace_CurrentCamera.X * 0.88 / 420, 0.6, 1);
    end;

    local workspace_CurrentCamera = workspace.CurrentCamera;
    local v20 = workspace_CurrentCamera and workspace_CurrentCamera.ViewportSize;

    if v20 and v20.X > 0 then
        UIScale.Scale = math.clamp(v20.X * 0.88 / 420, 0.6, 1);
    end;

    local u21;

    if workspace.CurrentCamera then
        u21 = workspace.CurrentCamera:GetPropertyChangedSignal("ViewportSize"):Connect(fitPanel);
    else
        u21 = nil;
    end;

    local _, u22, u23 = buildBar(Frame, "RageHealth", -28, 22, Color3_fromRGB_ret7, 15);
    local _, v24, v25 = buildBar(Frame, "RageMastery", -8, 16, Color3_fromRGB_ret5, 12);
    local Frame2 = Instance.new("Frame");
    Frame2.Name = "Abilities";
    Frame2.AnchorPoint = Vector2.new(0.5, 1);
    Frame2.Position = UDim2.new(0.5, 0, 1, -58);
    Frame2.Size = UDim2.fromOffset(420, 54);
    Frame2.BackgroundTransparency = 1;
    Frame2.Parent = Frame;
    local UIListLayout = Instance.new("UIListLayout");
    UIListLayout.FillDirection = Enum.FillDirection.Horizontal;
    UIListLayout.HorizontalAlignment = Enum.HorizontalAlignment.Center;
    UIListLayout.VerticalAlignment = Enum.VerticalAlignment.Center;
    UIListLayout.SortOrder = Enum.SortOrder.LayoutOrder;
    UIListLayout.Padding = UDim.new(0, 10);
    UIListLayout.Parent = Frame2;
    local u26 = {};

    for i, v in ipairs(u2) do
        local TextButton = Instance.new("TextButton");
        TextButton.Name = v.Name;
        TextButton.Size = UDim2.fromOffset(170, 46);
        TextButton.BackgroundColor3 = Color3_fromRGB_ret;
        TextButton.BorderSizePixel = 0;
        TextButton.Text = "";
        TextButton.AutoButtonColor = false;
        TextButton.Selectable = false;
        TextButton.BackgroundTransparency = 0.35;
        TextButton.LayoutOrder = i;
        TextButton.Parent = Frame2;
        local UIStroke = Instance.new("UIStroke");
        UIStroke.Color = Color3_fromRGB_ret4;
        UIStroke.Thickness = 2;
        UIStroke.Transparency = 0.35;
        UIStroke.Parent = TextButton;
        local Frame3 = Instance.new("Frame");
        Frame3.Name = "Cooldown";
        Frame3.Size = UDim2.fromScale(0, 1);
        Frame3.BackgroundColor3 = Color3_fromRGB_ret4;
        Frame3.BackgroundTransparency = 0.55;
        Frame3.BorderSizePixel = 0;
        Frame3.ZIndex = 0;
        Frame3.Parent = TextButton;
        local TextLabel = Instance.new("TextLabel");
        TextLabel.Position = UDim2.fromOffset(10, 4);
        TextLabel.Size = UDim2.new(1, -20, 0, 20);
        TextLabel.BackgroundTransparency = 1;
        TextLabel.Font = Arcade;
        TextLabel.TextSize = 16;
        TextLabel.TextColor3 = Color3_fromRGB_ret6;
        TextLabel.TextXAlignment = Enum.TextXAlignment.Left;
        TextLabel.TextStrokeColor3 = Color3_fromRGB_ret4;
        TextLabel.TextStrokeTransparency = 0.5;
        TextLabel.ZIndex = 2;
        TextLabel.Text = string.upper(v.Name);
        TextLabel.Parent = TextButton;
        local TextLabel2 = Instance.new("TextLabel");
        TextLabel2.AnchorPoint = Vector2.new(1, 1);
        TextLabel2.Position = UDim2.new(1, -8, 1, -5);
        TextLabel2.Size = UDim2.fromOffset(90, 18);
        TextLabel2.BackgroundTransparency = 1;
        TextLabel2.Font = Arcade;
        TextLabel2.TextSize = 14;
        TextLabel2.TextColor3 = Color3_fromRGB_ret6;
        TextLabel2.TextXAlignment = Enum.TextXAlignment.Right;
        TextLabel2.TextStrokeColor3 = Color3_fromRGB_ret4;
        TextLabel2.TextStrokeTransparency = 0.5;
        TextLabel2.ZIndex = 2;
        TextLabel2.Text = "READY";
        TextLabel2.Parent = TextButton;

        local function refreshCooldown() -- Line: 251
            -- upvalues: LocalPlayer (ref), v (copy), TextLabel2 (copy), Frame3 (copy)
            local Character = LocalPlayer.Character;

            if Character then
                Character = Character:GetAttribute(v.Attr);
            end;

            local v27 = Character and Character - workspace:GetServerTimeNow() or 0;

            if v27 <= 0 then
                TextLabel2.Text = "READY";
                Frame3.Size = UDim2.fromScale(0, 1);

                return;
            end;

            local math_ceil_ret = math.ceil(v27);
            TextLabel2.Text = tostring(math_ceil_ret);
            Frame3.Size = UDim2.fromScale(math.clamp(v27 / v.Total, 0, 1), 1);
        end;

        refreshCooldown();
        table.insert(u26, refreshCooldown);
    end;

    task.spawn(function() -- Line: 267
        -- upvalues: u4 (ref), u26 (copy)
        while u4 do
            for _, v in ipairs(u26) do
                v();
            end;

            task.wait(0.25);
        end;
    end);
    (function(u28) -- Line: 277, Name: bindHealth
        -- upvalues: u22 (copy), u23 (copy)
        if u28 then
            u28 = u28:FindFirstChildOfClass("Humanoid");
        end;

        if not u28 then
            return;
        end;

        local function refresh() -- Line: 280
            -- upvalues: u28 (copy), u22 (ref), u23 (ref)
            local math_max_ret = math.max(u28.MaxHealth, 1);
            u22.Size = UDim2.fromScale(math.clamp(u28.Health / math_max_ret, 0, 1), 1);
            u23.Text = string.format("%d / %d", math.floor(u28.Health + 0.5), (math.floor(math_max_ret + 0.5)));
        end;

        refresh();
        u28.HealthChanged:Connect(refresh);
        u28:GetPropertyChangedSignal("MaxHealth"):Connect(refresh);
    end)(LocalPlayer.Character);
    v24.Size = UDim2.fromScale(math.clamp(v19 / v18, 0, 1), 1);
    v25.Text = string.format("MASTERY   %.1f / %d   2 STARS = CONTROL", v19, v18);

    local function teardown() -- Line: 297
        -- upvalues: u4 (ref), u21 (ref), ScreenGui (copy), setInterfaceHidden (ref)
        if not u4 then
            return;
        end;

        u4 = false;

        if u21 then
            u21:Disconnect();
            u21 = nil;
        end;

        ScreenGui:Destroy();
        setInterfaceHidden(false);
    end;

    task.spawn(function() -- Line: 307
        -- upvalues: u4 (ref), LocalPlayer (ref), u21 (ref), ScreenGui (copy), setInterfaceHidden (ref)
        local v29 = os.clock() + 5;
        local v30 = false;

        while u4 do
            local Character = LocalPlayer.Character;

            if Character and Character.Parent then
                if Character:GetAttribute("State_BerserkApe") == true then
                    v30 = true;
                elseif v30 or v29 < os.clock() then
                    break;
                end;
            elseif v30 or v29 < os.clock() then
                break;
            end;

            task.wait(0.25);
        end;

        if not u4 then
            return;
        end;

        u4 = false;

        if u21 then
            u21:Disconnect();
            u21 = nil;
        end;

        ScreenGui:Destroy();
        setInterfaceHidden(false);
    end);
end;

return v3;