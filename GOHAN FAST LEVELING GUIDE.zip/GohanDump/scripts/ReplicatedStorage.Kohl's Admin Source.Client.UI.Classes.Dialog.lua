-- Decompiled with Potassium's decompiler.

local Parent = require(script.Parent.Parent);
local BaseClass = require(script.Parent:WaitForChild("BaseClass"));
local u1 = {
    Text = "",
    Title = "",
    Activated = false,
    Draggable = false,
    ExitButton = false,
    Selectable = false,
    Visible = true,
    Width = 256,
    AnchorPoint = Vector2.new(0.5, 0.5),
    Position = UDim2.new(0.5, 0, 0.5, 0),
    TextSize = Parent.Theme.FontSize,
    TextColor3 = Parent.Theme.PrimaryText,
    TextStrokeColor3 = Parent.Theme.Primary,
    TextStrokeTransparency = Parent.Theme.TextStrokeTransparency,
    TextXAlignment = Enum.TextXAlignment.Left,
    TitleSize = Parent.Theme.FontSizeLargest,
    TitleTextXAlignment = Enum.TextXAlignment.Left,
    ActionText = Parent.Nil,
    ActionTextSize = Parent.Theme.FontSize,
    Action = Parent.Nil,
    Duration = Parent.Nil,
    LeftAction = Parent.Nil,
    RightAction = Parent.Nil,
    Close = Parent.Function
};
local u2 = {};
u2.__index = u2;
setmetatable(u2, BaseClass);

function u2.new(p3) -- Line: 40
    -- upvalues: u1 (copy), Parent (copy), u2 (copy)
    local table_clone_ret = table.clone(u1);
    Parent.makeStatefulDefaults(table_clone_ret, p3);
    local u4 = nil;
    local u5 = nil;
    local u6 = nil;
    local u7 = Parent.state(false);
    table_clone_ret._dragging = u7;

    local function dragUpdate(p8) -- Line: 48
        -- upvalues: u4 (ref), u5 (ref), table_clone_ret (copy), u6 (ref)
        if not u4 then
            return;
        end;

        local v9 = p8.Position - u5;
        local AbsoluteSize = table_clone_ret._instance.AbsoluteSize;
        local v10 = AbsoluteSize * table_clone_ret._instance.AnchorPoint;
        local v11 = table_clone_ret._instance.Parent.AbsolutePosition + v10;
        local v12 = table_clone_ret._instance.Parent.AbsoluteSize - (AbsoluteSize - v10);
        local Position = table_clone_ret.Position;
        local UDim2_fromOffset = UDim2.fromOffset;
        local math_round_ret = math.round(u6.X + v9.X);
        local X = v11.X;
        local math_max_ret = math.max(v10.X, v12.X);
        local math_clamp_ret = math.clamp(math_round_ret, X, math_max_ret);
        local math_round_ret2 = math.round(u6.Y + v9.Y);
        local math_max_ret2 = math.max(v10.Y, v11.Y);
        local math_max_ret3 = math.max(v10.Y, v12.Y);
        Position(UDim2_fromOffset(math_clamp_ret, (math.clamp(math_round_ret2, math_max_ret2, math_max_ret3))), true);
    end;

    local function dragInputBegan(u13, p14) -- Line: 68
        -- upvalues: table_clone_ret (copy), u6 (ref), u4 (ref), u5 (ref), u7 (copy)
        if p14 or not table_clone_ret.Draggable._value then
            return;
        end;

        if u13.UserInputType == Enum.UserInputType.MouseButton1 or u13.UserInputType == Enum.UserInputType.Touch then
            u6 = table_clone_ret._instance.AbsolutePosition + table_clone_ret._instance.AbsoluteSize * table_clone_ret._instance.AnchorPoint - table_clone_ret._instance.Parent.AbsolutePosition;
            u4 = u13;
            u5 = u13.Position;
            u7(true);
            local u15 = nil;
            u15 = u13:GetPropertyChangedSignal("UserInputState"):Connect(function() -- Line: 81
                -- upvalues: u13 (copy), u15 (ref), u4 (ref), u7 (ref)
                if u13.UserInputState == Enum.UserInputState.End then
                    u15:Disconnect();

                    if u4 == u13 then
                        u4 = nil;
                        u7(false);
                    end;
                end;
            end);
        end;
    end;

    local u16 = nil;

    local function activate(p17) -- Line: 94
        -- upvalues: Parent (ref), table_clone_ret (copy), u16 (ref)
        if Parent.raw(table_clone_ret.Activated) then
            return;
        end;

        table_clone_ret.Activated(true);
        table_clone_ret.Action(p17, true);

        if u16 then
            u16:Disconnect();
        end;

        if table_clone_ret.Close and type(table_clone_ret.Close._value) == "function" then
            table_clone_ret.Close._value(table_clone_ret);

            return;
        end;

        table_clone_ret:Destroy();
    end;

    local u18 = Parent.new("Frame")({
        ZIndex = -1,
        Name = "Progress",
        BackgroundTransparency = 1,
        AnchorPoint = Vector2.new(0, 1),
        Position = UDim2.fromScale(0, 1),
        Size = UDim2.new(1, 0, 0, 4),
        ClipsDescendants = true,
        Visible = table_clone_ret.Duration and table_clone_ret.Duration._value > 0 and true or false,
        Parent.new("Frame")({
            Name = "Bar",
            AnchorPoint = Vector2.new(0, 1),
            BackgroundColor3 = Parent.Theme.Secondary,
            Position = UDim2.fromScale(0, 1),
            Size = UDim2.new(),
            Parent.new("UICorner")({
                CornerRadius = Parent.Theme.CornerRadius
            })
        })
    });
    local u19 = Parent.state(false);
    table_clone_ret._hovering = u19;

    if table_clone_ret.Duration and table_clone_ret.Duration._value > 0 then
        local _value = table_clone_ret.Duration._value;
        local u20 = 0;
        u16 = game:GetService("RunService").PreRender:Connect(function(p21: number) -- Line: 139
            -- upvalues: u19 (copy), u20 (ref), _value (copy), u18 (copy), u16 (ref), table_clone_ret (copy)
            if u19._value then
                return;
            end;

            u20 = u20 + p21;
            local v22 = u20 / _value;
            u18.Size = UDim2.new(math.clamp(1 - v22, 0, 1), 0, 0, 4);

            if v22 >= 1 then
                u16:Disconnect();

                if table_clone_ret.Close and type(table_clone_ret.Close._value) == "function" then
                    table_clone_ret.Close._value(table_clone_ret);

                    return;
                end;

                table_clone_ret:Destroy();
            end;
        end);
    end;

    local v23 = Parent.compute(function() -- Line: 158
        -- upvalues: Parent (ref)
        return UDim2.new(0, Parent.Theme.FontSizeLargest(), 0, Parent.Theme.FontSizeLargest());
    end);
    table_clone_ret._buttonSize = v23;
    local v24 = Parent.new("Button")({
        LayoutOrder = 9,
        BackgroundTransparency = 1,
        HoverTransparency = 0,
        Text = "",
        AnchorPoint = Vector2.new(1, 0),
        BackgroundColor3 = Color3.fromRGB(200, 0, 0),
        Position = UDim2.new(1, 0, 0, 0),
        Size = v23,
        Icon = Parent.Theme.Image.Close,
        IconProperties = {
            ImageColor3 = Parent.Theme.PrimaryText,
            Size = UDim2.fromScale(0.5, 0.5)
        },

        Activated = function() -- Line: 177, Name: Activated
            -- upvalues: table_clone_ret (copy)
            if table_clone_ret.Close and type(table_clone_ret.Close._value) == "function" then
                table_clone_ret.Close._value(table_clone_ret);

                return;
            end;

            table_clone_ret:Destroy();
        end,

        Visible = function() -- Line: 184, Name: Visible
            -- upvalues: table_clone_ret (copy)
            return table_clone_ret.ExitButton() and true or false;
        end
    });
    v24._instance:FindFirstChildOfClass("UIStroke"):Destroy();
    table_clone_ret._exitButton = v24;
    local Frame = Parent.new("Frame");
    local v25 = {
        Name = "UIContent",
        AutomaticSize = Enum.AutomaticSize.Y,
        BackgroundTransparency = 1,
        Size = UDim2.fromScale(1, 0)
    };
    local v26 = Parent.new("UIListLayout")({
        SortOrder = Enum.SortOrder.LayoutOrder,
        Padding = Parent.Theme.Padding,
        HorizontalFlex = Enum.UIFlexAlignment.Fill
    });
    local TextButton = Parent.new("TextButton");
    local v28 = {
        Name = "Title",
        AutoLocalize = false,
        AutomaticSize = Enum.AutomaticSize.XY,
        BackgroundTransparency = 1,
        Text = "",

        Visible = function() -- Line: 209, Name: Visible
            -- upvalues: table_clone_ret (copy)
            local v27 = table_clone_ret.Title();

            if v27 then
                v27 = v27 ~= "";
            end;

            return v27;
        end
    };
    local v29 = Parent.new("UIListLayout")({
        SortOrder = Enum.SortOrder.LayoutOrder,
        Padding = Parent.Theme.Padding,
        FillDirection = Enum.FillDirection.Horizontal
    });
    local v30 = Parent.new("TextLabel")({
        AutoLocalize = false,
        BackgroundTransparency = 1,
        TextColor3 = Parent.Theme.PrimaryText,
        TextStrokeColor3 = Parent.Theme.Primary,
        TextStrokeTransparency = Parent.Theme.TextStrokeTransparency,
        Text = table_clone_ret.Title,
        TextSize = table_clone_ret.TitleSize,
        TextTruncate = Enum.TextTruncate.SplitWord,
        TextXAlignment = table_clone_ret.TitleTextXAlignment,
        FontFace = Parent.Theme.FontHeavy,
        RichText = true,
        AutomaticSize = Enum.AutomaticSize.XY,
        Parent.new("UIFlexItem")({
            FlexMode = Enum.UIFlexMode.Fill
        })
    });
    local v31;

    if Parent.raw(table_clone_ret.Title) then
        v31 = v24;
    else
        v31 = nil;
    end;

    v28[1], v28[2], v28[3] = v29, v30, v31;
    v28.InputBegan = dragInputBegan;
    local v32 = TextButton(v28);
    local TextBox = Parent.new("TextBox");
    local v34 = {
        AutoLocalize = false,
        Name = "Text",
        BackgroundTransparency = 1,
        ClearTextOnFocus = false,
        Interactable = table_clone_ret.Selectable,
        TextEditable = false,
        TextColor3 = table_clone_ret.TextColor3,
        Text = table_clone_ret.Text,
        TextSize = table_clone_ret.TextSize,
        TextWrapped = true,
        TextXAlignment = table_clone_ret.TextXAlignment,
        FontFace = Parent.Theme.Font,
        RichText = true,

        Visible = function() -- Line: 258, Name: Visible
            -- upvalues: table_clone_ret (copy)
            local v33 = table_clone_ret.Text();

            if v33 then
                v33 = v33 ~= "";
            end;

            return v33;
        end,

        AutomaticSize = Enum.AutomaticSize.XY
    };

    if Parent.raw(table_clone_ret.Title) then
        v24 = nil;
    end;

    v34[1] = v24;
    v25[1], v25[2], v25[3] = v26, v32, TextBox(v34);
    table_clone_ret._content = Frame(v25);
    local ImageButton = Parent.new("ImageButton");
    local v35 = {
        Name = "Dialog",
        Active = false,
        AutoButtonColor = false,
        AutomaticSize = Enum.AutomaticSize.Y,

        BackgroundColor3 = function() -- Line: 274, Name: BackgroundColor3
            -- upvalues: Parent (ref)
            if Parent.Theme.BackgroundGradientEnabled() then
                return Color3.new(1, 1, 1);
            end;

            return Parent.Theme.Primary();
        end,

        BackgroundTransparency = Parent.Theme.Transparency,
        Image = Parent.Theme.BackgroundImage,
        ImageTransparency = Parent.Theme.BackgroundImageTransparency,
        ScaleType = Parent.Theme.BackgroundImageScaleType,
        ClipsDescendants = true,
        AnchorPoint = table_clone_ret.AnchorPoint,
        Position = table_clone_ret.Position,

        Size = function() -- Line: 284, Name: Size
            -- upvalues: table_clone_ret (copy)
            return UDim2.fromOffset(table_clone_ret.Width(), 0);
        end,

        Visible = table_clone_ret.Visible
    };
    local v36 = Parent.new("UICorner")({
        CornerRadius = Parent.Theme.CornerRadius
    });
    local v37 = Parent.new("Gradient")({});
    local v38 = Parent.new("Stroke")({});
    local v39 = Parent.new("UIListLayout")({
        SortOrder = Enum.SortOrder.LayoutOrder
    });
    local Frame2 = Parent.new("Frame");
    local v40 = {
        AutomaticSize = Enum.AutomaticSize.Y,
        BackgroundTransparency = 1,
        Size = UDim2.new(1, 0, 0, 0)
    };
    local v41 = Parent.new("UIPadding")({
        PaddingLeft = Parent.Theme.Padding,
        PaddingRight = Parent.Theme.Padding,
        PaddingTop = Parent.Theme.Padding,
        PaddingBottom = Parent.Theme.Padding
    });
    local v42 = Parent.new("UIListLayout")({
        SortOrder = Enum.SortOrder.LayoutOrder,
        Padding = Parent.Theme.Padding
    });
    local _content = table_clone_ret._content;
    local v43;

    if table_clone_ret.LeftAction or table_clone_ret.RightAction then
        v43 = Parent.new("Frame")({
            Name = "Actions",
            AutomaticSize = Enum.AutomaticSize.Y,
            BackgroundTransparency = 1,
            Size = UDim2.new(1, 0, 0, 0),
            Parent.new("UIListLayout")({
                SortOrder = Enum.SortOrder.LayoutOrder,
                FillDirection = Enum.FillDirection.Horizontal,
                HorizontalAlignment = Enum.HorizontalAlignment.Right,
                VerticalAlignment = Enum.VerticalAlignment.Center,
                VerticalFlex = Enum.UIFlexAlignment.Fill,
                Padding = Parent.Theme.Padding
            }),
            Parent.new("TextLabel")({
                AutoLocalize = false,
                Name = "Text",
                BackgroundTransparency = 1,
                TextWrapped = true,
                TextXAlignment = "Left",
                RichText = true,
                TextColor3 = Parent.Theme.PrimaryText,
                TextStrokeColor3 = Parent.Theme.Primary,
                TextStrokeTransparency = Parent.Theme.TextStrokeTransparency,
                Text = table_clone_ret.ActionText,
                TextSize = table_clone_ret.ActionTextSize,
                TextTruncate = Enum.TextTruncate.SplitWord,
                FontFace = Parent.Theme.FontBold,

                Visible = function() -- Line: 346, Name: Visible
                    -- upvalues: table_clone_ret (copy)
                    local v44 = table_clone_ret.ActionText();

                    if v44 then
                        v44 = v44 ~= "";
                    end;

                    return v44;
                end,

                AutomaticSize = Enum.AutomaticSize.XY
            }),
            Parent.new("Spacer")({}),
            Parent.new("Button")({
                Name = "LeftAction",
                BackgroundTransparency = 1,
                Text = "",
                AutomaticSize = Enum.AutomaticSize.None,
                Size = v23,
                Icon = Parent.Theme.Image.Close_Bold,
                IconProperties = {
                    ImageColor3 = Parent.Theme.Invalid,
                    Size = UDim2.fromScale(0.5, 0.5)
                },

                Activated = function() -- Line: 365, Name: Activated
                    -- upvalues: activate (copy)
                    activate(false);
                end
            }),
            Parent.new("Button")({
                Name = "RightAction",
                BackgroundTransparency = 1,
                Text = "",
                AutomaticSize = Enum.AutomaticSize.None,
                Size = v23,
                Icon = Parent.Theme.Image.Check_Bold,
                IconProperties = {
                    ImageColor3 = Parent.Theme.Valid,
                    Size = UDim2.fromScale(0.625, 0.625)
                },

                Activated = function() -- Line: 380, Name: Activated
                    -- upvalues: activate (copy)
                    activate(true);
                end
            })
        });
    else
        v43 = nil;
    end;

    v40[1], v40[2], v40[3], v40[4] = v41, v42, _content, v43;
    v35[1], v35[2], v35[3], v35[4], v35[5], v35[6] = v36, v37, v38, v39, Frame2(v40), u18;

    function v35.InputChanged(p45, p46) -- Line: 389
        -- upvalues: u19 (copy)
        if p46 then
            return;
        end;

        if p45.UserInputType == Enum.UserInputType.MouseMovement or p45.UserInputType == Enum.UserInputType.Touch then
            u19(true);
        end;
    end;

    function v35.inputEnded(p47) -- Line: 400
        -- upvalues: u19 (copy)
        if p47.UserInputType == Enum.UserInputType.MouseMovement or p47.UserInputType == Enum.UserInputType.Touch then
            u19(false);
        end;
    end;

    v35[Parent.Clean] = { Parent.UserInputService.InputChanged:Connect(function(p48) -- Line: 410
            -- upvalues: table_clone_ret (copy), u7 (copy), dragUpdate (copy)
            if not (table_clone_ret.Draggable._value and table_clone_ret._instance.Visible) then
                return;
            end;

            if (p48.UserInputType == Enum.UserInputType.MouseMovement or p48.UserInputType == Enum.UserInputType.Touch) and u7._value then
                dragUpdate(p48);
            end;
        end), u19 };
    table_clone_ret._instance = ImageButton(v35);
    local u49 = Parent.state(table_clone_ret._instance, "AbsoluteSize");
    table_clone_ret.sizeState = u49;
    Parent.edit(u18.Bar, {
        Size = function() -- Line: 431, Name: Size
            -- upvalues: u49 (copy)
            local v50 = u49();

            return UDim2.fromOffset(v50.X, v50.Y);
        end
    });

    return setmetatable(table_clone_ret, u2);
end;

return u2;