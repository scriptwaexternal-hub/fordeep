-- Decompiled with Potassium's decompiler.

local Players = game:GetService("Players");
local ReplicatedStorage = game:GetService("ReplicatedStorage");
local LocalPlayer = Players.LocalPlayer;
local ContractRemote = ReplicatedStorage:WaitForChild("Remotes"):WaitForChild("ContractRemote");
local ServerRemote = ReplicatedStorage:WaitForChild("Remotes"):WaitForChild("ServerRemote");
local Color3_fromRGB_ret = Color3.fromRGB(28, 28, 30);
local Color3_fromRGB_ret2 = Color3.fromRGB(216, 213, 205);
local Color3_fromRGB_ret3 = Color3.fromRGB(201, 198, 191);
local Color3_fromRGB_ret4 = Color3.fromRGB(88, 214, 106);
local Color3_fromRGB_ret5 = Color3.fromRGB(255, 255, 255);
local Color3_fromRGB_ret6 = Color3.fromRGB(0, 0, 0);
local Arcade = Enum.Font.Arcade;
local Bangers = Enum.Font.Bangers;
local u1 = {
    EASY = Color3.fromRGB(120, 200, 120),
    MEDIUM = Color3.fromRGB(230, 190, 90),
    HARD = Color3.fromRGB(225, 100, 90)
};

local function stroke(p2, p3, p4) -- Line: 42
    -- upvalues: Color3_fromRGB_ret6 (copy)
    local UIStroke = Instance.new("UIStroke");
    UIStroke.Color = p4 or Color3_fromRGB_ret6;
    UIStroke.Thickness = p3 or 2;
    UIStroke.Parent = p2;

    return UIStroke;
end;

local function corner(p5, p6) -- Line: 50
    local UICorner = Instance.new("UICorner");
    UICorner.CornerRadius = UDim.new(0, p6 or 6);
    UICorner.Parent = p5;

    return UICorner;
end;

local StatFrame = LocalPlayer:WaitForChild("PlayerGui"):WaitForChild("HUD"):WaitForChild("Inventory"):WaitForChild("StatFrame");
local Tabs = StatFrame:WaitForChild("Tabs");
local LoreTab = Tabs:WaitForChild("LoreTab");
local Lore = StatFrame:WaitForChild("Lore");

if Tabs:FindFirstChild("ContractTab") then
    return;
end;

local u7 = LoreTab:Clone();
u7.Name = "ContractTab";
u7.LayoutOrder = 1;
u7.Image = "rbxassetid://126454867112626";
local v8 = u7:FindFirstChildWhichIsA("TextLabel");

if v8 then
    v8.Text = "Missions";
end;

u7.Parent = Tabs;
local v9 = {};

for _, child in ipairs(Tabs:GetChildren()) do
    if child:IsA("ImageButton") then
        v9[#v9 + 1] = child;
    end;
end;

for _, v in ipairs(v9) do
    v.Size = UDim2.new(1, 0, 0.1, 0);
end;

local Frame = Instance.new("Frame");
Frame.Name = "Contracts";
Frame.AnchorPoint = Lore.AnchorPoint;
Frame.Position = Lore.Position;
Frame.Size = Lore.Size;
Frame.BackgroundColor3 = Lore.BackgroundColor3;
Frame.BackgroundTransparency = Lore.BackgroundTransparency;
Frame.BorderSizePixel = 0;
Frame.Visible = false;
Frame.ZIndex = 12;
Frame.DescendantAdded:Connect(function(p10) -- Line: 119
    if p10:IsA("GuiObject") then
        p10.ZIndex = 13;
    end;
end);
Frame.Parent = StatFrame;
local v11 = Lore:FindFirstChildOfClass("UICorner");

if v11 then
    local Offset = v11.CornerRadius.Offset;
    local UICorner = Instance.new("UICorner");
    UICorner.CornerRadius = UDim.new(0, Offset or 6);
    UICorner.Parent = Frame;
end;

local TextLabel = Instance.new("TextLabel");
TextLabel.BackgroundTransparency = 1;
TextLabel.Position = UDim2.new(0, 12, 0, 6);
TextLabel.Size = UDim2.new(1, -164, 0, 24);
TextLabel.Font = Bangers;
TextLabel.TextSize = 20;
TextLabel.TextColor3 = Color3_fromRGB_ret2;
TextLabel.TextXAlignment = Enum.TextXAlignment.Left;
TextLabel.TextTruncate = Enum.TextTruncate.AtEnd;
TextLabel.Text = "MISSIONS & CONTRACTS";
TextLabel.Parent = Frame;
local UIStroke = Instance.new("UIStroke");
UIStroke.Color = Color3_fromRGB_ret6;
UIStroke.Thickness = 2;
UIStroke.Parent = TextLabel;
local TextLabel2 = Instance.new("TextLabel");
TextLabel2.BackgroundTransparency = 1;
TextLabel2.AnchorPoint = Vector2.new(1, 0);
TextLabel2.Position = UDim2.new(1, -12, 0, 10);
TextLabel2.Size = UDim2.new(0, 130, 0, 16);
TextLabel2.Font = Arcade;
TextLabel2.TextSize = 11;
TextLabel2.TextXAlignment = Enum.TextXAlignment.Right;
TextLabel2.TextColor3 = Color3_fromRGB_ret3;
TextLabel2.Text = "";
TextLabel2.Parent = Frame;
local u12 = false;

local function applyQuota(p13) -- Line: 167
    -- upvalues: u12 (ref), TextLabel2 (copy), Color3_fromRGB_ret3 (copy)
    if type(p13) ~= "table" then
        return;
    end;

    u12 = (p13.Left or 0) <= 0;

    if not u12 then
        TextLabel2.TextColor3 = Color3_fromRGB_ret3;
        TextLabel2.Text = ("Contracts left: %d/%d"):format(p13.Left or 0, p13.Max or 3);

        return;
    end;

    local math_ceil_ret = math.ceil((p13.ResetIn or 0) / 60);
    local math_max_ret = math.max(math_ceil_ret, 1);
    TextLabel2.TextColor3 = Color3.fromRGB(225, 100, 90);
    TextLabel2.Text = ("Restocking in ~%dm"):format(math_max_ret);
end;

local ScrollingFrame = Instance.new("ScrollingFrame");
ScrollingFrame.BackgroundTransparency = 1;
ScrollingFrame.BorderSizePixel = 0;
ScrollingFrame.Position = UDim2.new(0, 12, 0, 70);
ScrollingFrame.Size = UDim2.new(1, -24, 1, -80);
ScrollingFrame.ScrollBarThickness = 4;
ScrollingFrame.AutomaticCanvasSize = Enum.AutomaticSize.Y;
ScrollingFrame.CanvasSize = UDim2.new(0, 0, 0, 0);
ScrollingFrame.ScrollingDirection = Enum.ScrollingDirection.Y;
ScrollingFrame.Parent = Frame;
local UIListLayout = Instance.new("UIListLayout");
UIListLayout.FillDirection = Enum.FillDirection.Vertical;
UIListLayout.Padding = UDim.new(0, 8);
UIListLayout.Parent = ScrollingFrame;

local function clearList() -- Line: 206
    -- upvalues: ScrollingFrame (copy)
    for _, child in ipairs(ScrollingFrame:GetChildren()) do
        if child:IsA("Frame") then
            child:Destroy();
        end;
    end;
end;

local u14 = nil;

local function makeOfferCard(u15) -- Line: 214
    -- upvalues: Color3_fromRGB_ret (copy), ScrollingFrame (copy), Color3_fromRGB_ret6 (copy), Arcade (copy), u1 (copy), Color3_fromRGB_ret2 (copy), Bangers (copy), Color3_fromRGB_ret3 (copy), Color3_fromRGB_ret4 (copy), u12 (ref), Color3_fromRGB_ret5 (copy), ContractRemote (copy), applyQuota (copy), u14 (ref)
    local Frame2 = Instance.new("Frame");
    Frame2.Size = UDim2.new(1, -6, 0, 122);
    Frame2.BackgroundColor3 = Color3_fromRGB_ret;
    Frame2.Parent = ScrollingFrame;
    local UICorner = Instance.new("UICorner");
    UICorner.CornerRadius = UDim.new(0, 6);
    UICorner.Parent = Frame2;
    local UIStroke2 = Instance.new("UIStroke");
    UIStroke2.Color = Color3_fromRGB_ret6;
    UIStroke2.Thickness = 2;
    UIStroke2.Parent = Frame2;
    local TextLabel3 = Instance.new("TextLabel");
    TextLabel3.BackgroundTransparency = 1;
    TextLabel3.Position = UDim2.new(0, 10, 0, 6);
    TextLabel3.Size = UDim2.new(0, 110, 0, 14);
    TextLabel3.Font = Arcade;
    TextLabel3.TextSize = 12;
    TextLabel3.TextXAlignment = Enum.TextXAlignment.Left;
    TextLabel3.TextColor3 = u1[u15.Tier] or Color3_fromRGB_ret2;
    TextLabel3.Text = u15.Tier or "?";
    TextLabel3.Parent = Frame2;
    local UIStroke3 = Instance.new("UIStroke");
    UIStroke3.Color = Color3_fromRGB_ret6;
    UIStroke3.Thickness = 1;
    UIStroke3.Parent = TextLabel3;
    local TextLabel4 = Instance.new("TextLabel");
    TextLabel4.BackgroundTransparency = 1;
    TextLabel4.Position = UDim2.new(0, 10, 0, 20);
    TextLabel4.Size = UDim2.new(1, -110, 0, 22);
    TextLabel4.Font = Bangers;
    TextLabel4.TextSize = 20;
    TextLabel4.TextXAlignment = Enum.TextXAlignment.Left;
    TextLabel4.TextColor3 = Color3_fromRGB_ret2;
    TextLabel4.TextTruncate = Enum.TextTruncate.AtEnd;
    TextLabel4.Text = u15.Title or "Contract";
    TextLabel4.Parent = Frame2;
    local v16 = {};

    for _, v in ipairs(u15.Objectives or {}) do
        table.insert(v16, v.Text .. " x" .. v.Count);
    end;

    local TextLabel5 = Instance.new("TextLabel");
    TextLabel5.BackgroundTransparency = 1;
    TextLabel5.Position = UDim2.new(0, 10, 0, 44);
    TextLabel5.Size = UDim2.new(1, -110, 0, 34);
    TextLabel5.Font = Arcade;
    TextLabel5.TextSize = 14;
    TextLabel5.TextXAlignment = Enum.TextXAlignment.Left;
    TextLabel5.TextYAlignment = Enum.TextYAlignment.Top;
    TextLabel5.TextColor3 = Color3_fromRGB_ret3;
    TextLabel5.TextWrapped = true;
    TextLabel5.TextTruncate = Enum.TextTruncate.AtEnd;
    TextLabel5.Text = table.concat(v16, "\n");
    TextLabel5.Parent = Frame2;
    local v17 = u15.Rewards or {};
    local v18 = {};

    if v17.Exp then
        local v19 = math.floor(v17.Exp * 100 + 0.5) .. "% of a Combat Level";
        table.insert(v18, v19);
    end;

    if v17.Zeni then
        table.insert(v18, v17.Zeni .. " Zeni");
    end;

    if v17.Item then
        table.insert(v18, v17.Item);
    end;

    local TextLabel6 = Instance.new("TextLabel");
    TextLabel6.BackgroundTransparency = 1;
    TextLabel6.Position = UDim2.new(0, 10, 0, 82);
    TextLabel6.Size = UDim2.new(1, -110, 0, 34);
    TextLabel6.Font = Arcade;
    TextLabel6.TextSize = 14;
    TextLabel6.TextXAlignment = Enum.TextXAlignment.Left;
    TextLabel6.TextYAlignment = Enum.TextYAlignment.Top;
    TextLabel6.TextColor3 = Color3_fromRGB_ret4;
    TextLabel6.TextWrapped = true;
    TextLabel6.TextTruncate = Enum.TextTruncate.AtEnd;
    TextLabel6.Text = "Reward: " .. table.concat(v18, ", ");
    TextLabel6.Parent = Frame2;
    local TextButton = Instance.new("TextButton");
    TextButton.AnchorPoint = Vector2.new(1, 0.5);
    TextButton.Position = UDim2.new(1, -10, 0.5, 0);
    TextButton.Size = UDim2.fromOffset(88, 34);
    TextButton.BackgroundColor3 = Color3.fromRGB(18, 18, 20);
    TextButton.Font = Bangers;
    TextButton.TextSize = 18;
    TextButton.TextColor3 = u12 and Color3_fromRGB_ret3 or Color3_fromRGB_ret5;
    TextButton.Text = u12 and "WAIT" or "ACCEPT";
    TextButton.Active = not u12;
    TextButton.Parent = Frame2;
    local UICorner2 = Instance.new("UICorner");
    UICorner2.CornerRadius = UDim.new(0, 6);
    UICorner2.Parent = TextButton;
    local UIStroke4 = Instance.new("UIStroke");
    UIStroke4.Color = Color3_fromRGB_ret6 or Color3_fromRGB_ret6;
    UIStroke4.Thickness = 2;
    UIStroke4.Parent = TextButton;
    TextButton.Activated:Connect(function() -- Line: 299
        -- upvalues: u12 (ref), TextButton (copy), ContractRemote (ref), u15 (copy), applyQuota (ref), u14 (ref)
        if u12 then
            return;
        end;

        TextButton.Active = false;
        TextButton.Text = "...";
        local success, result = pcall(ContractRemote.InvokeServer, ContractRemote, {
            Action = "Accept",
            Index = u15.Index
        });

        if success and (type(result) == "table" and result.ok) then
            if result.quota then
                applyQuota(result.quota);
            end;

            u14();

            return;
        end;

        local v20;

        if type(result) == "table" then
            v20 = result.reason;
        else
            v20 = false;
        end;

        if v20 == "Restocking" then
            applyQuota({
                Left = 0,
                ResetIn = type(result) == "table" and (result.ResetIn or 0) or 0
            });
            u14();

            return;
        end;

        TextButton.Text = v20 == "QuestCap" and "QUESTS FULL" or "ACCEPT";
        TextButton.Active = true;
    end);
end;

u14 = function() -- Line: 322
    -- upvalues: clearList (copy), ContractRemote (copy), applyQuota (copy), makeOfferCard (copy)
    clearList();
    local success, result = pcall(ContractRemote.InvokeServer, ContractRemote, {
        Action = "GetOffers"
    });

    if not (success and (type(result) == "table" and type(result.offers) == "table")) then
        return;
    end;

    if result.quota then
        applyQuota(result.quota);
    end;

    for _, v in ipairs(result.offers) do
        makeOfferCard(v);
    end;
end;

local u21 = "CONTRACTS";
local Frame2 = Instance.new("Frame");
Frame2.Name = "MissionSection";
Frame2.BackgroundTransparency = 1;
Frame2.Position = UDim2.new(0, 12, 0, 70);
Frame2.Size = UDim2.new(1, -24, 1, -80);
Frame2.Visible = false;
Frame2.Parent = Frame;
local Frame3 = Instance.new("Frame");
Frame3.Name = "SectionRow";
Frame3.BackgroundTransparency = 1;
Frame3.Position = UDim2.new(0, 12, 0, 36);
Frame3.Size = UDim2.new(1, -24, 0, 24);
Frame3.Parent = Frame;
local UIListLayout2 = Instance.new("UIListLayout");
UIListLayout2.FillDirection = Enum.FillDirection.Horizontal;
UIListLayout2.SortOrder = Enum.SortOrder.LayoutOrder;
UIListLayout2.Padding = UDim.new(0, 6);
UIListLayout2.Parent = Frame3;

local function makeSectionBtn(p22, p23) -- Line: 360
    -- upvalues: Arcade (copy), Color3_fromRGB_ret3 (copy), Frame3 (copy), Color3_fromRGB_ret6 (copy)
    local TextButton = Instance.new("TextButton");
    TextButton.LayoutOrder = p23;
    TextButton.Size = UDim2.new(0.25, -6, 1, 0);
    TextButton.BackgroundColor3 = Color3.fromRGB(18, 18, 20);
    TextButton.Font = Arcade;
    TextButton.TextSize = 11;
    TextButton.TextScaled = true;
    TextButton.TextColor3 = Color3_fromRGB_ret3;
    TextButton.Text = p22;
    TextButton.Parent = Frame3;
    local UICorner = Instance.new("UICorner");
    UICorner.CornerRadius = UDim.new(0, 6);
    UICorner.Parent = TextButton;
    local UIStroke2 = Instance.new("UIStroke");
    UIStroke2.Color = Color3_fromRGB_ret6 or Color3_fromRGB_ret6;
    UIStroke2.Thickness = 2;
    UIStroke2.Parent = TextButton;
    local UITextSizeConstraint = Instance.new("UITextSizeConstraint");
    UITextSizeConstraint.MinTextSize = 8;
    UITextSizeConstraint.MaxTextSize = 12;
    UITextSizeConstraint.Parent = TextButton;

    return TextButton;
end;

local u24 = makeSectionBtn("CONTRACTS", 1);
local u25 = makeSectionBtn("MISSIONS", 2);
local u26 = makeSectionBtn("BOUNTIES", 3);
local u27 = makeSectionBtn("PVP", 4);
local u28 = nil;
local u29 = nil;
local Frame4 = Instance.new("Frame");
Frame4.Name = "BountySection";
Frame4.BackgroundTransparency = 1;
Frame4.Position = UDim2.new(0, 12, 0, 70);
Frame4.Size = UDim2.new(1, -24, 1, -80);
Frame4.Visible = false;
Frame4.Parent = Frame;
local ScrollingFrame2 = Instance.new("ScrollingFrame");
ScrollingFrame2.BackgroundTransparency = 1;
ScrollingFrame2.BorderSizePixel = 0;
ScrollingFrame2.Size = UDim2.new(1, 0, 1, 0);
ScrollingFrame2.ScrollBarThickness = 4;
ScrollingFrame2.AutomaticCanvasSize = Enum.AutomaticSize.Y;
ScrollingFrame2.CanvasSize = UDim2.new(0, 0, 0, 0);
ScrollingFrame2.ScrollingDirection = Enum.ScrollingDirection.Y;
ScrollingFrame2.Parent = Frame4;
local UIListLayout3 = Instance.new("UIListLayout");
UIListLayout3.Padding = UDim.new(0, 6);
UIListLayout3.Parent = ScrollingFrame2;

local function refreshBounties() -- Line: 409
    -- upvalues: ScrollingFrame2 (copy), ContractRemote (copy), Color3_fromRGB_ret (copy), Color3_fromRGB_ret6 (copy), Arcade (copy), Color3_fromRGB_ret3 (copy), Bangers (copy), Color3_fromRGB_ret2 (copy), Color3_fromRGB_ret5 (copy), ServerRemote (copy)
    for _, child in ipairs(ScrollingFrame2:GetChildren()) do
        if child:IsA("Frame") then
            child:Destroy();
        end;
    end;

    local success, result = pcall(ContractRemote.InvokeServer, ContractRemote, {
        Action = "BountyList"
    });
    local v30 = success and (type(result) == "table" and result.bounties) or {};

    if #v30 ~= 0 then
        for i, v in ipairs(v30) do
            local Frame5 = Instance.new("Frame");
            Frame5.Size = UDim2.new(1, -6, 0, 46);
            Frame5.BackgroundColor3 = Color3_fromRGB_ret;
            Frame5.LayoutOrder = i;
            Frame5.Parent = ScrollingFrame2;
            local UICorner = Instance.new("UICorner");
            UICorner.CornerRadius = UDim.new(0, 6);
            UICorner.Parent = Frame5;
            local UIStroke2 = Instance.new("UIStroke");
            UIStroke2.Color = Color3_fromRGB_ret6;
            UIStroke2.Thickness = 2;
            UIStroke2.Parent = Frame5;
            local TextLabel3 = Instance.new("TextLabel");
            TextLabel3.BackgroundTransparency = 1;
            TextLabel3.Position = UDim2.new(0, 10, 0, 4);
            TextLabel3.Size = UDim2.new(1, -110, 0, 17);
            TextLabel3.Font = Bangers;
            TextLabel3.TextSize = 16;
            TextLabel3.TextXAlignment = Enum.TextXAlignment.Left;
            TextLabel3.TextColor3 = Color3_fromRGB_ret2;
            TextLabel3.TextTruncate = Enum.TextTruncate.AtEnd;
            TextLabel3.Text = v.Name or "?";
            TextLabel3.Parent = Frame5;
            local TextLabel4 = Instance.new("TextLabel");
            TextLabel4.BackgroundTransparency = 1;
            TextLabel4.Position = UDim2.new(0, 10, 0, 24);
            TextLabel4.Size = UDim2.new(1, -110, 0, 14);
            TextLabel4.Font = Arcade;
            TextLabel4.TextSize = 10;
            TextLabel4.TextXAlignment = Enum.TextXAlignment.Left;
            TextLabel4.TextColor3 = Color3.fromRGB(225, 100, 90);
            TextLabel4.TextTruncate = Enum.TextTruncate.AtEnd;
            TextLabel4.Text = ("Bounty: %s   Race: %s"):format(tostring(v.Bounty), (tostring(v.Race)));
            TextLabel4.Parent = Frame5;
            local TextButton = Instance.new("TextButton");
            TextButton.AnchorPoint = Vector2.new(1, 0.5);
            TextButton.Position = UDim2.new(1, -8, 0.5, 0);
            TextButton.Size = UDim2.fromOffset(84, 28);
            TextButton.BackgroundColor3 = Color3.fromRGB(18, 18, 20);
            TextButton.Font = Bangers;
            TextButton.TextSize = 15;
            TextButton.TextColor3 = Color3_fromRGB_ret5;
            TextButton.Text = "TARGET";
            TextButton.Parent = Frame5;
            local UICorner2 = Instance.new("UICorner");
            UICorner2.CornerRadius = UDim.new(0, 6);
            UICorner2.Parent = TextButton;
            local UIStroke3 = Instance.new("UIStroke");
            UIStroke3.Color = Color3_fromRGB_ret6 or Color3_fromRGB_ret6;
            UIStroke3.Thickness = 2;
            UIStroke3.Parent = TextButton;
            TextButton.Activated:Connect(function() -- Line: 475
                -- upvalues: ServerRemote (ref), v (copy), TextButton (copy)
                ServerRemote:FireServer(nil, {
                    Module = "BountyManager",
                    Action = "SetBountyTarget",
                    Target = v.UserName
                });
                TextButton.Text = "SET!";
            end);
        end;

        return;
    end;

    local Frame5 = Instance.new("Frame");
    Frame5.Size = UDim2.new(1, -6, 0, 40);
    Frame5.BackgroundColor3 = Color3_fromRGB_ret;
    Frame5.Parent = ScrollingFrame2;
    local UICorner = Instance.new("UICorner");
    UICorner.CornerRadius = UDim.new(0, 6);
    UICorner.Parent = Frame5;
    local UIStroke2 = Instance.new("UIStroke");
    UIStroke2.Color = Color3_fromRGB_ret6;
    UIStroke2.Thickness = 2;
    UIStroke2.Parent = Frame5;
    local TextLabel3 = Instance.new("TextLabel");
    TextLabel3.BackgroundTransparency = 1;
    TextLabel3.Size = UDim2.new(1, 0, 1, 0);
    TextLabel3.Font = Arcade;
    TextLabel3.TextSize = 11;
    TextLabel3.TextColor3 = Color3_fromRGB_ret3;
    TextLabel3.TextWrapped = true;
    TextLabel3.Text = "No bounties posted right now.";
    TextLabel3.Parent = Frame5;
end;

local function setSection(p31) -- Line: 486
    -- upvalues: u21 (ref), ScrollingFrame (copy), TextLabel2 (copy), Frame2 (copy), Frame4 (copy), u28 (ref), u24 (copy), Color3_fromRGB_ret4 (copy), Color3_fromRGB_ret3 (copy), u25 (copy), u26 (copy), u27 (copy), refreshBounties (copy), u29 (ref)
    u21 = p31;
    ScrollingFrame.Visible = p31 == "CONTRACTS";
    TextLabel2.Visible = p31 == "CONTRACTS";
    Frame2.Visible = p31 == "MISSIONS";
    Frame4.Visible = p31 == "BOUNTIES";

    if u28 then
        u28.Visible = p31 == "PVP";
    end;

    u24.TextColor3 = p31 == "CONTRACTS" and Color3_fromRGB_ret4 or Color3_fromRGB_ret3;
    u25.TextColor3 = p31 == "MISSIONS" and Color3_fromRGB_ret4 or Color3_fromRGB_ret3;
    u26.TextColor3 = p31 == "BOUNTIES" and Color3_fromRGB_ret4 or Color3_fromRGB_ret3;
    u27.TextColor3 = p31 == "PVP" and Color3_fromRGB_ret4 or Color3_fromRGB_ret3;

    if p31 == "BOUNTIES" then
        refreshBounties();
    end;

    if p31 == "PVP" and u29 then
        u29(true);
    end;
end;

local TextLabel3 = Instance.new("TextLabel");
TextLabel3.BackgroundTransparency = 1;
TextLabel3.Position = UDim2.new(0, 0, 0, 6);
TextLabel3.Size = UDim2.new(1, 0, 0, 18);
TextLabel3.Font = Arcade;
TextLabel3.TextSize = 13;
TextLabel3.TextXAlignment = Enum.TextXAlignment.Center;
TextLabel3.TextTruncate = Enum.TextTruncate.AtEnd;
TextLabel3.TextColor3 = Color3_fromRGB_ret3;
TextLabel3.Text = "NOT QUEUED";
TextLabel3.Parent = Frame2;
local Frame5 = Instance.new("Frame");
Frame5.BackgroundTransparency = 1;
Frame5.AnchorPoint = Vector2.new(0.5, 0);
Frame5.Position = UDim2.new(0.5, 0, 0, 34);
Frame5.Size = UDim2.fromOffset(316, 96);
Frame5.Parent = Frame2;
local TextButton = Instance.new("TextButton");
TextButton.AnchorPoint = Vector2.new(0.5, 0);
TextButton.Position = UDim2.new(0.5, 0, 0, 52);
TextButton.Size = UDim2.fromOffset(180, 44);
TextButton.BackgroundColor3 = Color3.fromRGB(18, 18, 20);
TextButton.Font = Bangers;
TextButton.TextSize = 17;
TextButton.TextColor3 = Color3_fromRGB_ret5;
TextButton.Text = "LEAVE QUEUE";
TextButton.Visible = false;
TextButton.Parent = Frame2;
local UICorner = Instance.new("UICorner");
UICorner.CornerRadius = UDim.new(0, 6);
UICorner.Parent = TextButton;
local Color3_fromRGB_ret7 = Color3.fromRGB(225, 100, 90);
local UIStroke2 = Instance.new("UIStroke");
UIStroke2.Color = Color3_fromRGB_ret7 or Color3_fromRGB_ret6;
UIStroke2.Thickness = 2;
UIStroke2.Parent = TextButton;
local v32 = {
    LOW = UDim2.fromOffset(0, 0),
    MEDIUM = UDim2.fromOffset(162, 0),
    HIGH = UDim2.fromOffset(0, 50),
    EXTREME = UDim2.fromOffset(162, 50)
};
local u33 = {};
local u34 = false;

for _, v in ipairs({ "LOW", "MEDIUM", "HIGH", "EXTREME" }) do
    local TextButton2 = Instance.new("TextButton");
    TextButton2.Position = v32[v];
    TextButton2.Size = UDim2.fromOffset(154, 44);
    TextButton2.BackgroundColor3 = Color3.fromRGB(18, 18, 20);
    TextButton2.Font = Arcade;
    TextButton2.TextSize = 12;
    TextButton2.TextColor3 = Color3_fromRGB_ret3;
    TextButton2.Text = v;
    TextButton2.Parent = Frame5;
    local UICorner2 = Instance.new("UICorner");
    UICorner2.CornerRadius = UDim.new(0, 6);
    UICorner2.Parent = TextButton2;
    local v35 = {
        unlocked = false,
        btn = TextButton2
    };
    local UIStroke3 = Instance.new("UIStroke");
    UIStroke3.Color = Color3_fromRGB_ret6;
    UIStroke3.Thickness = 2;
    UIStroke3.Parent = TextButton2;
    v35.stroke = UIStroke3;
    u33[v] = v35;
end;

local function applyTiers(p36) -- Line: 565
    -- upvalues: u33 (copy), Color3_fromRGB_ret5 (copy), Color3_fromRGB_ret4 (copy), Color3_fromRGB_ret3 (copy), Color3_fromRGB_ret6 (copy)
    for _, v in ipairs(p36 or {}) do
        local v37 = u33[v.Key];

        if v37 then
            v37.unlocked = v.Unlocked == true;

            if v37.unlocked then
                v37.btn.Text = v.Label:upper();
                v37.btn.TextColor3 = Color3_fromRGB_ret5;
                v37.stroke.Color = Color3_fromRGB_ret4;
            else
                v37.btn.Text = v.Label:upper() .. "  [LVL " .. v.MinLevel .. "+]";
                v37.btn.TextColor3 = Color3_fromRGB_ret3;
                v37.stroke.Color = Color3_fromRGB_ret6;
            end;
        end;
    end;
end;

local u38 = true;
local u39 = false;
local u40 = false;

local function applyQueued(p41, p42) -- Line: 585
    -- upvalues: u34 (ref), Frame5 (copy), u38 (ref), TextButton (copy), TextLabel3 (copy), Color3_fromRGB_ret3 (copy), u40 (ref), Color3_fromRGB_ret4 (copy), u39 (ref), u33 (copy)
    u34 = p41;
    Frame5.Visible = u38 and not u34;
    TextButton.Visible = u38 and u34;

    if u38 then
        if u34 and u40 then
            TextLabel3.TextColor3 = Color3.fromRGB(255, 140, 80);
            TextLabel3.Text = "IN QUEUE (" .. tostring(p42 or "?") .. ") -- paused: in combat";
        elseif u34 then
            TextLabel3.TextColor3 = Color3_fromRGB_ret4;
            TextLabel3.Text = "IN QUEUE (" .. tostring(p42 or "?") .. ") -- searching...";
        elseif u39 then
            TextLabel3.TextColor3 = Color3.fromRGB(255, 140, 80);
            TextLabel3.Text = "IN COMBAT -- queue when the fight is over";
        else
            TextLabel3.TextColor3 = Color3_fromRGB_ret3;
            TextLabel3.Text = "NOT QUEUED -- pick a difficulty";
        end;
    else
        TextLabel3.TextColor3 = Color3_fromRGB_ret3;
        TextLabel3.Text = "MISSIONS: EARTH, SADALA & NAMEK ONLY";
    end;

    for _, v in pairs(u33) do
        v.btn.AutoButtonColor = not u39 and v.unlocked;
    end;
end;

for i, v in pairs(u33) do
    v.btn.Activated:Connect(function() -- Line: 612
        -- upvalues: u34 (ref), v (copy), u39 (ref), ContractRemote (copy), i (copy), applyQueued (copy)
        if u34 or (not v.unlocked or u39) then
            return;
        end;

        v.btn.Active = false;
        local success, result = pcall(ContractRemote.InvokeServer, ContractRemote, {
            Action = "MissionQueue",
            Difficulty = i
        });

        if success and (type(result) == "table" and result.ok) then
            applyQueued(true, i);
        end;

        v.btn.Active = true;
    end);
end;

TextButton.Activated:Connect(function() -- Line: 625
    -- upvalues: TextButton (copy), ContractRemote (copy), applyQueued (copy)
    TextButton.Active = false;
    local success, _ = pcall(ContractRemote.InvokeServer, ContractRemote, {
        Action = "MissionLeave"
    });

    if success then
        applyQueued(false);
    end;

    TextButton.Active = true;
end);
task.spawn(function() -- Line: 635
    -- upvalues: Frame (copy), Frame2 (copy), ContractRemote (copy), u38 (ref), u39 (ref), u40 (ref), applyTiers (copy), applyQueued (copy)
    while Frame.Parent do
        if Frame.Visible and Frame2.Visible then
            local success, result = pcall(ContractRemote.InvokeServer, ContractRemote, {
                Action = "MissionStatus"
            });

            if success and type(result) == "table" then
                u38 = result.allowed ~= false;
                u39 = result.combat == true;
                u40 = result.held == true;
                applyTiers(result.tiers);
                applyQueued(result.queued == true, result.difficulty);
            end;

            task.wait(2);
        else
            task.wait(0.5);
        end;
    end;
end);
u24.Activated:Connect(function() -- Line: 654
    -- upvalues: u21 (ref), ScrollingFrame (copy), TextLabel2 (copy), Frame2 (copy), Frame4 (copy), u28 (ref), u24 (copy), Color3_fromRGB_ret4 (copy), Color3_fromRGB_ret3 (copy), u25 (copy), u26 (copy), u27 (copy)
    u21 = "CONTRACTS";
    ScrollingFrame.Visible = true;
    TextLabel2.Visible = true;
    Frame2.Visible = false;
    Frame4.Visible = false;

    if u28 then
        u28.Visible = false;
    end;

    u24.TextColor3 = Color3_fromRGB_ret4 or Color3_fromRGB_ret3;
    u25.TextColor3 = Color3_fromRGB_ret3;
    u26.TextColor3 = Color3_fromRGB_ret3;
    u27.TextColor3 = Color3_fromRGB_ret3;
end);
u25.Activated:Connect(function() -- Line: 655
    -- upvalues: u21 (ref), ScrollingFrame (copy), TextLabel2 (copy), Frame2 (copy), Frame4 (copy), u28 (ref), u24 (copy), Color3_fromRGB_ret3 (copy), u25 (copy), Color3_fromRGB_ret4 (copy), u26 (copy), u27 (copy)
    u21 = "MISSIONS";
    ScrollingFrame.Visible = false;
    TextLabel2.Visible = false;
    Frame2.Visible = true;
    Frame4.Visible = false;

    if u28 then
        u28.Visible = false;
    end;

    u24.TextColor3 = Color3_fromRGB_ret3;
    u25.TextColor3 = Color3_fromRGB_ret4 or Color3_fromRGB_ret3;
    u26.TextColor3 = Color3_fromRGB_ret3;
    u27.TextColor3 = Color3_fromRGB_ret3;
end);
u26.Activated:Connect(function() -- Line: 656
    -- upvalues: u21 (ref), ScrollingFrame (copy), TextLabel2 (copy), Frame2 (copy), Frame4 (copy), u28 (ref), u24 (copy), Color3_fromRGB_ret3 (copy), u25 (copy), u26 (copy), Color3_fromRGB_ret4 (copy), u27 (copy), refreshBounties (copy)
    u21 = "BOUNTIES";
    ScrollingFrame.Visible = false;
    TextLabel2.Visible = false;
    Frame2.Visible = false;
    Frame4.Visible = true;

    if u28 then
        u28.Visible = false;
    end;

    u24.TextColor3 = Color3_fromRGB_ret3;
    u25.TextColor3 = Color3_fromRGB_ret3;
    u26.TextColor3 = Color3_fromRGB_ret4 or Color3_fromRGB_ret3;
    u27.TextColor3 = Color3_fromRGB_ret3;
    refreshBounties();
end);
u28 = Instance.new("Frame");
u28.Name = "PvpSection";
u28.BackgroundTransparency = 1;
u28.Position = UDim2.new(0, 12, 0, 70);
u28.Size = UDim2.new(1, -24, 1, -80);
u28.Visible = false;
u28.Parent = Frame;
local Frame6 = Instance.new("Frame");
Frame6.Size = UDim2.new(1, -6, 0, 92);
Frame6.BackgroundColor3 = Color3_fromRGB_ret;
Frame6.Parent = u28;
local UICorner2 = Instance.new("UICorner");
UICorner2.CornerRadius = UDim.new(0, 6);
UICorner2.Parent = Frame6;
local UIStroke3 = Instance.new("UIStroke");
UIStroke3.Color = Color3_fromRGB_ret6;
UIStroke3.Thickness = 2;
UIStroke3.Parent = Frame6;
local TextLabel4 = Instance.new("TextLabel");
TextLabel4.BackgroundTransparency = 1;
TextLabel4.Position = UDim2.new(0, 10, 0, 6);
TextLabel4.Size = UDim2.new(1, -140, 0, 14);
TextLabel4.Font = Arcade;
TextLabel4.TextSize = 12;
TextLabel4.TextXAlignment = Enum.TextXAlignment.Left;
TextLabel4.TextColor3 = Color3.fromRGB(225, 100, 90);
TextLabel4.Text = "RANKED PVP";
TextLabel4.Parent = Frame6;
local TextLabel5 = Instance.new("TextLabel");
TextLabel5.BackgroundTransparency = 1;
TextLabel5.Position = UDim2.new(0, 10, 0, 20);
TextLabel5.Size = UDim2.new(1, -140, 0, 26);
TextLabel5.Font = Bangers;
TextLabel5.TextSize = 22;
TextLabel5.TextXAlignment = Enum.TextXAlignment.Left;
TextLabel5.TextColor3 = Color3_fromRGB_ret2;
TextLabel5.TextTruncate = Enum.TextTruncate.AtEnd;
TextLabel5.Text = "ELO 1000";
TextLabel5.Parent = Frame6;
local TextLabel6 = Instance.new("TextLabel");
TextLabel6.BackgroundTransparency = 1;
TextLabel6.Position = UDim2.new(0, 10, 0, 48);
TextLabel6.Size = UDim2.new(1, -140, 0, 14);
TextLabel6.Font = Arcade;
TextLabel6.TextSize = 11;
TextLabel6.TextXAlignment = Enum.TextXAlignment.Left;
TextLabel6.TextColor3 = Color3_fromRGB_ret4;
TextLabel6.TextTruncate = Enum.TextTruncate.AtEnd;
TextLabel6.Text = "0 W  -  0 L";
TextLabel6.Parent = Frame6;
local TextLabel7 = Instance.new("TextLabel");
TextLabel7.BackgroundTransparency = 1;
TextLabel7.Position = UDim2.new(0, 10, 0, 66);
TextLabel7.Size = UDim2.new(1, -140, 0, 18);
TextLabel7.Font = Arcade;
TextLabel7.TextSize = 10;
TextLabel7.TextXAlignment = Enum.TextXAlignment.Left;
TextLabel7.TextColor3 = Color3_fromRGB_ret3;
TextLabel7.TextTruncate = Enum.TextTruncate.AtEnd;
TextLabel7.TextWrapped = true;
TextLabel7.Text = "Solo or party. Level 10+. Wins pay big ELO.";
TextLabel7.Parent = Frame6;
local TextButton2 = Instance.new("TextButton");
TextButton2.AnchorPoint = Vector2.new(1, 0.5);
TextButton2.Position = UDim2.new(1, -10, 0.5, 0);
TextButton2.Size = UDim2.fromOffset(112, 40);
TextButton2.BackgroundColor3 = Color3.fromRGB(18, 18, 20);
TextButton2.Font = Bangers;
TextButton2.TextSize = 18;
TextButton2.TextColor3 = Color3_fromRGB_ret5;
TextButton2.Text = "QUEUE";
TextButton2.Parent = Frame6;
local UICorner3 = Instance.new("UICorner");
UICorner3.CornerRadius = UDim.new(0, 6);
UICorner3.Parent = TextButton2;
local UIStroke4 = Instance.new("UIStroke");
UIStroke4.Color = Color3_fromRGB_ret4 or Color3_fromRGB_ret6;
UIStroke4.Thickness = 2;
UIStroke4.Parent = TextButton2;
local TextLabel8 = Instance.new("TextLabel");
TextLabel8.BackgroundTransparency = 1;
TextLabel8.Position = UDim2.new(0, 4, 0, 100);
TextLabel8.Size = UDim2.new(1, -8, 0, 14);
TextLabel8.Font = Arcade;
TextLabel8.TextSize = 11;
TextLabel8.TextXAlignment = Enum.TextXAlignment.Left;
TextLabel8.TextColor3 = Color3_fromRGB_ret3;
TextLabel8.Text = "GLOBAL BATTLE RANKING";
TextLabel8.Parent = u28;
local ScrollingFrame3 = Instance.new("ScrollingFrame");
ScrollingFrame3.BackgroundTransparency = 1;
ScrollingFrame3.BorderSizePixel = 0;
ScrollingFrame3.Position = UDim2.new(0, 0, 0, 118);
ScrollingFrame3.Size = UDim2.new(1, 0, 1, -118);
ScrollingFrame3.ScrollBarThickness = 4;
ScrollingFrame3.AutomaticCanvasSize = Enum.AutomaticSize.Y;
ScrollingFrame3.CanvasSize = UDim2.new(0, 0, 0, 0);
ScrollingFrame3.ScrollingDirection = Enum.ScrollingDirection.Y;
ScrollingFrame3.Parent = u28;
local UIListLayout4 = Instance.new("UIListLayout");
UIListLayout4.Padding = UDim.new(0, 4);
UIListLayout4.SortOrder = Enum.SortOrder.LayoutOrder;
UIListLayout4.Parent = ScrollingFrame3;
local u43 = false;
local u44 = false;

local function applyPvpStatus(p45) -- Line: 767
    -- upvalues: u43 (ref), TextLabel5 (copy), TextLabel6 (copy), TextLabel7 (copy), Color3_fromRGB_ret3 (copy), TextButton2 (copy), Color3_fromRGB_ret4 (copy), UIStroke4 (copy)
    if type(p45) ~= "table" then
        return;
    end;

    u43 = p45.queued == true;
    TextLabel5.Text = "ELO " .. tostring(p45.elo or 1000);
    TextLabel6.Text = tostring(p45.wins or 0) .. " W  -  " .. tostring(p45.losses or 0) .. " L";

    if p45.allowed == false then
        TextLabel7.TextColor3 = Color3_fromRGB_ret3;
        TextLabel7.Text = "PVP: EARTH, SADALA & NAMEK ONLY";
        TextButton2.Visible = false;

        return;
    end;

    TextButton2.Visible = true;

    if p45.fighting then
        TextLabel7.TextColor3 = Color3.fromRGB(225, 100, 90);
        TextLabel7.Text = "IN A MATCH";
        TextButton2.Visible = false;

        return;
    end;

    if u43 then
        TextLabel7.TextColor3 = Color3_fromRGB_ret4;
        TextLabel7.Text = "IN QUEUE -- searching (" .. tostring(p45.waited or 0) .. "s)";
        TextButton2.Text = "LEAVE";
        UIStroke4.Color = Color3.fromRGB(225, 100, 90);

        return;
    end;

    TextLabel7.TextColor3 = Color3_fromRGB_ret3;
    TextLabel7.Text = "Solo or party. Level " .. tostring(p45.minLevel or 10) .. "+. Wins pay big ELO.";
    TextButton2.Text = "QUEUE";
    UIStroke4.Color = Color3_fromRGB_ret4;
end;

local function applyLeaderboard(p46) -- Line: 796
    -- upvalues: ScrollingFrame3 (copy), Color3_fromRGB_ret (copy), Color3_fromRGB_ret6 (copy), Arcade (copy), Color3_fromRGB_ret3 (copy), Color3_fromRGB_ret4 (copy), Bangers (copy), Color3_fromRGB_ret2 (copy)
    for _, child in ipairs(ScrollingFrame3:GetChildren()) do
        if child:IsA("Frame") then
            child:Destroy();
        end;
    end;

    local v47 = type(p46) == "table" and (p46.list or {}) or {};
    local v48;

    if type(p46) == "table" then
        v48 = p46.you and p46.you.Key;
    else
        v48 = false;
    end;

    if #v47 ~= 0 then
        for _, v in ipairs(v47) do
            local Frame7 = Instance.new("Frame");
            Frame7.Size = UDim2.new(1, -6, 0, 26);
            Frame7.BackgroundColor3 = Color3_fromRGB_ret;
            Frame7.LayoutOrder = v.Rank;
            Frame7.Parent = ScrollingFrame3;
            local UICorner4 = Instance.new("UICorner");
            UICorner4.CornerRadius = UDim.new(0, 6);
            UICorner4.Parent = Frame7;
            local v49 = v.Key == v48 and Color3_fromRGB_ret4 or Color3_fromRGB_ret6;
            local UIStroke5 = Instance.new("UIStroke");
            UIStroke5.Color = v49 or Color3_fromRGB_ret6;
            UIStroke5.Thickness = 2;
            UIStroke5.Parent = Frame7;
            local TextLabel9 = Instance.new("TextLabel");
            TextLabel9.BackgroundTransparency = 1;
            TextLabel9.Position = UDim2.new(0, 8, 0, 0);
            TextLabel9.Size = UDim2.new(0, 34, 1, 0);
            TextLabel9.Font = Arcade;
            TextLabel9.TextSize = 11;
            TextLabel9.TextXAlignment = Enum.TextXAlignment.Left;
            TextLabel9.TextColor3 = v.Rank <= 3 and Color3.fromRGB(250, 204, 90) or Color3_fromRGB_ret3;
            TextLabel9.Text = "#" .. tostring(v.Rank);
            TextLabel9.Parent = Frame7;
            local TextLabel10 = Instance.new("TextLabel");
            TextLabel10.BackgroundTransparency = 1;
            TextLabel10.Position = UDim2.new(0, 44, 0, 0);
            TextLabel10.Size = UDim2.new(1, -210, 1, 0);
            TextLabel10.Font = Bangers;
            TextLabel10.TextSize = 15;
            TextLabel10.TextXAlignment = Enum.TextXAlignment.Left;
            TextLabel10.TextColor3 = v.Key == v48 and Color3_fromRGB_ret4 or Color3_fromRGB_ret2;
            TextLabel10.TextTruncate = Enum.TextTruncate.AtEnd;
            TextLabel10.RichText = true;
            local v50 = tostring(v.Name or "?"):gsub("[<>&]", "");
            local v51;

            if v.Username then
                v51 = tostring(v.Username):gsub("[<>&]", "") or nil;
            else
                v51 = nil;
            end;

            if v51 and v51 ~= v50 then
                TextLabel10.Text = ("%s <font color=\"#9a978f\" size=\"11\">(%s)</font>"):format(v50, v51);
            else
                TextLabel10.Text = v50;
            end;

            TextLabel10.Parent = Frame7;
            local TextLabel11 = Instance.new("TextLabel");
            TextLabel11.BackgroundTransparency = 1;
            TextLabel11.AnchorPoint = Vector2.new(1, 0);
            TextLabel11.Position = UDim2.new(1, -8, 0, 0);
            TextLabel11.Size = UDim2.new(0, 70, 1, 0);
            TextLabel11.Font = Arcade;
            TextLabel11.TextSize = 11;
            TextLabel11.TextXAlignment = Enum.TextXAlignment.Right;
            TextLabel11.TextColor3 = Color3_fromRGB_ret2;
            TextLabel11.Text = tostring(v.Elo);
            TextLabel11.Parent = Frame7;
            local TextLabel12 = Instance.new("TextLabel");
            TextLabel12.BackgroundTransparency = 1;
            TextLabel12.AnchorPoint = Vector2.new(1, 0);
            TextLabel12.Position = UDim2.new(1, -82, 0, 0);
            TextLabel12.Size = UDim2.new(0, 84, 1, 0);
            TextLabel12.Font = Arcade;
            TextLabel12.TextSize = 10;
            TextLabel12.TextXAlignment = Enum.TextXAlignment.Right;
            TextLabel12.TextColor3 = Color3.fromRGB(90, 200, 255);
            TextLabel12.TextTruncate = Enum.TextTruncate.AtEnd;
            TextLabel12.Text = v.Race and string.upper((tostring(v.Race))) or "?";
            TextLabel12.Parent = Frame7;
        end;

        return;
    end;

    local Frame7 = Instance.new("Frame");
    Frame7.Size = UDim2.new(1, -6, 0, 32);
    Frame7.BackgroundColor3 = Color3_fromRGB_ret;
    Frame7.Parent = ScrollingFrame3;
    local UICorner4 = Instance.new("UICorner");
    UICorner4.CornerRadius = UDim.new(0, 6);
    UICorner4.Parent = Frame7;
    local UIStroke5 = Instance.new("UIStroke");
    UIStroke5.Color = Color3_fromRGB_ret6;
    UIStroke5.Thickness = 2;
    UIStroke5.Parent = Frame7;
    local TextLabel9 = Instance.new("TextLabel");
    TextLabel9.BackgroundTransparency = 1;
    TextLabel9.Size = UDim2.new(1, 0, 1, 0);
    TextLabel9.Font = Arcade;
    TextLabel9.TextSize = 10;
    TextLabel9.TextColor3 = Color3_fromRGB_ret3;
    TextLabel9.Text = "No ranked fights yet. Be the first.";
    TextLabel9.Parent = Frame7;
end;

u29 = function(p52) -- Line: 883
    -- upvalues: ContractRemote (copy), applyPvpStatus (copy), applyLeaderboard (copy)
    local success, result = pcall(ContractRemote.InvokeServer, ContractRemote, {
        Action = "PvpStatus"
    });

    if success then
        applyPvpStatus(result);
    end;

    if p52 then
        local success2, result2 = pcall(ContractRemote.InvokeServer, ContractRemote, {
            Action = "PvpLeaderboard"
        });

        if success2 then
            applyLeaderboard(result2);
        end;
    end;
end;

TextButton2.Activated:Connect(function() -- Line: 892
    -- upvalues: u44 (ref), u43 (ref), ContractRemote (copy), applyPvpStatus (copy), TextLabel5 (copy), u29 (ref)
    if u44 then
        return;
    end;

    u44 = true;
    local v53 = u43 and "PvpLeave" or "PvpQueue";
    local success, result = pcall(ContractRemote.InvokeServer, ContractRemote, {
        Action = v53
    });

    if success and (type(result) == "table" and result.ok) then
        applyPvpStatus({
            allowed = true,
            waited = 0,
            queued = v53 == "PvpQueue",
            elo = tonumber(TextLabel5.Text:match("%d+"))
        });
    end;

    u29(false);
    u44 = false;
end);
task.spawn(function() -- Line: 905
    -- upvalues: Frame (copy), u28 (ref), u29 (ref)
    local v54 = 0;

    while Frame.Parent do
        if Frame.Visible and u28.Visible then
            local v55 = os.clock() - v54 > 60;

            if v55 then
                v54 = os.clock();
            end;

            u29(v55);
            task.wait(2);
        else
            task.wait(0.5);
        end;
    end;
end);
u27.Activated:Connect(function() -- Line: 919
    -- upvalues: u21 (ref), ScrollingFrame (copy), TextLabel2 (copy), Frame2 (copy), Frame4 (copy), u28 (ref), u24 (copy), Color3_fromRGB_ret3 (copy), u25 (copy), u26 (copy), u27 (copy), Color3_fromRGB_ret4 (copy), u29 (ref)
    u21 = "PVP";
    ScrollingFrame.Visible = false;
    TextLabel2.Visible = false;
    Frame2.Visible = false;
    Frame4.Visible = false;

    if u28 then
        u28.Visible = true;
    end;

    u24.TextColor3 = Color3_fromRGB_ret3;
    u25.TextColor3 = Color3_fromRGB_ret3;
    u26.TextColor3 = Color3_fromRGB_ret3;
    u27.TextColor3 = Color3_fromRGB_ret4 or Color3_fromRGB_ret3;

    if u29 then
        u29(true);
    end;
end);
u21 = "CONTRACTS";
ScrollingFrame.Visible = true;
TextLabel2.Visible = true;
Frame2.Visible = false;
Frame4.Visible = false;

if u28 then
    u28.Visible = false;
end;

u24.TextColor3 = Color3_fromRGB_ret4 or Color3_fromRGB_ret3;
u25.TextColor3 = Color3_fromRGB_ret3;
u26.TextColor3 = Color3_fromRGB_ret3;
u27.TextColor3 = Color3_fromRGB_ret3;
u7.Activated:Connect(function() -- Line: 924
    -- upvalues: Tabs (copy), StatFrame (copy), u7 (copy), Frame (copy), u14 (ref)
    for _, child in ipairs(Tabs:GetChildren()) do
        if child:IsA("ImageButton") then
            child.Image = "rbxassetid://126454867112626";
        end;
    end;

    for _, child in ipairs(StatFrame:GetChildren()) do
        if child:IsA("Frame") and child.Name ~= "Tabs" then
            child.Visible = false;
        end;
    end;

    u7.Image = "rbxassetid://126781002557225";
    Frame.Visible = true;
    u14();
end);