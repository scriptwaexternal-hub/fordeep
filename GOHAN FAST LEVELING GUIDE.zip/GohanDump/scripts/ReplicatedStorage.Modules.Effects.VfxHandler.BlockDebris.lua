-- Decompiled with Potassium's decompiler.

game:GetService("Players");
local Debris = game:GetService("Debris");
local ReplicatedStorage = game:GetService("ReplicatedStorage");
game:GetService("RunService");
game:GetService("UserInputService");
local PhysicsService = game:GetService("PhysicsService");
local Assets = ReplicatedStorage.Assets;
local Modules = ReplicatedStorage:WaitForChild("Modules");
ReplicatedStorage:WaitForChild("Remotes");
local _ = Modules.Metadata;
local _ = Modules.Utility;
local _ = Assets.Gui;
require(Modules.Shared.SoundManager);
local GlobalFunctions = require(Modules.GlobalFunctions);
local Visuals = workspace.World.Visuals;

return {
    Execute = function(p1) -- Line: 31
        -- upvalues: Visuals (copy), PhysicsService (copy), GlobalFunctions (copy), Debris (copy)
        local Location = p1.Location;
        local Material = p1.Material;
        local Color = p1.Color;
        local Transparency = p1.Transparency;
        local v2 = p1 and p1.Duration or 14;

        for i = 1, p1.MaxParts or 3 do
            local math_random_ret = math.random(3, 7);
            local Part = Instance.new("Part");
            Part.CanCollide = true;
            Part.Parent = Visuals;
            Part.CFrame = Location;
            Part.Material = Material;
            Part.Color = Color;
            Part.Transparency = Transparency;
            local math_random_ret2 = math.random(1, 360);
            local math_random_ret3 = math.random(1, 360);
            Part.Orientation = Vector3.new(math_random_ret2, math_random_ret3, math.random(1, 360));
            local v3 = math.random(1, 20) / 10;
            local v4 = math.random(10, 20) / 10;
            local v5 = math.random(10, 20) / 10;
            Part.Size = Vector3.new(v3, v4, v5);
            pcall(function() -- Line: 59
                -- upvalues: PhysicsService (ref), Part (copy)
                PhysicsService:SetPartCollisionGroup(Part, "Phase");
            end);
            local math_random_ret4 = math.random(-10, 10);
            local math_random_ret5 = math.random(10, 20);
            local math_random_ret6 = math.random(-10, 10);
            local BodyVelocity = Instance.new("BodyVelocity");
            BodyVelocity.Parent = Part;
            BodyVelocity.MaxForce = Vector3.new(40000, 40000, 40000);
            BodyVelocity.Velocity = Vector3.new(math_random_ret4, math_random_ret5, math_random_ret6) * math_random_ret;
            game.Debris:AddItem(BodyVelocity, 0.5);
            task.delay(0.5, function() -- Line: 79
            end);
            task.delay(v2, function() -- Line: 83
                -- upvalues: GlobalFunctions (ref), Part (copy), Debris (ref)
                GlobalFunctions.TransparencyTween({
                    Instance = Part
                });
                Debris:AddItem(Part, 1);
            end);
            local _ = i;
        end;
    end
};