-- Decompiled with Potassium's decompiler.

local ReplicatedStorage = game:GetService("ReplicatedStorage");
local Players = game:GetService("Players");
local Modules = ReplicatedStorage:WaitForChild("Modules");
local Remotes = ReplicatedStorage:WaitForChild("Remotes");
local SkillData = require(Modules.Metadata.SkillData.SkillData);
local ClothesData = require(Modules.Metadata.MiscData.ClothesData.ClothesData);
local SkillRemote = Remotes.SkillRemote;
local LocalPlayer = Players.LocalPlayer;
local Color3_fromRGB_ret = Color3.fromRGB(170, 255, 130);
local Color3_fromRGB_ret2 = Color3.fromRGB(24, 24, 29);
local Color3_fromRGB_ret3 = Color3.fromRGB(33, 33, 40);
local Color3_fromRGB_ret4 = Color3.fromRGB(41, 41, 50);
local Color3_fromRGB_ret5 = Color3.fromRGB(235, 235, 240);
local Color3_fromRGB_ret6 = Color3.fromRGB(150, 150, 162);
local Color3_fromRGB_ret7 = Color3.fromRGB(20, 20, 20);
local u1 = {
    Clothes = nil,
    Cape = false,
    Turban = false,
    Self = false
};
local u2 = nil;
local u3 = nil;

local function corner(p4, p5) -- Line: 43
    local UICorner = Instance.new("UICorner");
    UICorner.CornerRadius = UDim.new(0, p5 or 8);
    UICorner.Parent = p4;
end;

local function setHint(p6, p7) -- Line: 51
    -- upvalues: u3 (ref), Color3_fromRGB_ret6 (copy)
    if not (u3 and u3.Parent) then
        return;
    end;

    u3.Text = p6;
    u3.TextColor3 = p7 or Color3_fromRGB_ret6;
end;

local function buildGui() -- Line: 57
    -- upvalues: u2 (ref), Color3_fromRGB_ret2 (copy), Color3_fromRGB_ret (copy), u3 (ref), Color3_fromRGB_ret6 (copy), Color3_fromRGB_ret3 (copy), u1 (copy), Color3_fromRGB_ret4 (copy), Color3_fromRGB_ret7 (copy), Color3_fromRGB_ret5 (copy), ClothesData (copy), LocalPlayer (copy)
    if u2 then
        u2:Destroy();
    end;

    u2 = Instance.new("ScreenGui");
    u2.Name = "MagicCreationPicker";
    u2.ResetOnSpawn = false;
    u2.DisplayOrder = 60;
    local Frame = Instance.new("Frame");
    Frame.Name = "Main";
    Frame.Size = UDim2.new(0, 250, 0, 430);
    Frame.AnchorPoint = Vector2.new(1, 0.5);
    Frame.Position = UDim2.new(0.99, 0, 0.5, 0);
    Frame.BackgroundColor3 = Color3_fromRGB_ret2;
    Frame.BorderSizePixel = 0;
    Frame.Parent = u2;
    local UICorner = Instance.new("UICorner");
    UICorner.CornerRadius = UDim.new(0, 12);
    UICorner.Parent = Frame;
    local UIStroke = Instance.new("UIStroke");
    UIStroke.Color = Color3_fromRGB_ret;
    UIStroke.Transparency = 0.5;
    UIStroke.Parent = Frame;
    local TextLabel = Instance.new("TextLabel");
    TextLabel.Size = UDim2.new(1, -20, 0, 26);
    TextLabel.Position = UDim2.new(0, 10, 0, 8);
    TextLabel.BackgroundTransparency = 1;
    TextLabel.Text = "Magic Creation";
    TextLabel.TextColor3 = Color3_fromRGB_ret;
    TextLabel.TextScaled = true;
    TextLabel.Font = Enum.Font.GothamBold;
    TextLabel.Parent = Frame;
    local UITextSizeConstraint = Instance.new("UITextSizeConstraint");
    UITextSizeConstraint.MaxTextSize = 18;
    UITextSizeConstraint.Parent = TextLabel;
    u3 = Instance.new("TextLabel");
    u3.Size = UDim2.new(1, -20, 0, 16);
    u3.Position = UDim2.new(0, 10, 0, 34);
    u3.BackgroundTransparency = 1;
    u3.Text = "Pick a fit, then use the skill";
    u3.TextColor3 = Color3_fromRGB_ret6;
    u3.TextScaled = true;
    u3.Font = Enum.Font.Gotham;
    u3.Parent = Frame;
    local UITextSizeConstraint2 = Instance.new("UITextSizeConstraint");
    UITextSizeConstraint2.MaxTextSize = 12;
    UITextSizeConstraint2.Parent = u3;
    local ScrollingFrame = Instance.new("ScrollingFrame");
    ScrollingFrame.Name = "FitList";
    ScrollingFrame.Size = UDim2.new(1, -20, 1, -190);
    ScrollingFrame.Position = UDim2.new(0, 10, 0, 56);
    ScrollingFrame.BackgroundColor3 = Color3_fromRGB_ret3;
    ScrollingFrame.BorderSizePixel = 0;
    ScrollingFrame.ScrollBarThickness = 4;
    ScrollingFrame.AutomaticCanvasSize = Enum.AutomaticSize.Y;
    ScrollingFrame.CanvasSize = UDim2.new();
    ScrollingFrame.Parent = Frame;
    local UICorner2 = Instance.new("UICorner");
    UICorner2.CornerRadius = UDim.new(0, 8);
    UICorner2.Parent = ScrollingFrame;
    local UIListLayout = Instance.new("UIListLayout");
    UIListLayout.Padding = UDim.new(0, 4);
    UIListLayout.SortOrder = Enum.SortOrder.Name;
    UIListLayout.Parent = ScrollingFrame;
    local UIPadding = Instance.new("UIPadding");
    UIPadding.PaddingTop = UDim.new(0, 6);
    UIPadding.PaddingLeft = UDim.new(0, 6);
    UIPadding.PaddingRight = UDim.new(0, 6);
    UIPadding.Parent = ScrollingFrame;
    local u8 = {};

    local function refreshFitColors() -- Line: 128
        -- upvalues: u8 (copy), u1 (ref), Color3_fromRGB_ret (ref), Color3_fromRGB_ret4 (ref), Color3_fromRGB_ret7 (ref), Color3_fromRGB_ret5 (ref)
        for i, v in pairs(u8) do
            local v9 = i == u1.Clothes;
            v.BackgroundColor3 = v9 and Color3_fromRGB_ret or Color3_fromRGB_ret4;
            v.TextColor3 = v9 and Color3_fromRGB_ret7 or Color3_fromRGB_ret5;
        end;
    end;

    for _, v in ipairs(ClothesData["Basic Clothes"]) do
        local TextButton = Instance.new("TextButton");
        TextButton.Name = v;
        TextButton.Size = UDim2.new(1, -8, 0, 26);
        TextButton.BackgroundColor3 = Color3_fromRGB_ret4;
        TextButton.BorderSizePixel = 0;
        TextButton.Text = v;
        TextButton.TextColor3 = Color3_fromRGB_ret5;
        TextButton.TextScaled = true;
        TextButton.Font = Enum.Font.Gotham;
        TextButton.Parent = ScrollingFrame;
        local UICorner3 = Instance.new("UICorner");
        UICorner3.CornerRadius = UDim.new(0, 6);
        UICorner3.Parent = TextButton;
        local UITextSizeConstraint3 = Instance.new("UITextSizeConstraint");
        UITextSizeConstraint3.MaxTextSize = 13;
        UITextSizeConstraint3.Parent = TextButton;
        u8[v] = TextButton;
        TextButton.MouseButton1Up:Connect(function() -- Line: 157
            -- upvalues: u1 (ref), v (copy), refreshFitColors (copy)
            u1.Clothes = v;
            refreshFitColors();
        end);
    end;

    refreshFitColors();

    for i, v in ipairs({ {
            key = "Cape",
            label = "Namekian Cape"
        }, {
            key = "Turban",
            label = "Namekian Turban"
        }, {
            key = "Self",
            label = "Cast on yourself"
        } }) do
        local TextButton = Instance.new("TextButton");
        TextButton.Name = "Toggle_" .. v.key;
        TextButton.Size = UDim2.new(1, -20, 0, 30);
        TextButton.Position = UDim2.new(0, 10, 1, -128 + (i - 1) * 36);
        TextButton.BackgroundColor3 = Color3_fromRGB_ret4;
        TextButton.BorderSizePixel = 0;
        TextButton.Text = "";
        TextButton.Parent = Frame;
        local UICorner3 = Instance.new("UICorner");
        UICorner3.CornerRadius = UDim.new(0, 8);
        UICorner3.Parent = TextButton;
        local Frame2 = Instance.new("Frame");
        Frame2.Size = UDim2.new(0, 18, 0, 18);
        Frame2.Position = UDim2.new(0, 8, 0.5, -9);
        Frame2.BackgroundColor3 = u1[v.key] and Color3_fromRGB_ret or Color3_fromRGB_ret2;
        Frame2.BorderSizePixel = 0;
        Frame2.Parent = TextButton;
        local UICorner4 = Instance.new("UICorner");
        UICorner4.CornerRadius = UDim.new(0, 5);
        UICorner4.Parent = Frame2;
        local TextLabel2 = Instance.new("TextLabel");
        TextLabel2.Size = UDim2.new(1, -40, 1, 0);
        TextLabel2.Position = UDim2.new(0, 34, 0, 0);
        TextLabel2.BackgroundTransparency = 1;
        TextLabel2.Text = v.label;
        TextLabel2.TextColor3 = Color3_fromRGB_ret5;
        TextLabel2.TextXAlignment = Enum.TextXAlignment.Left;
        TextLabel2.TextScaled = true;
        TextLabel2.Font = Enum.Font.Gotham;
        TextLabel2.Parent = TextButton;
        local UITextSizeConstraint3 = Instance.new("UITextSizeConstraint");
        UITextSizeConstraint3.MaxTextSize = 13;
        UITextSizeConstraint3.Parent = TextLabel2;
        TextButton.MouseButton1Up:Connect(function() -- Line: 203
            -- upvalues: u1 (ref), v (copy), Frame2 (copy), Color3_fromRGB_ret (ref), Color3_fromRGB_ret2 (ref)
            u1[v.key] = not u1[v.key];
            Frame2.BackgroundColor3 = u1[v.key] and Color3_fromRGB_ret or Color3_fromRGB_ret2;
        end);
    end;

    u2.Parent = LocalPlayer.PlayerGui;
end;

local u10 = false;
local u11 = nil;

local function destroyConfirm() -- Line: 225
    -- upvalues: u11 (ref)
    if u11 then
        u11:Destroy();
        u11 = nil;
    end;
end;

local function askConfirmation(p12) -- Line: 240
    -- upvalues: u11 (ref), Color3_fromRGB_ret2 (copy), Color3_fromRGB_ret (copy), Color3_fromRGB_ret5 (copy), Color3_fromRGB_ret4 (copy), Color3_fromRGB_ret7 (copy), LocalPlayer (copy)
    if u11 then
        u11:Destroy();
        u11 = nil;
    end;

    u11 = Instance.new("ScreenGui");
    u11.Name = "MagicCreationConfirm";
    u11.ResetOnSpawn = false;
    u11.DisplayOrder = 70;
    local TextButton = Instance.new("TextButton");
    TextButton.Size = UDim2.fromScale(1, 1);
    TextButton.BackgroundColor3 = Color3.new(0, 0, 0);
    TextButton.BackgroundTransparency = 0.45;
    TextButton.BorderSizePixel = 0;
    TextButton.Text = "";
    TextButton.AutoButtonColor = false;
    TextButton.Parent = u11;
    local Frame = Instance.new("Frame");
    Frame.Size = UDim2.new(0, 320, 0, 190);
    Frame.AnchorPoint = Vector2.new(0.5, 0.5);
    Frame.Position = UDim2.fromScale(0.5, 0.5);
    Frame.BackgroundColor3 = Color3_fromRGB_ret2;
    Frame.BorderSizePixel = 0;
    Frame.Parent = u11;
    local UICorner = Instance.new("UICorner");
    UICorner.CornerRadius = UDim.new(0, 12);
    UICorner.Parent = Frame;
    local UIStroke = Instance.new("UIStroke");
    UIStroke.Color = Color3_fromRGB_ret;
    UIStroke.Transparency = 0.4;
    UIStroke.Parent = Frame;
    local TextLabel = Instance.new("TextLabel");
    TextLabel.Size = UDim2.new(1, -24, 0, 26);
    TextLabel.Position = UDim2.new(0, 12, 0, 12);
    TextLabel.BackgroundTransparency = 1;
    TextLabel.Text = "Confirm Magic Creation";
    TextLabel.TextColor3 = Color3_fromRGB_ret;
    TextLabel.TextScaled = true;
    TextLabel.Font = Enum.Font.GothamBold;
    TextLabel.Parent = Frame;
    local UITextSizeConstraint = Instance.new("UITextSizeConstraint");
    UITextSizeConstraint.MaxTextSize = 18;
    UITextSizeConstraint.Parent = TextLabel;
    local TextLabel2 = Instance.new("TextLabel");
    TextLabel2.Size = UDim2.new(1, -24, 0, 86);
    TextLabel2.Position = UDim2.new(0, 12, 0, 44);
    TextLabel2.BackgroundTransparency = 1;
    TextLabel2.Text = p12;
    TextLabel2.TextColor3 = Color3_fromRGB_ret5;
    TextLabel2.TextWrapped = true;
    TextLabel2.TextYAlignment = Enum.TextYAlignment.Top;
    TextLabel2.TextXAlignment = Enum.TextXAlignment.Left;
    TextLabel2.Font = Enum.Font.Gotham;
    TextLabel2.TextSize = 14;
    TextLabel2.Parent = Frame;
    local u13 = nil;

    local function makeButton(p14, p15, p16, p17) -- Line: 300
        -- upvalues: Frame (copy)
        local TextButton2 = Instance.new("TextButton");
        TextButton2.Size = UDim2.new(0.44, 0, 0, 36);
        TextButton2.Position = UDim2.new(p15, 0, 1, -48);
        TextButton2.BackgroundColor3 = p16;
        TextButton2.BorderSizePixel = 0;
        TextButton2.Text = p14;
        TextButton2.TextColor3 = p17;
        TextButton2.TextScaled = true;
        TextButton2.Font = Enum.Font.GothamBold;
        TextButton2.Parent = Frame;
        local UICorner2 = Instance.new("UICorner");
        UICorner2.CornerRadius = UDim.new(0, 8);
        UICorner2.Parent = TextButton2;
        local UITextSizeConstraint2 = Instance.new("UITextSizeConstraint");
        UITextSizeConstraint2.MaxTextSize = 15;
        UITextSizeConstraint2.Parent = TextButton2;

        return TextButton2;
    end;

    local v18 = makeButton("Cancel", 0.04, Color3_fromRGB_ret4, Color3_fromRGB_ret5);
    local v19 = makeButton("Confirm", 0.52, Color3_fromRGB_ret, Color3_fromRGB_ret7);
    v18.MouseButton1Up:Connect(function() -- Line: 321
        -- upvalues: u13 (ref)
        u13 = false;
    end);
    v19.MouseButton1Up:Connect(function() -- Line: 322
        -- upvalues: u13 (ref)
        u13 = true;
    end);
    TextButton.MouseButton1Up:Connect(function() -- Line: 324
        -- upvalues: u13 (ref)
        u13 = false;
    end);
    u11.Parent = LocalPlayer.PlayerGui;
    local os_clock_ret = os.clock();

    while u13 == nil and os.clock() - os_clock_ret < 20 do
        if not (u11 and u11.Parent) then
            return false;
        end;

        task.wait(0.1);
    end;

    if u11 then
        u11:Destroy();
        u11 = nil;
    end;

    return u13 == true;
end;

local function buildSummary() -- Line: 342
    -- upvalues: u1 (copy)
    local v20 = u1.Self and "yourself" or "the player in front of you";
    local v21 = {};

    if u1.Cape then
        table.insert(v21, "Namekian Cape");
    end;

    if u1.Turban then
        table.insert(v21, "Namekian Turban");
    end;

    local v22 = "You are about to use Magic Creation on " .. v20 .. ", replacing their current outfit with \"" .. tostring(u1.Clothes) .. "\"";

    if #v21 > 0 then
        v22 = v22 .. " plus the " .. table.concat(v21, " and ");
    end;

    return v22 .. ".\n\nTheir existing clothing will be overwritten. Continue?";
end;

return {
    OnEquipped = function(p23, p24) -- Line: 364, Name: OnEquipped
        -- upvalues: buildGui (copy)
        buildGui();
    end,

    OnUnequipped = function(p25, p26) -- Line: 368, Name: OnUnequipped
        -- upvalues: u2 (ref), u3 (ref), u11 (ref)
        if u2 then
            u2:Destroy();
            u2 = nil;
            u3 = nil;
        end;

        if u11 then
            u11:Destroy();
            u11 = nil;
        end;
    end,

    OnActivated = function(p27, p28) -- Line: 378, Name: OnActivated
        -- upvalues: u1 (copy), u3 (ref), Color3_fromRGB_ret6 (copy), u10 (ref), askConfirmation (copy), buildSummary (copy), SkillData (copy), SkillRemote (copy)
        if not u1.Clothes then
            if u3 then
                u3.Text = "Pick a fit first!";
                u3.TextColor3 = Color3.fromRGB(235, 87, 87);
                task.delay(1.5, function() -- Line: 383
                    -- upvalues: u3 (ref), Color3_fromRGB_ret6 (ref)
                    if u3 then
                        u3.Text = "Pick a fit, then use the skill";
                        u3.TextColor3 = Color3_fromRGB_ret6;
                    end;
                end);
            end;

            return true, false;
        end;

        if u10 then
            return true, false;
        end;

        u10 = true;
        local v29 = askConfirmation((buildSummary()));
        u10 = false;

        if not v29 then
            if u3 and u3.Parent then
                u3.Text = "Magic Creation cancelled";
                u3.TextColor3 = Color3_fromRGB_ret6;
            end;

            task.delay(1.5, function() -- Line: 403
                -- upvalues: u3 (ref), Color3_fromRGB_ret6 (ref)
                if u3 then
                    if not u3.Parent then
                        return;
                    end;

                    u3.Text = "Pick a fit, then use the skill";
                    u3.TextColor3 = Color3_fromRGB_ret6;
                end;
            end);

            return true, false;
        end;

        local Any = SkillData.GetAny("Race Skills", "Magic Creation", "Namekian");
        local v30 = {
            Module = "SkillHandler",
            SkillModule = "Magic Creation",
            Action = "Charge",
            Attack_Name = "Magic Creation",
            Attack_Type = "Race Skills",
            Race_Type = "Namekian"
        };

        if Any then
            Any = Any.KiCost;
        end;

        v30.KiCost = Any;
        v30.ClothesSettings = {
            Clothes = u1.Clothes,
            Cape = u1.Cape,
            Turban = u1.Turban,
            Self = u1.Self
        };

        return true, SkillRemote:InvokeServer(v30);
    end
};