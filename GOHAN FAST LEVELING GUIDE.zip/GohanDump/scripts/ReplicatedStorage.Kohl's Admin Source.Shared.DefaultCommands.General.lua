-- Decompiled with Potassium's decompiler.

return {
    {
        name = "clean",
        description = "Cleans up miscellaneous admin objects like cloned characters, looped commands, and scripts.",
        aliases = { "clear", "clr" },
        args = {},

        run = function(p1) -- Line: 10, Name: run
            for _, v in p1._K.cleanupCommands do
                local v2 = typeof(v);

                if v2 == "Instance" then
                    v:Destroy();
                elseif v2 == "function" then
                    v();
                end;
            end;

            local disco = p1._K.Registry.commands.disco;

            if disco then
                task.spawn(disco.env.cleanup);
            end;

            p1._K.Remote.StartCountdown:FireAll();
        end
    },
    {
        name = "hint",
        description = "Sends a hint to everyone in the server.",
        aliases = { "h" },
        args = { {
                type = "string",
                name = "Message",
                description = "The message to send."
            } },

        envClient = function(u3) -- Line: 37, Name: envClient
            local u4 = nil;
            u3.Remote.Hint:Connect(function(p5: string, p6: number?) -- Line: 39
                -- upvalues: u4 (ref), u3 (copy)
                if u4 then
                    u4:Destroy();
                end;

                local v7 = u3.UI.new("TextLabel")({
                    Name = "Hint",
                    Parent = u3.UI.LayerTop,
                    AutoLocalize = false,
                    AutomaticSize = Enum.AutomaticSize.Y,
                    Size = UDim2.new(1, 0, 0, 0),
                    BackgroundColor3 = u3.UI.Theme.Primary,
                    BackgroundTransparency = u3.UI.Theme.Transparency,
                    FontFace = u3.UI.Theme.Font,
                    TextSize = u3.UI.Theme.FontSize,
                    TextColor3 = u3.UI.Theme.PrimaryText,
                    TextStrokeColor3 = u3.UI.Theme.Primary,
                    TextStrokeTransparency = u3.UI.Theme.TextStrokeTransparency,
                    Text = p5,
                    RichText = true,
                    u3.UI.new("UIPadding")({
                        PaddingTop = u3.UI.Theme.Padding,
                        PaddingBottom = u3.UI.Theme.Padding
                    })
                });
                u4 = v7;
                task.delay(p6 or #p5 * 0.0625 + 4, game.Destroy, v7);
            end);
        end,

        env = function(p8) -- Line: 68, Name: env
            return {
                remote = p8.Remote.Hint
            };
        end,

        run = function(p9: any, p10: string) -- Line: 71, Name: run
            p9.env.remote:FireAll((`<b>{p9.fromPlayer}:</b> {p10}`));
        end
    },
    {
        name = "privatehint",
        description = "Sends a private hint to one or more player(s).",
        aliases = { "phint", "ph" },
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) to hint."
            }, {
                type = "string",
                name = "Message",
                description = "The message to send."
            } },

        run = function(p11: any, p12: table, p13: string) -- Line: 91, Name: run
            for _, _ in p12 do
                p11._K.Remote.Hint:FireAll((`<b>{p11.fromPlayer}:</b> {p13}`));
            end;
        end
    },
    {
        name = "message",
        description = "Sends a message to everyone in the server.",
        aliases = { "m", "msg" },
        args = { {
                type = "string",
                name = "Message",
                description = "The message to send."
            } },

        env = function(p14) -- Line: 109, Name: env
            return {
                remote = p14.Remote.Announce
            };
        end,

        run = function(p15, p16) -- Line: 112, Name: run
            p15.env.remote:FireAll({
                From = p15.from,
                Text = p16
            });
        end
    },
    {
        name = "fullmessage",
        description = "Sends a full screen message to everyone in the server.",
        aliases = { "fm", "fmsg" },
        args = { {
                type = "string",
                name = "Message",
                description = "The message to send."
            } },

        envClient = function(u17) -- Line: 127, Name: envClient
            local u18 = nil;
            u17.Remote.FullScreenMessage:Connect(function(p19: number, p20: string, p21: number?) -- Line: 129
                -- upvalues: u18 (ref), u17 (copy)
                if u18 then
                    u18:Destroy();
                end;

                local v22 = u17.UI.new("TextLabel")({
                    Name = "Message",
                    Parent = u17.UI.LayerTop,
                    AutoLocalize = false,
                    AutomaticSize = Enum.AutomaticSize.Y,
                    Size = UDim2.new(1, 0, 1, 0),
                    BackgroundColor3 = u17.UI.Theme.Primary,
                    BackgroundTransparency = u17.UI.Theme.Transparency,
                    FontFace = u17.UI.Theme.Font,
                    TextSize = u17.UI.Theme.FontSizeDouble,
                    TextColor3 = u17.UI.Theme.PrimaryText,
                    TextStrokeColor3 = u17.UI.Theme.Primary,
                    TextStrokeTransparency = u17.UI.Theme.TextStrokeTransparency,
                    Text = p20,
                    TextWrapped = true,
                    RichText = true,
                    u17.UI.new("UIPadding")({
                        PaddingLeft = u17.UI.Theme.PaddingDouble,
                        PaddingRight = u17.UI.Theme.PaddingDouble
                    })
                });
                local v23 = u17.client.UserFrame(p19);
                v23.Icon.Image = `rbxthumb://type=AvatarHeadShot&id={p19}&w=150&h=150`;
                u17.UI.edit(v23, {
                    Parent = v22,
                    AnchorPoint = Vector2.new(0.5, 0),
                    Position = UDim2.new(0.5, 0, 0.05, 0),
                    u17.UI.new("UIScale")({
                        Scale = 2
                    })
                });
                local u24 = u17.UI.state(v23.From.From, "AbsoluteSize");
                u17.UI.edit(v23.From.Badge, {
                    Position = function() -- Line: 167, Name: Position
                        -- upvalues: u24 (copy)
                        return UDim2.fromOffset(u24().X / 2 + 4, 0);
                    end
                });
                u18 = v22;
                task.delay(p21 or #p20 * 0.0625 + 4, game.Destroy, v22);
            end);
        end,

        env = function(p25) -- Line: 175, Name: env
            return {
                remote = p25.Remote.FullScreenMessage
            };
        end,

        run = function(p26, p27) -- Line: 178, Name: run
            p26.env.remote:FireAll(p26.from, p27);
        end
    },
    {
        name = "notify",
        description = "Sends a notification to one or more player(s).",
        aliases = { "n" },
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) to notify."
            }, {
                type = "string",
                name = "Message",
                description = "The message to send."
            } },

        env = function(p28) -- Line: 198, Name: env
            return {
                remote = p28.Remote.Notify
            };
        end,

        run = function(p29, p30, p31) -- Line: 201, Name: run
            for _, v in p30 do
                p29.env.remote:Fire(v, {
                    From = p29.from,
                    Text = p31
                });
            end;
        end
    },
    {
        name = "privatemessage",
        description = "Sends a message to one or more player(s).",
        aliases = { "pm", "pmsg" },
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) to message."
            }, {
                type = "string",
                name = "Message",
                description = "The message to send."
            } },

        run = function(p32, p33, p34) -- Line: 224, Name: run
            for _, v in p33 do
                p32._K.Remote.Announce:Fire(v, {
                    From = p32.from,
                    Text = p34
                });
            end;
        end
    },
    {
        name = "countdown",
        description = "Starts a countdown.",
        aliases = { "cd" },
        args = { {
                type = "integer",
                name = "Duration",
                description = "The duration of the countdown, in seconds.",
                optional = true
            } },

        envClient = function(u35) -- Line: 242, Name: envClient
            local u36 = nil;
            local u37 = nil;
            u35.Remote.StartCountdown:Connect(function(u38, u39) -- Line: 244
                -- upvalues: u36 (ref), u37 (ref), u35 (copy)
                if u36 then
                    u36:Disconnect();
                end;

                if u37 then
                    u37:Destroy();
                end;

                if not u38 then
                    return;
                end;

                local u40 = u35.UI.new("TextLabel")({
                    Name = "Time",
                    AutoLocalize = false,
                    BackgroundTransparency = 1,
                    TextScaled = true,
                    TextStrokeTransparency = 0.5,
                    ZIndex = 2,
                    AnchorPoint = Vector2.new(0.5, 0.5),
                    Size = UDim2.new(1, 0, 1, 0),
                    Position = UDim2.new(0.5, 0, 0.5, 0),
                    FontFace = u35.UI.Theme.Font,
                    TextColor3 = u35.UI.Theme.SecondaryText,
                    TextStrokeColor3 = u35.UI.Theme.PrimaryText,
                    Text = u39
                });
                u37 = u35.UI.new("CircleProgress")({
                    Parent = u35.UI.LayerTopInset,
                    Image = "rbxassetid://123508079198656",
                    AnchorPoint = Vector2.new(0.5, 0),
                    Position = UDim2.new(0.5, 0),
                    Size = UDim2.new(0.125, 0, 0.125, 0),
                    SizeConstraint = Enum.SizeConstraint.RelativeYY,
                    ZIndex = -1,
                    u35.UI.new("UISizeConstraint")({
                        MaxSize = Vector2.new(128, 128)
                    }),
                    u40,
                    u35.UI.new("Frame")({
                        AnchorPoint = Vector2.new(0.5, 0.5),
                        BackgroundColor3 = u35.UI.Theme.Primary,
                        BackgroundTransparency = u35.UI.Theme.Transparency,
                        Position = UDim2.new(0.5, 0, 0.5, 0),

                        Size = function() -- Line: 290, Name: Size
                            -- upvalues: u35 (ref)
                            local v41 = u35.UI.Theme.Padding().Offset * 2;

                            return UDim2.new(1, v41, 1, v41);
                        end,

                        ZIndex = 0,
                        u35.UI.new("UICorner")({
                            CornerRadius = UDim.new(1, 0)
                        }),
                        u35.UI.new("Stroke")({})
                    })
                });
                u35.UI.Sound.Hover03:Play();
                u36 = u35.Service.Run.Heartbeat:Connect(function() -- Line: 306
                    -- upvalues: u38 (copy), u39 (copy), u36 (ref), u37 (ref), u35 (ref), u40 (copy)
                    local v42 = workspace:GetServerTimeNow() - u38;

                    if u39 < v42 then
                        u36:Disconnect();
                        u37:Destroy();
                        u35.UI.Sound.Notification_High:Play();

                        return;
                    end;

                    u37.Alpha(1 - math.clamp(v42 / u39, 0, 1));
                    local v43 = math.floor(u39 - v42) + 1;
                    local math_clamp_ret = math.clamp(v43, 0, u39);
                    local v44 = tostring(math_clamp_ret);

                    if v44 ~= u40.Text then
                        u35.UI.Sound.Hover03:Play();
                    end;

                    u40.Text = v44;
                end);
            end);
        end,

        env = function(p45) -- Line: 323, Name: env
            return {
                remote = p45.Remote.StartCountdown
            };
        end,

        run = function(p46, p47) -- Line: 327, Name: run
            if p47 then
                p46.env.remote:FireAll(workspace:GetServerTimeNow(), (math.min(p47, 3600)));

                return;
            end;

            p46.env.remote:FireAll();
        end
    },
    {
        name = "title",
        description = "Changes the title of one or more player(s).",
        aliases = { "tag", "untag", "untitle" },
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) whose title to change."
            }, {
                type = "string",
                name = "Title",
                description = "The title text to use.",
                optional = true
            }, {
                type = "color",
                name = "Color",
                description = "The title color to use.",
                optional = true
            }, {
                type = "color",
                name = "SecondaryColor",
                description = "The secondary title color to use.",
                optional = true
            }, {
                type = "Enum.Font",
                name = "Font",
                description = "The title font to use.",
                optional = true
            } },

        run = function(p48: any, p49: any, p50: string?, p51, p52, p53: any) -- Line: 371, Name: run
            for _, v in p49 do
                if p48.undo then
                    task.spawn(p48._K.VIP.Title, v);
                else
                    task.spawn(p48._K.VIP.Title, v, p50, p51, p52, p53);
                end;
            end;
        end
    },
    {
        name = "vote",
        description = "Starts a vote for one or more player(s).",
        aliases = { "makevote", "startvote", "poll" },
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) to poll."
            }, {
                type = "string",
                name = "Question",
                description = "The question to poll."
            } },

        env = function(p54) -- Line: 397, Name: env
            return {
                remote = p54.Remote.Vote
            };
        end,

        envClient = function(u55) -- Line: 400, Name: envClient
            function u55.Remote.Vote.OnInvoke(p56: string, p57: userdata) -- Line: 401
                -- upvalues: u55 (copy)
                local u58 = u55.Util.Signal.new();
                u55.Notify({
                    Text = p56,
                    ActionText = "<b>VOTE</b>",
                    Action = true,
                    ExitButton = false,
                    LeftAction = true,
                    RightAction = true,
                    Duration = 30,
                    UserFrame = { p57.UserId },
                    [u55.UI.Hook] = {
                        Action = function(p59) -- Line: 415, Name: Action
                            -- upvalues: u58 (copy)
                            u58:Fire(p59);
                        end
                    }
                });

                return u58:Wait() == true;
            end;
        end,

        run = function(u60, p61, u62) -- Line: 424, Name: run
            if u60.global then
                return;
            end;

            local u63 = 0;
            local u64 = 0;

            local function voteTask(p65) -- Line: 430
                -- upvalues: u60 (copy), u62 (copy), u63 (ref), u64 (ref)
                local v66 = u60.env.remote:Invoke(p65, u62, u60.fromPlayer);

                if v66 == true then
                    u63 = u63 + 1;

                    return;
                end;

                if v66 == false then
                    u64 = u64 + 1;
                end;
            end;

            local v67 = u60._K.Util.Tasks.new();

            for _, v in p61 do
                v67:add(voteTask, v);
            end;

            u60._K.Remote.Notify:Fire(u60.fromPlayer, {
                Text = `Created vote: <b>{u62}</b>\n\n<font transparency="0.5"><i>The vote will end in 30 seconds or when every player has submitted their vote!</i></font>`
            });
            task.delay(30, coroutine.resume, v67._running);
            v67:wait();
            v67._waiting = false;
            local v68 = u60._K.Data.settings.themeValid:ToHex();
            local v69 = u60._K.Data.settings.themeInvalid:ToHex();
            u60._K.Remote.Notify:Fire(u60.fromPlayer, {
                Text = `<font transparency="0.5">The results are in!</font>\n\n<b>{u62}</b>\n\t<font color="#{v68}"><b><sc>yes</sc></b>\t{u63}</font>\n\t<font color="#{v69}"><b><sc>no</sc></b> \t{u64}</font>`
            });
        end
    },
    {
        name = "link",
        description = "Links one or more player(s) to your character.",
        aliases = { "connect", "track" },
        credit = { "Kohl @Scripth", "Rie @Rietria" },
        args = { {
                type = "players",
                name = "Players",
                description = "The player(s) to link.",
                ignoreSelf = true
            }, {
                type = "boolean",
                name = "Persistent",
                description = "If the link persists through respawn.",
                optional = true
            } },

        envClient = function(u70) -- Line: 482, Name: envClient
            local LocalPlayer = u70.Service.Players.LocalPlayer;
            local u71 = {};
            local u72 = nil;

            local function characterAddedHandler(p73: userdata) -- Line: 486
                -- upvalues: u72 (ref), u70 (copy)
                task.defer(u72, u70.Service.Players:GetPlayerFromCharacter(p73));
            end;

            u72 = function(u74: userdata, p75: boolean?) -- Line: 490
                -- upvalues: u71 (copy), characterAddedHandler (copy), LocalPlayer (copy), u70 (copy)
                if p75 and not u71[u74] then
                    u71[u74] = u74.CharacterAdded:Connect(characterAddedHandler);
                end;

                local v76 = u74 and u74.Character and u74.Character:FindFirstChild("HumanoidRootPart");
                local u77 = LocalPlayer and LocalPlayer.Character and LocalPlayer.Character:FindFirstChild("HumanoidRootPart");
                local u78;

                if v76 then
                    u78 = v76:FindFirstChildOfClass("Attachment");
                else
                    u78 = v76;
                end;

                if u77 then
                    u77 = u77:FindFirstChildOfClass("Attachment");
                end;

                if u78 and u77 then
                    local _KLink = v76:FindFirstChild("_KLink");

                    if _KLink then
                        _KLink:Destroy();
                    end;

                    local BillboardGui = Instance.new("BillboardGui");
                    BillboardGui.Name = "_KLink";
                    BillboardGui.LightInfluence = 0;
                    BillboardGui.AlwaysOnTop = true;
                    BillboardGui.Size = u74.DisplayName == u74.Name and UDim2.fromOffset(250, 35) or UDim2.fromOffset(250, 50);
                    BillboardGui.SizeOffset = Vector2.new(0, 0.5);
                    BillboardGui.StudsOffsetWorldSpace = Vector3.new(0, 5, 0);
                    local Beam = Instance.new("Beam");
                    Beam.Color = ColorSequence.new(u74.TeamColor.Color);
                    Beam.Brightness = 2;
                    Beam.FaceCamera = true;
                    Beam.Segments = 1;
                    Beam.Transparency = NumberSequence.new(0);
                    Beam.Width0 = 0.2;
                    Beam.Width1 = 0.2;
                    Beam.Attachment0 = u78;
                    Beam.Attachment1 = u77;
                    Beam.Parent = BillboardGui;
                    local TextLabel = Instance.new("TextLabel");
                    TextLabel.TextColor3 = u74.TeamColor.Color;
                    TextLabel.BackgroundTransparency = 1;
                    TextLabel.Font = Enum.Font.RobotoMono;
                    TextLabel.RichText = true;
                    TextLabel.TextScaled = true;
                    TextLabel.Size = UDim2.fromScale(1, 1);
                    TextLabel.Text = u74.DisplayName == u74.Name and `@{u74.Name}` or `{u74.DisplayName}\n@{u74.Name}`;
                    TextLabel.Parent = BillboardGui;
                    BillboardGui.Parent = v76;
                    local u79 = { BillboardGui, u74:GetPropertyChangedSignal("TeamColor"):Connect(function() -- Line: 543
                            -- upvalues: Beam (copy), u74 (copy), TextLabel (copy)
                            Beam.Color = ColorSequence.new(u74.TeamColor.Color);
                            TextLabel.TextColor3 = u74.TeamColor.Color;
                        end) };

                    local function cleanLink() -- Line: 549
                        -- upvalues: u70 (ref), u79 (copy)
                        u70.Flux.cleanup(u79);
                    end;

                    BillboardGui.Destroying:Once(cleanLink);
                    LocalPlayer.CharacterRemoving:Once(cleanLink);
                    task.spawn(function() -- Line: 556
                        -- upvalues: TextLabel (copy), BillboardGui (ref), u77 (copy), u78 (copy)
                        local Text = TextLabel.Text;

                        while BillboardGui and BillboardGui.Parent do
                            local success, result = pcall(function() -- Line: 559
                                -- upvalues: u77 (ref), u78 (ref)
                                return (u77.WorldPosition - u78.WorldPosition).Magnitude;
                            end);

                            if not success then
                                break;
                            end;

                            TextLabel.Text = `{Text}\n[{math.round(result)}]`;
                            task.wait(0.1);
                        end;
                    end);
                end;
            end;

            LocalPlayer.CharacterAdded:Connect(function() -- Line: 572
                -- upvalues: u71 (copy), u72 (ref)
                for i in u71 do
                    task.defer(u72, i);
                end;
            end);

            return {
                persist = u71,
                link = u72
            };
        end,

        runClient = function(p80, p81, p82) -- Line: 584, Name: runClient
            for _, v in p81 do
                p80.env.link(v, p82);
            end;
        end
    },
    {
        name = "unlink",
        description = "Removes a link from one or more player(s).",
        aliases = { "unconnect", "untrack" },
        args = { {
                type = "players",
                name = "Players",
                description = "The player(s) to unlink.",
                ignoreSelf = true
            } },

        runClient = function(p83, p84) -- Line: 603, Name: runClient
            for _, v in p84 do
                local v85 = p83._K.Registry.commands.link.env.persist[v];

                if v85 then
                    v85:Disconnect();
                    p83._K.Registry.commands.link.env.persist[v] = nil;
                end;

                local v86 = v.Character and v.Character:FindFirstChild("HumanoidRootPart");

                if v86 then
                    v86 = v86:FindFirstChild("_KLink");
                end;

                if v86 then
                    v86:Destroy();
                end;
            end;
        end
    },
    {
        name = "watch",
        description = "Watches a player with your camera.",
        aliases = { "camera", "follow" },
        args = { {
                type = "player",
                name = "Player",
                description = "The player to watch."
            } },

        runClient = function(p87, p88) -- Line: 630, Name: runClient
            if p88.Character and p88.Character:FindFirstChildOfClass("Humanoid") then
                workspace.CurrentCamera.CameraSubject = p88.Character:FindFirstChildOfClass("Humanoid");
            end;
        end
    },
    {
        name = "spectate",
        description = "Spectate a player\'s camera view.",
        aliases = { "spy", "view" },
        args = { {
                type = "player",
                name = "Player",
                description = "The player to spectate.",
                ignoreSelf = true
            } },

        envClient = function(u89) -- Line: 649, Name: envClient
            local u90 = {
                currentSubject = nil,
                spectateConnection = nil,
                subjectFocus = nil,
                subjectDistance = nil,
                watched = nil
            };
            u89.Remote.Spectate:Connect(function(p91, p92: number) -- Line: 658
                -- upvalues: u90 (copy)
                if u90.currentSubject then
                    u90.subjectFocus = p91;
                    u90.subjectDistance = p92;
                end;
            end);
            u89.Remote.SpectateSubject:Connect(function(p93: boolean) -- Line: 665
                -- upvalues: u90 (copy)
                u90.watched = p93;
            end);
            u89.Service.Players.PlayerRemoving:Connect(function(p94: userdata) -- Line: 669
                -- upvalues: u90 (copy), u89 (copy)
                if p94 == u90.currentSubject then
                    u89.Registry.commands.unspectate.env.unspectate();
                end;
            end);

            local function getSubjectCFrame(p95: userdata) -- Line: 680
                if p95 and p95:IsA("Humanoid") then
                    local v96 = p95:GetState() == Enum.HumanoidStateType.Dead;
                    local CameraOffset = p95.CameraOffset;
                    local RootPart = p95.RootPart;

                    if v96 and (p95.Parent and p95.Parent:IsA("Model")) then
                        RootPart = p95.Parent:FindFirstChild("Head") or RootPart;
                    end;

                    if RootPart and RootPart:IsA("BasePart") then
                        local v97;

                        if p95.RigType == Enum.HumanoidRigType.R15 then
                            if p95.AutomaticScalingEnabled then
                                v97 = Vector3.new(0, 1.5, 0);
                                local RootPart2 = p95.RootPart;

                                if RootPart == RootPart2 then
                                    v97 = v97 + Vector3.new(0, (RootPart2.Size.Y - 2) / 2, 0);
                                end;
                            else
                                v97 = Vector3.new(0, 2, 0);
                            end;
                        else
                            v97 = Vector3.new(0, 1.5, 0);
                        end;

                        return RootPart.CFrame * CFrame.new((v96 and Vector3.new(0, 0, 0) or v97) + CameraOffset);
                    end;
                end;
            end;

            u89.Service.Run.PreRender:Connect(function(p98) -- Line: 722
                -- upvalues: u90 (copy), u89 (copy), getSubjectCFrame (copy)
                if u90.watched then
                    u89.Remote.SpectateSubject:Fire(workspace.CurrentCamera.CFrame.Rotation + workspace.CurrentCamera.Focus.Position, (workspace.CurrentCamera.Focus.Position - workspace.CurrentCamera.CFrame.Position).Magnitude);
                end;

                if u90.currentSubject and u90.subjectFocus then
                    local v99 = getSubjectCFrame(workspace.CurrentCamera.CameraSubject);
                    local v100;

                    if v99 then
                        v100 = u90.subjectFocus.Rotation + v99.Position;
                    else
                        v100 = u90.subjectFocus;
                    end;

                    workspace.CurrentCamera.CFrame = v100 * CFrame.new(0, 0, u90.subjectDistance);
                end;
            end);

            return u90;
        end,

        env = function(u101) -- Line: 740, Name: env
            local u102 = {};
            local Spectate = u101.Remote.Spectate;
            u101.Remote.SpectateSubject:Connect(function(p103: userdata, p104, p105: number) -- Line: 743
                -- upvalues: u102 (copy), Spectate (copy)
                if not (u102[p103] and (typeof(p104) == "CFrame" and typeof(p105) == "number")) then
                    return;
                end;

                for _, v in u102[p103] do
                    Spectate:Fire(v, p104, p105);
                end;
            end);

            local function spectateCleanup(p106) -- Line: 752
                -- upvalues: u102 (copy)
                local v107 = u102;

                for i, v in v107 do
                    local table_find_ret = table.find(v, p106.fromPlayer);

                    if table_find_ret then
                        table.remove(v, table_find_ret);

                        if #v == 0 then
                            v107[i] = nil;
                            p106._K.Remote.SpectateSubject:Fire(i);
                        end;
                    end;
                end;
            end;

            u101.Hook.roleRemoved:Connect(function(p108: number, p109: string) -- Line: 766
                -- upvalues: u101 (copy), spectateCleanup (copy)
                local PlayerByUserId = u101.Service.Players:GetPlayerByUserId(p108);

                if PlayerByUserId and not u101.Auth.hasCommand(p108, u101.Registry.commands.spectate) then
                    spectateCleanup({
                        _K = u101,
                        fromPlayer = PlayerByUserId
                    });
                end;
            end);
            u101.Service.Players.PlayerRemoving:Connect(function(p110: userdata) -- Line: 773
                -- upvalues: u102 (copy)
                if u102[p110] then
                    table.clear(u102[p110]);
                end;

                u102[p110] = nil;
            end);

            return {
                spectators = u102,
                spectateCleanup = spectateCleanup
            };
        end,

        runClient = function(p111, u112) -- Line: 786, Name: runClient
            p111.env.currentSubject = u112;

            if not workspace.CurrentCamera:GetAttribute("kCameraType") then
                workspace.CurrentCamera:SetAttribute("kCameraType", workspace.CurrentCamera.CameraType);
                workspace.CurrentCamera.CameraType = Enum.CameraType.Scriptable;
            end;

            local v113 = u112.Character and u112.Character:FindFirstChildOfClass("Humanoid");

            if v113 then
                workspace.CurrentCamera.CameraSubject = v113;
            end;

            if p111.env.spectateConnection then
                p111.env.spectateConnection:Disconnect();
            end;

            p111.env.spectateConnection = u112.CharacterAdded:Connect(function() -- Line: 799
                -- upvalues: u112 (copy)
                workspace.CurrentCamera.CameraSubject = u112.Character:FindFirstChildOfClass("Humanoid");
            end);
        end,

        run = function(p114, p115) -- Line: 803, Name: run
            p114.env.spectateCleanup(p114);

            if not p114.env.spectators[p115] then
                p114.env.spectators[p115] = {};
            end;

            p114._K.Remote.SpectateSubject:Fire(p115, true);
            table.insert(p114.env.spectators[p115], p114.fromPlayer);
        end
    },
    {
        name = "unspectate",
        description = "Stop spectating.",
        aliases = { "unspy", "unwatch", "uncamera", "unfollow", "unview" },
        args = {},

        envClient = function(u116) -- Line: 818, Name: envClient
            return {
                unspectate = function() -- Line: 820, Name: unspectate
                    -- upvalues: u116 (copy)
                    if workspace.CurrentCamera:GetAttribute("kCameraType") then
                        workspace.CurrentCamera.CameraType = workspace.CurrentCamera:GetAttribute("kCameraType");
                        workspace.CurrentCamera:SetAttribute("kCameraType", nil);
                    end;

                    local Character = u116.LocalPlayer.Character;

                    if Character then
                        workspace.CurrentCamera.CameraSubject = Character:FindFirstChildOfClass("Humanoid");
                    end;

                    local env = u116.Registry.commands.spectate.env;

                    if env.spectateConnection then
                        env.spectateConnection:Disconnect();
                        env.spectateConnection = nil;
                    end;

                    env.currentSubject = nil;
                    env.targetCFrame = nil;
                end
            };
        end,

        runClient = function(p117) -- Line: 841, Name: runClient
            p117.env.unspectate();
        end,

        run = function(p118) -- Line: 844, Name: run
            p118._K.Registry.commands.spectate.env.spectateCleanup(p118);
        end
    },
    {
        name = "fly",
        description = "Enables flight for one or more player(s).",
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) to give flight."
            }, {
                type = "number",
                name = "Speed",
                description = "The maximum flight speed, defaults to 128.",
                optional = true
            }, {
                type = "boolean",
                name = "Constant",
                description = "If true, flight speed is always set to maximum.",
                optional = true
            } },

        env = function(u119) -- Line: 870, Name: env
            u119.Hook.roleRemoved:Connect(function(p120: number, p121: string) -- Line: 871
                -- upvalues: u119 (copy)
                local PlayerByUserId = u119.Service.Players:GetPlayerByUserId(p120);

                if PlayerByUserId and not u119.Auth.hasCommand(p120, u119.Registry.commands.fly) then
                    PlayerByUserId:SetAttribute("_KFly", nil);
                    PlayerByUserId:SetAttribute("_KFlyConstant", nil);
                    PlayerByUserId:SetAttribute("_KNoClip", nil);
                end;
            end);
        end,

        run = function(p122, p123, p124, p125) -- Line: 880, Name: run
            for _, v in p123 do
                v:SetAttribute("_KFly", p124 or 128);
                v:SetAttribute("_KFlyConstant", p125 and true or nil);
                v:SetAttribute("_KNoClip", nil);
            end;
        end
    },
    {
        name = "unfly",
        description = "Disables flight for one or more player(s).",
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) to remove flight from."
            } },

        run = function(p126, p127) -- Line: 899, Name: run
            for _, v in p127 do
                v:SetAttribute("_KFly", nil);
                v:SetAttribute("_KFlyConstant", nil);
                v:SetAttribute("_KNoClip", nil);
            end;
        end
    },
    {
        name = "noclip",
        description = "Enables noclip for one or more player(s).",
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) to noclip."
            }, {
                type = "boolean",
                name = "Flight",
                description = "If flight should be enabled, defaults to enabled.",
                optional = true
            }, {
                type = "number",
                name = "Speed",
                description = "The maximum flight speed, defaults to 128.",
                optional = true
            } },

        run = function(p128: any, p129: any, p130: boolean?, p131: number?) -- Line: 929, Name: run
            for _, v in p129 do
                if not v:GetAttribute("_KDevCameraOcclusionMode") then
                    v:SetAttribute("_KDevCameraOcclusionMode", v.DevCameraOcclusionMode);
                    v.DevCameraOcclusionMode = Enum.DevCameraOcclusionMode.Invisicam;
                end;

                v:SetAttribute("_KFly", p130 ~= false and (p131 or 128) or nil);
                v:SetAttribute("_KNoClip", true);
            end;
        end
    },
    {
        name = "clip",
        description = "Disables noclip for one or more player(s).",
        aliases = { "unnoclip" },
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) to remove noclip from."
            } },

        run = function(p132, p133) -- Line: 952, Name: run
            for _, v in p133 do
                local Attribute = v:GetAttribute("_KDevCameraOcclusionMode");

                if Attribute then
                    v.DevCameraOcclusionMode = Attribute;
                    v:SetAttribute("_KDevCameraOcclusionMode", nil);
                end;

                v:SetAttribute("_KFly", nil);
                v:SetAttribute("_KNoClip", nil);
            end;
        end
    },
    {
        name = "notrip",
        description = "Prevents one or more player(s) from tripping.",
        aliases = { "unnotrip" },
        args = { {
                type = "players",
                name = "Player(s)",
                description = "The player(s) to prevent from tripping."
            } },

        envClient = function(u134) -- Line: 975, Name: envClient
            local u135 = nil;
            u134.Remote.Notrip:Connect(function(p136) -- Line: 977
                -- upvalues: u134 (copy), u135 (ref)
                local LocalPlayer = u134.Service.Players.LocalPlayer;
                local u137 = LocalPlayer.Character and LocalPlayer.Character:FindFirstChildOfClass("Humanoid");

                if u137 then
                    u137:SetStateEnabled(Enum.HumanoidStateType.FallingDown, not p136);
                    u137:SetStateEnabled(Enum.HumanoidStateType.Ragdoll, not p136);
                    u137:SetStateEnabled(Enum.HumanoidStateType.GettingUp, p136);

                    if u135 then
                        u135:Disconnect();
                    end;

                    u135 = u137.StateChanged:Connect(function(p138, p139) -- Line: 988
                        -- upvalues: u137 (copy)
                        if p139 == Enum.HumanoidStateType.FallingDown or p139 == Enum.HumanoidStateType.Ragdoll then
                            u137:ChangeState(Enum.HumanoidStateType.GettingUp);
                        end;
                    end);
                end;
            end);
        end,

        env = function(p140) -- Line: 1000, Name: env
            return {
                remote = p140.Remote.Notrip
            };
        end,

        run = function(p141: any, p142: table) -- Line: 1003, Name: run
            for _, v in p142 do
                p141.env.remote:Fire(v, not p141.undo);
            end;
        end
    },
    {
        name = "xray",
        description = "Show players through walls.",
        aliases = { "wallhack", "walls", "unxray", "unwallhack", "unwalls" },
        args = { {
                type = "color",
                name = "FillColor",
                description = "The fill color of the xray.",
                optional = true
            }, {
                type = "color",
                name = "OutlineColor",
                description = "The outline color of the xray.",
                optional = true
            } },

        envClient = function(u143) -- Line: 1027, Name: envClient
            local u144 = u143.Flux.state(false);
            local u145 = u143.Flux.new("Model")({
                Name = "_K_XRay"
            });
            local v146 = u143.Flux.new("Highlight")({
                Name = "_Kxray",
                Parent = u145,
                Enabled = u144,
                FillColor = Color3.new()
            });
            local u147 = {};

            local function cleanup(p148) -- Line: 1040
                -- upvalues: u143 (copy), u147 (copy)
                u143.Flux.cleanup(u147[p148]);
                u147[p148] = nil;
            end;

            local function xrayCharacter(u149: userdata) -- Line: 1045
                -- upvalues: u147 (copy), u144 (copy), u145 (copy)
                local Parent = u149.Parent;

                if not u147[u149] then
                    u147[u149] = {};
                end;

                if u144._value then
                    u149.Parent = u145;
                end;

                table.insert(u147[u149], u144:Connect(function(p150) -- Line: 1055
                    -- upvalues: u149 (copy), u145 (ref), Parent (ref)
                    local v151;

                    if p150 then
                        v151 = u145;
                    else
                        v151 = Parent;
                    end;

                    u149.Parent = v151;
                end));
                local v152 = u147[u149];
                local PropertyChangedSignal = u149:GetPropertyChangedSignal("Parent");
                table.insert(v152, PropertyChangedSignal:Connect(function() -- Line: 1061
                    -- upvalues: u149 (copy), u145 (ref), Parent (ref)
                    if u149.Parent ~= u145 then
                        Parent = u149.Parent;
                    end;
                end));
            end;

            local u153 = {};
            u143.Util.SafePlayerAdded(function(p154: userdata) -- Line: 1071, Name: xrayPlayer
                -- upvalues: u143 (copy), u153 (copy), xrayCharacter (copy), cleanup (copy)
                if p154 == u143.LocalPlayer then
                    return;
                end;

                local v155 = {};
                u153[p154] = v155;
                table.insert(v155, p154.CharacterAdded:Connect(xrayCharacter));
                table.insert(v155, p154.CharacterRemoving:Connect(cleanup));

                if p154.Character then
                    xrayCharacter(p154.Character);
                end;
            end);
            u143.Service.Players.PlayerRemoving:Connect(function(p156) -- Line: 1085
                -- upvalues: u153 (copy), u143 (copy)
                if u153[p156] then
                    u143.Flux.cleanup(u153[p156]);
                    u153[p156] = nil;
                end;
            end);

            return {
                xray = u144,
                xrayModel = u145,
                highlight = v146
            };
        end,

        runClient = function(p157: any, p158, p159) -- Line: 1099, Name: runClient
            p157.env.xray(not p157.undo);
            local v160;

            if p157.undo then
                v160 = nil;
            else
                v160 = workspace;
            end;

            p157.env.xrayModel.Parent = v160;
            p157.env.highlight.FillColor = p158 or Color3.new(0, 1, 1);
            p157.env.highlight.OutlineColor = p159 or Color3.new(1, 1, 1);
        end
    },
    {
        name = "whois",
        description = "Displays detailed information about a player.",
        group = "moderation",
        aliases = { "userinfo" },
        credit = { "Realistic @iiRealistic_Dev", "Kohl @Scripth" },
        args = { {
                type = "player",
                name = "Player",
                description = "The player to get information about.",
                shouldRequest = true
            } },

        run = function(p161: any, p162: userdata) -- Line: 1123, Name: run
            local v163 = p161._K.Remote.ShowFPS:Invoke(p162);
            local v164 = math.round(v163) or 0;
            local math_min_ret = math.min(999, v164);
            local v165 = p162:GetNetworkPing() * 1000;
            local math_ceil_ret = math.ceil(v165);
            local math_min_ret2 = math.min(9999, math_ceil_ret);
            local v166 = p162.Team and ("#" .. p162.Team.TeamColor.Color:ToHex() or "#16a085") or "#16a085";
            local CountryRegionForPlayerAsync = p161._K.Service.LocalizationService:GetCountryRegionForPlayerAsync(p162);
            local Attribute = p162:GetAttribute("_KPlatform");
            local v167 = {
                `<b>Account Age:</b> {p161._K.Util.Time.readable(p162.AccountAge * 86400) or "?"}`,
                `<b>FPS:</b> {math_min_ret}   <b>Ping:</b> {math_min_ret2} ms   <b>Locale:</b> {p161._K.Util.String.toFlag(CountryRegionForPlayerAsync)} {CountryRegionForPlayerAsync}`,
                `<b>Muted:</b> {p161._K.Data.muted[p162.UserId] and "✅" or "❌"}\t<b>Verified:</b> {p162:IsVerified() and "✅" or "❌"}`,
                `<b>Platform:</b> {({
                    Console = "🎮",
                    Mobile = "📱",
                    PC = "🖥️",
                    VR = "🥽"
                })[Attribute]} {Attribute}`,
                `<b>Session:</b> {p161._K.Util.Time.readable(workspace:GetServerTimeNow() - p162:GetAttribute("_KSessionStart"))}`,
                `<b>Team:</b> <font color="{v166}">{p162.Team and (p162.Team.Name or "None") or "None"}</font>`,
                (`<b>UserId:</b> {p162.UserId}`)
            };

            if (p162:GetAttribute("_KIdleTime") or 0) > 0 then
                local v168 = `<b>Idle Time:</b> {p162:GetAttribute("_KIdleTime")}`;
                table.insert(v167, v168);
            end;

            if p162.FollowUserId > 0 then
                local UserInfo = p161._K.Util.getUserInfo(p162.FollowUserId);
                local v169 = `<b>Joined:</b>{UserInfo.DisplayName == UserInfo.Username and "" or " " .. UserInfo.DisplayName} @{UserInfo.Username}`;
                table.insert(v167, v169);
            end;

            local v170 = {};

            for _, v in p161._K.Service.Players:GetPlayers() do
                if v.FollowUserId == p162.UserId then
                    local v171 = `{v.DisplayName == v.Name and "" or v.DisplayName .. " "}@{v.Name}`;
                    table.insert(v170, v171);
                end;
            end;

            if #v170 > 0 then
                local v172 = `<b>Joined them:</b> {table.concat(v170, ", ")}`;
                table.insert(v167, v172);
            end;

            table.sort(v167);
            p161._K.Remote.Notify:Fire(p161.fromPlayer, {
                Text = table.concat(v167, "\n"),
                From = p162.UserId
            });
        end
    },
    {
        name = "grouprank",
        description = "Gets a player\'s rank and role in a group.",
        aliases = { "grouprole" },
        args = { {
                type = "player",
                name = "Player",
                description = "The player to check."
            }, {
                type = "integer",
                name = "GroupId",
                description = "The group to check against."
            } },

        runClient = function(p173: any, p174: userdata, p175: number) -- Line: 1195, Name: runClient
            p173._K.Notify({
                From = p174.UserId,
                Text = `<b>Group Rank:</b> [{p174:GetRankInGroupAsync(p175)}] {p174:GetRoleInGroupAsync(p175)}`
            });
        end
    },
    {
        name = "playercount",
        description = "Counts the number of players in-game.",
        aliases = { "plrcount", "countplayers", "countplrs" },

        runClient = function(p176) -- Line: 1206, Name: runClient
            p176._K.Notify({
                Text = `<b>Player Count:</b> {#p176._K.Service.Players:GetPlayers()}`
            });
        end
    },
    {
        name = "tts",
        description = "Plays text to speech audio.",
        aliases = { "speak" },
        args = { {
                type = "voiceId",
                name = "Voice",
                description = "The voice to speak in.",
                optional = true
            }, {
                type = "string",
                name = "Text",
                description = "The text to speak."
            } },

        envClient = function(p177) -- Line: 1231, Name: envClient
            p177.Registry.registerType("voiceId", p177.Registry.makeEnumType(
                "voiceId",
                { "British male", "British female", "US male", "US female", "US male #2", "US female #2", "Australian male", "Australian female", "Retro #1", "Retro #2" }
            ));
        end,

        env = function(p178) -- Line: 1246, Name: env
            local v179 = { "British male", "British female", "US male", "US female", "US male #2", "US female #2", "Australian male", "Australian female", "Retro #1", "Retro #2" };
            p178.Registry.registerType("voiceId", p178.Registry.makeEnumType("voiceId", v179));

            return {
                playing = nil,
                voiceIds = v179
            };
        end,

        run = function(p180: any, p181: string?, p182: string) -- Line: 1266, Name: run
            local table_find_ret = table.find(p180.env.voiceIds, p181 or "British male");
            local AudioTextToSpeech = Instance.new("AudioTextToSpeech");
            AudioTextToSpeech.Parent = workspace;
            AudioTextToSpeech.Text = p182;
            AudioTextToSpeech.VoiceId = tostring(table_find_ret);
            local AudioDeviceOutput = Instance.new("AudioDeviceOutput");
            AudioDeviceOutput.Parent = workspace;
            local Wire = Instance.new("Wire");
            Wire.Parent = workspace;
            Wire.SourceInstance = AudioTextToSpeech;
            Wire.TargetInstance = AudioDeviceOutput;

            local function v183() -- Line: 1283
                -- upvalues: AudioTextToSpeech (copy), AudioDeviceOutput (copy), Wire (copy)
                AudioTextToSpeech:Unload();
                AudioTextToSpeech:Destroy();
                AudioDeviceOutput:Destroy();
                Wire:Destroy();
            end;

            if AudioTextToSpeech:LoadAsync() ~= Enum.AssetFetchStatus.Success then
                AudioTextToSpeech:Unload();
                AudioTextToSpeech:Destroy();
                AudioDeviceOutput:Destroy();
                Wire:Destroy();

                return "Failed to load sound";
            end;

            AudioTextToSpeech.Ended:Once(v183);
            AudioTextToSpeech:Play();
        end
    },
    {
        name = "play",
        description = "Plays a sound.",
        aliases = { "music", "sound", "audio" },
        args = { {
                type = "integer",
                name = "AssetId",
                description = "The asset identifier of the sound."
            } },

        env = function(p184) -- Line: 1313, Name: env
            return {
                playing = nil
            };
        end,

        run = function(p185, p186) -- Line: 1316, Name: run
            if p185.env.playing then
                p185.env.playing:Stop();
                p185.env.playing:Destroy();
            end;

            local Sound = Instance.new("Sound");
            p185.env.playing = Sound;
            Sound.Name = "_KPlaySound";
            Sound.SoundId = "rbxassetid://" .. p186;
            Sound.Looped = true;
            Sound.Parent = workspace;
            Sound:Play();
        end
    },
    {
        name = "pause",
        description = "Pauses the current sound.",
        aliases = {},
        args = {},

        run = function(p187) -- Line: 1337, Name: run
            local playing = p187._K.Registry.commands.play.env.playing;

            if playing then
                playing:Pause();
            end;
        end
    },
    {
        name = "resume",
        description = "Resumes the current sound.",
        aliases = {},
        args = {},

        run = function(p188) -- Line: 1350, Name: run
            local playing = p188._K.Registry.commands.play.env.playing;

            if playing then
                playing:Resume();
            end;
        end
    },
    {
        name = "stop",
        description = "Stops the currently playing sound.",
        aliases = { "stopmusic" },
        args = {},

        run = function(p189) -- Line: 1363, Name: run
            local playing = p189._K.Registry.commands.play.env.playing;

            if playing then
                playing:Stop();
                playing:Destroy();
            end;
        end
    },
    {
        name = "pitch",
        description = "Changes the pitch of the currently playing sound.",
        aliases = {},
        args = { {
                type = "number",
                name = "Value",
                description = "The pitch value."
            } },

        run = function(p190, p191) -- Line: 1383, Name: run
            local playing = p190._K.Registry.commands.play.env.playing;

            if playing then
                playing.Pitch = p191;
            end;
        end
    },
    {
        name = "volume",
        description = "Changes the volume of the currently playing sound.",
        aliases = {},
        args = { {
                type = "number",
                name = "Value",
                description = "The volume value."
            } },

        run = function(p192, p193) -- Line: 1402, Name: run
            local playing = p192._K.Registry.commands.play.env.playing;

            if playing then
                playing.Volume = p193;
            end;
        end
    }
};