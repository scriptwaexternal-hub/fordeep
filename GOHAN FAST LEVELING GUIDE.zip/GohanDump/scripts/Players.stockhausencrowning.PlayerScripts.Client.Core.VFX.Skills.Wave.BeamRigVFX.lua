-- Decompiled with Potassium's decompiler.

local Debris = game:GetService("Debris");
local ReplicatedStorage = game:GetService("ReplicatedStorage");
local RunService = game:GetService("RunService");
local Modules = ReplicatedStorage:WaitForChild("Modules");
local SoundManager = require(Modules.Shared.SoundManager);
local GlobalFunctions = require(Modules.GlobalFunctions);
local Visuals = workspace.World.Visuals;
local Wave = ReplicatedStorage.Assets.Effects.Skills.Wave;
local Meshes = ReplicatedStorage.Assets.Effects.Meshes;

local function multNumberSequence(p1, p2) -- Line: 33
    local v3 = {};

    for _, v in ipairs(p1.Keypoints) do
        table.insert(v3, NumberSequenceKeypoint.new(v.Time, v.Value * p2, v.Envelope * p2));
    end;

    return NumberSequence.new(v3);
end;

local function shiftColor(p4, p5) -- Line: 42
    local v6, v7, v8 = p4:ToHSV();

    if v7 < 0.05 then
        return p4;
    end;

    return Color3.fromHSV((v6 + p5) % 1, v7, v8);
end;

local function shiftColorSequence(p9, p10) -- Line: 48
    -- upvalues: shiftColor (copy)
    local v11 = {};

    for _, v in ipairs(p9.Keypoints) do
        table.insert(v11, ColorSequenceKeypoint.new(v.Time, shiftColor(v.Value, p10)));
    end;

    return ColorSequence.new(v11);
end;

local function isEffect(p12) -- Line: 56
    return p12:IsA("ParticleEmitter") or p12:IsA("Beam") or (p12:IsA("Trail") or p12:IsA("PointLight") or (p12:IsA("SpotLight") or p12:IsA("SurfaceLight")));
end;

local u28 = {
    Active = {},

    SetPhase = function(p13, p14, p15) -- Line: 72, Name: SetPhase
        -- upvalues: isEffect (copy)
        for _, descendant in ipairs(p13:GetDescendants()) do
            if isEffect(descendant) and (descendant:GetAttribute("FXPhase") or "Fire") == p14 then
                descendant.Enabled = p15;
            end;
        end;
    end,

    Recolor = function(p16, p17) -- Line: 81, Name: Recolor
        -- upvalues: shiftColorSequence (copy)
        local Attribute = p16:GetAttribute("BaseColor");

        if not (Attribute and p17) then
            return;
        end;

        local v18, v19 = Attribute:ToHSV();
        local v20 = p17:ToHSV();

        if v19 < 0.05 then
            return;
        end;

        local v21 = v20 - v18;

        if math.abs(v21) < 0.01 then
            return;
        end;

        for _, descendant in ipairs(p16:GetDescendants()) do
            if not descendant:GetAttribute("KeepColor") then
                if descendant:IsA("Beam") or (descendant:IsA("Trail") or descendant:IsA("ParticleEmitter")) then
                    descendant.Color = shiftColorSequence(descendant.Color, v21);
                elseif descendant:IsA("BasePart") then
                    local Color = descendant.Color;
                    local v22, v23, v24 = Color:ToHSV();

                    if v23 >= 0.05 then
                        Color = Color3.fromHSV((v22 + v21) % 1, v23, v24);
                    end;

                    descendant.Color = Color;
                elseif descendant:IsA("PointLight") or (descendant:IsA("SpotLight") or descendant:IsA("SurfaceLight")) then
                    local Color = descendant.Color;
                    local v25, v26, v27 = Color:ToHSV();

                    if v26 >= 0.05 then
                        Color = Color3.fromHSV((v25 + v21) % 1, v26, v27);
                    end;

                    descendant.Color = Color;
                end;
            end;
        end;
    end
};

function u28.Fire(p29) -- Line: 102
    -- upvalues: GlobalFunctions (copy), Wave (copy), multNumberSequence (copy), u28 (copy), Visuals (copy), SoundManager (copy), RunService (copy), isEffect (copy), Debris (copy), Meshes (copy)
    local Character = p29.Character;

    if not Character then
        return;
    end;

    local RootAndHumanoid = GlobalFunctions.GetRootAndHumanoid(Character);

    if not RootAndHumanoid then
        return;
    end;

    local v30 = p29.StartSize or 3;
    local u31 = p29.Length or 10;
    local u32 = p29.Speed or 5;
    local v33 = p29.Duration or 4;
    local v34 = p29.CloseDuration or 0.5;
    local Color = p29.Color;
    local v35 = p29.StartLocation or RootAndHumanoid.CFrame * CFrame.new(0, 0, -5);
    local v36 = p29.StartSoundName or "Death Beam";
    local Rig = p29.Rig;
    local v37 = Rig and Wave:FindFirstChild(Rig .. " Rig") or Wave:FindFirstChild("Beam Rig");

    if not v37 then
        return;
    end;

    local u38 = v37:Clone();
    local v39 = u38:FindFirstChild("Wave Start");
    local u40 = u38:FindFirstChild("Wave End");

    if not (v39 and u40) then
        u38:Destroy();

        return;
    end;

    local Magnitude = (u40.Position - v39.Position).Magnitude;

    if Magnitude < 0.01 then
        u38:Destroy();

        return;
    end;

    local CFrame_lookAt_ret = CFrame.lookAt(v39.Position, u40.Position);
    local u41 = v30 / 3;
    local v42 = math.abs(u41 - 1) > 0.01;
    local u43 = CFrame_lookAt_ret:ToObjectSpace(u40.CFrame);
    local u44 = {};
    local u45 = {};

    for _, descendant in ipairs(u38:GetDescendants()) do
        if descendant:IsA("BasePart") and descendant ~= u40 then
            local v46 = CFrame_lookAt_ret:ToObjectSpace(descendant.CFrame);
            local math_max_ret = math.max(descendant.Size.Y, descendant.Size.Z);

            if descendant.Size.X > math_max_ret * 2 then
                local v47 = {
                    Part = descendant,
                    LengthRatio = descendant.Size.X / Magnitude,
                    CenterRatio = -v46.Position.Z / Magnitude,
                    Lateral = Vector2.new(v46.Position.X, v46.Position.Y),
                    Rotation = v46 - v46.Position,
                    ThickY = descendant.Size.Y * u41,
                    ThickZ = descendant.Size.Z * u41
                };
                table.insert(u44, v47);
            else
                local v48 = {
                    Part = descendant,
                    Offset = v46,
                    TipAnchored = -v46.Position.Z > Magnitude * 0.5,
                    Lateral = Vector2.new(v46.Position.X, v46.Position.Y),
                    RelZ = v46.Position.Z + Magnitude,
                    Rotation = v46 - v46.Position
                };
                table.insert(u45, v48);

                if v42 then
                    descendant.Size = descendant.Size * u41;
                end;
            end;
        end;
    end;

    if v42 then
        for _, descendant in ipairs(u38:GetDescendants()) do
            if descendant:IsA("Beam") then
                descendant.Width0 = descendant.Width0 * u41;
                descendant.Width1 = descendant.Width1 * u41;
            elseif descendant:IsA("ParticleEmitter") then
                descendant.Size = multNumberSequence(descendant.Size, u41);
                descendant.Speed = NumberRange.new(descendant.Speed.Min * u41, descendant.Speed.Max * u41);
                descendant.Acceleration = descendant.Acceleration * u41;
            elseif descendant:IsA("Trail") then
                descendant.WidthScale = multNumberSequence(descendant.WidthScale, u41);
            elseif descendant:IsA("PointLight") or (descendant:IsA("SpotLight") or descendant:IsA("SurfaceLight")) then
                descendant.Range = descendant.Range * u41;
            elseif descendant:IsA("Attachment") then
                descendant.Position = descendant.Position * u41;
            end;
        end;
    end;

    if Color then
        u28.Recolor(u38, Color);
    end;

    local Position = v35.Position;
    local v49 = (p29.MousePosition or (p29.DefaultEndLocation or (v35 * CFrame.new(0, 0, -u31)).Position)) - Position;

    if v49.Magnitude < 0.01 then
        v49 = v35.LookVector;
    end;

    local Unit = v49.Unit;
    local v50 = Unit:Dot(Vector3.new(0, 1, 0));
    local v51 = math.abs(v50) > 0.99 and Vector3.new(0, 0, 1) or Vector3.new(0, 1, 0);
    local CFrame_lookAt_ret2 = CFrame.lookAt(Position, Position + Unit, v51);
    u38.Name = "BeamRig" .. Character.Name;

    for _, v in ipairs(u45) do
        v.Part.Anchored = true;

        if not v.TipAnchored then
            v.Part.CFrame = CFrame_lookAt_ret2 * v.Offset;
        end;
    end;

    u38.Parent = Visuals;
    SoundManager.AddSound(v36, {
        Parent = v39
    }, "Client", {
        Duration = 2
    });
    local os_clock_ret = os.clock();
    local u52 = false;
    local u53 = 0;
    local u54 = v34;
    local u55 = nil;
    local u56 = {
        HoldOpen = false,
        ClashDist = nil,
        Character = Character,
        Color = Color,
        StartSize = v30,
        StartPos = Position,
        Dir = Unit,
        Length = u31
    };
    u28.Active[Character] = u56;

    local function update() -- Line: 236
        -- upvalues: u38 (copy), u55 (ref), os_clock_ret (ref), u32 (copy), u31 (ref), u56 (copy), u52 (ref), u53 (ref), u54 (ref), u40 (copy), CFrame_lookAt_ret2 (copy), u43 (copy), u41 (copy), u45 (copy), u44 (copy)
        if not u38.Parent then
            if u55 then
                u55:Disconnect();
                u55 = nil;
            end;

            return;
        end;

        local v57 = (os.clock() - os_clock_ret) / u32;
        local v58 = math.min(v57, 1) * u31;
        local math_max_ret = math.max(v58, 0.5);

        if u56.ClashDist then
            math_max_ret = math.clamp(u56.ClashDist, 0.5, u31);
        end;

        local v59;

        if u52 then
            local v60 = (os.clock() - u53) / u54;
            v59 = 1 - math.clamp(v60, 0, 1);
        else
            v59 = 1;
        end;

        u40.CFrame = CFrame_lookAt_ret2 * CFrame.new(u43.Position.X * u41, u43.Position.Y * u41, -math_max_ret) * (u43 - u43.Position);

        for _, v in ipairs(u45) do
            if v.TipAnchored then
                v.Part.CFrame = CFrame_lookAt_ret2 * CFrame.new(v.Lateral.X * u41, v.Lateral.Y * u41, -math_max_ret + v.RelZ * u41) * v.Rotation;
            end;
        end;

        for _, v in ipairs(u44) do
            v.Part.Size = Vector3.new(math_max_ret * v.LengthRatio, v.ThickY * v59, v.ThickZ * v59);
            v.Part.CFrame = CFrame_lookAt_ret2 * CFrame.new(v.Lateral.X * u41, v.Lateral.Y * u41, -math_max_ret * v.CenterRatio) * v.Rotation;
        end;
    end;

    u55 = RunService.Heartbeat:Connect(update);
    update();
    u28.SetPhase(u38, "Fire", true);
    local u61 = false;

    local function closeBeam(p62) -- Line: 281
        -- upvalues: u61 (ref), u56 (copy), u52 (ref), u54 (ref), u53 (ref), u38 (copy), GlobalFunctions (ref), u45 (copy), isEffect (ref), u44 (copy), u55 (ref), u28 (ref), Character (copy), Debris (ref)
        if u61 then
            return;
        end;

        if u56.HoldOpen then
            u56.PendingClose = true;

            return;
        end;

        u61 = true;
        u52 = true;

        if p62 then
            u54 = p62;
        end;

        u53 = os.clock();
        local u63 = 0;

        for _, descendant in ipairs(u38:GetDescendants()) do
            if descendant:IsA("ParticleEmitter") then
                u63 = math.max(u63, descendant.Lifetime.Max);
                descendant.Enabled = false;
            elseif descendant:IsA("Trail") then
                descendant.Enabled = false;
            elseif descendant:IsA("Beam") then
                GlobalFunctions.Tween({
                    Instance = descendant,
                    Duration = u54
                }, {
                    Width0 = 0,
                    Width1 = 0
                });
            elseif descendant:IsA("PointLight") or (descendant:IsA("SpotLight") or descendant:IsA("SurfaceLight")) then
                GlobalFunctions.Tween({
                    Instance = descendant,
                    Duration = u54
                }, {
                    Brightness = 0
                });
            end;
        end;

        for _, v in ipairs(u45) do
            GlobalFunctions.Tween({
                Instance = v.Part,
                Duration = u54
            }, {
                Size = Vector3.new(0, 0, 0),
                Transparency = 1
            });
        end;

        task.delay(u54, function() -- Line: 318
            -- upvalues: u38 (ref), isEffect (ref), u44 (ref), u55 (ref), u28 (ref), Character (ref), u56 (ref), Debris (ref), u63 (ref)
            if not u38.Parent then
                return;
            end;

            for _, descendant in ipairs(u38:GetDescendants()) do
                if isEffect(descendant) then
                    descendant.Enabled = false;
                end;
            end;

            for _, v in ipairs(u44) do
                v.Part.Transparency = 1;
            end;

            if u55 then
                u55:Disconnect();
                u55 = nil;
            end;

            if u28.Active[Character] == u56 then
                u28.Active[Character] = nil;
            end;

            Debris:AddItem(u38, (math.min(u63, 3)));
        end);
    end;

    local u64 = 0;

    local function armClose(p65) -- Line: 339
        -- upvalues: u64 (ref), closeBeam (copy)
        local u66 = u64;
        task.delay(p65, function() -- Line: 341
            -- upvalues: u64 (ref), u66 (copy), closeBeam (ref)
            if u64 == u66 then
                closeBeam();
            end;
        end);
    end;

    function u56.SetClashPoint(p67: vector) -- Line: 345
        -- upvalues: u56 (copy), Position (copy), Unit (ref), closeBeam (copy)
        u56.HoldOpen = true;
        u56.ClashDist = (p67 - Position):Dot(Unit);

        if not u56.FailsafeArmed then
            u56.FailsafeArmed = true;
            task.delay(30, function() -- Line: 354
                -- upvalues: u56 (ref), closeBeam (ref)
                if u56.HoldOpen then
                    u56.HoldOpen = false;
                    closeBeam(0.3);
                end;
            end);
        end;
    end;

    function u56.Release(p68, p69) -- Line: 365
        -- upvalues: u56 (copy), u64 (ref), closeBeam (copy), u31 (ref), os_clock_ret (ref), u32 (copy)
        u56.HoldOpen = false;
        u64 = u64 + 1;

        if p68 == "collapse" then
            u56.ClashDist = nil;
            closeBeam(0.15);

            return;
        end;

        local math_clamp_ret = math.clamp(u56.ClashDist or u31, 0.5, u31);
        u56.ClashDist = nil;
        u31 = u31 * 2;
        u56.Length = u31;
        os_clock_ret = os.clock() - math_clamp_ret / u31 * u32;
        u56.PendingClose = nil;
        local v70 = math.max(u32 * (1 - math_clamp_ret / u31), 0) + 0.6 + (tonumber(p69) or 0);
        local u71 = u64;
        task.delay(v70, function() -- Line: 341
            -- upvalues: u64 (ref), u71 (copy), closeBeam (ref)
            if u64 == u71 then
                closeBeam();
            end;
        end);
    end;

    local u72 = u64;
    task.delay(u32 + v33, function() -- Line: 341
        -- upvalues: u64 (ref), u72 (copy), closeBeam (copy)
        if u64 == u72 then
            closeBeam();
        end;
    end);
    local u73 = p29.Rings and Meshes:FindFirstChild("Ring");

    if u73 then
        local u74 = p29.RingColor or Color3.fromRGB(255, 255, 255);
        local u75 = p29.RingAmt or 25;
        local u76 = p29.RingDelay or 0;
        local u77 = Vector3.new(1, 0.05, 1) * (1.1 + v30);
        local u78 = u32 + v33;
        task.spawn(function() -- Line: 402
            -- upvalues: u75 (copy), u61 (ref), u38 (copy), u73 (copy), u74 (copy), u77 (copy), CFrame_lookAt_ret2 (copy), u31 (ref), Visuals (ref), Debris (ref), u78 (copy), GlobalFunctions (ref), u76 (copy)
            for i = 0, u75 do
                if u61 or not u38.Parent then
                    break;
                end;

                local u79 = u73:Clone();
                u79.Anchored = true;
                u79.CanCollide = false;
                u79.CanQuery = false;
                u79.CanTouch = false;
                u79.Color = u74;
                u79.Size = u77;
                u79.CFrame = CFrame_lookAt_ret2 * CFrame.new(0, 0, -(i * u31 / u75)) * CFrame.Angles(1.5707963267948966, 0, 0);
                u79.Parent = Visuals;
                Debris:AddItem(u79, 5);
                task.delay(u78, function() -- Line: 417
                    -- upvalues: u79 (copy), GlobalFunctions (ref)
                    if not u79.Parent then
                        return;
                    end;

                    GlobalFunctions.Tween({
                        Duration = 0.6,
                        Instance = u79,
                        EasingStyle = Enum.EasingStyle.Exponential
                    }, {
                        Transparency = 1
                    });
                end);
                local v80;

                if u76 > 0 then
                    task.wait(u76);
                    v80 = i;
                else
                    v80 = i;
                end;
            end;
        end);
    end;
end;

return u28;