-- Decompiled with Potassium's decompiler.

local RunService = game:GetService("RunService");
local script_Parent = script.Parent;
local State = require(script_Parent.State);
local DataType = require(script_Parent.DataType);
local isState = State.isState;
local u1 = {};
setmetatable(u1, {
    __mode = "_k"
});

local function springCoefficients(p2: number, p3: number, p4: number) -- Line: 41
    if p2 == 0 or p4 == 0 then
        return 1, 0, 0, 1;
    end;

    if p3 > 1 then
        local math_sqrt_ret = math.sqrt(p3 ^ 2 - 1);
        local v5 = -p4 * (math_sqrt_ret + p3);
        local v6 = p4 * (math_sqrt_ret - p3);
        local math_exp_ret = math.exp(p2 * v5);
        local math_exp_ret2 = math.exp(p2 * v6);
        local v7 = -0.5 / (math_sqrt_ret * p4);

        return (math_exp_ret2 * v5 - math_exp_ret * v6) * v7, (math_exp_ret - math_exp_ret2) * v7 / p4, (math_exp_ret2 - math_exp_ret) * v7 * p4, (math_exp_ret * v5 - math_exp_ret2 * v6) * v7;
    end;

    if p3 == 1 then
        local v8 = p2 * p4;
        local math_exp_ret = math.exp(-v8);

        return math_exp_ret * (v8 + 1), math_exp_ret * p2, math_exp_ret * (-p4 * v8), math_exp_ret * (1 - v8);
    end;

    local v9 = p4 * math.sqrt(1 - p3 ^ 2);
    local v10 = p4 * p3;
    local math_exp_ret = math.exp(-v10 * p2);
    local math_cos_ret = math.cos(v9 * p2);
    local math_sin_ret = math.sin(v9 * p2);
    local v11 = 1 / v9;

    return math_exp_ret * (math_cos_ret + v10 * v11 * math_sin_ret), math_exp_ret * math_sin_ret * v11, -math_exp_ret * (p4 * p4 * v11 * math_sin_ret), math_exp_ret * (math_cos_ret - v10 * v11 * math_sin_ret);
end;

local function wake(p12) -- Line: 90
    if not p12._springInit then
        p12._springInit = os.clock();
    end;
end;

local function sleep(p13) -- Line: 96
    -- upvalues: DataType (copy)
    if p13._springInit then
        p13._springInit = nil;

        for i = 1, p13._activeNumSprings do
            p13._activeLatestP[i] = p13._activeTargetP[i];
            p13._activeLatestV[i] = 0;
            local _ = i;
        end;

        p13._value = DataType.pack(p13._activeLatestP, p13._activeType);
        task.spawn(p13._update, p13, true, true, true);
    end;
end;

local function initSpring(p14: any, p15: any, p16: string, p17: number, p18: number, p19: boolean) -- Line: 111
    -- upvalues: DataType (copy)
    local v20 = DataType.unpack(p15, p16);
    p14._activeTargetP = v20;
    p14._activeNumSprings = #v20;
    p14._activeType = p16;
    p14._activeGoal = p15;
    p14._activeDamping = p18;
    p14._activeSpeed = p17;

    if not p19 and p14._activeLatestP then
        p14._activeStartP = table.clone(p14._activeLatestP);
        p14._activeStartV = table.clone(p14._activeLatestV);

        if not p14._springInit then
            p14._springInit = os.clock();
        end;

        return;
    end;

    p14._activeStartP = table.clone(v20);
    p14._activeLatestP = table.clone(v20);
    p14._activeStartV = table.create(p14._activeNumSprings, 0);
    p14._activeLatestV = table.create(p14._activeNumSprings, 0);
    p14._value = DataType.pack(v20, p16);
    task.spawn(p14._update, p14, true, true, true);
end;

local function stepSpring(p21: any, p22: number) -- Line: 144
    -- upvalues: springCoefficients (copy), DataType (copy), sleep (copy)
    local _springInit = p21._springInit;

    if not _springInit then
        return;
    end;

    local v23, v24, v25, v26 = springCoefficients(os.clock() - _springInit, p21._activeDamping or 1, p21._activeSpeed or 1);
    local v27 = false;

    for i = 1, p21._activeNumSprings do
        local v28 = p21._activeTargetP[i];
        local v29 = p21._activeStartV[i];
        local v30 = p21._activeStartP[i] - v28;
        local v31 = v30 * v23 + v29 * v24;
        local v32 = v30 * v25 + v29 * v26;

        if v31 ~= v31 or v32 ~= v32 then
            v31 = 0;
            v32 = 0;
        end;

        v27 = (math.abs(v31) > 0.0001 or math.abs(v32) > 0.0001) and true or v27;
        p21._activeLatestP[i] = v31 + v28;
        p21._activeLatestV[i] = v32;
        local _ = i;
    end;

    if not v27 then
        sleep(p21);

        return;
    end;

    p21._value = DataType.pack(p21._activeLatestP, p21._activeType);
    task.spawn(p21._update, p21, true, true, true);
end;

local function destroySpring(p33) -- Line: 191
    -- upvalues: u1 (copy), State (copy)
    u1[p33] = nil;
    State.Destroy(p33);
end;

RunService.Heartbeat:Connect(function(p34) -- Line: 196
    -- upvalues: u1 (copy), isState (copy), initSpring (copy), stepSpring (copy)
    for i in u1 do
        if i._springInit then
            local _springGoal = i._springGoal;

            if isState(_springGoal) then
                _springGoal = _springGoal._value;
            end;

            local _springSpeed = i._springSpeed;

            if isState(_springSpeed) then
                _springSpeed = _springSpeed._value;
            end;

            local _springDamping = i._springDamping;

            if isState(_springDamping) then
                _springDamping = _springDamping._value;
            end;

            local v35 = typeof(_springGoal);
            local v36 = v35 ~= i._activeType;

            if v36 or (_springGoal ~= i._activeGoal or (_springSpeed ~= i._activeSpeed or _springDamping ~= i._activeDamping)) then
                initSpring(i, _springGoal, v35, _springSpeed, _springDamping, v36);
            end;

            stepSpring(i, p34);
        end;
    end;
end);
local v37 = {};
v37.__index = v37;

function v37.new(u38, p39, p40) -- Line: 236
    -- upvalues: State (copy), wake (copy), destroySpring (copy), initSpring (copy), u1 (copy)
    local v41;

    if type(u38) == "function" then
        v41 = State.compute(u38);
    elseif State.isState(u38) and u38._computation == nil then
        v41 = State.compute(function() -- Line: 248
            -- upvalues: u38 (copy)
            return u38();
        end);
    else
        v41 = State.new(u38);
    end;

    v41._springGoal = v41._value;
    v41._springSpeed = p39 or 10;
    v41._springDamping = p40 or 1;
    v41.wake = wake;
    v41.Destroy = destroySpring;
    initSpring(v41, v41._value, typeof(v41._value), State.raw(p39 or 10), State.raw(p40 or 1), true);
    u1[v41] = true;

    return v41;
end;

return v37;