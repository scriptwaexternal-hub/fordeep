-- Decompiled with Potassium's decompiler.

return function(u1) -- Line: 1
    local function roleIdSort(p2, p3) -- Line: 4
        -- upvalues: u1 (copy)
        return u1.Data.roles[p2[1]]._rank > u1.Data.roles[p3[1]]._rank;
    end;

    local function roleParse(p4: string, p5: any) -- Line: 8
        -- upvalues: u1 (copy)
        local string_lower_ret = string.lower(p4);
        local Rank = u1.Auth.getRank(p5.command.from);

        for i, v in u1.Data.roles do
            if v ~= u1.Data.roles.everyone and (p5.command.from == u1.creatorId or v._rank < Rank) and string.find(string.lower(i), string_lower_ret, 1, true) == 1 then
                return i;
            end;
        end;

        return nil, "Invalid role";
    end;

    local v9 = {
        validate = roleParse,
        parse = roleParse,

        suggestions = function(p6: string, p7: number) -- Line: 28, Name: suggestions
            -- upvalues: u1 (copy), roleIdSort (copy)
            local Rank = u1.Auth.getRank(p7);
            local v8 = {};

            for i, v in u1.Data.roles do
                if v ~= u1.Data.roles.everyone and (p7 == u1.creatorId or v._rank < Rank) then
                    table.insert(v8, { i, nil, v });
                end;
            end;

            table.sort(v8, roleIdSort);

            return v8, u1.Data.roles;
        end
    };
    u1.Registry.registerType("role", v9);
    u1.Registry.registerType("roles", {
        listable = true
    }, v9);
end;