-- Decompiled with Potassium's decompiler.

local Players = game:GetService("Players");
local ReplicatedStorage = game:GetService("ReplicatedStorage");
local RunService = game:GetService("RunService");
local Debris = game:GetService("Debris");
local TweenService = game:GetService("TweenService");
local SpaceshipConfig = require(ReplicatedStorage.Modules.Metadata.MiscData.TechData.SpaceshipConfig);
local LocalPlayer = Players.LocalPlayer;
local workspace_CurrentCamera = workspace.CurrentCamera;
local v1 = {};
local u2 = { "rbxassetid://114303603199822", "rbxassetid://98609496290942" };
local Color3_fromRGB_ret = Color3.fromRGB(44, 44, 45);
local Color3_fromRGB_ret2 = Color3.fromRGB(28, 28, 30);
local Color3_fromRGB_ret3 = Color3.fromRGB(0, 0, 0);
local Color3_fromRGB_ret4 = Color3.fromRGB(255, 255, 255);
local Color3_fromRGB_ret5 = Color3.fromRGB(216, 213, 205);
local Color3_fromRGB_ret6 = Color3.fromRGB(90, 200, 120);
local Color3_fromRGB_ret7 = Color3.fromRGB(226, 62, 48);
local u3 = setmetatable({}, {
    __mode = "k"
});

local function stroked(p4) -- Line: 58
    -- upvalues: Color3_fromRGB_ret3 (copy)
    p4.TextStrokeColor3 = Color3_fromRGB_ret3;
    p4.TextStrokeTransparency = 0.5;

    return p4;
end;

local function outline(p5, p6) -- Line: 64
    -- upvalues: Color3_fromRGB_ret3 (copy)
    local UIStroke = Instance.new("UIStroke");
    UIStroke.Color = Color3_fromRGB_ret3;
    UIStroke.Thickness = p6 or 1.5;
    UIStroke.Parent = p5;

    return UIStroke;
end;

local function buildHullBar(p7, p8) -- Line: 72
    -- upvalues: Color3_fromRGB_ret (copy), Color3_fromRGB_ret3 (copy), Color3_fromRGB_ret4 (copy), Color3_fromRGB_ret5 (copy), Color3_fromRGB_ret2 (copy), Color3_fromRGB_ret6 (copy)
    local BillboardGui = Instance.new("BillboardGui");
    BillboardGui.Name = "HullBar";
    BillboardGui.Adornee = p8;
    BillboardGui.Size = UDim2.fromOffset(180, 46);
    BillboardGui.StudsOffsetWorldSpace = Vector3.new(0, 10, 0);
    BillboardGui.AlwaysOnTop = true;
    BillboardGui.MaxDistance = 250;
    BillboardGui.ResetOnSpawn = false;
    local Frame = Instance.new("Frame");
    Frame.Size = UDim2.new(1, 0, 1, 0);
    Frame.BackgroundColor3 = Color3_fromRGB_ret;
    Frame.BorderSizePixel = 0;
    Frame.BackgroundTransparency = 1;
    Frame.Parent = BillboardGui;
    local UIStroke = Instance.new("UIStroke");
    UIStroke.Color = Color3_fromRGB_ret3;
    UIStroke.Thickness = 1.5;
    UIStroke.Parent = Frame;
    UIStroke.Transparency = 1;
    local TextLabel = Instance.new("TextLabel");
    TextLabel.BackgroundTransparency = 1;
    TextLabel.Position = UDim2.new(0, 8, 0, 4);
    TextLabel.Size = UDim2.new(0.5, -8, 0, 16);
    TextLabel.Font = Enum.Font.Arcade;
    TextLabel.TextSize = 14;
    TextLabel.TextColor3 = Color3_fromRGB_ret4;
    TextLabel.TextXAlignment = Enum.TextXAlignment.Left;
    TextLabel.Text = "HULL";
    TextLabel.TextTransparency = 1;
    TextLabel.TextStrokeColor3 = Color3_fromRGB_ret3;
    TextLabel.TextStrokeTransparency = 0.5;
    TextLabel.Parent = Frame;
    local TextLabel2 = Instance.new("TextLabel");
    TextLabel2.BackgroundTransparency = 1;
    TextLabel2.Position = UDim2.new(0.5, 0, 0, 4);
    TextLabel2.Size = UDim2.new(0.5, -8, 0, 16);
    TextLabel2.Font = Enum.Font.Bangers;
    TextLabel2.TextSize = 16;
    TextLabel2.TextColor3 = Color3_fromRGB_ret5;
    TextLabel2.TextXAlignment = Enum.TextXAlignment.Right;
    TextLabel2.Text = "";
    TextLabel2.TextTransparency = 1;
    TextLabel2.TextStrokeColor3 = Color3_fromRGB_ret3;
    TextLabel2.TextStrokeTransparency = 0.5;
    TextLabel2.Parent = Frame;
    local Frame2 = Instance.new("Frame");
    Frame2.Position = UDim2.new(0, 8, 0, 26);
    Frame2.Size = UDim2.new(1, -16, 0, 12);
    Frame2.BackgroundColor3 = Color3_fromRGB_ret2;
    Frame2.BorderSizePixel = 0;
    Frame2.BackgroundTransparency = 1;
    Frame2.Parent = Frame;
    local UIStroke2 = Instance.new("UIStroke");
    UIStroke2.Color = Color3_fromRGB_ret3;
    UIStroke2.Thickness = 1.5;
    UIStroke2.Parent = Frame2;
    UIStroke2.Transparency = 1;
    local Frame3 = Instance.new("Frame");
    Frame3.Size = UDim2.new(1, 0, 1, 0);
    Frame3.BackgroundColor3 = Color3_fromRGB_ret6;
    Frame3.BorderSizePixel = 0;
    Frame3.BackgroundTransparency = 1;
    Frame3.Parent = Frame2;
    BillboardGui.Parent = p8;

    return {
        Token = 0,
        Gui = BillboardGui,
        Card = Frame,
        Fill = Frame3,
        Value = TextLabel2,
        Fades = { Frame, Frame2, Frame3 },
        Strokes = { UIStroke, UIStroke2 },
        Texts = { TextLabel, TextLabel2 }
    };
end;

local function setHullBarVisible(p9, p10) -- Line: 140
    -- upvalues: TweenService (copy)
    local TweenInfo_new_ret = TweenInfo.new(0.4);
    local v11 = p10 and 0 or 1;

    for _, v in ipairs(p9.Fades) do
        TweenService:Create(v, TweenInfo_new_ret, {
            BackgroundTransparency = v11
        }):Play();
    end;

    for _, v in ipairs(p9.Strokes) do
        TweenService:Create(v, TweenInfo_new_ret, {
            Transparency = v11
        }):Play();
    end;

    for _, v in ipairs(p9.Texts) do
        TweenService:Create(v, TweenInfo_new_ret, {
            TextTransparency = v11,
            TextStrokeTransparency = p10 and 0.5 or 1
        }):Play();
    end;
end;

local function refreshHullBar(p12, p13) -- Line: 150
    -- upvalues: SpaceshipConfig (copy), TweenService (copy), Color3_fromRGB_ret7 (copy), Color3_fromRGB_ret6 (copy)
    local MAX_HEALTH = SpaceshipConfig.MAX_HEALTH;
    local v14 = tonumber(p12:GetAttribute("Health")) or MAX_HEALTH;
    local v15 = v14 / math.max(1, MAX_HEALTH);
    local math_clamp_ret = math.clamp(v15, 0, 1);
    TweenService:Create(p13.Fill, TweenInfo.new(0.18), {
        Size = UDim2.new(math_clamp_ret, 0, 1, 0)
    }):Play();
    p13.Fill.BackgroundColor3 = math_clamp_ret <= 0.3 and Color3_fromRGB_ret7 or Color3_fromRGB_ret6;
    p13.Value.Text = string.format("%d / %d", math.floor(v14), (math.floor(MAX_HEALTH)));
end;

local function showHullBar(u16, p17) -- Line: 159
    -- upvalues: u3 (copy), buildHullBar (copy), refreshHullBar (copy), setHullBarVisible (copy)
    local u18 = u3[u16];

    if not (u18 and u18.Gui.Parent) then
        u18 = buildHullBar(u16, p17);
        u3[u16] = u18;
        u18.Conn = u16:GetAttributeChangedSignal("Health"):Connect(function() -- Line: 164
            -- upvalues: u18 (ref), refreshHullBar (ref), u16 (copy)
            if u18.Gui.Parent then
                refreshHullBar(u16, u18);
            end;
        end);
    end;

    refreshHullBar(u16, u18);
    setHullBarVisible(u18, true);
    u18.Token = u18.Token + 1;
    local Token = u18.Token;
    task.delay(6, function() -- Line: 174
        -- upvalues: u18 (ref), Token (copy), setHullBarVisible (ref)
        if u18.Token ~= Token or not u18.Gui.Parent then
            return;
        end;

        setHullBarVisible(u18, false);
    end);
end;

local function destroyHullBar(p19) -- Line: 180
    -- upvalues: u3 (copy)
    local v20 = u3[p19];

    if not v20 then
        return;
    end;

    u3[p19] = nil;

    if v20.Conn then
        v20.Conn:Disconnect();
    end;

    if v20.Gui then
        v20.Gui:Destroy();
    end;
end;

local function watchShip(u21) -- Line: 195
    -- upvalues: SpaceshipConfig (copy), showHullBar (copy), u3 (copy)
    if not u21:IsA("Model") then
        return;
    end;

    local function check() -- Line: 197
        -- upvalues: u21 (copy), SpaceshipConfig (ref), showHullBar (ref)
        local v22 = tonumber(u21:GetAttribute("Health"));
        local v23 = v22 and (v22 < SpaceshipConfig.MAX_HEALTH and v22 > 0) and (u21.PrimaryPart or u21:FindFirstChild("Pod"));

        if v23 then
            showHullBar(u21, v23);
        end;
    end;

    u21:GetAttributeChangedSignal("Health"):Connect(check);
    u21.AncestryChanged:Connect(function(p24, p25) -- Line: 205
        -- upvalues: u21 (copy), u3 (ref)
        if not p25 then
            local v26 = u21;
            local v27 = u3[v26];

            if not v27 then
                return;
            end;

            u3[v26] = nil;

            if v27.Conn then
                v27.Conn:Disconnect();
            end;

            if v27.Gui then
                v27.Gui:Destroy();
            end;
        end;
    end);
    task.defer(check);
end;

task.spawn(function() -- Line: 211
    -- upvalues: SpaceshipConfig (copy), watchShip (copy)
    local v28 = workspace:WaitForChild("World"):WaitForChild(SpaceshipConfig.SHIP_FOLDER, 30);

    if not v28 then
        return;
    end;

    for _, child in ipairs(v28:GetChildren()) do
        watchShip(child);
    end;

    v28.ChildAdded:Connect(watchShip);
end);

local function getRoot(p29) -- Line: 219
    if p29 then
        p29 = p29.PrimaryPart or p29:FindFirstChild("Pod");
    end;

    return p29;
end;

local function isPiloting(p30) -- Line: 223
    -- upvalues: LocalPlayer (copy)
    if p30 then
        p30 = p30:FindFirstChildOfClass("VehicleSeat");
    end;

    if p30 then
        p30 = p30.Occupant;
    end;

    local v31;

    if p30 == nil then
        v31 = false;
    else
        v31 = p30.Parent == LocalPlayer.Character;
    end;

    return v31;
end;

local function cameraKick(p32, u33) -- Line: 231
    -- upvalues: RunService (copy), workspace_CurrentCamera (copy)
    local math_clamp_ret = math.clamp(p32, 0, 1.6);
    local u34 = 0;
    local u35 = nil;
    u35 = RunService.RenderStepped:Connect(function(p36) -- Line: 235
        -- upvalues: u34 (ref), u33 (copy), u35 (ref), math_clamp_ret (ref), workspace_CurrentCamera (ref)
        u34 = u34 + p36;

        if u33 <= u34 then
            u35:Disconnect();

            return;
        end;

        local v37 = math_clamp_ret * (1 - u34 / u33);
        local CFrame2 = workspace_CurrentCamera.CFrame;
        local CFrame_Angles = CFrame.Angles;
        local v38 = (math.random() - 0.5) * v37;
        local math_rad_ret = math.rad(v38);
        local v39 = (math.random() - 0.5) * v37;
        local math_rad_ret2 = math.rad(v39);
        local v40 = (math.random() - 0.5) * v37;
        workspace_CurrentCamera.CFrame = CFrame2 * CFrame_Angles(math_rad_ret, math_rad_ret2, (math.rad(v40)));
    end);
end;

local function sparkBurst(p41, p42) -- Line: 251
    -- upvalues: Debris (copy)
    local Attachment = Instance.new("Attachment");
    Attachment.Parent = p41;
    local ParticleEmitter = Instance.new("ParticleEmitter");
    ParticleEmitter.Color = ColorSequence.new(Color3.fromRGB(255, 190, 90), Color3.fromRGB(255, 80, 40));
    ParticleEmitter.LightEmission = 1;
    ParticleEmitter.Size = NumberSequence.new(0.8, 0);
    ParticleEmitter.Transparency = NumberSequence.new(0.1, 1);
    ParticleEmitter.Speed = NumberRange.new(18, 34);
    ParticleEmitter.Lifetime = NumberRange.new(0.25, 0.5);
    ParticleEmitter.SpreadAngle = Vector2.new(180, 180);
    ParticleEmitter.Rate = 0;
    ParticleEmitter.Parent = Attachment;
    local math_floor_ret = math.floor(p42 / 8);
    ParticleEmitter:Emit((math.clamp(math_floor_ret, 6, 40)));
    Debris:AddItem(Attachment, 1.5);
end;

function v1.Impact(p43) -- Line: 270
    -- upvalues: sparkBurst (copy), showHullBar (copy), u2 (copy), Debris (copy), LocalPlayer (copy), SpaceshipConfig (copy), RunService (copy), workspace_CurrentCamera (copy)
    local Ship = p43.Ship;
    local v44;

    if Ship then
        v44 = Ship.PrimaryPart or Ship:FindFirstChild("Pod");
    else
        v44 = Ship;
    end;

    if not v44 then
        return;
    end;

    sparkBurst(v44, p43.Amount or 50);
    showHullBar(Ship, v44);
    local Sound = Instance.new("Sound");
    Sound.SoundId = u2[math.random(1, #u2)];
    Sound.PlaybackSpeed = math.random(70, 120) / 100;
    Sound.Volume = math.random(80, 120) / 100;
    Sound.RollOffMaxDistance = 300;
    Sound.Parent = v44;
    Sound:Play();
    Debris:AddItem(Sound, 3);

    if Ship then
        Ship = Ship:FindFirstChildOfClass("VehicleSeat");
    end;

    if Ship then
        Ship = Ship.Occupant;
    end;

    local v45;

    if Ship == nil then
        v45 = false;
    else
        v45 = Ship.Parent == LocalPlayer.Character;
    end;

    if v45 then
        local DAMAGE_SHAKE_TIME = SpaceshipConfig.DAMAGE_SHAKE_TIME;
        local math_clamp_ret = math.clamp(0.9, 0, 1.6);
        local u46 = 0;
        local u47 = nil;
        u47 = RunService.RenderStepped:Connect(function(p48) -- Line: 235
            -- upvalues: u46 (ref), DAMAGE_SHAKE_TIME (copy), u47 (ref), math_clamp_ret (ref), workspace_CurrentCamera (ref)
            u46 = u46 + p48;

            if DAMAGE_SHAKE_TIME <= u46 then
                u47:Disconnect();

                return;
            end;

            local v49 = math_clamp_ret * (1 - u46 / DAMAGE_SHAKE_TIME);
            local CFrame2 = workspace_CurrentCamera.CFrame;
            local CFrame_Angles = CFrame.Angles;
            local v50 = (math.random() - 0.5) * v49;
            local math_rad_ret = math.rad(v50);
            local v51 = (math.random() - 0.5) * v49;
            local math_rad_ret2 = math.rad(v51);
            local v52 = (math.random() - 0.5) * v49;
            workspace_CurrentCamera.CFrame = CFrame2 * CFrame_Angles(math_rad_ret, math_rad_ret2, (math.rad(v52)));
        end);
    end;
end;

function v1.Destroy(p53) -- Line: 294
    -- upvalues: u3 (copy), sparkBurst (copy), LocalPlayer (copy), RunService (copy), workspace_CurrentCamera (copy)
    local Ship = p53.Ship;
    local v54;

    if Ship then
        v54 = Ship.PrimaryPart or Ship:FindFirstChild("Pod");
    else
        v54 = Ship;
    end;

    if not v54 then
        return;
    end;

    local v55 = u3[Ship];

    if v55 then
        u3[Ship] = nil;

        if v55.Conn then
            v55.Conn:Disconnect();
        end;

        if v55.Gui then
            v55.Gui:Destroy();
        end;
    end;

    sparkBurst(v54, 400);
    local Smoke = Instance.new("Smoke");
    Smoke.Color = Color3.fromRGB(40, 40, 40);
    Smoke.Size = 12;
    Smoke.RiseVelocity = 8;
    Smoke.Parent = v54;
    local v56 = Ship and Ship:FindFirstChildOfClass("VehicleSeat");

    if v56 then
        v56 = v56.Occupant;
    end;

    local v57;

    if v56 == nil then
        v57 = false;
    else
        v57 = v56.Parent == LocalPlayer.Character;
    end;

    if v57 then
        local math_clamp_ret = math.clamp(1.6, 0, 1.6);
        local u58 = 0;
        local u59 = nil;
        local u60 = 0.8;
        u59 = RunService.RenderStepped:Connect(function(p61) -- Line: 235
            -- upvalues: u58 (ref), u60 (copy), u59 (ref), math_clamp_ret (ref), workspace_CurrentCamera (ref)
            u58 = u58 + p61;

            if u60 <= u58 then
                u59:Disconnect();

                return;
            end;

            local v62 = math_clamp_ret * (1 - u58 / u60);
            local CFrame2 = workspace_CurrentCamera.CFrame;
            local CFrame_Angles = CFrame.Angles;
            local v63 = (math.random() - 0.5) * v62;
            local math_rad_ret = math.rad(v63);
            local v64 = (math.random() - 0.5) * v62;
            local math_rad_ret2 = math.rad(v64);
            local v65 = (math.random() - 0.5) * v62;
            workspace_CurrentCamera.CFrame = CFrame2 * CFrame_Angles(math_rad_ret, math_rad_ret2, (math.rad(v65)));
        end);
    end;
end;

return v1;