GOHAN 悟飯 FAST LEVELING GUIDE:

## **Quick Tips**

- **Run the full story questline** — it's your fastest early leveling path.
- **Spend all 10 GTP before trying to level up** — it's mandatory.
- **Pick your Fighting School** — it locks which skills you can ever learn like Kamehameha.
- **Watch your Health** — you only survive 4 deaths before Heaven or Hell.
- **Keep Motivation above 100** so you can level up faster it increases your exp gain %.
- **If Your a Saiyan Get All Zenaki Boosts As Fast As Possible, The Lower Level you aare the Easier it Is** Get Zenkai Boost By Getting Knocked  and Then Regaining your HP Multiple Times there is a 30min cooldown till your next Zenkai Boost the mAx Zenkai is 20
- **Train Transformation Mastery** on any transformation you use often — mastery makes it so you stay in the form longer  (crucial for forms like LSSJ that otherwise force a berserk state).
- **Once the story's done, grind the Mission Board** to keep leveling.


1. ## **Ki & Flight (Have to Do this In order to get Access to your Other Stats when your First Start)**

**How to unlock Ki:**
1. When you load in on a new slot, press **M** to start meditating and click the first option at the top.
2. A circle will appear telling you to **hold Space to breathe**.
3. Keep doing this for a certain amount of time and you'll unlock Ki.
4. **This does NOT give you flight** — flight is unlocked separately via the skill tree.

Once Ki is unlocked, hold **C** to charge it, and **X or G** to access transformations tied to ki thresholds.


2. ## **Gameplay**

1. **Load in and run the story questline** — completing the full story is how you get your main early levels.
2. **Fight and quest to fill your stat points.** You gain 10 UTP per rank, and sparring/missions convert it to GTP. **You must spend all 10 GTP** before you can level up — put it into whatever stat(s) fit your build **(strength, ki damage, ki control, etc...)**
3. **Join a Fighting School** — Crane, Brawling, or Turtle Hermit. You need to be in one of these to learn skills from trainers, and each trainer only teaches skills tied to their own school (e.g., a Crane student can't learn Nappa's skills if Nappa teaches under Brawling).
4. **Obtain and unlock your Forms** do it as you go —  but some are sitting in your skill tree, others need a quest or another unlock condition.
5. **Train your Form Mastery.** The more mastery you have in a form, the less Ki it costs to hold, the more control you have in it, and so on.
6. **Grind the Mission Board** once the main story is done, to keep leveling and stacking stats or use a reset code to reset the story line and redo it again .

3. ## **Mission Board**

Once you're through the main storyline, the **Mission Board** becomes your main leveling loop — you can repeatedly pick up missions from it to keep converting UTP into GTP, gain XP, and stack stats without needing new story content. This is the "endgame grind" once the questline itself is exhausted.


4. ## **Motivation**

- If your Motivation is **low or negative**, it **slows your progress**. The **higher** it is, the **faster** you progress.
- **Dying makes you lose Motivation.**
- **Eating** or **Meditating** **increases** Motivation.
- **Eating Rice** specifically raises Motivation.
- Certain forms (like Legendary Super Saiyan) explicitly require **100+ Motivation** as part of their unlock condition — so this stat isn't just a speed multiplier, it can gate content outright.


5. ## **Stats (UTP, GTP, SP)**

Open your stat menu with **Tab**. Three separate point pools *(Trello-confirmed)*:

- **UTP (Ungained Training Points)** — every new rank you gain 10 UTP. Sparring and completing missions **converts your UTP into GTP**.
- **GTP (Gained Training Points)** — these are the points you actually spend on stats. **You cannot level up without spending all 10 of your GTP.**
- **SP (Skill Points)** — every *level* grants 1 SP, spent in the skill tree.

**Core stats you allocate points into:**

| Stat | What it affects |
|---|---|
| **Strength** | Physical melee damage |
| **Agility** | Movement/attack speed |
| **Durability** | How much damage you can take |
| **KiDmg** | Damage of ki blasts/energy attacks |
| **KiControl** | Ki efficiency/control (affects ki-based abilities and charging) |
| **Motivation** | Only increases your Potential so you can get more EXP from doing stuff but it doesnt actually use a Stat Point |

Decide on a build direction (melee brawler vs. ki blaster vs. balanced) before dumping points.

6. ## **Skill Tree (Spending SP/Skill Points)/ How To Unlock Ki Flight**

 Press **L** to open the Ki/skill menu, split into a few sections:

| Section | Skill | SP Cost |
|---|---|---|
| Ki Section | **Ki Flight** — actually gives you flight | 1 SP |
| Ki Section | **Ki Suppression** — hides/lowers your ki presence | 1 SP |
| Ki Section | **Ki Sense** — lets you sense other players' ki | 5 SP |
| Basic Section | **Snap Vanish** — widely considered the most useful basic skill | 1 SP |
| Race Section | Race-specific skills (example: **Death Beam** for Arcosians) | Varies Depending on Your Race |

So the actual path to flying is: unlock Ki via meditation → earn SP by leveling → spend 1 SP on **Ki Flight**.

## **EVERYTHING ELSE:**

## **Death, Reviving & Vitality**

- **Vitality** can be checked by **a doctor**. You spawn in with **100 Vitality**.
- Every time you die, you **lose 25 Vitality**.
- If you reach **0 Vitality**, you'll be sent to **Heaven or Hell**, depending on your **Karma**.
- When you die, you can **wait 15 minutes** and then talk to **King Yemma (Heaven)** or **Alucard (Hell)**.
- **Currently, the only way to restore Vitality is Classing up** — which happens every 7 level-ups (i.e., every time you Limit Break into a new rank).

You only survive 4 deaths (100 ÷ 25) before Heaven/Hell, and the only known fix is grinding a full rank's worth of levels.

## **Fighting Schools & Trainers To Get Skills like Kamehameha**

### The 3 Fighting Styles — full unlock quest chains

**Turtle Hermit School**
- Can be trained by **Krillin** on Earth and By Roshi at Roshi House.
- Quest 1 — Deliver a turtle shell to Kame's house.
- Quest 2 — Gain Ki and Ki Control (20 Ki Control needed).
- Quest 3 — Defeat 1 Red Ribbon soldier.
- Final Quest — Defeat the Turtle Hermit School master.

**Crane** on Planet Namek
- Quest 1 — Buy the school outfit for 150 Zeni.
- Quest 2 — Targets spawn directly above you; hit them with a ki blast or M1.
- Quest 3 — Do a quiz related to ki and strategy.
- *(Then wait roughly 15 minutes.)*
- Final Quest — Defeat the Crane School master (200-second timer).

**Brawler School** on Earth
- Style summary: slower M1s, high physical damage, longer stuns, and good ki damage — but not many ki options.
- Quest 1 — Hit the boulder 250 times.
- Quest 2 — Get hit 50 times (130-second timer).
- Quest 3 — Get 80 Strength.
- Final Quest — Defeat the Brawler School master.

### Trainers, grouped by school
Each trainer only teaches skills belonging to their own school — a Crane student can't learn a Brawler trainer's skills, and vice versa. Skills are unlocked by meeting stat/fight requirements, then bought with Zeni.

**Turtle NPCs**

- **Krillin** — Talk to him hes found outside Capsule Corp on Earth. Once unlocked, teaches:
  - *Spread Energy Blast* — Requires: 2 Fights won, 45 Ki Control, 45 Strength, 2000 Zeni
  - *Kamehameha* — Requires: 40 enemies killed, 10 Fights won, 65 Strength, some ki attacks landed, 75 Ki Control, 4500 Zeni
  - *Kienzan* — Requires: 5 Fights won, some ki attacks landed, 60 Ki Control, 55 Strength, 4500 Zeni

- **Raditz** — Talk to him hes located under the Shop on Planet Sadala. Teaches:
  - *Double Sunday* — Requires: 2 Fights won, 30 Ki Control, 35 Strength, 750 Zeni
  - *Behind You* — Requires: 40 enemies killed, 10 Fights won, some ki attacks landed, 60 Ki Control, 50 Strength, 4500 Zeni
  - *Energy Crash* — Requires: 5 Fights won, some ki attacks landed, 45 Ki Control, 45 Strength, 2000 Zeni

- **Ginyu (Turtle)** — teaches:
  - *Body Swap* **(marked UNOBTAINABLE)** — Requires: 95 Strength, 120 Ki Control, 80 Durability, 65 SP. Swaps skills with your opponent: you take theirs and keep your own; they end up with only your skills. **Neither of you get your race passives** during the swap, since you're not in your own body.
  - *Ginyu Pose* — Requires: 5 Fights won, some ki attacks landed, 65 Ki Control, 60 Strength, **6750 Zeni** (the card literally notes "Not a joke"). Buffs you roughly **1.4x** for a short period.
  - *Milky Cannon* — Requires: 2 Fights won, 50 Ki Control, 50 Strength, 2600 Zeni. A big ball attack that does heavy damage.

**Crane Trainers**

- **Vegeta** — Talk to him hes found on Planet Namek. Teaches:
  - *Ki Barrage* — Requires: 30 Ki Control, 15 Ki Damage
  - *Galaxy Breaker* — Requires: 45 Ki Control, 25 Ki Damage
  - *Explosion Wave* — Requires: 60 Ki Control, 40 Ki Damage
  - *Galick Gun* — Requires: 105 Ki Control, 75 Ki Damage

- **Tien** — Talk to him hes found on one of the small pillars around Capsule Corp. Teaches:
  - *Solar Flare* — Requires: 750 Zeni, 15 Ki Control
  - *Tri Beam* — Requires: 2000 Zeni, 50 Ki Control, 25 Ki Damage
  - *Neo Tri Beam* — Requires: 4500 Zeni, 75 Ki Control, 50 Ki Damage

**Brawler Trainers**

- **Recoome** — teaches:
  - *Sledgehammer* — Requires: 50 Strength, 25 Ki Control, 750 Zeni
  - *Eraser Gun* — Requires: 75 Strength, 60 Ki Control, 2000 Zeni
  - *Ultra Fighting Bomber* — Requires: 100 Strength, 90 Ki Control, 4500 Zeni
- **Broly** *(labeled "Legendary Saiyan")* — Talk to him hes found in one of the tree/garden areas at the edge of Planet Sadala. Teaches:
  - *Dragon Throw* — Requires: 35 Strength *(Zeni cost not fully visible on the card)*
  - *Bone Crusher* — Requires: 75 Strength *(Zeni cost not fully visible on the card)*
  - *Eraser Cannon* — Requires: 75 Strength, 35 Ki Damage, 4500 Zeni
- **Nappa** — Talk to him hes located at the edge of Sadala Capital Planet Teaches:
  - *Volcano Explosion* — Requires: 45 Strength, 40 Ki Control, 750 Zeni
  - *Blazing Storm* — Requires: 65 Strength, 45 Ki Control, 2000 Zeni
  - *Arm Break* — Requires: 90 Strength, 60 Ki Control, 4500 Zeni


## **Karma System**

Karma is a good/evil alignment track that gates certain race-specific content and also determines whether you go to **Heaven or Hell** when you run out of Vitality:
- **Majin** players lean into **evil Karma** to power up (Majin Mark, absorption path).
- **Demon** players use Karma choices to shape their transformation path (e.g., toward Dabura or Janemba).
- **Namekian** and other neutral races aren't locked to either path.


## **Race Rerolls & Potential**

Four types of rerolls, done from the character customization screen:

| Reroll Type | What it does |
|---|---|
| **Race Reroll** | Changes your race — a certain % chance to get any given new race |
| **Trait Reroll** | Rerolls your subtype (see the Traits table above) |
| **Ki Color Reroll** | Changes your ki color |
| **Potential Reroll** | Rerolls your **Potential**, which gives an XP-gain buff — the higher your Potential, the bigger the buff |

**Race, Ki Color, and Potential rerolls WIPE your character slot.** **Trait Reroll is the only one that does NOT wipe your slot.**

You earn **Race Spins**, **Trait Spins**, and other resets mainly from redeeming codes. The game also has **multiple character slots** you can switch between.


## **Currency: Zeni**

 **Zeni** is the universal currency, used to pay for clothing, food, and other items.

**How to get Zeni:**
- Sell items you get from **chests** to Bulma.
- The best NPCs to farm for chest loot are the **Ginyu Force boss** or **Saiyans on Planet Sadala**.
- You can also **steal loot from other players after they've been knocked out**.


## **Combat Mechanics Basics**

- **M1/M2** combos form your basic offense; **1–4** are equipped skills.
- **F** blocks — timing it precisely triggers a **Perfect Block**.
- **R** allows you to dodge an enemys attack and Z Vanish behind them
- **C** charges Ki once unlocked; **X** transforms; **G** lists your unlocked transformations.
- Fighting actions like M1s are **not** slowed by low gravity mastery (only movement/running is).
- Transformations generally increase your stats/Battle Power significantly but may have activation requirements (rage meter, near-death state, absorption count, karma threshold, motivation threshold, or a charged ki gauge, depending on race/form).


